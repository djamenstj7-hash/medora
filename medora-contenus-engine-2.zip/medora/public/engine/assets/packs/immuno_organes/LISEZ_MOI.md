# Organes et structures lymphoïdes du système immunitaire — paquet Immunologie

76 notes, 148 cartes. Chapitre `chap-ue-immunologie-fc2` de l'UE Immunologie
(identifiant du squelette), pour l'examen de novembre. Cours du **Pr Lefèvre, le
21/09/2026** (semaine 3), un ronéo de 14 pages ; quatorze questions d'annales sur
neuf sessions.

## La méthode (Vincent, 28/09)

Le **Ronéosaure S1** — la FC n°2 du Pr Labalette (2024-25) et son polycopié
d'annales — est la base : tout ce qu'il enseigne a sa carte. Le **ronéo
2026-27** le corrige et l'emporte en cas de désaccord. Ce que seul l'ancien
cours porte reste en carte, marqué « Absent du cours 2026-27 ». À l'examen, on
répond d'abord comme le professeur.

Le cours a changé d'enseignant (Pr Lefèvre au lieu du Pr Labalette) et de plan
(les organes avant le réseau lymphatique), pas de programme. Il ajoute des
exemples cliniques : l'adénopathie lue par son territoire, la splénectomie et la
vaccination, l'angine, la lymphangite, le lymphœdème, le chylothorax, le
lymphome.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 34 | 34 |
| Texte à trous | 13 | 73 |
| QROC | 10 | 10 |
| Recto-verso | 7 | 7 |
| Lexique | 9 | 9 |
| Schéma cliquable | 3 | 15 |
| **Total** | **76** | **148** |

Dont **14 annales** (12 QCM, 2 QROC en recto-verso) sur 9 sessions, de
2017/2018 à 2024/2025 S1. **34 QCM sur 34 illustrés** (100 %) : 21 figures du ronéo
2026-27 en correction. **5 cartes absentes du cours 2026-27** (tag
`absent-2026`). **13 cartes portent un piège du ronéo** (thème « Pièges des
ronéos »). Aucune carte `a-relire`.

Huit thèmes, dans l'ordre du cours :

| Clé | Libellé | Statut |
|---|---|---|
| `composantes-si` | Composantes du système immunitaire | **nouveau** |
| `organes-lymphoides` | Organes lymphoïdes | partagé avec `immuno_temporelle` (FC n°1), même libellé |
| `thymus` | Le thymus | **nouveau** |
| `ganglions` | Les ganglions lymphatiques | **nouveau** |
| `rate` | La rate | **nouveau** |
| `muqueuses` | Formations lymphoïdes des muqueuses | **nouveau** |
| `lymphe` | La lymphe et sa circulation | **nouveau** |
| `pathologie-lymphatique` | Pathologie lymphatique et adénopathies | **nouveau** |

La clé `systeme-immunitaire` n'est pas employée ici : FC n°1 lui donne le
libellé « Missions du système immunitaire et agresseurs », et un tag n'a qu'un
libellé. Les huit libellés sont à ajouter à `THEME_LABELS`
(`app/src/med_engine/application/scopes.py`) ; tant qu'ils n'y sont pas,
`test_tout_theme_du_paquet_a_son_libelle` échoue sur ce chapitre, et lui seul.

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-immuno-organes` — Ronéo & Juliette, « Organes et circulation des cellules » (14 p.) | **2026-27** | corrige la base et l'emporte ; chaque note relue porte sa page ; c'est ce que le lecteur ouvre |
| `src-cours-lym-2425` — Ronéosaure, FC n°2 (12 p.) | 2024-25 | **la base** ; source des 5 cartes absentes du cours 2026-27 |
| `src-roneo-lym-2324` — Charonéo 2023-24 (7 p.) | 2023-24 | appoint : CSH « totipotentes* », pic thymique, cryptes, lymphœdème unilatéral |
| `src-annales-lym` — Ronéosaure, « IMMUNO n°2 » (5 p.) | 2024-25 | 10 QCM et 2 QROC, corrections p. 4-5 ; source de la session 2023/2024, dont la Q5 (sujet et grille officiels, absents du polycopié) |
| `src-sujets-immuno-2425` — sujet de système immunitaire 2024/2025, session 1 (3 p.) | 2024-25 | dépôt du 15/10/2026 : la Q5 (`SRC["sessions"]["2024/2025 S1"]`) ; sujet sans corrigé, clé déduite du cours ; déclaré à l'identique dans chaque chapitre d'immunologie qui en a une question |
| sujet et grille officiels 2023/2024 (02/11/2023) | 2023-24 | dépôt du 15/10/2026 : la Q5 et sa clé ADE, et la clé de la Q.4 (ACD) ; cités, pas déclarés (la session garde son polycopié) |
| errata Immunologie 2024-25 (cours et annales) | 2024-25 | sept entrées sous ce cours dans l'errata des cours : six sur la FC, intégrées (veine subclavière DROITE, citerne de Pecquet, rabats anti-reflux, retour au système veineux, cellules « en transit », une coquille), et une sur les annales (2023/2024 Q4 « ne concerne pas ce cours ») ; l'errata des annales ne dit rien de ce polycopié |
| tableau des erreurs Immunologie 2026-27 | 2026-27 | vide au 28/09 ; au **19/10/2026**, une entrée sur ce cours : les CSH « totipotentes » → multipotentes (p. 3), déjà portée comme le cours lui-même |

Le ronéo 2026-27 « Organisation temporelle » (Pr Dubucquoi) est cité dans le
texte de deux cartes (95 % des LT éliminés, p. 10 ; mémoire et effecteurs,
p. 11-13), sans être déclaré : il appartiendra au chapitre FC n°1.

Les vérifications hors du cours sont citées dans la carte qui s'en sert :
StatPearls (mastocytes, amygdale palatine, végétations, ganglion, chylothorax,
DiGeorge), OpenStax et Guyton (entrée de la lymphe), Kenhub (chylifère), Seita
et Weissman 2010 (CSH), Sims et al. 2005 (LB transitionnels), Summers et al.
2010 (production de neutrophiles), Coccolini et al., WSES 2017 (traumatisme
splénique), Douglass et al. 2016 (lymphœdème secondaire), Perry 1994 (cryptes),
Randolph et al. 2005 (migration des cellules dendritiques), Murali-Krishna et
al. 1999, Tokoyoda et al. 2009, Di Rosa 2016, Farber et al. 2014 (LT mémoire), Br J Radiol
2012 (citerne du chyle).

## Ce que le cours a dicté

- **Le rouge du ronéo** : « palpables » (aires superficielles), « plein » de
  vaisseaux **A**fférents, un « seul » vaisseau **E**fférent (p. 5) — cartes
  `lym-qc-ganglion-aires`, `lym-fa-ganglion`, `lym-rv-ganglion-rate`, et le
  schéma du ganglion.
- **« A bien retenir cette différence »** (p. 3) : LB et NK sortent matures de
  la moelle, LT immatures — `lym-qc-moelle`, `lym-fa-moelle`,
  `lym-rv-maturation`.
- **Le gris** : la voix des rédacteurs (le ganglion qui gonfle, l'hypochondre
  gauche, la moelle aussi secondaire, le risque infectieux vers 75-80 ans, la
  question sur les cellules du thymus, le passage lent de la lymphe, la
  contention). Aucun passage n'est défini comme hors programme : tout se carte.
- **Laissé de côté** : le logo (p. 1), la photo d'un enfant (p. 6, visage
  identifiable), une image sans rapport avec le cours (p. 13) ; la p. 14 est
  vide.

## Ce que les annales ont dicté

Le thymus revient quatre fois (2020/2021 S1 Q1, 2020/2021 S2 Q3, 2019/2020 S2
Q6, 2017/2018 S1 Q4), le ganglion et son stroma cinq fois (2024/2025 S1 Q5,
2023/2024 Q5, 2021/2022 S1 Q1, 2020/2021 S2 Q1, 2019/2020 S2 Q7), la lymphe et
sa circulation trois fois (2019/2020 S1 Q2, 2017/2018 S1 Q3, QROC 2021/2022 S2).
Le piège le plus fréquent : **le stroma épithélial**, celui du thymus, prêté au
ganglion (quatre fois) — d'où `lym-fa-stroma`, carte absente du cours 2026-27
mais tenue par les annales. Viennent ensuite la médulla du ganglion
(« thymo-dépendante », « lymphe afférente déversée », « maturation des CD »,
« follicules secondaires ») et la prolifération thymique, corticale.

**Les annales du dépôt du 15/10/2026** :

- **2023/2024 Q.4** (`lym-an-2324-q4`) : clé ACD, **confirmée par la grille
  officielle (dépôt du 15/10/2026)**.
- **2023/2024 Q5** (`lym-an-2324-q5`, les ganglions) : aucune carte ne la
  portait, le polycopié ne l'imprime pas. Énoncé du sujet officiel, clé de la
  grille officielle (**ADE**), `officielle`, conforme au cours ; la session garde
  son libellé « 2023/2024 » et sa source (le polycopié), et l'explication dit
  que la question vient du sujet. Sa proposition A (les veinules post-capillaires)
  relève d'une notion absente du texte du ronéo 2026-27 (`lym-qr-veinules`) : la
  justification cite le cours 2024-25 et la FC n°8 2025-26 ; E cite la FC n°11
  2025-26 pour la lymphe afférente, le ronéo 2026-27 du CMH écrivant « par le
  sang » (une prise de notes déjà portée par `cmh-qc-cd-localisation`).
- **2024/2025 S1 Q5** (`lym-an-2425s1-q5`, les ganglions) : clé déduite du cours
  (**AE**). Les follicules, primaires et secondaires, et les cellules dendritiques
  folliculaires ne sont pas nommés par le ronéo 2026-27 de ce cours (seule sa
  figure p. 5 dit « follicules ») : la justification cite la FC n°6 2025-26
  (activation des LB, p. 5-7).

**Les quatorze clés sont reprises telles quelles** — les douze du polycopié, la
grille officielle de 2023/2024 Q5 — sauf celle de 2024/2025, déduite faute de
corrigé : toutes vérifiées contre le cours et la littérature, aucune n'est
fausse, `CONFLITS` est vide. Trois nuances, dites dans la justification sans
changer la clé :

| Question | Clé imprimée | Nuance |
|---|---|---|
| 2023/2024 Q.4 | ACD | question surtout d'un autre cours (« B/C/E pas de ce cours », imprimé ; errata 2024-25) ; A et D sont de ce cours |
| 2020/2021 S2 Q.3 D | vrai | la sélection négative porte sur des thymocytes, pas sur des « LT naïfs » : formulation approximative |
| 2017/2018 S1 Q.4 E | vrai | le thymus du DiGeorge est le plus souvent hypoplasique, absent dans la forme complète |

Les deux QROC ont une correction dans la table : recto-verso, `officielle=True`,
correction à peine remise en forme.

## Les clés qui ne sont pas reprises telles quelles

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2024/2025 S1 Q5 (`lym-an-2425s1-q5`) | aucune (sujet sans corrigé) | **AE**, déduite du cours, non officielle | follicules primaires et secondaires dans le cortex superficiel (figure p. 5 ; FC n°6 2025-26, p. 5-6), pas dans la médulla ; LT naïfs dans le cortex profond, pas dans les follicules (p. 6) ; la CD mature dans le cortex profond, la CD folliculaire dans le centre germinatif (FC n°6 2025-26, p. 5-7) ; sur le trajet de la lymphe et vascularisés (p. 3, 6) |

Cas ouvert : aucun.

## Les schémas cliquables

| Fichier | Ce qu'on clique | Carte |
|---|---|---|
| `ganglion-nu.svg` | afférents, cortex superficiel, cortex profond (« la zone thymo-dépendante »), médulla, hile, efférent | `lym-zo-ganglion` (6) |
| `drainage-nu.svg` | les territoires du conduit lymphatique droit et du canal thoracique | `lym-zo-drainage` (2) |
| `organes-nu.svg` | amygdales, thymus, ganglions axillaires, rate, plaques de Peyer, ganglions inguinaux, moelle (fémur) | `lym-zo-organes` (7) |

Le ganglion suit la figure du ronéo (p. 5), convexité à gauche, hile à droite ;
la médulla rejoint le hile par ses cordons, comme sur la figure. Le corps est vu
de face : la droite du sujet est à gauche de l'image, et un repère sous les
pieds le rappelle — c'est le piège du drainage. Les organes pairs (ganglions,
fémur) ne sont pleins que d'un côté. Aucune légende n'est imprimée ; les figures
du ronéo sont en correction. Les libellés des organes sont des fonctions
(« l'organe lymphoïde secondaire qui filtre le sang, sans lymphatique
afférent ») : on clique la rate en se rappelant pourquoi.

## Les erreurs du ronéo 2026-27

Le ronéo n'est pas corrigé ; chaque erreur est portée par la carte qui tient la
notion, avec un `ATTENTION` qui dit son genre, et la carte retient la bonne
lecture. Toutes sont trouvées en relisant ; le tableau de la promo, vide au 28/09,
relève au 19/10 la seule CSH « totipotente ». Leur tri, vérifié le 28/09, est celui
de `contenu/ERRATA_RONEOS_2026-27.md`.

**Prises de notes** — la carte suit la référence :

| Page | Le ronéo dit | Ce qui est juste | Carte |
|---|---|---|---|
| 2 | les mastocytes parmi les cellules circulantes, « par le sang et la lymphe » | les mastocytes matures sont résidents ; seuls leurs progéniteurs circulent (StatPearls) | `lym-qc-composantes` (C) |
| 3 | « plaques de Payer » | plaques de Peyer (J. C. Peyer, 1677), comme le ronéo l'écrit p. 9 | `lym-qc-peyer` |
| 8 | les cryptes, amygdales « tellement remaniée à cause des angines à répétitions » | structure normale de l'épithélium ; le pathologique est l'amygdalite cryptique (cours 2024-25 p. 11, Charonéo p. 6, Perry 1994) | `lym-qc-cryptes` (E) |
| 8 | l'amygdale pharyngée « derrière le rhino-pharynx » | dans le rhinopharynx, toit et paroi postérieure (StatPearls, Adenoids) | `lym-qc-amygdales` (B) |
| 9 | « c'est la pression oncotique qui favorise l'entrée du liquide » | la pression hydrostatique du liquide interstitiel (cours 2024-25 p. 3, OpenStax, Guyton) | `lym-qc-lymphe` (C) |
| 12 | des lymphatiques « dans la sous-muqueuse et l'épithélium » | le chylifère est dans l'axe de chorion de la villosité (figure p. 12, cours 2024-25 p. 12, Kenhub) | `lym-qc-chyle` (B) |
| 13 | chyle « dans la plèvre/intestin : c'est un chylothorax » | la seule cavité pleurale (figure p. 13, StatPearls) | `lym-qc-lymphangite-chylothorax` (D) |

**C'est le cours lui-même** — la carte répond comme le professeur, puis « À
l'examen : », puis « La référence : » :

| Page | Ce qui est écrit | D'où vient la formule | À l'examen | La référence | Carte |
|---|---|---|---|---|---|
| 3 | CSH, « cellules totipotentes de l'hématopoïèse » — **tableau de la promo, 19/10** : « multipotentes » | le mot des enseignants : Charonéo 2023-24 p. 4, le Pr Lefèvre en immunosénescence (Ronéosaure S2, FC n°3 p. 3), le Pr Dubucquoi en ontogenèse B | ne pas l'écrire de soi-même, ne pas compter fausse une proposition d'immunologie qui l'emploie | multipotentes (cours de tissu sanguin 2026-27 ; Seita et Weissman 2010) | `lym-qc-moelle` (A) |

**Les points douteux**, dits dans la carte sans changer sa clé :

| Page | Le point | Carte |
|---|---|---|
| 3 | « 5 milliards de leucocytes par jour » (la littérature : 5-10 × 10^10 neutrophiles) ; chiffre gardé | `lym-fa-moelle` |
| 3 | LB et NK « sortent de la moelle matures » (le LB sort transitionnel) ; le cours retenu | `lym-qc-moelle` (E), `lym-fa-moelle` |
| 6 | la médulla, « cellules présentatrices d'antigènes » | `lym-qc-ganglion-structure` (E) |
| 6 | la cellule naïve devient « cellule mémoire (avec des fonctions CD4 ou CD8) » | `lym-qc-ganglion-fonctions` (D) |
| 7 | « si la rate saigne, on ne peut pas suturer, on doit ainsi l'enlever » | `lym-qc-splenectomie` (explication) |
| 12 | « Lymphoedème : la cause est une très grosse phlébite » | `lym-qc-lymphoedeme` (A) |

**Les erreurs du Ronéosaure 2024-25**, avec un `ATTENTION` sans genre : la rate
« antérieure à l'estomac » (p. 10 ; elle est en arrière, `lym-qc-rate`) et le
« LDL cholestérol » des chylomicrons (p. 12, `lym-qc-chyle`).

## Absent du cours 2026-27

Cinq cartes entières viennent du seul cours 2024-25 (et du Charonéo 2023-24) ;
elles le disent en tête de leur explication et portent `absent-2026`.

| Carte | Notion | Source |
|---|---|---|
| `lym-fa-stroma` | le stroma conjonctif réticulaire des OL secondaires | cours 2024-25 p. 7 ; trois annales |
| `lym-qr-lymphocytes-sang` | 500 milliards de lymphocytes, 2 % dans le sang | cours 2024-25 p. 6 |
| `lym-qr-moelle-memoire` | la moelle, lieu de domiciliation des lymphocytes mémoire | cours 2024-25 p. 5 ; annale 2023/2024 Q4 D |
| `lym-qr-digeorge` | le syndrome de DiGeorge | cours 2024-25 p. 6 ; annale 2017/2018 S1 Q4 E |
| `lym-qr-veinules` | les veinules post-capillaires, 90 % / 10 % | cours 2024-25 p. 9 |

Absents aussi, mais dits dans une carte qui a sa version 2026-27 : le MALT
diffus des tractus respiratoire et uro-génital (`lym-fa-ol-secondaires`, et la
correction du QROC 2020/2021 S2), la citerne de Pecquet (sur la figure p. 11
seulement). Les 95 % de LT éliminés ne sont plus dans ce cours-ci, mais dans le
ronéo 2026-27 « Organisation temporelle » (p. 10) : `lym-qr-95` n'est donc pas
marquée absente.

## Le lexique

Neuf termes, accueillis ici : lymphe, chyle, chylothorax, lymphangite,
lymphœdème, splénectomie, amygdale, thymopoïèse, ganglion lymphatique. Les
pages sont mesurées dans le texte du ronéo 2026-27, mot entier, pluriel permis,
accents et casse ignorés (même règle que `scripts/chercher_pages.py`, lue avec
PyMuPDF faute de pypdf dans l'environnement). Deux écarts, voulus : la page 1,
le plan du cours, n'est jamais comptée (lymphe, amygdale et ganglion lymphatique
y figurent) ; **splénectomie** garde la p. 7, où le ronéo écrit
« splénectomisé ». **Adénopathie** est laissée à
`semio_gyneco`, qui l'accueille déjà (`lex-adenopathie`) : même identifiant,
un seul terme.

L'origine grecque ou latine de chaque terme et de chaque racine est proposée
pour la table, vérifiée sur le Wiktionnaire (qui cite le TLFi et le Gaffiot),
le Bailly et le LSJ : neuf racines nouvelles
(`lymph(o)-`, `angi(o)-`, `-œdème`, `-ectomie`, `-thorax`, `amygdal-`,
`thym(o)-`, `-poïèse`, `gangli-`) et neuf termes. Elle entre dans
`scripts/etymologies.json` à la fusion, puis `appliquer_etymologies.py`
l'écrit ; `chyl(o)-`, `splén(o)-` et `-ite` y sont déjà.

## Les figures

21 figures du ronéo 2026-27, extraites en PNG (900 px de large au plus,
réduites à 256 couleurs : 2,4 Mo en tout), chacune avec sa page, toutes en
correction. Elles font foi et partent avec le chapitre ; la figure légendée du
ganglion (p. 5) illustre aussi le schéma cliquable. Les deux figures de la p. 10
se distinguent par leur place : `capillaire-lymphatique.png` est le capillaire
borgne et ses rabats (sous « B. Les capillaires lymphatiques »),
`circulation-lymphatique.png` la diapositive « Circulation dans le réseau
lymphatique » (sous « C. »). `angine.png` (p. 8) est déclarée mais n'illustre
aucune carte : chaque carte n'a qu'une illustration, et les amygdales ont déjà
les leurs.

## À relire

Aucune carte `a-relire` : chaque carte cite sa page du ronéo 2026-27 ou du cours
2024-25. Restent ouverts, et dits dans la carte : les 10 000 lymphocytes par
seconde (p. 10, sans source retrouvée, gardés tels que le cours les donne) ; les
amygdales linguales « tout au bout » (p. 8), lues comme la base de la langue,
selon la figure de la même page.

## L'échelle : Simple → Moyen → Annale (C20, 16/10/2026)

Le pilote de l'immunité innée, étendu au reste de l'immunologie pour l'examen du 4/11 (choix de Vincent, 15/10). Sous les annales, 26 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 5 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`) ; les QROC reçoivent le schéma nu.

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `composantes-si` | 1 | 0 | 1 |
| `organes-lymphoides` | 1 | 1 | 1 |
| `thymus` | 8 | 1 | 4 |
| `ganglions` | 8 | 2 | 5 |
| `lymphe` | 8 | 1 | 3 |

**Le schéma** `ech-organes`, « Les organes lymphoïdes · produire, rencontrer, drainer », donne 44 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_ORGANES`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu les dix chapitres ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Un piège de mots entre deux annales** : « il est fonctionnel dès la naissance » (2019/2020 S2 Q6 C, vraie) et « devient fonctionnel dès la naissance » (thymus, 2022/2023 S1 Q.3 A, fausse). Les clés s'accordent avec le cours ; lym-ech-m3 D le dit par un ATTENTION.

**Sans marche** :
- lym-an-2324-q4 B, C, E : « B/C/E pas de ce cours », imprimé par le polycopié ; C et E ne tiennent que par la littérature (IL-7, IL-15), B par le ronéo « Organisation temporelle » (p. 10), que ce chapitre ne déclare pas. Pas de lettre posée pour elles.
- lym-an-2021s2-q3 E et lym-an-1920s2-q6 E : les LT régulateurs naturels et induits, absents des cours du chapitre (les deux justifications renvoient l'une à l'autre).
- lym-an-1920s2-q6 B : la vascularisation lymphatique du thymus, qu'aucun cours du chapitre ne décrit.

## Régénérer

```powershell
cd contenu\chapitres\immuno_organes
..\..\..\app\.venv\Scripts\python.exe generer.py
```
