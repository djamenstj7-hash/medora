# Les groupes sanguins — paquet d'exemple

38 notes, 58 cartes. Neuvième chapitre de l'UE **Tissu sanguin**, Pr Mendel,
semaine 7. Premier des trois cours de transfusion, et celui qui pose le
vocabulaire des deux suivants.

## Une seule règle porte le système ABO

**On a toujours l'anticorps de l'antigène qu'on n'a pas.** Tout s'en déduit :

| Groupe | Antigènes | Anticorps | Reçoit |
|---|---|---|---|
| A | A | anti-B | A, O |
| B | B | anti-A | B, O |
| **AB** | A et B | **aucun** | **les quatre** — receveur universel |
| **O** | **aucun** | anti-A et anti-B | O seulement — **donneur universel** |

Le ronéo signale ce schéma en toutes lettres — « schéma pouvant tomber à
l'examen » — et c'est lui qui est redessiné nu dans `schemas.py` : dix boîtes,
aucun mot dessus.

## Naturels ou immuns : la distinction qui revient partout

- **ABO** : anticorps **naturels et réguliers**, apparus spontanément après la
  naissance au contact de l'environnement. Présents dès la première transfusion —
  d'où l'hémolyse immédiate.
- **Tous les autres systèmes** — Rhésus, Kell, Duffy, Kidd, MNS : anticorps
  **immuns**, acquis par transfusion, grossesse ou greffe.

Il n'existe donc **pas d'anticorps anti-D naturel**, et le fascicule pose cet
item trois fois. Seule exception partielle : les anti-M et anti-N, naturels mais
irréguliers, trouvés en RAI chez l'enfant l'hiver.

## Deux natures, deux distributions

| | ABO | Rhésus |
|---|---|---|
| Nature | déterminants **sucrés** | déterminants **protéiques** |
| Distribution | **tissulaires** (GR, leucocytes, plaquettes, rein) | **strictement érythrocytaires** |

C'est ce qui fait que l'ABO compte en greffe d'organe et le Rhésus non.

## Ce qu'est un groupe sanguin

**ABO + Rhésus + KEL1** — le cours insiste : « pas juste ABO ! ». Le phénotypage
**étendu** ajoute six antigènes (FY1, FY2, JK1, JK2, MNS3, MNS4) et n'est **pas**
systématique : polytransfusés, greffés d'organes, drépanocytaires.

Deux déterminations indépendantes, à deux moments différents — la même personne
peut les faire, mais pas simultanément. Le groupe ne change jamais, sauf greffe
de moelle. Celui du nouveau-né est valide six mois et ne vaut pas pour
transfuser.

## Clés d'annales non reprises telles quelles

La clé retenue est la bonne, pas la clé imprimée (règle de Vincent, 26/09) :
la question porte alors `cle_officielle` à faux, et la justification de l'item
dit que la correction imprimée n'est pas bonne, et pourquoi.

| Question | Clé imprimée | Retenu | Pourquoi | Source |
|---|---|---|---|---|
| 2019/2020, QCM 8 D (`grp-an-1920-q8`) — « les anticorps anti-JK1, dès lors qu'ils sont détectés, seront présents indéfiniment dans le sérum d'un individu » | D (vrai) | **faux** — aucune proposition exacte | l'anti-JK1 peut disparaître du sérum en gardant la mémoire immunologique : c'est l'évanescence des anticorps Kidd, qui les rend « perfides et dangereux » ; les quatre autres items sont faux aussi | cours p. 9 ; errata des annales (« pas de réponse vraie à cette question ») ; StatPearls, « Kidd Blood Group System », NCBI Bookshelf ; EFS, « Les groupes sanguins », pour l'item A |

**Une question sans bonne réponse devient un recto-verso** (26/09/2026). La
bonne réponse est « aucune », et une question à choix exige au moins une
proposition vraie. La carte est donc un recto-verso : l'énoncé et les cinq
propositions tels qu'imprimés au recto, « aucune n'est exacte » et la raison
de chaque item au verso, clé non officielle. La note garde son identifiant, et
sa carte ses révisions (tenu par `tests/test_reimport.py`). Elle ne figure plus
dans `CONFLITS`, qui vise une proposition précise.

Le même errata confirme un autre point, validé celui-là : le **contrôle ultime
de concordance** se fait avant la transfusion de **tout** produit sanguin,
plaquettes comprises et même en urgence. Seul le contrôle de *compatibilité* —
la carte au lit du malade — est réservé aux globules rouges.

## Les sujets du dépôt du 15/10/2026

Trois annales de plus : le chapitre en compte 10, sur 6 sessions. Le polycopié
de ce cours s'arrête à 2021/2022 ; chaque session nouvelle cite donc son sujet
(`SRC["sessions"]`) : `src-sujets-sang-2324` et `src-sujets-sang-2425`.

- **2023/2024, QROC 4** (`grp-an-qr-abo`) : « Décrire le système de groupe
  sanguin ABO », recto-verso selon le corrigé officiel — les antigènes A et B,
  présents ou absents sur les globules rouges et de nombreuses cellules, et les
  anticorps naturels et réguliers quand l'antigène manque (p. 3-4).
- **2024/2025, QCM 8** (`grp-an-2425-q8`) : reprise remaniée de 2021/2022 QCM 1
  (`grp-an-2122-q1`), devenue question à réponses multiples — A et B à
  l'identique, C passé du O négatif à l'AB, D et E retournés. Illustrée par le
  schéma des règles transfusionnelles (p. 6).
- **2024/2025, QROC 1** (`grp-an-qr-determination`) : le principe de la
  détermination d'un groupe, recto-verso construit sur le cours (p. 3-5,
  10-11).

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2024/2025, QCM 8 (`grp-an-2425-q8`) | aucune (sujet sans corrigé) ; surlignée : DE | **DE** | phénotype étendu « pas systématique » (p. 11) ; groupe du nouveau-né « valide durant les 6 mois suivant la naissance » (p. 5) |
| 2024/2025, QROC 1 (`grp-an-qr-determination`) | aucune | réponse du cours | Beth Vincent et Simonin, concordance (p. 4-5) ; ABO-RH-KEL1, deux déterminations (p. 10-11) |

**La correction surlignée (officieuse).** Les sujets du dépôt portent des
réponses surlignées en bleu, posées en annotation sur le PDF après coup et
d'origine inconnue : ce n'est ni une grille ni un corrigé de la faculté, et elle
n'est pas déclarée comme source. Sur 2023/2024, elle reproduit la
grille officielle, sauf au QCM 9, où elle ajoute D. Sur 2024/2025, elle sert de
seconde opinion : quand la clé déduite du cours coïncide, l'explication le dit ;
quand elle diffère et que le cours tranche, la carte suit le cours, et l'item
en cause porte un `ATTENTION —` et une entrée `CONFLITS`. Les surlignages des
QROC 2024/2025 ne marquent que l'énoncé et n'apportent rien.

## L'échelle : Simple → Moyen → Annale (C20, 16/10/2026)

L'échelle du pilote de l'immunité innée, étendue au tissu sanguin et aux trois derniers chapitres de sémiologie pour l'examen du 4/11 (Vincent, 16/10 : « on continue pour les chapitres que je vais avoir à l'examen »). Sous les annales, 22 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 6 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`) ; les QROC reçoivent le schéma nu.

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `abo` | 13 | 3 | 6 |
| `rhesus` | 4 | 1 | 2 |
| `autres` | 2 | 1 | 1 |
| `regles` | 3 | 1 | 1 |

**Le schéma** `ech-groupes`, « Les groupes sanguins · antigènes, anticorps, règles », donne 36 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_GROUPES`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**La source.** Les marches citent le cours 2024-25 du chapitre, sur lequel ses cartes et les justifications de ses annales sont bâties (décision de Vincent, 16/10 : pas de ronéo 2026-27 parue). La FC 2025-26 du Ronéosaure a servi de contre-épreuve : un fait qui change d'une année à l'autre porte un `ATTENTION`, ou n'a pas de marche.

**Le générateur.** Depuis le 16/10, `generer.py` est la copie exacte du modèle du skill : le bloc « le générateur modèle » en fin de `donnees.py` déclare les sources dans `SRC` et range les QROC d'annales dans `ANNALES_QROC`, officielles comme avant. Le paquet est resté le même, à trois écarts voulus près (indentation, champs par défaut des cartes à zones, légende du média du schéma cliquable).

**ATTENTION posé** : la clé imprimée de 2019/2020 QCM 8 tient vrai un anti-JK1 présent indéfiniment, et la carte de l'annale retient faux (s18, m6). La case de la RAI dit « avant de transfuser des GR », comme le chapitre de la transfusion.

**Sans marche** :
- grp-an-1920-q7 E — le contrôle ultime pré-transfusionnel n'est pas dans le cours des groupes sanguins : il relève du cours de transfusion (sang_transfusion), dont les marches trf-ech-s7, s8 et m2 le préparent ; aucune lettre posée.
- grp-an-1920-q8 A (recto-verso) — la fréquence du groupe A chez les caucasiens n'est pas dans le cours 2024-25 qui fait foi ; seule la FC 2025-26 la donne (p. 4 : le groupe A est le plus fréquent, puis le O, « règle des 4 »), qui n'est pas une source déclarée du chapitre.

## Régénérer

```
python generer.py
```
