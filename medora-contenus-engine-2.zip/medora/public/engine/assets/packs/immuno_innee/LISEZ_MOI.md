# Immunité innée et réponse inflammatoire — paquet Immunologie

154 notes, 216 cartes. Chapitre `chap-ue-immunologie-fc7` de l'UE Immunologie.
**Cours du Pr Lefèvre, le 12/10/2026, de 11 h à 12 h**, « Immunité innée et
réponse inflammatoire » (ronéo Ronéo & Juliette 2026-27, 14 pages, déposé le
19/10/2026). Réaligné sur lui le 19/10/2026 ; il était carté depuis le 02/10
(tâche C14) sur la FC n°7 du Ronéosaure 2025-26, du même professeur, qui n'est
plus qu'un appoint. Annales du polycopié IMMUNO n°7 du Ronéosaure 2024-25
(32 questions, 16 sessions). Examen : partiel de novembre (mercredi 4/11/2026).
C'est le pilote de l'échelle (C20).

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 60 | 60 |
| QRU | 41 | 41 |
| Texte à trous | 14 | 68 |
| QROC | 9 | 9 |
| Recto-verso | 14 | 14 |
| Schéma cliquable | 1 | 9 |
| Planche à légender | 1 | 1 |
| Lexique | 14 | 14 |

Dont **32 annales** : 25 QCM et 7 QROC (recto-verso), sur 16 sessions, de
2015/2016 S1 à 2023/2024 S1. **25 QCM de cours**, une justification par
proposition, et **51 marches de l'échelle** (40 Simple, 11 Moyen). **101 QCM
sur 101 illustrés**, 139 notes sur 154. **7 cartes absentes du cours 2026-27**
(tag `absent-2026`), **11 cartes portent un piège du ronéo** (thème « Pièges
des ronéos »). Aucune carte `a-relire`.

Sept thèmes, dans l'ordre du cours, déjà dans `THEME_LABELS`
(`app/src/med_engine/application/scopes.py`) ; le réalignement n'en ajoute aucun :

| Clé | Libellé |
|---|---|
| `inne-adaptatif` | Immunité innée et immunité adaptative (celui d'`immuno_temporelle`) |
| `barrieres` | Barrières cutanées et muqueuses |
| `inflammation` | La réaction inflammatoire |
| `complement-voies` | Les voies d'activation du complément |
| `complement-effets` | Fonctions du complément et complexe d'attaque |
| `phagocytose` | Phagocytes et opsono-phagocytose |
| `cellules-nk` | Les cellules NK |

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-immuno-innee-2627` — « Immunité innée et réponse inflammatoire » (14 p.), `IMMUNOLOGIE/IMMUNITE INNEE ET RÉPONSE INFLAMMATOIRE.pdf` | **2026-27** | **la base** : `SRC["fiche"]`, ce que le lecteur ouvre (`chapitre=`) ; les cartes citent « p. N » ; 18 de ses diapositives illustrent les corrections |
| `src-fc-immuno-innee` — Ronéosaure, « FC n°7 Immunitée innée et réponse inflammatoire » (10 p.) | 2025-26 | **appoint** (`SRC["cours"]`, sans `chapitre=`) : la source de la carte absente `inn-qr-meningocoque` et de huit diapositives plus nettes que leurs reprises de 2026-27 ; citée « FC 2025-26, p. N » |
| `src-cours-immuno-innee-2425` — Ronéosaure, FC n°7 (AC), Pr Dubucquoi (13 p.) | 2024-25 | appoint : la voie alterne (protection de nos cellules, properdine, p. 5-8), les défensines (p. 10-11), les NK (p. 11-13) ; la source de six marches absentes |
| `src-annales-immuno-innee` — Ronéosaure, « IMMUNO n°7 - Immunité innée et réponses inflammatoires » (12 p.) | 2024-25 | les 32 questions et leur table de corrections (p. 10-12) ; déclaration partagée avec `immuno_infectieux`, à l'identique |
| FC n°11 2025-26 (Réponse aux agents infectieux) | 2025-26 | citée dans le texte, à la page, sans être déclarée : la fiche d'un autre chapitre |
| tableau d'erreurs Immunologie de la promo 2026-27 | 2026-27 | rien sur ce cours au 19/10/2026 |

La fiche de l'année se copie dans le dossier des PDF de l'application par
`outils/copier_les_cours.py`, lancé avec le dossier des ronéos du 19/10/2026
(`Ajouts/[NUMERIQUE] Ronéo & Juliette 26-27 19 10 2026/S1/CM`), hors du bac à
sable. L'en-tête du ronéo nomme ses rédacteurs et ses correcteurs : aucun nom
n'est repris.

Vérifications hors du cours, citées dans la carte qui s'en sert : Janeway et
Abbas (C3bBb, C3bBb3b, IgG3 > IgG1 > IgG2, CR1 à CR4, C1 inhibiteur, C1q sans
anticorps) ; Sepsis-3 (Singer et al., JAMA 2016) ; Ferlazzo et al., PNAS 2004
(l'IL-12 des cellules dendritiques et le NK) ; Mogensen, Clin Microbiol Rev 2009
(les PAMP) ; Klebanoff, J Leukoc Biol 2005, et IUBMB EC 1.11.2.2 (la
myéloperoxydase) ; Zlotnik et Yoshie, Immunity 2000, et Klos et al., Mol Immunol
2009 (les chimiokines et les anaphylatoxines) ; l'étymologie (TLFi, Bailly, Gaffiot, Wiktionnaire).

## Ce qui correspond à quoi

| FC n°7 2025-26 | Ronéo 2026-27 |
|---|---|
| I.A Système immunitaire, innée et adaptative (p. 1-2) | p. 2-3 |
| I.B Revêtements cutanés et muqueux (p. 2-3) | p. 3-4 |
| I.C Réponse inflammatoire, phases, médiateurs tardifs, chocs, cytokines (p. 3-4) | p. 4-7 |
| Cellules NK, cinétique (p. 5) | p. 7 |
| II.A-B Complément, généralités, trois voies (p. 5-6) | p. 7-8 |
| II.C Voie classique, C3a, C3b (p. 6-7) | p. 8-9 |
| II.D Voie finale commune, résumé (p. 7) | p. 9-10 |
| III. Phagocytes (p. 8) | p. 10-11 |
| III. Opsono-phagocytose, destruction, NETs (p. 9) | p. 11-13 |
| IV. NK (p. 10) | p. 13-14 |
| — | **nouveau** : le rôle du système immunitaire (p. 2), les quatre barrières et leurs défaillances (p. 3-4), la phase cellulaire (p. 5), les médiateurs tardifs en détail, le sepsis et le choc septique (p. 6), la conclusion du complément et l'activation dès la naissance (p. 10), les fonctions du PNN et du macrophage, l'IFN-γ « chef d'orchestre » (p. 10-11), le phénotype et l'origine des NK (p. 13), leurs cytokines (p. 14) |

## Le réalignement du 19/10/2026

Les 137 notes de la version 2025-26 ont été relues une à une contre le ronéo
2026-27. **122 notes de cours** désormais : 101 citent une page de l'année (et
perdent le badge « Cours 2025-26 »), 7 sont absentes, 14 sont des termes de
lexique. Chaque proposition ou chaque trou que seul un cours d'une autre année
porte le dit dans sa justification (« FC 2025-26, p. 9 », « cours 2024-25,
p. 7 ») : une carte n'est confirmée que si sa notion centrale est dans le cours
de l'année.

**Ce que le ronéo 2026-27 dit autrement, et ce qui a été réécrit** :

- **Le C4bC2a est enseigné** (« C4bC2a = C3 convertase classique », diapositive
  p. 8 ; « l'assemblage de ces fragments (notamment C4b et C2a) », p. 8) : la FC
  2025-26 le disait « pas à retenir ». **Les cytokines du NK sont dans le texte**
  (IFN-γ et TNF, p. 14) ; la FC 2025-26 les disait « à ne pas retenir ». **Le
  phénotype CD3−, CD56+ et l'origine lymphoïde des NK** sont sur la diapositive
  p. 13 ; le cours 2024-25 les disait « pas à retenir ». Le tag `edn` quitte donc
  cinq cartes : `inn-fa-voie-classique`, `inn-ech-cpl-s6`, `inn-ech-cpl-s7`
  (C3bBb, sur deux diapositives p. 9), `inn-ech-nk-s12`, `inn-ech-nk-s13`
  (qui cite désormais le ronéo, p. 13, et non plus le cours 2024-25).
- **La part des NK** : « 5 à 15 % » (diapositive « Introduction », p. 13) et
  « 2 à 18 % » (diapositive p. 7), au lieu d'« environ 10 % » : `inn-fa-nk` (trou
  c1), `inn-qr-nk-proportion`, `inn-qc-nk-effecteurs` A, `inn-ech-nk-s1`.
- **Les monocytes migrent en « quelques heures »** (diapositive p. 11), au lieu
  de « 20 à 24 h » : `inn-fa-phagocytes` (le trou c3 demande désormais les
  monocytes), `inn-qc-macrophages`, `inn-rv-pnn-macrophage`, `inn-qc-pnn` C.
- **La peau saine arrête 99,9 %** des bactéries et des champignons (p. 3), au
  lieu de 99 % : `inn-fa-barrieres`, `inn-qc-barrieres` B (douteux, plus bas).
- **Les IgA n'activent pas la voie classique** (p. 8), « principalement les IgG
  et les IgM » : `inn-qc-voie-classique` A et E ; les sous-classes IgG1, IgG2,
  IgG3 restent dites « FC 2025-26 ».
- **Cinq signes locaux**, avec la rougeur et l'impotence fonctionnelle (p. 4) :
  `inn-fa-inflammation`. **La coupure** remplace l'écharde, la définition perd
  « bénéfiques et normaux » : `inn-qc-inflammation` A et D.
- **Les médiateurs tardifs** d'après la diapositive p. 6 (prostaglandines,
  leucotriènes, PAF ; l'IL-1 à la fièvre, l'IL-6 au foie) :
  `inn-fa-mediateurs-tardifs` (trou c2 : leucotriènes au lieu du mastocyte),
  `inn-qc-mediateurs` C et D.
- **Le choc septique** : hypotension qui ne répond pas au remplissage, amines
  vasopressives et corticoïdes (p. 6) : `inn-qc-mediateurs` E, `inn-rv-chocs`
  (le choc anaphylactique y reste, dit « FC 2025-26, p. 4 »).
- **Les étapes de la phagocytose** : le ronéo ne les numérote plus et ne nomme
  plus le phagolysosome ; `inn-qc-ordre-phagocytose` demande l'étape qui suit
  l'internalisation (la fusion), `inn-fa-phagocytose` et `inn-qc-phagocytose` A
  disent la fusion avec les vésicules (p. 12).
- **La lyse par le CAM** touche aussi les cellules tumorales et infectées
  (p. 9) : `inn-qc-cam` E et `inn-fa-cam` (trou c5 : osmotique au lieu des
  méningocoques, que le ronéo ne cite plus).
- **Les trois rôles du complément** viennent de la conclusion (p. 10) :
  `inn-fa-trois-fonctions`. **La spécificité de l'innée** est « + (générique) »
  (diapositive p. 3) : `inn-ech-pha-s7` (proposition C), la case `inne-spe` du
  schéma `ech-phagocytose`, `inn-ech-pha-m3` A.
- `inn-qc-inne-adaptatif` D (« phagocyte » est une fonction), une formule de la
  FC 2025-26 seule, devient « la réponse innée progresse » (p. 3) ;
  `inn-qc-pnn` B et D quittent la neutrophilie et les exemples de bactéries
  intracellulaires pour les diapositives p. 10-11.
- **Les erreurs du Ronéosaure 2025-26** ne sont plus dans le cours de l'année :
  le ronéo 2026-27 dit juste la perforine et les granzymes du NK (p. 14) et
  l'action endocrine (p. 6). Leurs ATTENTION ont quitté `inn-qc-nk-effecteurs`,
  `inn-qc-cytokines`, `inn-ech-pha-m1`, `inn-ech-nk-s6`, `inn-ech-nk-s7` et
  `inn-an-1516s1-qroc4`, qui le disent en une phrase.

**Notes nouvelles (11)**, sur ce que le cours 2026-27 apporte :

| Note | Ce qu'elle carte |
|---|---|
| `inn-qc-role-si` | rejeter, tolérer le soi et l'environnement, répondre à toute agression (p. 2) |
| `inn-qc-barrieres-types` | les quatre barrières de la diapositive (p. 3) |
| `inn-qc-portes-entree` | cathéter et septicémie nosocomiale, intertrigo, œdèmes, antibiotiques, cellules épithéliales immunitaires (p. 4) |
| `inn-fa-phase-cellulaire` | au-delà de 4 h, diapédèse des PNN puis des monocytes (p. 5) |
| `inn-qc-sepsis` | sepsis, cortisol, remplissage, choc septique (p. 6) |
| `inn-qc-declencheurs` | la conclusion du complément : Fc des Ig, carbohydrates, BGN, BGP (p. 10) |
| `inn-rv-complement-naissance` | la voie classique dès la naissance : nos IgM, les IgG maternelles (p. 10, question d'une élève en gris) |
| `inn-qc-pnn-fonctions` | noyau polylobé, bactéries extracellulaires et champignons, NETose, phagocytose moindre (p. 10-11) |
| `inn-qc-macrophages` | migration en quelques heures, microbicidie << PNN, IFN-γ chef d'orchestre (p. 11) |
| `inn-fa-nk-arrivee` | précurseurs lymphoïdes, infections virales, interférons de type 1, CD3−, CD56+ (p. 13) |
| `inn-qc-nk-cytokines` | l'IFN-γ et le TNF du NK, l'IL-12 qu'il reçoit (p. 14) |

**Le gris du ronéo** (« on ne détaille pas le mécanisme des autres voies »,
p. 9 ; la question d'une élève, p. 10) : le ronéo ne définit pas son gris, il se
carte comme le reste.

## Absent du cours 2026-27

Sept cartes entières (tag `absent-2026`, « Absent du cours 2026-27 » en tête de
l'explication) ; elles citent la FC 2025-26 ou le cours 2024-25, jamais la fiche
de l'année :

| Carte | Ce qu'elle carte | Source |
|---|---|---|
| `inn-qr-meningocoque` | le déficit en C6 ou C7 et les méningocoques | FC 2025-26, p. 7 |
| `inn-ech-cpl-s2` | nos cellules se protègent de la voie alterne | cours 2024-25, p. 6 |
| `inn-ech-cpl-s4` | les IgM plus efficaces que les IgG | cours 2024-25, p. 7 |
| `inn-ech-cpl-s8` | la properdine | cours 2024-25, p. 7 |
| `inn-ech-cpl-s18` | le complément contre les microbes extracellulaires | cours 2024-25, p. 11 |
| `inn-ech-pha-s4` | les défensines, qui percent les membranes | cours 2024-25, p. 11 |
| `inn-ech-nk-s6` | le NK tue comme le LT CD8 | cours 2024-25, p. 11 ; FC n°11 2025-26, p. 9 |

Les six marches restent sur l'échelle : les annales demandent ces notions à
chaque session. Ce que le ronéo 2026-27 ne reprend pas dans une carte qu'il
confirme par ailleurs est dit dans la justification : le choc anaphylactique
(`inn-rv-chocs`), le phagolysosome nommé, la neutrophilie, le développement du
sigle NETs (`inn-qr-nets`, ligne rouge de la FC 2025-26).

## Les erreurs du ronéo 2026-27

Chacune est portée là où la notion se joue, avec son genre ; elles seront
inscrites dans `contenu/ERRATA_RONEOS_2026-27.md`.

**Prise de notes** (la diapositive dit juste) :

| Page | Ce que dit le ronéo | Ce qui est juste | Carte |
|---|---|---|---|
| 3 | « Barrière chimique : les cils respiratoires et le mucus » | les cils sont une barrière mécanique ; la chimique : acidité, sébum, mucus, surfactant (diapositive p. 3) | `inn-qc-barrieres-types` B |
| 8 | complexe immun : « immunoglobuline fixée sur son anticorps » | un anticorps fixé sur son antigène (diapositive p. 8, « Cplx immuns AC – AG ») | `inn-qc-trois-voies` A |
| 11 | « relargage dans l'environnement d'enzymes : des formes réactives de l'oxygène » | les ROS ne sont pas des enzymes ; la diapositive p. 10 distingue enzymes protéolytiques, ROS, NET | `inn-qc-pnn-fonctions` C |
| 11 | PAMP : « protéines de surface » | des motifs de toute nature : mannose, PGN, LPS (diapositive p. 12) | `inn-qc-opsonisation` A |
| 14 | le NK produit « d'autres cytokines (TNF, IL-12) » | l'IL-12 vient des macrophages et des cellules dendritiques et active le NK (diapositive p. 14) | `inn-qc-nk-cytokines` C |

**Points douteux** :

| Page | Ce que dit le ronéo | Le doute | Carte |
|---|---|---|---|
| 3 | la peau saine arrête 99,9 % des bactéries | 99 % l'an passé, même professeur ; aucune diapositive | `inn-fa-barrieres`, `inn-qc-barrieres` B |
| 10 | les PNN « migrent très peu dans les tissus » | vrai hors inflammation ; ils sont les premiers à traverser l'endothélium vers le site (diapositive p. 5) | `inn-qc-pnn-fonctions` |
| 12 | opsonisation : « ajout de motifs […] par PNN, macrophages » | les opsonines sont des molécules solubles ; les phagocytes les reconnaissent | `inn-qc-opsonisation` E |
| 12 | « Peptides antimicrobiens (enzymes protéolytiques) » | deux armes distinctes (corrigé de 2023/2024 S1 QROC 5) | `inn-fa-bactericidie` |
| 12 | la NADPH oxydase aboutit à l'HOCl, « aussi » produit par la myéloperoxydase | seule la myéloperoxydase forme l'HOCl, à partir de l'H2O2 que fournit la NADPH oxydase | `inn-qc-phagocytose` C |
| 6 | « sepsis », « sepsis sévère », « choc septique » | classification abandonnée par Sepsis-3 (2016) ; on répond avec les mots du cours | `inn-qc-sepsis` C |
| 9 | C3a : « fonction anaphylatoxine = chimiokine » (la FC 2025-26 : « agit comme une anaphylatoxine/une chimiokine ») | le C3a agit comme une chimiokine sans en être une : les chimiokines sont une famille de petites cytokines (CC, CXC, C, CX3C ; Zlotnik et Yoshie, Immunity 2000), le C3a une anaphylatoxine du complément (Klos et al., Mol Immunol 2009) | `inn-qc-c3a-c3b` A |

**Deux sources du même cours qui ne disent pas la même chose**, dites par un
ATTENTION sans genre : la part des NK (5-15 % et 2-18 %, contre 10 % en 2025-26 :
`inn-fa-nk`, `inn-qr-nk-proportion`) ; la migration des monocytes (quelques
heures contre 20 à 24 h : `inn-fa-phagocytes`, `inn-qc-macrophages` A,
`inn-rv-pnn-macrophage`).

## Ce que les annales ont dicté

| Savoir | Questions |
|---|---|
| La voie alterne : spontanée, protection de l'hôte, properdine, facteur B, C3bBb, C5 convertase alterne | 2023/2024 S1 Q9, 2021/2022 S2 Q5, 2020/2021 S1 Q7, 2019/2020 S1 Q7, 2017/2018 S1 Q.5, 2016/2017 S2 Q3 |
| Les NK : récepteurs (KIR, CD94/NKG2, CD16), missing self, cytotoxicité, place dans l'antiviral | 2023/2024 S1 Q.8, 2022/2023 S1 Q7, 2021/2022 S2 Q8, 2020/2021 S2 Q9, 2018/2019 S2 Q10, 2017/2018 S2 Q5, 2016/2017 S1 Q6, 2016/2017 S2 Q6, 2015/2016 S1 QROC 4 |
| La voie classique : complexes immuns, C1q, C4b2a, C1 inhibiteur | 2020/2021 S2 Q6, 2018/2019 S2 Q6, 2015/2016 S1 Q7, 2021/2022 S2 QROC 5, 2019/2020 S1 QROC 5 |
| Le complexe d'attaque et les fonctions du complément | 2022/2023 S2 Q7, 2021/2022 S1 Q6 et Q10, 2019/2020 S2 Q2, 2017/2018 S2 Q6, 2016/2017 S1 QROC 4, 2015/2016 S2 QROC 5 |
| La bactéricidie des phagocytes | 2021/2022 S1 Q8, 2019/2020 S2 Q3, 2023/2024 S1 QROC 5, 2022/2023 S1 QROC 5 |
| Les effecteurs de l'immunité innée | 2015/2016 S1 Q1 |

Les annales restent verbatim ; leurs justifications citent désormais le ronéo
2026-27. **Aucune clé n'est contredite par le cours de l'année**, et trois sont
mieux assises : le C4bC2a (2020/2021 S2 Q6 C), enseigné p. 8 ; l'origine
lymphoïde des NK (2021/2022 S2 Q8 A) et leur phénotype CD3−, CD19− (2017/2018
S2 Q5 A, 2016/2017 S1 Q6 B), sur la diapositive p. 13. Les clés 2023/2024
(Q8 BCDE, Q9 BCE) et le corrigé du QROC 5 restent confirmés par la grille
officielle (dépôt du 15/10/2026). Cinq questions sont aussi dans IMMUNO n°11
(Pr Lefebvre), avec la même clé ; elles ne sont cartées qu'ici. Les huit autres
questions d'IMMUNO n°7 sont dans le chapitre de leur sujet (docstring
d'`annales.py`) ; la Q9 du sujet 2024/2025 est dans `immuno_infectieux`.

## Les clés qui ne sont pas reprises telles quelles

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2020/2021 S2 Q6 (voie classique) | ADE | **CE** | A (activation spontanée) et D (properdine) décrivent la voie alterne — l'errata des annales du Ronéosaure le relève ; C (C3 convertase C4bC2a) est vraie : diapositive p. 8 du ronéo 2026-27, corrigé de 2021/2022 S2 QROC 5. ADE est la clé de 2018/2019 S2 Q6 : recopie probable. Conflits sur A, C, D |
| 2017/2018 S2 Q5 (NK) | BCE | **BE** | C, les KIR « qui reconnaissent des signaux de danger », est cotée fausse en 2016/2017 S1 (question 6, C) sur la même formule ; le cours range les KIR parmi les récepteurs inhibiteurs du CMH I (p. 13). Conflit déclaré sur les deux sessions ; celle de 2016/2017 S1 garde sa clé |
| 2017/2018 S2 Q6 (le complément) | ADE | **ABE** | B (opsonisation) est un rôle du C3b (p. 9-10) ; D (« n'est activé efficacement qu'en présence d'IgG ») est fausse : voies sans anticorps (p. 8), IgM plus efficaces (cours 2024-25, p. 7). Conflits sur B, D |
| 2021/2022 S2 QROC 5 (voie classique) | corrigé imprimé sous « QROC 4 » | ce corrigé, rattaché au QROC 5 | les corrigés des QROC 4 et 5 sont intervertis dans la table ; non marqué officiel |
| 2019/2020 S1 QROC 5 (voie classique) | « pas de correction » | le corrigé de 2021/2022 S2 QROC 5 | la même question, au mot près : clé déduite |
| 2016/2017 S1 QROC 4 (complément et bactéries) | « récepteurs CR1-CR2 des PNN/macroph. » | « récepteurs du complément » | le CR2 (CD21) est celui des LB et des cellules dendritiques folliculaires ; non marqué officiel |

Reprises, avec une remarque dans la carte : 2021/2022 S1 Q8 (proposition C
entre parenthèses) ; 2021/2022 S1 Q10 (errata des annales) ; 2022/2023 S1 QROC 5
(corrigé sans titre) ; 2016/2017 S2 Q6 E (la vaccination et l'ADCC) ; 2017/2018
S2 Q6 C (les virus enveloppés) ; 2018/2019 S2 Q6 E (le C1 inhibiteur, hors des
trois cours, vrai d'après la littérature). Cas ouvert : aucun.

## Le schéma cliquable et la planche

| Fichier | Ce qu'on clique | Cartes |
|---|---|---|
| `cascade-complement-nue.svg` (`inn-zo-complement`) | les trois voies, la C3 convertase, le C3a, le C3b sur le microbe, la C5 convertase, le C5a, le complexe d'attaque | 9 |

Redessinée d'après les deux diapositives de la cascade, les mêmes en 2026-27
(p. 8-9) qu'en 2025-26 (p. 6-7), sans une légende ; la version légendée
`cascade-complement.svg`, tirée des mêmes constantes, est en correction. Les
notes des zones citent désormais le ronéo 2026-27.

**La planche** `inn-pl-phagocytose` : la diapositive « Reconnaissance /
Phagocytose / Destruction » (FC 2025-26 p. 9, plus nette ; ronéo 2026-27 p. 13),
légendes effacées — douze numéros, cinq intrus (perforine, complexe d'attaque
membranaire, récepteur KIR, granzyme, histamine). Ses notes citent le ronéo
2026-27.

**Illustrations** : 101 QCM sur 101 portent une diapositive ou un schéma de
l'échelle en correction ; 139 notes sur 154. Dix-huit diapositives viennent du
ronéo 2026-27 (les trois de la p. 13 — « Natural Killer », « Introduction » des NK,
« Conclusion PNN et mono » — remises le 19/10 au bon nom de fichier, qu'elles
n'avaient pas à la première extraction) ; huit de la FC 2025-26, quand le ronéo reprend la même
diapositive moins nette (complément, reconnaissance, destruction ; légende citant
les deux pages) ou ne la reprend pas (la tolérance des NK, p. 10). Cinq figures
2025-26 qui n'illustraient plus rien sont retirées du dossier `media/`.

## L'échelle : Simple → Moyen → Annale (C20, pilote du 15/10/2026)

Le premier chapitre à porter l'échelle (maquette validée par Vincent le 15/10,
`Diffusion/maquettes/maquette_echelle.html`). Sous ses annales, deux marches :
- **Simple** (`niveau-simple`, QRU à trois choix) : une seule idée. Le schéma du
  mécanisme est dans la question, une ligne effacée (la réponse).
- **Moyen** (`niveau-moyen`, QRM à quatre propositions) : une paire que les
  annales confondent, reformulée. Le schéma vient en correction, ses lettres
  posées dessus.

Chaque annale garde la figure du cours et reçoit en plus son schéma à lettres
(`diagramme=`, écrit `schema` dans le paquet) ; ses QROC reçoivent le schéma
nu. Les marches sont dans `ECHELLE`, entre deux marqueurs de `donnees.py` ; les
mécanismes, leurs cases vides et leurs lettres sont dans `schemas.py`
(`COMPLEMENT`, `NK`, `PHAGO`, `TROUS_*`, `LETTRES_*`) ; le dessin est dans
`echelle.py`, copie exacte du modèle du skill (`echelle_modele.py`).

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `inne-adaptatif` | 3 | 1 | 1 |
| `complement-voies` | 10 | 2 | 11 |
| `complement-effets` | 9 | 2 | 7 |
| `phagocytose` | 5 | 2 | 4 |
| `cellules-nk` | 13 | 4 | 9 |

**Trois schémas, un par mécanisme** : `ech-complement` (trois portes d'entrée,
une seule sortie), `ech-nk` (reconnaître, puis tuer), `ech-phagocytose`
(reconnaître, internaliser, détruire ; l'inné face à l'adaptatif). 79 fichiers :
3 complets, 40 variantes trouées, 36 variantes à lettres.

**Relue le 19/10/2026 sur le ronéo 2026-27** : chaque marche cite sa page de
l'année, ou sa page du cours 2024-25 pour les six absentes ; aucune clé ne
change, la répartition des clés Simple (A, B, C) et le nombre de vraies des
Moyen (une à trois) sont intacts. Un seul fait du schéma change : la case
`inne-spe` dit « spécificité + (générique) », le mot de la diapositive p. 3, au
lieu de « spécificité relative », et la proposition C de `inn-ech-pha-s7`, que
cette case cache, le suit. Les légendes des trois schémas citent le ronéo
2026-27.

**Le tag `edn`** n'est plus porté par aucune marche : les convertases, l'IFN-γ du
NK et le phénotype CD3−, CD56+ sont du cours 2026-27 (plus haut).

**Sans marche** : 2018/2019 S2 Q6 E, le C1 inhibiteur, hors des trois cours.

## Le lexique

Quatorze termes. Les huit d'avant gardent leurs pages de la FC 2025-26 et
prennent d'abord celles du ronéo 2026-27, mesurées par `chercher_pages.py`
(« inflammation » à la main : la ligature « ﬂ » le cache à l'extraction) :
phagocytose (5, 9, 11), opsonisation (9, 12), chimiotactisme (5, 6, 9),
anaphylatoxine (9, 11), complément (1, 2, 5, 7-10, 12), inflammation (2, 4-6,
12). Phagolysosome et neutrophilie ne sont plus dans le texte de l'année : ils
gardent la seule FC 2025-26 (p. 9, p. 8), sans provenance dans ce chapitre.

**Six termes nouveaux**, tous du ronéo 2026-27 : chimiokine (p. 6, 9), phagosome
(p. 12), intertrigo (p. 4), nosocomial (p. 4), septicémie (p. 4), vasodilatation
(p. 5-7). Écartés parce qu'un autre chapitre de l'UE les accueille déjà :
sepsis (`immuno_infectieux`), diapédèse et cytokine (`immuno_reponse_t`),
apoptose (`immuno_temporelle`), endocytose (`immuno_cmh`) ; cytotoxicité et
microbiote ont déjà une note ailleurs (`viro_antiviraux`, `bmcp_glucides`).

Les étymologies nouvelles — trois racines (`-comial (grec)`, `vas(o)- (latin)`,
`dilatare (latin)`) et les six termes — sont **proposées** pour
`scripts/etymologies.json`, avec leurs sources (TLFi par l'API du portail
cnrtl.fr, Littré, Wiktionnaire, Bailly, Gaffiot) ; la table n'est pas modifiée
par ce chapitre. Les définitions et les racines disent déjà, mot pour mot, ce
qu'`appliquer_etymologies.py` en écrira. Les racines réemployées gardent la clé
de la table : `chimi(o)-`, `kin(é)-`, `phag(o)-`, `-some`, `inter (latin)`,
`terere (latin)`, `noso-`, `sept- / sepsi- (grec)`, `-émie`.

## À relire

Aucune carte `a-relire` : chaque carte de cours porte sa page dans le ronéo
2026-27 ou, pour les sept absentes, dans la FC 2025-26 ou le cours 2024-25 ;
chaque annale garde sa clé vérifiée.

## Questions pour Vincent

- Le tag `edn` quitte cinq cartes, parce que le cours 2026-27 enseigne ou montre
  ce que les cours d'avant disaient « pas à retenir ». Pour le C3bBb
  (`inn-ech-cpl-s7`), le texte dit seulement « on ne détaille pas le mécanisme des
  autres voies » et la convertase n'est que sur les diapositives : la garder hors
  `edn` ?
- La part des NK : deux diapositives du même cours, 5-15 % et 2-18 %. Les cartes
  retiennent 5-15 % (la diapositive du chapitre des NK) et acceptent 2-18 %.
- Le sepsis : les cartes répondent avec les mots du cours (sepsis, sepsis
  sévère, choc septique), en point douteux. Si le professeur l'a projeté ainsi,
  le genre deviendrait « cours ».
- Le C3a « chimiokine » : deux ronéos de suite (2025-26, 2026-27) le disent, la
  diapositive dit « chimiotactisme ». Les cartes le gardent vrai au sens « agit
  comme », en point douteux ; si le professeur le dit tel quel, le genre
  deviendrait « cours ».

## Régénérer

```powershell
cd contenu\chapitres\immuno_innee
..\..\..\app\.venv\Scripts\python.exe generer.py
```

La planche se refait depuis `app/`, si ses rectangles changent :
`uv run --with pillow python ../.claude/skills/nouveau-chapitre/scripts/planche_depuis_image.py ../contenu/chapitres/immuno_innee inn-pl-phagocytose --apercus <brouillon>`.
