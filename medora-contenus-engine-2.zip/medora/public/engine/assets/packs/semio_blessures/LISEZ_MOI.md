# Sémiologie des blessures — paquet d'exemple

57 notes, 107 cartes. Deux sources : la fiche de cours et les annales de neuf
sessions.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 31 | 31 |
| QRU | 1 | 1 |
| Texte à trous | 12 | 49 |
| Repérage sur schéma | 4 | 17 |
| QROC | 5 | 5 |
| Recto-verso | 4 | 4 |

Sur les 32 questions à choix, **21 sont des annales** de 2016/2017 à 2023/2024 —
tout le polycopié.

## Les sept questions sur photographie, et les deux visages floutés

**Sept des vingt-et-une questions reposent chacune sur une photographie
médico-légale.** Elles sont cartées avec leur cliché : le lire EST l'exercice, et
une description écrite assez précise pour rendre la question jouable donnerait la
réponse du même coup — écrire que l'empreinte de la bouche du canon est visible,
c'est répondre « tir à bout touchant ».

| Session | Question | Ce qu'elle fait reconnaître | Cliché |
|---|---|---|---|
| 2022/2023 S2 | Q.17 *(imprimée « 14. »)* | distance de tir sur un orifice d'entrée | orifice + arme |
| 2019/2020 S1 | Q.1 | orifice osseux pariétal : entrée ou sortie | crâne sec |
| 2019/2020 S1 | Q.2 | orifice d'entrée, brûlure péri-orificielle | orifice + arme |
| 2019/2020 S2 | Q.1 | orifice d'entrée du visage, collerette d'essuyage | **visage flouté** |
| 2018/2019 | Q.23 | brûlures d'un nourrisson : accident ou maltraitance | jambes |
| 2016/2017 | Q.24 | ecchymose frontale d'un enfant : datation, cohérence du récit | **yeux floutés** |
| 2016/2017 | Q.25 | plaie par arme blanche : vitalité, arme à un ou deux tranchants | plaie |

### L'anonymisation

Deux clichés montraient un visage. `photos.py` les extrait du polycopié et les
floute avant qu'ils entrent dans le paquet :

- **2019/2020 S2 Q.1** — sourcil et paupière, aile du nez, lèvres. L'orifice
  temporal, sa collerette érosive et la teinte péri-orbitaire restent nets.
- **2016/2017 Q.24** — les deux yeux. L'ecchymose frontale, la lésion de l'arête
  nasale et la couleur des paupières restent nettes.

Le flou est gaussien, et c'est délibéré : il détruit le détail d'une zone mais en
conserve la couleur moyenne. L'hématome « en lunettes », qui est la réponse de
l'item D de 2016/2017, reste donc lisible alors que les traits ne le sont plus.
Le script vérifie la taille de chaque image avant de la traiter et s'arrête si le
polycopié a changé, plutôt que de flouter à côté.

Pour refaire les images (les deux bibliothèques ne sont pas des dépendances de
l'application) :

```
python -m uv run --with pymupdf --with pillow python photos.py [racine des cours]
```

## Ce que la fiche a dicté

Trois commentaires en marge :

- **« A savoir QCM »** sur toute la section IV — érythème, trace ecchymotique,
  ecchymose, hématome. C'est la section la plus cartée, et les annales
  confirment : **neuf de leurs vingt-et-une questions portent sur les
  ecchymoses**.
- **« A savoir »** sur la chronologie des couleurs — et c'est cette lecture qui
  l'emporte : **le nuancier est à connaître**. La phrase du cours, trois lignes
  plus haut (*« la chronologie suivante n'est pas à connaître par cœur car elle
  n'est pas toujours exacte »*), est une réserve sur la *précision*, pas une
  dispense : les annales ne demandent jamais qu'une datation **grossière**. Le
  nuancier est donc révisé sous trois angles — texte à trous (`ble-fa-datation`),
  repérage sur l'axe des jours (`ble-zo-datation`), et QCM de correspondances
  (`ble-qc-teintes`).
- Le troisième note que le professeur regarde particulièrement les **faces
  internes de cuisses et les creux poplités**, pour savoir s'il y a eu
  contrainte. D'où le schéma des localisations.

Plus deux « à savoir » écrits par le ronéiste : la définition de l'hématome
(*à savoir +++*) et le sens de résorption d'une ecchymose (*à savoir ++*).

## Une contradiction entre deux clés

| Source | Ce qu'elle dit d'une trace ecchymotique |
|---|---|
| Charonéo 2023-24, cours du Pr Gosset (auteur des deux questions) | « disparaît rapidement (24h) » |
| Ronéosaure 2024-25 (errata du cours, p. 4) | la trace d'une gifle « disparaît le lendemain » |
| Fiche de 2026 | « peut rester jusqu'à 48 h » |
| 2022/2023 Q.23 B | « disparaît en 24 heures » → **VRAI** |
| 2021/2022 S2 Q.24 B | « disparaît en moins d'une semaine » → **FAUX** |

Les deux clés ne peuvent pas être vraies ensemble : ce qui disparaît en 24 heures
disparaît a fortiori en moins d'une semaine. Le cours tranche pour 2022/2023. La
clé de 2021/2022 S2 confond sans doute la trace avec l'ecchymose elle-même, qui
met quinze à vingt-cinq jours à s'effacer (Medileg, « Éléments de traumatologie
médico-légale »). C'est le seul point du chapitre sur lequel deux sessions se
contredisent ; une autre clé reste ouverte, sur le contondant et la plaie
pénétrante, et une clé du polycopié est corrigée par le corrigé officiel
2023-24, le canal de Wharton (tableau ci-dessous).

### Clés non reprises telles quelles

Règle de Vincent du 26/09 : la clé retenue est la bonne, pas la clé imprimée.

| Question | Clé imprimée | Retenu | Pourquoi | Source |
|---|---|---|---|---|
| 2021/2022 S2 Q.24 (`ble-an-2122s2-q24`) | DE | **BDE** — carte non officielle | B « une trace ecchymotique disparaît en moins d'une semaine » est vraie : la trace s'efface en 24 à 48 h | Charonéo 2023-24 (Pr Gosset) ; fiche de 2026 ; Medileg pour la durée de l'ecchymose |
| 2022/2023 Q.23 (`ble-an-2223-q23`) | ABCDE | ABCDE, gardée | la clé est juste ; l'ATTENTION dit que c'est l'autre session qui se trompe | Charonéo 2023-24 |
| 2022/2023 Q.25 (`ble-an-2223-q25`) | BCD | BCD, gardée — **question ouverte** | A « les plaies pénétrantes peuvent être créées par un agent contondant » : faux pour le cours du Pr Gosset, auteur de la question (piquant et tranchant seulement) ; vrai si l'on suit le ronéo 2026-27, qui définit la plaie pénétrante par sa profondeur et range la plaie par balle parmi les plaies contuses | Charonéo 2023-24, p. 6 ; ronéo 2026-27, p. 2-3 ; Medileg (le contondant agit « par sa masse » ou « par sa vitesse ») |
| 2023/2024 Q.15 (`ble-an-2324-q15`) | ABCDE (table du polycopié) ; **ABCE** (corrigé officiel, reçu le 15/10/2026) | **ABCE**, le corrigé officiel — carte officielle, `CONFLITS` sur D | D « une plaie de la joue doit faire vérifier l'intégrité du canal de Wharton » est fausse : le Wharton est le conduit sous-mandibulaire, dans le plancher de la bouche ; c'est le canal de Sténon, parotidien, qui traverse la joue (et le nerf facial). La carte disait l'inverse et l'explication « les cinq items sont vrais » : corrigées | Gray's Anatomy (« Parotid duct », « Submandibular duct ») ; le cours ne parle pas de la joue |

**Le corrigé officiel 2023-24** (sujet de sémiologie générale et une clé par
question, dépôt du 15/10/2026) : la QCM 14 (`ble-an-2324-q14`, ABC) a sa clé
confirmée par le corrigé officiel 2023-24, dépôt du 15/10/2026 ; la QCM 15 est
corrigée (ligne ci-dessus). Les deux cartes gardent la source du polycopié.

La carte de cours `ble-fa-sansaffraction` précise désormais que « permanente »
veut dire visible après la mort, pas durable : sur le vivant, la trace s'efface
en 24 à 48 heures.

**La cocarde, corrigée le 16/10/2026** (relecture de l'échelle) : `ble-fa-collerettes`,
`ble-qr-cocarde` et la note de la zone « collerette érosive » d'`orifice-balle.svg`
disaient que les deux collerettes, ensemble, donnent l'aspect de cocarde. C'est
la peau, invaginée par le projectile puis revenue en place, qui le donne
(ronéo 2026-27, p. 3 ; FC 2025-26, II.C) ; les collerettes l'entourent.

## Deux notions hors cours

Elles n'existent que dans les annales, et il faut les connaître par elles :

- la **collerette d'estompage** et le **tatouage de poudre**, qui signent un tir
  à bout portant — à ne pas confondre avec les deux collerettes de l'entrée, qui
  ne disent rien de la distance ;
- les lésions de la **bombe lacrymogène** : érythème, bulles, puis desquamation
  furfuracée.

## Les quatre schémas cliquables

| Fichier | Ce qu'on y clique | Cartes |
|---|---|---|
| `peau-couches.svg` | les trois couches, avec trois profondeurs de lésion tracées | 3 |
| `orifice-balle.svg` | l'aspect de cocarde et ses deux collerettes | 3 |
| `ecchymose-datation.svg` | un nuancier posé sur un axe des jours | 5 |
| `sites-ecchymoses.svg` | six localisations, sur deux silhouettes | 6 |

Le deuxième emploie deux anneaux de `geometry.annulus`, ce qui laisse les trois
zones concentriques se toucher sans se recouvrir.

## Sans illustration

Restent sans lettre sur le schéma de l'échelle (`ech-blessures`) 2022/2023
QCM 24 (bombe lacrymogène), 2018/2019 QCM 23 (brûlures par immersion),
2017/2018 QCM 3 E, 2016/2017 QCM 24 C et D, 2019/2020 S1 QCM 1 A, D et E :
aucune case du cours ne les porte. Les deux premières, sans aucune lettre,
reçoivent le schéma nu, comme toute annale d'un thème qui a des marches.


## L'échelle : Simple → Moyen → Annale (C20, 16/10/2026)

L'échelle du pilote de l'immunité innée, étendue à la sémiologie pour l'examen du 4/11 (Vincent, 16/10 : « on continue pour les chapitres que je vais avoir à l'examen »). Sous les annales, 23 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 7 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`) ; les annales qui n'ont aucune lettre à poser (`ble-an-2223-q24`, `ble-an-1819-q23`) reçoivent le schéma nu.

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `effraction` | 6 | 1 | 4 |
| `objets` | 2 | 1 | 1 |
| `balles` | 4 | 1 | 6 |
| `ecchymoses` | 7 | 2 | 7 |
| `vitalite` | 2 | 1 | 2 |
| `sites` | 2 | 1 | 3 |

**Le schéma** `ech-blessures`, « Les blessures · décrire la lésion, remonter au mécanisme », donne 52 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_BLESSURES`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Sources.** `SRC` n'a pas de clé `fiche` : les marches relues sur la ronéo 2026-27 nomment la leur (`fiche="src-fc-semio-blessures"`), et les images de l'échelle sont déclarées sous `SRC["cours"]`. La relecture de l'échelle a corrigé la cocarde dans deux cartes de cours et une note de zone (plus haut) ; les annales sans lettre sont dites dans « Sans illustration ».

**Sans marche** :
- ble-an-2223-q24 (A à E) : la bombe lacrymogène n'est ni dans la ronéo 2026-27 ni dans la FC 2025-26 ; aucune lettre posée.
- ble-an-2223s2-q17 (A à E) : distance de tir et coloration par le CO, hors des deux cours ; lettres posées sur la case de l'orifice d'entrée.
- ble-an-1920s1-q1 (A à E) : le biseau d'un orifice osseux, hors des deux cours ; B et C posées sur les orifices d'entrée et de sortie ; A, D et E sans lettre.
- ble-an-1819-q23 (A à E) : brûlures par immersion d'un nourrisson, hors des deux cours ; aucune lettre posée.
- ble-an-2324-q14 D, ble-an-2223-q23 C, ble-an-2122s2-q24 C, ble-an-1920s2-q2 E : la lumière d'examen (du jour ou artificielle) n'est dans aucun des deux cours.
- ble-an-2324-q14 E, ble-an-1819-q24 C, ble-an-1718-q3 A, B, C, E : la maltraitance à enfant (multiplicité, tibias, poids) est hors cours ; seule 1718-q3 D, la couleur qui dit l'âge, a sa marche (s13).
- ble-an-2324-q15 C, D : l'anatomie de la joue (nerf facial, canal de Sténon ou de Wharton) est hors cours ; D est au CONFLITS, sa carte le dit.
- ble-an-2223-q23 E, ble-an-2122s2-q24 E : l'extension par fragilité cutanée (jeune enfant, sujet âgé) est hors cours.
- ble-an-2223-q25 B : la ronéo dit la plaie du tranchant « plutôt superficielle » (p. 3) sans la dire pénétrante ; aucune marche ne l'affirme.
- ble-an-2223s2-q18 D : la fracture n'est pas dans le cours.
- ble-an-2122s2-q21 C, D, E : la plaque parcheminée relève de la thanatologie (déshydratation, que la ronéo 2026-27 ne développe pas) ; hémothorax et hémopéricarde sont hors cours.
- ble-an-2122s2-q22 C, D, E : collerette d'estompage, brûlure et tatouage de poudre (distance de tir) sont hors cours.
- ble-an-2122s2-q23 A, ble-an-1819-q24 B : la contusion n'est définie nulle part ; la ronéo ne nomme le « mécanisme de contusion » que pour l'hématome (p. 4).
- ble-an-2122s2-q23 E : la dispersion des plombs est hors cours.
- ble-an-1718-q4 C, D, E : brûlures et ecchymose péri-orificielles hors cours ; E (« aucun des éléments ») dépend de C et D. E est posée sur la case de la sortie.
- ble-an-1920s1-q2 C, D, E et ble-an-1920s2-q1 C, E : bout touchant, brûlure, CO, ecchymose péri-orbitaire par diffusion : hors cours.
- ble-an-1617-q24 B, C, D, E : cohérence du récit, lésion de réanimation, fracture de l'étage antérieur : hors cours.
- ble-an-1617-q25 B, D : points de suture, couteau crénelé : hors cours.

## Régénérer

```powershell
python generer.py
```
