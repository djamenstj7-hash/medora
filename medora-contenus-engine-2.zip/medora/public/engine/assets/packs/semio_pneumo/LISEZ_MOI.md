# Examen pneumologique du sujet normal — paquet d'exemple

73 notes, 126 cartes (un texte à trous fait une carte par trou, un schéma
cliquable une carte par zone).

| Type | Notes | Cartes |
|---|---|---|
| QRM | 30 | 30 |
| Texte à trous | 14 | 55 |
| QROC | 8 | 8 |
| Recto-verso | 10 | 10 |
| Repérage sur schéma | 3 | 15 |
| Lexique | 8 | 8 |

Sur les 30 QRM, **15 sont des annales** : 13 du polycopié, de 2015/2016 à
2019/2020, avec la clé de sa table de corrections, et 2 du sujet 2023/2024,
avec la clé de son corrigé officiel (voir « Le sujet 2023/2024 »). Quatorze
images : trois schémas redessinés, neuf tirées de l'ancienne fiche — qui est
elle-même un ronéo, celui de 2025-26 (voir « Sans illustration ») —, et deux
du cours d'embolie pulmonaire (FC n°29, Ronéosaure 2024-25).

## La base : le ronéo 2026-27

**La base du chapitre est le ronéo de l'année** : Ronéo & Juliette 2026-27,
« Examen pneumologique », cours du **Pr Scherpereel** du 10/09/2026, 14 pages
(source `src-fc-semio-pneumo`, `SRC["fiche"]`). Le chapitre avait d'abord été
carté sur la fiche FC n°5 (`src-cours-pneumo`), qui est le ronéo de l'année
précédente : son en-tête dit « Swan et Ronéo 2025/2026 », cours du 15/09/2025,
et son texte suit de très près le FC n°11 du Ronéosaure 2024-25 (18/09/2024).
Il a été relu note par note sur le ronéo 2026-27 le 25/09/2026 : **38 notes de
cours, dont 11 nouvelles, citent la fiche 2026-27 à sa page** ; les 12 qui n'y
figurent pas gardent l'ancienne fiche et sont listées plus bas.

Même professeur, cours plus court (pas d'introduction ni de conclusion), mais
plus structuré : un plan d'analyse de chaque signe fonctionnel, « ARC IDATIC »,
une partie sur les troubles respiratoires du sommeil, des seuils d'abondance de
l'hémoptysie. Le ronéo n'a **pas de texte gris** ; son **rouge** marque, hors
des titres, ce qu'il faut retenir (« chez le sujet sain, aucun de ces signes
fonctionnels n'est présent », ARC IDATIC, les types d'expectoration, la
définition de l'hémoptysie, orthopnée / antépnée / platypnée, le siège des
douleurs thoraciques, le diaphragme, le plan de l'examen, « les deux temps »),
et tout ce rouge est carté.

## Ce qui a changé avec le ronéo 2026-27

- **Tachypnée : FR > 16/min** (p. 8). L'ancienne fiche (2025-26) écrivait
  « > 16-20/min », et le ronéo 2024-25 « on peut tolérer jusqu'à 20 ». `pne-fa-fr`, l'explication de `pne-zo-rythmes` et le
  terme de lexique « Tachypnée » (qui disait « au-delà de 20 ») sont alignés.
- **Le son trachéal est « normalement inaudible SANS stéthoscope »** (p. 14).
  La carte disait « pas audible AU stéthoscope », comme l'ancienne fiche
  (2025-26 : « non audible au stéthoscope ») ; le ronéo 2024-25 et le Charonéo
  2023-24 écrivaient déjà « sans ». `pne-fa-trachea` et
  la justification E de `pne-qc-bruits` réécrites.
- **Sept signes fonctionnels**, et non « cinq classiques » : la somnolence
  diurne (troubles respiratoires du sommeil) et les sifflements en font partie
  (p. 2). `pne-fa-cinq` a deux trous de plus.
- Le chiffre d'ouverture « 90 % d'interrogatoire, 10 % d'examen », et toute
  l'introduction sur les antécédents, ne sont plus au cours (voir plus bas).
- Les justifications et explications citent désormais le ronéo 2026-27 à la
  page ; ce qui vient de l'ancienne fiche le dit (« d'après l'ancienne
  fiche »). Aucune clé de question du cours n'a changé.
- **Onze notes nouvelles**, pour ce que l'ancienne fiche ne disait pas :
  `pne-rv-arcidatic` (le plan d'analyse), `pne-qc-toux-caracteres` (rauque,
  bitonale, grasse, déclencheurs), `pne-fa-abondance` (< 50, 50-200, > 200 cc
  ou > 500 ml/24 h), `pne-rv-hemoptysie-maladie` (maladie contre symptôme),
  `pne-fa-positions` (orthopnée, antépnée, platypnée), `pne-qc-douleur-siege`
  (rétro-sternale, latéro-thoracique, épaule ; EVA), `pne-qc-sommeil` et
  `pne-qr-epworth` (troubles respiratoires du sommeil, Epworth ≥ 10),
  `pne-rv-plan-examen` (3 A + fièvre, IPPA, examen extra-thoracique ciblé),
  `pne-rv-accessoires` (palpés « si non évident à l'œil »), `pne-rv-percussion`
  (la technique du droitier).
- Deux annales portent maintenant un schéma redessiné à la correction :
  2018/2019 QCM 11 (les rythmes) et QCM 12 (l'espace intercostal).

## Les ATTENTION du chapitre

Aucune clé d'annales n'est contredite par le ronéo 2026-27 : `CONFLITS` ne
garde que ses deux entrées de mise en page (plus bas), dont l'une porte aussi
une clé ouverte — voir « Clés relues le 26/09/2026 ».

| Carte | Ce qui se discute | Retenu |
|---|---|---|
| `pne-fa-fr` | tachypnée « > 16-20/min » (ancienne fiche, 2025-26) contre « FR > 16/min » (p. 8) | 16 |
| `pne-fa-trachea`, `pne-qc-bruits` E | « non audible au stéthoscope » (ancienne fiche, 2025-26) contre « normalement inaudible sans stéthoscope » (p. 14, comme 2024-25 et 2023-24) | le ronéo 2026-27 |
| `pne-fa-toux-types` | coquilles du ronéo 2026-27, qu'aucun tableau d'erreurs ne relève (« les cours ne seront pas modifiés ») : « monoliforme » pour « moniliforme », la toux quinteuse qui « survient par excès » pour « par accès » (p. 2) | « moniliforme », « par accès » — la graphie « monoliforme » reste à vérifier |
| `pne-zo-rythmes` | la note de la zone « tachypnée » (dans `schemas.py`) disait « au-delà de 16 à 20 », alignée sur 16 le 28/09/2026 ; le tracé plat est étiqueté « arrêt cardiaque : FR = 0 » par le ronéo, « arrêt respiratoire » par la carte | 16 ; arrêt respiratoire (FR nulle) |
| `pne-zo-reperes` | **c'est le cours lui-même** (tri du 28/09/2026) : la veine jugulaire externe « dans la région profonde du cou », drainant avec la jugulaire interne le sang « de l'encéphale, de la face » (p. 11) est le texte du Pr Scherpereel — même libellé au Ronéosaure 2024-25 (p. 13), et la diapositive voisine, rognée en haut, finit sur « …le cœur. ». Seul « et du cœur » est une déformation des ronéos 2025-26 et 2026-27 : le cours dit qu'elle ramène ce sang **vers** le cœur. La référence : elle est superficielle, et draine le cuir chevelu et la face (StatPearls) | à l'examen, comme le cours : un item qui reprend ce texte du cours se coche, « du cœur » est faux ; l'explication et la note de la zone donnent la référence anatomique |
| `pne-rv-accessoires` | le ronéo 2024-25 les faisait palper « si on ne les voit pas bien », et son errata proposait « si on les voit bien » ; le ronéo 2026-27 écrit « si non évident à l'œil » (p. 12), dans le sens du texte d'origine | le ronéo 2026-27 |

**Corrigé dans `schemas.py` le 28/09/2026** (relecture des erreurs du ronéo) :
la note de la zone « tachypnée » dit « au-delà de 16 » (elle disait « au-delà
de 16 à 20 »), et celle de la zone « jugulaire externe » dit qu'elle ramène le
sang vers le cœur (elle disait « de l'encéphale, de la face et du cœur »), avec
une ATTENTION qui attribue le reste au cours et donne la référence anatomique :
superficielle, drainant le cuir chevelu et la face.

## Absent du cours 2026-27

Rien dans le ronéo 2026-27 ne contredit ces cartes, mais leur contenu ne s'y
trouve pas. Elles sont **gardées telles quelles**, et leur explication dit
d'où elles viennent. **Vincent décide s'il les garde.**

**Notes entières, toujours citées sur l'ancienne fiche (sans page)**

| Note | Ce qui manque au ronéo 2026-27 |
|---|---|
| `pne-qr-9010` | « 90 % d'interrogatoire, 10 % d'examen » : plus d'introduction |
| `pne-qc-atcd` | les antécédents (tabac d'abord, professions successives, amiante 40 à 50 ans après, cannabis) ; il ne reste que le « contexte de survenue » d'ARC IDATIC |
| `pne-qc-dyspnee` | B, C, D : dire « essoufflé » au patient, l'échelle gros effort → repos ; le ronéo donne des repères pratiques et mMRC / NYHA (A et E y sont) |
| `pne-qc-toux` | les étiologies d'une toux sèche (RGO, ORL, pneumopathie interstitielle, asthme) ; D y est |
| `pne-qc-hypercapnie` | toute l'hypercapnie : l'inspection du visage ne cherche plus que la cyanose |
| `pne-fa-aaa` | le nom des trois A et le détail de la fièvre : le ronéo écrit seulement « 3 A + fièvre » |
| `pne-fa-percussion`, `pne-qr-mat` | le son normal (creux, tympanique) et la matité : le texte du ronéo ne décrit que la technique, et ses figures de la p. 13 n'ont pas été relues |
| `pne-qr-lingula` | la lingula et la percussion des faces latérales (l'auscultation latérale, elle, y est) |
| `pne-qr-troisier` | le ganglion de Troisier : le ronéo renvoie aux aires ganglionnaires par une figure |
| `pne-qr-hrb` | l'hyper-réactivité bronchique non spécifique |

**Éléments de l'ancienne fiche gardés dans des cartes relues** — la carte cite
le ronéo 2026-27, la justification dit d'où vient l'élément :

| Note | Élément gardé |
|---|---|
| `pne-zo-reperes` | la zone « Troisier » (sa note dit « Absent du cours 2026-27 »), et la sonorité dans la note de l'espace intercostal ; le SCM, la jugulaire et l'espace intercostal sont au cours. La carte entière était marquée absente jusqu'au 28/09 : une carte ne l'est que si elle manque tout entière |
| `pne-qc-hemoptysie` D et E | la fourchette « 200 à 300 cc » et le seuil plus bas si pathologie pulmonaire ; le sang clair récent, sombre ancien |
| `pne-qc-hemoptysie-mort` C | « aéré », souvent mousseux (le ronéo dit « rouge ») |
| `pne-qc-sifflements` C, D, E | les sifflements inspiratoires plus rares (bronchiolite) ; localisés → cancer, corps étranger ; l'asthme |
| `pne-qc-cyanose` E | « signe tardif » |
| `pne-qc-bruits` B | la fibrose et la décompensation cardiaque (le ronéo donne le mécanisme : des parois alvéolaires anormales) |
| `pne-qc-expectoration` C | la justification : expectoration abondante → dilatation des bronches, mucoviscidose |
| `pne-qc-thorax` D | la distension causée par une affection pulmonaire |
| `pne-fa-dynamique` | « dû au relâchement musculaire » (hors des trous) |
| `pne-qr-hematemese`, `pne-qr-trentetrois`, `pne-qr-somnolence` | dans l'explication ou le verso : les débris alimentaires ; la diminution des vibrations par l'air ou le liquide ; les siestes et le retentissement cardiovasculaire et métabolique |
| `pne-zo-formes` | dans les notes des zones : les causes (emphysème, déformation du contenant) |

## Le sujet 2023/2024 : deux questions sur l'embolie pulmonaire

Le sujet de sémiologie générale 2023/2024 et son corrigé officiel (une clé par
question) sont arrivés le 15/10/2026 (source `src-sujet-semio-2324`,
`SRC["sessions"]["2023/2024"]`). Ses QCM 24 et 25, du Pr Scherpereel, portent
sur l'**embolie pulmonaire** ; le chapitre n'avait aucune carte de cette
session. Elles sont ajoutées avec la clé officielle, `officielle=True` :
aucune ne contredit le cours.

| Carte | Clé officielle | Ce qu'elle demande |
|---|---|---|
| `pne-an-2324-q24` | BCD | l'origine du thrombus (« toujours » les membres inférieurs : faux), PIED, la radiographie (normale dans 25 % des cas ; atélectasies en bande, épanchement, coupole surélevée), le cœur droit et non gauche |
| `pne-an-2324-q25` | BCE | les quatre tableaux d'EP — infraclinique, infarctus pulmonaire, dyspnée isolée, choc « à poumons normaux » — contre le pneumothorax et l'œdème aigu du poumon |

**L'EP n'est pas au cours de ce chapitre** : ni l'ancienne fiche ni le ronéo
2026-27 ne la traitent, ils ne la nomment que dans PIED (p. 5). Elle
s'enseigne dans l'UE Système cardiovasculaire, au second semestre, par le même
professeur : les justifications citent son cours, la **FC n°29 « Embolie
pulmonaire » du Ronéosaure 2024-25** (cours du 07/02/2025), déclarée dans
`SOURCES` (`src-cours-ep`) ; le ronéo 2026-27 de ce cours ne paraîtra qu'au
second semestre. L'item D de la QCM 25 s'appuie aussi sur le ronéo de
sémiologie cardiovasculaire 2026-27 (l'œdème pulmonaire de l'insuffisance
cardiaque gauche, p. 12), et l'item A sur le FC n°11 du Ronéosaure 2024-25
(p. 17-18 : le pneumothorax ne transmet plus les vibrations vocales). Quatre
propositions de la QCM 24 reprennent la Q. 34 de 2017/2018 des annales de
cardiologie (Charonéo 2023-24), avec les mêmes réponses.

Les deux cartes sont illustrées à la correction par deux figures de ce cours,
extraites en PNG avec leur page : la radiographie d'une EP gauche (coupole
surélevée, atélectasies en bandes, p. 8) et l'angioscanner (infarctus à base
pleurale, « filling defect », p. 11). Les figures du Ronéosaure des années
précédentes partent avec le chapitre, seule une planche d'atlas restant exclue
(accord de Vincent du 29/09, `.claude/rules/cartes.md`) ; c'est plus récent que
la réserve écrite plus bas, dans « Sans illustration », pour les photographies
du ronéo — à confirmer par Vincent pour ces deux images.

Une coquille du sujet, gardée telle qu'imprimée : « quels peuvent-être »
(QCM 25). Les énoncés sont ceux du sujet ; le corrigé les formule un peu
autrement.

## Ce que les annales ont dicté

**Huit questions sur treize portent sur l'examen physique** — inspection,
palpation, percussion, auscultation. Les cinq autres portent sur le vocabulaire
des sécrétions et des saignements, dont quatre sur la seule toux.

Trois confusions font à elles seules la moitié des items faux :

| La confusion | Ce qui la lève |
|---|---|
| **hémostase** / **hématose** | hémoSTASE = coagulation ; hémaTOSE = échanges gazeux. Le mot « hémostase » apparaît dans trois questions différentes, toujours faux |
| **hémoptysie** / **hématémèse** | l'une vient des voies aériennes inférieures et sort à la toux, l'autre du tube digestif supérieur et sort au vomissement, avec des débris alimentaires |
| **cyanose** / **hypercapnie** | le manque d'O₂ **bleuit** ; l'excès de CO₂ **rougit**, avec sueurs, agitation puis somnolence (ancienne fiche) |

Et un piège que le cours désamorce explicitement : **une hémoptysie abondante tue
par asphyxie — « inondation des voies aériennes » —, pas par choc
hémorragique.** Au-delà de 200 cc en une fois (ou 500 ml en 24 heures), elle est
massive et toujours à risque mortel. Une annale 2016/2017 propose le choc
hémorragique, et le donne faux.

## Les trois schémas cliquables

| Fichier | Ce qu'on y clique | Cartes |
|---|---|---|
| `thorax-formes.svg` | six thorax, dont un seul normal | 6 |
| `respiration-rythmes.svg` | quatre tracés de ventilation | 4 |
| `thorax-reperes.svg` | cinq repères du thorax et du cou | 5 |

Les photographies de l'ancienne fiche **portent leur nom imprimé dessus** —
« Pectus excavatum = thorax en entonnoir ». Elles donneraient la réponse, donc
elles ne servent qu'à la correction ; les six silhouettes à cliquer sont
redessinées nues, avec la vue indiquée sous chaque case (de face, de profil, de
dos), parce que l'orientation est une donnée et non la réponse.

Deux points de méthode sur le troisième schéma :

- **Les côtes sont obliques**, donc les zones « une côte » et « l'espace
  intercostal » sont des parallélogrammes calés sur la pente, leurs sommets
  calculés sur la courbe de Bézier qui trace la côte. Un rectangle mordrait sur
  l'espace d'un côté et laisserait l'os de l'autre — c'est ce qu'il faisait au
  premier essai.
- **Le sterno-cléido-mastoïdien et la jugulaire externe sont bilatéraux**, et ne
  sont dessinés que d'un côté chacun. Les dessiner en double ferait compter faux
  un clic sur le jumeau, qui désigne pourtant la même chose. La légende du schéma
  le dit.

## Clés relues le 26/09/2026

Règle de Vincent : la clé retenue est la bonne, pas la clé imprimée. Aucune clé
n'a été changée ; une reste ouverte.

| Question | Clé imprimée | Retenu | Pourquoi | Source |
|---|---|---|---|---|
| 2018/2019 QCM 11 A (`pne-an-1819-q11`) — « la FR se mesure visuellement en comptant les mouvements thoraciques observés » | faux (clé BD) | **faux, gardé — question ouverte** | le référentiel national mesure la FR en observant le patient ; le ronéo 2026-27 la range dans l'inspection mais la mesure main posée, au chronomètre, et le professeur sépare l'observation (une idée) de la mesure | Collège des enseignants de pneumologie, référentiel de sémiologie respiratoire 2009, p. 29 ; ronéo 2026-27 p. 7-8 |
| 2018/2019 QCM 12 C (`pne-an-1819-q12`) — diminution des vibrations vocales par air ou liquide | vrai (clé BCD) | vrai, gardé | la clé est juste ; seul l'imprimé est coupé | même référentiel, p. 73 |

## Les trois anomalies du polycopié

Aucune autre clé ne contredit le cours, et les sessions qui se recoupent se
confirment l'une l'autre. Restent trois défauts d'impression, tous signalés à
l'endroit exact où ils se jouent :

- **2018/2019 QCM 11** : la proposition A tient sur deux lignes et la seconde a
  reçu à son tour la lettre « A ».
- **2018/2019 QCM 12** : la proposition C est coupée et sa suite est numérotée
  « 1. ». Dans les deux cas, six lettres imprimées pour cinq propositions.
- **2019/2020 nov S2 QCM 5** : l'énoncé annonce « l'auscultation pulmonaire
  normale » alors que les cinq propositions parlent de percussion et de
  vibrations vocales. C'est l'énoncé de la question 4 recopié par inadvertance ;
  la clé, elle, corrige bien des items de percussion. L'énoncé a été rétabli et
  la carte le signale.

## Sans illustration

7 QRM sur 30 portent une image à la correction (cinq schémas redessinés, et
les deux figures du cours d'EP pour les questions de 2023/2024), et le
chapitre ne peut pas atteindre la moitié. Les trois schémas redessinés couvrent tout ce qui se
dessine ici — les formes du thorax, les rythmes, les repères du cou et de la
percussion — et sont attachés partout où ils éclairent la réponse. Le reste du
cours est fait de mots et de sons : les signes fonctionnels, les sécrétions,
les saignements, la cyanose, les bruits d'auscultation. Leurs seules images
seraient les photographies du ronéo (cyanose, hippocratisme, aires
ganglionnaires), qui appartiennent à leur propriétaire et ne s'emportent pas.
Les neuf photographies déjà attachées (`cours-*.png`) viennent de l'ancienne
fiche, dont on sait maintenant que c'est le ronéo 2025-26 : elles sont gardées
telles quelles, et Vincent décide si elles restent dans le dépôt.


## L'échelle : Simple → Moyen → Annale (C20, 16/10/2026)

L'échelle du pilote de l'immunité innée, étendue à la sémiologie pour l'examen du 4/11 (Vincent, 16/10 : « on continue pour les chapitres que je vais avoir à l'examen »). Sous les annales, 26 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 6 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`).

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `fonctionnels` | 3 | 1 | 1 |
| `toux` | 4 | 1 | 4 |
| `hemoptysie` | 6 | 1 | 2 |
| `inspection` | 6 | 1 | 4 |
| `palpation` | 3 | 1 | 3 |
| `auscultation` | 4 | 1 | 1 |

**Les schémas** sont au nombre de 2 : `ech-pneumo`, « L'examen pneumologique · les signes, puis l'IPPA » (21 Simple, 5 Moyen, 13 annales ; 40 fichiers), et `ech-embolie`, « L'embolie pulmonaire · d'où, comment, quelle gravité » (5 Simple, 1 Moyen, 2 annales ; 9 fichiers). Une carte ou une annale va au schéma de son mécanisme. Ils sont décrits dans `schemas.py` (`ECH_PNEUMO`, `ECH_EMBOLIE`, avec leurs `TROUS_*` et `LETTRES_*`, un `FICHIERS.update` chacun) et dessinés par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Le second mécanisme**, `ech-embolie`, redessine en appoint le cours d'embolie pulmonaire 2024-25 (FC n°29 du Ronéosaure, `src-cours-ep`, p. 2-9), que citent `pne-ech-s22` à `pne-ech-s26` et `pne-ech-m6`, pour les deux questions de 2023/2024 (Q24 et Q25) : une case d'embolie sur le schéma principal aurait trahi la case vide de `pne-ech-s21`.

**Exception à la règle 2** : `pne-an-1718s2-q3` reste sans marche (voir « Sans marche ») : une marche trancherait entre le ronéo 2026-27 et la FC n°5 2025-26 sur les étiologies de la toux ; ses lettres sont posées sur la case de la toux.

**Sans marche** :
- pne-an-1718s2-q3 (toute la question) : les cinq étiologies ne sont ni au ronéo 2026-27 ni à la FC n°5 2025-26, qui ne nomme que le reflux d'une toux allongée (p. 4), là où le ronéo attribue la toux aux changements de position au liquide pleural (p. 2) ; une marche trancherait entre les deux. Lettres posées sur la case de la toux.
- pne-an-1617-q23 A, B, C, E et pne-an-1516-q19 A, B, E : même raison (réflexe, RGO, ORL, pneumopathie interstitielle, asthme), seules les D et C se préparent
- pne-an-1920s1-q9 A (thorax harmonieux) : écrit sur la case du thorax normal (p. 7), sans carte qui la troue
- pne-an-1718s2-q4 A et pne-an-1516-q18 A (coloration bleutée) : écrite sur la case de la cyanose (ligne 1, p. 11), sans carte qui la troue
- pne-an-1920s1-q10 A (crépitations sous-cutanées), D (son creux), pne-an-1920s2-q5 C (tympanique) et pne-an-1819-q12 E (matité) : le ronéo ne décrit que la technique de la percussion (pne-fa-percussion et pne-qr-mat sont absents de 2026-27)
- pne-an-1819-q12 C (diminution des vibrations par air ou liquide) : absente du ronéo 2026-27, justifiée par le référentiel du Collège ; prise dans le CONFLITS de mise en page
- pne-an-1718s2-q4 B et pne-an-1516-q18 B (ralentissement circulatoire) : absent du ronéo 2026-27
- pne-an-1617-q22 A (lors d'une toux), C (hémostase), D (cyanose) : le ronéo le dit par la toux grasse, que le schéma n'écrit pas pour ne pas trahir la case de la toux sèche ; hémostase et cyanose n'ont rien à y faire et le cours ne les rapproche pas
- pne-an-1617s2-q22 A (aéré) et C (origine vasculaire) : le ronéo dit seulement « rouge » (p. 3) et ne dit pas l'origine vasculaire

## Régénérer

```powershell
python generer.py
```

Le script valide avant d'écrire et refuse d'écrire s'il trouve une erreur : une
justification manquante, un trou de plus de deux mots, une page hors de la
fiche, un conflit déclaré et non signalé.
