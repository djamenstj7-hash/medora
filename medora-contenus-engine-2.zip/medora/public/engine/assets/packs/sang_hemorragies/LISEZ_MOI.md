# Syndromes hémorragiques d'origine hématologique — paquet Tissu sanguin

53 notes, 80 cartes. Chapitre `chap-ue-tissu-sanguin-fc7` de l'UE **Tissu sanguin**,
septième chapitre. **Cours du 14/10/2026, 9 h-10 h, Pr A. Rauch, ronéo Ronéo & Juliette
2026-27** « Principes d'exploration et sémiologie des syndromes hémorragiques » (12 p.),
la base du chapitre depuis le 19/10/2026. Il était carté depuis septembre sur la FC n°7
du Ronéosaure 2024-25, qui n'est plus qu'un appoint. Annales : le QCM 3 et la QROC 1 de
2023/2024 (Ronéosaure 2024-25). Examen : partiel de novembre (mercredi 4/11/2026) ; la
ronéo annonce pour l'UE 10 QCM et 2 dossiers cliniques de 7 questions (p. 2).

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 20 | 20 |
| QRU (échelle) | 12 | 12 |
| Texte à trous | 5 | 22 |
| QROC | 4 | 4 |
| Recto-verso | 6 | 6 |
| Lexique | 5 | 5 |
| Schéma cliquable | 1 | 11 |

Dont **2 annales** (QCM 3 et QROC 1 de 2023/2024), 17 QCM de cours et 14 marches de
l'échelle. **28 QCM sur 32 illustrés (88 %)**, 36 notes sur 53. **Aucune carte absente du
cours 2026-27.** **2 cartes portent un piège de la ronéo** (thème « Pièges des ronéos »).

Cinq thèmes, déjà dans `THEME_LABELS` (`app/src/med_engine/application/scopes.py`) ; le
réalignement n'en ajoute aucun :

| Clé | Libellé |
|---|---|
| `interrogatoire` | L'interrogatoire d'un syndrome hémorragique |
| `purpura` | Le purpura |
| `gravite` | Signes de gravité et purpura fulminans |
| `coagulopathies` | Sémiologie des coagulopathies |
| `hemophilie` | L'hémophilie |

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-sang-hemorragies-2627` — « Principes d'exploration et sémiologie des syndromes hémorragiques » (12 p.), `Tissu sanguin/SYNDROMES HEMORRAGIQUES.pdf` | **2026-27** | **la fiche** (`SRC["fiche"]`, `chapitre=`), ce que le lecteur ouvre. Partie I, la sémiologie (p. 2-7) : 50 notes la citent. Partie II, l'exploration (p. 7-12), cartée dans `sang_exploration` |
| `src-hemorragies-renvoi-arbres` — « Arbres décisionnels et cas cliniques » (26 p.), `Tissu sanguin/ARBRES DECISIONNELS ET CAS CLINIQUES.pdf` | **2026-27** | la fin du même cours (10 h-11 h, « Principes d'exploration et sémiologie des syndromes hématologiques (fin) ») ; fiche de `sang_exploration`, déclarée ici **sans** `chapitre=` ; 3 notes la citent (`fiche=ARB`) : les seuils de l'hémophilie (p. 12) et la toxicité du sang pour le cartilage (p. 16) |
| `src-cours-sang-hemorragies` — FC n°7 « Syndromes hémorragiques d'origine hématologique » (9 p.) | 2024-25 | **appoint** (`SRC["cours"]`, sans `chapitre=`), cité « cours 2024-25, p. 5 » ; son auteur porte désormais l'année, qu'il n'avait pas : une carte qui le citerait sans page montrerait « Cours 2024-25 » |
| `src-fc-sang-hemorragies-2526` — FC n°8 « Principes d'exploration et sémiologie des syndromes hémorragiques » (9 p.) | 2025-26 | **appoint**, cité « FC 2025-26, p. 3 » |
| `src-annales-sang-hemorragies` — « Principes d'exploration et sémiologie des syndromes hématologiques » (9 p.) | 2024-25 | fascicule commun avec `sang_exploration` ; deux questions relèvent de la sémiologie, elles sont ici |
| tableau des erreurs de tissu sanguin de la promo 2026-27 | 2026-27 | **aucune ligne** sur ce cours au 19/10/2026 |

Les textes citent « (p. 4) » pour la ronéo 2026-27, « (Arbres décisionnels 2026-27,
p. 25) » pour la ronéo de 10 h. La fiche se copie dans le dossier des PDF de
l'application par `outils/copier_les_cours.py`, lancé hors du bac à sable avec le dossier
du dépôt du 19/10 (`Ajouts/[NUMERIQUE] Ronéo & Juliette 26-27 19 10 2026/S1/CM`).

Les en-têtes des ronéos nomment leurs rédacteurs et leurs correcteurs, le polycopié
d'annales son secrétaire : aucun nom n'est repris.

## Ce qui correspond à quoi

| Cours 2024-25 (FC n°7) | Ronéo 2026-27 |
|---|---|
| I. Introduction, interrogatoire, nature des symptômes (p. 2-3) | I-A, p. 2-3, avec un tableau des saignements |
| II-A, B. Purpura : généralités, origines (p. 3-4, 6) | I-B-1, 2, 6, p. 3-5, avec le tableau des formes (p. 3-4) et le tableau plaquettaire / vasculaire (p. 5) |
| II-C. Purpura fulminans, thrombopénie sévère (p. 4-6) | I-B-3, 4, 5, p. 4 |
| II-D. Exemples : PTI, purpura rhumatoïde (p. 7) | p. 5 |
| III-A. Coagulopathies : hématome, hémarthrose (p. 7-8) | I-C-1, 2, p. 5-6 |
| III-B. Hémophilie sévère (p. 8-9) | I-C-3, p. 6 ; les seuils, la révélation et l'arthropathie dans les Arbres décisionnels, p. 12-16 |
| III-C. Hémophilie acquise (p. 9) | I-C-4, p. 6-7 |
| Orientation biologique (p. 9) | partie II, p. 7-12 : `sang_exploration` |
| — | **nouveau** : cinq signes de gravité, vibices, saignement immédiat ou retardé, AVK et AOD, « saignements utérins abondants », complications d'un hématome (nerf médian, nerf fémoral, loges), signes non spécifiques, Silverman, hémophilie acquise sous anticoagulant, conclusion (p. 7) |

## Le réalignement du 19/10/2026

Les 41 notes de la version 2024-25 ont été relues une à une contre la ronéo 2026-27 et
sa fin, les Arbres décisionnels. **Toutes citent désormais une page de l'année** (leur
tag est `cours-2026-27`) : 38 la ronéo de 9 h, annales comprises en source secondaire,
3 les Arbres décisionnels (`hmr-qc-hemophilie-severite`, `hmr-fa-severite`,
`hmr-rv-hemarthrose`). Chaque proposition ou chaque phrase que seuls les cours 2024-25 ou
2025-26 portent le dit dans sa justification.

**Ce que la ronéo 2026-27 dit autrement, et ce qui a été réécrit** :

- **Cinq signes de gravité** (p. 4) — extension rapide, fièvre, nécrose, bulles
  endobuccales, céphalées ou signes neurologiques focaux — au lieu des « deux signes,
  fièvre et thrombopénie » de 2024-25 : `hmr-qc-gravite` B devient « une fièvre et une
  thrombopénie sévère sont à rechercher en urgence » (les deux urgences du plan, p. 1, 4) ;
  la marche `hmr-ech-s2` demande la fièvre « avec l'extension rapide et la nécrose » ; la
  case « Premier réflexe » du schéma dit « chercher les signes de gravité ».
- **L'antibiothérapie du purpura fulminans** est « à large spectre, administrée sans
  attendre la ponction lombaire » (p. 4), sans nommer la C3G ni la voie : le texte à trous
  `hmr-fa-fulminans` est réécrit sur l'encadré « Urgence » (cinq trous : rapidement,
  fièvre, nécrose, fulminans, large spectre) ; la C3G en intraveineuse reste dans les
  cartes qui la demandaient (annale E, `hmr-ech-s6`), dite du cours 2024-25.
- **« Infection invasive »** à méningocoque ou à pneumocoque (p. 4), non plus
  « septicémie » : `hmr-qc-fulminans` A, `hmr-ech-s4`, le schéma.
- **Les bulles endobuccales font hospitaliser en urgence** (p. 4), non plus « examen
  neurologique » : `hmr-rv-bulle`, `hmr-ech-s9`, le schéma.
- **Le tableau des saignements** laisse l'hématurie et les saignements digestifs sans
  orientation (p. 3) : la QROC `hmr-qr-signes-primaire` demande désormais les quatre
  saignements cutanéo-muqueux du tableau (ecchymoses, épistaxis, gingivorragies,
  saignements utérins abondants).
- **« Saignements utérins abondants »** remplace ménorragie (p. 3) : `hmr-qc-questions` D.
- **Le PTI devient « immunologique »**, touche l'enfant et l'adulte, typiquement
  pétéchial, chronique plus souvent chez l'adulte (p. 5) : `hmr-qc-pti` est réécrite sur
  ces traits (clé ADE).
- **Le purpura plaquettaire est « plan, sans relief », « membres atteints
  indifféremment »** (tableau, p. 5) : le schéma et les marches `hmr-ech-s5`, `s10` disent
  « plan », non plus « maculeux ».
- **La présentation de l'hémophilie sévère** : une première hémarthrose de cheville, de
  genou ou de coude, des hématomes d'âges différents (p. 6), sans les « 9 à 18 mois » de
  2024-25 : `hmr-qc-hemophilie-presentation` A et D.
- **Les formes sporadiques font « environ 1/3 »** (p. 6), non plus 30 % :
  `hmr-rv-depistage`.
- **L'hémophilie acquise est « plutôt » celle du sujet âgé, « plus rarement » du
  post-partum** (p. 7) : `hmr-qc-hemophilie-acquise` B et D.
- **L'hématome du psoas comprime le nerf fémoral** (p. 6) : `hmr-rv-psoas` demande le nerf,
  et garde la présentation abdominale de 2024-25, que confirme la World Federation of
  Hemophilia.
- **Le purpura thrombopénique « jamais ecchymotique » et « thrombopathie (= maladie de
  Willebrand) »** de 2024-25 disparaissent : la ronéo fait la numération devant un purpura
  « pétéchial ou ecchymotique » (p. 7) et cherche le Willebrand avant la thrombopathie
  (p. 8). `hmr-qc-purpura-def` E le dit par un ATTENTION nu ; le texte à trous
  `hmr-fa-purpura` est réécrit sur les quatre formes (vitropression, pétéchies,
  thrombopénie, ecchymoses, vibices).

**Notes nouvelles (12)** :

| Note | Ce qu'elle carte |
|---|---|
| `hmr-qc-signes-gravite` | les signes de gravité d'un purpura (p. 4) |
| `hmr-qc-orientation` | saignement immédiat ou retardé, l'exemple de transmission dominante, Willebrand, saignements utérins abondants (p. 2-3) |
| `hmr-qc-complications` | nerf médian, nerf fémoral, syndrome des loges, signes non spécifiques (p. 5-6) |
| `hmr-qc-conduite` | la conclusion : la gravité d'abord, risque compressif, bilan pré-transfusionnel, bilan de coagulation sous anticoagulant (p. 7 ; Arbres décisionnels p. 5) |
| `hmr-fa-signes-coagulation` | signes spécifiques et non spécifiques des troubles de la coagulation (p. 5-6) |
| `hmr-qr-silverman` | le seul diagnostic différentiel cité, le bilan normal (p. 6) |
| `hmr-rv-acquise-anticoagulant` | le bilan de coagulation systématique, même sous anticoagulant (p. 7) |
| `lex-purpura`, `lex-gingivorragie`, `lex-thrombopathie`, `lex-coagulopathie`, `lex-vitropression` | le lexique du chapitre (voir plus bas) |

## Ce que le cours a dicté

- **Le rouge** de la ronéo est celui des titres du plan, des encadrés « Signe
  caractéristique » (la vitropression, p. 3 : `hmr-qc-purpura-def` B) et « Urgence » (p. 4 :
  `hmr-fa-fulminans`), et d'« urgence vitale » (p. 4 : `hmr-qc-fulminans`).
- **Le gris** : le cas du petit garçon (p. 6) et la ligne des vibices, en gris clair dans
  le tableau des formes (p. 4). La ronéo ne définit pas son gris : c'est la voix des
  rédacteurs (décision de Vincent du 25/09), cartée comme le reste
  (`hmr-qc-hemophilie-presentation`, `hmr-fa-purpura`).
- **Les figures de la ronéo** font foi et illustrent les corrections (voir plus bas).
- **Pas de carte** sur les modalités d'examen (p. 2), dites ici seulement.

## Les annales

Le polycopié commun avec `sang_exploration` porte presque entièrement sur
l'exploration ; deux questions relèvent de la sémiologie et sont ici, **verbatim** pour le
QCM 3 : ses propositions A, C et E, résumées avant le 19/10/2026 (« rouges ou violacées »,
« en faveur d'un purpura fulminans », « en intraveineuse »), reprennent le texte du sujet
officiel de 2023/2024 (QCM de tissu sanguin du 06/11/2023, dépôt d'annales du 15/10/2026) :
« rouges/violacées », « en faveur d'un diagnostic de purpura fulminans », « administrée par
voie intraveineuse ». La QROC 1, en deux temps sur le sujet (a, citer les deux mécanismes ;
b, un tableau d'au moins trois critères), est réunie en une question, comme les autres
QROC de l'UE. Leurs
clés ont été relues sur la ronéo 2026-27, qui les confirme : le purpura ne s'efface pas
(p. 3), le purpura nécrotique fait chercher un fulminans (p. 4), les bulles « ne sont pas
un signe spécifique de purpura fulminans » (p. 4), l'antibiotique part sans attendre la
ponction lombaire (p. 4) ; la QROC trouve ses critères dans le tableau de la p. 5. Elles
portent `page=` et citent la ronéo de l'année en source secondaire.

## Les clés qui ne sont pas reprises telles quelles

Aucune clé n'est reprise autrement qu'imprimée. Un contresens reste ouvert, et la carte
le dit (`CONFLITS`, justification de l'item B) :

| Question | Clé imprimée | Retenu | Pourquoi | Source |
|---|---|---|---|---|
| 2023/2024, QCM 3 B (`hmr-an-2324-q3`) — « la présence de lésions nécrotiques doit faire éliminer un diagnostic de purpura thrombopénique idiopathique » | E (B faux) | **E**, clé imprimée, officielle — cas ouvert | tout tient à « doit faire éliminer ». Au sens d'« oblige à écarter un diagnostic à ne pas manquer » — celui de l'item D de la même question et de l'usage médical —, l'item est faux : une nécrose fait écarter en urgence un purpura fulminans, pas un PTI. Au sens de « permet d'exclure un PTI », il serait vrai : le PTI est « typiquement pétéchial ». La clé colle à la construction de la question | ronéo 2026-27, p. 4-5 ; cours 2024-25, p. 5 ; E. Pilly (ECN), item 215 |

La grille officielle du sujet 2023/2024, déposée le 15/10/2026, donne E seul : la clé est
confirmée, sans que le sens de « doit faire éliminer » soit tranché. Le corrigé officiel
des QROC 2023/2024 donne pour la QROC 1 les trois critères exigés et un quatrième, les
signes associés ; l'explication de `hmr-an-qr-mecanismes` les cite.

## Les erreurs de la ronéo 2026-27

Le tableau des erreurs de tissu sanguin de la promo n'a aucune ligne sur ce cours au
19/10/2026 : toutes ont été trouvées en relisant. À l'examen, on répond d'abord comme le
professeur.

**Prise de notes fausse** (`ATTENTION (prise de notes)`) :

| Page | La ronéo dit | Ce qui est juste | Carte |
|---|---|---|---|
| 2 | « Certaines formes modérées de maladie de Willebrand ou d'hémophilie » saignent peu, découvertes « parfois à l'âge adulte » | pour l'hémophilie, ce sont les formes MINEURES (5-40 %) ; les modérées (1-5 %) se découvrent dans les premières années de vie (Arbres décisionnels 2026-27, p. 13-14, même professeur, même jour ; cours 2024-25, p. 2 ; World Federation of Hemophilia, lignes directrices 2020, tableau 2-1) | `hmr-qc-hemophilie-severite` (D) |

**Point douteux** (`ATTENTION (douteux)`), dit dans la carte sans changer sa clé :

| Page | Le point | Carte |
|---|---|---|
| 6 | l'hématome du psoas, « compression du nerf fémoral avec paralysie du membre inférieur » : une formule imprécise ; la compression du nerf fémoral affaiblit le quadriceps, abolit le réflexe rotulien et donne des paresthésies de la cuisse (World Federation of Hemophilia, 2020), sans paralyser tout le membre | `hmr-rv-psoas` |

**Relu et écarté le 19/10/2026** : « Extension rapide des lésions, si oui alors on a un
purpura fulminans jusqu'à preuve du contraire » (p. 4) n'est pas une erreur. L'encadré
« Urgence » de la même page réunit extension rapide, fièvre et nécrose, les Arbres
décisionnels mettent l'extension rapide parmi les premiers signes cherchés (p. 25), et le
purpura fulminans se définit comme un purpura rapidement extensif (FC 2025-26, p. 4).
`hmr-qc-gravite` D le dit à côté de l'adage du purpura fébrile, sans ATTENTION.

**Dans la partie II** (p. 7-12), que `sang_exploration` carte : le type 2 de Willebrand
« (il en existe deux types) » (p. 9) — il en a quatre, 2A, 2B, 2M, 2N (Arbres décisionnels
2026-27, p. 6-7 ; classification de Sadler, J Thromb Haemost 2006) — et le plasma pauvre
en plaquettes donné pour la couche intermédiaire de plaquettes et de leucocytes (p. 10 ;
porté par `exp-qc-plasma` B). Aucune carte d'ici ne les porte.

Deux imprécisions sans ATTENTION : les hématomes de l'hémophilie acquise dits
« concentriques » (p. 7 ; « circonférentiels » en 2024-25, ce que dit
`hmr-qc-hemophilie-acquise` D) ; le PTI « typiquement pétéchial » (p. 5), quand il peut
aussi être ecchymotique.

## Les erreurs du Ronéosaure

Elles ne vont pas dans `contenu/ERRATA_RONEOS_2026-27.md`, qui ne tient que les ronéos de
l'année ; la carte les dit par un ATTENTION nu ou une phrase :

- cours 2024-25, p. 3 et 6 : « thrombopathie (= maladie de Willebrand) », et un purpura
  thrombopénique « jamais ecchymotique » — `hmr-qc-purpura-def` E (ATTENTION nu) ;
- cours 2024-25, p. 6 : le texte prête au purpura plaquettaire les lésions « infiltrées,
  palpables, en relief », que son propre tableau donne au vasculaire — `hmr-ech-s10` B le
  dit, sans ATTENTION depuis que la carte cite la ronéo 2026-27, dont le tableau est juste.

Deux ATTENTION nus restent pour les années qui diffèrent : la C3G de 2024-25 contre
l'« antibiothérapie à large spectre » de 2026-27 (`hmr-ech-s6`), et le cas ouvert de
2023/2024 QCM 3 B (`hmr-ech-s5`, `hmr-ech-m1`).

## Les schémas et les figures

**Huit figures de la ronéo 2026-27**, extraites en PNG dans `media/` et déclarées dans
`IMAGES` avec leur page, côté correction :

| Fichier | Page | Cartes |
|---|---|---|
| `bulles-endobuccales.png` (avec « céphalées, hémorragies rétiniennes, signes de focalisation neurologique ») | 3 | `hmr-qc-gravite`, `hmr-qc-signes-gravite`, `hmr-rv-bulle`, `hmr-an-2324-q3` |
| `purpura-ecchymotique-petechial.png` | 4 | `hmr-qc-purpura-def` |
| `purpura-necrotique.png` (sans légende dans la ronéo) | 4 | `hmr-qc-fulminans`, `hmr-fa-fulminans` |
| `hematomes-enfant.png` | 6 | `hmr-qc-hemophilie-presentation`, `hmr-qr-silverman` |
| `hemophilie-acquise.png` | 6-7 | `hmr-qc-hemophilie-acquise`, `hmr-qc-coagulopathie`, `hmr-qc-complications`, `hmr-rv-acquise-anticoagulant` |
| `tableau-saignements.png` | 2-3 | `hmr-qc-topographie`, `hmr-qc-orientation`, `hmr-fa-topographie`, `hmr-qr-signes-primaire` |
| `tableau-formes-purpura.png` | 3-4 | `hmr-fa-purpura` |
| `tableau-plaquettaire-vasculaire.png` | 5 | `hmr-qc-origines`, `hmr-qc-pti`, `hmr-qc-rhumatoide`, `hmr-an-qr-mecanismes` |

Les photographies sont les figures du cours, en définition native (le PDF) ; les
tableaux sont rendus depuis la page.

**Un schéma cliquable**, `arbre-purpura.svg`, redessiné nu : onze boîtes, aucun mot
dessus, seule leur place dit ce qu'elles sont — le purpura, les deux urgences (fièvre,
thrombopénie), ce qu'elles font craindre et imposer, puis les deux origines et ce qui les
distingue. Ses notes de zone sont relues sur la ronéo 2026-27 (« antibiotique
immédiat » au lieu de « C3G en intraveineuse »), et deux libellés de zone aussi : la
fièvre n'est plus « le premier signe de gravité à chercher » mais « le signe de gravité qui
oriente vers une infection », la thrombopénie n'est plus « le second » mais « ce que la
numération plaquettaire cherche en urgence » — la ronéo liste cinq signes, en commençant
par l'extension rapide (p. 4).

**28 QCM sur 32 illustrés (88 %).** Sans figure : `hmr-qc-interrogatoire`,
`hmr-qc-questions`, `hmr-qc-hemophilie-severite`, `hmr-qc-conduite`, que rien ne dessine.

## L'échelle : Simple → Moyen → Annale (C20, relue le 19/10/2026)

L'échelle du pilote de l'immunité innée, étendue au tissu sanguin pour l'examen du 4/11.
Sous les annales, 12 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma
troué dans la question) et 2 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre,
le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son
schéma (`diagramme=`) ; la QROC reçoit le schéma nu.

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `purpura` | 12 | 2 | 2 |

**Le schéma** `ech-purpura`, « Devant un purpura · deux temps, dans l'ordre », donne 16
fichiers (complet, troués, à lettres), décrit dans `schemas.py` (`ECH_PURPURA`,
`TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Sa
légende cite désormais la ronéo 2026-27 (p. 3-5) et les Arbres décisionnels (p. 25).

**Relue le 19/10/2026 sur la ronéo 2026-27.** Les 14 marches citent la page de l'année
(`page=`, `SRC["fiche"]`). Ce qui a changé, dans le schéma et les cartes ensemble :

| Case du schéma | 2024-25 | 2026-27 | Marches |
|---|---|---|---|
| Premier réflexe | « chercher deux signes de gravité », « déshabiller, examiner tout le corps » | « chercher les signes de gravité », « déshabiller, examiner toute la peau » (p. 4) | — |
| Fièvre | « tout purpura qui en a est, jusqu'à preuve du contraire, un… » | « signe de gravité : le purpura fait alors suspecter un… » (p. 4) | s2, s3 (énoncés réécrits) |
| Purpura fulminans | « souvent une septicémie à » | « souvent une infection invasive à » (p. 4) | s4 (énoncé) |
| Risque | « intracrânien : examen neurologique » | « intracrânien : hospitaliser en urgence » (p. 4) | s9 |
| Traitement | « C3G en intraveineuse », « avant la ponction lombaire » | « antibiotique large spectre (C3G) en IV », « sans attendre la ponction lombaire » (p. 4) | s6, s7 |
| Purpura plaquettaire | « maculeux, sans volume », « localisation indifférente » | « plan, sans relief », « membres atteints indifféremment » (p. 5) | s5 A, s10 A, s12 A |
| Purpura vasculaire | « numération plaquettaire normale » | « plaquettes généralement normales » (p. 5) | m2 D |

La marche `hmr-ech-s8` A devient « une raideur de nuque » (au lieu de « raideur de nuque
et céphalées ») : la ronéo 2026-27 range les céphalées parmi les signes d'une
thrombopénie sévère (p. 4 ; Arbres décisionnels, p. 25). Les formes sont tenues : clés
Simple réparties A 4, B 4, C 4 ; Moyen à deux (m1) et trois (m2) vraies ; chaque marche
finit par « ↗ Prépare… ». Aucun trou n'est trahi par une autre case (relecture sceptique
du 19/10/2026) : la première réécriture mettait « avec extension rapide ou nécrose » dans
la case « Fièvre », ce qui donnait la réponse de s5 (« nécrotiques, rapidement
extensives »), et « examiner peau, extrémités, bouche » dans le « Premier réflexe », ce
qui désignait la bulle de s8 ; les deux cases ne nomment plus ni la nécrose, ni
l'extension, ni la bouche, ni la fièvre hors du titre, et n'ont pas de pronom qui
trahirait le genre de la réponse de s2.

## Le lexique

Cinq termes de l'UE Tissu sanguin, chacun avec son **origine grecque ou latine** ; pages
mesurées dans le texte de la ronéo 2026-27 (en-têtes exclus), puis des Arbres
décisionnels :

| Terme | Origine | Pages 2026-27 |
|---|---|---|
| Purpura | grec πορφύρα, par le latin purpura | p. 3, 4, 5, 7 ; Arbres p. 5, 25 |
| Gingivorragie | latin gingiva + grec -ρραγία | p. 2 |
| Thrombopathie | grec θρόμβος + πάθος | p. 5, 8, 9, 10 |
| Coagulopathie | latin coagulare + grec πάθος | p. 2, 3 |
| Vitropression | latin vitrum + pressio | p. 3 ; Arbres p. 5 |

Aucun n'existait dans un autre paquet. Les racines viennent de la table commune
(`-rr(h)agie`, `thromb(o)-`, `-pathie`, `coagulare (latin)`, `vitrum (latin)`) ; deux
racines nouvelles (`gingiva (latin)`, `pressio (latin)`) et les cinq termes sont proposés à
`etymologies.json` (brouillon `etym/sang_hemorragies.json`), que Claude fusionne ; les
textes du lexique sont déjà écrits dans la forme que `appliquer_etymologies.py`
produirait. `-rr(h)agie` et `-pathie` citent la FC de sémantique 2026-27 (1/2, p. 3, 5).
Ecchymose, épistaxis, hématome, hématurie, hématémèse, ménorragie et thrombopénie sont
déjà accueillis par d'autres chapitres et ne sont pas repris.

**Hémophilie et hémarthrose vont à `sang_exploration`**, réaligné le même jour, qui les
déclare sous les mêmes identifiants (`lex-hemophilie`, `lex-hemarthrose`) : ses annales
les emploient (cinq questions pour l'hémophilie, une pour l'hémarthrose, aucune ici) et
sa fiche, les Arbres décisionnels, les cite sur plus de pages. Elles ne sont donc pas
reprises ici : un même identifiant dans deux paquets ferait passer le terme d'un chapitre
à l'autre au gré des imports.

## Absent du cours 2026-27

**Aucune carte entière.** Chaque note a sa notion centrale dans la ronéo du 14/10/2026 ou
dans les Arbres décisionnels du même jour ; `ABSENTS_2026` est vide (et
`ORIGINE_ABSENTS` prêt). Ce que seuls les cours 2024-25 et 2025-26 portent est dit
proposition par proposition, par exemple : les deux pics d'incidence de l'hémophilie
acquise, l'enfant apyrétique de 9 à 18 mois, le plancher buccal, la reprise au bloc, le
contexte infectieux ou vaccinal du PTI, la raideur de nuque, la C3G en intraveineuse, la
présentation abdominale et le psoïtis de l'hématome du psoas, l'arthrose dès vingt ans.

## Sans illustration

Sans objet : 88 % des QCM sont illustrés.

## À relire

**Aucune carte `a-relire`** : chaque carte cite sa page de la ronéo 2026-27 ou des
Arbres décisionnels 2026-27.

## Questions pour Vincent

- **Les vibices** sont écrites en gris clair dans le tableau des formes (p. 4) ; la ronéo
  ne définit pas son gris, elles sont donc cartées (`hmr-fa-purpura`, c5). À retirer si le
  professeur les a écartées.
- **Les « deux signes de gravité »** de 2024-25 ne sont plus dans la ronéo, qui en liste
  cinq : `hmr-qc-gravite` B parle désormais des « deux urgences » (fièvre et thrombopénie
  sévère). À garder ainsi si le partiel pose encore la formule ancienne.
- **Le cas ouvert** de 2023/2024 QCM 3 B reste ouvert.
- **La partie II de la ronéo** (p. 7-12) est cartée par `sang_exploration`, qui la cite
  sous son propre identifiant ; l'erreur du type 2 de Willebrand (p. 9) n'y est portée par
  aucune carte.
- **Hémophilie et hémarthrose** sont laissées au lexique de `sang_exploration`, qui les
  déclarait aussi : un seul chapitre doit les accueillir.

## Régénérer

```
python generer.py
```

Le script écrit d'abord les SVG, puis valide : une justification manquante, un trou de
plus de deux mots, deux zones qui se recouvrent, une page hors de sa fiche, un conflit
déclaré mais non signalé — et il refuse d'écrire. `generer.py` et `echelle.py` sont les
copies exactes des modèles du skill.
