# Activation et différenciation des cellules B par l'antigène — paquet Immunologie

96 notes, 167 cartes. Chapitre `chap-ue-immunologie-fc6` de l'UE Immunologie
(identifiant du squelette). Cours du **Pr Dubucquoi, le 09/10/2026** (8 h-9 h),
« Ontogenèse des lymphocytes B et mise en place d'une réponse immunitaire anticorps
dépendante », la suite du cours de l'ontogenèse B du 02/10 : **ronéo Ronéo & Juliette
2026-27** (12 pages, la 11e porte le tableau des classes d'anticorps, la 12e est
blanche), déposé le 19/10/2026. La FC n°6 du Ronéosaure 2025-26 (même professeur,
13/10/2025), sur laquelle le chapitre était bâti, n'est plus qu'un appoint. Annales du
polycopié « IMMUNO n°8 » du Ronéosaure 2024-25 (17 questions sur 14 sessions) et du sujet
2024/2025 déposé le 15/10/2026 (1 question). Examen de novembre (mercredi 4 novembre 2026).

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| Texte à trous | 11 | 73 |
| QRM | 33 | 33 |
| QRU | 22 | 22 |
| QROC | 8 | 8 |
| Recto-verso | 12 | 12 |
| Schéma cliquable | 2 | 11 |
| Lexique | 8 | 8 |

Dont **18 annales** sur 15 sessions (2015/2016 S2 à 2024/2025 S1) : 11 QCM et 7 QROC
rangés en recto-verso ; **28 marches de l'échelle** (21 Simple, 7 Moyen) ; les notes du
cours : 16 QCM (15 QRM, 1 QRU), 11 textes à trous, 8 QROC, 5 recto-verso, 2 schémas.
**55 QCM sur 55 illustrés** (100 %), 85 notes sur 96. **4 cartes portent un piège du
ronéo** (thème « Pièges des ronéos ») ; **une carte est absente du cours 2026-27**
(`alb-qr-plasmoblastes`).

Huit thèmes (les 88 notes hors lexique), tous déjà dans `THEME_LABELS` (`app/src/med_engine/application/scopes.py`) :

| Clé | Libellé | Notes |
|---|---|---|
| `ontogenese-lb` | Production et sortie de moelle des LB | 12 |
| `baff-april` | BAFF, APRIL et survie des LB | 9 |
| `aide-cognate` | Rencontre de l'antigène et aide cognate | 22 |
| `centre-germinatif` | Le centre germinatif | 20 |
| `maturation-affinite` | Hypermutation somatique et commutation isotypique | 10 |
| `chronologie-reponse` | Chronologie de la réponse immunitaire (celui d'`immuno_temporelle`) | 13 |
| `fonctions-isotypes` | Fonctions des classes d'anticorps (celui d'`immuno_anticorps`) | 1 |
| `ac-en-pratique` | Anticorps en pratique : thérapeutique et sérologie (celui d'`immuno_anticorps`) | 1 |

Les deux derniers sont nouveaux dans ce chapitre, pour ses deux cartes nouvelles des p. 10-11 ;
leurs libellés existent déjà : aucun libellé à ajouter.

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-immuno-activation-b` — Ronéo & Juliette, « Ontogenèse des lymphocytes B et mise en place d'une réponse immunitaire anticorps dépendante » (12 p.), `IMMUNOLOGIE/ONTOGENÈSE DES LYMPHOCYTE B 2.pdf` | **2026-27** | **la base** : la fiche que le lecteur ouvre (`chapitre=`, `SRC["fiche"]`) ; 69 notes de cours sur 70 portent sa page, les 18 annales la citent en source secondaire, les 8 termes du lexique y ont leurs premières pages. À copier dans le dossier des PDF de l'application par `outils/copier_les_cours.py`, hors du bac à sable. **Cet identifiant était, jusqu'au 19/10, celui de la FC n°6 2025-26** : comme pour `immuno_ontogenese_b`, la fiche du chapitre garde son identifiant, et c'est l'ancienne fiche qui en reçoit un nouveau |
| `src-cours-immuno-activation-b` — Ronéosaure, « FC n°6 -Activation et différenciation des cellules B par l_Ag » (8 p.) | 2025-26 | **appoint**, sans `chapitre=` : les diapositives que le ronéo 2026-27 ne reproduit pas, la carte absente, les pages de 2025-26 du lexique (après celles de 2026-27) |
| `src-annales-immuno-activation-b` — Ronéosaure, « IMMUNO n°8 » (13 p.) | 2024-25 | les 17 questions et la table de corrections (p. 9-13). Déclarée aussi par `immuno_ontogenese_b` et `immuno_anticorps` : la déclaration est la même, mot pour mot |
| `src-sujets-immuno-2425` — sujet de système immunitaire 2024/2025, session 1 (3 p.) | 2024-25 | la Q8 (`SRC["sessions"]["2024/2025 S1"]`) ; sujet sans corrigé ; déclaré à l'identique dans chaque chapitre d'immunologie qui en a une question |
| grille officielle des QCM 2023/2024 (02/11/2023) | 2023-24 | confirme la clé de la Q7 de cette session ; citée, pas déclarée |
| FC n°8 (AC) 2024-25 « Ontogenèse des LB », même professeur ; FC n°8 2025-26 « La réponse immunitaire T » et FC n°6 (AC) 2024-25 (Pr Labalette) ; FC n°7 et FC n°10 2025-26 | 2024-25, 2025-26 | cités dans le texte seulement (division « toutes les 4h » ; CD80/86–CD28 et CD40–CD40L ; voies du complément ; toxoplasmose) |
| Tableau des erreurs d'immunologie 2026-27 | 2026-27 | quatre entrées au 19/10 (CMH, organes, cellules dendritiques) : **aucune sur ce cours** |

Le ronéo 2026-27 n'a ni rouge ni gris ; deux consignes du professeur : les étapes de
différenciation « à ne pas toutes retenir » (p. 4), les fonctions des classes « à
connaître » (p. 10).

Vérifications hors du cours, citées dans la carte qui s'en sert : Mackay & Schneider,
Nat Rev Immunol 2009 (cellules productrices et récepteurs de BAFF et d'APRIL) ; Lesley et
al., Immunity 2004 (PubMed 15084273), et Thien et al., Immunity 2004 (les LB autoréactifs
dépendent davantage de BAFF, que son excès laisse survivre) ; Randolph, Angeli & Swartz,
Nat Rev Immunol 2005 (la cellule dendritique gagne le ganglion par la lymphe) ;
Robert-Gangneux & Dardé, Clin Microbiol Rev 2012 (IgA anti-toxoplasme dès la première
semaine, jusqu'à 9 mois) ; Crotty, Immunity 2014 ; Odegard & Schatz, Nat Rev Immunol
2006 ; Janeway's Immunobiology ; Seita & Weissman, WIREs Syst Biol Med 2010.

## Le ronéo 2026-27 remplace le Ronéosaure 2025-26 (19/10/2026)

Les pages du ronéo et ce qu'elles font du chapitre :

| Pages 2026-27 | Contenu | Pages 2025-26 | Cartes |
|---|---|---|---|
| 2-3 | rappels de la première partie : Ig, RAG, TdT, sélection, révision du paratope | 2 (copier-coller 2024-25, gris) | au chapitre `immuno_ontogenese_b` |
| 3-5 | de la moelle aux organes lymphoïdes secondaires ; origine, étapes, sous-populations | 3-4 | `ontogenese-lb` |
| 6 | BAFF et APRIL ; les deux voies | 4-5 | `baff-april`, `aide-cognate` |
| 6-9 | macrophage du sinus sous-capsulaire, aide cognate, licence, deux voies de différenciation, centre germinatif, hypermutation, commutation, chronologie | 5-8 | `aide-cognate`, `centre-germinatif`, `maturation-affinite`, `chronologie-reponse` |
| 9-10 | réponses primaire et secondaire, protocole vaccinal ; biologie médicale | 8 | `chronologie-reponse`, `ac-en-pratique` |
| 10-11 | fonctions des classes, « à connaître », et leur tableau | 8 (tableau « à lire ») | `fonctions-isotypes` |

**Chaque note a été relue contre lui** : 69 notes de cours sur 70 citent sa page, et
perdent le badge « Cours 2025-26 » ; 35 ont changé de contenu (propositions, texte,
verso), les 58 autres de justifications et de pages. Ce que le ronéo 2026-27 dit
autrement :

- **La rencontre de l'antigène.** Le macrophage du sinus sous-capsulaire réintroduit les
  antigènes au follicule primaire et les expose ; le LB les arrache de sa membrane et
  les internalise (p. 6-7). La cellule dendritique folliculaire n'est plus nommée qu'au
  centre germinatif, où elle **assure la sélection** des LB les plus affins, le LTfh
  vérifiant qu'on lutte toujours contre le même pathogène (p. 8-9). Réécrits :
  `alb-fa-deux-voies`, `alb-qc-deux-voies` D, `alb-qr-msc`, `alb-qr-cdf` (la question
  porte désormais sur la sélection), `alb-qc-zones-cg` D-E, `alb-fa-zones-cg`,
  `alb-rv-zones-cg`, et le schéma (zones du cortex, case « Voie de la lymphe » de
  l'échelle).
- **Des chiffres.** La survie par BAFF et APRIL « jusqu'à deux mois » (« quelques jours à
  quelques semaines » en 2025-26 : `alb-fa-baff`, `alb-qc-baff-april` A, `alb-ech-s4` A
  et sa case) ; la zone sombre de 10 LB à 100 000 en quinze jours (une division « toutes
  les 3 à 6 h » en 2025-26 : `alb-fa-zones-cg`, `alb-qc-zones-cg` A, la case « Zone
  sombre ») ; J7 et J21 (« 5 à 7 j », « J14 à J21 » : `alb-fa-chronologie`,
  `alb-qc-chronologie`) ; le rappel vaccinal à 4 semaines (`alb-qc-primaire-secondaire`).
- **Du nouveau, carté** : les étapes pro-B, pré-B, transitionnelle (`alb-fa-stades`) ;
  les lipides et les acides nucléiques parmi les antigènes thymo-indépendants
  (`alb-fa-populations`, `alb-rv-ti-td`) ; les cellules qui produisent BAFF et APRIL, et
  leur intérêt dans les maladies auto-immunes (`alb-qc-baff-april` B et E) ; la licence,
  les LB étrangers chassés du follicule (`alb-fa-devenir`) ; les plasmablastes
  circulants et la niche des plasmocytes, « plusieurs mois, voire plusieurs années »
  (`alb-fa-sorties-cg`, `alb-qc-selection` C) ; les LB mutés vers le soi qui meurent
  (`alb-qc-selection` D, la case « Après le tri ») ; « sans LT, pas de réponse
  secondaire » (`alb-rv-sans-cd4`) ; la biologie médicale (`alb-qc-serologie`) ; les
  fonctions des classes (`alb-qc-classes`).
- **Ce qu'il ne dit plus**, gardé avec la mention dans la justification : la lymphopénie
  qui laisse survivre des LB autoréactifs (`alb-ech-m2` D, « Vrai, mais absent du cours
  2026-27 ») ; le nouveau tour en zone sombre, « cognate = cognitif », « anamnestique »,
  les récepteurs BAFF-R, BCMA, TACI (dits « FC n°6 2025-26 » dans les explications).
- **Trois marches ont changé avec le cours, et le schéma avec elles** : `alb-ech-s4`
  (« de quelques jours à deux mois »), `alb-ech-s11` (la voie extra-folliculaire :
  « un renfort rapide, en première ligne », au lieu des plasmoblastes ; son trou passe à
  la dernière ligne de la case), `alb-ech-m5` B (« le LTfh vérifie que les LB luttent
  toujours contre le même pathogène », au lieu de la « licence » de zone claire). Les
  cases « Voie de la lymphe », « Zone sombre », « Zone claire », « Après le tri » et la
  légende du schéma suivent le cours de l'année ; clés Simple toujours réparties 7-7-7.
- **Les « erreurs » du Ronéosaure 2025-26** (« totipotentes », « un autre isotope »,
  « des Ig1, Ig2 ») ne sont plus dans le ronéo 2026-27 : leurs ATTENTION sans genre sont
  retirés, une phrase de la justification les rappelle. La cellule dendritique « par la
  voie sanguine ou lymphatique » y revient : c'est désormais une erreur du ronéo de
  l'année, avec son genre.

**Trois cartes nouvelles**, toutes illustrées : `alb-fa-stades` (p. 4-5, figure p. 5),
`alb-qc-classes` (p. 10-11, tableau p. 11), `alb-qc-serologie` (p. 10).

## Ce que les annales ont dicté

| Savoir | Questions |
|---|---|
| L'aide cognate : définition, couples moléculaires, conséquences | 2022/2023 S1 QROC 4, 2020/2021 S1 QROC 5, 2019/2020 S2 Q4, 2018/2019 S2 Q8, 2017/2018 S1 Q8, 2016/2017 S2 Q2, 2015/2016 S2 QROC 3 |
| Le centre germinatif, l'hypermutation, les IgG hyper-affines | 2023/2024 S1 Q7, 2022/2023 S1 Q8, 2021/2022 S1 Q9, 2019/2020 S1 QROC 3, 2017/2018 S2 QROC 4 |
| BAFF, APRIL et la sortie de moelle | 2024/2025 S1 8., 2022/2023 S2 8., 2020/2021 S2 Q8, 2018/2019 S1 QROC 4 |
| Réponses primaire et secondaire | 2018/2019 S1 Q10, 2019/2020 S2 QROC 3 |

**Le 19/10/2026, chaque clé a été relue contre le ronéo 2026-27 : aucune n'est
contredite.** Chaque annale porte la page où se lit sa réponse (source secondaire). Les
trois QROC sans corrigé ont une réponse réécrite sur le cours de l'année. Deux
propositions se corrigent désormais sur lui, et non plus sur la littérature ou une
diapositive : 2020/2021 S2 Q8 A (la superfamille du TNF, p. 6) et B (les cellules
productrices, dendritiques et mésenchymateuses, p. 6).

Le polycopié IMMUNO n°8 mêle d'autres cours : la structure du BCR et l'ontogenèse B
(rangées dans `immuno_ontogenese_b`), les fonctions des anticorps (FC n°10),
l'immunité antibactérienne (FC n°11). 2019/2020 S1 Q9 et 2017/2018 S1 Q9 sont déjà dans
`immuno_temporelle` : non recopiées.

## Les clés qui ne sont pas reprises telles quelles

Aucune clé imprimée n'est contestée : les dix clés de QCM du polycopié sont reprises,
`officielle` ; `CONFLITS` est vide.

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2024/2025 S1 8. (`alb-an-2425s1-q8`) | aucune (sujet sans corrigé) | **CE**, déduite, `officielle` faux | cellule souche lymphoïde, pas myéloïde (p. 4) ; IgM et IgD sur les LB immatures, pas des IgG (figure p. 5) ; BAFF et APRIL (p. 6) ; antigène exposé par le macrophage du sinus sous-capsulaire, pas seulement soluble (p. 6-7) ; macrophage et CDF facilitent l'activation (p. 6-9) |
| 2019/2020 S1 QROC 3, 2019/2020 S2 QROC 3, 2017/2018 S2 QROC 4 | « voir cours », « pas de correction » | clé déduite du ronéo 2026-27 (p. 4, 6-10) | `officielle` faux |
| 2022/2023 S1 QROC 4 | corrigé | repris | le corrigé dit l'antigène « phagocyté » ; le cours dit que le LB l'arrache de la membrane du macrophage et l'internalise (p. 7) |
| 2015/2016 S2 QROC 3 | corrigé | repris | le corrigé fait sélectionner les LB par le LTfh ; le cours de l'année confie la sélection à la CDF, le LTfh vérifiant le pathogène (p. 8-9) : dit dans l'explication |

Cas ouvert : aucun.

## Les erreurs du ronéo 2026-27

Le tableau des erreurs de la promo ne cite pas ce cours au 19/10 : toutes ont été
trouvées en relisant, et sont à porter dans `contenu/ERRATA_RONEOS_2026-27.md`. Le
ronéo n'est pas corrigé ; chaque erreur est portée par la carte où la notion se joue,
avec son genre, et la carte retient la bonne lecture.

**Prises de notes fausses** (`ATTENTION (prise de notes)`) :

| Page | Le ronéo dit | Ce qui est juste | Carte |
|---|---|---|---|
| 6 | « C'est donc BAFF et APRIL qui atténuent son auto-réactivité » | ce sont des facteurs de survie : le LB autoréactif en consomme beaucoup et, en concentration limitée, meurt ; l'autoréactivité s'atténue par la révision du paratope. La même page le dit ; la FC n°6 2025-26 : « gros besoins en BAFF et APRIL pour qu'il survive le temps de ses cycles d'atténuation » (p. 4) ; Lesley et al., Thien et al., Immunity 2004 | `alb-qc-baff-april` (D) |
| 6 | la cellule dendritique quitte le tissu « pour aller dans la circulation sanguine et lymphatique » | elle gagne le ganglion de drainage par la lymphe afférente ; le sang n'apporte aux tissus que ses précurseurs (diapositive du même professeur, cours des cellules dendritiques ; Randolph et al., Nat Rev Immunol 2005) — déjà « sanguine ou lymphatique » en 2025-26 | `alb-qc-deux-voies` (A) |
| 10 | toxoplasmose : « Si ce sont des IgA ou des IgG, c'est une infection ancienne probablement antérieure à la conception » | les IgA anti-toxoplasme apparaissent dès la première semaine, avec les IgM, et persistent jusqu'à environ 9 mois : elles ne datent pas l'infection, et ne signent pas une infection ancienne. Le cours 2025-26 (FC n°10, Dr Collet, p. 9) ne date l'infection que par les IgM et les IgG ; les cours 2024-25 et 2025-26 du Pr Dubucquoi n'avaient pas cet exemple (Robert-Gangneux et Dardé, Clin Microbiol Rev 2012) | `alb-qc-serologie` (D) |
| 5 | « un réarrangement du gène V, puis DJ au niveau de la chaîne légère » | chaîne LOURDE : D-J puis V-DJ ; chaîne légère : V-J, sans D (cours du 02/10, p. 14-15 ; le même ronéo p. 2) | `olb-qc-rag` (B), au chapitre de l'ontogenèse |
| 3 | la diversité N « apportée par la termino terminale, mais aussi la TDT (transférase) » | une seule enzyme, la terminal désoxynucléotidyl transférase (cours du 02/10, p. 16) | `olb-qr-tdt`, au chapitre de l'ontogenèse |
| 2 | « fragment cristallisable (IgG) » | le Fc, comme le dit la figure de la même page | `olb-qc-fab-fc` (E), au chapitre de l'ontogenèse |

**C'est le cours lui-même** : la figure de rappel p. 2 développe Fab en « Fragment
« Antibody » », comme la première partie (déjà dans la liste, `olb-qc-fab-fc` B, qui le
mentionne désormais).

**Point douteux** (`ATTENTION (douteux)`) :

| Page | Le point | Carte |
|---|---|---|
| 5 | les LB presque matures « n'expriment qu'une seule IgM à la membrane », à côté d'une figure qui leur donne IgM et IgD (et du tableau p. 11 : « (IgD) expression sur les LB naïfs ») ; la phrase peut aussi vouloir dire un seul BCR, une seule spécificité. À l'examen, la figure | `alb-ech-s2` (C) |

**Coquilles sans carte** : « commutations isotopiques » (p. 8, juste p. 9) ; « activation
induced citidine Desaminase » (p. 9) ; « IgC » pour IgG (p. 9) ; « commutation de place »,
sans doute pour commutation de classe (p. 9) ; la mère qui « produisait
des gènes » pour des IgM (p. 9) ; l'antigène « auquel ils exprimeraient un antigène
utile » (p. 5) ; « aire cognate » dans le plan (p. 2).

**Pas une erreur** : les trois délais des IgM — 4-5 jours sur la courbe vaccinale (p. 9),
J7 dans la chronologie (p. 9), 7 à 15 jours pour les détecter en biologie (p. 10) — ne
mesurent pas la même chose ; les cartes les citent chacun à sa place.

## Absent du cours 2026-27

**Une carte entière** : `alb-qr-plasmoblastes` (« en quelles cellules à vie courte se
différencient les LB de la voie extra-folliculaire ? — en plasmoblastes »). Le ronéo
2026-27 parle de « cellules productrices d'anticorps » et réserve le mot de
plasmablastes aux précurseurs circulants des plasmocytes (p. 8). Elle est dans
`ABSENTS_2026` (`ORIGINE_ABSENTS` : le cours du Pr Dubucquoi de 2025-26, FC n°6) et cite
la FC n°6 2025-26 à sa page 6 (`page=6, fiche=FC2526`, comme les cartes absentes de
`bmcp_ed_electrophorese`) ; le générateur écrit « Absent du cours 2026-27 » en tête de son
explication.

Une proposition isolée le dit dans sa justification : `alb-ech-m2` D (la lymphopénie).

## Les schémas cliquables

| Fichier | Ce qu'on clique | Cartes |
|---|---|---|
| `cortex-ganglion-nu.svg` (`alb-zo-cortex`) | une coupe du cortex d'un ganglion, la capsule en haut : le sinus sous-capsulaire, le follicule primaire, la zone sombre et la zone claire du centre germinatif, la zone intermédiaire (LTfh) | 5 |
| `anticorps-primaire-secondaire-nu.svg` (`alb-zo-anticorps`) | les courbes des anticorps : IgM et IgG primaires, délai primaire, délai secondaire, pic d'IgG secondaire, persistance | 6 |

Dessins inchangés ; les phrases des zones citent désormais les pages de 2026-27 (la
zone claire : la CDF sélectionne, le LTfh vérifie ; la zone sombre : de 10 à 100 000
LB). La persistance « 1 an à plusieurs années » reste celle de la diapositive de 2025-26.
Les zones du ganglion entier sont dans `immuno_organes` (`lym-zo-ganglion`).

**Pas de planche à légender** tirée de la coupe de ganglion du ronéo 2026-27 (p. 8) :
quatre de ses sept légendes (capsule, trabécule, hile, corde médullaire) sont grisées
sur la diapositive, le hile y est posé au milieu de la coupe, et l'anatomie du ganglion
est déjà cliquable dans `immuno_organes`. La coupe illustre la correction de trois
cartes.

## Les figures

**Trois figures du ronéo 2026-27** (extraites du PDF, 256 couleurs) :

| Fichier | Page | Ce qu'elle montre | Cartes |
|---|---|---|---|
| `alb-stades-lb.png` | 5 | cellule souche hématopoïétique, cellule pluripotente, précurseur lymphoïde, pré-pro-LB, pro-LB, pré-LB, LB immatures (IgM, IgD) | `alb-fa-sortie`, `alb-fa-stades`, `alb-qc-production`, `alb-qr-transitionnel` |
| `alb-coupe-ganglion.png` | 8 | follicule primaire petit et sombre, centre germinatif clair, paracortex, corde médullaire | `alb-fa-devenir`, `alb-qc-devenir` |
| `classes-anticorps.png` | 11 | le tableau des classes, « à connaître » | `alb-qc-classes`, 2 annales (2022/2023 S1 Q8, 2018/2019 S1 Q10) |

Le tableau des classes **remplace** le fichier du même nom : c'est la même diapositive
qu'en 2025-26 (p. 8), deux fois plus nette (2 500 px, réduite à 1 400). La figure de
rappel p. 2 (structure de l'immunoglobuline) n'est pas reprise : elle est au chapitre
de l'ontogenèse.

**Les huit diapositives de la FC n°6 2025-26** restent en correction : le ronéo 2026-27
ne les reproduit pas, et leur légende cite la page de 2025-26 et celle du texte de 2026-27
(`production-lb-moelle.png`, désormais sans carte, `test-bcr-deux-populations.png`,
`baff-april.png`, `deux-voies-ganglion.png`, `aide-cognate.png`, `centre-germinatif.png`,
`chronologie-reponse-b.png`, `reponses-primaire-secondaire.png`). Deux disent ce que
2026-27 ne dit plus : la CDF du follicule primaire (`deux-voies-ganglion.png`) et les
récepteurs de BAFF et d'APRIL (`baff-april.png`) ; les cartes le précisent.

## Le lexique

Huit termes, pages mesurées dans le texte du ronéo 2026-27 (règle de
`chercher_pages.py` ; le plan, p. 2, n'est pas compté), en tête, puis celles de la FC
n°6 2025-26 :

| Terme | Origine | Pages 2026-27 | Pages 2025-26 |
|---|---|---|---|
| Hypermutation somatique | grec hyper- + latin mutatio + grec sômatikos | 8, 9, 10 | 6, 7 |
| Commutation isotypique | latin commutatio + grec isos + typos | 9, 10 (« isotopiques » p. 8) | 7 |
| Aide cognate | latin cognatus, « apparenté » (par l'anglais) | 7, 10 | 1, 5, 6, 8 |
| Centre germinatif | latin germinare ; l'allemand Keimzentrum de Flemming (1885) | 7, 8, 9 | 1, 6 |
| Follicule lymphoïde | latin folliculus + lympha + grec eidos | 6, 8 | 5, 6 |
| Thymo-dépendant | thymus + latin dependere | 5 | 1, 4 |
| Transitionnel | latin transitio, de transire | 5 (« transitionnelle ») | 3 |
| Lymphopénie | latin lympha + grec penia | 6 | 4 |

Aucun terme nouveau, aucune étymologie nouvelle ; les définitions suivent le cours de
l'année (la glose « cognitif » et la lymphopénie qui laisse survivre des LB
autoréactifs y sont dites « du cours 2025-26 »), et leurs phrases d'étymologie sont
inchangées, au format exact d'`appliquer_etymologies.py`.

## À relire

**0 carte `a-relire`** : chaque note de cours cite sa page du ronéo 2026-27, la carte
absente celle de la FC n°6 2025-26, chaque annale sa session, son numéro et sa clé.
Reste à faire :

- porter les erreurs ci-dessus dans `contenu/ERRATA_RONEOS_2026-27.md` (ronéo
  « Ontogenèse des lymphocytes B et mise en place d'une réponse immunitaire anticorps
  dépendante — Pr Dubucquoi, 09/10 ») ;
- copier la fiche 2026-27 dans le dossier des PDF de l'application
  (`outils/copier_les_cours.py`, hors du bac à sable).

## L'échelle : Simple → Moyen → Annale (C20, 16/10/2026)

Le pilote de l'immunité innée, étendu au reste de l'immunologie pour l'examen du 4/11 (choix de Vincent, 15/10). Sous les annales, 21 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 7 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`) ; les QROC reçoivent le schéma nu. **Relues le 19/10/2026 sur le ronéo 2026-27** : chaque marche cite ses pages ; `alb-ech-s4`, `alb-ech-s11` et `alb-ech-m5` B ont changé avec le cours, et le schéma avec elles (ci-dessus).

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `ontogenese-lb` | 2 | 1 | 2 |
| `baff-april` | 3 | 1 | 2 |
| `aide-cognate` | 4 | 2 | 7 |
| `centre-germinatif` | 5 | 1 | 4 |
| `maturation-affinite` | 3 | 1 | 1 |
| `chronologie-reponse` | 4 | 1 | 2 |

**Le schéma** `ech-activation-b`, « La réponse B · de la moelle au plasmocyte », donne 40 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_ACTIVATION_B`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu les dix chapitres ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Un point douteux, dit dans la carte** : `alb-ech-s2` C porte un ATTENTION (douteux) — le texte p. 5 donne aux LB presque matures « une seule IgM », la figure de la même page IgM et IgD ; le cours du 02/10 dit IgM puis IgD, « jamais en même temps ».

**Sans marche** :
- alb-an-1819s2-q8 E : l'IL-4 du LTfh et son récepteur sur le LB, absents des cours (sa justification s'appuie sur la littérature, Crotty 2014) : rien du cours pour bâtir une marche.
- alb-an-2021s2-q8 B : les cellules qui produisent BAFF et APRIL — le ronéo 2026-27 en nomme désormais (dendritiques, mésenchymateuses, p. 6), et `alb-qc-baff-april` B les teste ; pas de marche Simple, la case BAFF n'a pas de ligne pour elles.

## Questions pour Vincent

- (19/10) L'identifiant `src-fc-immuno-activation-b` passe de la FC n°6 2025-26 au ronéo 2026-27, comme pour l'ontogenèse le 11/10 : à l'import, la fiche du chapitre change de PDF chez toi et chez les collègues. Ça te va ?
- (19/10) La figure p. 5 dit « Pluripotent cell » entre la cellule souche hématopoïétique et le précurseur lymphoïde ; la diapositive de 2025-26 disait « cellule souche multipotente ». Les cartes ne cotent ni l'un ni l'autre mot. Si tu as le diaporama, quelle étiquette le professeur emploie-t-il ?
- (19/10) Les IgA « d'infection ancienne » (p. 10) sont rangées en prise de notes, parce que le cours 2025-26 ne date l'infection que par les IgM et les IgG ; si tu as entendu le professeur les citer, c'est une erreur du cours lui-même, et la carte devrait dire « À l'examen ».
