# Information médicale et financement des établissements de santé — paquet Informatique médicale

101 notes, 156 cartes. Chapitre `chap-ue-info-medicale-fc4` de l'UE
Informatique médicale, quatrième de l'UE. Cours du **Pr Chazard, le
12/11/2025, de 10 h à 11 h**, dans le **Ronéosaure 2025-26** (FC n°4, 16
pages) ; les annales du polycopié du Ronéosaure 2024-25 (11 sessions, 41 QCM).
Examen : partiel du mercredi 16 décembre 2026.

**Fiche provisoire** (décision de Vincent du 02/10) : le cours de l'année
2026-27 n'est pas encore paru. Chaque carte de cours cite la FC 2025-26 à sa
page et porte le badge « Cours 2025-26 » ; le ronéo 2026-27 la corrigera quand
il sortira. `donnees.py` porte `ANNEE_COURS = "2025-26"`.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 60 | 60 |
| Texte à trous | 13 | 65 |
| QROC | 10 | 10 |
| Recto-verso | 7 | 7 |
| Lexique | 8 | 8 |
| Planche à légender | 2 | 2 |
| Schéma cliquable | 1 | 4 |

Dont **41 annales** (QCM) sur 11 sessions, de 2018/2019 S1 à 2023/2024 S2, et
19 QCM du cours.

Huit thèmes, dans l'ordre du cours. Les huit clés sont nouvelles ; leurs
libellés restent à ajouter à `THEME_LABELS`
(`app/src/med_engine/application/scopes.py`). `interoperabilite` est partagée
avec la FC n°1, au même libellé. Aucune clé ni aucun libellé ne porte de
chiffre : la clé du plan, `t2a-groupage`, en avait un (un tag à chiffre n'est
pas un thème) ; elle est devenue `groupage-tarifs`, et « T2A » s'écrit en
toutes lettres dans les libellés. La clé `informatisation` du plan est devenue
`informatisation-dossier` : un mot seul qu'un autre chapitre voudrait aussi (la
FC n°1 parle de l'informatisation du système de santé et des cabinets) ne doit
pas porter un libellé propre au dossier médical.

| Clé | Libellé | Notes |
|---|---|---|
| `dossier-medical` | Le dossier médical : définition, contenu, organisation | 13 |
| `informatisation-dossier` | Informatiser le dossier : enjeux et contenus | 3 |
| `interoperabilite` | Interopérabilité et terminologies | 7 |
| `circuit-medicament` | Circuit du médicament et dénominations | 6 |
| `champs-hospitalisation` | Champs d'hospitalisation, soins externes, structure | 22 |
| `financement-historique` | Prix de journée, budget global, tarification à l'activité | 7 |
| `pmsi-recueil` | PMSI : RUM, RSS, RSA | 22 |
| `groupage-tarifs` | Tarification à l'activité : groupage, GHM, CMA, durée | 13 |

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-info-financement-2526` — Ronéosaure, « FC n°4 Information médicale et financement des établissements de santé » (16 p.) | 2025-26 | le cours ; `SRC["fiche"]`, ses 19 diapositives extraites |
| `src-annales-fc-n4-information-medicale-et-financement-des-etablissements-de-sante` — « FC n°4 - Information médicale et financement des établissements de santé » (15 p.) | 2024-25 | 11 sessions, 41 QCM, table p. 15 |

La fiche se range sous `INFORMATIQUE MÉDICALE/` du dossier des PDF de
l'application ; elle y arrive par `copier_les_cours.py` lancé sur
`…/examen décembre`, hors du bac à sable. L'annale est déclarée avec les seuls
champs convenus (id tiré du nom du fichier, titre, chemin, auteur), pour qu'un
autre chapitre la déclare à l'identique.

Lus en appoint, sans être déclarés, et cités dans le texte des cartes : le
cours 2024-25 du même professeur (23 p.) et celui de 2023-24 (Charonéo), pour
comprendre une annale ; l'errata des cours 2025-26 et celui des annales 2024-25
(tous deux vides) ; l'errata des cours 2023-24, dont les deux entrées sur ce
cours (« exclut les séjours », « seul un séjour achevé peut être codé ») sont
déjà justes en 2025-26. Le droit est cité quand une annale le demande : code de
la santé publique, art. R. 1112-2 (contenu du dossier), R. 6316-4 (télésanté),
L. 1111-2 (preuve de l'information), L. 5126-1 (pharmacie à usage intérieur).

Les en-têtes des ronéos, des erratas et du polycopié portent des noms
d'étudiants : aucun n'est repris.

## Ce que le cours a dicté

Le ronéo a peu de rouge (« important » sur les CMA, p. 14) et son gris marque
surtout les titres ; il se carte comme le reste. Les consignes du professeur
ont choisi les cartes :

- **à connaître** — l'interopérabilité et ses trois niveaux (p. 4 :
  `fin-fa-interop-niveaux`, `fin-qc-interop-exemples`) ; le circuit du
  médicament, « à connaître pour l'examen » (p. 6 : `fin-fa-circuit`,
  `fin-qc-circuit`, `fin-rv-dispensation`, la planche `fin-pl-circuit`) ; le
  sigle PMSI et les cinq champs (p. 7 : `fin-qr-pmsi`, `fin-fa-champs`,
  `fin-qc-champs`) ; le transfert, la mutation, le RUM et le RSS, « qui
  reviennent dans les QCM » (p. 11 : `fin-rv-transfert-mutation`,
  `fin-fa-sejour`, la planche `fin-pl-sejour`) ; la CIM-10 et le nom de la CCAM
  (p. 12-13 : `fin-qr-cim`, `fin-qr-ccam`) ; les CMA (p. 14 : `fin-fa-cma`,
  `fin-qr-cma`) ; les informations indirectement nominatives, « IMPORTANT »
  (p. 16 : `fin-qc-nominatif`, `fin-qr-nominatif`) ;
- **à ne pas apprendre, aucune carte** — les normes de l'interopérabilité
  syntaxique (p. 4), le tableau du recueil par champ (p. 10, sa diapositive
  n'est pas extraite), les exemples de codage MCO (p. 13) ;
- « faire les annales, les notions reviennent d'une année à l'autre » (p. 2) :
  les 41 sont cartées.

**Ce qui n'est pas carté ici**, parce qu'un autre chapitre le tient (plan C15) :
le cadre national de l'ANS et la chaîne de production de l'information (FC n°1),
le PMSI réutilisé, le SNDS et le chaînage anonyme (FC n°3), la protection des
données (FC n°6), le DMP (FC n°1) et la télésanté (FC n°7). Les cartes les
citent ; les annales qui y touchent (le DMP, la télésanté dans le dossier) sont
justifiées à la page de ces FC.

## Ce que les annales ont dicté

Cinq questions font presque tout le polycopié, reposées mot pour mot d'une
session à l'autre : une carte par session, l'explication renvoie aux autres.

| Savoir | Questions |
|---|---|
| Le dossier médical : code de la santé publique, papier ou numérique, notes des étudiants, télésanté, DMP | 2023/2024 S1 Q3 et S2 Q5, 2022/2023 S2 Q1, 2021/2022 S1 Q3 et S2 Q1 ; voisines : 2019/2020 S1 Q8, 2018/2019 S1 Q2 |
| Le PMSI : sigle, date, RUM, RSS | 2023/2024 S2 Q3, 2022/2023 S1 Q3 et S2 Q9, 2021/2022 S1 Q12 et S2 Q9, 2020/2021 S1 Q3 et S2 Q8, 2019/2020 S2 Q3 |
| L'hospitalisation : mutation, urgences, HAD, hôpital de jour ou réanimation, SSR | 2023/2024 S1 Q5, 2022/2023 S1 Q4 et S2 Q11, 2021/2022 S1 Q14 et S2 Q11, 2020/2021 S1 Q4 et S2 Q9, 2019/2020 S2 Q4 |
| Les établissements : cinq champs, T2A du privé, PMSI et T2A, informatisation ou pôles | 2023/2024 S1 Q4, 2022/2023 S1 Q5 et S2 Q12, 2021/2022 S1 Q15 et S2 Q12, 2020/2021 S1 Q5 et S2 Q10, 2019/2020 S2 Q5 |
| La T2A : sigle, date, CCAM, CMA, forfait, borne haute, EXH | 2022/2023 S2 Q10, 2021/2022 S1 Q13 et S2 Q10 ; 2019/2020 S1 Q11, 2019/2020 S2 Q2, 2018/2019 S1 Q5 |
| Les fichiers et le financement : un RUM par unité, un RSS par séjour, RSA, forfait, budget global | 2019/2020 S1 Q10, 2018/2019 S1 Q4 |
| LOINC, la biologie, la redondance, les « ASSCM » | 2019/2020 S1 Q9, 2018/2019 S1 Q3 |

**Deux anomalies de la table, sans effet sur les clés** : la table imprime deux
fois l'en-tête « 2023-2024 S1 » — la seconde colonne est la session 2, celle des
énoncés « 2023-2024 session 2 » ; et la session 2021-2022 S2 est la copie
exacte de 2022-2023 S2 (mêmes numéros, mêmes énoncés, mêmes clés). Les cartes
le disent.

## Les clés qui ne sont pas reprises telles quelles

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2023/2024 S1, QCM n° 3 (dossier médical), proposition D « Le dossier de télésanté ne fait pas partie du dossier médical » | ABDE | **ABE**, `officielle=False`, `CONFLITS`, ATTENTION sur D | la même proposition est donnée fausse dans les quatre autres sessions qui la posent (2023/2024 S2 Q5, 2022/2023 S2 Q1, 2021/2022 S1 Q3 et S2 Q1 : ABE) ; le droit la dément — le compte rendu de l'acte de télésanté, les prescriptions, l'identité des professionnels, la date et l'heure s'inscrivent dans le dossier du patient (code de la santé publique, art. R. 6316-4) ; la FC n°7 2025-26 le dit en rouge (p. 18) |

Toutes les autres clés sont reprises telles quelles, vérifiées proposition par
proposition contre le cours. Les propositions que le cours 2025-26 ne dit pas
mot pour mot sont justifiées par les cours 2024-25 ou 2023-24, cités à la page,
ou par le code de la santé publique : le contenu du dossier fixé par la loi
(R. 1112-2), la biologie « une ligne par mesure » (modèle entité-attribut-valeur,
cours 2023-24, p. 8), les « algorithmes de soins sans contrôle médical »
(inventés), le supplément EXH compté au jour (diapositive p. 15).

## Les erreurs du ronéo 2025-26

Le Ronéosaure n'est pas le ronéo de l'année : chaque erreur est portée par un
**ATTENTION nu** dans la carte qui tient la notion, la sorte dite dans le texte,
et rien n'entre dans `contenu/ERRATA_RONEOS_2026-27.md`. Les diapositives
photographiées dans le ronéo départagent.

| Page | Le ronéo dit | Retenu | Sorte | Carte |
|---|---|---|---|---|
| 7, 9 | la T2A « en 2005 », « depuis 2005 » | 2004 dans le public (10 %, puis 50, 80, 100 %), 2005 dans le privé : la première diapositive p. 9, les cours 2023-24 et 2024-25 (p. 12), la loi de financement de la sécurité sociale pour 2004 | le cours lui-même simplifie : sa seconde diapositive p. 9 date la T2A de 2005 | `fin-fa-financement`, `fin-an-1819s1-q4` A |
| 6 | nom IUPAC du paracétamol « hydroxy-4'-acetanemib » (déjà en 2024-25) | N-(4-hydroxyphényl)acétamide (4'-hydroxyacétanilide) | prise de notes | `fin-fa-noms-medicament` |
| 7 | « Diagnosis Related Groups = DGR » | DRG | coquille | `fin-qc-pmsi-histoire` A |
| 12 | la CIM « mise au point par l'OMS en 1893 » | 1893 : la classification des causes de décès de Bertillon ; l'OMS en a la charge depuis 1948 (6e révision) ; CIM-10 adoptée en 1990 | point douteux | `fin-qr-cim` |
| 13 | « Classification Commune aux Actes Médicaux » (déjà en 2024-25) | classification commune des actes médicaux (Assurance maladie) ; la forme du ronéo reste acceptée au QROC | coquille | `fin-qr-ccam` |
| 13 | le scanner cérébral avec injection d'iode codé « avec injection intrathécale » | l'intrathécale est le cisternoscanner (ACQH001) ; l'iode s'injecte par voie intraveineuse (ACQH003) ; le point du cours, « crâne » et non « cerveau », reste juste | point douteux | `fin-qc-codage` |
| 14 | « Les complications et morbidités associées (CAM) » | CMA | coquille | `fin-qr-cma` |
| 15 | GHM sans leur lettre (« 06094 », « GHM06093 », « GHM06092 »), et « (GHM 06091) » pour le niveau 4 | le niveau 4 est le 06C094, le niveau 1 le 06C091 (diapositives) | prise de notes | `fin-qc-tarifs` |
| 15 | la convergence des tarifs « au-delà de 62 jours » | absent des diapositives, où les courbes se rejoignent vers le 49e jour | point douteux | `fin-qc-tarifs` |
| diapositive p. 6 | « Pharmacie à usage interne (PUI) » | pharmacie à usage intérieur (code de la santé publique, art. L. 5126-1) | la diapositive elle-même | planche `fin-pl-circuit`, numéro 10 (dit dans la phrase du numéro) |

Sans ATTENTION, parce qu'aucune réponse n'en dépend : la définition tronquée de
l'interopérabilité (p. 4, « sans qu'il y ait besoin de développer d'autres
modules.restriction d'accès » ; dite dans `fin-qr-interoperabilite`), « on
additionne tous les ACCM » (p. 13, les actes CCAM, comme le dit le cours
2024-25, p. 19), le supplément de « 200 euros » (201 € sur la diapositive, dit
dans `fin-qc-tarifs`).

## Les schémas et les figures

**Dix-neuf diapositives de la FC 2025-26**, extraites en PNG à leur résolution
(captures, ramenées à 256 couleurs) : interface de DPI (p. 4) ; terminologies,
données d'un DPI, LOINC (p. 5) ; ATC de l'aspirine, circuit du médicament
(p. 6) ; les cinq champs (p. 7) ; financement public et privé, intérêt de
l'établissement (p. 9) ; pôles et UM, entité juridique, séjour → RUM → RSS →
RSA, définitions (p. 11) ; codage d'une pneumonie (p. 12) ; CMD 06 (p. 14) ;
les quatre courbes de tarif (p. 15). Non extraite : le tableau du recueil par
champ (p. 10, « pas à connaître »).

**Deux planches à légender** (diapositives en image,
`planche_depuis_image.py`, aperçus de contrôle regardés) :

| Planche | Numéros | Intrus |
|---|---|---|
| `fin-pl-sejour` — du séjour aux fichiers (p. 11) | 11 : transfert, deux mutations, sortie, trois RUM, chaînage et groupage, RSS, anonymisation, RSA | GHS, IPP, Admission, Facturation, Consultation externe |
| `fin-pl-circuit` — le circuit du médicament (p. 6) | 10 : les trois étapes, médecin, pharmacien, infirmier, les deux dispensations, le stock du service, la PUI | Aide-soignant, Ordonnance de sortie, Préparation magistrale, Pharmacie d'officine |

Le fond des diapositives n'est pas blanc : les cases effacées se voient en
blanc, comme les cases à remplir d'un schéma distribué. « Préparateur »,
« Service de soin » et les UM restent visibles.

**Un schéma cliquable** (`schemas.py`), avec sa version légendée en
correction :

| Fichier | Ce qu'on clique | Pourquoi ce dessin |
|---|---|---|
| `ghm-code-nu.svg` | dans le code 06C094 : la CMD (06), le type de prise en charge (C), le compteur (09), le niveau (4) — 4 zones | le nom « semi-hiérarchisé » d'un GHM (p. 14) se lit de gauche à droite ; c'est une figure dont la réponse est une place. Les zones sont les cases mêmes du dessin |

**Une figure redessinée** pour les corrections : `dossier-organisations.svg`
(p. 2-3) — le dossier unique du public, la superposition du privé, le contenu
à l'admission, pendant et en fin de séjour, les mentions obligatoires ; une
ligne y ajoute la télésanté, d'après le code de la santé publique, et le dit.

**60 QCM sur 60 illustrés**, 93 notes sur 101. Seuls les huit termes du lexique
n'ont pas d'image.

## Le lexique

Huit termes, ceux du plan C15 ; aucun n'existait (vérifié contre les `lex-*` de
tous les paquets et des propositions d'étymologie en cours). Pages mesurées
dans le texte de la FC 2025-26, en-têtes exclus :

| Terme | Origine | Pages |
|---|---|---|
| Interopérabilité | latin inter + operari | 1, 4, 5 |
| Terminologie | latin terminus + grec lógos | 4, 5, 12, 13 |
| Nomenclature | latin nomenclatura | 4 |
| Dispensation | latin dispensatio | 1, 6 |
| Excipient | latin excipiens | 6 |
| Ambulatoire | latin ambulatorius | 8 |
| Morbidité | latin morbidus | 14 |
| Nominatif | latin nominare | 6, 16 |

`Interopérabilité` est accueillie ici, bien qu'elle figure aussi dans les FC
n°1, 3 et 7 : deux annales de ce chapitre en parlent (2019/2020 S1 Q9,
« interopérables » ; 2018/2019 S1 Q3, « l'interopérabilité sémantique »).
`Nominatif` couvre les deux sens du cours : la dispensation nominative (p. 6)
et l'information indirectement nominative (p. 16).

Une racine est enseignée par la FC de sémantique et la cite : `-logie` (1/2,
p. 5). Les racines nouvelles (`operari`, `terminus`, `calare`, `dispensare`,
`excipere`, `ambulare`, `morbus`) et les huit termes sont proposés à la table
commune (`etymologies.json`), vérifiés sur le Wiktionnaire (qui cite le TLFi)
et renvoyés au Gaffiot ; les textes du lexique sont déjà écrits dans la forme
que `appliquer_etymologies.py` produirait. `inter (latin)`, `nomen (latin)` et
`-logie, de logos (grec)` reprennent les clés existantes.

## Décisions prises en route

- **`EXAMENS` n'est pas déclaré** (convention de BMCT) : le partiel du 16/12 se
  règle dans l'application.
- **Les questions répétées** ont chacune leur carte, y compris la session
  2021/2022 S2, copie de 2022/2023 S2 : ce sont deux sujets d'examen distincts,
  et l'explication le dit.
- **La clé de thème `t2a-groupage`** du plan portait un chiffre : renommée
  `groupage-tarifs`.
- **Interopérabilité** : une seule carte des trois niveaux (`fin-fa-interop-niveaux`),
  qui donne aussi le nom du Pr Gérard pour le premier (« technique », FC n°1) ;
  la FC n°1 ne la carte pas.
- **Relecture sceptique, frontières avec les autres chapitres** :
  - le recto-verso « CIM-10 et CCAM : ce que code chacune » doublait celui de
    la FC n°1 (`isn-rv-cim-ccam`, la liste des standards que le plan lui
    donne) ; il est remplacé par `fin-rv-bornes`, propre à ce cours : séjour
    trop court (dégressivité) contre borne haute (supplément EXH par jour), le
    piège de deux annales. Son ATTENTION sur l'« injection intrathécale » passe
    dans l'explication de `fin-qc-codage` ;
  - le QROC `fin-qr-nominatif` demandait la définition générale de
    l'information indirectement nominative, que carte la FC n°6
    (`cry-fa-donnee-personnelle`) ; il porte désormais sur les fichiers du
    PMSI (le RSS, le RSA), l'exemple que le plan donne à ce chapitre.

## Questions pour Vincent

Aucune question ouverte : le plan C15 n'en posait pas pour ce chapitre, et la
seule clé contestée (2023/2024 S1 Q3) se tranche sur quatre sessions et le code
de la santé publique.

## À relire

**Aucune carte `a-relire`** : toutes les notes citent une page de la FC 2025-26,
ou une source sûre. Reste à Vincent :

- quand le ronéo 2026-27 paraîtra, relire chaque carte sur lui et retirer le
  badge « Cours 2025-26 » ;
- `copier_les_cours.py` avec le dossier `…/examen décembre` du Ronéosaure
  2025-26, hors du bac à sable, pour que la fiche s'ouvre dans l'application ;
- les libellés des huit thèmes à ajouter à `THEME_LABELS`.


## L'échelle : Simple → Moyen → Annale (C20, 18/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 16 décembre. Sous les annales, 39 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 9 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`).

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `dossier-medical` | 10 | 1 | 7 |
| `interoperabilite` | 4 | 1 | 2 |
| `champs-hospitalisation` | 9 | 2 | 16 |
| `financement-historique` | 1 | 1 | 1 |
| `pmsi-recueil` | 7 | 1 | 9 |
| `groupage-tarifs` | 8 | 3 | 6 |

**Le schéma** `ech-financement`, « Information médicale et financement · du dossier au tarif », donne 90 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_FINANCEMENT`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Sources déclarées en plus** : `src-fc-info-telesante-2526` et `src-fc-info-sante-2526`, à l'identique de leurs chapitres, parce que des marches citent la FC n°7 (le compte rendu de télésanté inscrit au dossier) et la FC n°1 (le DMP).

**Sans marche** :
- fin-an-1920s1-q9 B et fin-an-1819s1-q3 B, en partie seulement : le tableau « une ligne par mesure » (modèle entité-attribut-valeur) n'est que dans le cours 2023-24 (p. 8), absent des sources fournies ; fin-ech-m5 C n'en prépare que la moitié tirée de la FC 2025-26, des valeurs chiffrées suivies dans le temps (p. 5). Leurs lettres sont posées sur la case des données informatisées.
- Les propositions sur le RSA (fin-an-1920s1-q10 E ; fin-ech-m4 D) n'ont pas de ligne à elles : le RSA n'est pas dessiné, faute de place sous le RSS ; leurs lettres sont posées sur la case du RSS, dont il est tiré par anonymisation.

## Régénérer

```powershell
..\..\..\app\.venv\Scripts\python.exe generer.py
```
