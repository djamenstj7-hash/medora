# Sémiologie de la phase ultime — paquet d'exemple

30 notes, 61 cartes. Une seule source : la fiche de cours.

## Le seul chapitre sans annales

Le polycopié de sémiologie ne comporte **aucune section** sur la phase ultime :
ni sous ce nom, ni sous celui de fin de vie ou de soins palliatifs. Le chapitre
voisin, la thanatologie, en a quinze — mais elles commencent toutes *après* le
décès.

`annales.py` existe quand même, avec des listes vides. Un fichier vide dit qu'on
a cherché et qu'on n'a rien trouvé ; un fichier manquant laisserait croire à un
oubli.

**Conséquence pour la révision** : la hiérarchie ne vient que du cours, et le
cours est avare de signaux — deux verbes en rouge, *distinguer* et *décider*, et
trois titres en orange. Les cartes suivent donc le fil du cours plutôt qu'une
hiérarchie inventée.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| Texte à trous | 10 | 33 |
| Repérage sur schéma | 3 | 11 |
| QRM | 8 | 8 |
| Recto-verso | 5 | 5 |
| QROC | 4 | 4 |

## Ce que le cours enseigne vraiment

C'est le seul chapitre du corpus où la sémiologie sert moins à poser un
diagnostic qu'à **savoir quoi dire**. Le cours y revient sans cesse : expliquer
aux proches ce qu'ils voient, et faire en sorte que le patient ne perçoive pas
ses propres signes de lutte. Les cartes le suivent sur ce terrain-là, parce que
c'est ce qu'il enseigne.

Trois mots y sont séparés avec un soin inhabituel, et c'est là que le cours écrit
**distinguer** en rouge :

| Mot | Ce qu'il désigne |
|---|---|
| **Confort** | la satisfaction des besoins fondamentaux de soulagement, d'aisance ou de transcendance |
| **Douleur** | une expérience sensorielle et émotionnelle liée à une lésion tissulaire, existante ou potentielle |
| **Souffrance** | l'expression psychique d'affects ouverts sur le rapport à soi, à autrui, au sens |

La distinction pratique qui en découle : séparer ce qui relève d'un **symptôme
pénible ou d'une souffrance** — sur quoi le médecin peut agir — de ce qui relève
d'une **altération physiologique du corps**, qui est le processus normal du
mourir.

## Deux phases, deux régimes

| | Pré-agonique | Agonique |
|---|---|---|
| Réversibilité | potentiellement **réversible** | **irréversible** |
| Durée | **incertaine** : heures à semaines | **moins de 48 h** |
| Conscience | fluctuante, confusion | coma aréactif |
| Cœur | **tachycardie**, pouls filant | **bradycardie**, pouls abolis |

Le renversement cardiaque est le repère le plus simple : rapide, puis lent.

## Les trois schémas cliquables

| Fichier | Ce qu'on y clique | Cartes |
|---|---|---|
| `phases-ultime.svg` | les quatre étapes, de la terminale au décès | 4 |
| `respiration-ultime.svg` | apnée, reprise, apnée suivante | 3 |
| `signes-lutte.svg` | les quatre signes de lutte respiratoire | 4 |

Le deuxième redessine la figure du cours : le tracé et les zones cliquables
sortent des mêmes bornes, écrites une seule fois dans le code, pour qu'une zone
ne puisse pas glisser à côté de la courbe qu'elle désigne.

## Erreurs du ronéo 2026-27

Relevée à la relecture du 28/09/2026, absente du tableau d'erreurs de la promo ;
les cours ne seront pas modifiés. Elle est aussi dans
`contenu/ERRATA_RONEOS_2026-27.md`.

| Page | Imprimé | À lire | Carte |
|---|---|---|---|
| p. 6 | la confusion, « une infection cérébrale aiguë » | une **affection** cérébrale aiguë ; l'infection est l'une de ses causes | `ult-fa-confusion` (ATTENTION) |

Point douteux, non carté : dans la même définition, les troubles du
comportement et de la vigilance sont une « hypotension avec somnolence ou au
contraire avec une agitation » (p. 6) ; la phrase oppose sans doute les formes
hypoactive et hyperactive de la confusion.

## Régénérer

```powershell
python generer.py
```
