# Sémiologie urologique normale — paquet d'exemple

65 notes, 113 cartes. Deux sources : la fiche de cours et les annales de dix
sessions.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 36 | 36 |
| Texte à trous | 12 | 50 |
| QROC | 11 | 11 |
| Repérage sur schéma | 3 | 13 |
| Recto-verso | 3 | 3 |

Sur les 36 QRM, **21 sont des annales** de 2016/2017 à 2023/2024, avec la clé de
correction du polycopié.

## Ce que la fiche a dicté

C'est la fiche la plus annotée des six traitées jusqu'ici : le rouge court sur
presque toutes les définitions, et **trois commentaires en marge** disent quoi en
faire.

| Commentaire | Sur quoi | Ce qui en a été fait |
|---|---|---|
| « Plus rare ici » | pneumaturie, pyurie | une QROC chacune, pas de QCM |
| « Important les origines » | les trois hématuries macroscopiques | le schéma cliquable du test des trois verres |
| « A savoir » | la douleur de colique néphrétique | un texte à trous et un QCM, sur ses cinq caractères |

Et le professeur conclut par une phrase que le ronéo a notée telle quelle : **« il
faut savoir quasiment tout le vocabulaire »**. Les annales lui donnent raison — la
moitié des questions ne demande qu'un mot.

## Une contradiction dans la fiche, tranchée avec son auteur

À la section cystite, deux annotations rouges se contredisaient à trois lignes
d'écart : **« On retien avec fievre »**, puis **« Pas de fièvre ici ! »**.

Le corps du cours écrit « Absence de fièvre ». Les annales 2022/2023 donnent vraie
la proposition « elle est typiquement isolée chez la femme, **sans fièvre** ». Et
les deux sections voisines — prostatite et pyélonéphrite — sont justement celles
qui portent « fièvre, frissons » ; la pyélonéphrite porte même sa propre
annotation, **« (avec fièvre !) »**. L'auteur des notes a confirmé cette lecture :
la première annotation visait les sections suivantes, pas la cystite.

La règle sous-jacente vaut la peine d'être retenue : **dès que le parenchyme d'un
organe est infecté — prostate ou rein — il y a de la fièvre.** La cystite ne
touche que la muqueuse des voies basses.

Comme c'est là que la prise de notes a dérapé, les trois infections sont révisées
ensemble : un texte à trous qui les aligne (`uro-fa-infections`), un QROC qui
demande la troisième (`uro-qr-pyelonephrite`), et les deux QCM qui les opposaient
déjà sur la fièvre et sur le siège de la douleur.

## Ce que les annales ont dicté

Le polycopié est remarquablement répétitif, et c'est une aubaine. Quatre savoirs
couvrent **dix-neuf questions sur vingt-et-une** :

| Le savoir | Questions |
|---|---|
| La définition de l'**urétrorragie** — sang par l'urètre, **en dehors** de la miction | 5 |
| Le tri **remplissage (irritatif)** contre **vidange (obstructif)** | 5 |
| Le partage **inspection** contre **palpation** des organes génitaux externes | 5 |
| La douleur du **calcul urétéral** obstructif | 4 |

Trois mots reviennent sans cesse et s'échangent : **hématurie** (sang dans
l'urine), **urétrorragie** (sang hors miction), **hémospermie** (sang dans
l'éjaculat).

## Les trois schémas cliquables

| Fichier | Ce qu'on y clique | Cartes |
|---|---|---|
| `voies-urinaires.svg` | six repères, dont les deux sphincters | 6 |
| `diurese-echelle.svg` | quatre seuils sur un axe de 0 à 4 L/j | 4 |
| `trois-verres.svg` | les trois profils d'hématurie | 3 |

Le deuxième mérite un mot : les seuils de diurèse ne sont que des nombres, et un
axe gradué les tient mieux qu'une phrase. Les deux intervalles entre les bornes
— 500 à 800 mL, 1500 à 3000 mL — ne portent aucun nom, et le schéma les laisse
vides.

Sur le premier, le rein et l'uretère sont pairs : **un seul côté est dessiné plein
et porte une zone**, l'autre est estompé. Les dessiner tous deux en zones ferait
compter faux un clic sur le jumeau, qui désigne pourtant la même chose.

## Relu sur le ronéo 2026-27 (25/09/2026)

- **Le sphincter strié est « au niveau de l'urètre »**, comme le corrige le
  tableau d'erreurs de l'UE : le ronéo écrit « uretère » (p. 2). Les cartes
  disaient « sous l'urètre », imprécis ; `uro-fa-sphincters` le dit par
  ATTENTION.
- **Le test des trois verres est historique** (« Auparavant on utilisait »,
  p. 4) : les cartes le datent, la classification initiale / terminale /
  totale reste.
- **Les sels biliaires qui colorent les urines : c'est le cours lui-même**
  (relecture du 28/09/2026, tri du même jour). Parmi les colorations des
  urines, le ronéo cite « une excrétion de sels biliaires lors d'une
  cholestase : colore en jaune » (p. 4). « Excrétion de sels biliaires lors
  d'une cholestase » est le libellé du cours depuis au moins 2023-24, sous deux
  enseignants : Charonéo 2023-24 (Pr Villers, « couleur foncée »), Ronéosaure
  2024-25 et ronéo 2025-26 (Pr Olivier, « orangé foncé, marron »), ronéo
  2026-27 ; seul « colore en jaune » est propre au ronéo 2026-27. À l'examen :
  retenir la formule du cours — un item qui attribue la coloration des urines
  de la cholestase aux sels biliaires le reprend, et se coche ; la cholestase
  fonce les urines, orangé foncé à marron, pas jaune. La référence : ce sont les **pigments** biliaires, la
  bilirubine conjuguée, qui foncent les urines de la cholestase ; les sels
  biliaires, eux, donnent le prurit (Manuel MSD, « Ictère »). Aucune carte ne
  porte la coloration des urines ; le point est dans
  `contenu/ERRATA_RONEOS_2026-27.md`.

## Les trois anomalies du polycopié

- **2023/2024 QCM 6** — la table imprime « C » seul. Or la proposition E,
  « saignement pouvant être associé à un traumatisme de l'urètre », est donnée
  **vraie par trois autres sessions** dans des termes presque identiques, et le
  cours écrit que l'origine de l'urétrorragie « est souvent traumatique ». La
  carte retient **CE** et n'est **pas** marquée comme clé officielle. Le
  **corrigé officiel** du sujet 2023-24 (dépôt du 15/10/2026) imprime lui aussi
  « C » seul : c'est la clé du professeur cette année-là (la définition seule),
  pas une coquille du polycopié. L'analyse est gardée, et l'ATTENTION le dit.
- **2019/2020** — la table numérote les deux questions « Q.5 » et « Q.6 » alors
  que les énoncés sont imprimés « 1. » et « 2. ». Les clés correspondent bien aux
  énoncés dans l'ordre ; c'est la numérotation qui a glissé.
- **2022/2023 S2 QCM 10** — l'énoncé annonce la cystite, mais ses cinq
  propositions sont mot pour mot celles de la question de 2021/2022 sur la
  douleur de **rétention urinaire**, avec la même clé. Les deux lectures ne
  donnent **pas** la même réponse (relu le 26/09/2026) : une cystite n'est ni
  « intense, insupportable » ni accompagnée d'agitation, et son examen est le
  plus souvent normal. L'énoncé et la clé imprimés sont gardés, A, B et C
  portent l'ATTENTION ; question ouverte.

## Clés non reprises telles quelles

Relues le 26/09/2026 — règle de Vincent : la clé retenue est la bonne, pas la clé
imprimée.

| Question | Clé imprimée | Retenu | Pourquoi | Source |
|---|---|---|---|---|
| 2023/2024 QCM 6 (`uro-an-2324-q6`) | C (polycopié, et corrigé officiel 2023-24 reçu le 15/10/2026) | **CE** — carte non officielle | E « saignement pouvant être associé à un traumatisme de l'urètre » est vraie : l'urétrorragie est souvent traumatique, trois autres sessions la donnent vraie ; le corrigé officiel ne comptait que la définition | FC n°9 2024-25, p. 5 ; Manuel MSD pro, « Traumatisme urétral » |
| 2019/2020 QCM 1 (`uro-an-1920-q1`) | AB | AB, gardée — **question ouverte** | C « évolution sur un mode continu » : le ronéo 2026-27 écrit « Mode continu : émaillé de paroxysmes » (p. 5) ; le Collège décrit une « évolution par crises paroxystiques », et 2017/2018 donne vraie « une évolution paroxystique » | ronéo 2026-27 ; Collège français des urologues, item Lithiase urinaire (UMVF 2014) |
| 2022/2023 S2 QCM 10 (`uro-an-2223s2-q10`) | BC | BC, gardée — **question ouverte** | la clé est celle de la rétention, dont la question recopie les propositions ; pour la cystite de l'énoncé, B et C seraient fausses et A plutôt vraie (examen normal, au plus une gêne sus-pubienne) | ronéo 2026-27, p. 5-6 ; Collège français des urologues, item 161 (« un inconfort variable ») |
| 2019/2020 QCM 2 (`uro-an-1920-q2`) | ADE | ADE, gardée — **question ouverte** (16/10/2026) | A « des brûlures urétrales » est comptée au remplissage (signes irritatifs) par la clé, alors que le ronéo 2026-27 range les « brûlures urétrales mictionnelles » parmi les anomalies de la phase de vidange ; la lettre A n'est pas posée sur le schéma de l'échelle jusqu'à l'arbitrage de Vincent | ronéo 2026-27, p. 3 |

## Le corrigé officiel 2023-24

Le sujet de sémiologie générale 2023-24 et son corrigé officiel (une clé par
question) sont arrivés le 15/10/2026. Les cartes de cette session venaient du
polycopié ; elles gardent sa source.

- 2023/2024 QCM 5 (`uro-an-2324-q5`, AE) : clé confirmée par le corrigé
  officiel 2023-24, dépôt du 15/10/2026.
- 2023/2024 QCM 6 (`uro-an-2324-q6`) : le corrigé officiel imprime « C », comme
  le polycopié ; la carte garde CE, non officielle (tableau ci-dessus).


## L'échelle : Simple → Moyen → Annale (C20, 16/10/2026)

L'échelle du pilote de l'immunité innée, étendue à la sémiologie pour l'examen du 4/11 (Vincent, 16/10 : « on continue pour les chapitres que je vais avoir à l'examen »). Sous les annales, 39 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 5 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`).

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `miction` | 7 | 1 | 4 |
| `urines` | 7 | 1 | 5 |
| `douleurs` | 17 | 2 | 9 |
| `genital` | 8 | 1 | 5 |

**Le schéma** `ech-urologie`, « L'appareil urinaire · signes, douleurs, examen », donne 68 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_UROLOGIE`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Sources.** `SRC` n'a pas de clé `fiche` : les marches relues sur la ronéo 2026-27 nomment la leur (`fiche="src-fc-semio-uro"`), et les images de l'échelle sont déclarées sous `SRC["cours"]`.

**Deux contresens relevés à la relecture** (16/10/2026) : `uro-an-1920-q2` A, les brûlures urétrales, est une question ouverte, déclarée dans `CONFLITS` (tableau des clés, plus haut), et sa lettre A n'est pas posée sur le schéma jusqu'à l'arbitrage de Vincent ; la justification de `uro-an-2526-q19` D dit désormais que la douleur sacro-iliaque est celle de la prostatite (ronéo 2026-27, p. 6).

**Sans marche** :
- 2019/2020 QCM 2 A (brûlures urétrales, données vraies parmi les signes du remplissage, irritatifs) : la ronéo 2026-27 range les « brûlures urétrales mictionnelles » parmi les anomalies de la phase de VIDANGE (p. 3). Contresens entre l'annale et le cours de l'année, déclaré dans CONFLITS le 16/10/2026 (question ouverte, clé imprimée gardée) : pas de marche tant que Vincent n'a pas tranché ; lettre non posée.
- 2022/2023 S2 QCM 9 B (cystite « typiquement isolée chez l'homme ») et D (« pas de pollakiurie ») : la ronéo dit la cystite beaucoup plus fréquente chez la femme, possible chez l'homme, et ne cite pas la pollakiurie dans sa description (p. 6) ; pas de place sur le schéma pour la première, pas de page pour la seconde. Lettres posées sur la cystite.
- 2018/2019 QCM 25, 2017/2018 QCM 13, 2016/2017 QCM 16 B (un calcul d'un seul uretère ne bloque pas la vessie) : raisonnement anatomique de la justification, que la ronéo ne dit pas ; lettre posée sur la rétention.
- 2019/2020 QCM 1 E et 2018/2019 QCM 25 C (altération de l'état général) : absente de la ronéo 2026-27 ; lettre posée sur la colique.
- 2018/2019 QCM 16 et 2016/2017 QCM 17 A (inflammation du prépuce) : la ronéo cite le prépuce et le phimosis, pas l'inflammation (p. 7-8) ; lettre posée sur la verge.
- 2019/2020 S2 QCM 1, 2018/2019 QCM 16, 2016/2017 QCM 17 B (urétrorragie recueillie à l'inspection) : le partage inspection / palpation vient des annales, pas du cours ; lettre posée sur la case de l'urétrorragie.
- 2017/2018 S2 QCM 22 A (orifices herniaires) et E (urètre bulbaire) : absents de l'examen génital de la ronéo 2026-27 ; lettres non posées.
- 2023/2024 QCM 5 B (écoulement urétral) : section à part de la ronéo (p. 4), hors des troubles mictionnels ; la case des écoulements ne porte pas la sérosité ; lettre posée sur cette case.
- 2017/2018 QCM 14 B (« toujours associée à une pollakiurie ») : écartée par la définition de l'urétrorragie, sans autre page ; lettre posée sur la case de l'urétrorragie.
- 2021/2022 QCM 2 A (siège : canal inguinal, cordon, bourses) : la ligne de la case le dit presque mot pour mot comme l'annale, et la bonne réponse serait une recopie ; lettre posée sur la douleur inguino-scrotale.

## Régénérer

```powershell
python generer.py
```
