# Application en pharmacovigilance — paquet Biomédecine quantitative

63 notes, 125 cartes. Chapitre `chap-ue-biomed-quanti-fc3` de l'UE
Biomédecine quantitative, neuvième de l'UE. Cours du **Pr S. Gautier, le
19/11/2025, de 8 h à 9 h**, dans le **Ronéosaure 2025-26** (FC n°9, 10 pages) ;
deux annales du Ronéosaure 2024-25 (2017/2018 S2). Examen : partiel du mercredi
16 décembre 2026.

**Fiche provisoire** (C15, décision de Vincent du 02/10) : le cours de l'année
2026-27 n'est pas encore paru. Chaque carte de cours cite la FC 2025-26 à sa
page et porte le badge « Cours 2025-26 » ; le ronéo 2026-27 corrigera les cartes
quand il sortira. `donnees.py` porte `ANNEE_COURS = "2025-26"`. Aucune carte ne
dit « Absent du cours 2026-27 », et les erreurs du Ronéosaure sont dites par un
ATTENTION sans genre : la liste des erreurs de la promo,
`contenu/ERRATA_RONEOS_2026-27.md`, ne concerne que les ronéos 2026-27.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 25 | 25 |
| QRU | 1 | 1 |
| Texte à trous | 10 | 64 |
| QROC | 11 | 11 |
| Recto-verso | 6 | 6 |
| Schéma cliquable | 2 | 10 |
| Lexique | 8 | 8 |

Dont **2 annales** (2017/2018 S2, Q17 et Q18), rangées dans le polycopié
« 15 - Analyse médico-économique » ; les 24 autres QCM sont des questions de
cours.

Sept thèmes, dans l'ordre du cours. `pharmacovigilance` (« Pharmacovigilance »,
déjà employé par `bmct_risques`) et `types-etudes` (« Types d'études », déjà
employé par `biostat_regression_lineaire`) ont leur libellé dans `THEME_LABELS` ;
les cinq autres sont nouveaux et leurs libellés restent à ajouter
(`app/src/med_engine/application/scopes.py`) :

| Clé | Libellé | Notes |
|---|---|---|
| `pharmacovigilance` | Pharmacovigilance | 4 |
| `notification-spontanee` | Notification spontanée et ses limites | 5 |
| `types-etudes` | Types d'études | 13 |
| `rr-or` | Risque relatif, odds ratio, hazard ratio | 8 |
| `olmesartan` | L'exemple de l'olmésartan | 17 |
| `valproate-paternel` | Acide valproïque et exposition paternelle | 4 |
| `interpreter-risque` | Interpréter un risque proche de l'unité | 4 |

`rr-or` est partagée avec la régression logistique et les analyses de survie
(plan C15), où son libellé dit vrai aussi.

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-biomed-pvg-2526` — Ronéosaure, « FC n°9 Application en pharmacovigilance » (10 p.) | 2025-26 | le cours ; `SRC["fiche"]`, ses 10 figures ; fiche provisoire en attendant le ronéo 2026-27 |
| `src-annales-15-analyse-medico-economique` — « 15 - Analyse médico-économique » (19 p.) | 2024-25 | 2017/2018 S2, Q17 et Q18 (p. 15-16) ; table p. 19 |

Le polycopié d'annales est déclaré **à l'identique** de
`biostat_tests_diagnostiques` (même id, même titre — deux espaces finales
comprises —, même chemin, même auteur). Lus en appoint, sans être déclarés : le
cours 2024-25 (FC n°3, Pr Gautier) et le cours 2023-24 (Charonéo), pour
comprendre les annales et trier les erreurs ; les erratas des cours 2025-26 et
des annales 2024-25, qui n'ont **aucune entrée** pour ce cours (l'errata des
cours 2024-25 en a, mais pour l'ancien ronéo) ; le rapport EPI-PHARE de novembre
2025 (la figure de la p. 10), le dossier « Valproate et grossesse » de l'ANSM et
sa page sur les pères traités avant la conception (mesure du PRAC de janvier
2024), cités dans les justifications.

Les pages citées sont celles du PDF ; la p. 1 est la page de garde et le plan,
et le ronéo imprime « 0/9 » à « 9/9 », la page du PDF moins un. Les en-têtes des
ronéos, des erratas et du polycopié portent des noms d'étudiants : aucun n'est
repris. Le polycopié attribue ses annales au « Pr Décaudin » : l'attribution
n'est pas reprise.

## Ce que le cours a dicté

| Partie | Pages | Cartes |
|---|---|---|
| I. Introduction | 2 | `pvg-qc-objectif` |
| II. La notification spontanée : principe, limites | 2-3 | `pvg-fa-notification`, `pvg-qc-notification`, `pvg-qc-limites`, `pvg-qr-notification`, `pvg-rv-annees-2000` |
| III. Études pharmaco-épidémiologiques : descriptives et analytiques, transversale (EMIR), cohorte, cas-témoins, RR et OR | 3-5 | `pvg-fa-etudes`, `pvg-fa-iatrogenie`, `pvg-fa-cohorte-cas-temoins`, `pvg-fa-rr`, six QCM, cinq QROC, `pvg-rv-cohorte-cas-temoins`, la zone `pvg-zo-tableau` |
| IV. L'olmésartan : Mayo Clinic, signal français, cas typique, cohorte du SNDS, tableaux 3 et 4, décisions | 5-8 | trois textes à trous, neuf QCM dont la QRU du critère, quatre QROC, deux recto-verso, la zone `pvg-zo-forest` |
| IV.C Outils épidémiologiques ; l'acide valproïque, la mère et le père | 8-9 | `pvg-qc-outils`, `pvg-fa-valproate`, `pvg-qc-valproate`, `pvg-qc-valproate-pere`, `pvg-qr-hr`, `pvg-rv-descriptif-demonstration`, `pvg-rv-brut-ajuste` |
| V. Conclusion : 1 à 1,5, l'hépatite B, la figure du père | 9-10 | `pvg-fa-prudence`, `pvg-qc-hr-prudence`, `pvg-qc-figure-pere`, `pvg-qc-hepatite-b` |

- **Le rouge** est celui des titres et de « courbe du haut » (p. 2) : la
  courbe des ventes, dite dans `pvg-fa-notification`.
- **Le gris** (p. 8, l'anecdote du laboratoire de l'olmésartan et de son
  anticoagulant) est la voix des rédacteurs : il est repris dans l'explication
  de `pvg-qc-decision`, sans devenir une proposition — une anecdote
  invérifiable ne fait pas une clé.
- **Ce qui n'est pas carté ici** (plan C15) : les méthodes de détection des
  EIM — déclaration, imputabilité, disproportionnalité, règles, data-mining —
  (`biostat_phase_4_eim`) ; l'OR de la régression logistique, exp(β), et
  l'approximation OR ≈ RR (`biostat_regression_logistique`) ; le HR du modèle de
  Cox (`biostat_survie`) ; le risque médicamenteux, l'EIM et le CRPV en
  pharmacologie (`bmct_risques`, UE BMCT, qui carte aussi l'hépatite B et la
  SEP sous l'angle de la perception du risque : rien ne s'y recarte).
- **Les exercices chiffrés** : `pvg-qc-calcul-rr` (une cohorte inventée, RR = 3)
  applique la formule du tableau a, b, c, d ; `pvg-qc-tableau-3` et
  `pvg-qc-duree` recopient en texte, dans l'énoncé, les lignes utiles des
  tableaux 3 et 4 de la p. 7, comme les annales recopient leurs tableaux.

## Les erreurs du Ronéosaure 2025-26

Le Ronéosaure n'est pas le ronéo de l'année : chaque erreur est portée par un
**ATTENTION nu** dans la carte qui tient la notion, la sorte dite dans le texte,
et rien n'entre dans `contenu/ERRATA_RONEOS_2026-27.md`.

| Page | Le ronéo dit | Retenu | Sorte | Carte |
|---|---|---|---|---|
| 2-3 | la figure des ventes et des notifications : « des atteintes rénales sévères », « insuffisance rénale sévère » | la légende de la diapositive : notifications d'hépatites sous acide tiénilique, avant et après l'intervention des médias (1980) ; le cours 2024-25 prenait aussi des atteintes hépatiques. Le principe ne change pas | point douteux | `pvg-qc-limites` (explication) |
| 3 | « comparer le groupe témoin non exposé avec le groupe témoin exposé » | le groupe exposé contre le groupe non exposé, qui est le témoin | prise de notes | `pvg-qc-descriptives-analytiques` B |
| 3 | l'enquête transversale « sur tous les CHU de France » (même phrase dans le cours 2024-25, qui la datait du 12 avril 2024, aux urgences) | la diapositive : EMIR 2007, 63 services de spécialités des hôpitaux publics tirés au sort, 2 692 patients, 97 EIM ; le professeur parle sans doute d'une autre enquête, d'un jour. La proposition ne dépend pas de l'écart | point douteux | `pvg-qc-transversale` A |
| 7 | l'olmésartan, « un risque à 5,58 (très supérieur à 1) » | 5,58 est le taux d'incidence pour 100 000 personnes-années ; le RR est 2,34 [1,64 ; 3,32] | prise de notes | `pvg-qc-tableau-3` B (et `pvg-rv-incidence-rr`, `pvg-fa-tableau-3`) |
| 7 | IEC : « 2,39 hospitalisations pour 100 000 personnes », « 3 millions de patients traités par IEC » | pour 100 000 personnes-années ; 3 646 329 personnes-années | prise de notes | `pvg-qc-tableau-3` D |
| 7 | les autres sartans : « aucune différence notable n'apparaît » | vrai du sur-risque ; mais l'IC du valsartan, [0,34 ; 0,95], exclut 1 : RR significativement inférieur à 1 | le cours lui-même (formulation) | `pvg-qc-tableau-3` E ; zone « valsartan » de `pvg-zo-forest` |
| 7 | plus de 2 ans : « un risque multiplié par 8 » | RR 10,09 [4,80 ; 16,34] ; 8,86 est l'incidence | prise de notes | `pvg-qc-duree` E |
| 8 | l'acide valproïque, « commercialisé depuis les années 1980 », risque malformatif connu « dès son introduction » | la Dépakine est commercialisée en France depuis 1967 ; ce sont les malformations (spina bifida, Robert et Guibaud, Lancet 1982) qui sont connues depuis les années 1980 | point douteux (absent du plan) | `pvg-qc-valproate` A ; la proposition B et `pvg-fa-valproate` évitent la date |
| 8 | risque malformatif « 15-20 % » | ANSM : 11 % de malformations, 30 à 40 % de troubles neurodéveloppementaux. À l'examen : le chiffre du cours | le cours lui-même, point douteux | `pvg-qc-valproate` D |
| 9 | l'olmésartan, « qui a un risque supérieur à 5 » | RR 2,34 [1,64 ; 3,32] ; 5,58 est son taux d'incidence — la confusion de la p. 7 | prise de notes (trouvée à la relecture, absente du plan) | `pvg-qc-hr-prudence` (explication) |
| 9 | la mesure européenne pour les pères, « en 2023 » | recommandée par le PRAC en janvier 2024 : contraception efficace pendant le traitement et au moins 3 mois après l'arrêt ; attestation d'information partagée en France depuis janvier 2025 (ANSM) | point douteux (trouvé à la relecture, absent du plan) | `pvg-qc-valproate-pere` E |
| 9 | « quand les hazard ratio ne sont pas au-dessus de 2, […] le risque est peut-être lié au hasard » | la significativité se lit sur l'IC ; le message est la prudence entre 1 et 1,5-2 | le cours lui-même | `pvg-qc-hr-prudence` D |
| 9 | l'autisme : 1/120, « +20 % = on passe à 1/90 » | 1,24 × 1/120 ≈ 1/97, de l'ordre de 1/100 ; le message, un faible risque absolu, ne change pas | point douteux | `pvg-qc-hr-prudence` B |
| 10 | « chevauchement des écarts-types (les barres) » | la légende ne nomme pas les barres ; le rapport EPI-PHARE donne ses estimations avec leur IC à 95 % : vraisemblablement des intervalles de confiance | point douteux (le plan disait « prise de notes ») | `pvg-qc-figure-pere` B |
| 10 | hépatite B : « un facteur propre à la population française qui expliquait l'apparition de la SEP » | le signal n'existait que dans les études françaises : un biais ou un facteur propre à ces études, pas un risque démontré du vaccin (cours 2024-25, p. 12) | point douteux | `pvg-qc-hepatite-b` C |

Aucune proposition dont le verdict dépende d'un point douteux n'est posée sans
que la carte le dise ; la seule clé qui suit un chiffre contesté est
`pvg-qc-valproate` D (« le cours estime… 15-20 % »), qui interroge ce que dit le
cours et donne la référence.

## Ce que les annales ont dicté

Deux questions, une session (2017/2018 S2), rangées par le Ronéosaure dans le
polycopié médico-économique :

| Question | Thème | Savoir | Clé |
|---|---|---|---|
| Q17 — La décision nationale en pharmacovigilance | `pharmacovigilance` | elle tient compte du bénéfice, s'appuie sur des données épidémiologiques ; ni toujours européenne, ni confidentielle, et elle peut aller jusqu'au retrait | BD |
| Q18 — Les études épidémiologiques en pharmacovigilance | `types-etudes` | bases médico-administratives, cohortes et cas-témoins, utiles à la décision ; elles ne remplacent pas la notification spontanée | ABE |

Énoncés recopiés mot pour mot (« des données épidémiologique », sans s, est
gardé tel qu'imprimé) ; une justification par proposition, qui cite la page de
la FC 2025-26.

## Les schémas cliquables

**Deux schémas** (`schemas.py`), chacun avec sa version légendée en
correction ; le plan C15 n'en prévoyait qu'un, le forest plot :

| Fichier | Ce qu'on clique | Pourquoi ce dessin |
|---|---|---|
| `forest-sartans.svg` | quatre bandes de lignes : les quatre sartans dont l'IC contient 1 (candésartan, irbésartan, losartan, telmisartan, consécutifs dans le tableau), le valsartan (IC sous 1), l'olmésartan (IC au-dessus de 1), les IEC (la référence) — 4 zones | le tableau 3 de la p. 7 redessiné en forest plot, échelle logarithmique de 0,25 à 4, droite RR = 1 ; la règle du cours (« si 1 est inclus dans l'IC, le résultat n'est pas significatif ») se lit d'un coup d'œil. Une zone par sartan aurait demandé « un sartan dont l'IC contient 1 » quatre fois : les quatre sont une seule zone. L'éprosartan (0 événement, pas de RR) n'est pas dessiné |
| `tableau-rr-or.svg` | les cases a, b, c, d, chacune par son rôle (numérateur du risque des exposés, des non-exposés ; exposés et non-exposés indemnes), et les deux entrées : les lignes (point de départ d'une cohorte) et les colonnes (d'une étude cas-témoins) — 6 zones | le tableau de la p. 4, « Cohortes : RR = (a/a+b) / (c/c+d) ; cas-témoins : OR » ; le RR et l'OR sont **définis ici** (plan C15). La version légendée écrit l'OR en (a × d) / (b × c), la formule classique que la diapositive ne détaille pas |

**Dix figures de la FC 2025-26**, extraites en PNG (captures de diapositives),
en 256 couleurs, toutes sous 1 000 px de large. **24 QCM sur 26 illustrés**,
40 notes sur 63. Les deux sans figure (`pvg-qc-valproate`,
`pvg-qc-hepatite-b`) n'en ont pas dans le cours.

## Les clés qui ne sont pas reprises telles quelles

**Aucune.** Les deux clés imprimées (17 BD, 18 ABE) ont été relues sur la table
de la p. 19 (colonne « Année 2017/2018 Session 2 ») et vérifiées proposition
par proposition contre la FC 2025-26 : elles sont justes et restent officielles.
`CONFLITS` est vide.

## Le lexique

Huit termes. Sept viennent du plan C15 ; **« Épigénétique » est remplacé par
« Incidence »** : `lex-epigenetique` existe déjà dans `immuno_reponse_t` (UE
d'immunologie), et un second terme du même identifiant écraserait le premier à
l'import. Aucun des huit n'existait (vérifié contre les `lex-*` de tous les
chapitres). Pages mesurées dans le texte de la FC 2025-26 (`chercher_pages.py`,
texte lu avec PyMuPDF), page de plan exclue :

| Terme | Origine | Pages |
|---|---|---|
| Cœliaque | grec κοιλιακός, par le latin coeliacus | 5, 6 |
| Malabsorption | latin male + absorbere | 6, 7 |
| Myocardite | grec μῦς + καρδία + -ῖτις | 4 |
| Entéropathie | grec ἔντερον + πάθος | 7 |
| Neurodéveloppemental | grec νεῦρον + français développement | 8, 9 |
| Hypokaliémie | grec ὑπό + latin moderne kalium + grec αἷμα | 6 |
| Pharmaco-épidémiologie | grec φάρμακον + ἐπιδημία + λόγος | 3, 5 |
| Incidence | latin incidere, par incident | 7, 9 |

`-pathie`, `neur(o)-`, `hypo-` et `épi-` citent la FC de sémantique (1/2 p. 5 et
4 ; 2/2 p. 10 et 9). Les trois racines nouvelles (`male (latin)`,
`kali- (latin moderne)`, `cadere (latin)`) et les huit termes sont proposés à la
table commune dans le brouillon `etym/biostat_pharmacovigilance.json`, vérifiés
sur le Wiktionnaire, le Bailly et le Gaffiot ; les textes du lexique sont déjà
écrits dans la forme que `appliquer_etymologies.py` produirait. Les autres
racines reprennent les clés existantes à l'identique.

## Questions pour Vincent

Le plan C15 ne posait aucune question ouverte sur ce chapitre ; voici les
décisions prises en route, chacune dite sur sa carte :

1. **« Épigénétique » remplacé par « Incidence »** dans le lexique (l'identifiant
   existe déjà en immunologie). Faut-il plutôt un terme d'UE partagé, accueilli
   une seule fois ?
2. **La clé de thème `valproate-paternel`** au lieu du `valproate` du plan : un
   mot que la pharmacologie (BMCT) voudrait pour elle, avec un autre libellé. Et
   le libellé « Interpréter un risque proche de l'unité », sans le chiffre « 1 »
   du plan, qu'un libellé de thème ne peut pas porter (pas « risque relatif » :
   le thème range surtout des hazard ratios).
3. **Le valsartan** : à la lecture de l'IC [0,34 ; 0,95], son RR est
   significativement inférieur à 1, quand le ronéo dit « aucune différence
   notable ». Les cartes le comptent (`pvg-qc-tableau-3` E fausse, zone
   « valsartan ») avec un ATTENTION ; à confirmer quand le ronéo 2026-27 paraîtra.
4. **Les « écarts-types » de la figure de la p. 10** sont classés « point
   douteux » et non « prise de notes » comme dans le plan : la légende de la
   figure ne nomme pas les barres. La carte ne pose aucune proposition dont la
   clé en dépende.
5. **Trois erreurs trouvées en relisant, hors du plan** : la date de la
   Dépakine (« depuis les années 1980 » ; 1967 en réalité, les malformations
   connues depuis 1982), l'olmésartan « à un risque supérieur à 5 » (p. 9 ; RR
   2,34) et la mesure européenne pour les pères datée de 2023 (PRAC, janvier
   2024). Chacune est dite sur sa carte ; aucune ne change une clé.
6. **Un second schéma**, le tableau a, b, c, d, en plus du forest plot du plan ;
   sa version légendée donne l'OR en (a × d) / (b × c), que la diapositive ne
   détaille pas.
7. **L'anecdote en gris de la p. 8** (le laboratoire de l'olmésartan et son
   anticoagulant) n'est reprise que dans l'explication de `pvg-qc-decision`,
   jamais en proposition : d'accord ?

## À relire

**Aucune carte `a-relire`** : chaque carte cite une page de la FC 2025-26, et
les deux clés d'annales ont été vérifiées proposition par proposition, table
relue sur le PDF.

Reste à Vincent :

- quand le ronéo 2026-27 paraîtra, relire chaque carte sur lui et retirer le
  badge « Cours 2025-26 » ;
- `copier_les_cours.py` avec le dossier `…/S1 25-26/examen décembre` du
  Ronéosaure 2025-26, hors du bac à sable, pour que la fiche s'ouvre dans
  l'application ;
- les cinq libellés de thème nouveaux à ajouter à `THEME_LABELS`.

## L'échelle : Simple → Moyen → Annale (C20, 18/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 16 décembre. Sous les annales, 7 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 2 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`).

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `pharmacovigilance` | 4 | 1 | 1 |
| `types-etudes` | 3 | 1 | 1 |

**Le schéma** `ech-pharmacovigilance`, « La pharmacovigilance · alerter, démontrer, décider », donne 12 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_PHARMACOVIGILANCE`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

## Régénérer

```powershell
..\..\..\app\.venv\Scripts\python.exe generer.py
```
