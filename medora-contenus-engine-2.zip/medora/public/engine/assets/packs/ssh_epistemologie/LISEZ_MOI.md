# Épistémologie : la causalité en médecine — paquet SSH

97 notes, 187 cartes. Chapitre `chap-ue-ssh-fc5` de l'UE SSH (identifiant et
nom du squelette, « Epistémologie La causalité en médecine »). Cours du
**Pr Devinant, les 23, 25 et 30/09/2026** (semaines 3 et 4), en trois ronéos ;
deux annales, la question rédactionnelle de 2023/2024 et la QROC 5 du sujet de
2024/2025 (déposé le 15/10/2026). Réaligné le 28/09 sur les
parties 1 et 2, **étendu le 11/10/2026 à la partie 3**, qui finit le cours.

**18/10/2026** : 2 recto-verso du sujet de SSH 2025/2026 (examen du
09/01/2026, sans corrigé) — QROC 3, QROC 5 ; voir « Le sujet 2025/2026 ».

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QROC | 28 | 28 |
| Texte à trous | 16 | 100 |
| QRM | 21 | 21 |
| Recto-verso | 16 | 16 |
| Lexique | 14 | 14 |
| Schéma cliquable | 2 | 8 |

Dont **4 annales** (recto-verso, `ANNALES_QROC`) sur 3 sessions : 2023/2024, 2024/2025 S1 et 2025/2026 S1.
**85 notes citent un ronéo 2026-27** à la page (71 notes de cours et les 14
termes du lexique), 4 sont absentes du cours 2026-27, 4 attendent le ronéo de
l'ED. **15 cartes portent un piège des ronéos** (thème « Pièges des ronéos ») :
13 cartes de cours et 2 annales (QROC 3 et 5 de 2025/2026 S1).

**Deux schémas cliquables** (`schemas.py`), redessinés sans une légende :

| Carte | Schéma | Ce qu'on clique | Pourquoi |
|---|---|---|---|
| `cau-zo-quatre-causes` | `quatre-causes-nu.svg` | la cause matérielle (le bronze), efficiente (le sculpteur), formelle (la statue), finale (le temple) | l'exemple d'Aristote que reprend le cours (partie 1, p. 2) ; formelle et efficiente sont le couple qu'on inverse |
| `cau-zo-koch` | `postulats-koch-nu.svg` | les quatre postulats, dans l'ordre | le premier fait la cause nécessaire, le troisième la cause suffisante (partie 2, p. 2) : c'est la charnière de l'annale |

Huit thèmes, dans l'ordre du cours, tous déjà dans `THEME_LABELS` : histoire de
la notion de cause (`histoire-causalite`), cause nécessaire et suffisante
(`necessaire-suffisante`), théories de la causalité (`theories-causalite`),
modèle monocausal et postulats de Koch (`monocausal`), modèle multifactoriel
(`multifactoriel`), inférence causale (`inference-causale`), valeur des preuves
et critères de Hill (`valeur-preuves`), et, pour la seule carte de la
transition éthique, **le dilemme du tramway (`dilemme-tramway`)**, le thème du
chapitre `ssh_donner_la_mort`, dont le libellé dit vrai ici. Le réalignement
n'ajoute aucun libellé.

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-ssh-causalite-1` et `-2` — Ronéo & Juliette, « Épistémologie _ causalité en médecine 1 » et « 2 » (6 et 6 p., la p. 6 de la partie 2 vide) | **2026-27** | **la base** : 26 notes de la partie 1 et 28 de la partie 2 portent leur page ; `SRC["fiche"]` est la partie 1 |
| `src-fc-ssh-causalite-3` — Ronéo & Juliette, « Causalité en médecine 3 » (6 p.), `SSH/CAUSALITÉ EN MÉDECINE 3.pdf` | **2026-27** | **la partie 3**, 30/09/2026, 9 h-10 h : la valeur des preuves (p. 2-5), la transition vers les débats éthiques (p. 5-6) ; `fiche=C3` ; 17 notes de cours et 4 termes |
| `src-cours-ssh-causalite-2425` — Ronéosaure, FC n°5 (AC) (15 p.) | 2024-25 | appoint ; source des 4 cartes absentes du cours 2026-27 ; sa valeur des preuves (p. 13-15) reste citée en appoint |
| `src-roneo-ssh-causalite-2324` — Charonéo 2023-24 (10 p.) | 2023-24 | appoint : les formules du professeur que les ronéos 2026-27 ont perdues |
| `src-ed-ssh-causalite-2425` — Ronéosaure, ED n°3 de SSH (7 p.) | 2024-25 | 4 cartes d'exercices, **en attente** de l'ED de 2026-27 |
| `src-roneo-ssh-litterature-2324` — Charonéo 2023-24, « Littérature et médecine » (8 p.) | 2023-24 | le roman au programme de l'annale, « Mourir » de Schnitzler (p. 4-5) |
| `src-annales-ssh-causalite` — Ronéosaure, « SSH 5 » (1 p.) | 2024-25 | l'annale de 2023/2024, « Pas de correction » |
| `src-sujets-ssh-2425` — « Sujets de SSH 2024/2025, session 1 » (examen du 10/01/2025, 1 QR et 10 QROC, sans corrigé), déposés le 15/10/2026 | 2024-25 | la source de la session 2024/2025 S1 (`SRC["sessions"]`), la QROC 5 ; déclarée à l'identique dans tous les chapitres de SSH qui en cartent une question |
| errata SSH du Ronéosaure (cours) | 2024-25 | deux entrées sur ce cours, déjà portées par la version numérique lue ici : « projette les réalités » (p. 3), « on ne peut plus dire que le tabagisme est la cause du cancer du poumon » (p. 5) ; la seconde est reprise (`cau-qc-trois-theories` B) |
| errata des annales SSH | 2024-25 | vide pour ce cours |
| tableau d'erreurs SSH 2026-27 (Ronéo & Juliette) | 2026-27 | rien sur la causalité au 11/10/2026 ; au **19/10/2026**, une entrée sur la partie 3 : « Judith Jarvis Thomson » (p. 6), que la ronéo appelle « Judy » |

Lus en appoint, sans être déclarés : la FC n°4 « La causalité en médecine pt 2 »
du Ronéosaure 2025-26 (29/09/2025), dont la partie 3 de 2026-27 reprend presque
mot pour mot la valeur des preuves — c'est elle qui fait classer « cours » ou
« douteux » plusieurs erreurs (voir plus bas) ; la ronéo 2026-27 « Éthique :
donner la mort » (29/09/2026), qui écrit juste les noms du tramway. Les trois
fiches de l'année se copient dans le dossier des PDF de l'application par
`outils/copier_les_cours.py`, lancé avec le dossier des ronéos 2026-27, hors du
bac à sable : **la partie 3 est une fiche nouvelle à copier**.

Les en-têtes des ronéos nomment leurs rédacteurs et leurs correcteurs : aucun
nom n'est repris.

Les vérifications hors du cours sont citées dans la carte qui s'en sert :
l'OMS (porteurs du bacille), CDC (Principles of Epidemiology, les tartes ;
MMWR, la date de 1882 et les postulats de 1884), Rothman et Greenland (AJPH
2005), Mackie (1965), la Stanford Encyclopedia of Philosophy (Aristote,
« Causal Models »), Semmelweis (Antimicrob Resist Infect Control 2018 ;
Epidemiol Infect 2010 ; PMC9209376 ; ses tableaux de 1861), Mailand et
Frederiksen (J Neurol 2017), StatPearls (mésothéliome), la James Lind Library
(l'essai de 1747), Freedman (NEJM 1987), Britannica (Koch, Typhoid Mary),
Walboomers (J Pathol 1999), Chang et Moore (Science 1994, HHV-8),
NobelPrize.org (Koch et le charbon) ; pour la partie 3, **Hill lui-même**
(« The Environment and Disease: Association or Causation? », Proc R Soc Med
1965 : la force, la spécificité, l'analogie, « sine qua non »), Gilbert et al.
(Int J Epidemiol 2005, le couchage des nourrissons), Stolley (Am J Epidemiol
1991, Fisher), la loi n° 2026-794 du 18 août 2026 (FHF ; Vidal, 2026), le
Traité du scorbut de Lind (1753 : les six remèdes, le régime commun) et le
TLFi pour « épistémologiste ».

## L'extension du 11/10/2026 : la partie 3

La troisième séance (30/09/2026) traite **la valeur des preuves**, que le
chapitre attendait depuis le 28/09 : ses neuf cartes citaient le Ronéosaure
2024-25, sans la mention « absent ». Le plan de la ronéo (p. 1) mêle deux
numérotations (« A. Difficultés » et « B. La valeur des preuves » rangés sous
le II) ; le texte, lui, suit l'ordre du cours : I.B la valeur des preuves, II la
transition vers les débats éthiques.

Une seconde relecture (11/10/2026), carte par carte contre les pages de la
partie 3, la FC n°4 du Ronéosaure 2025-26, le Ronéosaure 2024-25, le Charonéo
2023-24 et le texte de Hill (1965), a retiré l'euthanasie « légale » des
erreurs (voir plus bas), ajouté « la vitamine C cause le scorbut » à la liste,
et précisé trois cartes (`cau-qc-lind` C, `cau-qc-criteres-hill` E,
`cau-qr-hill`) et une page du lexique.

**Les neuf cartes qui attendaient, relues sur la partie 3** — elles citent
désormais sa page, et perdent le badge « Cours 2024-25 » :

| Carte | Page | Ce qui a changé |
|---|---|---|
| `cau-fa-theses` | 2 | l'explication cite la partie 3 (« 2 options extrêmes… et une option modérée », « la thèse utilisée aujourd'hui ») ; « pluraliste » reste le mot de 2024-25, dit comme tel |
| `cau-qc-theses` | 2 | chaque justification cite la partie 3 ; la clé ne change pas |
| `cau-fa-hill` | 4 | l'ordre et les noms sont ceux de la ronéo (« stabilité / fiabilité ») ; illustré par le nouveau schéma des critères |
| `cau-qc-hill` | 4 | A-D citent la partie 3 ; E (la spécificité du tabac) reste du cours de 2024-25, dit comme tel, avec la « spécificité dans l'ampleur » de Hill |
| `cau-qr-lind` | 3 | l'ATTENTION nu devient **ATTENTION (cours)** (la partie 3 redit le « premier essai contrôlé randomisé »), et gagne un **ATTENTION (douteux)** sur l'essai à deux groupes |
| `cau-qr-fisher` | 4 | l'explication suit la partie 3 (l'essai randomisé impossible) |
| `cau-qr-hill` | 4 | **ATTENTION (douteux)** : Hill « épistémologiste » |
| `cau-qr-temporalite` | 5 | la phrase du cours sur la « force probante » de la temporalité |
| `cau-rv-fisher-hill` | 4 | le verso gagne les freins socio-économiques et l'essai impossible ; « faire arrêter de fumer » est dit du cours de 2024-25 |

**Notes nouvelles (8, et 5 termes)**, sur ce que la partie 3 apporte :

| Note | Ce qu'elle carte |
|---|---|
| `cau-qc-lind` | Lind, le HMS Salisbury, 1747, le « premier essai contrôlé randomisé » du cours, la vitamine C inconnue (p. 3) |
| `cau-qc-mecaniste` | les arguments de la thèse mécaniste, les essais éthiquement impossibles, l'anti-EBM, le couchage des nourrissons (p. 3) |
| `cau-qc-controverse-tabac` | la controverse de la fin des années 1950 : les preuves, les freins, Fisher, l'essai impossible (p. 4) |
| `cau-qc-criteres-hill` | les définitions de la force, de la stabilité, de la spécificité, de la plausibilité ; les critères ne sont pas tous requis (p. 4-5) |
| `cau-fa-hill-definitions` | les neuf définitions du cours, chacune pour retrouver son critère (p. 4-5) |
| `cau-qr-boite-noire` | le paradigme de la boîte noire, avec la figure de la ronéo (p. 2) |
| `cau-qr-nourrissons` | l'exemple d'un raisonnement mécaniste démenti par les statistiques (p. 3) |
| `cau-rv-transition-ethique` | l'euthanasie, les 40 % de médecins, le problème du tramway (p. 5-6) |
| `lex-epistemologie`, `lex-plausibilite`, `lex-teratogene-ssh`, `lex-antiemetique`, `lex-regurgitation` | cinq termes du lexique (voir plus bas) |

**Ce que la partie 3 dit autrement que le cours de 2024-25** : l'exemple du
couchage des nourrissons (nouveau) ; les essais irréalisables pour raisons
éthiques, dans la thèse mécaniste (le professeur le disait en 2023-24) ; Fisher
« grand fumeur » et l'essai impossible ; des exemples pour la stabilité (le
Nevada, la Chine, la Bulgarie), la spécificité (un colorant et un cancer
colorectal) et l'analogie (les antiémétiques) ; la temporalité, « le seul
critère qui a une force probante ». La conclusion de 2024-25 (« faire arrêter
les gens de fumer ») n'y est pas : la carte qui la porte le dit.

**La transition vers les débats éthiques** (p. 5-6) n'a qu'une carte ici
(`cau-rv-transition-ethique`, thème `dilemme-tramway`) : le tramway est le
sujet du cours « Éthique : donner la mort » du 29/09/2026, et du chapitre
`ssh_donner_la_mort`.

## Ce que le cours a dicté

- **Le format de l'examen**, « 10 QROC + 1 QR » (Histoire de la médecine,
  partie 1, p. 7) : un chapitre de QROC, de textes à trous et de recto-verso ;
  les QCM portent les pièges.
- **Le gris.** Aucune des trois ronéos ne le définit ; c'est la voix des
  rédacteurs, cartée comme le reste : la citation de Russell (partie 1, p. 3),
  « à retenir, car c'est fonctionnel en médecine » pour l'INUS (p. 5), le bloc
  « À retenir » (p. 6), « une causalité est une corrélation » (partie 2, p. 2),
  « et absents chez les non malades » (p. 2). La partie 3 n'a pas de gris.
- **Le rouge de la partie 3** : « impossibilité d'expliquer pourquoi A cause
  B » (p. 2 : `cau-qc-theses` B, `cau-qr-boite-noire`) et les noms des neuf
  critères de Hill (p. 4-5 : `cau-fa-hill`, `cau-fa-hill-definitions`,
  `cau-qc-criteres-hill`). Chacun a sa carte.
- **À retenir, dit le cours** (partie 1, p. 3 et 6) : le doute sur la notion
  de cause ; l'orientation temporelle et la nécessité ; nécessaire et
  suffisante ; les trois théories, dont l'INUS, « celui qui fonctionne le mieux
  aujourd'hui en médecine ». Chacun a sa carte et son texte à trous.
- **Les ajouts du début de la deuxième séance** (partie 2, p. 2) : corrélation
  et causalité (`cau-qc-correlation`), l'INUS et Rothman
  (`cau-rv-inus-rothman`).
- **Les figures** : les tartes de Rothman (partie 1, p. 6), en correction de six
  cartes ; la boîte noire (partie 3, p. 2), en correction de
  `cau-qr-boite-noire`. Le mème de la partie 1 et les bandeaux ne sont pas
  repris.

## Ce que les annales ont dicté

Deux questions, rédactionnelles. La QR de 2023/2024 sur l'annonce de Koch.
Elle traverse tout le cours : la tuberculose, les postulats, le modèle
monocausal, ses limites (porteurs sains, INUS, multifactoriel), et le roman au
programme. Chacun de ces savoirs a aussi ses cartes du cours — le schéma
cliquable des postulats, `cau-fa-koch`, `cau-rv-postulats-logique`,
`cau-qc-porteurs-sains`, `cau-rv-porteurs-sains` —, pour qu'on sache répondre
avant d'avoir vu la question.

La QROC 5 de 2024/2025 (sujet déposé le 15/10/2026, sans corrigé) : décrire le
modèle INUS et l'appliquer à un ulcère dû à Helicobacter pylori associé à une
hyperacidité gastrique. Le modèle est celui du cours (partie 1, p. 5-6 ; partie 2,
p. 3), carté par `cau-fa-inus`, `cau-qc-inus`, `cau-qr-mackie`, `cau-rv-inus` ;
l'exemple de l'ulcère n'est dans aucun cours lu (2023-24 à 2026-27) : la carte
applique la définition, et dit hors cours, avec leur source, les faits sur la
bactérie (prix Nobel 2005).

## Les erreurs des ronéos 2026-27

Chacune est dite par un **ATTENTION** de son genre, dans la carte où la notion
se joue ; la carte retient la bonne lecture, ou, quand c'est le cours lui-même,
répond comme le professeur et donne la référence (règles de Vincent, 26 et
28/09).

**Parties 1 et 2** (relevées le 28/09, déjà dans
`contenu/ERRATA_RONEOS_2026-27.md`) :

| Page | La ronéo dit | Genre | Retenu | Carte |
|---|---|---|---|---|
| 1, p. 6 | retirer « un élément quelconque » d'une tarte fait disparaître la maladie | prise de notes | seul un élément présent dans toutes les tartes, la cause nécessaire ; une composante ne bloque que sa voie (CDC ; Rothman et Greenland 2005) | `cau-qc-rothman` D |
| 2, p. 2-3 | « théorie INOS », « modèle Rottman », « modèle INOS » | prise de notes | INUS (Mackie, 1965), Rothman (1976), écrits juste en partie 1 | `cau-rv-inus-rothman` |
| 2, p. 4 | Semmelweis et le lavage des mains « en chirurgie » | prise de notes | en obstétrique, clinique d'accouchement de Vienne, 15 mai 1847 ; l'antisepsie chirurgicale, c'est Lister (1867) | `cau-qc-semmelweis` B |
| 2, p. 5 | la polémique hépatite B - SEP due à « l'oubli de la non-transitivité » | prise de notes | le paralogisme post hoc ; la non-transitivité, c'est le VIH et le Kaposi (Ronéosaure 2024-25, p. 12) | `cau-qc-orientation` C |
| 2, p. 2 | le monocausal « s'impose au milieu du XIXᵉ », le multifactoriel « à partir du XXᵉ » | douteux | apogée au XIXe (Koch 1882-1884), multifactoriel dans la seconde moitié du XXe (2024-25 : fin XIXe ; années 1950-60) | `cau-qc-modeles` C |
| 2, p. 4 | Semmelweis conclut à « un MO passant dans le sang » | douteux | des « particules cadavériques » ; aucun germe identifié ; le professeur disait déjà « germes » en 2024-25 | `cau-qc-semmelweis` E |
| 2, p. 4 | « les nouveaux-nés n'étaient pas atteints » | douteux | ils l'étaient (7,6 % contre 3,8 %), par transmission secondaire, nuance que le professeur donnait en 2024-25 | `cau-rv-semmelweis` |
| 2, p. 4 | « si A cause B et que B cause C, A ne cause pas C » | douteux | on ne peut pas **conclure** que A cause C (2024-25 : « ≠ ») | `cau-qc-orientation` B |

**Partie 3** (relevées le 11/10/2026, à porter dans la liste) :

| Page | La ronéo dit | Genre | Retenu | Carte |
|---|---|---|---|---|
| 3, p. 3 | Lind publie l'essai « en 1947 » | prise de notes | essai commencé le 20 mai 1747, publié en 1753 (Traité du scorbut) ; la ronéo dit « en 1747 » quelques lignes plus bas (James Lind Library) | `cau-qc-lind` B |
| 3, p. 3 | Lind, « le premier essai contrôlé randomisé de toute l'histoire de la médecine occidentale » | **cours** | à l'examen, la formule du cours (2023-24 à 2026-27) ; la référence : un essai contrôlé, non randomisé ; le premier essai randomisé moderne est celui de la streptomycine (MRC, 1948) | `cau-qr-lind`, `cau-qc-lind` C |
| 3, p. 3 | l'essai de Lind : « des agrumes à un groupe… le régime habituel à un autre », « une différence significative » | douteux | six remèdes chez douze malades, deux par remède, aucun test statistique (James Lind Library) ; la ronéo 2025-26 dit la même chose, le professeur décrivait juste en 2023-24 et 2024-25 | `cau-qr-lind` |
| 3, p. 3 | « si on sait pourquoi la vitamine C cause le scorbut » (la thèse mécaniste) | prise de notes | c'est sa **carence** qui le cause, comme la ronéo l'écrit quelques lignes plus haut ; le professeur disait en 2023-24 « pourquoi manger des agrumes protège du scorbut » (Charonéo, p. 8) ; la vitamine C est le cofacteur des hydroxylases du collagène (StatPearls, « Vitamin C Deficiency ») | `cau-qc-mecaniste` A |
| 3, p. 3 | « toucher les bébés sur le ventre pour éviter les régurgitations » | prise de notes | les **coucher** sur le ventre, pour qu'ils n'inhalent pas ce qu'ils régurgitent ; les statistiques montraient un risque de mort inattendue environ trois fois plus grand (Gilbert et al., Int J Epidemiol 2005) | `cau-qc-mecaniste` E |
| 3, p. 4 | Bradford Hill, « épistémologiste » | douteux | épidémiologiste et statisticien médical (LSHTM ; essai de la streptomycine) ; la ronéo 2025-26 dit la même chose, le cours de 2023-24 « deux grandes figures de la statistique » | `cau-qr-hill` |
| 3, p. 4 | la force « est estimée avec la prévalence » | **cours** | à l'examen, la formule du cours (2023-24 à 2026-27) ; la référence : Hill compare exposés et non-exposés par le rapport des taux, 9 à 10 fois, 20 à 30 fois chez les grands fumeurs (Proc R Soc Med 1965) | `cau-qc-criteres-hill` A |
| 3, p. 5 | « on connaît les effets tératogènes des antiémétiques » (l'analogie) | douteux | l'exemple de Hill : la thalidomide et la rubéole (Proc R Soc Med 1965) ; la ronéo a pu réduire « la thalidomide, un antiémétique » | `cau-fa-hill-definitions` |
| 3, p. 5 | « il faut avoir tous les critères réunis… chaque critère ne suffit pas à lui seul pour prouver la corrélation » | prise de notes | aucun n'est requis comme condition sine qua non (Hill 1965) ; leur accumulation renforce le lien (Ronéosaure 2024-25, p. 15), et tous ensemble donnent « une très forte raison de croire », pas une condition (Charonéo 2023-24, p. 10) ; la ronéo se contredit (la temporalité, seule à exclure) ; et c'est la causalité qu'ils établissent | `cau-qc-criteres-hill` E |
| 3, p. 6 | « Phillipa Foot », « troléologie » | prise de notes | Philippa Foot (1967), trolléologie, écrits juste dans la ronéo d'éthique du 29/09/2026, p. 2 | `cau-rv-transition-ethique` |
| 3, p. 6 | « Judy Jarvis Thomson » — **tableau de la promo, 19/10/2026** | prise de notes | Judith Jarvis Thomson, le nom sous lequel elle publie (The Monist 1976 ; Yale Law Journal 1985) et que la ronéo d'éthique du 29/09/2026 écrit (p. 2) ; « Judy » est son diminutif (MIT News, 2020) | `cau-rv-transition-ethique` |

Le gris « une causalité est une corrélation » (partie 2, p. 2) n'est **pas**
une erreur de la ronéo : il redit la définition du professeur, écrite juste
au-dessus (« une corrélation qui implique qu'un élément A soit responsable d'un
événement B »), et le critère de l'augmentation de probabilité du cours y
conduit. `cau-qc-correlation` D en garde la nuance, dite « hors cours », sans
ATTENTION (Stanford Encyclopedia of Philosophy, « Causal Models »).

Et, sans ATTENTION, des nuances dites dans la carte : Banting et Best
rattachés à la « fin du XIXe » (Ronéosaure 2024-25, p. 9 ; 1921,
`cau-qr-banting`) ; un tiers de porteurs et 10 % de malades (2024-25) contre un
quart et 5 à 10 % (2026-27, OMS) ; la controverse du tabac dite « américaine »
(partie 3, p. 4), quand Fisher et Hill étaient britanniques
(`cau-qc-controverse-tabac`) ; Fisher « statisticien et épistémologiste »,
statisticien et généticien (`cau-qr-fisher`) ; « Judy » Jarvis Thomson, que
la carte nomme Judith, comme la ronéo d'éthique (`cau-rv-transition-ethique`).

« Désormais, l'euthanasie est quelque chose de légal (loi d'août 2026) »
(partie 3, p. 5) n'est **pas** une erreur de la ronéo (relecture du
11/10/2026) : la loi n° 2026-794 du 18 août 2026 (JO du 19 août) crée un
« droit à l'aide à mourir » où la personne s'administre la substance létale ou,
si elle n'en est pas physiquement capable, se la fait administrer par un
médecin ou un infirmier — une euthanasie au sens du cours, même si le texte
n'emploie pas le mot ; le professeur parle lui-même de « la loi sur la
légalisation de l'euthanasie et l'aide à mourir » (ronéo d'éthique du
29/09/2026, p. 5). `cau-rv-transition-ethique` en donne la précision, sans
ATTENTION, et rappelle que les décrets d'application sont attendus (FHF ;
Vidal, 2026).

## Les autres ATTENTION (hors ronéo 2026-27)

| Carte | Ce qui est dit | Retenu |
|---|---|---|
| `cau-rv-equipoise` | l'ED 2024-25 définit l'équipoise comme la certitude qui dispense de tester | c'est sa rupture ; l'équipoise est l'incertitude réelle qui rend l'essai acceptable (Freedman, NEJM 1987) |
| `cau-qc-dbcp` | l'ED 2024-25 : au-dessus d'un odds ratio de 4, « un lien causal sûr » | aucun seuil ne rend un lien causal certain (Rothman et Greenland 2005) |
| `cau-an-2324-qr` | l'énoncé : annonce de Koch « le 22 mars 1882 » | le 24 mars 1882 (CDC, MMWR ; Britannica) ; l'énoncé reste tel qu'imprimé |
| `cau-qr-charbon` | le cours de 2023-24 et 2024-25 : Koch cultive « l'humeur vitrée » d'yeux de bovins « malades » | l'œil ne donnait que le milieu de culture, l'humeur aqueuse ; le bacille venait des animaux morts du charbon (Koch, 1876 ; NobelPrize.org) ; la ronéo 2026-27 ne le dit plus |

Le « premier essai contrôlé randomisé » de Lind, qui figurait ici, est passé
dans le tableau des erreurs 2026-27 : la partie 3 le redit (ATTENTION (cours)).

## Le sujet 2025/2026 (18/10/2026)

Les sujets de SSH de l'examen du 09/01/2026 (1 QR, 10 QROC,
`src-sujets-ssh-2526`, sans corrigé), déposés le 18/10/2026, apportent 2
recto-verso à ce chapitre (QROC 3, QROC 5). Aucun n'était déjà en cartes. Au
verso, la bonne réponse, tirée du ronéo 2026-27 quand il couvre la notion,
sinon du cours 2025-26, celui de l'année de l'examen ; ce qui dépasse le cours
est dit « hors cours », avec sa source (`officielle=False`). Rédigés et
contre-vérifiés le 18/10/2026 : un rédacteur, un sceptique, un critique de
complétude.

| Question | Ce que le verso répond | Voisine de |
|---|---|---|
| 2025/2026 S1 QROC 3 (`cau-an-2526s1-qroc3`) | le « cancer gay » : le sarcome de Kaposi et l'émergence du sida en 1981 ; la non-transitivité : VIH → immunodépression → HHV-8 → Kaposi, une chaîne et non une cause directe | — |
| 2025/2026 S1 QROC 5 (`cau-an-2526s1-qroc5`) | le cannabis n'est ni nécessaire ni suffisant ; une condition INUS, une part de certaines tartes de Rothman ; une cause contributive chez les sujets vulnérables | `cau-an-2425s1-qroc5` |

Ce qui est signalé :

- La QROC 3, à double rubrique (« Histoire de la médecine & épistémologie »),
  est rangée ici, avec le schéma de la chaîne VIH - Kaposi ; sa première
  moitié cite le cours sur le sida (FC n°11 2025-26). ATTENTION nu sur le New
  York Times de « juin 1981 » (le 3 juillet 1981) ; ATTENTION (douteux) sur la
  non-transitivité écrite « A ne cause pas C » (causalité 2, p. 4) : carte
  ajoutée à la ligne de `cau-qc-orientation` de la liste des erreurs, section
  des points douteux.
- La QROC 5, le cannabis et la schizophrénie, voisine de 2024/2025 S1 QROC 5
  (l'ulcère à Helicobacter pylori) : le cannabis n'est dans aucun cours lu,
  l'application suit les définitions. ATTENTION (prise de notes) sur les
  tartes de Rothman (« un élément quelconque », causalité 1, p. 6) : carte
  ajoutée à la ligne de `cau-qc-rothman` de la liste des erreurs.
- Les numéros imprimés sont 1, 2, 3, 5, 4, 6… : la QROC 5 précède la QROC 4 dans
  le sujet ; numéros gardés.

## Les clés qui ne sont pas reprises telles quelles

Les annales ne sont pas des QCM : `CONFLITS` est vide. Ni le polycopié (« Pas de
correction ») ni le sujet de 2024/2025 ne donnent **aucune correction** : aucune
carte n'est officielle, et leur explication commence par « Clé déduite du cours ».

| Question | Corrigé imprimé | Retenu | Pourquoi |
|---|---|---|---|
| 2023/2024 QR (Koch, tuberculose, Schnitzler) | aucun | tuberculose ; postulats ; modèle monocausal ; limites (porteurs sains, INUS) ; « Mourir » : le professeur Bernard, la médecine qui sait mais ne peut pas | ronéos 2026-27 (partie 2, p. 2-3) ; Charonéo 2023-24, « Littérature et médecine » (p. 4-5) |
| 2024/2025 S1 QROC 5 (INUS, ulcère à H. pylori) | aucune (sujet sans corrigé) | la définition et l'étincelle ; H. pylori et l'hyperacidité, conditions INUS d'un ensemble suffisant non nécessaire ; la bactérie insuffisante (porteurs sans ulcère) mais nécessaire dans l'ensemble | ronéos 2026-27 (partie 1, p. 5-6 ; partie 2, p. 3) ; l'exemple, absent des cours, est une application de la définition |

Cas ouvert : le roman. « Mourir » était le livre de 2023-24 ; celui de 2026-27
est « Le Lambeau » de Philippe Lançon (Vincent, 29/09). La seconde moitié du
verso sera récrite sur lui quand le cours qui le présente sera en cartes.

Dans les QCM du cours, deux propositions répondent **comme le professeur**, la
clé restant officielle, parce que c'est le cours lui-même : `cau-qc-lind` C
(« premier essai contrôlé randomisé ») et `cau-qc-criteres-hill` A (la force
« estimée avec la prévalence ») ; leur ATTENTION (cours) donne la référence.

## Absent du cours 2026-27

Quatre cartes n'ont **pas de version 2026-27** et le disent, en tête de leur
explication. Elles citent la FC n°5 2024-25 à sa page. La partie 3 n'en
reprend aucune : elle ne traite que la valeur des preuves et la transition
éthique, et les parties 1 et 2 couvraient en entier les sections d'où elles
viennent.

| Carte | Ce qui manque aux ronéos 2026-27 | Source restée |
|---|---|---|
| `cau-rv-etymologie` | causa, aitia, étiologie, le sens juridique | Ronéosaure 2024-25, p. 4 ; Charonéo 2023-24, p. 3 |
| `cau-qr-drepanocytose` | l'exemple génétique du modèle monocausal | Ronéosaure 2024-25, p. 7 ; Charonéo 2023-24, p. 5 |
| `cau-qr-typhoid-mary` | Typhoid Mary et la série The Knick | Ronéosaure 2024-25, p. 9-10 |
| `cau-qr-epistemique-realiste` | les noms « épistémique » et « réaliste » des deux conceptions | Ronéosaure 2024-25, p. 10-11 |

Détails de 2024-25 et 2023-24 gardés **dans des explications** de cartes par
ailleurs relues, et dits comme tels : la mécanique quantique (`cau-qc-doutes`),
la causalité individuelle et générique chez Russell (`cau-fa-hume-russell`),
l'expérience du charbon, corrigée (`cau-qr-charbon`), le rôle de vérification des
postulats 2 et 4 (`cau-rv-postulats-logique`, `cau-fa-koch`), les maladies
chroniques du modèle multifactoriel (`cau-fa-multifactoriel`), le tabac qui
n'est plus une cause sous le seul critère de suffisance (`cau-qc-trois-theories`
B), la spécificité du tabac (`cau-qc-hill` E), « pluraliste »
(`cau-fa-theses`), « faire arrêter de fumer » (`cau-rv-fisher-hill`). Les
instituts Pasteur (Ronéosaure, p. 9) n'ont pas de carte.

## En attente des ronéos suivantes

Quatre cartes viennent de **l'ED n°3 de SSH de 2024-25**, sur la causalité.
L'ED de 2026-27 sur ce cours n'a pas encore de ronéo (le dossier des ED
2026-27 ne tient, en SSH, que « Éthique et droit ») : elles ne sont **pas**
« absentes », gardent leur badge « Cours 2024-25 » et seront relues sur lui.
`EN_ATTENTE` les liste dans `donnees.py`.

| Carte | Ce qu'elle carte | Source |
|---|---|---|
| `cau-qc-dbcp` | les critères de Hill appliqués au DBCP | ED 2024-25, p. 2-4 |
| `cau-qc-erreurs-lecture` | inversion, troisième facteur, affirmation du conséquent, négation de l'antécédent | ED 2024-25, p. 5-6 |
| `cau-qr-hasard` | le hasard, rencontre de séries causales indépendantes | ED 2024-25, p. 5 |
| `cau-rv-equipoise` | le principe d'équipoise | ED 2024-25, p. 4 |

S'il n'y a pas d'ED de causalité cette année, elles passeront dans
`ABSENTS_2026`.

## Les illustrations

**17 QCM sur 21 illustrés (81 %)**, 50 notes sur 97, toujours du côté de la
correction.

| Fichier | D'où | Cartes |
|---|---|---|
| `rothman-tartes.png` | la figure du ronéo, partie 1, p. 6 (extraite, passée en gris, réduite de moitié : 190 → 33 Ko) | `cau-fa-rothman`, `cau-qc-rothman`, `cau-qc-porteurs-sains`, `cau-qr-rothman`, `cau-qr-rothman-necessaire`, `cau-rv-inus-rothman` |
| `boite-noire-roneo.png` | **la figure du ronéo, partie 3, p. 2** (extraite à 150 dpi, en gris : 1,3 Ko) | `cau-qr-boite-noire` |
| `quatre-causes.svg` (et `-nu` pour le clic) | redessiné, partie 1, p. 2 | `cau-fa-quatre-causes`, `cau-qc-quatre-causes`, `cau-zo-quatre-causes` |
| `postulats-koch.svg` (et `-nu` pour le clic) | redessiné, partie 2, p. 2 | `cau-fa-koch`, `cau-qc-modeles`, `cau-qc-koch`, `cau-rv-postulats-logique`, `cau-zo-koch`, `cau-an-2324-qr` |
| `necessaire-suffisante.svg` | redessiné, partie 1, p. 4 | `cau-fa-piliers`, `cau-qc-necessaire-suffisante`, `cau-qr-hpv`, `cau-qr-iode` |
| `inus-flamme.svg` | redessiné, partie 1, p. 5 | `cau-fa-inus`, `cau-qc-inus`, `cau-rv-inus`, `cau-an-2425s1-qroc5` |
| `troisieme-facteur.svg` | redessiné, partie 1, p. 5 (et Fisher, partie 3, p. 4) | `cau-qc-trois-theories`, `cau-qc-correlation`, `cau-qc-hill`, `cau-qc-controverse-tabac`, `cau-qc-erreurs-lecture`, `cau-qr-troisieme-facteur`, `cau-qr-fisher`, `cau-rv-fisher-hill` |
| `chaine-kaposi.svg` | redessiné, partie 2, p. 5 | `cau-qc-orientation`, `cau-qr-kaposi`, `cau-rv-kaposi` |
| `post-hoc.svg` | redessiné, partie 2, p. 4-5 | `cau-fa-post-hoc`, `cau-qr-post-hoc` |
| `boite-noire.svg` | redessiné, partie 3, p. 2-3 (Lind, la thèse mécaniste) | `cau-fa-theses`, `cau-qc-theses`, `cau-qc-lind`, `cau-qr-lind` |
| `criteres-hill.svg` | **nouveau** : les neuf critères dans l'ordre, la temporalité à part, partie 3, p. 4-5 | `cau-fa-hill`, `cau-fa-hill-definitions`, `cau-qc-criteres-hill`, `cau-qr-hill`, `cau-qr-temporalite` |
| `couchage-nourrisson.svg` | **nouveau** : le mécanisme contre les statistiques, partie 3, p. 3 (et Gilbert 2005) | `cau-qc-mecaniste`, `cau-qr-nourrissons` |

Les QCM sans figure : `cau-qc-doutes`, `cau-qc-multifactoriel`,
`cau-qc-semmelweis`, `cau-qc-dbcp` — le cours n'a rien à montrer là.

## Le lexique

Quatorze termes, chacun avec son **origine grecque ou latine** dans la
définition et dans ses racines ; pages mesurées dans le texte des trois ronéos
2026-27 (texte extrait par PyMuPDF ; les pages où le mot n'est que dans
l'en-tête ne sont pas comptées) :

| Terme | Origine | Pages (partie, page) |
|---|---|---|
| Causalité | latin causalitas, de causa | 1 p. 2-6 ; 2 p. 2-5 ; 3 p. 2, 3, 5 |
| Corrélation | latin correlatio (co- + relatio) | 1 p. 5 ; 2 p. 2, 4 ; 3 p. 4, 5 |
| Inférence causale | latin inferre + causa | 2 p. 1, 3 ; 3 p. 1, 2, 4, 5 |
| Paralogisme | grec paralogismos | 2 p. 4 |
| Anthropomorphique | grec anthrôpomorphos | 1 p. 3 |
| Asymptomatique | grec a- + sumptôma | 2 p. 3 |
| Fièvre puerpérale | latin febris + puerpera | 2 p. 4 |
| Mésothéliome | grec mesos + thêlê + -ome | 2 p. 4 |
| Épidémiologie | grec epidêmia + logos | 1 p. 6 ; 3 p. 4 |
| **Épistémologie** | grec epistêmê + logos | 1 p. 1, 3, 5 ; 2 p. 1 ; 3 p. 4 |
| **Plausibilité** | latin plausibilis, de plaudere | 3 p. 5 |
| **Tératogène** (`lex-teratogene-ssh`) | grec teras + -genês | 3 p. 5 |
| **Antiémétique** | grec anti + emetikos | 3 p. 5 |
| **Régurgitation** | latin re- + gurges | 3 p. 3 |

Aucun ne double le lexique d'un autre chapitre de SSH. « Tératogène » prend
l'identifiant `lex-teratogene-ssh`, `lex-teratogene` étant une note de la BMCP
(`bmcp_lipides`), comme la virologie a pris `lex-teratogene-viro`. **Quatre
racines sont enseignées par la FC de sémantique** : le privatif `a-/an-`
(sémantique 1, p. 3), `épi-` (sémantique 2, p. 9), `térat(o)-` et `-gène`
(sémantique 1, p. 6) ; les autres s'affichent en gris, « hors FC ». Les
étymologies nouvelles (cinq termes, trois racines : `emetikos (grec)`,
`plausibilis (latin)`, `gurges (latin)`), vérifiées sur le TLFi (API cnrtl.fr),
le Wiktionnaire, le Bailly et le Gaffiot, sont proposées dans
`etym/ssh_epistemologie.json` du brouillon, à fusionner dans
`scripts/etymologies.json` ; elles sont déjà écrites dans `LEXIQUE`, au format
qu'`appliquer_etymologies.py` produit, qui ne les touchera pas deux fois.

## À relire

**0 carte `a-relire`** : chaque note cite une page — des ronéos 2026-27 (71
notes du cours et les 14 termes), du Ronéosaure 2024-25 (4, absentes) ou de
l'ED 2024-25 (4, en attente) — et les deux annales disent d'où vient leur réponse. Reste à
Vincent :

- un ED de causalité en 2026-27 ? Ses quatre cartes l'attendent ; sans lui,
  elles passent « Absent du cours 2026-27 ».
- les diapositives du professeur trancheraient les trois points douteux de la
  partie 3 (l'essai de Lind à deux groupes, Hill « épistémologiste », les
  antiémétiques) et ceux des parties 1 et 2.
- le tableau d'erreurs SSH 2026-27 ne relève, sur la causalité, que le prénom de
  Thomson (19/10) : y signaler Lind « en 1947 », « la vitamine C cause le scorbut », « toucher les bébés »,
  « tous les critères réunis », « Phillipa Foot », et les erreurs des parties 1
  et 2 ?
- la partie 3 est une fiche nouvelle : la copier dans le dossier des PDF de
  l'application (`outils/copier_les_cours.py`, hors du bac à sable).

## L'échelle : Simple → Moyen → Annale (C20, 19/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 5 janvier (BMCP) ou du 6 janvier (SSH, papier). Sous les annales, 19 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 4 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`) ; les QROC reçoivent le schéma nu.

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `theories-causalite` | 8 | 2 | 2 |
| `monocausal` | 7 | 1 | 1 |
| `inference-causale` | 4 | 1 | 1 |

**Le schéma** `ech-causalite`, « La causalité en médecine · conditions, modèles, chaînes », donne 24 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_CAUSALITE`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Constantes ajoutées** à `annales.py` (`_SCHEMA_LETTRES`, `_SCHEMA_NU`) : les annales de SSH sont toutes des QROC, rangées dans `ANNALES_QROC` ; chacune reçoit le schéma nu, et les marches la préparent sans lettre.

**Sans marche** :
- cau-an-2526s1-qroc3, première moitié (le lien fait entre sida et cancer au début des années 1980) : ses faits viennent du cours sur le sida (FC n°11 2025-26), qui n'est pas une source de ce chapitre ; seule la seconde moitié (non-transitivité, chaîne VIH - Kaposi) a ses marches.
- cau-an-2324-qr, seconde moitié (le roman « Mourir » de Schnitzler) : livre du programme 2023-24, absent du cours 2026-27 (« Le Lambeau » cette année) ; pas de marche.
- cau-an-2425s1-qroc5 et cau-an-2526s1-qroc5, les faits sur H. pylori et le cannabis : hors cours, pas de marche ; seuls les modèles (nécessaire, suffisante, INUS, Rothman) sont préparés.

## Régénérer

```powershell
..\..\..\app\.venv\Scripts\python.exe generer.py
```

## Questions pour Vincent

- (11/10) Y aura-t-il un ED de causalité en 2026-27 ? Le dossier des ED SSH ne contient que « Éthique et droit ». Quatre cartes de l'ED n°3 de 2024-25 l'attendent (DBCP, erreurs de lecture, hasard, équipoise). Sans lui, elles passent « Absent du cours 2026-27 ».
- (11/10) As-tu les diapositives du Pr Devinant ? Elles trancheraient les trois points douteux de la partie 3 : l'essai de Lind à deux groupes, Hill (et Fisher) « épistémologiste », les antiémétiques « tératogènes ».
- (11/10) La transition éthique (l'euthanasie, les 40 % de médecins, le tramway) n'a ici qu'une carte, cau-rv-transition-ethique, sous le thème dilemme-tramway. On la garde, ou on laisse le tramway au seul chapitre « Éthique : donner la mort » ?
- (11/10) Faut-il signaler au tableau d'erreurs SSH de la promo, qui ne dit rien de la causalité, ces cinq points : Lind « en 1947 », « la vitamine C cause le scorbut », « toucher les bébés sur le ventre », « tous les critères réunis » et « Phillipa Foot » ?
