# Insuline — paquet BMCP

97 notes, 232 cartes. Deuxième chapitre du bloc biochimie de l'UE **BMCP**,
Pr Pigny, cours du 23/09/2026 (semaine 3, 8 h 30-10 h). C'est le chapitre le
mieux servi en annales de tout le bloc : **dix-huit QCM sur onze sessions**, plus
un QROC, et deux QCM du sujet de 2024/2025. Cinq sources :

- **les deux ronéos 2026-27** (Ronéo & Juliette), qui font foi :
  partie 1, 6 pages (`src-fc-bmcp-insuline-1` : actions de l'insuline, le
  récepteur et ses deux voies, arrêt du signal) et partie 2, 10 pages
  (`src-fc-bmcp-insuline-2` : insulinorésistance, exploration, syndrome
  métabolique, moyens de correction) ;
- le ronéo 2024-25 (Ronéosaure, FC n°2, 12 pages, `src-cours-insuline`), sur
  lequel le chapitre avait été bâti ;
- le polycopié d'annales (11 sessions, 18 QCM et 1 QROC) et l'errata du
  Ronéosaure ;
- le sujet de l'examen du 09/01/2025 (`src-sujets-bmcp-2425`, « Sujets de BMCP
  2024/2025, session 1 », 30 p.), déposé le 15/10/2026 **sans corrigé** : ses
  Q. 15 et Q. 16, du Pr Pigny. Elles le citent par `SRC["sessions"]`, comme
  les autres chapitres de BMCP ; la source est déclarée à l'identique dans tous
  les chapitres de BMCP qui en cartent une question.

| Type | Notes | Cartes | Ce que c'est |
|---|---|---|---|
| `qrm` | 24 | 24 | 20 QCM d'annales (18 du polycopié, 2 du sujet 2024/2025), les 2 quizz du ronéo 2024-25, les 2 quiz du cours 2026-27 |
| `cloze` | 28 | 148 | les seuils et les cascades qui se récitent |
| `basic` | 26 | 26 | les couples à ne pas inverser |
| `qroc` | 17 | 17 | 16 questions du cours, 1 QROC d'annales |
| `zone` | 2 | 17 | les deux schémas cliquables |

## Relu sur le cours de l'année (28/09/2026)

Chaque note a été relue contre les deux ronéos 2026-27, texte et figures. Même
enseignant ; le cours tient maintenant en deux ronéos (16 pages contre 12), et il
a bougé. Une note vérifiée porte la page de ce ronéo (`page`, et `fiche=P2` pour
la partie 2) : sa source devient la fiche de l'année à cette page, et pour une
annale, cette page devient la source secondaire. Une note sans page garde le
ronéo 2024-25 pour source : ce sont les cinq de la section « Absent du cours
2026-27 ». **Aucune note n'a été retirée, aucun identifiant ni aucun type n'a
changé, aucune clé d'annale n'a bougé.** Quatorze notes sont nouvelles.

Les textes à trous réécrits gardent au moins leur nombre de trous (chaque trou
est une carte) ; `ins-fa-23` en gagne deux (surpoids, obésité). La carte de zone
`ins-zo-hpo` garde ses six zones dans le même ordre et en gagne une (voir « Les
deux schémas »).

Ce qui a changé dans le cours, et ce que les cartes en font :

| Point | 2024-25 | 2026-27 | Cartes |
|---|---|---|---|
| Glycogène synthase | active déphosphorylée, phosphorylée par la GSK3β ; mémo « l'insuline favorise les formes déphosphorylées » (p. 3) | seulement la figure p. 5 (GSK3 inhibée, glycogène synthase activée) | `ins-fa-05`, `ins-rv-03`, `ins-qr-03` gardées, absentes ; les items d'annales sur l'état de phosphorylation le disent |
| Glycogène (partie 1 p. 2-3) | GS : UDP-glucose, post-prandial ; les deux voies jamais simultanées | GS dans muscles et foie ; GP au jeûne **ou à l'exercice** ; glycolyse et pyruvate déshydrogénase augmentées | `ins-fa-02`, `ins-fa-04`, `ins-rv-01`, `ins-rv-02` réécrites ; `ins-fa-28` nouvelle |
| Insuline, lipides (p. 3) | action anti-lipolytique, compétition métabolique | idem, et l'enfant insulinodépendant : β-oxydation, corps cétoniques, coma acido-cétosique | `ins-rv-20` nouvelle |
| Récepteur (p. 4) | « α2β2 », « hétérodimérique » | récepteur tyrosine kinase, deux variants d'épissage ; figure à deux α et deux β | `ins-fa-07` (trous c1-c2), `ins-rv-04`, `ins-rv-05`, zones `alpha`, `beta` |
| Domaines (p. 4-5) | SH2 et PTB dans IRS-1 et IRS-2 | IRS-1 : domaine PH (lipides polaires, rapatrie à la membrane) et PTB (phosphotyrosines) ; le SH2 ne reste que sur la figure p. 6, celui de la PI3-K | `ins-rv-06` réécrite ; 2021/2022 S1 Q. 5 D justifiée par le 2024-25 et la figure p. 6 |
| AKT (p. 5) | trois effets : GLUT-4, lipolyse par l'AMPc, GSK3β | **quatre** : GLUT-4, glycogène synthase, **synthèse lipidique**, anti-lipolyse ; figure des relais (GSK3, PDE3B, ACLY, TSC/mTORC1, TBC1D4) | `ins-fa-09`, `ins-qr-05` (la question dit « quatre »), `ins-rv-09`, zone `akt` |
| Arrêt du signal (p. 6) | endocytose ; Ser/Thr par encombrement stérique | endocytose (recyclage, dégradation) ; Ser/Thr d'IRS-1 : arrêt, accrue dans l'insulinorésistance | `ins-fa-11`, `ins-rv-10`, `ins-qr-06` |
| Définition (partie 2 p. 2) | concentrations physiologiques | idem, plus les courbes dose-réponse (décalage à droite, réponse maximale abaissée) | `ins-fa-24` nouvelle |
| Complications (p. 3) | trois : endothélium (vasoconstriction), pancréas (fibrose), muscle lisse (prolifération) | deux : endothélium (vasoconstriction **et adhésion plaquettaire**, micro-thrombus), muscle lisse (prolifération) | `ins-fa-17`, `ins-qr-14` |
| Glycémie à jeun (p. 3) | après 12 h de jeûne | à deux reprises, deux jours différents ; plus de durée | `ins-fa-13` réécrite, `ins-rv-12`, `ins-qr-08` |
| HPO (p. 4-5) | 75 g de glucose | du glucose, sans dose ; glycémie ET insulinémie dosées ; retour de l'insuline du contrôle vers T120 ; **trois caractéristiques** de l'obèse ; « dessiner le profil d'insulino-sécrétion » en QROC | `ins-fa-14`, `ins-fa-15`, `ins-rv-14`, `ins-rv-15`, `ins-qr-09`, `ins-zo-hpo` redessiné |
| HOMA (p. 5) | « diviser par les constantes », étude en quartiles | la formule, avec ses unités et **22,5** ; tableau de Hulsmans (leptine × 7,5 — « presque 10 fois » dans le ronéo —, adiponectine basse, IL-6 et hs-CRP hautes) | `ins-fa-16` réécrite, `ins-rv-25` nouvelle ; le 22,5 des annales est maintenant sourcé |
| IMC, syndrome métabolique (p. 6) | tableau identique ; Alphonse : **3** critères | seuils de surpoids (25) et d'obésité (30) ; Alphonse : **4** critères (la tension) ; RR cardiovasculaire × 2,35, AVC × 2,25 | `ins-fa-23` (+ 2 trous), `ins-qr-11` réécrite, `ins-fa-26` nouvelle |
| Situations (p. 5-6) | obésité ; maladies rares | idem, détaillées : mutation d'INSR, lipodystrophie | `ins-rv-22` nouvelle |
| Stéatose (p. 7) | — | stéatose, fibrose, cirrhose, carcinome hépatique | `ins-fa-27` nouvelle |
| Mécanisme de l'insulinorésistance (p. 7) | « défaut de mise en membrane de GLUT-4, mais pas en amont d'AKT » | consensus : GLUT-4, voies distales, en aval d'AKT ; IRS-1 phosphorylée sur Ser/Thr = **ancienne hypothèse** | `ins-rv-21` nouvelle ; 2023/2024 Q. 13 B réécrite ; zone `irs` réécrite |
| Causes (p. 7-8) | « tout part du tissu adipeux » : macrophages, inflammation chronique, adiponectine basse | acides gras (acide palmitique) : foie (stéatose, insulinorésistance hépatique) et cellule β (**lipotoxicité**) ; seuil individuel ; adipokines (TNF-α, IL-6 hautes, adiponectine basse) ; stress du RE | `ins-fa-19`, `ins-qr-12` réécrites, `ins-fa-25` nouvelle ; les macrophages et l'inflammation « chronique » ne restent que dans `ins-co-quizz2` C, qui le dit |
| Correction (p. 9-10) | poids ; metformine « activateur indirect » de l'AMPK (β-oxydation, captation, glycolyse), cancers (RR 0,86, mTORC1) ; incrétines, « GPL1 » | perte de poids, « le moyen le plus efficace » (régime 800 kcal/j, marche, chirurgie) ; metformine **inhibiteur du complexe I** → AMPK (captation, β-oxydation, lipolyse), avantages et inconvénients ; GLP-1 (sémaglutide), GLP-1/GIP (tirzépatide) ; hypolipémiants | `ins-fa-21`, `ins-rv-17`, `ins-rv-18` réécrites ; `ins-rv-23`, `ins-rv-24` nouvelles ; `ins-fa-22`, `ins-qr-15` absentes |
| Quiz | QUIZZ 1 (B, C) et QUIZZ 2 (A, B, D, E) | QUIZZ 1 (A, C, E), partie 1 p. 5-6 ; quiz du professeur (A, B, D, E), partie 2 p. 10 | `ins-co-quizz1` et `ins-co-quizz2` gardées, re-citées sur les pages 2026-27 ; `ins-co-quizz2026-1` et `-2` nouvelles |
| Cancer (partie 1 p. 4) | — | sujets en surpoids hyperinsulinémiques : risque relatif de cancer augmenté | `ins-rv-26` nouvelle |

Les réponses attendues des QROC, que l'audit du 26/09 jugeait intapables
(phrases de 12 à 22 mots), ont été raccourcies en mots-clés, avec leurs
variantes.

## Les ATTENTION de ce chapitre

Le ronéo 2026-27 ne sera pas corrigé, et la promo n'a pas encore de tableau
d'erreurs pour BMCP : toutes les erreurs ci-dessous ont été trouvées à la
relecture. Elles sont portées par les cartes, là où elles se jouent, et vont
aussi dans `contenu/ERRATA_RONEOS_2026-27.md`. Sur la carte, une erreur de
prise de notes s'écrit `ATTENTION (prise de notes)`, un point douteux
`ATTENTION (douteux)` : l'écran de correction en fait un encadré, et la carte
entre dans le thème « Pièges des ronéos ». Les `ATTENTION` sans genre
d'`annales.py` restent ceux des clés imprimées fausses.

| Ronéo, page | Ce que dit le ronéo | Ce qui est juste | Carte |
|---|---|---|---|
| partie 1, p. 2 | l'insuline, « utilisée par les cellules ß-pancréatiques » | produite (sécrétée) par elles ; leur stimulus est le glucose (partie 2 p. 3) | `ins-fa-01` |
| partie 1, p. 2 | « récepteurs GLUT-4 » | GLUT-4 est un transporteur de glucose (le même ronéo le dit partie 2 p. 7) | `ins-fa-03`, `ins-qr-02`, zone `glut4` |
| partie 1, p. 4 | l'insuline « a donc besoin d'un transporteur membranaire, plus précisément, un récepteur » | un récepteur n'est pas un transporteur : l'insuline ne traverse pas la membrane, elle se fixe sur l'InsR | `ins-qr-16` |
| partie 1, p. 5 | la PI3K « phosphoryle une protéine intracellulaire, qui est également une protéine kinase : AKT » | la PI3K phosphoryle les phosphoinositides (PIP2 → PIP3) ; le PIP3 recrute AKT, phosphorylée par PDK1 et mTORC2 — la figure de la même page le montre (Manning et Toker, Cell 2017) | `ins-fa-08`, `ins-rv-07`, `ins-qr-04`, zone `pi3k` |
| partie 2, p. 2-3 | néoglucogenèse : « libérer de + de glucose à partir du glycogène » | c'est la glycogénolyse ; la néoglucogenèse fabrique du glucose à partir de précurseurs non glucidiques (partie 1 p. 3 ; ronéo 2024-25 p. 2) | `ins-qr-07` |
| partie 2, p. 5 | les paramètres lipidiques encadrés en rouge « augmentent (avec quand même une baisse du HDL) » | le tableau reproduit montre aussi un LDL-cholestérol plus bas chez les obèses (85 contre 110 mg/dL) ; seuls les triglycérides augmentent | `ins-rv-25` |
| partie 2, p. 5 | la leptine est « presque 10 fois plus élevée » chez l'obèse | le tableau reproduit sur la même page donne 65,6 contre 8,7 ng/mL, soit environ 7,5 fois | `ins-rv-25`, `ins-fa-19` |
| partie 2, p. 6 | IMC : « la taille en cm » | en mètres (kg/m²) : 95 / 1,73² = 31,7 | `ins-fa-23` |
| partie 2, p. 7 | Alphonse : « tension artérielle systolique de 95 mmHg (> 85 mmHg) » | 95 est la DIASTOLIQUE (TA 123/95) ; 85 est le seuil diastolique | `ins-qr-11` |

Points douteux, signalés sur la carte sans être tenus pour des erreurs :

| Ronéo, page | Ce qui fait douter | Carte |
|---|---|---|
| partie 1, p. 3 | « l'ajout à une molécule de glycogène n-1 glucose, de n glucose » : phrase qui se lit mal ; la synthase ajoute un glucose, le glycogène passe de n-1 à n résidus (figure p. 2) | `ins-fa-04`, `ins-rv-01` |
| partie 2, p. 3 | « prolifération cellulaire (formation de fibrose au niveau du foie) » sous les cellules musculaires lisses ; le Charonéo 2023-24 (p. 9) attribue la fibrose à la prolifération des cellules stellaires ; non carté | `ins-fa-17` |
| partie 2, p. 9 | l'AMPK « ↗ de la lipolyse » : point discuté, l'AMPK est classiquement antilipolytique dans l'adipocyte (Daval et al., J Biol Chem 2005), et la metformine freine la lipolyse stimulée des adipocytes humains par l'AMPK (Bourron et al., Diabetologia 2010) ; la liste du cours reste à savoir | `ins-rv-17` |
| partie 2, p. 6 | RR d'AVC « x2,25 » : la méta-analyse d'où viennent ces chiffres (Mottillo et al., J Am Coll Cardiol 2010) donne 2,35 pour les maladies cardiovasculaires, comme le ronéo, mais 2,27 pour l'AVC ; la diapositive n'est pas vérifiable | `ins-fa-26` |
| partie 1, p. 4-5 contre partie 2, p. 7 | la phosphorylation des sérines d'IRS-1, « facteur de l'insulinorésistance » de l'obèse (partie 1), devient l'« ancienne hypothèse » (partie 2) ; les deux se tiennent : elle gêne le signal, mais le défaut majeur est en aval d'AKT | `ins-rv-10`, `ins-an-20212022s1-q6` (D), zone `irs` |

## Seconde relecture (28/09/2026)

Une relecture sceptique a repris chaque carte nouvelle ou modifiée contre la
page du ronéo qu'elle cite, et chaque annale contre le PDF du polycopié :

- **huit propositions d'annales rendues à leur texte imprimé.** Le chapitre
  les avait tirées d'une extraction qui perdait les lettres grecques :
  « GSK3β (… Kinase 3β) » (2021/2022 S1 Q.5 C), « cellule β » (2019/2020 S2
  Q.5 B, 2017/2018 S1 Q.5 C), « TNFα » (2020/2021 S1 Q.4 D, 2020/2021 S2 Q.6 B,
  2017/2018 S1 Q.6 A), « insulino-résistant » (2021/2022 S2 Q.19 A). Et
  2018/2019 Q.5 C, où la carte avait **ajouté** « bêta », redit « la cellule
  pancréatique » comme le polycopié ; sa justification dit qu'il faut lire
  cellule β, ce que confirme la même phrase en 2017/2018 S1 Q.5 C. Aucune clé
  n'a bougé ;
- deux erreurs du ronéo 2026-27 de plus : la leptine « presque 10 fois » plus
  élevée (7,5 fois sur le tableau reproduit), et un point douteux, le RR d'AVC
  de 2,25 (2,27 dans la méta-analyse source) ;
- le GLP-1 est bien une incrétine (`ins-rv-18`, `ins-fa-21` le disaient
  comme une erreur du 2024-25) ; le seuil du diabète est « ≥ » pour l'OMS
  (`ins-rv-12`) ; le stress du RE explique la défaillance de la cellule β
  plus que la résistance (`ins-qr-12`) ; le schéma de l'HPO cite la partie 2,
  qu'il redessine (`SOURCES_SCHEMAS`).

## Les clés qui ne sont pas reprises telles quelles

La règle est celle de Vincent (26/09) : **la clé retenue est la bonne, pas la
clé imprimée** — celle du cours, ou celle de l'analyse vérifiée sur des sources
sûres quand le cours se trompe. L'énoncé reste tel qu'il est imprimé. La
justification de la proposition en cause commence par « ATTENTION : la
correction imprimée donne cette proposition VRAIE|FAUSSE ; elle n'est pas
bonne », dit pourquoi, cite sa source et finit par « Retenu : … » ; les quatre
questions portent `officielle=False`. Le générateur refuse d'écrire si un
conflit déclaré n'est pas signalé là où il se joue. La relecture 2026-27 n'a
changé aucune de ces clés ; elle les appuie sur le cours de l'année.

| Question | Clé imprimée | Retenu | Pourquoi | Source |
|---|---|---|---|---|
| 2019/2020 S2 Q.5 | A | **ABE** | B (stress du RE puis apoptose de la cellule β surstimulée) est le mécanisme même qui rend A vraie, et le cours 2026-27 le dit en rouge ; E : l'insuline, hormone de stockage antilipolytique, épargne les lipides | ronéo 2026-27 partie 2 p. 8 et quiz p. 10 (A), partie 1 p. 2-3 ; Eizirik, Cardozo, Cnop, *Endocrine Reviews* 2008 ; PubMed 7718614 (PDE3B) |
| 2021/2022 S2 Q.19 | BCD | **BCDE** | E, telle qu'elle est imprimée, décrit la compensation par hyperinsulinisme (hyperfonctionnement de la cellule β) | ronéo 2026-27 partie 2 p. 4-5 ; Kahn, Hull, Utzschneider, *Nature* 2006 |
| 2022/2023 S1 Q.15 | C | **CE** | le tissu adipeux (acides gras libérés en excès, adipokines : TNF-α, IL-6 hautes, adiponectine basse) est un contributeur majeur de l'insulinorésistance ; 2023/2024 Q.13 D le cote vrai, l'errata signale une correction CE du professeur | ronéo 2026-27 partie 2 p. 7-8 ; Kahn, Hull, Utzschneider, *Nature* 2006 |
| 2020/2021 S1 Q.3 | ADE | **AE** | D fait favoriser la lipolyse par l'insuline, qui est antilipolytique — la question 4 de la **même session** le cote, le QUIZZ 1 du cours 2026-27 (C) aussi, et 2022/2023 Q.11 C (métabolisme général) cote fausse la même phrase | ronéo 2026-27 partie 1 p. 3 et figure p. 5 (PDE3B, AMPc) ; PubMed 7718614 |

Deux clés **déduites**, le sujet de 2024/2025 étant publié sans corrigé
(`officielle=False`) ; le générateur exigeant un conflit pour toute clé non
officielle, chacune porte son ATTENTION « sans clé officielle » sur l'item que le
cours dit le moins en toutes lettres, déclaré dans `CONFLITS` :

| Question | Clé imprimée | Retenu | Pourquoi | Source |
|---|---|---|---|---|
| 2024/2025 S1 Q.15 | *aucune* (sujet sans corrigé) | **ABD** | A, récepteur à activité tyrosine kinase ; B, IRS-1/2 phosphorylés sur tyrosine (signal) ou sur sérine (frein) — ATTENTION ; C fausse, GLUT4 est en aval d'AKT ; D, le HOMA mesure l'insulinorésistance ; E fausse, le HOMA est un produit, divisé par 22,5 | ronéo 2026-27 partie 1 p. 4-5, partie 2 p. 5 et 7 |
| 2024/2025 S1 Q.16 | *aucune* (sujet sans corrigé) | **BC** | A fausse, le défaut est distal ; B, l'HPO est dynamique, glycémie et insulinémie ; C, l'obèse non diabétique a des glycémies normales — ATTENTION ; D fausse, 1,26 g/L (le quiz du professeur corrige la même phrase) ; E fausse, cytokines pro-inflammatoires | ronéo 2026-27 partie 2 p. 3-8, quiz p. 10 |

Pour 2020/2021 S1 Q.3, l'énoncé d'origine disait peut-être « lipogenèse » et a
été mal recopié ; la carte juge l'énoncé **tel qu'il est imprimé**, où D est
fausse, et signale l'autre lecture plutôt que de la masquer.

**2021/2022 S2 Q.19 E reste à confirmer, et la carte le dit.** Le polycopié
perd ses lettres grecques — en 2018/2019 Q.5 C, il imprime « la cellule
pancréatique » pour la cellule β, et la clé la cote vraie. L'errata propose de
lire « cellule *alpha* », ce qui rendrait E fausse et la clé juste, mais sa
colonne « avis bureau » est vide et rien dans le dossier ne le montre. La carte
garde E vraie pour l'énoncé imprimé, explique les deux lectures, et la question
est posée à Vincent : le sujet d'origine (Moodle) tranche.

Le QROC 2017/2018 S1 n°2 n'a pas de clé imprimée complète (trois puces, sans la
constante) : sa réponse est déduite du cours, qui donne 22,5 cette année.

## Deux clés du professeur conservées malgré un défaut

* **QUIZZ 1 E du ronéo 2024-25** — « GSK3β en amont d'AKT » est donné FAUX, et
  c'est juste : l'errata l'a confirmé, l'annale 2021/2022 S1 Q.5 C aussi, et la
  figure du cours 2026-27 (partie 1 p. 5) place la GSK3 en aval d'AKT.
* **QUIZZ 2 A du ronéo 2024-25** — l'énoncé est auto-contradictoire
  (« glycémie à jeun […] à 2 h de l'HPO »). La clé VRAI du professeur est
  gardée, la contradiction est signalée dans la justification.

## Absent du cours 2026-27

Ces cartes sont **gardées telles quelles**, parce que rien dans les ronéos
2026-27 ne les contredit et que les annales les posent encore ; leur explication
commence par « Absent du cours 2026-27 : il n'y a pas de version 2026-27 de
cette carte ; elle vient du cours 2024-25 (FC n°2, Ronéosaure) », et elles
portent le tag `absent-2026`. À Vincent de décider s'il les garde.

| Carte | Ce qui est absent | Annales qui s'en servent |
|---|---|---|
| `ins-fa-05`, `ins-rv-03` | l'état de phosphorylation de la glycogène synthase (active déphosphorylée), la GSK3β qui la phosphoryle, le mémo des formes déphosphorylées ; le 2026-27 ne garde que la figure p. 5 | 2020/2021 S1 Q.3 B, 2019/2020 S2 Q.5 D, 2017/2018 S2 Q.6 B |
| `ins-qr-03` | le mécanisme GSK3β → GS déphosphorylée, active | idem |
| `ins-fa-22`, `ins-qr-15` | metformine et cancers : RR 0,86, AMPK contrôleur négatif de mTORC1, effet anti-prolifératif | 2017/2018 S1 Q.5 A, 2018/2019 Q.5 A, 2021/2022 S2 Q.19 B |

Détails absents gardés dans des cartes par ailleurs vérifiées, et dits dans
leur explication : les 12 h de jeûne et les 75 g de l'HPO, l'encombrement
stérique, les quartiles d'HOMA, la fibrose du pancréas, les macrophages et
l'inflammation « chronique » (`ins-co-quizz2` C), le domaine SH2 dans le texte
(2021/2022 S1 Q.5 D ; la figure p. 6 le garde), la surexpression tumorale d'InsR-A, « sans perte
d'exons », les incrétines et l'effet du GLP-1 sur la sécrétion d'insuline. Deux
items d'annales s'appuient sur le Charonéo 2023-24, faute de mieux : PTEN
(2019/2020 S1 Q.5 E) et mTORC1 en aval d'AKT (même question, B, avec la figure
du cours 2026-27 p. 5).

## Les deux schémas

Les figures du ronéo portent toutes leurs étiquettes et donneraient la
réponse : les deux schémas cliquables sont redessinés nus, et la figure du
cours illustre la correction.

* `recepteur-insuline.svg` — le récepteur et **les deux voies** qui en partent.
  La plupart des items faux des annales sont des inversions de place sur ce
  schéma : GSK3 mise en amont d'AKT, AKT en amont de la PI3K, la voie mitogène
  confondue avec la voie métabolique. Relu le 28/09 : GLUT-4 est rattaché à AKT
  et la voie des MAP kinases au récepteur, comme sur la figure p. 6 ; les notes
  des zones `alpha`, `tyrosines`, `irs`, `pi3k`, `akt`, `glut4`, `mapk` et
  `mitogene` suivent le cours 2026-27 (quatre effets d'AKT, domaines PH et PTB,
  défaut majeur en aval d'AKT ; plus de « α2β2 déjà assemblé », plus d'item
  d'annales inventé sur le cerveau).
* `hpo-courbes.svg` — l'hyperglycémie provoquée par voie orale, glycémie en
  haut, insulinémie en bas, **redessinée d'après la figure du cours 2026-27**
  (partie 2 p. 4) : un contrôle (vert) et un obèse insulinorésistant non
  diabétique (bleu), avec les pointillés de 1,26 et 2 g/L. La version du 26/09
  dessinait un troisième sujet, diabétique, qu'aucun cours ne montre, et
  faisait redescendre la glycémie du sujet sain à sa valeur de départ quand le
  cours la décrit en plateau. Les zones gardent leur rang (une carte de zone
  est tirée par son rang) : les rangs 2 et 5, qui portaient le diabétique,
  deviennent le seuil de 2 g/L et l'insulinémie de l'obèse à T120 ; une
  septième zone, l'insulinémie de l'obèse à T0, complète les trois
  caractéristiques du cours.

Les zones des courbes sont posées là où **un seul tracé passe** : au départ
pour les deux glycémies (les seules minutes où elles se séparent), sur les
sommets et à T120 pour les insulinémies, sur le pointillé de 2 g/L là où
aucune courbe ne monte.

## Les illustrations

Quinze figures des deux ronéos 2026-27, extraites en PNG dans `media/` avec
leur page (`IMAGES`, troisième élément : la partie), illustrent les
corrections : **24 QCM sur 24**, 65 notes sur 97. Elles partent avec le
chapitre ; les collègues ont les mêmes ronéos.

## Le lexique

Ce chapitre n'a pas encore de lexique. Son générateur est le modèle depuis le
19/10 : une liste `LEXIQUE` en fin de `donnees.py` suffira à le construire.

## À relire

Aucune carte. Les deux QCM du sujet de 2024/2025 ont leurs clés déduites, chaque
proposition sur une page du ronéo de l'année. Les quarante cartes que l'audit du 26/09 avait signalées
(`contenu/COUVERTURE.md`) ont été relues contre les ronéos 2026-27, page par
page ; les réponses attendues des QROC ont été raccourcies, et les seuils du
syndrome métabolique confrontés au tableau de la partie 2 p. 6.

## L'échelle : Simple → Moyen → Annale (C20, 19/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 5 janvier. Sous les annales, 39 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 11 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`) ; les QROC reçoivent le schéma nu.

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `recepteur` | 3 | 1 | 1 |
| `signalisation` | 8 | 2 | 4 |
| `secretion` | 3 | 1 | 1 |
| `resistance` | 21 | 6 | 13 |
| `syndrome-metabolique` | 4 | 1 | 2 |

**Le schéma** `ech-insuline`, « L'insuline · la mécanique, puis la panne », donne 71 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_INSULINE`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Les ATTENTION de l'échelle portent leur genre** (C29, 19/10), comme les cartes du chapitre et la liste des erreurs : `(prise de notes)` sur `ins-ech-s1`, `ins-ech-s9`, `ins-ech-s25` et `ins-ech-m9` ; `(douteux)` sur `ins-ech-s10`, `ins-ech-m2` et `ins-ech-m6`. Le générateur ajoute le tag `piege-roneo` sans retirer le thème, que l'échelle lit seul (`domain/rungs.py`).

**`annales.py`** : `_SCHEMA_LETTRES` et `_SCHEMA_NU` sont posées avant `ANNALES`. Fiche par défaut : la partie 1 du ronéo 2026-27 (`src-fc-bmcp-insuline-1`) ; la partie 2 se cite par `fiche="src-fc-bmcp-insuline-2"`, le ronéo 2024-25 par `src-cours-insuline` (`ins-ech-s11`, `ins-ech-s37`). Aucune source à déclarer en plus.

**Sans marche** :
- ins-an-20192020s1-q5 E (PTEN inactive la voie de l'InsR) : ni le ronéo 2026-27 ni le 2024-25 ne citent PTEN ; seule la justification de l'annale la tire du Charonéo 2023-24. Lettre posée sur la case AKT (PTEN déphosphoryle le PIP3).
- ins-an-20192020s1-q6 D (l'adiponectine favorise l'AMPK) : le cours 2026-27 la dit seulement insulinosensibilisante (partie 2, p. 8) ; le mécanisme vient de Yamauchi et al. (Nature Medicine 2002), cité par la justification. Lettre posée sur la case du tissu adipeux.
- ins-an-20192020s2-q6 A (l'essentiel du glycogène serait hépatique) : les ronéos de ce chapitre ne chiffrent pas les réserves ; le ronéo 2026-27 de métabolisme énergétique le fait (Dr Huin, p. 4 : foie ≈ 100 g, muscles ≈ 400 g ; chapitre bmcp_energetique), hors des sources de ce chapitre. Lettre posée sur la case du glycogène.
- ins-an-20192020s2-q6 E (le glycogène musculaire maintiendrait la glycémie) : les ronéos 2026-27 de métabolisme énergétique (p. 4 : glycogène musculaire « uniquement disponible pour le muscle ») et glucidique (p. 3) le contredisent, hors des sources de ce chapitre ; bmcp_metabolisme le prépare par met-ech-m8 A (sans glucose-6-phosphatase, le muscle garde son glucose). Lettre posée sur la case du glycogène.

## Régénérer

```
python generer.py
```

**Le générateur.** Depuis le 19/10/2026 (C29), `generer.py` est la copie exacte
du modèle du skill, pour que le chapitre puisse recevoir l'échelle Simple/Moyen.
Le bloc « le générateur modèle », en fin de `donnees.py`, déclare les sources
dans `SRC` (le sujet 2024/2025 par `SRC["sessions"]`) et ajoute à `IMAGES` le
schéma redessiné d'après la partie 2. Le paquet est resté le même, à trois
écarts voulus près :
- l'indentation et la fin de ligne finale ;
- la légende des deux schémas cliquables, désormais accentuée ;
- le tag d'année que le modèle pose sur chaque carte de cours d'après sa
  source : `cours-2026-27` sur 71 cartes, `cours-2024-25` sur les 5 absentes.
