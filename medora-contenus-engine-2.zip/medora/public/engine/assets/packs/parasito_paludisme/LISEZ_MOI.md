# Paludisme — paquet Parasitologie et mycologie

78 notes, 140 cartes. Chapitre `chap-ue-parasito-fc4` de l'UE Parasitologie et
mycologie (`ue-parasito`). Cours du **Pr Cornu, le 27/10/2025**, « Paludisme »
(FC n°4 du Ronéosaure 2025-26, 11 pages) ; annales de deux polycopiés du
Ronéosaure 2024-25 (7 questions, 6 sessions) et du sujet 2024/2025 de l'UE
(1 QROC, sans corrigé). Examen de janvier (5 janvier 2027).

**Une fiche provisoire.** Le ronéo 2026-27 de ce cours n'est pas paru : le
chapitre est carté sur le Ronéosaure 2025-26 (décision de Vincent du 02/10), et
le ronéo de l'année corrigera les cartes à sa parution. La fiche porte son année
dans son auteur : chaque carte de cours montre « Cours 2025-26 », ou « Cours
2024-25 » pour les cinq qui viennent de l'appoint. Aucune carte ne dit « Absent
du cours 2026-27 », et les erreurs du Ronéosaure sont dites par un ATTENTION
sans genre : la liste des erreurs de la promo, `contenu/ERRATA_RONEOS_2026-27.md`,
ne concerne que les ronéos 2026-27.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 32 | 32 |
| QRU | 1 | 1 |
| Texte à trous | 14 | 69 |
| QROC | 9 | 9 |
| Recto-verso | 10 | 10 |
| Schéma cliquable | 2 | 9 |
| Lexique | 10 | 10 |

Dont **8 annales** : 4 QCM (QRM) et 4 QROC (recto-verso), sur 7 sessions, de
2019/2020 S1 à 2024/2025 S1 (le QROC 2 du sujet 2024/2025, réponse déduite). Les 29 QCM du cours, dont les trois quizz de la
professeure, ont une justification par proposition, comme les annales.

Huit thèmes, dans l'ordre du cours :

| Clé | Libellé |
|---|---|
| `epidemiologie-transmission` | Épidémiologie et transmission |
| `especes-plasmodium` | Les espèces de Plasmodium |
| `cycle-parasitaire` | Cycle parasitaire et hôtes (partagé dans l'UE) |
| `physiopathologie-palu` | Hémolyse, splénomégalie, thrombopénie |
| `manifestations-cliniques` | Manifestations cliniques |
| `urgence-gravite` | Quand évoquer, critères de gravité |
| `diagnostic-biologique` | Diagnostic biologique (partagé dans l'UE) |
| `traitement-prevention` | Traitement et prévention (partagé dans l'UE) |

Les huit libellés sont à ajouter à `THEME_LABELS`
(`app/src/med_engine/application/scopes.py`), bloc « parasitologie » ; aucune
de ces clés n'existe ailleurs dans l'application.

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-parasito-paludisme` — Ronéosaure, « FC n°4 Paludisme » (11 p.), `PARASITO-MYCOLOGIE/FC n°4 Paludisme .pdf` | **2025-26** | **la base** : chaque note du cours porte sa page ; c'est ce que le lecteur ouvre (`chapitre=`) |
| `src-annales-4-protozoose-sanguine-paludisme` — polycopié « 4 - Protozoose sanguine _ paludisme » (3 p.) | 2024-25 | 4 QCM et 1 QROC, table de corrections p. 3 |
| `src-annales-1-definition-du-parasitisme-classification-des-pathogenes-d-interet-medical` — polycopié « 1 - Définition du parasitisme… » (3 p.) | 2024-25 | 2 QROC de paludisme rangés là (2020/2021 S1, 2019/2020 S1), table p. 3 |
| `src-cours-parasito-paludisme-2425` — Ronéosaure, FC n°4 « Le paludisme », Pr Cornu (20 p.) | 2024-25 | appoint pour ce que la fiche 2025-26 ne dit pas : sujets à risque (p. 17), chimioprophylaxie et répulsifs (p. 17-18), prévention collective et prémunition (p. 19), correction des quizz (p. 20) |
| erratas : cours 2025-26 (`Erratas de Parasitologie mycologie.docx`), cours 2024-25, annales 2024-25 | — | une entrée sur la FC n°4 2025-26 (« cours pas complet » p. 11), une sur la FC n°4 2024-25 (« J13, 17 » → J3, J7) ; l'errata des annales est vide |
| `src-sujets-parasito-2425` — sujets de parasitologie-mycologie 2024/2025, session 1 (examen du 10/01/2025, 14 p.), sans chemin | 2024-25 | 2024/2025 S1 QROC 2, par `SRC["sessions"]` ; **aucun corrigé**, réponse déduite du cours ; déclaration commune aux dix chapitres de l'UE, champ pour champ |

**Les deux polycopiés d'annales sont partagés** avec d'autres chapitres de l'UE
(le n°1 avec le parasitisme et les parasitoses digestives) : leur déclaration
suit la forme commune (identifiant `src-annales-<slug>`, titre = nom du fichier
sans extension, chemin `S1/ANNALES/Examens de Janvier/Parasitologie et
Mycologie/…`, auteur « Ronéosaure 2024/2025 », rien d'autre). Le nom du n°1 a
une espace avant `.pdf` : son titre la garde.

Vérifications hors du cours, citées dans la carte qui s'en sert : ANOFEL (cours
de parasitologie, UNF3S : fécondation dans l'estomac, schizogonie hépatique
unique, groupe Duffy, fièvres tierce et quarte, 90 % des accès à P. falciparum
dans les 2 mois, « état de prémunition plutôt que d'immunité ») ; SPILF 2017
(parasitémie isolée > 4 % « à risque d'aggravation rapide », hémolyse différée
post-artésunate et son suivi J7-J28, atovaquone-proguanil du jour du départ à
7 jours après le retour) ; l'étymologie (TLFi, Wiktionnaire, Bailly, Gaffiot).
Chaque citation a été relue dans le texte de la source (relecture du 05/10).

## Ce que le cours a dicté

- **Les ✪**, diapositives que la professeure signale comme importantes pour les
  EDN : primo-invasion, accès simple, accès pernicieux, quand évoquer,
  incubations, diagnostic, traitement. Chacune a sa carte, et les deux encadrés
  « Toute fièvre… » et « Tout malade présentant une atteinte de la
  conscience… » sont `indispensables` dans `pal-qc-quand-evoquer` : quatre
  annales les demandent.
- **Le gris** est la voix des rédacteurs (titres, éléments de diapositive) : il
  se carte. « La prof passe volontairement la partie moustique » (p. 6) :
  l'hôte définitif, que les annales demandent, reste carté normalement, sans
  tag `edn`.
- **Les trois quizz de la professeure** sont des cartes : p. 3 (`pal-qc-quiz-curable`,
  QRU, C), p. 4 (`pal-qc-quiz-globules-rouges`, BC), p. 11
  (`pal-qc-quiz-prevention`). Celui de la p. 11 a **six propositions**,
  réponse ABDEF : le type QRM n'en prend que cinq, la sixième (« éducation de
  la population », vraie) est dite dans l'explication. Les deux premiers
  gardent la clé de la professeure (`officielle=True`), le troisième non,
  puisqu'il est raccourci.
- **Le cours 2025-26 est incomplet** à la p. 11 (errata 2025-26) : sujets à
  risque, chimioprophylaxie, répulsifs, prévention collective. Cinq cartes les
  prennent dans le cours 2024-25 de la même professeure et le citent à sa page
  (`fiche=FC2425`) : `pal-qc-chimioprophylaxie`, `pal-qc-sujets-risque`,
  `pal-fa-repulsifs`, `pal-fa-prevention-collective`, `pal-rv-premunition`.
  Elles portent le badge « Cours 2024-25 ».
- **« Porteurs sains »** (quizz p. 3, E) : la professeure la cote fausse ; sa
  correction de 2024-25 (p. 20) dit pourquoi — il n'existe que des porteurs
  asymptomatiques, atteints d'un paludisme chronique. La carte suit la
  professeure et dit le point douteux (plan C16) : la prémunition laisse un
  portage sans symptôme (cours 2024-25, p. 19), qu'ailleurs on appelle
  « porteur sain ».

## Les erreurs du Ronéosaure

Chacune est dite par **ATTENTION**, sans genre, dans la carte qui porte la
notion.

| Page | Ce que dit le Ronéosaure | Ce qui est juste | Carte |
|---|---|---|---|
| 6 (2025-26) | « c'est au niveau de ses glandes salivaires que la reproduction sexuée aura lieu » | dans l'**estomac** : gamètes, ookinète, oocyste sur la face externe de la paroi ; les glandes salivaires logent les sporozoïtes (ANOFEL ; cours 2024-25, p. 8) | `pal-qc-cycle-sanguin` D ; zone « estomac » de `pal-zo-cycle` |
| 5 (2025-26) | des mérozoïtes hépatiques, « certains vont rentrer à nouveau dans le foie et le contaminer », et le schéma simplifié du cycle de la même page dessine une boucle qui revient au foie ; le cours 2024-25 dit aussi « réinfecter d'autres hépatocytes » (p. 8) | la schizogonie hépatique est unique, « la cellule hépatique ne pouvant être infectée que par des sporozoïtes » (ANOFEL) ; seuls les hypnozoïtes de P. vivax et P. ovale restent dans le foie. Point douteux et sans doute le cours lui-même (deux années, un texte et un schéma) ; la carte suit la référence, comme le veut la consigne de l'UE, et la question est posée à Vincent | `pal-qc-cycle-hepatique` E ; zone « schizonte hépatique » de `pal-zo-cycle` |
| 18 (2024-25) | atovaquone-proguanil « adaptés pour les séjours de plus d'une semaine », doxycycline « de plus de quatre semaines » | ce sont les durées de prise **après le retour** (« séjour + 1 semaine », « séjour + 4 semaines » sur le tableau) | `pal-qc-chimioprophylaxie` B |

Sans ATTENTION, parce qu'aucune réponse n'en dépend ou que c'est douteux : la
« transmission du virus » (p. 3, pour le parasite) ; « Haptoglovine » et
« Bilirubiune » (p. 7, dit dans `pal-fa-hemolyse`) ; « La paludisme est » (quizz
p. 4, corrigé dans l'énoncé de la carte) ; le « bilan épidémiologique
hebdomadaire » (p. 11), qui est le Bulletin épidémiologique hebdomadaire (BEH),
dit dans `pal-qc-moyens-piqures` ; la réactivation des hypnozoïtes
« lorsque le patient prend une grande dose d'alcool » (p. 6), affirmation non
vérifiée, que la carte `pal-qc-hypnozoites` ne reprend pas et signale dans son
explication.

## Ce que les annales ont dicté

| Savoir | Questions |
|---|---|
| Quand évoquer un paludisme : fièvre au retour, atteinte cérébrale, thrombopénie | 2023/2024 S1 Q8 D, 2022/2023 S1 QROC 1, 2021/2022 S2 Q.8, 2019/2020 S1 QROC 1 |
| Le diagnostic de certitude : frottis, goutte épaisse | 2022/2023 S1 Q.2 |
| Ce que donne le frottis : l'espèce et la parasitémie | 2024/2025 S1 QROC 2 |
| La biologie de l'accès simple : hémolyse, anémie, thrombopénie | 2021/2022 S1 Q.1 |
| P. falciparum, l'espèce la plus fréquente, et le neuropaludisme | 2020/2021 S1 QROC 1 |
| Hôtes, transmission, anémie régénérative, diagnostic parasitologique | 2023/2024 S1 Q8 |

| Polycopié | Session | Question | Clé imprimée | Retenue |
|---|---|---|---|---|
| n°4 | 2023/2024 S1 | Q8 | D | D |
| n°4 | 2022/2023 S1 | Q.2 | BC | BC |
| n°4 | 2022/2023 S1 | QROC 1 | corrigé (fièvre ; symptôme au retour ; syndrome confusionnel ou atteinte neurologique) | le corrigé, plus la thrombopénie en complément signalé |
| n°4 | 2021/2022 S1 (table : « Session X ») | Q.1 | BDE | BDE |
| n°4 | 2021/2022 S2 | Q.8 | BD | BD |
| n°1 | 2020/2021 S1 | QROC 1 | P. falciparum → neuropaludisme → mortalité | idem |
| n°1 | 2019/2020 S1 | QROC 1 | « Pas de correction, vérifier le cours » | clé déduite du cours |
| sujet 2024/2025 | 2024/2025 S1 | QROC 2 | aucune (sujet sans corrigé) | réponse déduite du cours |

## Les schémas cliquables

| Fichier | Ce qu'on clique | Cartes |
|---|---|---|
| `cycle-plasmodium-nu.svg` (`pal-zo-cycle`) | l'estomac de l'anophèle, ses glandes salivaires, l'hépatocyte au schizonte, l'hépatocyte à l'hypnozoïte, le cycle érythrocytaire, le gamétocyte | 6 |
| `frottis-sanguin-nu.svg` (`pal-zo-frottis`) | l'hématie parasitée (anneau), le gamétocyte en faucille, le polynucléaire | 3 |

Le cycle est redessiné d'après le schéma simplifié du cycle, dessiné à la main
(p. 5), et le cycle du CDC (p. 6), tous deux légendés : l'anophèle de profil à gauche
(estomac dans l'abdomen, glandes salivaires dans le thorax), la peau piquée,
le foie et ses deux hépatocytes, le sang et le cycle des hématies. Le clic
tranche l'erreur du Ronéosaure : la fécondation se fait dans l'estomac. Le
frottis répond à la question du cours (« Où sont les globules rouges
infectés ? », p. 10), dont la photographie porte déjà les cercles de la
réponse : elle est en correction. Les versions légendées (`cycle-plasmodium.svg`,
`frottis-sanguin.svg`) sortent des mêmes constantes ; le dessin et les zones ont
été rendus superposés et relus.

**Illustrations** : 23 QCM sur 33 (70 %) portent une figure en correction —
onze figures de la fiche 2025-26 (classification, carte, anatomie du
Plasmodium, cycle du CDC, neuropaludisme, les deux encadrés, critères de
gravité, diagnostic en urgence, frottis et goutte épaisse, moyens de
prévention), deux du cours 2024-25 (chimioprophylaxie, efficacité des moyens),
et le cycle légendé ; 42 notes sur 78 (le QROC 2024/2025 prend le frottis et la
goutte épaisse). Les dix QCM sans figure portent sur ce
que la fiche ne dessine pas : le quizz de la p. 3, l'histoire, la France,
l'hémolyse, la rate, la primo-invasion, les TDR et la NFS, les deux
traitements, les sujets à risque.

## Les clés qui ne sont pas reprises telles quelles

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2019/2020 S1 QROC 1 (quand évoquer) | « Pas de correction, vérifier le cours » | les deux encadrés, la thrombopénie, transfusion et greffe | clé déduite du cours (p. 4, 7-9), non officielle |
| 2022/2023 S1 QROC 1 (circonstances) | fièvre ; symptôme au retour ; syndrome confusionnel ou atteinte neurologique | le corrigé, plus « une thrombopénie au retour de voyage » | complément tiré du cours (p. 7, 9), signalé dans l'explication ; le corrigé reste officiel |
| 2021/2022 S1 Q.1 | BDE, sous « Session X » | BDE, en session 1 | l'énoncé est imprimé en session 1 |
| 2024/2025 S1 QROC 2 (ce qu'on attend d'un frottis positif) | aucune (sujet sans corrigé) | le diagnostic d'espèce (P. falciparum ou non) et la parasitémie (> 4 % : critère de gravité ; suivi à J3, J7, J28) | réponse déduite du cours : le frottis sert à « réaliser une parasitémie et un diagnostic d'espèce » (p. 9), espèces (p. 4-6), critères de gravité (p. 9), contrôle (p. 10) ; non officielle |

Reprise avec une remarque : **2021/2022 S2 Q.8 A** (la thrombopénie au retour
est un argument du cours, p. 9, mais l'énoncé demande « les 2 circonstances » :
celles des deux encadrés). Aucun conflit déclaré (`CONFLITS = []`) : aucune clé
imprimée n'est contredite par le cours ni par une autre session.

Cas ouvert : les mérozoïtes qui « réinfectent » le foie (voir les erreurs, et
les questions).

## Le lexique

Dix termes, aux pages mesurées dans le texte de la fiche 2025-26 :
hématozoaire (p. 4), érythrocytopathie (2, 4), mérozoïte (5, 6), schizogonie
(6, 7), gamétocyte (4, 6, 10), hypnozoïte (5, 6), hémozoïne (5), thrombopénie
(7, 9, 10), neuropaludisme (4, 8, 9 : « neuro paludismes » p. 4, « accès
pernicieux » p. 8, l'encadré-image p. 9), parasitémie (9). Chacun dit son
origine grecque ou latine.

Les étymologies nouvelles sont **proposées** pour `scripts/etymologies.json`,
avec leurs sources (fichier de proposition du chapitre), et la table n'est pas
modifiée : cinq racines (`mér(o)-`, `schiz(o)-`, `gamét(o)-`, `palud- (latin)`,
`parasit(o)-`), deux reprises à l'identique de la proposition des parasitoses
digestives autochtones (`zo(o)-`, `-zoïte`), et les dix termes. Les définitions
et les racines disent déjà, mot pour mot, ce qu'`appliquer_etymologies.py` en
écrira (vérifié). Les racines réemployées gardent la clé de la table :
`hém(at)-`, `éryth(r)-`, `cyt(o)- / -cyte`, `-pathie`, `gon(o)-`,
`hypn(o)- (grec)`, `thromb(o)-`, `-pénie`, `neur(o)-`, `-émie`. `mér(o)-` a le même
étymon que `-mère`, en forme préfixe, comme `hém(at)-` à côté de `-émie`.

« Sporozoïte » est laissé à la toxoplasmose, « trophozoïte » aux parasitoses
digestives autochtones (plan C16) ; « splénomégalie » est déjà au lexique de la
sémiologie digestive.

## Questions pour Vincent

1. **Les mérozoïtes qui « réinfectent » le foie.** Le Ronéosaure 2025-26 (p. 5,
   dans le texte et dans le schéma simplifié du cycle, qui boucle sur le foie)
   et celui de 2024-25 (p. 8) l'écrivent tous ; la référence (ANOFEL) dit le
   contraire : la schizogonie hépatique est unique. Tout porte à croire que la
   professeure l'enseigne ainsi. La carte `pal-qc-cycle-hepatique` cote la
   proposition fausse, avec la référence, et l'ATTENTION dit les deux lectures.
   Veux-tu qu'elle réponde plutôt comme le cours (« à l'examen, on répond
   d'abord comme le professeur ») ?
2. **L'examen du 5 janvier 2027** (question 5 du plan de l'UE) : le chapitre ne
   déclare pas d'`EXAMENS`, comme tous les chapitres existants. Faut-il le
   déclarer dans les chapitres des quatre UE de janvier, ou le laisser au
   réglage de l'application ?

## À relire

Aucune carte `a-relire` : chaque carte de cours porte sa page dans la fiche
2025-26 (ou, pour cinq, dans le cours 2024-25), chaque annale sa clé vérifiée
(déduite à la page pour le QROC 2024/2025).
À la parution du ronéo 2026-27 de ce cours, relire toutes les cartes contre
lui : chiffres (249 millions de cas, 608 000 décès, 96 %, 3 000 cas en France,
13 %), incubations, critères de gravité, traitements, et les deux erreurs
ci-dessus ; et voir si la prévention (p. 11) y est enfin complète, pour
remplacer l'appoint 2024-25.


## L'échelle : Simple → Moyen → Annale (C20, 19/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 5 janvier. Sous les annales, 18 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 5 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`) ; les QROC reçoivent le schéma nu.

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `especes-plasmodium` | 3 | 1 | 1 |
| `physiopathologie-palu` | 2 | 1 | 1 |
| `manifestations-cliniques` | 3 | 1 | 1 |
| `urgence-gravite` | 5 | 1 | 3 |
| `diagnostic-biologique` | 5 | 1 | 2 |

**Le schéma** `ech-paludisme`, « Le paludisme · du cycle au diagnostic », donne 28 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_PALUDISME`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

## Régénérer

```powershell
cd contenu\chapitres\parasito_paludisme
..\..\..\app\.venv\Scripts\python.exe generer.py
```
