# Parasitoses digestives « exotiques » — paquet Parasitologie et mycologie

78 notes, 133 cartes. Chapitre `chap-ue-parasito-fc5` de l'UE Parasitologie et
mycologie (identifiant du squelette, ordre 5). Cours du **Pr Cornu, le
27/10/2025**, « Parasitoses digestives « exotiques » » (FC n°5 du Ronéosaure
2025-26, 12 pages) ; annales du polycopié « 5 - Parasitoses digestives
exotiques » du Ronéosaure 2024-25 (9 questions, 4 sessions) et du sujet
2024/2025 de l'UE (2 questions, sans corrigé). Examen du 5 janvier 2027.

**Une fiche provisoire.** Aucun ronéo 2026-27 de parasitologie n'est paru :
le chapitre est carté sur le Ronéosaure 2025-26 (tâche C16, décision de Vincent
du 02/10), et le ronéo de l'année corrigera les cartes à sa parution. La source
porte son année dans son auteur : chaque carte de cours prend le tag
`cours-2025-26` et le badge « Cours 2025-26 ». Aucune carte ne dit « Absent du
cours 2026-27 », et les erreurs du Ronéosaure sont dites par un ATTENTION sans
genre (précédent d'`immuno_cmh` et d'`immuno_innee`) : la liste des erreurs de
la promo, `contenu/ERRATA_RONEOS_2026-27.md`, ne concerne que les ronéos
2026-27.

**Le brouillon du 03/10.** Le dossier ne contenait que les seize figures de la
fiche, extraites par une exécution interrompue, sans aucune note. Chacune a été
revue contre la page du PDF : toutes sont des recadrages justes des
diapositives, elles sont gardées. Le tableau des causes parasitaires (p. 3), du
texte, a été ajouté en image, et la planche des œufs numérotée.

**Relu le 05/10**, carte par carte contre la page de la FC qu'elle cite, chaque
clé d'annale contre les tables des polycopiés n°5 et n°8 (en image), les figures
contre leurs pages, le schéma cliquable avec ses zones superposées. Corrigés à
la relecture : la justification de `pde-qc-entamoeba` D (l'enkystement), celle
de `pde-qc-eau-boisson` C (les glaçons « manipulés avec les doigts »), le
« marché ambulant » de `pde-fa-conseils-alimentation`, l'énoncé de
`pde-qc-causes` (la colonne « Exotiques »), la nuance entre les deux
formulations de la courbe de Lavier, les sources de l'ATTENTION de l'épreinte,
et les racines `syn-` et `-drome`, qui citent désormais la FC de sémantique 2.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 31 | 31 |
| QRU | 2 | 2 |
| Texte à trous | 13 | 64 |
| QROC | 10 | 10 |
| Recto-verso | 10 | 10 |
| Schéma cliquable | 1 | 5 |
| Planche à légender | 1 | 1 |
| Lexique | 10 | 10 |

Dont **11 annales** : 6 QCM (QRM) et 5 QROC (recto-verso, corrigés officiels de
la table), sur 5 sessions, de 2021/2022 S1 à 2024/2025 S1 (Q4 et Q6 du sujet
2024/2025, clés déduites du cours). Les 27 QCM du cours
ont une justification par proposition, comme les annales.

Sept thèmes, dans l'ordre du cours :

| Clé | Libellé |
|---|---|
| `peril-fecal` | Péril fécal et transmission digestive (partagé avec la FC n°3) |
| `amoebose` | Amoebose |
| `hypereosinophilie` | Hyperéosinophilie et helminthes (partagé avec la FC n°3) |
| `anguillulose` | Anguillulose |
| `bilharziose` | Schistosomoses (bilharzioses) |
| `diagnostic-biologique` | Diagnostic biologique (partagé dans l'UE) |
| `traitement-prevention` | Traitement et prévention (partagé dans l'UE) |

Les sept libellés sont à ajouter à `THEME_LABELS`
(`app/src/med_engine/application/scopes.py`), bloc « parasitologie » : aucun
n'existe encore dans l'application, et `tests/test_paquets.py`
(`test_tout_theme_du_paquet_a_son_libelle`) échoue tant qu'ils manquent. Les
clés partagées sont celles du plan C16 (§0.5), au même libellé dans tous les
chapitres de l'UE ; `diagnostic` (semio_thanato) et `clinique` (sang_anemies)
ne sont pas réemployés.

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-parasito-exotiques` — Ronéosaure, « FC n°5 Parasitoses digestives « exotiques » » (12 p.), `PARASITO-MYCOLOGIE/…` (espaces insécables autour d'« exotiques », comme sur le disque) | **2025-26** | **la base** : chaque note du cours porte sa page ; c'est ce que le lecteur ouvre (`chapitre=`) |
| `src-annales-5-parasitoses-digestives-exotiques` — Ronéosaure, « 5 - Parasitoses digestives exotiques » (5 p.) | 2024-25 | les 9 questions et leur table de corrections (p. 4-5) |
| `src-sujets-parasito-2425` — sujets de parasitologie-mycologie 2024/2025, session 1 (examen du 10/01/2025, 14 p.), sans chemin | 2024-25 | 2024/2025 S1 Q4 et Q6, par `SRC["sessions"]` ; **aucun corrigé**, clés déduites du cours ; déclaration commune aux dix chapitres de l'UE, champ pour champ |
| `src-cours-parasito-exotiques-2425` — Ronéosaure, FC n°5 2024-25, Pr Cornu (14 p.) | 2024-25 | appoint, cité dans le texte : l'eau de baignade (p. 2-3), le « cosmopolite protozoaire ✪ » (p. 4), la trichocéphalose cosmopolite à hyperéosinophilie (p. 6), les « plexus artério-veineux » (p. 11), la sérologie qui persiste et la diapositive de prévention (p. 13) |
| FC n°1, n°3, n°4, n°10 2025-26 de l'UE | 2025-26 | citées dans le texte, à la page, sans être déclarées : ce sont les fiches d'autres chapitres |
| erratas : cours 2025-26 (`Erratas de Parasitologie mycologie.docx`), cours 2024-25, annales 2024-25 | — | une seule entrée sur cette FC (la p. 12 imprimée à la fin du cours de BMCP « Morts cellulaires » dans la version complète : le PDF a ses 12 pages) ; rien en 2024-25 ; l'errata des annales est vide |

**La déclaration du polycopié n°5 est partagée** : « Parasitoses digestives
autochtones » (FC n°3) en tire cinq questions (2023/2024 S1 Q1 et Q2, 2021/2022
S1 Q5, 2021/2022 S2 Q6 et Q7) et doit la copier à l'identique — identifiant
`src-annales-5-parasitoses-digestives-exotiques`, les cinq champs `id`, `kind`,
`titre`, `chemin_relatif`, `auteur`, et rien d'autre.

Vérifications hors du cours, citées dans la carte qui s'en sert : l'OMS (aide-
mémoire « Schistosomiase » : transmission par les selles et les urines dans
l'eau douce, vers adultes dans les vaisseaux, praziquantel) ; le CDC (DPDx,
« Schistosomiasis » : veinules mésentériques, plexus veineux vésical, éperons
latéral et terminal) ; e-sémio (UNF3S, « Diarrhée » : épreintes et ténesme) ;
l'étymologie (TLFi, Littré, Bailly, Gaffiot, Wiktionnaire).

## Ce que le cours a dicté

- **Les ✪**, diapositives « qui tombent régulièrement » et seront interrogées
  aux EDN (p. 1) : les deux mécanismes des diarrhées, la clinique et le
  diagnostic de l'amoebose, les hyperéosinophilies, la contamination, la
  clinique et le diagnostic de l'anguillulose et des schistosomoses, les
  conseils aux voyageurs. Toutes ont leurs cartes ; la `section` de la carte
  porte le ✪.
- **Le rouge** — antiamibien diffusible, métronidazole, antiamibien de contact
  (p. 5), parthénogenèse (p. 6), ivermectine (p. 8), praziquantel (p. 11) — a
  chacun sa carte : `pde-fa-amoebose-traitement`, `pde-qc-amoebose-traitement`,
  `pde-fa-cycle-anguillulose`, `pde-qr-ivermectine`, `pde-qr-praziquantel`.
- **Le gris** est défini par la FC elle-même : « présent sur le diaporama mais
  non détaillé par la prof » (p. 1). C'est la voix des rédacteurs, pas un « à ne
  pas retenir » : il est carté sans tag `edn` — les seuils d'hyperéosinophilie
  (p. 5, `pde-fa-hypereo-seuils`, `pde-qc-impasse`), les espèces du tableau des
  causes (p. 3, `pde-qc-causes`), les formes artério-veineuse et
  extra-intestinales de la schistosomose (p. 10, `pde-qc-schisto-formes` E).
- **Le tableau « Autres parasitoses exotiques »** (p. 11), dont les lignes et
  colonnes étoilées sont « à connaître pour les EDN » : `pde-qc-autres-parasitoses`
  et `pde-qc-transmission`.
- **Rien n'est annoncé « pas à retenir »** dans cette FC : aucune carte `edn`.
- **Ce qui appartient à d'autres chapitres** (plan C16, §2) : la définition du
  péril fécal et le principe de la courbe de Lavier ont leurs cartes dans la
  FC n°3. Ici, ils ne reviennent que dans la formulation de la FC n°5 — la
  définition comme proposition A de `pde-qc-peril-fecal`, les trois phases
  (montée, pic, décroissance) sur le schéma cliquable que le plan (§3.5)
  attribue à ce chapitre — et avec ce que la FC n°5 y ajoute : les quatre
  lieux des déjections, les seuils, l'oscillation de l'anguillulose. Les deux
  professeurs formulent la courbe un peu autrement (pic « au stade adulte » ici,
  éosinophilie qui « culmine pendant la migration » en FC n°3) ;
  `pde-fa-lavier` le dit.

## Les erreurs du Ronéosaure 2025-26

Chacune est dite par **ATTENTION**, sans genre, dans la carte qui porte la
notion.

| Page | Ce que dit le Ronéosaure | Ce qui est juste | Carte |
|---|---|---|---|
| 2 | l'épreinte, « forte douleur au niveau de la fosse inguinale gauche » | une douleur colique du cadre colique, surtout de la fosse iliaque gauche (sigmoïde), terminée par un besoin impérieux (e-sémio, UNF3S ; Larousse médical : « du côlon terminal ») | `pde-rv-epreinte-tenesme`, `lex-epreinte` |
| 8 | les adultes « se reproduisent dans les plexus artérioveineux » (comme la diapositive du cycle, et le cours 2024-25, p. 11) | des plexus **veineux** : le tableau des espèces de la même FC (p. 9), l'OMS, le CDC | `pde-qc-schisto-cycle` C, `pde-fa-cycle-schistosome` |
| 9 | la photographie légendée « furcocercaire logé au niveau des plexus artérioveineux » | des vers adultes dans des veines mésentériques (photo ANOFEL) ; la furcocercaire est une larve nageuse de 500 µm (p. 8) | `pde-qc-schisto-formes` (explication), légende de `pde-schistosomes-adultes.png` |
| 11 | « bien alerter sur les baignades en eau douce et dans les piscines » | la diapositive de la même professeure : « baignade en eau de mer et piscine uniquement » (cours 2024-25, p. 13) | `pde-qc-prevention` E |

Sans ATTENTION, parce qu'aucune réponse n'en dépend : « Hymenolepsis » pour
Hymenolepis et « Trichuris trichuria » pour T. trichiura (p. 3, comme sur la
diapositive p. 11 ; dit dans `pde-qc-autres-parasitoses` C), « Furcoceraire »
(p. 9), « classification des parasite » (plan, p. 1). Et une imprécision, dite
dans la justification de `pde-qc-entamoeba` D sans changer la clé : dans une
selle apportée trop tard, les amibes « meurent et se transforment en kyste »
(p. 3) ; l'enkystement a lieu dans le côlon, avant l'émission (la même FC,
p. 4), et la forme végétative émise meurt sans s'enkyster (CDC, DPDx).

La FC n°1 2025-26 (p. 10) écrit que l'examen parasitologique des selles se fait
« à 3 reprises, espacé de 3 semaines », et l'errata de la promo propose « 2
semaines » ; les deux contredisent ce cours (« 3 fois, sur un intervalle de 7 à
10 jours, jamais 3 jours de suite », p. 4 et p. 12 ✪). Les cartes d'ici suivent
la FC n°5 et le disent (`pde-fa-eps`, `pde-an-2223s1-qroc2`) ; l'ATTENTION
elle-même est dans le chapitre de la FC n°1.

## Ce que les annales ont dicté

| Savoir | Questions |
|---|---|
| Le péril fécal et les modes de transmission | 2022/2023 S1 Q1, 2021/2022 S1 QROC 3, 2023/2024 S1 Q10, 2024/2025 S1 4) (l'anguillulose) |
| La sérologie : amoebose hépatique, anguillulose, schistosomose, et non giardiose ni téniasis | 2024/2025 S1 6) |
| Cosmopolites et exotiques | 2021/2022 S1 Q6, 2023/2024 S1 Q10, 2021/2022 S2 QROC 3 |
| La bilharziose digestive | 2021/2022 S1 Q7 (et 2022/2023 S1 Q1 D, 2023/2024 S1 Q10 D) |
| L'amoebose | 2021/2022 S1 QROC 2 (et 2023/2024 S1 Q10 A) |
| L'hyperéosinophilie | 2021/2022 S2 QROC 3, 2023/2024 S1 Q10 A |
| L'examen parasitologique des selles | 2022/2023 S1 QROC 2 |
| Les conseils aux voyageurs (eau de boisson) | 2021/2022 S2 QROC 5 |

| Session | Question | Clé imprimée | Retenu | Carte |
|---|---|---|---|---|
| 2023/2024 S1 | Q10 parasitoses exotiques | E | E | `pde-an-2324s1-q10` |
| 2022/2023 S1 | Q1 péril fécal | ABCE | **ABCDE** | `pde-an-2223s1-q1` |
| 2022/2023 S1 | QROC 2 EPS, modalités | EPS, 3 fois sur 7 à 10 jours | idem, complété | `pde-an-2223s1-qroc2` |
| 2021/2022 S1 | Q6 cosmopolites | « BC (D) » (n°5) / BCD (n°8) | **BCD** | `pde-an-2122s1-q6` |
| 2021/2022 S1 | Q7 bilharziose digestive | ABCDE | ABCDE | `pde-an-2122s1-q7` |
| 2021/2022 S1 (table : « Session X ») | QROC 2 entités d'E. histolytica | dysenterie amibienne ; amibiase hépatique | idem | `pde-an-2122s1-qroc2` |
| 2021/2022 S1 (table : « Session X ») | QROC 3 modes de transmission | transcutanée, orale ; IST, materno-fœtale, greffe, transfusion | idem | `pde-an-2122s1-qroc3` |
| 2021/2022 S2 | QROC 3 cosmopolites à hyperéosinophilie | oxyurose, ascaridiose, taeniasis | idem | `pde-an-2122s2-qroc3` |
| 2021/2022 S2 | QROC 5 eau de boisson | boissons contrôlées ; ni jus, ni glaces, ni glaçons | idem | `pde-an-2122s2-qroc5` |
| 2024/2025 S1 | 4) transmission de l'anguillulose | aucune (sujet sans corrigé) | **DE**, déduite | `pde-an-2425s1-q4` |
| 2024/2025 S1 | 6) parasitoses à sérologie | aucune (sujet sans corrigé) | **BCE**, déduite | `pde-an-2425s1-q6` |

Les cinq autres questions du polycopié n°5 (giardiose, ténias) sont dans
« Parasitoses digestives autochtones ». Deux questions d'ici sont aussi
imprimées ailleurs pour la même session — 2021/2022 S1 Q6 dans « 8.
Ectoparasitoses », 2021/2022 S1 QROC 3 dans « 7. Mycoses de l'immunodéprimé »
— et ne sont cartées qu'une fois.

## Le schéma cliquable et la planche

| Fichier | Ce qu'on clique | Cartes |
|---|---|---|
| `courbes-eosinophilie-nues.svg` (`pde-zo-eosinophilie`) | sur la courbe à un seul pic, la migration larvaire, le stade adulte, l'émission des parasites ; la courbe de l'anguillulose ; celle de l'impasse parasitaire | 5 |

Trois panneaux à la même échelle, sans titre ni nom de phase : une courbe à un
seul pic (un ver intestinal à migration larvaire, l'Ascaris, vers 2 000/mm³),
une courbe qui oscille (l'anguillulose), une courbe qui monte au-dessus de
3 000 et y reste (l'impasse). Les pointillés à 1 500 et 3 000/mm³ sont les
seuils du cours (p. 5). Les trois phases de la courbe de Lavier sont trois
bandes verticales qui se touchent sans se recouvrir. La version légendée,
`courbes-eosinophilie.svg`, tirée des mêmes constantes, est en correction ; la
courbe photographiée du cours (`pde-courbe-lavier.png`) illustre les QCM.

**La planche** `pde-pl-oeufs` : la diapositive des œufs (p. 10), ses deux
légendes effacées par `scripts/planche_depuis_image.py` — 1, l'œuf de
S. haematobium (éperon terminal) ; 2, l'œuf de S. mansoni (éperon latéral) —
et quatre intrus (œuf d'Ascaris, embryophore de Taenia, kyste de Giardia, œuf
de S. japonicum). Les cadres blancs vidés restent : la case à remplir. L'aperçu
de contrôle a été relu : aucun reste de lettre. Les mesures des œufs, dans les
légendes effacées, ne sont pas demandées (« jamais de question sur la taille
d'un parasite », dit la FC n°3).

**Illustrations** : 30 QCM sur 33 (91 %) portent une figure de la fiche en
correction ; 56 notes sur 78. Les deux annales 2024/2025 sont illustrées (le
cycle de l'anguillulose, celui de l'amoebose). Les trois QCM sans figure
(`pde-qc-mecanismes`, `pde-qc-amoebose-traitement`, `pde-qc-eau-boisson`)
n'en ont pas dans la fiche : ces parties du cours sont du texte.

## Les clés qui ne sont pas reprises telles quelles

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2022/2023 S1 Q1 (maladies liées au péril fécal) | ABCE | **ABCDE** (`officielle=False`) | D, la bilharziose : le cours range l'eau de baignade parmi les lieux des déjections, « notamment pour les schistosomes » (FC n°5 p. 2 ; cours 2024-25 p. 2-3) ; le péril fécal vient des excréments, « selles, urines » (FC n°3 p. 2) ; l'OMS fait naître la transmission de selles ou d'urines dans l'eau douce. La lecture féco-orale stricte exclurait aussi l'anguillulose (E), que la même clé compte vraie. Conflit déclaré sur D ; la carte rappelle que la table l'a cotée fausse |
| 2021/2022 S1 Q6 (parasitoses cosmopolites) | « BC (D) » dans le n°5, BCD dans le n°8 | **BCD** (gardée officielle : imprimée telle quelle dans le n°8) | la gale est « une parasitose cosmopolite et contagieuse » (FC n°10 2025-26, p. 2 et 5). Conflit déclaré sur D |
| 2024/2025 S1 4) (transmission de l'anguillulose) | aucune (sujet sans corrigé) | **DE** (`officielle=False`) | clé déduite de la FC 2025-26 : pénétration transcutanée de la larve strongyloïde, sable souillé, « lié au péril fécal » ✪ (p. 3, 6) ; ni animal, ni aliment, ni eau bue |
| 2024/2025 S1 6) (parasitoses diagnostiquées par sérologie) | aucune (sujet sans corrigé) | **BCE** (`officielle=False`) | clé déduite : sérologie de l'anguillulose (p. 8), de l'amoebose hépatique (p. 4-5), de la schistosomose (p. 10-11) ; « complètement inutile » pour Giardia (FC n°3 2025-26, p. 7), réservée à la cysticercose et non au téniasis (FC n°3, p. 16-17) |

Reprises, avec une remarque dans la carte : **2023/2024 S1 Q10** (la note du
secrétariat sur B, « présent mondialement mais plus dans les régions
tropicales ?? » : B reste fausse, Strongyloides est exotique, p. 3 et 6) ;
**2021/2022 S1 QROC 2 et 3** (rangés sous « Session X » dans la table : les
énoncés et le polycopié n°7 les datent de 2021/2022 S1).

Cas ouvert : aucun, sinon la validation des deux clés ci-dessus (questions pour
Vincent).

## Le lexique

Dix termes, aux pages mesurées dans la fiche 2025-26 (texte du PDF, mot entier,
pluriel permis, la méthode de `scripts/chercher_pages.py`) : épreinte (p. 2),
ténesme (2), amoebose (1, 3, 4 — « Amœbose » p. 1), parthénogenèse (6), larva
currens (7), syndrome de Löffler (6, 7), rhabditoïde (6, 7, 8), furcocercaire
(8, 9), bilharziose (schistosomose) (1, 2, 5, 8-11 — les pages des deux noms,
synonymes dans le cours), anguillulose (1-3, 5-8, 11). Chacun dit son origine
grecque ou latine. Les termes que la FC n°3 accueille — péril fécal,
cosmopolite, hyperéosinophilie, prurit — ne sont pas repris ici (plan C16,
§3.3). « Dysenterie » est déjà au lexique de la sémantique.

**Parthénogenèse** est déjà au lexique de BMCP (`lex-parthenogenese`,
`bmcp_cellules_souches`), une autre UE : le terme de parasitologie prend
l'identifiant `lex-parthenogenese-parasito`, comme `lex-phagocytose-bmcp`, pour
ne pas écraser la note de BMCP à l'import.

Les étymologies nouvelles — neuf racines (`teinein (grec)`, `amib(o)- /
amoeb(o)-`, `larva (latin)`, `currere (latin)`, `rhabd(o)-`, `furca (latin)`,
`cerc(o)- / -cercaire`, `schist(o)-`, `anguilla (latin)`) et les dix termes —
sont **proposées** dans le brouillon `etym/parasito_digestives_exotiques.json`,
avec leurs sources ; `scripts/etymologies.json` n'est pas modifié par ce
chapitre. Les définitions et les racines disent déjà, mot pour mot, ce
qu'`appliquer_etymologies.py` en écrira. Les racines réemployées gardent la clé
de la table : `exprimere (latin)`, `-ose`, `parthén(o)-`, `-genèse`, `syn-
(grec)`, `dromos (grec)`, `-oïde`, `-some`. `parthén(o)-` et `-genèse` citent la
FC de sémantique 1 2026-27 (p. 7, où « parthénogenèse » est l'exemple même),
`syn-` et `-drome` la FC de sémantique 2 (p. 2, « syndrome »), `-ose` la même
(p. 9). La racine `cerc(o)- / -cercaire` (κέρκος) est proposée sous la même
clé, au contenu identique, par « Parasitoses digestives autochtones »
(cysticercose).

## Questions pour Vincent

1. **Deux clés autres que l'imprimée** (plan C16, question 2, pour ce
   chapitre) : la bilharziose liée au péril fécal (2022/2023 S1 Q1 D, retenu
   vrai contre la table) et la gale cosmopolite (2021/2022 S1 Q6 D, les deux
   polycopiés en désaccord, retenu vrai). Les valides-tu, ou préfères-tu que la
   carte réponde comme la table imprimée ? La carte dit les deux lectures.
2. **L'examen parasitologique des selles** (plan C16, question 3) : la FC n°1
   p. 10 écrit « espacé de 3 semaines », l'errata de la promo « 2 semaines » ;
   la FC n°3, la FC n°5 (✪) et le corrigé de 2022/2023 S1 QROC 2 disent « 3 fois
   sur 7 à 10 jours ». Les cartes d'ici suivent la FC n°5 : d'accord ?
3. **L'examen du 5 janvier 2027** (plan C16, question 5) : faut-il le déclarer
   (`EXAMENS`) dans les chapitres des quatre UE de janvier, ou le laisser au
   réglage de l'application, comme jusqu'ici ? Il n'est pas déclaré ici.

## À relire

Aucune carte `a-relire` : chaque carte de cours porte sa page dans la fiche
2025-26, chaque annale 2024/2025 sa clé déduite à la page, chaque autre annale sa clé vérifiée sur la table (p. 4-5 du polycopié, la
p. 4 relue en image, et sur celle du polycopié n°8 pour 2021/2022 S1 Q6). À la parution du ronéo 2026-27 de ce cours, relire toutes les
cartes contre lui : pages, chiffres (10 % d'invasif, 90 % d'E. dispar, 10 cm/h,
seuils de 1 500 et 3 000, 2 à 3 mois), les quatre erreurs ci-dessus, et la
diapositive de prévention (eau de mer et piscine).


## L'échelle : Simple → Moyen → Annale (C20, 19/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 5 janvier. Sous les annales, 30 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 8 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`) ; les QROC reçoivent le schéma nu.

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `peril-fecal` | 10 | 2 | 4 |
| `amoebose` | 2 | 1 | 1 |
| `hypereosinophilie` | 2 | 1 | 1 |
| `anguillulose` | 2 | 1 | 1 |
| `bilharziose` | 5 | 1 | 1 |
| `diagnostic-biologique` | 6 | 1 | 2 |
| `traitement-prevention` | 3 | 1 | 1 |

**Le schéma** `ech-parasitoses-exotiques`, « Amibe, anguillule, schistosomes · s'infester, se manifester, se prouver », donne 45 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_PARASITOSES_EXOTIQUES`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Un ATTENTION ajouté** (C29, 19/10) sur 2023/2024 S1 Q10 A : la FC n°3 dit que les protistes n'engendrent « pas normalement » d'hyperéosinophilie, moins absolu que ce cours ; le chapitre des parasitoses autochtones en fait un point douteux. La marche `pde-ech-s4` le dit aussi.

**Sans marche** :
- pde-an-2425s1-q6 A : la sérologie du téniasis (réservée à la cysticercose) n'est que dans la FC n°3 2025-26 (p. 16-17), la fiche d'un autre chapitre ; lettre posée sur la case de la sérologie, sans marche.
- pde-an-2425s1-q6 D : la sérologie « complètement inutile » de la giardiose n'est que dans la FC n°3 2025-26 (p. 7) ; lettre posée sur la case de la sérologie, sans marche.
- pde-an-2223s1-q1 A : la transmission de Giardia par le péril fécal est enseignée dans la FC n°3 2025-26 (p. 2-5) ; la FC n°5 ne fait que ranger Giardia parmi les cosmopolites (p. 3). Lettre posée sur la case de Giardia, sans marche.
- pde-an-2122s1-q6 A : le paludisme tropical relève de la FC n°4 2025-26 (p. 4), hors de ce chapitre ; lettre posée sur la case de Giardia (la répartition), sans marche.
- pde-an-2122s1-q6 D : la gale cosmopolite relève de la FC n°10 2025-26 (p. 2, 5) — conflit déclaré entre les polycopiés n°5 et n°8 — ; lettre posée sur la case de Giardia (la répartition), sans marche.

## Régénérer

```powershell
cd contenu\chapitres\parasito_digestives_exotiques
..\..\..\app\.venv\Scripts\python.exe generer.py
```

La planche se refait depuis `app/`, si ses rectangles changent :
`uv run --with pillow python ../.claude/skills/nouveau-chapitre/scripts/planche_depuis_image.py ../contenu/chapitres/parasito_digestives_exotiques pde-pl-oeufs --apercus <brouillon>`.
