# Marqueurs viraux et application au diagnostic virologique — paquet Virologie

79 notes, 133 cartes. Chapitre `chap-ue-virologie-fc4` de l'UE Virologie
(ordre 4). Cours du **Pr Hober** en deux séances : le **15/10/2025**, 11 h-12 h
(FC n°4 du Ronéosaure 2025-26, 7 pages), et le **22/10/2025**, 10 h-11 h
(FC n°5, « Marqueurs viraux II », p. 1-7) ; annales des polycopiés VIRO n°4 et
VIRO n°7 du Ronéosaure 2024-25 (14 questions, 10 sessions). Examen de
virologie du 5 janvier 2027.

**18/10/2026** : 1 question du sujet de virologie 2025/2026 (examen du
08/01/2026, sans corrigé) — Q.8 ; voir « Le sujet 2025/2026 ».

**Une fiche provisoire.** Le ronéo 2026-27 de ce cours n'est pas paru (la
virologie 2026-27 commence le 06/10) : le chapitre est carté sur le
Ronéosaure 2025-26 (décision de Vincent du 02/10), et le ronéo de l'année
corrigera les cartes à sa parution. Chaque source porte son année dans son
auteur : les cartes de cours prennent le tag `cours-2025-26` et le badge
« Cours 2025-26 ». Aucune carte ne dit « Absent du cours 2026-27 », et les
erreurs du Ronéosaure sont dites par un ATTENTION sans genre (précédent
d'`immuno_innee`) : la liste des erreurs de la promo,
`contenu/ERRATA_RONEOS_2026-27.md`, ne concerne que les ronéos 2026-27.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 37 | 37 |
| QRU | 2 | 2 |
| Texte à trous | 12 | 66 |
| QROC | 9 | 9 |
| Recto-verso | 8 | 8 |
| Planche à légender | 2 | 2 |
| Lexique | 9 | 9 |

Dont **15 annales** (QRM), sur 11 sessions, de 2018/2019 S1 à 2022/2023 S2, et 2025/2026.
Les 24 QCM du cours ont une justification par proposition, comme les
annales.

Sept thèmes, dans l'ordre du cours :

| Clé | Libellé |
|---|---|
| `diagnostic-interets` | Intérêts et objectifs du diagnostic virologique |
| `prelevements-viraux` | Les prélèvements virologiques |
| `culture-virale` | Examen direct et culture virale |
| `detection-antigenes` | Détection des antigènes viraux |
| `genome-pcr` | Détection du génome viral (PCR) |
| `serologie-virale` | Diagnostic indirect : la sérologie |
| `interpretation-diagnostic` | Interpréter un résultat virologique |

Les sept libellés sont à ajouter à `THEME_LABELS`
(`app/src/med_engine/application/scopes.py`) ; aucune clé n'est prise par un
autre chapitre. Le plan C16 proposait `prelevements` et `serologie` : ce sont
deux mots que d'autres UE voudront (la parasitologie a sa sérologie, ses
prélèvements), avec un libellé qui ne dit vrai qu'en virologie. La relecture
les a rendus propres à la virologie, `prelevements-viraux` et
`serologie-virale`, comme le veut la règle des clés (« absorption-intestinale »,
pas « absorption »).

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-viro-fc4` — Ronéosaure, « FC n°4 Marqueurs viraux et application au diagnostic virologique » (7 p.), `VIROLOGIE/…` | **2025-26** | **la base**, première partie du cours ; ce que le lecteur ouvre (`chapitre=`) |
| `src-fc-viro-fc5` — Ronéosaure, « FC n°5 Marqueurs viraux 2 » (12 p.), `VIROLOGIE/…` | **2025-26** | p. 1-7 : la fin du cours (les cartes la nomment, `fiche=`) ; ses p. 8-12 ouvrent « Pathogènes viraux I » et sont à `viro_pathogenes_1` |
| `src-annales-virologie-4-marqueurs-viraux-application-au-diagnostic-virologique` — VIRO n°4 (7 p.) | 2024-25 | 12 questions et leur table (p. 6-7) |
| `src-annales-virologie-7-pathogenes-viraux-iii` — VIRO n°7 (32 p.) | 2024-25 | la session 2022/2023 S2 (Q13, Q14), et la seconde table de 2022/2023 S1 |
| FC n°1 partie 2, n°2, n°7, n°8, n°11 2025-26 | 2025-26 | cités dans le texte, à la page, sans être déclarés : gp120 et CD4 (FC n°1 partie 2 p. 14), p53 et adénovirus (FC n°2 p. 5), rougeole et salive (FC n°7 p. 2), IgM anti-VHA (FC n°8 p. 7), profil du western-blot du VIH (FC n°8 p. 17), varicelle de la femme enceinte et IgM du nouveau-né (FC n°11 p. 7-8) |
| cours 2024-25, FC n°4 (p. 13-14) | 2024-25 | **seulement dans les justifications d'annales**, pour les comprendre (IgM anti-VHA, salive de la rougeole, varicelle de la femme enceinte, IgM fœtales) ; aucune carte de cours ne le cite |
| erratas du Ronéosaure : cours 2025-26 (`Erratas Virologie.docx`) et annales 2024-25 | — | **aucune entrée** sur la FC n°4, sur les p. 1-7 de la FC n°5, ni sur VIRO n°4 |

**Déclarations partagées**, copiées à l'identique (vérifié champ par champ à
la relecture) : la FC n°5 comme dans `viro_pathogenes_1` et
`viro_multiplication` (`pages=12`, rattachée à ce chapitre) ; VIRO n°4 comme
dans `viro_pathogenes_1` ; VIRO n°7 comme dans `viro_multiplication` et
`viro_pathogenes_3`.

`EXAMENS` : l'examen de virologie du 5 janvier 2027, porté sur l'UE, identique
dans les dix chapitres.

## Ce que le cours a dicté

- **Le rouge** de la FC n°4 : « Diagnostic direct » et « Diagnostic indirect »
  (p. 3), qui ont leur texte à trous (`mar-fa-deux-approches`), leur QCM et
  leur recto-verso ; « leur présence ne prouve pas toujours une infection
  active (donc interprétation des résultats ++) » (p. 4), repris dans
  `mar-qc-elimination` et `mar-qc-portage`. Pas de gris défini comme hors
  programme.
- **Le partage de la FC n°5** (plan C16) : ses p. 1-7 sont ici, ses p. 8-12
  (virus respiratoires) dans `viro_pathogenes_1`. Les cartes d'ici citent la
  p. 10 de la FC n°5 quand elle tranche une annale (« pour les virus
  respiratoires, le diagnostic direct »), sans la carter.
- **Ce qu'aucune FC 2025-26 de ce cours ne dit** et que les annales demandent :
  le diagnostic de l'hépatite A (IgM anti-VHA, FC n°8 p. 7), la salive dans la
  rougeole (FC n°7 p. 2), la varicelle de la femme enceinte (FC n°11 p. 8) —
  cités dans les justifications, sans carte de cours.
- **« C'est important à savoir »** (FC n°5 p. 7, la dengue sans anticorps les
  8 premiers jours) : `mar-qc-remarques` A et B.

## Les erreurs du Ronéosaure 2025-26

L'errata de la promo n'a aucune entrée sur ces pages. Trouvée en relisant, et
dite par **ATTENTION**, sans genre :

| Page | Ce que dit le Ronéosaure | Ce qui est juste | Carte |
|---|---|---|---|
| FC n°5, 6 | dilution du sérum « de 2 en 2 au dixième donc 10 20 30 40 ..160ème » | 10, 20, 40, 80, 160 : la plaque de la diapositive de la même page (et le cours 2024-25, p. 18, « de 2 en 2 10 20 40 80 ») | `mar-qc-titre` B |

Sans ATTENTION, parce qu'aucune réponse n'en dépend :
- « contexte père-enfant » pour mère-enfant (FC n°5 p. 3) ;
- l'efficacité d'une vaccination mêlée à la résistance aux antiviraux (FC n°4
  p. 3) : aucune carte sur la phrase, l'objectif est carté d'après la FC n°5
  p. 3 (« on vérifie si le sujet a produit une quantité d'Ac suffisante ») ;
- les protéines « marquées au SDS » (FC n°5 p. 5) : le SDS les charge, il ne les
  marque pas ; les cartes disent « traitées au SDS » ;
- un second titre « D. Les prélèvements » pour « D. Application » (FC n°5 p. 3) ;
- « seulement la p24 et c'est un cas de faux positif » (FC n°5 p. 5) est
  raccourci : le cours du VIH dit qu'au début de l'infection on renouvelle les
  détections et que le profil se complète (FC n°8 p. 17) ;
  `mar-qc-western-blot` D cote la formule « suffit à affirmer l'infection »,
  fausse dans les deux lectures, et cite les deux pages.

## Ce que les annales ont dicté

| Savoir | Questions |
|---|---|
| Intérêts du diagnostic : immunodéprimés, greffés, symptômes absents, médico-économie, donneurs | 2022/2023 S1 et S2 Q13, 2021/2022 S1 et S2 Q13 |
| Nouveau-né et fœtus : IgM et non IgG, indirect applicable | 2022/2023 S1 et S2 Q13 E, 2021/2022 S1 et S2 Q13 E |
| Direct ou indirect : VHA (indirect), virus respiratoire (direct), p24 (direct) | 2018/2019 S1 et S2 Q18, 2019/2020 S1 et S2 Q3, 2020/2021 S1 Q.18, 2020/2021 S2 Q4, 2022/2023 S1 Q.14 |
| Immunofluorescence (antigènes dans les cellules), ELISA antigène | les six questions « diagnostic des infections virales » (2018/2019 à 2020/2021) |
| Immunochromatographie : selles (rotavirus, adénovirus), nasopharynx | les mêmes, et 2021/2022 S1 Q.14, 2022/2023 S1 et S2 Q14 |
| IgM dans le LCR, PCR dans le LCR, liquides du diagnostic indirect | 2018/2019 à 2020/2021 E, 2022/2023 S1 et S2 Q14 C, 2021/2022 S1 et S2 Q14 B |

Doublons, une carte chacun : 2022/2023 S1, 2021/2022 S1 et S2 Q13-Q14 sont
aussi dans VIRO n°7 ; 2018/2019 S1 Q18 dans VIRO n°5. La table de VIRO n°4
porte « 2023/2024 S1 Q5/ BCE » sans énoncé : c'est la question VIH de VIRO n°7,
cartée dans `viro_pathogenes_3`. Les questions VHC, EBV et gastro-entérites
de VIRO n°4 sont dans les chapitres de leur sujet.

## Les planches

Aucun schéma cliquable : le chapitre n'a pas de lieu à désigner (les sites de
prélèvement sont en texte à trous). Deux planches à légender, tirées des
diapositives de la FC n°5 par `scripts/planche_depuis_image.py` :

| Planche | Figure | Numéros | Intrus |
|---|---|---|---|
| `mar-pl-elisa` | l'ELISA indirect, p. 4 | antigène fixé, sérum du patient, anticorps anti-humain marqué, substrat chromogène, révélation colorimétrique | anticorps de capture, antigène soluble du prélèvement, complément, fluorescéine, amorces |
| `mar-pl-western-blot` | western-blot d'un sujet contaminé 30 jours plus tôt par le VIH-1, p. 5 | gp160, gp120, p68, p55, gp41, p40, p34, p24, p17, contrôle négatif, contrôle positif | p53, Ag HBs, NS1 |

Les aperçus de contrôle ont été relus. Sur l'ELISA, le « e » final
d'« enzyme » mord sur la flèche du substrat : le rectangle qui l'efface laisse
une encoche de 12 × 20 px dans la flèche, qui reste lisible. Les gènes des
bandes du western-blot (env, gag, pol) viennent des notices des trousses de
western-blot VIH-1 (gp160, gp120, gp41 : env ; p55, p40, p24, p18 : gag ; p65,
p51, p31 : pol) ; le cours ne nomme que la gp160 et la p24.

**Illustrations** : 34 QCM sur 39 (87 %) portent une diapositive de la fiche en
correction ; 56 notes sur 79. Les cinq QCM sans figure (`mar-qc-objectifs`,
`mar-qc-elimination`, `mar-qc-immunochromatographie`, `mar-qc-nouveau-ne`,
`mar-qc-chronique`) n'en ont pas dans la fiche.

## Le sujet 2025/2026 (18/10/2026)

Le sujet de virologie de l'examen du 08/01/2026 (cahier de 30 QCM,
`src-sujet-viro-2526`, sans corrigé), déposé le 18/10/2026, apporte 1 question
à ce chapitre (Q.8) ; les autres questions vont aux chapitres de leur cours.
Aucune n'était déjà en cartes. Chaque clé est déduite du cours 2025-26,
l'année de l'examen, proposition par proposition et page à l'appui
(`officielle=False`) ; les propositions déjà posées d'autres années ont servi
de contre-épreuve, et l'explication dit chaque reprise. Rédigées et
contre-vérifiées le 18/10/2026 : un rédacteur, un sceptique qui a refait
chaque clé sur le cours, un critique de complétude. Le profil des clés — A
souvent vraie, trois ou quatre vraies par question — est celui des sessions 1
officielles du Pr Hober (2021/2022 S1, 2023/2024 S1).

| Question | Clé imprimée | Retenue | Lecture |
|---|---|---|---|
| 2025/2026 Q.8 (`mar-an-2526-q8`) | aucune (sujet sans corrigé) | **ABCD** | Ce qui décide est ce qu'on cherche, non le liquide : le virus ou ses constituants (direct), la réponse de l'hôte (indirect) ; le sérum et le LCR se prêtent aux deux. |

Ce qui est signalé :

- La première question du chapitre tirée d'un sujet d'examen ; ses annales
  s'arrêtaient à la session 2022/2023 S2.
- Q.8 C, « sont applicable », gardé tel qu'imprimé ; A et E sans point final.
- Q.8 E tombe sur « protéines virales » : le western-blot révèle les ANTICORPS
  du sérum ; « sensible » est au mieux imprécis pour un test dont la qualité
  est la spécificité. La justification dit les deux.
- A et B citent aussi l'ED 1 de virologie (Pr Hober, Ronéosaure 2024-25, rangé
  dans le dossier des ED du Ronéosaure 2025-26), cité dans le texte comme les
  autres fiches d'appoint ; la clé tient sur la FC n°4, p. 3.

## Les clés qui ne sont pas reprises telles quelles

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2022/2023 S1 Q.14 (ELISA VHA, IgM rougeole, PCR du LCR, immunochromatographie, p24) | ABD (VIRO n°4) ; ABDE (VIRO n°7) | **ABDE** | E, l'ELISA qui détecte l'antigène p24 appliqué au diagnostic direct : vrai — FC n°4 2025-26 p. 6 (Ag p24 parmi les applications de l'ELISA antigène), FC n°5 2025-26 p. 2 (l'antigène p24 « relève du diagnostic direct »). Conflit sur E, `officielle=False` |

Reprises telles quelles, avec une remarque dans la carte : le second titre
« 2019/2020, session 1 » de VIRO n°4 (c'est la session 2 de la table, juste
item par item) ; 2018/2019 S2, numérotée Q18 dans l'énoncé et « Q1 » dans la
table ; 2021/2022 S1 Q.14 D, « indirect mais pas … indirect », fausse dans
toutes les lectures ; « immunochomatogaphie » (2019/2020 S2, 2018/2019 S2).

Cas ouvert : aucun.

## Le lexique

Neuf termes, aux pages mesurées dans les fiches 2025-26 (recherche insensible
aux accents dans le texte des PDF) : séroconversion (FC n°5 p. 3, 4),
séro-élévation (3, 4), sérodiagnostic (2), immunochromatographie (FC n°4 p. 5 ;
FC n°5 p. 10 ; FC n°6 p. 11 ; FC n°11 p. 10), immunofluorescence (FC n°4
p. 6), avidité (FC n°5 p. 4), effet cytopathique (FC n°4 p. 3, 5 ; FC n°5 p. 6,
où il est écrit « ECP » ; FC n°2 p. 2 ; FC n°1 partie 2 p. 2, 5, 6),
western-blot (FC n°5 p. 5 ; FC n°8 p. 17), séroneutralisation (FC n°5 p. 6).

« Séroconversion » et « Avidité » sont déjà des termes d'autres UE
(`lex-seroconversion` en parasitologie, `lex-avidite` en immunologie) : ils
sont repris ici sous `lex-seroconversion-viro` et `lex-avidite-viro`
(précédent `lex-papule-viro`), pour le lexique de la virologie.

Les étymologies nouvelles — trois racines (`elevare (latin)`,
`western (anglais)`, `blot (anglais)`) et les neuf termes — sont
**proposées** dans `scratchpad/etym/viro_marqueurs.json`, avec leurs sources
(TLFi par l'API du CNRTL, Gaffiot, Bailly, etymonline, Wiktionnaire) ; la table
n'est pas modifiée par ce chapitre. Les définitions et les racines disent déjà,
mot pour mot, ce qu'`appliquer_etymologies.py` en écrira (vérifié : il ne
changerait aucun texte). Les racines réemployées gardent la clé de la table :
`serum (latin)`, `conversio (latin)`, `dia-`, `-gnose`, `immun(o)-`,
`-chrome / chromat-`, `-graphie`, `fluor- (latin)`, `avidus (latin)`,
`efficere (latin)`, `cyt(o)- / -cyte`, `-pathie`, `neutr(o)-`.
« Western-blot » n'a pas d'étymon grec ni latin : il est rangé « Mot
français, emprunté à l'anglais », comme `lex-kwashiorkor`.

## Questions pour Vincent

1. **La planche du western-blot** demande les neuf bandes de la diapositive
   (gp160, gp120, p68, p55, gp41, p40, p34, p24, p17) ; le cours oral n'en
   nomme que deux (gp160, p24) et les annales parlent de p24 et de gp120. On la
   garde entière (proposé : oui, l'ordre des poids moléculaires s'apprend avec
   elle, comme le plan C16 le proposait), ou on la réduit aux bandes de
   l'enveloppe et à la p24 ?

## Relecture (05/10)

Chaque carte relue contre la page qu'elle cite, chaque clé d'annale contre la
table de VIRO n°4 (rendue en image), celle de VIRO n°7 et l'errata des
annales. Corrigé : les deux clés de thème génériques (ci-dessus) ; les
citations du cours 2024-25 retirées des cartes de cours (`mar-qc-portage`,
`mar-qc-immunochromatographie`, `mar-qc-western-blot`, `mar-qc-chronique`,
lexique de l'immunochromatographie), remplacées par la fiche 2025-26 ou par la
FC n°8 p. 17 ; les explications des deux Q13 de 2022/2023, qui comptaient mal
les items retournés (quatre, pas trois) ; les énoncés « jusqu'au 1/160 et plus
au 1/320 », lus à contresens, devenus « mais plus » ; la proposition B de
`mar-qc-microscopie`, qui faisait de l'astrovirus un virus non cultivable ;
deux pages de lexique ajoutées (FC n°11 p. 10, FC n°8 p. 17).

## À relire

Aucune carte `a-relire` : chaque carte de cours porte sa page dans la fiche
2025-26, chaque annale sa clé vérifiée contre le cours. À la parution du ronéo
2026-27 de ce cours, relire toutes les cartes contre lui : pages, chiffres
(3 heures pour l'ARN, ×4 à 2-3 semaines, 70-80 % de chronicité du VHC,
8 jours sans anticorps dans la dengue), et l'erreur ci-dessus.


## L'échelle : Simple → Moyen → Annale (C20, 19/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 5 janvier. Sous les annales, 25 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 6 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`).

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `diagnostic-interets` | 11 | 3 | 5 |
| `detection-antigenes` | 7 | 1 | 4 |
| `serologie-virale` | 6 | 1 | 4 |
| `interpretation-diagnostic` | 1 | 1 | 2 |

**Le schéma** `ech-diagnostic`, « Le diagnostic virologique · direct, indirect, et pourquoi », donne 47 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_DIAGNOSTIC`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**`schemas.py` créé** (C29, 19/10) : le chapitre n'avait pas de schéma cliquable ; le fichier ne porte que le schéma de l'échelle.

## Régénérer

```powershell
cd contenu\chapitres\viro_marqueurs
..\..\..\app\.venv\Scripts\python.exe generer.py
```

Les planches se refont depuis `app/`, si leurs rectangles changent :
`uv run --with pillow python ../.claude/skills/nouveau-chapitre/scripts/planche_depuis_image.py ../contenu/chapitres/viro_marqueurs <mar-pl-elisa | mar-pl-western-blot> --apercus <brouillon>`.
