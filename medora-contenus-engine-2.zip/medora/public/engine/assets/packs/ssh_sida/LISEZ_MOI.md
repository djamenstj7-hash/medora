# Histoire sociale : l'émergence du SIDA — paquet SSH

76 notes, 163 cartes. Chapitre `chap-ue-ssh-fc11` de l'UE SSH. Cours du
**Pr Devinant, le 21/11/2025** (8 h-10 h, semaine 10), « Histoire sociale :
l'émergence du SIDA » (FC n°11 du Ronéosaure 2025-26, 9 pages). **Une
annale** : aucun polycopié 2024-25 ne porte sur ce cours ; la QROC 2 du sujet
de SSH 2025/2026 en apporte une. Examen de SSH du
6 janvier 2027, écrit (« 10 QROC + 1 QR »).

**18/10/2026** : 1 recto-verso du sujet de SSH 2025/2026 (examen du
09/01/2026, sans corrigé) — QROC 2 ; voir « Le sujet 2025/2026 ».

**Une fiche provisoire.** Le ronéo 2026-27 de ce cours n'est pas paru (le
cours a lieu fin novembre) : le chapitre est carté sur le Ronéosaure 2025-26
(décision de Vincent du 02/10), et le ronéo de l'année corrigera les cartes à
sa parution. La source porte son année dans son auteur (« Ronéosaure
2025-26 ») : chaque carte de cours prend le tag `cours-2025-26`, et l'écran
montre « Cours 2025-26 ». Aucune carte ne dit « Absent du cours 2026-27 », et
les erreurs du Ronéosaure sont dites par un ATTENTION sans genre : la liste des
erreurs de la promo, `contenu/ERRATA_RONEOS_2026-27.md`, ne concerne que les
ronéos 2026-27.

**Un cours de deux heures qui en vaut deux.** En 2024-25, le même cours tenait
en deux séances (Ronéosaure 2024-25, FC n°11 et FC n°14 « SIDA Partie 2 ») ;
la fiche 2025-26 contient les deux. Le chapitre prend l'identifiant `fc11` du
squelette ; `chap-ue-ssh-fc14` (« SIDA Partie 2 ») ne sert pas, sans quoi il
ferait doublon (plan C16).

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 14 | 14 |
| Texte à trous | 15 | 94 |
| QROC | 26 | 26 |
| Recto-verso | 10 | 10 |
| Schéma cliquable | 2 | 10 |
| Lexique | 9 | 9 |
| **Total** | **76** | **163** |

L'examen est rédactionnel : le chapitre est surtout fait de QROC, de textes à
trous et de recto-verso, dont deux questions de synthèse dans la forme d'une QR
(`sida-rv-construction` : en quel sens le sida est-il une construction
sociale ? ; `sida-rv-trois-sens` : en quels sens est-il une maladie
nouvelle ?). Les quatorze QCM portent les pièges, chacun avec une
justification par proposition.

Six thèmes, dans l'ordre du cours (clés nouvelles ; libellés sans chiffre, à
ajouter à `THEME_LABELS`, bloc « ssh ») :

| Clé | Libellé | Notes |
|---|---|---|
| `construction-sociale` | La construction sociale de la maladie | 6 |
| `metaphores-maladie` | Les métaphores de la maladie et la stigmatisation | 8 |
| `sida-emergence` | L'émergence publique du sida | 21 |
| `sida-chronicite` | Le sida, maladie chronique | 6 |
| `militantisme-sante` | Associations de malades et militantisme en santé | 13 |
| `maladie-nouvelle` | Une maladie nouvelle ? Grmek et la pathocénose | 12 |

Le plan C16 proposait « L'émergence du sida, 1981-1986 » : un libellé ne porte
pas de chiffre (`test_le_chapitre_se_decoupe_en_themes_lisibles`), d'où
« L'émergence publique du sida ».

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-ssh-sida` — Ronéosaure, « FC n°11 - Histoire sociale _ l’émergence du SIDA » (9 p.), `SSH/…` | **2025-26** | **la base** : chaque note porte sa page ; c'est ce que le lecteur ouvre (`chapitre=`) ; fiche provisoire en attendant le ronéo 2026-27 |
| `src-cours-ssh-sida-2425` — Ronéosaure, FC n°11 (6 p.), Pr Devinant | 2024-25 | appoint, cité dans le texte des cartes : les conditions de Hacking numérotées de 0 à 3 (p. 2), les quatre temps (p. 3-6) ; c'est lui qui montre que plusieurs erreurs sont « le cours lui-même » |
| `src-cours-ssh-sida-2425-2` — Ronéosaure, FC n°14 « SIDA Partie 2 » (3 p.) | 2024-25 | appoint, cité dans le texte : les hémophiles et les fractions plasmatiques, les seringues rares donc réutilisées (p. 2-3), la pathocénose et ses ruptures (p. 3) |
| erratas du Ronéosaure : cours 2025-26 (`Erratas SSH.docx`) et annales 2024-25 | — | aucune entrée sur la FC n°11 |

Vérifications hors du cours, citées dans la carte qui s'en sert :
- la chronologie française et américaine : L. Sebillotte, « Sida - Repères
  chronologiques en contexte français », Centre national de la danse, 2025
  (MMWR du 5 juin 1981, presse française de janvier 1982, sigle AIDS du
  27 juillet 1982, arrêté du 23 juillet 1985 sur les dons, Rock Hudson, grande
  cause nationale pour 1987, loi du 27 janvier 1987 sur la publicité du
  préservatif, AMM de l'AZT le 27 février 1987, Le Pen et les « sidaïques » le
  6 mai 1987, décret Barzach du 13 mai 1987) ; HIV.gov, « Timeline of the HIV
  and AIDS epidemic » (conférence d'Atlanta, ACT UP, nom HIV, premier discours
  de Reagan) ;
- NEJM du 10 décembre 1981 (Gottlieb, quatre patients) ; New York Times du
  3 juillet 1981 ; Edman et al., Nature 1988 (Pneumocystis, un champignon) ;
  Nature et Science, mai 1986 (le nom HIV) ; Faria et al., Science 2014
  (Kinshasa vers 1920) ; Worobey et al., Nature 2016 (le « patient zéro ») ;
  l'accord franco-américain de mars 1987 sur la découverte du virus ;
- Grmek : P.-O. Méthot, « Le concept de pathocénose chez M. D. Grmek. Une
  réflexion évolutionniste sur l'écologie des maladies ? », dans J. Coste,
  B. Fantini et L. L. Lambrichs (dir.), *Le concept de pathocénose de M. D.
  Grmek*, Droz, 2016, p. 93-117 (pathocénose, 1969, p. 95 ; les quatre
  ruptures, p. 96 ; les cinq situations d'une maladie nouvelle, conférence
  d'Annecy de 1987, p. 109-110 ; la tuberculose qui « faisait écran », p. 114) ;
- Hacking, The Social Construction of What ?, Harvard, 1999 ; Sontag, Illness
  as Metaphor (1978), AIDS and Its Metaphors (1989) ; les principes de Denver
  (1983) et le GIPA (sommet de Paris, 1994), ONUSIDA ; l'APF (1933) ; la
  Ligue préventive contre la tuberculose du Dr Armaingaud (Bordeaux, présentée
  en novembre 1892 selon Gallica, datée de 1891 par d'autres sources) ; la
  Ligue contre le cancer (14 mars 1918) ;
- l'étymologie : Wiktionnaire (qui cite le TLFi), proposée dans
  `scratchpad/etym/ssh_sida.json`.

## Ce que le cours a dicté

- **Ni gris ni rouge** dans la FC n°11 : tout le texte se carte. Le gras du
  ronéo a guidé le choix des trous.
- **Aucune figure** : les dix schémas sont redessinés dans `schemas.py`,
  d'après le texte, avec la page sur chaque dessin.
- **Ce qui appartient à d'autres chapitres n'est pas carté** (plan C16, §3) :
  la chaîne causale VIH - immunodépression - HHV-8 - Kaposi reste à
  `ssh_epistemologie` (`sida-qr-kaposi` y renvoie) ; le paternalisme médical
  et la démocratie sanitaire dans la loi de 2002 restent à
  `ssh_droits_malades` — ici, le paternalisme des ligues philanthropiques
  (`sida-fa-ligues`, `sida-qc-ligues`) et « l'impulsion décisive » du
  militantisme (`sida-qr-democratie`), sans terme de lexique. Les porteurs
  sains (la notion de 1985 et la panique) sont ici ; l'échec du monocausal,
  à l'épistémologie.

## Les erreurs du Ronéosaure 2025-26

Chacune est dite par **ATTENTION**, sans genre, dans la carte qui porte la
notion. Quand le cours 2024-25 dit la même chose, c'est « le cours lui-même » :
la carte répond comme le professeur, et l'ATTENTION dit « À l'examen : », puis
« La référence : ».

| Page | Ce que dit le Ronéosaure | Ce qui est juste | Cours lui-même ? | Carte |
|---|---|---|---|---|
| 2 | le NEJM de décembre 1981 publie « cinq cas graves de pneumonie » à Los Angeles | les cinq cas sont publiés par le CDC (MMWR, 5 juin 1981) — c'est « la newsletter » ; le NEJM du 10 décembre 1981 publie d'autres séries (Gottlieb : quatre hommes) | oui (2024-25, p. 3) | `sida-fa-premiers-cas`, `sida-qc-premiers-cas` |
| 3 | le New York Times en « juin 1981 » | le 3 juillet 1981, « Rare Cancer Seen in 41 Homosexuals » ; le cours 2024-25 disait juillet | non | `sida-qr-kaposi`, `sida-qc-premiers-cas`, `cau-an-2526s1-qroc3` (explication) |
| 3 | la pneumonie due à « un protozoaire » | le classement de l'époque ; Pneumocystis est un champignon (Edman et al., Nature, 1988) | oui (2024-25, p. 3) | `sida-qc-premiers-cas` C |
| 4 | ACT UP pousse à la conférence d'Atlanta de 1985 | ACT UP est fondé à New York le 12 mars 1987 ; la conférence d'avril 1985 est organisée par le département américain de la Santé et l'OMS | oui (2024-25, p. 5) | `sida-qr-atlanta`, `sida-qc-militantisme` C, `sida-an-2526s1-qroc2` (explication) |
| 5 | Rock Hudson « vit ses derniers jours en France » | sa maladie est annoncée à Paris le 25 juillet 1985 ; il meurt à Beverly Hills le 2 octobre 1985 | non | `sida-qr-rock-hudson` |
| 5 | en 1987, « le sigle HIV est adopté […], nom scientifique de la maladie » | le nom HIV est publié en mai 1986, et c'est celui du virus ; la maladie est le sida | oui (2024-25, p. 6) | `sida-qr-controverse`, `sida-qc-1987` |
| 8-9 | les seringues « à usage unique » jouent un rôle, « car pas de lavage » | phrase confuse : rares (vente réglementée), elles sont réutilisées sans stérilisation (2024-25, FC n°14, p. 3) | — | `sida-rv-seringues` |

Sans ATTENTION, parce qu'aucune réponse n'en dépend (dit dans l'explication) :
« The construction of what ? » (p. 2) pour *The Social Construction of What ?* ;
« La Maladie et ses métaphores » (p. 2) pour *La Maladie comme métaphore* ;
« Gmek » (p. 9) pour Grmek ; « popérisation » (p. 8) pour paupérisation.

Vérifié et juste : « janvier 1982 » pour la France (Le Matin de Paris,
2 janvier 1982) ; l'APF « dans les années 30 » (1933) ; les antirétroviraux
essayés en 1985, sur le marché en 1987 (l'AZT, autorisé en France le
27 février 1987).

Défendable, et précisé dans l'explication sans ATTENTION (aucune réponse
n'en dépend) : Reagan qui ne parle du sida « qu'en 1987 » — son premier
discours sur le sida date du 31 mai 1987, mais il avait répondu à une
question de presse le 17 septembre 1985 (`sida-qc-1987` C, `sida-fa-1987`) ;
la ligue contre la tuberculose « en 1892 » — le Dr Armaingaud la présente à
Bordeaux et à Paris en novembre 1892 (Gallica), d'autres sources disent 1891
(`sida-fa-ligues`, qui garde la date du cours). Les chiffres « 40 cas en 1981, 4 000
en 1983 » sont des ordres de grandeur de la presse : la carte le dit
(`sida-fa-noms-chiffres`), sans ATTENTION.

## Ce que les annales ont dicté

Aucune question d'annales sur ce cours dans le Ronéosaure 2024-25 (polycopiés
SSH 1 à 8, 10, 13 : aucun sur le sida), ni dans la FC 2025-26. Le sujet de SSH
2025/2026 en pose une, la QROC 2 : l'évolution des mouvements sociaux de santé
que montre la mobilisation autour du sida, et la démocratie sanitaire (section
suivante). `annales.py` est créé le 18/10/2026. Sa QROC 3, le lien fait entre
le sida et le cancer, puis la non-transitivité causale, est rangée dans
`ssh_epistemologie` ; sa première moitié cite ce cours (p. 3 et 8).

## Le sujet 2025/2026 (18/10/2026)

Les sujets de SSH de l'examen du 09/01/2026 (1 QR, 10 QROC,
`src-sujets-ssh-2526`, sans corrigé), déposés le 18/10/2026, apportent 1
recto-verso à ce chapitre (QROC 2). Aucun n'était déjà en cartes. Au verso, la
bonne réponse, tirée du ronéo 2026-27 quand il couvre la notion, sinon du
cours 2025-26, celui de l'année de l'examen ; ce qui dépasse le cours est dit
« hors cours », avec sa source (`officielle=False`). Rédigés et
contre-vérifiés le 18/10/2026 : un rédacteur, un sceptique, un critique de
complétude.

| Question | Ce que le verso répond | Voisine de |
|---|---|---|
| 2025/2026 S1 QROC 2 (`sida-an-2526s1-qroc2`) | des ligues POUR les malades aux associations DE malades ; le militantisme du sida (Denver, conférences, publicisation) ; la compétence profane et la démocratie sanitaire, que consacre la loi du 4 mars 2002 | — |

Ce qui est signalé :

- La première annale du chapitre : la QROC 2. `annales.py` est créé, et le sujet
  est aussi la source d'annales du chapitre (`SRC["annales"]`).
- ATTENTION nu, le cours lui-même : ACT UP qui pousse à la conférence d'Atlanta
  de 1985 (p. 4) ; ACT UP naît le 12 mars 1987. Carte ajoutée à sa ligne du
  tableau des erreurs, comme `cau-an-2526s1-qroc3` (rangée en épistémologie) à
  celle du New York Times de « juin 1981 ».

## Les clés qui ne sont pas reprises telles quelles

Aucune : la seule annale vient d'un sujet sans corrigé, et son verso est tiré
du cours. Les écarts au ronéo sont
dans le tableau des erreurs ci-dessus.

## Les schémas cliquables

| Fichier | Ce qu'on clique | Cartes |
|---|---|---|
| `frise-sida-nue.svg` (`sida-zo-frise`) | six bandes égales, bornées par les dates du cours (années 1920, printemps 1981, printemps 1983, 1984, 1987, 1996) : le temps où le VIH circule sans être vu, le mystère médical, la maladie virale, la publicisation et la politisation, la marche vers la chronicité, les trithérapies | 6 |
| `carte-etats-unis-nue.svg` (`sida-zo-carte`) | quatre points sur les États-Unis : Los Angeles (les cinq pneumonies), New York (le New York Times), Atlanta (le CDC, la conférence de 1985), Denver (les principes de 1983) | 4 |

La frise n'est pas proportionnelle : six bandes égales, pour qu'une période
d'un an (la maladie virale) se clique aussi bien qu'une de neuf ; les dates du
cours sont écrites sous l'axe, dans les deux versions — c'est leur
correspondance avec les temps du cours qu'on apprend. La carte est un contour
simplifié des États-Unis contigus (projection équirectangulaire, les Grands Lacs
suivis par la frontière). Les versions légendées (`frise-sida.svg`,
`carte-etats-unis.svg`), tirées des mêmes constantes, sont en correction.

Huit schémas de correction, redessinés : `hacking-conditions.svg`,
`registres-maladie.svg`, `visibles-invisibles.svg`, `aigu-chronique.svg`,
`ligues-associations.svg`, `grmek-cinq-sens.svg`, `pathocenose.svg`,
`facteurs-emergence.svg`. Les quatorze QCM sont illustrés (100 %), et 60 notes
sur 75.

## Le lexique

Neuf termes, pages mesurées dans la FC n°11 (page de plan exclue) :
Construction sociale (p. 2, 8), Contingence (p. 2, 8 : « contingente »),
Stigmatisation (p. 2, 6), Séropositivité (p. 5, 6 : « séropositives »,
« séropositif »), Porteur sain (p. 5), Chronicisation (p. 5, 7, 8),
Trithérapie (p. 6), Patient expert (p. 7), Pathocénose (p. 9).

Les pages ont été mesurées avec le motif de `chercher_pages.py` (mot entier,
pluriel permis, accents ignorés) appliqué au texte de pymupdf : `uv` n'était
pas sur le chemin de l'agent.

Racines : `serum (latin)`, `tri-`, `-thérapie` (FC de sémantique 1, p. 5) et
`experiri (latin)` reprennent les clés de la table ; onze racines nouvelles
(`construere (latin)`, `socius (latin)`, `contingere (latin)`, `stigma
(grec)`, `positivus (latin)`, `portare (latin)`, `sanus (latin)`,
`chron(o)-`, `pati (latin)`, `path(o)-` — forme préfixe de `-pathie`, enseignée
par la FC de sémantique 1, p. 5 —, `koinos (grec)`) et les neuf termes sont
proposés dans `scratchpad/etym/ssh_sida.json`, à fusionner dans
`etymologies.json`. Les textes de `LEXIQUE` portent déjà l'étymologie, à
l'identique de ce que `appliquer_etymologies.py` écrira.

Laissés à d'autres chapitres : paternalisme et démocratie sanitaire
(`ssh_droits_malades`) ; asymptomatique (`ssh_epistemologie`).

## Questions pour Vincent

1. **Examen** : aucun chapitre de SSH ne déclare d'`EXAMENS`. Proposition du
   plan, appliquée : rien ici ; un seul `exam-ssh-jan-2027` (6 janvier 2027)
   pour toute l'UE, à décider une fois.
2. **La fiche dans l'application** : `outils/copier_les_cours.py` doit
   connaître le dossier « ROneosaure 2025-2026 sans annles/S1 25-26/examen
   janvier » et le préfixe `SSH/` des `chemin_relatif`, sans quoi la FC n°11
   n'est pas lisible dans le lecteur (même question que pour BMCT et
   l'immunologie).
3. **Les erreurs du Ronéosaure 2025-26** (tableau ci-dessus) ne vont pas dans
   `ERRATA_RONEOS_2026-27.md`, réservé aux ronéos de l'année : à confirmer.
4. **Le ronéo 2026-27** de ce cours (fin novembre 2026) remplacera la fiche :
   les sept erreurs relevées seront à revérifier sur lui, et les cartes à
   relire page par page.

## À relire

Aucune carte `a-relire` : chaque note cite sa page dans la FC n°11 2025-26, et
ce qu'elle dit hors du cours, sa référence.

## L'échelle : Simple → Moyen → Annale (C20, 19/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 5 janvier (BMCP) ou du 6 janvier (SSH, papier). Sous les annales, 13 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 1 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`) ; les QROC reçoivent le schéma nu.

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `militantisme-sante` | 13 | 1 | 1 |

**Le schéma** `ech-mouvements-sante`, « Les mouvements de santé · des ligues au sida », donne 15 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_MOUVEMENTS_SANTE`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Constantes ajoutées** à `annales.py` (`_SCHEMA_LETTRES`, `_SCHEMA_NU`) : les annales de SSH sont toutes des QROC, rangées dans `ANNALES_QROC` ; chacune reçoit le schéma nu, et les marches la préparent sans lettre.

**Sans marche** :
- sida-an-2526s1-qroc2, la loi du 4 mars 2002 : elle n'est que dans la FC n°14 2025-26 (droits des malades), qui n'est pas une source de ce chapitre ; pas de marche, la démocratie sanitaire est préparée par sa définition (FC n°11, p. 8).

## Régénérer

```powershell
cd contenu\chapitres\ssh_sida
..\..\..\app\.venv\Scripts\python.exe generer.py
```
