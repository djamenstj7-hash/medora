# Métabolisme des protéines — paquet BMCP

82 notes, 163 cartes. Chapitre `chap-ue-bmcp-fc7` de l'UE BMCP (ordre 8). **Cours du
Pr Huin du 30/09/2026, de 10 h à 11 h, dans le ronéo Ronéo & Juliette 2026-27
« Métabolisme des protéines » (14 pages)** : réaligné sur lui le 11/10/2026. Le
chapitre était carté depuis le 02/10 (C16) sur la FC n°8 du Ronéosaure 2025-26 (Pr
Huin, 03/10/2025), qui n'est plus qu'un appoint. Une annale propre, la Q. 20 du sujet
de 2024/2025, sans corrigé ; les trois questions du polycopié BMCP 7 sont dans
`bmcp_metabolisme` (voir « Les annales »).
Examen : mardi 5 janvier 2027.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 32 | 32 |
| QRU | 2 | 2 |
| Texte à trous | 13 | 90 |
| QROC | 12 | 12 |
| Recto-verso | 8 | 8 |
| Schéma cliquable | 1 | 5 |
| Planche à légender | 1 | 1 |
| Lexique | 13 | 13 |

**32 QCM sur 34 illustrés (94 %)**, 65 notes sur 82. Sans figure : `prt-qc-sante` et
`prt-qc-sources-proteines` (apports en protéines animales et santé), que le ronéo
n'illustre pas. **2 cartes absentes du cours 2026-27** (tag `absent-2026`), **15
cartes portent un piège du ronéo** (thème « Pièges des ronéos »).

Huit thèmes, dans l'ordre du cours, tous déjà dans `THEME_LABELS`
(`app/src/med_engine/application/scopes.py`) ; le réalignement n'en ajoute aucun :

| Clé | Libellé | Notes |
|---|---|---|
| `proteines-structure` | Structure des protéines | 4 |
| `acides-amines` | Acides aminés | 7 |
| `digestion-proteines` | Digestion des protéines | 8 |
| `vegetarisme` | Régimes végétariens et apports en protéines | 12 |
| `carence-cobalamine` | Carence en cobalamine (vitamine B douze) | 14 |
| `azote` | Métabolisme de l'azote | 7 |
| `renouvellement-proteique` | Renouvellement des protéines et protéines plasmatiques | 10 |
| `denutrition-proteique` | Dénutrition protéique | 7 |

(Le lexique, treize termes, porte le tag `lexique` et non un thème.)

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-bmcp-prt-2627` — « Métabolisme des protéines » (14 p.), `BMCP/MÉTABOLISME DES PROTÉINES.pdf` | **2026-27** | **la base** : `SRC["fiche"]`, ce que le lecteur ouvre, et `SRC["medias"]` ; 78 notes y citent leur page (66 notes de cours et 12 termes du lexique) |
| `src-fc-bmcp-prt-2526` — Ronéosaure, « FC n°8 - Métabolisme des protéines » (13 p.) | 2025-26 | **appoint** (`SRC["cours"]`, sans `chapitre=`) : ce que le ronéo 2026-27 ne dit plus, trois figures sans équivalent, et la source des **2 cartes absentes** |
| `src-sujets-bmcp-2425` — « Sujets de BMCP 2024/2025, session 1 » (30 p.) | 2024-25 | le sujet de l'examen du 09/01/2025, **sans corrigé** (dépôt `Annales_15102026/`, 15/10/2026) : la Q. 20 ; `SRC["annales"]` et `SRC["sessions"]["2024/2025 S1"]` ; déclaré à l'identique dans tous les chapitres de BMCP qui en cartent une question |

Les textes citent « p. 9 » pour le ronéo 2026-27 et « FC 2025-26, p. 8 » pour
l'appoint. Une carte que le cours de l'année ne porte plus cite la FC 2025-26 à sa
page (`fiche=FC2526`, `page=`) et garde le badge « Cours 2025-26 ». La fiche de
l'année se copie dans le dossier des PDF de l'application par
`outils/copier_les_cours.py`, lancé avec le dossier des ronéos 2026-27
(`Ajouts/[NUMERIQUE] Ronéo & Juliette 26-27 11 10 2026/S1/CM`), hors du bac à sable.

Lus en appoint, sans être déclarés : les ronéos 2023-24 (Charonéo, n°7) et 2024-25
(Ronéosaure, FC n°7) du même professeur, pour classer les erreurs ; le polycopié
d'annales BMCP 7 ; l'errata des cours 2025-26. Le dossier BMCP du dépôt du 11/10 n'a
pas de tableau des erreurs de la promo. Les en-têtes des ronéos et des polycopiés
nomment leurs rédacteurs : aucun nom n'est repris.

## Ce qui correspond à quoi

Le ronéo 2026-27 suit exactement le plan de 2025-26 (I à VI), une page plus loin à
partir de la digestion :

| Partie | FC 2025-26 | Ronéo 2026-27 |
|---|---|---|
| I. Rappels : protides, acides aminés, liaison peptidique, diversité, schéma général | p. 2-4 | p. 2-4 |
| II.A Digestion | p. 4-5 | p. 4-5 |
| II.B Besoins, rations, AA essentiels, régimes, santé | p. 5-7 | p. 6-8 |
| II.C Vitamine B12 : origines, carence, sclérose combinée, autres terrains | p. 7-8 | p. 8-9 |
| III. Catabolisme, élimination de l'azote, cycle de l'urée | p. 9-10 | p. 10-11 |
| IV. Renouvellement, protéines plasmatiques, dénutrition | p. 10-12 | p. 11-13 |
| V-VI. Synthèse de novo, fonctions spécifiques | p. 12-13 | p. 14 |

## Le réalignement du 11/10/2026

Les 71 notes de la version 2025-26 ont été relues une à une contre le ronéo 2026-27.

**Confirmées (68), qui citent désormais leur page de l'année** (et perdent le badge
« Cours 2025-26 ») : les 13 textes à trous, les 28 QCM, 16 des 18 QROC et
recto-verso, le schéma cliquable (p. 5), la planche (p. 4), et 9 des 10 termes du
lexique. Le dixième, **Transamination**, garde sa page de 2025-26 (p. 12) : le ronéo
2026-27 ne l'écrit plus que dans son plan (p. 1) ; la notion est à la p. 14, sans le
mot. Dans les cartes confirmées, ce que seul le cours 2025-26 porte le dit dans sa
justification ou son explication (« FC 2025-26, p. 10 »).

**Ce que le ronéo 2026-27 dit autrement, et ce qui a été réécrit** (identifiants et
types inchangés ; un texte à trous garde son nombre de trous) :

- **Le trypsinogène est activé par l'entérokinase**, dans le duodénum (p. 5), et non
  plus « auto-activé » : `prt-fa-digestion` réécrit ; `prt-qc-pancreas` réécrit (A :
  « la plupart des enzymes de la digestion » ; B, « le trypsinogène s'active lui-même »,
  devient la proposition fausse ; **clé ABC → AC**).
- **L'amorce gastrique** : pH 1, l'acide chlorhydrique active le pepsinogène,
  Helicobacter pylori survit (p. 5) ; la pepsine n'« active d'autres pré-enzymes » plus.
- **La fin de la digestion** en quatre étapes (p. 5) : peptidases membranaires, au
  moins sept transporteurs actifs, peptidases intracellulaires, passage passif dans la
  veine porte.
- **Les besoins** : « 1g à 1,5g de protéine/jour/kg » (p. 6) ; le « seul plat de viande
  ou de poisson par jour » de 2025-26 disparaît : `prt-qc-besoins` B, `prt-qr-besoins`.
- **Les œufs** apportent « très peu » de B12 (p. 8), non plus « pas » ; la rectocolite
  hémorragique n'est plus citée ; l'anémie mégaloblastique a « de très gros
  érythrocytes » (p. 8) ; « l'albumine (aussi appelée sérumalbumine) » a la demi-vie
  longue (p. 12) : les ATTENTION de 2025-26 sur ces points sont retirés, la carte dit
  l'écart en une phrase.
- **Le délai de la carence en B12** : « environ 2 à 3 ans » (p. 8), « environ 3 ans »
  pour un régime végan strict (p. 7), au lieu de « jusqu'à 2 ans » : `prt-qr-delai-b12`
  répond 2 à 3 ans ; son ATTENTION nu (le cours lui-même) tombe, le nouveau chiffre
  étant celui de la référence (StatPearls : environ 3 ans de régime végan strict).
- **La sclérose combinée** associe deux syndromes (p. 9) ; elle n'est plus dite
  « cause traitable de démence » : `prt-fa-sclerose` (c4 « pyramidal », c6
  « protoxyde d'azote » au lieu de « traitables »), `prt-qc-sclerose` (B et E
  réécrits).
- **Le protoxyde d'azote** est dit « consommé de façon récréative », aux mêmes
  atteintes qu'une carence (p. 9) ; l'oxydation de la B12 vient de 2025-26 :
  `prt-qr-n2o` (question réécrite).
- **Le nourrisson** a très peu de réserves ; le lait de soja « n'est pas du lait »
  (p. 9) ; l'hypotonie et l'anémie de 2025-26 ne sont plus citées :
  `prt-fa-grossesse-b12` (c5 « réserves », c6 « soja », c7 « staturo-pondérale »).
- **Le catabolisme** : 80 g/j oxydés, rendement « très mauvais », perte métabolique de
  près de 30 % (p. 10) ; les 15 % de l'apport énergétique disparaissent :
  `prt-qc-catabolisme` A réécrit, `prt-qr-part-energie` absente.
- **L'ammoniac**, « particulièrement toxique pour le système nerveux central »
  (p. 10) ; le sang « plus basique » et le coma de 2025-26 ne sont plus dits :
  `prt-fa-uree` (c2 « nerveux », c3 « exclusivement », c4 « foie », c8 « urines »),
  `prt-qc-azote` (A et B réécrits).
- **Le renouvellement** : les contributions des organes (muscle 20 %, peau et intestin
  15 %, foie 10 %, p. 11) ; le coût de 1 kcal/g, 300 kcal/j, disparaît, la synthèse
  est dite « extrêmement énergivore » (p. 12) : `prt-fa-renouvellement` (c6
  « muscle », c7 « foie »), `prt-qc-renouvellement` (B, C, D réécrits).
- **La planche du schéma général** est refaite sur la figure du ronéo 2026-27 (p. 4,
  900 × 584, deux fois plus nette), mêmes onze légendes ; l'aperçu de contrôle a été
  relu, rien ne reste visible.

**Notes nouvelles (10)**, sur ce que le cours 2026-27 apporte :

| Note | Ce qu'elle carte |
|---|---|
| `prt-qc-amorce-gastrique` | pH 1, HCl et pepsinogène, Helicobacter pylori, la pepsine fait des peptides, le mucus (p. 5) |
| `prt-qc-absorption-enterocyte` | les quatre étapes de l'entérocyte, transport passif vers la veine porte (p. 5) |
| `prt-qr-enterokinase` | l'entérokinase, dans le duodénum (p. 5) |
| `prt-qc-sources-proteines` | consommation modérée, viandes blanches, impact écologique (p. 7-8) |
| `prt-qc-nourrisson-b12` | réserves du nourrisson, mère carencée, lait de soja, grossesse (p. 9) |
| `prt-rv-sclerose-syndromes` | les deux syndromes de la sclérose combinée (p. 9) |
| `prt-qc-demi-vies` | préalbumine, transferrine, albumine = sérumalbumine, suivi et gravité, facteurs de coagulation (p. 12-13) |
| `lex-enterokinase`, `lex-proprioception`, `lex-cytolyse` | trois termes du lexique (voir plus bas) |

## Absent du cours 2026-27

Deux cartes **entières**, dans des sections que le ronéo du 30/09/2026 couvre en
entier. Elles restent, citent la FC n°8 2025-26 à sa page (`fiche=FC2526`), prennent
le tag `absent-2026` et la phrase « Absent du cours 2026-27 » en tête de
l'explication (`ABSENTS_2026`, `ORIGINE_ABSENTS`) :

| Carte | Ce que le cours 2026-27 ne dit plus |
|---|---|
| `prt-qr-part-energie` | les protéines, « 15 % de l'apport alimentaire énergétique quotidien » (FC 2025-26, p. 9) ; le ronéo 2026-27 parle d'un rendement « très mauvais », perte de près de 30 % (p. 10) |
| `prt-rv-demence-b12` | la carence en B12, « une des rares causes traitables de démence », d'où le dosage devant des troubles cognitifs (FC 2025-26, p. 8) ; le ronéo 2026-27 garde la démence d'une carence prolongée (p. 9), pas le reste |

## En attente des ronéos suivantes

**Rien.** Le ronéo du 30/09/2026 n'est pas numéroté « 1 » et couvre tout le plan du
cours (I à VI) : aucune carte n'attend une suite.

## Les erreurs du ronéo 2026-27

Toutes trouvées en relisant (pas de tableau des erreurs BMCP au 11/10), à verser dans
`contenu/ERRATA_RONEOS_2026-27.md`. Aucun ronéo n'est corrigé ; chaque erreur est portée
par une carte, avec son genre. À l'examen, on répond d'abord comme le professeur.

**Prises de notes fausses** (`ATTENTION (prise de notes)`) :

| Page | Le ronéo dit | Ce qui est juste | Carte |
|---|---|---|---|
| 10 | « ALAT (Alanine-aminotransférase) (aussi appelée TGO) ; ASAT (Aspartate-aminotransférase) (aussi appelée TGP) », comme le ronéo 2025-26 | ALAT = TGP (glutamate-pyruvate transaminase), ASAT = TGO (glutamate-oxaloacétate transaminase) ; le ronéo 2024-25 cite les deux noms sans les apparier | `prt-qc-cycle-uree` (D), `prt-rv-alat-asat` |
| 9 | les paresthésies rangées, deux fois, dans le « Syndrome pyramidal (motricité) » | sensitives, elles relèvent du cordon postérieur : ronéo 2023-24 (« syndrome cordonal postérieur = paresthésie des membres inférieurs ») ; FC 2025-26, p. 8 ; StatPearls, Subacute Combined Degeneration | `prt-fa-sclerose`, `prt-qc-sclerose` (C), `prt-rv-sclerose-syndromes` |
| 13 | « infections nosocomiales ou liées à l'allaitement prolongé » | l'alitement prolongé (FC 2025-26, p. 11 ; l'errata des cours 2025-26 avait corrigé le même mot) | `prt-qc-denutrition` |

**C'est le cours lui-même** (`ATTENTION (cours)` : « À l'examen : … », puis « La
référence : … ») :

| Page | Le cours dit | La référence | Carte |
|---|---|---|---|
| 11 (et la figure) | « On perd 3 ATP mais on en reproduit 2 » ; la figure : 2 ATP puis 1 ATP consommés, « +2 ATP » au fumarate ; le même compte en 2025-26 | quatre liaisons phosphate riches en énergie consommées (l'argininosuccinate synthétase hydrolyse son ATP en AMP), environ 2,5 ATP rendus par le NADH du fumarate redevenu oxaloacétate (Lehninger, chap. 18). À l'examen : 3 et 2 | `prt-fa-uree`, `prt-qc-cycle-uree` (B) |
| 13 | « Autre moyen diagnostic : biologie, dosage de l'albumine/pré-albumine », pour le suivi et la gravité ; mot pour mot en 2025-26 (p. 12), et en 2024-25 « le diagnostic de certitude » sur ces deux biomarqueurs (p. 13) | pour la HAS (2019), « l'albuminémie n'est pas un critère diagnostique ; c'est un critère de sévérité » ; le diagnostic ne repose que sur un critère phénotypique et un critère étiologique. À l'examen : un critère clinique et un critère étiologique posent le diagnostic ; la biologie suit et grade | `prt-rv-diagnostic-denutrition` |

**Points douteux** (`ATTENTION (douteux)`), dits dans la carte sans changer sa clé :

| Page | Le point | Carte |
|---|---|---|
| 2, 4 | « 18 kg » de protéines pour un homme de 70 kg, alors que la figure de la p. 4 porte « PROTÉINES (10 kg) » ; les ronéos 2023-24 à 2025-26 disent aussi 18 kg (2023-24 : « 18 kg de protides », puis « un stock de 10 kg de protéines ») ; la référence : environ 10,6 kg (Wang et al., Am J Clin Nutr 2003) | `prt-fa-flux`, `prt-qc-schema-general` |
| 3 | la titine « la plus abondante dans le muscle », comme en 2025-26 : troisième protéine du muscle, après la myosine et l'actine (Gregorio et al., Curr Opin Cell Biol 1999) | `prt-qc-diversite` (A) |
| 10 | le cycle de l'urée « a besoin de 2 enzymes », l'ALAT et l'ASAT (comme en 2023-24 et 2025-26), puis fonctionne « avec des enzymes spécifiques » (p. 11) : les transaminases apportent l'azote au cycle, qui a ses propres enzymes | `prt-qc-cycle-uree` |
| 12 | les gamma-globulines parmi les protéines à demi-vie courte, moins de 3 jours : surtout des IgG, demi-vie d'environ 21 jours (Morell et al., J Clin Invest 1970) | `prt-qc-demi-vies` |
| 6 | « Il faut approximativement 70 à 100g de protéines par jour, soit 1g à 1,5g de protéine/jour/kg » : c'est la consommation habituelle (67 à 114 g/j chez l'homme, EFSA) plus que le besoin, l'apport de référence étant de 0,83 g/kg/j (EFSA, 2012) ; le ronéo 2023-24 parlait de ce que l'on « reçoit ». À l'examen, les chiffres du cours | `prt-qc-besoins`, `prt-qr-besoins` |
| 14 | « convertir certains acides aminés entre eux (ex : histidine → arginine) » : ni une transamination ni une conversion directe ; l'histidine, essentielle, est dégradée en glutamate, dont l'organisme peut faire de l'ornithine, puis de la citrulline et de l'arginine, en plusieurs étapes (Lehninger, chap. 18 et 22) ; les exemples des années précédentes étaient de vraies transaminations (glutamate → acide aspartique, FC 2025-26 p. 12 ; alanine → glutamate, 2024-25). Rien ne dit si l'exemple vient du professeur | `prt-qc-transamination` (C) |

Précisions sans ATTENTION, parce que le ronéo simplifie sans se tromper : l'urée faite
de « deux molécules d'ammoniac » (p. 10 ; l'un des deux azotes vient de l'aspartate) ;
les transporteurs « couplés au sodium » (p. 5 ; celui des di- et tripeptides, PepT1, est
couplé aux protons, Bröer, Physiol Rev 2008) ; les AA « non essentiels en cétoacides »
(p. 14 ; la transamination est réversible) ; les AA hydrophiles « grâce au groupement
acide » (p. 3 ; les deux groupements sont ionisés).

## La relecture critique du 11/10/2026

Une seconde lecture a repris chaque carte nouvelle ou changée contre sa page du ronéo
2026-27, et chaque référence. Ce qu'elle a changé :

- **« Histidine → arginine »** passe de « prise de notes » à **point douteux** : la
  conversion n'est pas impossible (histidine → glutamate → ornithine → citrulline →
  arginine, en plusieurs étapes), seulement mal choisie comme exemple
  (`prt-qc-transamination`, C).
- **La biologie, « autre moyen diagnostic »** de la dénutrition (p. 13) devient un
  `ATTENTION (cours)` sur `prt-rv-diagnostic-denutrition` : le cours le dit depuis trois
  ans, la HAS (2019) n'en fait qu'un critère de sévérité. L'explication disait à tort
  que la biologie « ne pose pas le diagnostic dans ce cours ».
- **Les références** : la titine est citée d'après Gregorio et al. (1999), dont le
  résumé dit l'abondance, et non plus d'après Labeit et Kolmerer (1995). Le suivi de la
  renutrition par la préalbumine (`prt-qc-proteines-plasmatiques`) cite le ronéo 2024-25
  (p. 12), et non plus une HAS (2019) qui n'en parle pas.
- **Les mots de l'année** : `prt-qc-aa-essentiels` B et C disent « limitantes en
  lysine » au lieu de « très pauvres » et « pauvres ». `prt-qc-schema-general` B
  rapporte « flux le plus important » au ronéo 2025-26 (p. 10).

Le reste a tenu : les pages citées, celles de la FC 2025-26 et des ronéos 2023-24 et
2024-25, les items d'annales cités, les figures, la planche, les deux cartes absentes,
les étymologies.

## Les erreurs du Ronéosaure 2025-26

Le Ronéosaure n'est pas le ronéo de l'année ; ses erreurs étaient dites par un
ATTENTION nu. **Celles que le ronéo 2026-27 corrige** ne portent plus d'ATTENTION, la
carte dit l'écart en une phrase : le trypsinogène « s'auto-active » ; les œufs « sans
vit B12 » ; la rectocolite hémorragique parmi les malabsorptions de la B12 ; l'anémie
« contenant peu d'hémoglobine », la B12 « impliquée dans la synthèse d'hémoglobine » ;
« albumine et pré-albumine = demi-vie courte » ; la sérumalbumine « utile pour voir
l'efficacité du traitement » ; la carence installée « jusqu'à 2 ans ». **Celles que le
ronéo 2026-27 redit** ont pris le genre de l'année (18 kg, titine, TGO et TGP, « 2
enzymes », 3 et 2 ATP).

## Les annales

**Une annale, depuis le 15/10/2026** (`annales.py`, nouveau) : la Q. 20 du sujet de
l'examen du 09/01/2025 (`prt-an-2425s1-q20`), publié sans corrigé, cartée ici, au
chapitre dont le cours traite la notion. C'est la 2023/2024 S1 Q.16 remaniée : ses C
et D sont les A et B, mot pour mot ; son E (« trop pauvre en protéines animales… »,
faux) devient « riche en protéines végétales… », faux aussi ; C (combiner les sources
végétales, p. 6) et D (les acides aminés essentiels, p. 6, 14) sont neuves. Clé
déduite ABCD.

Le polycopié BMCP 7 « Métabolisme des protéines » (Ronéosaure 2024-25) compte trois
questions, toutes cartées dans `bmcp_metabolisme`, où elles restent — déplacer une
note changerait son chapitre chez les collègues. Relues contre le ronéo 2026-27, leurs
clés tiennent :

| Question | Clé | Carte | Le cours 2026-27 |
|---|---|---|---|
| 2023/2024 S1 Q.16 | ACD | `met-an-2324-q16` | B12 des végétariens (p. 8), synthèse des non essentiels (p. 14), viande rouge cancérogène probable (p. 7), protéines animales et maladies cardiovasculaires (p. 7), démence (p. 8) |
| 2022/2023 S1 Q.18 | ABD | `met-an-2223-q18` | p. 7-8 (cardiovasculaire, démence), p. 8 (B12, pas B6), p. 14 (synthèse), p. 6 (associations végétales) |
| 2019/2020 S1 Q.30 | D | `met-an-1920s1-q30` | le foie fait l'urée (p. 10) |

## Les clés qui ne sont pas reprises telles quelles

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2024/2025 S1 Q. 20 | aucune (sujet sans corrigé) | **ABCD**, déduite, `officielle=False` | A et B, p. 7 ; C, combiner céréales et légumineuses (p. 6) ; D, les essentiels sont « peu voire pas synthétisés » (p. 6, 14) ; E fausse, les régimes végétariens diminuent le risque de démence (p. 8) — seule la carence prolongée en B12 d'un végétalisme non supplémenté mène à des troubles cognitifs (p. 8-9) |

Aucune clé imprimée n'est contestée. Une clé de cours change :
`prt-qc-pancreas` passe de ABC à AC, la proposition B testant désormais l'activation
du trypsinogène (voir le réalignement).

## Le schéma cliquable, la planche et les figures

**Six figures du ronéo 2026-27**, extraites en PNG (900 px de large au plus, 256
couleurs), illustrent les corrections : p. 2 (deux), 4, 7, 11, 13. Elles remplacent
les sept PNG de la FC 2025-26 qui en étaient les mêmes diapositives, moins nettes
(retirés de `media/`). **Trois figures de 2025-26 restent**, sans équivalent en
2026-27, où leur contenu est en texte : les rations (p. 5), les origines de la carence
en B12 (p. 7-8), la transformation des aliments (p. 9).

| Fichier | Ce qu'on clique ou légende | Cartes |
|---|---|---|
| `digestion-proteines.svg` (correction : `digestion-proteines-legende.svg`) | l'estomac, le pancréas, l'intestin grêle, la veine porte, le foie | `prt-zo-digestion`, 5 zones |
| `prt-2627-schema-general-numerote.png` (correction : `prt-2627-schema-general.png`) | les 11 légendes de la figure p. 4 ; intrus : glycogène, triglycérides, lactate, glucose, corps cétoniques, acétyl-CoA | `prt-pl-schema-general` |

Les textes des schémas redessinés (`schemas.py`) citent le ronéo 2026-27 : le pancréas
nomme l'entérokinase, la carence en B12 dit 2 à 3 ans et le protoxyde d'azote
récréatif, la sclérose combinée ses deux syndromes. Le schéma des transformations
garde l'exemple de transamination de 2025-26 (glutamate → aspartate), juste.

## Le lexique

Treize termes, chacun avec son **origine grecque ou latine** ; pages mesurées dans le
texte du ronéo 2026-27 (en-têtes et plan exclus), puis de la FC 2025-26 :

| Terme | Pages 2026-27 | Pages 2025-26 | Racines |
|---|---|---|---|
| Peptide | 2, 5 | 2, 5 | pept- (grec) |
| Protéolyse | 11 | 4, 10 | prot(é)-, -lyse |
| Pepsine | 5 | 4 | -pepsie |
| Trypsine | 5 | 5 | tryps- (grec) |
| **Entérokinase** (nouveau) | 5 | — | entér-, kin(é)-, -ase |
| Végétalisme | 8 | 6, 7 | vegetare (latin) |
| Facteur intrinsèque | 8 | 7 | facere (latin), intrinsecus (latin) |
| Mégaloblastique | 8 | 8 | -mégalie, -blaste |
| Hyperhomocystéinémie | 9 | 8 | hyper-, homo-, cyst-, -émie |
| **Proprioception** (nouveau) | 9 | 8 | proprius (latin) *(nouvelle)*, recipere (latin) |
| **Cytolyse** (nouveau) | 10 | 9 | cyt(o)- / -cyte, -lyse |
| Transamination | — (plan seul) | 12 | trans- (latin), ammoni- |
| Dénutrition | 12, 13 | 11, 12 | dé- (latin), nutrire (latin) |

Les trois termes nouveaux et la racine `proprius (latin)` sont proposés à
`etymologies.json` (brouillon `scratchpad/etym/bmcp_proteines.json`, sur le TLFi par
l'API cnrtl.fr, le Wiktionnaire et le Gaffiot), que Claude fusionne ; leurs textes
sont déjà écrits dans la forme que `appliquer_etymologies.py` produirait (vérifié en
simulant le script avec la table complétée). Aucun des trois n'est accueilli par un
autre chapitre de BMCP. Pour l'entérokinase, le TLFi cite κίνησις ; la carte suit,
comme pour kinase, le verbe κινέω de la racine `kin(é)-`.

## À relire

Aucune carte `a-relire` : chaque carte cite sa page du ronéo 2026-27 ou, pour les
deux absentes et le terme Transamination, de la FC 2025-26 ; la clé de la Q. 20 de
2024/2025, déduite, tient chaque proposition à une page du ronéo de l'année ; les écarts à la référence
sont dits par un ATTENTION, source à l'appui.

## Questions pour Vincent

- (11/10) ALAT et TGO (p. 10) : je l'ai laissé en « prise de notes », parce que le texte 2026-27 reprend mot pour mot celui de 2025-26. Mais la ronéo 2024-25 écrit « ALAT et ASAT ou TGO et TGP », un ordre qui les apparie de travers. Si la diapositive les liste ainsi, faut-il en faire un « point douteux » ? La réponse ne change pas : ALAT = TGP.
- (11/10) « Histidine → arginine » (p. 14) : je l'ai reclassé en « point douteux ». La conversion n'est pas impossible : elle passe par le glutamate, puis l'ornithine et la citrulline. Le professeur a-t-il donné cet exemple ? Aucune proposition n'en dépend.
- (11/10) Albumine et préalbumine, « autre moyen diagnostic » (p. 13) : j'en ai fait un « le cours lui-même ». À l'examen, la carte fait poser le diagnostic sur un critère clinique et un critère étiologique, et réserve la biologie au suivi et à la gravité, comme la HAS. Est-ce bien ce que le Pr Huin attend ?
- (11/10) Besoins en protéines, « 70 à 100 g, 1 à 1,5 g/kg/j » : je l'ai laissé en point douteux. À l'examen, les chiffres du cours ; pour les EDN, 0,83 g/kg/j (EFSA). Cela vous convient-il ?
- (11/10) 18 kg ou 10 kg de protéines : la question reste ouverte. Quatre ronéos écrivent 18 kg, la figure dit 10 kg ; aucune proposition n'en dépend.
- (11/10) La mère carencée qui allaite (p. 9) : la ronéo conseille de « privilégier » les laits infantiles. L'usage serait plutôt de supplémenter la mère sans arrêter l'allaitement, mais aucune source lisible ne l'a confirmé. Je ne l'ai pas carté comme erreur ; faut-il en faire un point douteux ?

1. **ALAT et TGO** : classé « prise de notes » (le texte 2026-27 reprend mot pour mot
   celui de 2025-26). Le ronéo 2024-25 écrit « ALAT et ASAT ou TGO et TGP », dans
   l'ordre qui les apparie de travers : si la diapositive les liste ainsi, c'est un
   « point douteux » de la diapositive, la réponse ne changeant pas (ALAT = TGP).
2. **« Histidine → arginine »** (p. 14) : classé « point douteux ». Les exemples des
   deux années précédentes étaient de vraies transaminations, et la conversion ne se
   fait que par plusieurs étapes, par le glutamate et l'ornithine. Le professeur
   l'a-t-il donné ? Aucune proposition n'en dépend.
3. **70 à 100 g, 1 à 1,5 g/kg/j** : le cours appelle besoin ce qui est la
   consommation habituelle ; à l'examen, ses chiffres ; pour les EDN, 0,83 g/kg/j. À
   garder en point douteux ?
4. **18 kg ou 10 kg** : quatre ronéos écrivent 18 kg, la figure 10 kg ; toujours
   ouvert, aucune proposition n'en dépend.
5. **La mère carencée qui allaite** (p. 9) : le ronéo conseille de « privilégier » les
   laits infantiles du commerce (2025-26 : avec eux, « le problème ne se pose plus »).
   L'usage est plutôt de supplémenter la mère, et l'enfant au besoin, sans arrêter
   l'allaitement, mais aucune source lisible ne l'a confirmé à la relecture. Le point
   n'est donc pas carté comme erreur ; `prt-fa-grossesse-b12` rapporte seulement le
   conseil du ronéo. Faut-il en faire un point douteux ?

## L'échelle : Simple → Moyen → Annale (C20, 19/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 5 janvier (BMCP) ou du 6 janvier (SSH, papier). Sous les annales, 6 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 1 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`).

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `vegetarisme` | 6 | 1 | 1 |

**Le schéma** `ech-vegetarisme`, « Protéines animales, protéines végétales · ce qu'en dit le cours », donne 9 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_VEGETARISME`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

## Régénérer

```powershell
cd contenu\chapitres\bmcp_proteines
..\..\..\app\.venv\Scripts\python.exe generer.py
```

`generer.py` est la copie exacte de
`.claude/skills/nouveau-chapitre/scripts/generer_modele.py`. La planche numérotée se
refait depuis `app/` :
`uv run --with pillow python ../.claude/skills/nouveau-chapitre/scripts/planche_depuis_image.py ../contenu/chapitres/bmcp_proteines prt-pl-schema-general --apercus <brouillon>`.
