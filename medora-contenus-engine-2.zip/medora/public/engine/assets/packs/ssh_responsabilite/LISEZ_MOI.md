# La responsabilité médicale : enjeux, évolution et bonnes pratiques — paquet SSH

79 notes, 168 cartes. Chapitre `chap-ue-ssh-fc3` de l'UE SSH (`ordre=6`). Cours
du **Pr J. Saison, le 01/10/2025**, FC n°6 du Ronéosaure 2025-26 (14 pages) ;
annales des polycopiés SSH 3 et SSH 8 du Ronéosaure 2024-25 et du sujet de SSH
2024/2025, déposé le 15/10/2026 (9 questions, 5 sessions). Examen du 6 janvier
2027, écrit (« 10 QROC + 1 QR »).

**18/10/2026** : 2 recto-verso du sujet de SSH 2025/2026 (examen du
09/01/2026, sans corrigé) — QROC 8, QROC 9 ; voir « Le sujet 2025/2026 ».

**Une fiche provisoire.** Le ronéo 2026-27 de ce cours n'est pas paru au
05/10/2026 : le chapitre est carté sur le Ronéosaure 2025-26 (tâche C16,
décision de Vincent du 02/10), et le ronéo de l'année corrigera les cartes à sa
parution. Les sources portent leur année dans leur auteur : les cartes de cours
prennent le badge « Cours 2025-26 », les cinq qui viennent du cours 2024-25 du
Pr Gosset le badge « Cours 2024-25 ». Deux cartes seulement disent « Absent du
cours 2026-27 » (`ABSENTS_2026`) : deux annales de 2024/2025 dont la notion
entière vient d'un cours 2024-25 du Pr Gosset que le cours 2025-26 ne reprend pas
(les conditions d'exercice, l'incapacité totale de travail) — la règle du dépôt
du 15/10 ; les trois annales plus anciennes tirées des mêmes cours gardent leur
« hors du cours 2025-26 » (décision de C16). Les erreurs du Ronéosaure se disent
par un ATTENTION sans genre : la liste `contenu/ERRATA_RONEOS_2026-27.md` ne
concerne que les ronéos 2026-27.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 16 | 16 |
| Texte à trous | 16 | 95 |
| QROC | 17 | 17 |
| Recto-verso | 18 | 18 |
| Schéma cliquable | 1 | 11 |
| Planche à légender | 1 | 1 |
| Lexique | 10 | 10 |

Dont **11 annales**, toutes rédactionnelles, devenues des recto-verso
(`ANNALES_QROC`, `type="basic"`), sur 6 sessions (2021/2022 S2 à 2025/2026 S1).
Les 16 QCM du cours ont une justification par proposition. L'examen étant
rédactionnel, le chapitre est surtout fait de QROC, de textes à trous et de
recto-verso ; les QCM portent les pièges.

Huit thèmes, dans l'ordre du cours :

| Clé | Libellé |
|---|---|
| `sources-responsabilite` | Sources et types de responsabilité médicale |
| `obligations-medecin` | Les obligations du médecin |
| `information-patient` | L'information du patient (partagé avec `ssh_droits_malades`) |
| `responsabilite-civile` | Responsabilité civile et administrative : indemniser |
| `responsabilite-penale` | La responsabilité pénale |
| `responsabilite-disciplinaire` | La responsabilité disciplinaire |
| `reparation-prejudice` | La réparation du préjudice corporel |
| `responsabilite-evolutions` | Responsabilité : chiffres, nouvelles technologies, bonnes pratiques |

Les huit libellés sont à ajouter à `THEME_LABELS`
(`app/src/med_engine/application/scopes.py`, bloc « ssh ») ; aucun ne porte de
chiffre. Le plan C16 disait « Les sources de la responsabilité médicale » pour
le premier : le libellé dit aussi « types », parce que les cartes du cumul, des
modes d'exercice, des juridictions et des délais y vont (voir les questions).

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-ssh-responsabilite` — Ronéosaure, « FC n°6 La responsabilité médicale _ enjeux, évolution et bonnes pratiques » (14 p.), `SSH/…` | **2025-26** | **la base** : chaque note de cours porte sa page ; c'est ce que le lecteur ouvre (`chapitre=`) |
| `src-annales-ssh-3-responsabilites-medicales` — « SSH 3 - Responsabilités médicales » | 2024-25 | 2023/2024 Q.3 ; 2021/2022 S2 QROC 1 et 2 (`SRC["annales"]`) |
| `src-annales-ssh-8-reparation-juridique-du-dommage-corporel-2` — « SSH 8 - Réparation juridique du dommage corporel 2 » | 2024-25 | 2022/2023 S1 et 2023/2024 S2 (`SRC["sessions"]`) |
| `src-cours-ssh-responsabilites-2425` — FC n°3, « Les responsabilités médicales », Pr Gosset | 2024-25 | appoint : les délais de prescription par type (p. 3-4) ; cité par `resp-fa-prescription` et `resp-qc-prescription` |
| `src-cours-ssh-conflits-2425` — FC n°4, « Les conflits d'intérêts », Pr Gosset | 2024-25 | appoint : la médecine d'expertise (p. 4), source du corrigé de SSH 4 ; cité dans le texte |
| `src-cours-ssh-reparation-2425` — FC n°8 (AC), « La réparation juridique du préjudice corporel », Pr Gosset | 2024-25 | appoint, et clé des trois annales hors cours 2025-26 (p. 5-13) et des conditions d'exercice (p. 2-3, 2024/2025 QROC 2) ; figure p. 11 |
| `src-cours-ssh-ecrits-2425` — FC n°2 (AC), « Les écrits médicaux », Pr Gosset | 2024-25 | appoint : l'incapacité totale de travail et l'arrêt de travail (p. 5-7), clé de 2024/2025 QROC 3 ; cité dans le texte |
| `src-sujets-ssh-2425` — « Sujets de SSH 2024/2025, session 1 » (examen du 10/01/2025, 1 QR et 10 QROC, sans corrigé), déposés le 15/10/2026 | 2024-25 | la source de la session 2024/2025 S1 (`SRC["sessions"]`) ; déclarée à l'identique dans tous les chapitres de SSH qui en cartent une question |
| erratas du Ronéosaure : cours 2025-26 (`Erratas SSH.docx`) et annales 2024-25 | — | aucune entrée sur la FC n°6 ni sur ces polycopiés (celui des annales est vide) |

Les deux déclarations d'annales suivent la règle des sources partagées
(identifiant tiré du nom du fichier, cinq champs) : aucun autre chapitre ne les
déclarait. SSH 4 et SSH 8 « Réparation du préjudice corporel », qui impriment les
mêmes questions en doublon, ne sont pas déclarés : aucune note ne les cite comme
provenance ; les cartes les nomment.

Vérifications hors du cours, citées dans la carte qui s'en sert : le code de la
santé publique (L1111-2, L1142-2, L1142-22, L1142-28, D1142-1, L4111-1, L4112-1, L4112-6,
L4124-6, L4161-5, L6322-2, D6322-30, R.4127-4, -7, -9, -105, -108), le code pénal (121-3,
221-1, 222-11, 222-19, 222-20, 226-13, 441-7, R625-1, R625-2), la
loi du 27 février 2017 sur la prescription pénale, l'arrêt Hédreul (Cass. 1re
civ., 25 février 1997), Cass. 1re civ. 7 octobre 1998 et CE 5 janvier 2000
(Telle) sur les risques exceptionnels, Cass. ch. mixte 30 avril 1976
(transmissibilité), la nomenclature Dintilhac ; l'étymologie (TLFi, Gaffiot,
Bailly, Wiktionnaire).

## Ce que le cours a dicté

- **Pas de rouge** dans la FC n°6.
- **Deux passages gris « NE PAS APPRENDRE »** : les risques exceptionnels et le
  débat qu'ils suscitent (p. 3-4) → une carte, `resp-rv-risques-exceptionnels`,
  tag `edn` (pour les EDN, hors partiel) ; les arrêts cités p. 8-9 (« ne servent
  que d'illustration ») → aucune carte : seuls les principes qu'ils illustrent —
  l'expertise déterminante, demander un autre avis, les règles de l'art au jour
  de l'acte — sont cartés (`resp-qc-moyens`, `resp-qr-regles-art`,
  `resp-qr-expertise`).
- **Le gris de la p. 7** (« définition non précisée en cours : le délai de
  prescription… ») est la voix des rédacteurs : carté (`resp-an-2324-q3`).
- **Les chiffres de la p. 12** (31 radiations, 5 %, MACSF) : une carte, qui
  n'exige pas les chiffres (`resp-qc-chiffres`).
- **Ce qui appartient à d'autres chapitres** (plan C16, §3) : le consentement,
  le fondement et les limites de l'information, le dossier médical, la fin de
  vie (`ssh_droits_malades`, FC n°14). De l'information, ce chapitre ne prend
  que l'obligation, sa forme, sa preuve et ses exceptions (p. 3-5).

**Couverture de la FC n°6** : I. Introduction (p. 2 : `resp-fa-sources`,
`resp-qc-sources`, `resp-qr-respondere`, `resp-qr-kouchner`) ; II.A moyens
(p. 3) ; II.B information (p. 3-5 : sept notes) ; II.C-E secret,
non-discrimination, secours (p. 6) ; III cumul, sanctionner/indemniser, modes
d'exercice, trois conditions, PH et HU (p. 6-8) ; III.A civile, expertise, CCI
et seuils (p. 8-10) ; III.B pénale (p. 10) ; III.C disciplinaire (p. 10-11) ;
tableau récapitulatif (p. 11 : zone, planche, figures) ; IV chiffres, IA,
influenceur (p. 12-13) ; V bonnes pratiques (p. 13-14).

## Les erreurs du Ronéosaure 2025-26

Chacune est dite par **ATTENTION**, sans genre, dans la carte qui porte la
notion.

| Page | Ce que dit le Ronéosaure | Ce qui est juste | Carte |
|---|---|---|---|
| 7 | « Dans tous les cas, les actions se prescrivent par un délai de 10 ans » | 10 ans depuis la consolidation pour l'action en indemnisation, civile ou administrative (L1142-28 CSP) ; au pénal 1, 6, 20 ans (loi du 27 février 2017) ; devant l'Ordre, aucun délai — ce que disait le cours 2024-25 (FC n°3, p. 3-4) et ce que demandent les trois annales de SSH 3. Point douteux : prise de notes ou raccourci, la FC ne permet pas de trancher | `resp-fa-prescription`, `resp-qc-prescription` D, `resp-an-2324-q3`, `resp-an-2122s2-qroc1` |
| 5 | avant 2002, « c'était au patient de montrer la preuve qu'il avait bien été informé » ; la loi Kouchner « a instauré » l'inversion | il devait prouver qu'il ne l'avait PAS été ; l'inversion vient de l'arrêt Hédreul (1997), que la loi de 2002 a inscrit à l'article L1111-2. À l'examen, « depuis la loi Kouchner » reste juste | `resp-qc-preuve` A, `resp-an-2526s1-qroc8` (explication) |
| 4 (gris) | « depuis la loi Kouchner, les juges ont inclus l'information sur les risques exceptionnels dans la loi » | la jurisprudence a précédé la loi (Cass. 7 octobre 1998 ; CE 5 janvier 2000, Telle) ; la loi dit « risques fréquents ou graves normalement prévisibles » | `resp-rv-risques-exceptionnels` |

Sans ATTENTION, dites dans l'explication parce qu'aucune réponse n'en dépend :
le DFT « > 50 % » (≥ 50 %, D1142-1) et « APIPP » pour AIPP (p. 9,
`resp-fa-cci-seuils`) ; le titre « commission d'indemnisation et de
conciliation » (p. 9, `resp-qr-cci`) ; les infractions spécifiques « plutôt dans
le code de la santé publique » — le secret et le faux certificat sont dans le
code pénal (p. 10, `resp-fa-penal`) ; l'élément moral « volonté consciente » des
infractions involontaires (p. 11, `resp-fa-infraction`) ; l'assurance « rappelée »
par la loi Kouchner, qui l'a créée (p. 8, `resp-qc-exercice` E).

Erreurs des cours 2024-25, dites là où elles servent : « homicide involontaire
et volontaire » parmi les délits (FC n°3, p. 3, recopié par le corrigé de
2021/2022 S2 QROC 1) ; le quantum doloris « pas transmissible » (FC n°8, p. 12 ;
transmissible depuis Cass. ch. mixte 30 avril 1976).

## Ce que les annales ont dicté

| Savoir | Questions |
|---|---|
| Le délai de prescription : définition, civil, pénal, Ordre | 2023/2024 Q.3, 2021/2022 S2 QROC 1 et QROC 2 |
| Les délits qui engagent la responsabilité pénale | 2021/2022 S2 QROC 1 |
| Expert et médecin conseil d'assurance | 2022/2023 S1 QROC 2 (imprimée trois fois) |
| Le quantum doloris | 2022/2023 S1 QROC 1 (imprimée deux fois) |
| Le déficit fonctionnel permanent | 2023/2024 S2 QROC |
| Les quatre conditions d'exercice de la médecine | 2024/2025 S1 QROC 2 |
| Incapacité totale de travail et arrêt de travail | 2024/2025 S1 QROC 3 |
| L'ONIAM | 2024/2025 S1 QROC 4 |

**Le sujet de 2024/2025** (session 1, déposé le 15/10/2026, sans corrigé) range
ici trois de ses dix QROC. Deux viennent de cours du Pr Gosset de 2024-25 sans
version 2025-26 — les conditions d'exercice (FC n°8, p. 2-3) et l'incapacité
totale de travail (FC n°2 « Les écrits médicaux », p. 5-7, le cours de SSH 2 que
le plan C16 rangeait déjà ici) — et sont des cartes entières « Absent du cours
2026-27 ». L'ONIAM est dans la FC n°6 (p. 9) ; son rôle vient du cours 2024-25
(FC n°3, p. 8-14). Sa QROC 1, l'intoxication aiguë à la cocaïne, vient d'un
autre cours du Pr Gosset de 2024-25 (FC n°12 et n°16, « Cocaïne ») qu'aucun
chapitre ne porte : pas de carte.

Les trois anciennes viennent de cours du Pr Gosset qui n'ont pas de version
2025-26 (conflits d'intérêts, réparation juridique du préjudice corporel). Le
plan C16 (§13) propose de les carter ici, sous `reparation-prejudice` : la
réparation est l'aboutissement de la responsabilité civile, dont la FC n°6 porte
le cadre (expertise, CCI, seuils). Proposition appliquée : chaque carte dit
« hors du cours 2025-26 » et cite le cours 2024-25 à la page ; trois cartes de
cours d'appoint (`resp-fa-consolidation`, `resp-qr-echelle-qd`,
`resp-rv-pretium`) permettent d'y répondre avant de les voir.

**SSH 2 - Les écrits médicaux** (2023-2024, QR) : l'énoncé manque (« QR: »
suivi de rien, vérifié sur l'image de la page), sans corrigé : aucune carte.

## Les annales et leurs clés

| Question | Polycopié | Corrigé imprimé | Retenu | Pourquoi |
|---|---|---|---|---|
| 2023/2024 Q.3 a) b) (délai de prescription ; devant l'Ordre) | SSH 3 | en italique, sans accolades ni mention officielle : a) « l'espace de temps entre les faits et une certaine date… » ; b) « pas de délai de prescription » | **repris** | juste (cours 2024-25, p. 3-4) ; ATTENTION contre le « 10 ans dans tous les cas » de la FC 2025-26 |
| 2021/2022 S2 QROC 1 (trois délits ; délai) | SSH 3 | violation du secret, non-assistance, coups et blessures involontaires, « homicide involontaire **et volontaire** » ; 6 ans | **sans l'homicide volontaire** | c'est un crime (art. 221-1 du code pénal : cour d'assises, 20 ans) ; les 6 ans sont justes |
| 2021/2022 S2 QROC 2 (délai ; au civil) | SSH 3 | « 10 ans (loi du 4 mars 2002) » | **repris**, avec le point de départ (la consolidation) | L1142-28 CSP |
| 2022/2023 S1 QROC 2 (expert / médecin conseil) | SSH 8 « 2 » (aussi SSH 4 et SSH 8 « 1 ») | SSH 4 : l'expert seul, entre accolades ; SSH 8 : « pas de correction, voir cours » | **clé déduite** : l'expert et le médecin conseil, et leur incompatibilité | le corrigé de SSH 4 ne dit pas la différence ; son « pas de secret médical » est nuancé (R.4127-108) |
| 2022/2023 S1 QROC 1 (quantum doloris) | SSH 8 « 2 » (aussi SSH 8 « 1 ») | « pas de correction » | **clé déduite** du cours 2024-25 (FC n°8, p. 12) | — |
| 2023/2024 S2 QROC (deux éléments d'un DFP) | SSH 8 « 2 » | lien profession/IPP ; IPP antérieure ; barèmes (droit commun, ONIAM) | **barèmes, état antérieur, écart à la consolidation, douleurs persistantes** ; le lien avec la profession retiré | c'est un autre préjudice, l'incidence professionnelle (cours 2024-25, p. 10) |
| 2024/2025 S1 QROC 2 (les 4 conditions d'exercice) | sujet 2024/2025 | aucune (sujet sans corrigé) | **clé déduite** : diplôme, nationalité, inscription au tableau de l'Ordre, moralité | cours 2024-25 (FC n°8, p. 2-3) ; L4111-1 en pose trois, la moralité est vérifiée à l'inscription (L4112-1) |
| 2024/2025 S1 QROC 3 (incapacité totale de travail / arrêt de travail) | sujet 2024/2025 | aucune (sujet sans corrigé) | **clé déduite** : notion pénale, travail personnel, qualification de l'infraction / notion professionnelle et sociale ; deux certificats | cours 2024-25 (FC n°2, p. 5-7) ; seuils du code pénal (222-11, 222-19, R625-1, R625-2) |
| 2024/2025 S1 QROC 4 (l'ONIAM) | sujet 2024/2025 | aucune (sujet sans corrigé) | **clé déduite** : l'office, la solidarité nationale, l'aléa, les seuils, la CCI | FC n°6 2025-26, p. 9 ; cours 2024-25 (FC n°3, p. 8-14) ; L1142-22, D1142-1 |

Aucune n'est marquée officielle : les corrigés de SSH 3, imprimés sans
accolades, ne sont dits officiels nulle part et recopient le cours 2024-25,
erreur comprise. `CONFLITS = []` : il ne se déclare que sur une proposition de
QCM.

## Le schéma cliquable et la planche

| Fichier | Ce qu'on clique | Cartes |
|---|---|---|
| `juridictions.svg` (`resp-zo-juridictions`) | les onze juridictions du tableau de la p. 11 : police, correctionnel, assises ; tribunal judiciaire, cour d'appel, Cour de cassation ; chambres disciplinaires régionale et nationale ; tribunal administratif, cour administrative d'appel ; Conseil d'État | 11 |

Redessiné nu d'après le tableau récapitulatif (p. 11) : la pénale à gauche,
rangée par gravité (« si contravention », « si délit », « si crime ») ; les trois
autres colonnes par degré (premier degré, appel, cassation), le Conseil d'État
dans une seule case sous la disciplinaire et l'administrative. Les pièges
visés : la Cour de cassation et le Conseil d'État, le tribunal judiciaire et le
tribunal correctionnel. La version nommée, `juridictions-legende.svg`, tirée des
mêmes constantes, est en correction.

**La planche** `resp-pl-mode-exercice` : la diapositive « Variations selon le
mode d'exercice de l'activité médicale » (p. 11), les neuf cases (libéral,
salarié, territorial ou PMI × civile, pénale, disciplinaire) blanchies EN ENTIER
par `scripts/planche_depuis_image.py` — une case vidée à la taille de son texte
aurait trahi « Personnelle ». Cinq légendes (« Employeur responsable » sert aux
cases 4 et 7 : la réserve « sauf abus de mission » est dite dans la note du 4),
trois intrus du même champ — « l'établissement, devant le tribunal correctionnel », « ONIAM, au titre
de la solidarité nationale », « aucune devant l'Ordre » ; jamais un synonyme d'une légende (un premier
intrus, « l'établissement, à la place du médecin », redisait « Employeur responsable » : remplacé à la
relecture). L'image numérotée et l'aperçu de contrôle ont été
relus.

**Illustrations** : 14 QCM sur 16 (88 %) portent en correction une figure de la
FC (la diapositive p. 11, le graphique MACSF p. 12, les tableaux des p. 7 et 11,
extraits en PNG) ou un schéma redessiné (juridictions, CCI et seuils, délais de
prescription, information et preuve) ; 42 notes sur 79. Les deux QCM sans
figure (`resp-qc-sources`, `resp-qc-technologies`) n'en ont pas dans la FC. Les
cartes du préjudice corporel montrent le schéma capacité-temps du cours 2024-25
(FC n°8, p. 11).

## Le sujet 2025/2026 (18/10/2026)

Les sujets de SSH de l'examen du 09/01/2026 (1 QR, 10 QROC,
`src-sujets-ssh-2526`, sans corrigé), déposés le 18/10/2026, apportent 2
recto-verso à ce chapitre (QROC 8, QROC 9). Aucun n'était déjà en cartes. Au
verso, la bonne réponse, tirée du ronéo 2026-27 quand il couvre la notion,
sinon du cours 2025-26, celui de l'année de l'examen ; ce qui dépasse le cours
est dit « hors cours », avec sa source (`officielle=False`). Rédigés et
contre-vérifiés le 18/10/2026 : un rédacteur, un sceptique, un critique de
complétude.

| Question | Ce que le verso répond | Voisine de |
|---|---|---|
| 2025/2026 S1 QROC 8 (`resp-an-2526s1-qroc8`) | le professionnel ou l'établissement (L1111-2, arrêt Hédreul) ; par tout moyen, l'écrit n'étant exigé que dans les cas prévus par la loi | — |
| 2025/2026 S1 QROC 9 (`resp-an-2526s1-qroc9`) | sanctionner : pénale, disciplinaire ; réparer : civile (libéral, clinique), administrative (hôpital public, sauf faute détachable) | `resp-an-2122s2-qroc1` |

Ce qui est signalé :

- QROC 8 : ATTENTION nu sur la charge de la preuve avant 2002 (FC n°6, p. 5) :
  le patient devait prouver qu'il n'avait PAS été informé, et le renversement
  vient de l'arrêt Hédreul (1997) ; carte ajoutée à la ligne du tableau des
  erreurs. Arrêts vérifiés le 18/10/2026 : Cass. 1re civ., 25 février 1997, n°
  94-19.685 (Hédreul) ; 14 octobre 1997, n° 95-19.609 (« par tous moyens, et
  notamment par des présomptions »).
- QROC 9 : le cours ne distingue pas le salarié du public et celui du privé ; le
  verso le fait, hors cours (Cass. 1re civ., 9 novembre 2004, Bull. I n° 262 :
  le médecin salarié qui reste dans sa mission n'engage pas sa responsabilité
  envers le patient).
- Coquilles gardées telles qu'imprimées : « Quelles sont les différents types »
  (QROC 9), « ? et selon quelles modalités » (QROC 8).

## Le lexique

Dix termes, pages mesurées dans la FC n°6 (plan exclu) : jurisprudence (2, 8),
obligation de moyens (3, 8), déontologie (2, 7, 10, 11), secret professionnel
(6, 7, 11), délai de prescription (7 ; et FC n°3 2024-25, p. 3, 4), préjudice
(8), indemnisation (8, 9), expertise (8, 10), radiation (10, 11, 12) ; quantum
doloris, absent de la FC n°6, aux pages de la FC n°8 2024-25 (12, 13). Chacun dit
son origine grecque ou latine.

Les étymologies — onze racines nouvelles (`jus, juris (latin)`,
`prudentia (latin)`, `obligare (latin)`, `deon (grec)`, `secernere (latin)`,
`profiteri (latin)`, `judicium (latin)`, `damnum (latin)`,
`radiare (latin tardif)` — distincte de `radi- (latin)`, le rayon —,
`quantus (latin)`, `dolor (latin)`) et les dix termes — sont **proposées** pour
`scripts/etymologies.json`, avec leurs sources ; la table n'est pas modifiée par
ce chapitre. Les définitions et les racines disent déjà, mot pour mot, ce
qu'`appliquer_etymologies.py` en écrira. Les racines réemployées gardent la clé
de la table : `medius (latin)`, `-logie, de logos (grec)`,
`praescribere (latin)`, `pré- (latin)`, `in- (latin)`, `experiri (latin)`.

## Questions pour Vincent

1. **SSH 2 - Les écrits médicaux, 2023-2024, QR** : le polycopié n'imprime pas
   l'énoncé. As-tu le sujet 2023-24 ? Sans lui, aucune carte (plan C16, §13).
2. **Le cours de réparation juridique du préjudice corporel (Pr Gosset)
   existe-t-il en 2026-27 ?** Proposition du plan appliquée : ses trois annales
   (expert et médecin conseil, quantum doloris, DFP) et trois cartes d'appoint
   sont ici, sous `reparation-prejudice`, badge « Cours 2024-25 », chacune dite
   « hors du cours 2025-26 ». Si le cours revient, elles migreront vers son
   chapitre (`chap-ue-ssh-fc8`).
3. **« Dans tous les cas, 10 ans » (FC n°6, p. 7)** : à vérifier sur le ronéo
   2026-27 du Pr Saison. D'ici là, les cartes répondent par type de
   responsabilité, comme les annales.
4. **Le libellé du thème `sources-responsabilite`** : élargi en « Sources et
   types de responsabilité médicale » (le plan disait « Les sources de la
   responsabilité médicale »), pour qu'il dise vrai des cartes du cumul, des
   modes d'exercice, des juridictions et des délais. À valider avant de l'écrire
   dans `THEME_LABELS`.
5. **Les cours de médecine légale du Pr Gosset (2024-25)** — écrits médicaux,
   réparation du préjudice, cocaïne — n'ont aucune version 2025-26. Le sujet de
   2024/2025 en interroge trois notions : deux sont cartées ici, « Absent du
   cours 2026-27 » ; la troisième, l'intoxication aiguë à la cocaïne (QROC 1),
   n'a aucun chapitre. Si ces cours reviennent en 2026-27, le tag tombera et la
   cocaïne trouvera son chapitre.

## À relire

Aucune carte `a-relire` : chaque carte de cours porte sa page (dans la FC n°6
2025-26, ou dans la FC n°3 ou n°8 2024-25 pour les cinq cartes d'appoint), chaque
annale une clé vérifiée sur le cours et les textes. À la parution du ronéo
2026-27 de ce cours, relire toutes les cartes contre lui : pages, chiffres
(radiations 2022, déclarations MACSF 2023), le délai de prescription de la p. 7,
et le sort des trois annales du Pr Gosset.

## L'échelle : Simple → Moyen → Annale (C20, 19/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 5 janvier (BMCP) ou du 6 janvier (SSH, papier). Sous les annales, 32 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 7 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`) ; les QROC reçoivent le schéma nu.

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `sources-responsabilite` | 4 | 1 | 1 |
| `obligations-medecin` | 4 | 1 | 1 |
| `information-patient` | 5 | 1 | 1 |
| `responsabilite-civile` | 3 | 1 | 2 |
| `responsabilite-penale` | 7 | 1 | 2 |
| `responsabilite-disciplinaire` | 2 | 1 | 1 |
| `reparation-prejudice` | 7 | 1 | 3 |

**Le schéma** `ech-responsabilite`, « La responsabilité médicale · qui répond, qui répare », donne 40 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_RESPONSABILITE`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Constantes ajoutées** à `annales.py` (`_SCHEMA_LETTRES`, `_SCHEMA_NU`) : les annales de SSH sont toutes des QROC, rangées dans `ANNALES_QROC` ; chacune reçoit le schéma nu, et les marches la préparent sans lettre.

**Sans marche** :
- resp-an-2526s1-qroc9 : les juridictions de chaque responsabilité (tribunal judiciaire, administratif, Conseil d'État, chambres de l'Ordre) et le Centre national de gestion — le schéma n'a plus la place ; la carte de zone resp-zo-juridictions les tient déjà
- resp-an-2425s1-qroc4 : la composition de la CCI, les victimes que l'ONIAM indemnise à part (vaccins obligatoires, VIH et hépatite C transfusionnels, Mediator, hormone de croissance) et les délais de la procédure — détails du cours 2024-25, sans marche
- resp-an-2425s1-qroc3 : les seuils de qualification (8 jours, 3 mois) — une ligne de plus aurait trahi le trou « une notion du droit pénal » de la même case
- resp-an-2324s2-qroc : la douleur persistante dans le DFP — sans Simple (une ligne dans la case du DFP aurait donné sa réponse par sa seule place) ; resp-ech-m6 D la porte
- resp-an-2223s1-qroc1 : « pas transmissible » aux héritiers (cours 2024-25, p. 12) — c'est l'erreur que l'ATTENTION de la carte relève ; aucune marche ne l'enseigne
- resp-an-2526s1-qroc8 : l'arrêt Hédreul et l'article L1111-2, hors cours — dits seulement dans l'ATTENTION de resp-ech-s1

## Régénérer

```powershell
cd contenu\chapitres\ssh_responsabilite
..\..\..\app\.venv\Scripts\python.exe generer.py
```

La planche se refait depuis `app/`, si ses rectangles changent :
`uv run --with pillow python ../.claude/skills/nouveau-chapitre/scripts/planche_depuis_image.py ../contenu/chapitres/ssh_responsabilite resp-pl-mode-exercice --taille 38 --apercus <brouillon>`.
Les figures PNG ont été extraites du PDF (pymupdf) : les deux diapositives
(p. 11 réduite à 1 200 px de large, p. 12), les tableaux des p. 7 et 11 rognés à
200 dpi, et la figure p. 11 de la FC n°8 2024-25.
