# Pharmacologie du système nerveux végétatif — paquet BMCT

134 notes, 193 cartes. Chapitre `chap-ue-bmct-fc4` de l'UE BMCT, quatrième
chapitre de l'UE. **Cours du 05/10/2026, de 10 h à 12 h, Pr S. Gautier, en deux
ronéos Ronéo & Juliette 2026-27** (partie 1, 10 h-11 h ; partie 2, 11 h-12 h).
Réaligné sur elles le 19/10/2026 ; il était carté depuis le 02/10 (C14) sur la
FC n°4 du Ronéosaure 2025-26 (Pr Deplanque, 07/10/2025), qui n'est plus qu'un
appoint. Annales : 25 QCM et deux questions rédactionnelles sur onze sessions
(Ronéosaure 2024-25 et sujet 2024/2025). Examen : partiel de novembre (mercredi
4/11/2026).

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 60 | 60 |
| QRU (marches Simple) | 29 | 29 |
| Texte à trous | 11 | 63 |
| QROC | 10 | 10 |
| Recto-verso | 10 | 10 |
| Lexique | 12 | 12 |
| Schéma cliquable | 2 | 9 |

Dont **30 annales** sur 11 sessions : 25 QCM (2015/2016 à 2024/2025 S1) et les
deux questions rédactionnelles sans corrigé, en recto-verso (`ANNALES_QROC`) — les
quatre sous-questions de la Question n°2 de 2022/2023 (l'atropine) et le QROC 1
de 2018/2019 (le schéma de l'organisation synaptique). Les trois QCM du sujet
2024/2025, session 1 (`snv-an-2425s1-q14` à `-q16`), n'ont pas de corrigé : clés
déduites du cours. Le PDF du sujet porte une correction surlignée en bleu,
officieuse et d'origine inconnue (le même surligneur reproduit 37 des 40 clés
officielles de 2023-24) : non déclarée, elle sert de seconde opinion, et donne les
mêmes clés (CE, AD, BE). Les clés de 2023/2024 (Q.12 AD, Q.13 BE, Q.14 CE) sont
confirmées par la grille officielle de la faculté (dépôt du 15/10/2026).

Les 28 QCM du cours comprennent les **quatre QCM du professeur** que les ronéos
corrigent (QCM 1, partie 1, p. 2 ; QCM 2, p. 5 ; QCM 3, p. 12 ; QCM 4, partie 2,
p. 3-4), marqués `officielle=True` comme un quizz corrigé ; les mêmes, avec les
mêmes réponses, qu'en 2025-26. Sous les annales, l'échelle : 29 marches Simple et
7 marches Moyen (voir plus bas). **88 QCM sur 89 illustrés (99 %)**, 115 notes sur
134. **5 cartes absentes du cours 2026-27** (tag `absent-2026`), **28 cartes
portent un piège du ronéo** (thème « Pièges des ronéos »). Aucune carte
`a-relire`.

Six thèmes, déjà dans `THEME_LABELS` (`app/src/med_engine/application/scopes.py`) ;
le réalignement n'en ajoute aucun :

| Clé | Libellé |
|---|---|
| `organisation-snv` | Organisation du système nerveux végétatif |
| `synapse-adrenergique` | Synapse et récepteurs adrénergiques |
| `synapse-cholinergique` | Synapse et récepteurs cholinergiques |
| `effets-snv` | Effets sympathiques et parasympathiques |
| `pupille` | Pupille : myosis et mydriase |
| `modulation-snv` | Mimétiques et lytiques |

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-bmct-snv-2627-1` — « Pharmacologie du système nerveux végétatif » (14 p.), `BMCT/PHARMACOLOGIE DU SYSTÈME NERVEUX VÉGÉTATIFS.pdf` | **2026-27** | **partie 1**, 10 h-11 h : introduction et QCM 1 (p. 2), organisation macroscopique et globale (p. 2-5), sympathique, médullosurrénale, synapse et récepteurs adrénergiques (p. 6-9), parasympathique, synapse cholinergique, nicotiniques, muscariniques (p. 9-12), QCM 3, effets de l'activation (p. 12-13) ; p. 14 sans cours ; `SRC["fiche"]`, ce que le lecteur ouvre ; 40 notes |
| `src-fc-bmct-snv-2627-2` — « Pharmacologie du système nerveux végétatif 2 » (8 p., la dernière vide), `BMCT/PHARMACOLOGIE DU SYSTÈME NERVEUX VÉGÉTATIFS 2.pdf` | **2026-27** | **partie 2**, 11 h-12 h : dualité d'action et vaisseaux (p. 2), œil et QCM 4 (p. 3-4), vocabulaire, parasympathomimétiques et parasympatholytiques (p. 4-5), atropine (p. 5-6), sympathomimétiques, sympatholytiques, conclusion (p. 6-7) ; `fiche=FC2` ; 47 notes |
| `src-fc-bmct-snv-2526` — FC n°4, « Pharmacologie du SNV » (24 p.) | 2025-26 | **appoint** (`SRC["cours"]`, `SRC["medias"]`, sans `chapitre=`) : ce que l'année ne reprend pas, sept figures, et la source des **5 cartes absentes** |
| `src-annales-bmct-snv` — « BMCT - Pharmacodynamie du SNV » (8 p.) | 2024-25 | 10 sessions, table de corrections p. 7-8 |
| `src-sujets-bmct-2425` — Sujets de BMCT 2024/2025, session 1 (20 p.) | 2024-25 | les Q14 à Q16, sujet sans corrigé ; `SRC["sessions"]["2024/2025 S1"]` |
| tableau d'erreurs BMCT de la promo 2026-27 | 2026-27 | rien sur ce cours au 19/10/2026 (deux entrées, sur la pharmacocinétique et la pharmacodynamie) |

Les textes citent « partie 1, p. 7 » (ronéo 2026-27) ou « FC 2025-26, p. 22 ».
Lus en appoint, sans être déclarés : la FC n°4 2024-25 (Ronéosaure, Pr Deplanque),
le cours 2023-24 n°5 (Charonéo) — la myasthénie (p. 15), les effets indésirables
et contre-indications de l'atropine (p. 18) ; l'errata des cours 2025-26 et celui
des annales BMCT ; le RCP d'Atropine Aguettant (BDPM) et la monographie Vidal du
tropicamide. Les deux fiches de l'année se copient dans le dossier des PDF de
l'application par `outils/copier_les_cours.py`, lancé avec le dossier des ronéos
2026-27 (`Ajouts/[NUMERIQUE] Ronéo & Juliette 26-27 19 10 2026/S1/CM`), hors du
bac à sable.

Les en-têtes des ronéos nomment leurs rédacteurs et leurs correcteurs, et la
partie 1 finit sur une page qui n'est pas du cours (p. 14) : aucun nom n'est
repris. L'en-tête de la partie 2 écrit « Gauthier » ; c'est le Pr Gautier.

## Ce qui correspond à quoi

Les deux ronéos suivent tout le plan de la FC 2025-26 ; le texte de la partie 1
en reprend souvent les phrases mot pour mot, **erreurs comprises** :

| FC 2025-26 | Ronéo 2026-27 |
|---|---|
| I. Introduction, QCM 1 (p. 2) | partie 1, p. 2 |
| II.A-B Organisation macroscopique et globale, niveaux, innervation viscérale, QCM 2 (p. 3-6) | partie 1, p. 2-5 |
| II.C.1 Sympathique, médullosurrénale, synapse et récepteurs adrénergiques (p. 6-10) | partie 1, p. 6-9 |
| II.C.2 Parasympathique, synapse et récepteurs cholinergiques (p. 10-14) | partie 1, p. 9-12 |
| III.A-B Activation sympathique et parasympathique, QCM 3 (p. 15-17) | partie 1, p. 12-13 |
| III.C Dualité d'action, vaisseaux (p. 17-18) | partie 2, p. 2 |
| III.D Œil (p. 19) | partie 2, p. 3 |
| IV.A-B Vocabulaire, synapse et modulation, QCM 4 (p. 19-21) | partie 2, p. 3-4 |
| IV.C Parasympathomimétiques, organophosphorés, parasympatholytiques, atropine (p. 21-23) | partie 2, p. 4-6 — **sans les organophosphorés ni l'Alzheimer ni l'ipratropium** |
| IV.D Sympathomimétiques, sympatholytiques, conclusion (p. 23-24) | partie 2, p. 6-7 |

## Le réalignement du 19/10/2026

Les **85 notes de cours** de la version 2025-26 (sans compter le lexique), échelle
comprise, ont été relues une à une contre les deux ronéos : **80 confirmées**, qui citent
désormais leur page de l'année (`page`, et `fiche=FC2` pour la partie 2) et
perdent le badge « Cours 2025-26 » ; **5 absentes** (plus bas). Dans les cartes
confirmées, chaque proposition que seul le cours 2025-26 porte le dit dans sa
justification (« FC 2025-26, p. 7 ; le ronéo 2026-27 dit seulement… ») : une
carte n'est confirmée que si sa notion centrale est dans le cours de l'année. Les
annales gardent leurs énoncés et leurs clés ; leurs justifications citent l'année.

**Ce que le ronéo 2026-27 dit autrement, et ce qui a été réécrit** :

- **La sudation de l'atropine est désormais du cours** (« glandes sudorales :
  diminution de la sécrétion sudorale », partie 2, p. 6), avec l'hyperhidrose
  parmi les indications : 2024/2025 S1 Q16 E se justifie par l'année, et une
  marche nouvelle la prépare (`snv-ech-s29`, une ligne « peau : sudation ↓ »
  ajoutée à la case de l'atropine du schéma).
- **La paralysie de l'accommodation** est du cours (partie 2, p. 6) : 2023/2024
  Q.14 C et 2020/2021 Q.17 A n'ont plus besoin des cours 2023-24 et 2024-25.
- **Les contre-indications de l'atropine** mêlent cette année quatre effets
  indésirables aux deux vraies (voir les erreurs).
- **L'atropine « bradycardisante à faible dose »** (partie 2, p. 6) : un ATTENTION
  nu dans la justification partagée des six sessions du blocage muscarinique et
  dans 2024/2025 S1 Q16 C dit que la clé (« diminue la fréquence cardiaque »,
  faux) reste juste — une bradycardie transitoire du début, que le RCP décrit.
- **L'activation parasympathique « diminue la PA »** (partie 1, p. 13) : la
  justification des anticholinestérasiques et de la pression artérielle (trois
  sessions, D faux) dit pourquoi la clé ne change pas.
- **Les indirects du parasympathique sont « pas importants »** (« activité sur la
  plaque motrice, je passe », partie 2, p. 5) : les organophosphorés, leur
  intoxication et leur traitement, l'Alzheimer déremboursé ne sont plus au cours.
- **L'hypertension** : les sympatholytiques indirects (méthyldopa, clonidine)
  « étaient utilisés avant » et sont jugés peu efficaces ; les antagonistes α
  baissent la pression et traitent l'hypertrophie prostatique (partie 2, p. 7) :
  la case « Contre l'hypertension » du schéma dit désormais « les antagonistes
  α », et la marche s19 cite l'année.
- **La médullosurrénale** n'a plus sa diapositive (« second neurone », 4:1) : la
  proposition D de `snv-qc-medullosurrenale` la cite dans la FC 2025-26.
- **Le muscle ciliaire** n'a plus les diapositives « Activation adrénergique » et
  « Activation cholinergique » : sa contraction pour l'accommodation se lit dans
  la paralysie que donne l'atropine (partie 2, p. 6), et la diapositive de 2025-26
  (FC 2025-26, p. 16) reste citée ; de même pour l'utérus gravide (p. 15).
- **La scopolamine** n'est plus dite « en patch » : la QROC `snv-qr-scopolamine`
  la demande « sédative et amnésiante », contre le mal des transports.
- **La pilocarpine a une sœur** : l'acéclidine, acceptée dans `snv-qr-pilocarpine`.
- **Le NO** active « une enzyme » : la guanylate cyclase reste dans les cartes,
  sourcée par la FC 2025-26 (p. 18).

**Notes nouvelles (11)**, sur ce que le cours 2026-27 apporte :

| Note | Ce qu'elle carte |
|---|---|
| `snv-qc-cholinomimetiques` | esters de la choline, M1-M2-M3, pilocarpine et acéclidine, arécoline (partie 2, p. 4-5) |
| `snv-qc-parasympatholytiques` | tropicamide, conduite après fond d'œil, scopolamine naturelle, anticholinergiques de la personne âgée, antagonistes nicotiniques (partie 2, p. 5) |
| `snv-qc-atropine-proprietes` | sudation, bradycardie à faible dose, malaise vagal, antispasmodiques, larmes (partie 2, p. 6) |
| `snv-qc-sympathique-medicaments` | α-bloquants et prostate, réserpine parkinsonienne, faux neurotransmetteur, sympatholytiques indirects déchus, effets neuropsychiatriques (partie 2, p. 6-7) |
| `snv-fa-atropine-indications` | indications et contre-indications de l'atropine (partie 2, p. 6) |
| `snv-qr-tropicamide` | le Mydriaticum (partie 2, p. 5) |
| `snv-ech-s29` | la sudation sous atropine, marche Simple de 2024/2025 S1 Q16 E |
| `lex-anticholinergique`, `lex-hyperhidrose`, `lex-parasympathomimetique`, `lex-sympatholytique` | quatre termes du lexique (plus bas) |

## Ce que le cours a dicté

- **Le rouge** des deux ronéos est celui des titres du plan, de « Attention » (un
  même neurotransmetteur, des effets opposés selon le récepteur et le tissu :
  `snv-qc-dualite-vaisseaux`), de « mimétiques » et « lytiques »
  (`snv-qc-vocabulaire`, `snv-rv-mimetique-lytique`) et de la conclusion.
- **Le gris** (les QCM 1 à 3, le moyen mnémotechnique, le cortisol, les
  tremblements β2, la belladone, les agonistes nicotiniques passés) est la voix
  des rédacteurs (décision de Vincent du 25/09) et se carte comme le reste ;
  aucun ronéo ne le définit comme hors programme.
- **Ce que le professeur a dit de laisser** : « les différents sous-types de
  récepteurs ne sont pas à apprendre » (partie 1, p. 13), mais les annales
  interrogent β1 et β2 : `snv-fa-recepteurs-adrenergiques` les carte ; les
  inhibiteurs de l'acétylcholinestérase, « pas importants » (partie 2, p. 5) :
  les cartes qui en vivaient sont absentes, les annales restent.
- **Le QCM 3** se carte dans sa version juste (partie 1, p. 12, BCE) ; sa copie
  grise de la même page, aux réponses fausses, est signalée.
- **Pas de carte propre** sur la méditation des sujets entraînés (partie 1, p. 4),
  dite dans `snv-fa-fonctions` et la marche s1.

## Ce que les annales ont dicté

| Savoir | Questions |
|---|---|
| Le SNA : récepteurs ganglionnaires et tissulaires, chaîne paravertébrale, « autonome » | 2024/2025 S1 Q14 (= 2022/2023 Q.10 mot pour mot), 2022/2023 Q.10, 2020/2021 Q.7, 2019/2020 S1 Q.12, 2018/2019 Q.9, 2017/2018 Q.11, 2015/2016 Q.12 |
| Le blocage des récepteurs muscariniques | 2023/2024 Q.12, 2021/2022 Q.7, 2019/2020 S1 Q.13, 2018/2019 Q.10, 2017/2018 Q.12, 2015/2016 Q.13 |
| Les anticholinestérasiques (diarrhée, myasthénie, bradycardie) | 2022/2023 Q.11, 2019/2020 S2 Q.13, 2016/2017 Q.11 |
| Les inhibiteurs irréversibles de l'acétylcholinestérase | 2023/2024 Q.13, 2021/2022 Q.8 |
| Les récepteurs β, β1 | 2024/2025 S1 Q15 (= 2020/2021 Q.8 mot pour mot), 2021/2022 Q.9, 2020/2021 Q.8, 2016/2017 Q.10 |
| Les effets anticholinergiques, de l'atropine ou d'autres médicaments | 2024/2025 S1 Q16, 2023/2024 Q.14, 2020/2021 Q.17 |
| L'atropine : mécanisme, mydriase, surdosage, contre-indications | 2022/2023 Question n°2 a-d |
| Le schéma de l'organisation synaptique | 2018/2019 QROC 1 |

Une carte par session ; l'explication renvoie aux autres. Trois notions des
annales manquent au cours 2026-27 et sont dites dans la justification : la
myasthénie (cours 2023-24, p. 15 ; l'année ne dit que l'« activité sur la plaque
motrice » des anticholinestérasiques, partie 2, p. 5), l'intoxication aux
organophosphorés (FC 2025-26, p. 22) et la raison pour laquelle les
anticholinestérasiques ne baissent pas la pression artérielle (Katzung).

## Les clés qui ne sont pas reprises telles quelles

**Aucune clé imprimée n'est contestée** : les 22 clés ont été vérifiées
proposition par proposition contre la FC 2025-26, puis contre les deux ronéos
2026-27, qui n'en contredisent aucune ; `CONFLITS` est vide. Aucun errata (annales
BMCT, cours 2025-26, 2024-25, 2023-24) ne porte sur ce polycopié.

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2022/2023 Question n°2 a-d | aucune (« AUCUNE CORRECTION, vérifier le cours ») | versos déduits du cours, `officielle=False`, explication « Clé déduite du cours, absente de la table de corrections » | chaque réponse tient sur la partie 2, p. 3-6 ; la d) suit les cours 2023-24 et 2024-25 et le RCP, qui ne donnent que deux contre-indications (ATTENTION (prise de notes) sur la liste de l'année) |
| 2018/2019 QROC 1 | aucune | verso déduit du cours (partie 1, p. 4-12), illustré par le schéma légendé | idem |
| 2024/2025 S1 Q14 (`snv-an-2425s1-q14`) | aucune (sujet sans corrigé) | **CE**, `officielle=False` | 2022/2023 Q.10 mot pour mot, même clé (partie 1, p. 4-6, 10) |
| 2024/2025 S1 Q15 (`snv-an-2425s1-q15`) | aucune (sujet sans corrigé) | **AD**, `officielle=False` | 2020/2021 Q.8 mot pour mot, même clé (partie 1, p. 9, 12-13) |
| 2024/2025 S1 Q16 (`snv-an-2425s1-q16`) | aucune (sujet sans corrigé) | **BE**, `officielle=False` | antagoniste muscarinique : moins de péristaltisme et de sécrétions, tachycardie, sudation diminuée (partie 2, p. 5-6) |

Deux avertissements ordinaires (ATTENTION nu, la clé est juste) : le blocage
muscarinique et l'atropine qui « diminue la fréquence cardiaque » (faux, malgré
l'effet bradycardisant à faible dose de la partie 2, p. 6).

## Les erreurs du ronéo 2026-27

Le tableau d'erreurs BMCT de la promo ne porte rien sur ce cours au 19/10/2026 :
toutes les erreurs ci-dessous ont été trouvées en relisant, et vont dans
`contenu/ERRATA_RONEOS_2026-27.md`. Aucun ronéo n'est corrigé ; chaque erreur est
portée par une carte, avec son genre. À l'examen, on répond d'abord comme le
professeur. Toutes les erreurs de prise de notes de la partie 1 étaient déjà dans
le ronéo 2025-26, dont elle recopie le texte.

**Prises de notes fausses** (`ATTENTION (prise de notes)`) :

| Partie, page | Le ronéo dit | Ce qui est juste | Carte |
|---|---|---|---|
| 1, p. 7 | les médullosurrénales « vidées de leur contenu de noradrénaline » | d'adrénaline surtout : la même page dit la « libération massive d'adrénaline » ; diapositive 2025-26, adrénaline et noradrénaline 4:1 (FC 2025-26, p. 7) | `snv-qc-medullosurrenale` (C) |
| 1, p. 7 | la tyrosine hydroxylase « transforme la tyrosine en dopamine sous l'effet de la DOPA décarboxylase », puis la noradrénaline « sous l'effet de cette DOPA décarboxylase » | tyrosine → L-DOPA (TH) → dopamine (DDC) → noradrénaline (DβH) : la diapositive de la p. 8 | `snv-qc-synapse-adrenergique` (A), `snv-fa-synthese-na` |
| 1, p. 8 | le neurone à TH, DDC et DβH « va fabriquer de l'adrénaline » | de la noradrénaline (même ronéo, p. 7 ; diapositive p. 8, DA → NA) ; l'adrénaline demande la PNMT, celle de la médullosurrénale (Goodman & Gilman) | `snv-qc-synapse-adrenergique` (B) |
| 1, p. 10 | la choline acétyltransférase « qui permet de stocker l'acétylcholine dans des vésicules » | elle la synthétise (diapositive p. 10 : AcCoA + choline → ACh) ; un transporteur vésiculaire la stocke | `snv-qc-synapse-cholinergique` (A), `snv-qr-chat` |
| 1, p. 10 | « l'acylcholine estérase » ; l'acétylcholine « recapturée pour être stockée ou dénaturée par un auto récepteur » | l'acétylcholinestérase (AChE sur la diapositive) ; c'est la choline qui est recaptée ; l'autorécepteur freine la libération (p. 8) | `snv-qc-synapse-cholinergique` (B), `snv-qr-ache` |
| 1, p. 11 | récepteurs nicotiniques découverts chez un poisson « TORPI » | la torpille (*Torpedo*), que montre la diapositive de la même page | `snv-qc-relais-ganglionnaire` (C) |
| 1, p. 12 | la Gq des M3 « activée par la phosphorylase C » | la Gq active la phospholipase C (tableau et figure du même cours, FC 2025-26, p. 13 et 18) | `snv-qc-muscariniques` (E), `snv-fa-muscariniques` |
| 1, p. 12 | la copie grise du QCM 3 : A « VRAI » (bradycardie sympathique), B « FAUX » (myosis), réponse ACE | BCE, la réponse du professeur, sur la même page | `snv-qc-quiz3-effets` (A, B) ; marches `snv-ech-s5`, `snv-ech-s27`, `snv-ech-m3`, `snv-ech-m7` |
| 1, p. 12 | le muscle ciliaire, β2, dont la relaxation est « responsable de la dilatation » | la mydriase est le fait du dilatateur (diapositive de l'œil, partie 2, p. 3) ; le ciliaire règle l'accommodation | `snv-qc-oeil` (E), zone `ciliaire` de `snv-zo-oeil` ; marches `snv-ech-s21`, `snv-ech-m7` |
| 2, p. 6 | contre-indications de l'atropine : glaucome à angle fermé, hypertrophie prostatique, « troubles de l'accommodation », « rétentions urinaires », « confusion, convulsion, coma en cas d'intoxication », « sécheresse buccale désagréable » | deux contre-indications ; les quatre autres sont des effets indésirables, que la même page décrit plus haut, et les quatre « effets indésirables les plus communs » que le cours de 2024-25 donnait, dans le même ordre, après les deux contre-indications (Ronéosaure 2024-25, p. 18-19 ; Charonéo 2023-24, p. 18) ; la rétention urinaire n'est contre-indication que par le risque de l'hypertrophie prostatique (RCP d'Atropine Aguettant, 4.3 et 4.8) | `snv-qc-atropine-usage` (D), `snv-fa-atropine-indications`, `snv-an-2223-q2d`, `snv-an-2324-q14` (C) ; marches `snv-ech-s18`, `snv-ech-m5` |
| 2, p. 5 | la pilocarpine et l'acéclidine « synthétisés en labo » | la pilocarpine est un alcaloïde naturel du jaborandi (*Pilocarpus*), comme la même page le range ; l'acéclidine seule est de synthèse | `snv-qc-cholinomimetiques` (D) |
| 2, p. 5 (gris) | la belladone, « baie d'un arbre » | *Atropa belladonna*, plante herbacée vivace (Solanacées) ; la FC 2025-26 disait « la baie du cerisier des fous » (p. 22) | `snv-qr-belladone` |

**C'est le cours lui-même** (`ATTENTION (cours)`) : aucune erreur. La sudation
que la partie 1 donne aux récepteurs α1 de la peau (p. 13), un temps rangée ici,
n'en est pas une (relecture du 19/10) : la sueur localisée du stress passe par les
α1, la sudation généralisée par des fibres sympathiques cholinergiques (M3), d'où
l'atropine qui la diminue (partie 2, p. 6) ; les deux diapositives de 2025-26
portaient l'une et l'autre, « peau : α1, pilo-érection, sudation » et « peau :
sudation » (FC 2025-26, p. 15-16), comme le Goodman & Gilman (α1, sécrétion
localisée ; M3, généralisée). `snv-qc-quiz1-organisation` (D) le dit, sans
ATTENTION.

**Points douteux** (`ATTENTION (douteux)`), dits dans la carte sans changer sa clé :

| Partie, page | Le point | Carte |
|---|---|---|
| 2, p. 3 | « quand la pupille est très fermée, on peut voir très loin », dilatée « uniquement de près » (déjà en 2025-26, p. 19) : voir de près ou de loin, c'est l'accommodation ; une petite pupille accroît la profondeur de champ, et le myosis accompagne la vision de près | `snv-rv-myosis-mydriase` |
| 2, p. 6 | effets oculaires : « augmentation de la pression oculaire et sécrétion lacrymale » — l'atropine diminue les larmes (RCP d'Atropine Aguettant, 5.1) ; la même phrase est dans les cours de 2023-24 et 2024-25 (p. 17) : sans doute la diapositive, dont le sens reste incertain | `snv-qc-atropine-proprietes` (E) |
| 2, p. 6 | une « vasocontraction » parmi les effets cardiologiques : aux doses usuelles l'atropine agit peu sur les vaisseaux ; ses bouffées vasomotrices sont une vasodilatation (RCP, 4.8) ; le cours de 2023-24 en donnait la condition, « si vasodilatation induite par acétylcholine » (Charonéo, p. 17) | `snv-qc-atropine-proprietes` |
| 2, p. 5 | tropicamide et scopolamine, « durée des effets : environ 30 min / 1 h » — tropicamide : mydriase maximale en 15 min, environ 1 h 30, pupille normale en 5 à 8 h (Vidal) | `snv-qr-tropicamide` |

## Absent du cours 2026-27

Cinq cartes **entières** que les deux ronéos du 05/10/2026 ne portent plus. Elles
restent, citent la FC n°4 2025-26 (sans `page`, donc avec le badge « Cours
2025-26 »), prennent le tag `absent-2026` et la phrase « Absent du cours 2026-27 »
en tête de l'explication (`ABSENTS_2026`, `ORIGINE_ABSENTS`) :

| Carte | Ce que le cours 2026-27 ne dit plus |
|---|---|
| `snv-fa-organophosphores`, `snv-qc-organophosphores` | l'intoxication aux organophosphorés, la pralidoxime, l'atropine en injections répétées : le Pr Gautier passe les inhibiteurs de l'acétylcholinestérase |
| `snv-ech-s22`, `snv-ech-s26` | les deux marches de l'intoxication (l'atropine qui la traite, les convulsions et le coma) ; les annales qu'elles préparent restent |
| `snv-qr-ipratropium` | l'ipratropium : l'asthme reste parmi les indications, sans molécule |

Restent dans des cartes confirmées, dits dans leur justification : l'Alzheimer
déremboursé (`snv-qc-parasympathomimetiques` D), le « second neurone » 4:1 de la
médullosurrénale (`snv-qc-medullosurrenale` D), la guanylate cyclase, l'utérus
gravide, la contraction ciliaire pour l'accommodation.

## Les schémas et les figures

**Huit figures du ronéo 2026-27**, extraites en PNG à leur résolution d'origine,
déclarées dans `IMAGES` avec leur page et leur source : l'innervation viscérale
(partie 1, p. 5), le sympathique et le parasympathique (p. 6 et 10, réunis), le
relais ganglionnaire (p. 6), la synapse adrénergique (p. 8), les récepteurs
adrénergiques (p. 9), la synapse cholinergique (p. 10), les récepteurs
nicotiniques (p. 11), l'œil (partie 2, p. 3). Cinq étaient déjà dans la FC
2025-26 : l'image de l'année, plus nette, a remplacé l'ancienne sous le même nom.
**Sept figures de la FC 2025-26** restent, que l'année ne reproduit pas : SNC et
SNP (p. 3), médullosurrénale (p. 7), parasympathique (p. 11), récepteurs
cholinergiques (p. 12), muscariniques (p. 13), vaisseaux (p. 18), modulation
(p. 21).

**Deux schémas cliquables** (`schemas.py`), chacun avec sa version légendée :

| Fichier | Ce qu'on clique | Pourquoi ce dessin |
|---|---|---|
| `snv-organisation-synaptique.svg` | la chaîne paravertébrale ; les récepteurs du ganglion sympathique, de l'organe sympathique (α, β), de la médullosurrénale, du ganglion parasympathique, de l'organe parasympathique (M) — 6 zones | le QROC 1 de 2018/2019 ; d'après la partie 1, p. 6-7 et 9-11 ; préganglionnaire vert, postganglionnaire sympathique rouge et parasympathique bleu, comme sur les diapositives ; le parasympathique sacré est estompé, sans zone ; aucun nom écrit |
| `snv-oeil.svg` | le sphincter (M3, myosis), le dilatateur (α, mydriase), le muscle ciliaire (accommodation) — 3 zones | d'après la partie 2, p. 3 et 6 ; trois anneaux séparés par un jour ; libellés fonctionnels |

Et une figure de correction, **`snv-effets.svg`** : les effets sympathiques et
parasympathiques organe par organe, d'après la partie 1, p. 12-13, et la partie 2,
p. 2-3 ; l'utérus et le génital, des diapositives de 2025-26.

**88 QCM sur 89 illustrés (99 %)**, 115 notes sur 134. Le seul QCM sans figure,
`snv-qc-vocabulaire`, n'a rien à montrer que le texte ne dise.

## Le lexique

Douze termes, chacun avec son **origine grecque ou latine** ; pages mesurées dans
les deux ronéos 2026-27 par `scripts/chercher_pages.py` du skill (mot entier,
pluriel permis : le plan des p. 1-2 compte, « antimuscariniques » ne compte pas),
puis dans la FC 2025-26 :

| Terme | Origine | Pages 2026-27 |
|---|---|---|
| Myosis | grec μύω + -ωσις, « se fermer » | partie 1 p. 12, 13 ; partie 2 p. 3, 5 |
| Sympathomimétique | grec συμπάθεια + μιμητικός | partie 2 p. 2, 4, 6 |
| Parasympatholytique | grec παρά + συμπάθεια + λυτικός | partie 2 p. 1, 4, 5 |
| Muscarinique | latin musca | partie 1 p. 1, 10, 11 ; partie 2 p. 2-5 |
| Nicotinique | latin Nicotiana | partie 1 p. 1, 6, 7, 10, 11 ; partie 2 p. 4, 5 |
| Glaucome | grec γλαύκωμα, par le latin | partie 2 p. 5, 6 |
| Médullosurrénale | latin medulla + super + ren (racines : medulla, sur-, ren) | partie 1 p. 5, 7 |
| Orthosympathique | grec ὀρθός + συμπάθεια | partie 1 p. 3, 4, 6 |
| **Parasympathomimétique** (nouveau) | grec παρά + συμπάθεια + μιμητικός | partie 2 p. 1, 4 |
| **Sympatholytique** (nouveau) | grec συμπάθεια + λυτικός | partie 2 p. 2, 4, 7 |
| **Anticholinergique** (nouveau) | grec ἀντί + χολή + ἔργον, par cholinergique | partie 2 p. 5 |
| **Hyperhidrose** (nouveau) | grec ὑπέρ + ἵδρωσις | partie 2 p. 6 |

Les quatre termes nouveaux et une racine (`-hidrose (grec)`) sont proposés à la
table commune (`etymologies.json`) dans `scratchpad/etym/bmct_snv.json`, vérifiés
sur le Wiktionnaire et le CNRTL ; les textes du lexique sont déjà écrits dans la
forme que `appliquer_etymologies.py` produirait. Les autres racines sont celles
de la table (`anti-`, `chol(é)-`, `ergon (grec)`, `hyper-`, `para- (grec)`,
`syn- (grec)`, `-pathie`, `-mimétique`, `-lyse`). `mydriase` existe déjà ailleurs
(`lex-mydriase`) et n'est pas repris.

## La contre-relecture du 19/10/2026

Un second lecteur a repris chaque carte nouvelle ou changée contre la page du
ronéo 2026-27 qu'elle cite et son image, chaque clé d'annale, et chaque erreur
relevée. Ce qu'il a changé :

- **La sudation n'est plus une erreur du cours** : l'`ATTENTION (cours)` de
  `snv-qc-quiz1-organisation` (D) est retiré (voir « Les erreurs du ronéo »).
  Les diapositives « Activation adrénergique » et « Activation cholinergique »
  de 2025-26, agrandies, portent « peau : α1, pilo-érection, sudation » et
  « peau : sudation ».
- **Les contre-indications de l'atropine** : la preuve de la prise de notes est
  plus forte (les quatre lignes de trop sont, dans l'ordre, les quatre effets
  indésirables du cours de 2024-25), et la rétention urinaire est nuancée — elle
  n'est contre-indication que par le risque de l'hypertrophie prostatique.
- **Les deux points douteux de l'atropine** (larmes, « vasocontraction »)
  citent les cours de 2023-24 et 2024-25, qui portaient déjà ces phrases ; le
  second y avait sa condition (« si vasodilatation induite par acétylcholine »).
- **Ajouts** : les réponses « opposées dans 90 % des cas » (partie 1, p. 6), dans
  `snv-qc-dualite-vaisseaux` ; la ligne « Tropicamide et Scopolamine » des
  dérivés synthétiques, lue comme un usage et non une origine
  (`snv-qc-parasympatholytiques` C) ; la racine `sur-` de la médullosurrénale.
- **Le lexique** suit `chercher_pages.py` à la lettre (six termes : le plan des
  p. 1-2 compte ; la p. 6 de « muscarinique », qui n'avait que
  « antimuscariniques », sort).

## Décisions prises en route

- **`EXAMENS` n'est pas déclaré**, comme dans les autres chapitres de BMCT.
- **`semaine` vaut « 05/10/2026 · Pr Gautier »**, comme les deux en-têtes.
- **Les QCM du professeur sont `officielle=True`** : leur clé est celle du
  ronéo, réponse du professeur ; les quatre sont les mêmes qu'en 2025-26.
- **Les figures identiques** sont celles de l'année, plus nettes ; les sept
  figures de 2025-26 que l'année ne reproduit pas restent, la légende citant la
  FC 2025-26.
- **Une carte n'est confirmée que si sa notion centrale est dans le cours de
  l'année** : les anticholinestérasiques accumulés (marches s23 à s25) le sont,
  par les effets de l'activation parasympathique (partie 1, p. 13) ; leur
  intoxication et son traitement (s22, s26) ne le sont pas.

## À relire

**Aucune carte `a-relire`** : chaque note de cours cite une page de l'une des
deux parties du ronéo 2026-27 ou, pour les absentes, de la FC 2025-26, et les
versos des rédactionnelles tiennent sur des pages entières.

## L'échelle : Simple → Moyen → Annale (C20, 16/10/2026 ; relue le 19/10)

L'échelle du pilote de l'immunité innée, étendue à la BMCT pour l'examen du 4/11.
Sous les annales, 29 cartes Simple (`niveau-simple`, une idée, trois choix, le
schéma troué dans la question) et 7 cartes Moyen (`niveau-moyen`, une paire à ne
pas confondre, le schéma à lettres en correction). Chaque annale garde la figure
du cours et reçoit son schéma (`diagramme=`) ; les QROC reçoivent le schéma nu.

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `organisation-snv` | 4 | 2 | 8 |
| `synapse-adrenergique` | 5 | 1 | 4 |
| `pupille` | 1 | 1 | 1 |
| `modulation-snv` | 19 | 3 | 17 |

**Le schéma** `ech-snv`, « Le système nerveux végétatif · des neurones aux
médicaments », donne 62 fichiers (complet, troués, à lettres). Il est décrit dans
`schemas.py` (`ECH_SNV`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`,
copie exacte du modèle du skill ; sa légende cite les pages de l'année.

**Relue le 19/10/2026 sur le ronéo 2026-27** : chaque marche cite sa page de
l'année, sauf s22 et s26, absentes. Trois retouches du schéma, cohérentes avec
leurs cartes : la ligne « peau : sudation ↓ » dans la case de l'atropine (la case
grandit, celle des contre-indications descend), qui porte le trou de la marche
nouvelle s29 ; la case « Contre l'hypertension » dit « les antagonistes α » au
lieu de « méthyldopa, clonidine », que le cours dit désormais peu efficaces ; la
légende. Les clés des marches Simple se répartissent 9 A, 10 B, 10 C ; les Moyen
ont une à trois vraies.

**Sans marche** :
- snv-an-2223-q11 B, snv-an-1920s2-q13 B, snv-an-1617-q11 B (la myasthénie) : ni
  le cours 2026-27 ni la FC 2025-26 ; seul le cours 2023-24 (Charonéo, p. 15),
  que le chapitre ne déclare pas comme source, la donne. La lettre est posée sur
  la case des anticholinestérasiques.
- snv-an-2223-q11 D, snv-an-1920s2-q13 D, snv-an-1617-q11 D (les
  anticholinestérasiques et la pression artérielle) : la raison de la clé (des
  vaisseaux presque sans innervation cholinergique) vient du Katzung et d'aucun
  cours. La lettre est posée sur la case « Contre l'hypertension ».

**La figure du cours dans la correction** (pilote du 19/10/2026, *demande de
Vincent*). Une marche dont le fait se lit sur une figure du chapitre la montre
après son schéma. Le schéma passe en `diagramme`, la figure en `illustration`,
avec sa légende (`_LEGENDE_FIGURE`), et l'énoncé ne change pas. Trois
apparieurs ont ouvert chaque figure et chaque page des deux ronéos, puis trois
sceptiques ont refait chaque choix sans en changer aucun. Résultat : 18
marches sur 36 ont leur figure, aucune nouvelle.
- s1, s2, s3, s4, s6, s10, s13, s14, s16, s18, s20, s27, s28 ;
- m1, m2, m3, m4, m7.

Trois figures viennent de la FC 2025-26 (s1, s3, s4) : la ronéo de l'année n'a
pas de diapositive pour ces faits, et son texte les confirme. Les 18 autres
marches gardent leur schéma seul. Leurs faits (les effets de l'activation selon
l'organe, l'atropine, les organophosphorés) ne sont qu'en texte dans la ronéo
2026-27 (partie 1, p. 12-13 ; partie 2, p. 2 et 4-7). Les diapositives
« Activation adrénergique » et « Activation cholinergique » de la FC 2025-26
(p. 15-16) existent, mais leur capture fait 639 × 356 px pour un tableau de
vingt lignes : elle est illisible à la largeur d'une carte. Il faudrait les
redessiner. Les deux ronéos n'ont pas d'autre diapositive que celles déjà dans
`media/`. Aucune figure retenue ne contredit sa carte.

## Régénérer

```powershell
..\..\..\app\.venv\Scripts\python.exe generer.py
```

## Questions pour Vincent

- (19/10, contre-relecture) Les larmes sous atropine : trois années de cours
  écrivent « augmentation de la pression oculaire et sécrétion lacrymale »
  (2023-24, 2024-25, 2026-27), sans doute la phrase de la diapositive. La carte
  `snv-qc-atropine-proprietes` (E) répond « diminue » avec le RCP, en point
  douteux. Si le Pr Gautier pose « l'atropine augmente la sécrétion lacrymale »,
  quelle réponse veux-tu réviser ?
- (19/10) L'effet « bradycardisant à faible dose » de l'atropine (partie 2,
  p. 6) : les annales du Pr Deplanque donnent « le blocage muscarinique diminue
  la fréquence cardiaque » faux dans six sessions, et les cartes gardent cette
  clé. Le Pr Gautier interroge-t-il ce paradoxe ?
- (19/10) Les anticholinestérasiques et les organophosphorés, « pas importants »
  pour le Pr Gautier, restent interrogés par cinq annales du Pr Deplanque : les
  cinq cartes absentes et les annales restent dans le chapitre. Faut-il les
  sortir des révisions avant le partiel ?
- (19/10) Le sujet 2024/2025 nomme deux auteurs pour la BMCT (QR1 du Pr
  Deplanque, QR2 du Pr Gautier) : les questions de cette année sur ce cours
  seront-elles du Pr Gautier ?
