# Sémantique médicale — paquet d'exemple

65 notes, 196 cartes. C'est le chapitre le plus dense et le moins clinique du
dépôt : pas de malade, pas d'examen, plus d'une centaine de radicaux grecs et
latins. C'est aussi celui qui conditionne tous les autres.

## La base : le ronéo 2026-27

Le cours du **10/09/2026, Pr Aubert-Baillot** (deux heures, 8 h et 10 h), dans
le ronéo Ronéo & Juliette 2026-27, **versions définitives** : partie 1 en
10 pages (`src-fc-semio-semantique-1`), partie 2 en 12 pages
(`src-fc-semio-semantique-2`). Le professeur a changé : c'était le Pr Hecquet en
2023-24 et 2024-25, avec un autre plan.

Le chapitre avait été bâti sur les versions **provisoires** (9 + 9 pages, la
partie 2 inachevée). Il a été relu note par note sur les définitives le
25/09/2026 : toute note de cours relue porte la page où le ronéo l'enseigne
(`page`, et `fiche` pour la partie 2) et cite cette page dans l'application.
Les deux notes qui n'en portent pas citent encore la version provisoire,
gardée dans `SOURCES` avec son année.

Ces deux ronéos n'ont ni gris ni rouge. Le seul code annoncé est le gras des
« modifications apportées » (plan de la partie 2), qui ne se distingue pas du
gras des en-têtes : tout a donc été relu, sans tri.

## Ce qui a changé le 25/09/2026

- **Neuf notes nouvelles**, pour ce que les définitives enseignent et qu'aucune
  carte ne couvrait : `sem-fa-cessation` (-pause, crin-, lapsus, -leptique),
  `sem-fa-patho` (pathognomonique, pathomimie, tératogène, agénésie,
  parthénogenèse), et toute la première moitié de la partie 2 —
  `sem-fa-fixation` (-synthèse, -rraphie, -pexie, -dèse, -ectomie, -tomie),
  `sem-fa-separation` (-ectasie, sciss-, schiz-, hiat-, -prive, -pénie),
  `sem-fa-ecartement` (ab-, dis-, -fuge contre ad-, -pète, -trope, -fère),
  `sem-fa-extremite` (acr(o)-, radic-, rhiz-, caud-, sept-, pariét-) —, puis
  `sem-fa-couleur` (-chrome, hyal-, topo-), `sem-fa-obscurite` (nyct-, scot-)
  et `sem-fa-isoles` (acu-, méga-, claustr-, ultra-, éco-).
- **Réécrit contre le ronéo** : la racine du menton est `gen-` (et non
  « géni- »), le genou `gon- / gony-`, avec gonarthrite pour exemple
  (`sem-fa-generation`, `sem-pi-homonymes` D) ; lepto- est « léger » et pycn-
  « épais » (`sem-fa-taille`) ; -rrhagie reprend son h (`sem-fa-ecoulement`).
- **Des explications qui attribuaient au cours ce qu'il ne dit pas** : « le
  cours prévient qu'il faut connaître les mots » (-gène), « le cours prévient
  que la correction sanctionne le radical mal écrit » (2025/2026 QCM 17).
- **Des comptes d'annales faux** : leuc- n'est tombé dans aucune annale cartée
  (trois couleurs et non quatre), axénique est tombé deux fois et non trois, la série
  ultième / pénultième n'est pas tombée entière, trois pièges de `sem-pi-lettres`
  et non quatre (deux tels quels, et cyt- en 2023/2024), et « haplo- vrai » date
  de 2022/2023, pas de 2021/2022.
- **Relecture du même jour** : une erreur du ronéo que les cartes reprenaient en
  silence, l'achalasie (ATTENTION dans `sem-fa-chute` et 2018/2019 Q3 D) ; et
  quatre explications d'annales qui prêtaient encore au cours ce qu'il ne dit
  pas (brady-, le sens « retard » d'ops-, la règle d'orthographe) ou qui se
  trompaient d'item (2018/2019 Q1).
- **Les conflits d'annales** citent la page du ronéo 2026-27, et l'ATTENTION dit
  le désaccord (revus le 26/09/2026, voir « Les clés non reprises telles
  quelles »).
- Semaine du chapitre : « 10/09/2026 · Pr Aubert-Baillot ».

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| Texte à trous | 26 | 141 |
| QRM | 27 | 27 |
| Repérage sur schéma | 2 | 18 |
| QROC | 4 | 4 |
| Recto-verso | 2 | 2 |
| Lexique | 4 | 4 |

Sur les 27 QRM, **23 sont des annales** : 21 du polycopié (neuf sessions, de
2017/2018 à 2023/2024), avec la clé de sa table de corrections, et 2 du sujet
2025/2026. Les deux questions de 2023/2024 ont été relues le 15/10/2026 sur le
sujet original et son corrigé officiel : Q10 confirmée, Q11 réalignée sur
l'énoncé imprimé et la clé officielle (voir « Les clés non reprises telles
quelles »).

## Trois partis pris

**Une note par famille, un trou par radical.** Les radicaux ne sont pas récités
un à un : chaque famille est un texte à trous, et la famille entière reste
lisible pendant qu'on comble un trou. C'est le contexte qui fait tenir le mot.
Aucun trou ne dépasse deux mots — au-delà, la saisie serait refusée pour une
virgule, et un test le vérifie.

**Les deux familles non verbales deviennent des schémas cliquables.** Les
préfixes de position désignent un endroit : on le montre. Les radicaux de
couleur sont des couleurs : on clique la bonne pastille.

- `positions.svg` — un organe de référence, la limite du corps. Six zones :
  dedans, autour, au-dessus, au-dessous, à côté, dehors. La zone « autour » est
  un **anneau**, une forme qui contient son pourtour et pas son trou.
- `couleurs.svg` — douze pastilles, sans un mot. « Quelle couleur désigne le
  radical xanth- ? »

**Les pièges ont leurs propres cartes.** Ce sont eux qui font les points :
cysto- ≠ cyto-, -stase ≠ -stasie, -physe ≠ -phyte, dys- grec ≠ dis- latin,
ops- la vue ≠ ops- le retard, -algie = -odynie.

## La règle que les annales enseignent et que le cours tait

Sur les neuf sessions du polycopié, quatre donnent **faux** à six radicaux mal
orthographiés dont le sens proposé est pourtant le bon ; le corrigé officiel
2023-24 en ajoute un septième, que le polycopié avait effacé en recopiant
« polio- » :

| Proposé | Correction | Le vrai radical |
|---|---|---|
| polyo- = gris | faux (corrigé officiel 2023-24) | polio- |
| antrac- = noir | faux | anthrac- |
| nictémère = nuit et jour | faux | nycthémère |
| -condre = cartilage | faux | chondr- |
| pirhét- = fièvre | faux | pyrét- |
| dy- = deux | faux | di- |
| aplo- = simple | faux | haplo- |

La preuve tient en deux sessions : « haplo- signifie simple » est **vrai** en
2022/2023, « aplo- signifie simple » est **faux** en 2018/2019. Même définition,
un h en moins, réponse opposée. La carte `sem-rv-orthographe` énonce la règle.

## Ce que le polycopié d'annales ne permet pas de reconstituer

- **La numérotation de la table de corrections ne suit pas celle des énoncés** :
  décalage de +2 en 2022/2023, Q.17 à Q.19 pour les questions 1 à 3 de
  2018/2019, et les quatre questions de 2019/2020 corrigées sous deux colonnes
  de sessions différentes. Le rapprochement est fait par position, puis vérifié
  item par item : partout où le contenu tranche, la clé tombe juste — à un
  item près dans deux questions, où les quatre autres items confirment le
  rapprochement (-esthésie, poliomyélite : voir « Les clés non reprises telles
  quelles »).
- **Une correction de plus qu'il n'y a d'énoncés** : 2017/2018 Q.6 « ACD », dont
  la question est absente du document. Aucune carte n'a été inventée pour elle.
- **2022/2023 Q2 est imprimée avec six items** parce qu'un retour à la ligne
  coupe une proposition en deux. Les morceaux sont recollés, ce qui redonne cinq
  items et rend la clé « AD » cohérente.
- La colonne « 2021/2022S2 » correspond aux énoncés titrés « Année 2021/2022 ».

## Les clés non reprises telles quelles

**La clé retenue est la bonne, pas la clé imprimée** (règle de Vincent,
26/09/2026) : celle du cours de l'année, ou celle de l'analyse vérifiée sur des
sources sûres quand le cours se trompe. Six propositions opposent la clé
imprimée et le ronéo 2026-27 ; toutes sont déclarées dans `CONFLITS` et dites
par `ATTENTION` dans la justification de l'item, et le générateur refuse
d'écrire si l'une perd son avertissement. Revu le 26/09/2026 (tâche C7).

Deux clés imprimées ne sont pas bonnes. La carte retient la bonne et n'est
plus officielle :

| Question | Item | Clé imprimée | Retenu | Pourquoi | Source |
|---|---|---|---|---|---|
| 2019/2020 Q2 | B | DE (-esthésie ≠ « sensation ») | BDE (B vrai) | -esthésie vient d'aisthêsis, la sensation ; le ronéo l'emploie pour la sensibilité (« hypersthésie [sic] », 2/2 p. 9), la fiche de révision dit « sensation » | dictionnaire Larousse, « esthésie » |
| 2017/2018 S2 Q6 | B | E (la poliomyélite ne toucherait pas le système nerveux) | BE (B vrai) | « inflammation de la substance grise de la moelle épinière » (2/2 p. 8) : la moelle est le système nerveux central | OMS, aide-mémoire « Poliomyélite » |

**Le sujet 2023-24 original et son corrigé officiel** (dépôt du 15/10/2026)
confirment Q10 (`sem-an-2324-q10`, CE : clé confirmée par le corrigé officiel
2023-24, dépôt du 15/10/2026) et corrigent Q11. Le polycopié avait recopié
l'énoncé en le réparant — « polio- » et « Vésiculeur » là où le sujet imprime
« **polyo-** » et « **Vésiculeux** » — et imprimait ABC. La carte reprend
l'énoncé du sujet, tel qu'imprimé, et la clé officielle ; elle reste
officielle, `CONFLITS` sur A :

| Question | Item | Clé du polycopié | Corrigé officiel (retenu) | Pourquoi |
|---|---|---|---|---|
| 2023/2024 Q11 (`sem-an-2324-q11`) | A | ABC (A vrai, sur « polio- ») | **BC** (A faux) | le sujet imprime « polyo- » : le radical du gris s'écrit polio- (2/2 p. 8, poliomyélite ; grec πολιός), et une lettre changée rend la proposition fausse, comme antrac- en D — la règle que les annales enseignent (section du même nom) |

Quatre fois, c'est le ronéo 2026-27 qui se trompe ou se tait. La clé imprimée
est gardée, officielle, et l'ATTENTION dit l'erreur du cours. La liste des
erreurs (`contenu/ERRATA_RONEOS_2026-27.md`) range ces deux passages, la
dysenterie et opsi-, parmi les **points douteux** : leurs ATTENTION portent
« (douteux) », comme celui de `lex-dysenterie` (C11, 28/09/2026).

| Question | Item | Clé imprimée (gardée) | Le ronéo 2026-27 dit | Pourquoi la clé tient | Source |
|---|---|---|---|---|---|
| 2017/2018 Q5 | A | faux : la dysenterie n'est pas « un trouble du fonctionnement intestinal » | « dysenterie : trouble du fonctionnement intestinal » (2/2 p. 6) | c'est la traduction de dys- + entér-, pas la définition : la dysenterie est un syndrome glairo-sanglant | Larousse médical ; Dictionnaire de l'Académie française |
| 2022/2023 S2 Q2 | A | faux : opsigène n'est pas « qui génère la vision » | « opsi- / opti- : vue » (2/2 p. 7) | opsi- vient d'opsé, tard : opsigène, qui se forme tard ; le ronéo lui prête le sens du suffixe -opsie | dictionnaire-medical.net, « opsigène » ; Larousse médical, « opsiurie » |
| 2019/2020 S2 Q4 | C | vrai : opsi- signifie « tardivement » | idem | idem | idem |
| 2018/2019 Q3 | C | vrai : ops- signifie « en retard » | idem | la graphie porte deux sens, le retard (opsé) et la vue (opsis) ; le ronéo ne donne que le second, sans nier le premier | idem |

`sem-pi-homonymes` A, dans `donnees.py`, retient les deux sens d'ops-, et le
dit par ATTENTION.

## Erreurs du ronéo 2026-27

Le tableau d'erreurs de la promo en relève trois : « cystopathie » pour
cytopathie (version du 28/09/2026), l'achalasie (03/10) et « onychoptose :
chute de singles » pour chute des ongles (11/10) ; les ATTENTION de leurs
cartes le disent. Les autres ont été trouvées à la relecture. Les cours ne seront pas
modifiés, et les cartes ne les reprennent jamais telles qu'imprimées. Les
erreurs de fond sont aussi dans `contenu/ERRATA_RONEOS_2026-27.md`.

**Tri du 28/09/2026** (règle de Vincent : à l'examen, on répond d'abord comme
le professeur). Les racines rangées dans la mauvaise colonne de la partie 2 —
hiat-, dextr(o)-, lévo-, acu-, extra-, et l'exemple exfoliation d'ex- / ec- —
ne sont pas des prises de notes : **c'est le cours lui-même**, le support de la
Pr Aubert-Baillot, que le ronéo reproduit (la fiche de révision, § 12, les note
« classé grec » dans le support, relevés en plus et non corrigés en cours).
Leurs ATTENTION le disent, puis « À l'examen : » — les annales n'interrogent
que le sens ; si la langue l'est, répondre comme le support, grec : la
professeure a corrigé en cours réti- et atr(a)-, rangés en grec eux aussi, mais
pas celles-ci —, puis « La référence : », la vraie étymologie, latine.
« Subfébrile : légère hypothermie », lui, est une **prise de notes fausse** : la
coquille est dans le support, et déjà dans le Charonéo 2023-24, mais la
professeure l'a corrigée en cours cette année (§ 12, « Noté en cours »), et le
ronéo ne l'a pas reportée.

**Le genre dans la carte** (C11, 28/09/2026). Chaque ATTENTION de ce tableau
écrit son genre juste après le mot, celui de la section de la liste des
erreurs : « (cours) » pour hiat-, dextr(o)-, lévo-, acu-, extra- et ex- / ec- ;
« (prise de notes) » pour -rrhée, kinés(i)-, l'onychoptose (tableau de la promo,
11/10), l'achalasie, la cystopathie, atr(a)- (que la professeure a corrigé en
cours) et subfébrile ; « (douteux) » pour la dysenterie, opsi- et « -stase : debout », que rien ne tranche — στάσις
porte les deux sens, et seul l'usage les sépare. La correction dessine chacun
dans son encadré.

| Page | Imprimé | À lire | Carte qui le dit |
|---|---|---|---|
| 1/2 p. 2 | « pantalon rhei » | panta rhei | `sem-fa-ecoulement` (ATTENTION) |
| 1/2 p. 2 | « -rrhée (LATIN : rrhéo) » | ῥέω (rhéō), couler, est grec | `sem-fa-ecoulement` (ATTENTION) |
| 1/2 p. 2 | « kinés(i)- (LATIN : kinesis) » | κίνησις (kínēsis) est grec | `sem-fa-mouvement` (ATTENTION) |
| 1/2 p. 3 | « onychoptose : chute de singles » — **tableau de la promo, 11/10** | chute des ongles (la même case : « onych- / onyx : ongle » ; Littré) | `sem-qr-ptose` (ATTENTION) |
| 1/2 p. 4 | « achalasie : relâchement des sphincters » — **tableau de la promo, 03/10** | DÉFAUT de relâchement (a- privatif) | `sem-fa-chute`, 2018/2019 Q3 D (ATTENTION) |
| 1/2 p. 6 | « hom-, homo-, homéo- : semblable » | homo- le même, homéo- similaire (2/2 p. 5) | `sem-fa-egalite` (ATTENTION) |
| 1/2 p. 8 | « cystopathie : maladie de la cellule » | cytopathie | `sem-fa-cellules`, `sem-pi-lettres` A (ATTENTION) |
| 1/2 p. 10 | « Salping(o) : trompe droite » | salping(o)- : la trompe utérine, droite ou gauche (2/2 p. 3). Point douteux (relu le 28/09) : σάλπιγξ est la trompette de guerre, un instrument droit, et « trompe droite » peut décrire l'instrument | aucune carte ne le reprend |
| 2/2 p. 3 | hiat- dans la colonne « Grec » — **c'est le cours lui-même** (le support, fiche § 12) | hiatus est latin (hiare) ; à l'examen, le sens, et grec comme le support si la langue est demandée | `sem-fa-separation` (ATTENTION) |
| 2/2 p. 5 | dextr(o)- et lévo- dans la colonne « Grec » — **c'est le cours lui-même** (le support, fiche § 12) | dexter et laevus sont latins ; à l'examen, le sens, et grec comme le support si la langue est demandée | `sem-fa-normal`, `sem-rv-lateralite` (ATTENTION) |
| 2/2 p. 5 | acu- dans la colonne « Grec » — **c'est le cours lui-même** (le support, fiche § 12) | acutus est latin ; à l'examen, le sens, et grec comme le support si la langue est demandée | `sem-fa-isoles` (ATTENTION) |
| 2/2 p. 6 | « dysenterie : trouble du fonctionnement intestinal » | un syndrome : selles glaireuses et sanglantes ; la phrase n'est que la traduction | 2017/2018 Q5 A (ATTENTION), `lex-dysenterie` |
| 2/2 p. 7 | « opsi- / opti- : vue » | -opsie (opsis) : la vue ; opsi- (opsé) : tard | 2022/2023 S2 Q2 A, 2019/2020 S2 Q4 C, 2018/2019 Q3 C, `sem-pi-homonymes` A (ATTENTION) |
| 2/2 p. 7 | atr(a)- dans la colonne « Grec » | ater est latin (atra bilis) | `sem-zo-couleurs` (ATTENTION) |
| 2/2 p. 8 | ex- / ec- en grec, avec exfoliation pour exemple — **c'est le cours lui-même** (le support, que la fiche reprend) | ec-, ex- existent en grec (eczéma), mais exfoliation est latin (exfoliare) ; à l'examen, le sens, et grec comme le support si la langue est demandée | `sem-zo-positions` (ATTENTION) |
| 2/2 p. 9 | extra- dans la colonne « Grec » — **c'est le cours lui-même** (le support, fiche § 12) | extra est latin ; à l'examen, le sens, et grec comme le support si la langue est demandée | `sem-zo-positions` (ATTENTION) |
| 2/2 p. 9 | « hypersthésie » | hyperesthésie | `sem-an-1920-q2` B (ATTENTION) |
| 2/2 p. 9 | « subfébrile : légère hypothermie » — **prise de notes fausse** : coquille du support, déjà dans le Charonéo 2023-24, corrigée par la professeure en cours (fiche § 12, « Noté en cours ») | légère HYPERthermie — déjà corrigé par l'errata Charonéo 2023-24 | `sem-zo-positions` (ATTENTION) |
| 2/2 p. 11 | « -stase : debout » | -stasie : debout ; -stase : arrêt | `sem-fa-station`, `sem-pi-lettres` B (ATTENTION) |
| 2/2 p. 12 | « scotum » | scotome — déjà corrigé par l'errata Charonéo 2023-24 | `sem-fa-obscurite` (ATTENTION) |

« (Jumeaux) homozygotes … = vrais jumeaux » (2/2 p. 5) n'en est pas une non
plus, contrairement à ce que ce tableau disait avant le 28/09 : le dictionnaire
de l'Académie nationale de médecine donne « jumeau homozygote » pour synonyme de
jumeau monozygote, ou vrai jumeau. Monozygote reste le terme courant ;
homozygote désigne aussi, en génétique, deux allèles identiques.

« Cholostase » (1/2 p. 2) n'est pas une erreur : la professeure de 2023-24 le
prononçait déjà ainsi, et l'errata du Charonéo notait que les deux graphies
existent. `sem-fa-mouvement` garde celle du ronéo et cite cholestase.

## Origine des racines

Tâche C9 (26/09/2026), demandée par Vincent pour mieux comprendre : chaque carte
qui enseigne une racine finit son explication par « Origine : », racine par
racine, dans la forme « dys- : du grec δυσ- (dus-), difficulté, mauvais état ».
Le mot grec est écrit en lettres grecques accentuées, suivi de sa
translittération ; le mot latin tel qu'il s'écrit. Quand l'origine est l'objet
même d'une proposition (dys- grec contre dis- latin, noci- contre noso-, les
deux ops-, aur(i)- et auri-, gon- et gen-), sa justification la dit aussi :
38 explications et 5 justifications. Aucune question, réponse, clé ni
identifiant n'a changé ; le `LEXIQUE` reçoit ses origines ailleurs, par script.

- **Les sources.** Le ronéo donne la langue et quelques mots (mên, cholê,
  gonos, klasis…), pas plus. Les mots grecs et latins viennent du TLFi
  (cnrtl.fr), du Bailly et du Gaffiot (par Logeion), du Wiktionnaire et du
  Littré, vérifiés un à un, et de la table des racines du lexique vérifiée pour
  la même tâche. Ce qu'aucune de ces sources ne donnait n'a pas été écrit.
- **Un grec, deux racines.** -stase et -stasie viennent toutes deux de στάσις,
  qui dit la station comme l'arrêt ; -physe et -phyte, de φύω. C'est l'usage
  médical qui les sépare, et les cartes le disent. Le TLFi tire -gène de γεννᾶν
  (engendrer), Littré de -γενής (engendré) : la racine ne tranche pas entre
  actif et passif.
- **La langue du ronéo, relue sur la page.** Les colonnes Grec / Latin de la
  partie 2 ne passent pas dans le texte extrait : elles ont été lues sur le rendu
  des pages. Huit racines sont dans la mauvaise langue — -rrhée et kinés(i)-
  étiquetées « LATIN » en partie 1, hiat-, dextr(o)-, lévo-, acu-, atr(a)- et
  extra- dans la colonne grecque en partie 2 —, et l'exemple d'ex- / ec-,
  exfoliation, est latin. Chaque carte concernée le dit par une ATTENTION qui
  donne les deux lectures, retient l'étymologie et cite sa source (tableau
  ci-dessus) ; pour les racines de la partie 2 que le support de la
  professeure range déjà en grec, l'ATTENTION dit que c'est le cours lui-même,
  qu'à l'examen on répond comme le support, et donne l'étymologie pour
  référence (tri du 28/09/2026). stat-, rangé en latin, l'est à bon droit
  (stare) ; statique, son exemple, vient du grec στατικός, et `sem-fa-station`
  le précise.

## Absent du cours 2026-27

Gardé, parce que rien dans le ronéo ne le contredit. À Vincent de décider.

- `sem-pi-orthographe` et `sem-rv-orthographe` : la règle de l'orthographe du
  radical vient des annales, et le cours ne l'énonce pas. Ces deux notes citent
  encore la version provisoire.
- Dans des notes relues, quelques éléments ne sont pas dans le ronéo :
  noso- (`sem-pi-lettres` E, un leurre), le sens « retard » d'ops- / opsi-
  (`sem-pi-homonymes` A, voir plus haut), Héraclite (`sem-fa-ecoulement`), et
  les mots grecs et latins d'où viennent les racines (voir « Origine des
  racines »). La langue elle-même, que les cartes prêtent à dys- et dis-, méso-
  et méd-, -ole / -ule, luc(i)- et radi-, a été relue le 26/09/2026 sur les
  colonnes Grec / Latin de la partie 2 : le ronéo dit la même chose.
- La plupart des mots des annales — fétor, stridor, térébrant, ténesme,
  hircine… — ne sont dans aucun des deux ronéos : c'est la nature de l'épreuve,
  qui interroge des mots formés sur les radicaux du cours.

## Sans illustration

Aucun des 27 QRM n'est illustré, et le chapitre ne peut pas atteindre la
moitié. La sémantique est une liste de radicaux : le ronéo n'a que des
tableaux, sans une figure, et une question sur le sens d'un mot n'a pas de
schéma à attacher à sa correction. Les deux familles qui se dessinent — les
positions et les couleurs — le sont déjà, en schémas cliquables
(`sem-zo-positions`, `sem-zo-couleurs`) ; attacher ces schémas nus à un QRM
n'apprendrait rien.


## L'échelle : Simple → Moyen → Annale (C20, 16/10/2026)

L'échelle du pilote de l'immunité innée, étendue à la sémiologie pour l'examen du 4/11 (Vincent, 16/10 : « on continue pour les chapitres que je vais avoir à l'examen »). Sous les annales, 42 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 10 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`).

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `pieges` | 16 | 4 | 8 |
| `mots` | 26 | 6 | 15 |

**Le schéma** `ech-semantique`, « Sémantique médicale · le radical fait le sens », donne 76 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_SEMANTIQUE`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

Les annales ne portent sur le tableau que les lettres dont le radical est au cours ; les 63 autres (liste ci-dessous, « Sans marche ») restent sans lettre, le ronéo 2026-27 ne les enseignant pas.

**Sans marche** :
- sem-an-2324-q10 A, D, E : fétor, possisymptomatique (pauci-) et cingulaire ne sont dans aucun des deux ronéos 2026-27.
- sem-an-2324-q11 C : vésiculeux n'est pas défini dans le ronéo, qui n'emploie « vésiculeuse » que dans la définition de l'eczéma (2/2 p. 8).
- sem-an-2223-q1 B, C, D : pauci-, erratique et gémination sont absents du ronéo 2026-27.
- sem-an-2223-q2 C, D, E : le syndrome d'enfermement (efférentation motrice), chym- et striction sont absents du ronéo ; afférent (2/2 p. 4) ne tranche pas C.
- sem-an-2223-q3 A, B, D, E : ténesme, tympanisme, haplo- et épreinte sont absents du ronéo 2026-27.
- sem-an-2223s2-q2 A, B, E : A se joue sur le sens « tard » d'opsi-, que le ronéo ne donne pas (« opsi- / opti- : vue », 2/2 p. 7, point douteux de CONFLITS) — une marche tirée du cours enseignerait contre la clé ; l'ATTENTION de sem-ech-s28 le signale, et la lettre est posée sur la case Couleurs. ambo- et axillaire sont absents du ronéo.
- sem-an-2223s2-q3 B, C, D, E : térébrant, brady- (et brachy-), stertoreux et hircine sont absents du ronéo 2026-27.
- sem-an-2122-q1 A, B, C : nidoreux, érosif et mordicant sont absents du ronéo 2026-27.
- sem-an-2122-q2 B, C, D, E : striction, tangible, stridor et tact grossier sont absents du ronéo 2026-27.
- sem-an-2122-q3 B, C, E : prurit, constrictif et pongitif sont absents du ronéo 2026-27.
- sem-an-2122-q4 A, D, E : borborygme, térébrant et tormineux sont absents du ronéo 2026-27.
- sem-an-1920-q1 B, D, E : vulnologie, panacée et anancurésie sont absents du ronéo 2026-27.
- sem-an-1920s2-q3 A, B, D : morbidité (le ronéo emploie « morbide » sans le définir), vésic- et typhl- sont absents du ronéo ; cysto-, la vessie, y est, pas vésic-.
- sem-an-1920s2-q4 A, C, D : désafférentation et cardial sont absents du ronéo ; C (opsi- « tardivement ») oppose la clé au ronéo, qui ne donne que la vue (2/2 p. 7) — l'ATTENTION de sem-ech-s28 le signale, et la lettre est posée sur la case Couleurs.
- sem-an-1819-q1 A, B, C, D : pyrét- (écrit pirhét-), la fièvre tierce, pauci- et brachy- sont absents du ronéo 2026-27, qui ne donne pour la fièvre que fébri- (2/2 p. 9).
- sem-an-1819-q2 A, C, E : ambi- / ambo- et brady- sont absents du ronéo ; di- n'y est qu'employé (diplégie, 1/2 p. 4), jamais défini, et C se joue sur sa graphie.
- sem-an-1819-q3 C, E : ops- « en retard » oppose la clé au ronéo (point douteux de CONFLITS, ATTENTION de sem-ech-s28 ; lettre posée sur la case Couleurs) ; haplo- est absent du ronéo 2026-27.
- sem-an-1718-q5 A, C : la dysenterie est un point douteux de CONFLITS — le ronéo imprime la définition même que la clé refuse (2/2 p. 6), et une marche tirée du cours enseignerait contre la clé ; fétor est absent du ronéo.
- sem-an-1718s2-q6 A, D, E : hircine, amblyopie et sibilant sont absents du ronéo 2026-27.
- sem-an-2526-q16 A, B, D : oligo-, dicho- et haplo- sont absents du ronéo 2026-27.
- sem-an-2526-q17 A, B, D : dolicho-, brady- (brachy-) et ambly- sont absents du ronéo 2026-27.

## Régénérer

```powershell
..\..\..\app\.venv\Scripts\python.exe generer.py
```

Réécrit les deux schémas SVG puis `paquet.json`. Le script refuse d'écrire s'il
trouve : une proposition sans justification, un trou de plus de deux mots, une
zone sans phrase explicative, deux zones qui se recouvrent, une légende hors du
schéma, un thème inconnu, une page hors de sa fiche, ou un désaccord déclaré
mais absent de la carte.
