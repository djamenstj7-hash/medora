# Mycoses de l'immunodéprimé : aspergillose, pneumocystose — paquet Parasitologie et mycologie

88 notes, 138 cartes. Chapitre `chap-ue-parasito-fc7` de l'UE Parasitologie et
mycologie (ordre 9). Cours du **Dr M. Cornu, le 02/12/2025**, « Mycoses de
l'immunodéprimé : Aspergillose et Pneumocystose » (FC n°9 du Ronéosaure
2025-26, 10 pages dont une blanche) ; annales du polycopié n°7 du Ronéosaure
2024-25 (22 questions, 12 sessions) et du sujet 2024/2025 de l'UE (2 QROC, sans
corrigé). Examen du 5 janvier 2027.

**Une fiche provisoire.** Aucun ronéo 2026-27 de parasitologie n'est paru : le
chapitre est carté sur le Ronéosaure 2025-26 (décision de Vincent du 02/10), et
le ronéo de l'année corrigera les cartes à sa parution. La source porte son
année dans son auteur (« Ronéosaure 2025-26 ») : chaque carte de cours prend le
tag `cours-2025-26` et le badge « Cours 2025-26 ». Aucune carte ne dit « Absent
du cours 2026-27 », et les erreurs du Ronéosaure sont dites par un ATTENTION
sans genre (précédent d'`immuno_cmh` et d'`immuno_innee`) : la liste
`contenu/ERRATA_RONEOS_2026-27.md` ne concerne que les ronéos 2026-27.

**Un PDF sans couche texte.** La FC n°9 est faite de pages scannées (seules les
pages 7 à 9 ont un peu de texte) : elle a été lue page par page, en image, et
les pages des cartes et du lexique ont été relevées à l'œil.
`chercher_pages.py` n'y trouve rien.

**Reprise d'un brouillon.** Un passage interrompu le 03/10 avait laissé
`generer.py` (copie exacte du modèle, vérifiée), `schemas.py` et douze figures
dans `media/`. Les douze figures ont été revues une à une contre les pages
(bonnes captures, bonnes pages) ; le schéma du spectre a été vérifié rendu, zones
superposées ; deux notes de zone ont été corrigées (une affirmation hors cours,
« il peut saigner », remplacée par le cours 2024-25 ; les pages précisées), et
les coupes entre zones, que le commentaire nommait sans les définir, sont
devenues des constantes (`X_COUPE_GAUCHE`, `X_COUPE_DROITE`), aux mêmes valeurs.
`donnees.py`, `annales.py`, la planche et ce fichier sont de ce passage-ci.

**Relecture sceptique (05/10).** Chaque carte a été relue contre la page de la
fiche qu'elle cite, chaque clé d'annale contre la table imprimée (p. 5-6) et
chaque citation d'appoint contre le cours 2024-25, le cours 2023-24, les FC
n°5 à 8 et 10 2025-26 et l'ANOFEL. Corrigé à cette relecture :
`asp-qc-biologie-pneumo` D, qui notait vrai le « mode asexué » du kyste de
Pneumocystis (une erreur du Ronéosaure, ci-dessous), réécrite ; « la
gastrofongine » rapprochée de la caspofungine (`asp-qc-antifongiques` D) ;
les zones du spectre, qui laissaient entre elles un intervalle où un clic sur
la courbe ne tombait dans aucune zone, devenues un pavage ; deux précisions
(le cours 2024-25 dit aussi « plus de 10 jours » p. 4 ; la légende de la
planche explique ses cases vides sans numéro) ; une étymologie (manna) remise
en forme.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 37 | 37 |
| Texte à trous | 11 | 58 |
| QROC | 9 | 9 |
| Recto-verso | 19 | 19 |
| Schéma cliquable | 1 | 4 |
| Planche à légender | 1 | 1 |
| Lexique | 10 | 10 |

Dont **24 annales** : 11 QCM (QRM) et 13 QROC (recto-verso), sur 13 sessions,
de 2017/2018 S1 à 2024/2025 S1 (QROC 3 et 4 du sujet 2024/2025, réponses
déduites). Les 26 QCM du cours ont une justification par
proposition, comme les annales.

Huit thèmes, dans l'ordre du cours :

| Clé | Libellé |
|---|---|
| `aspergillus` | Aspergillus : réservoir, cycle, pouvoir pathogène |
| `aspergilloses-formes` | Les aspergilloses : entités cliniques |
| `aspergillose-invasive` | Aspergillose invasive : terrain et diagnostic |
| `pneumocystis` | Pneumocystis : histoire, biologie, transmission |
| `pneumocystose-clinique` | Pneumocystose : clinique et imagerie |
| `diagnostic-biologique` | Diagnostic biologique (thème partagé de l'UE) |
| `immunodeprime` | Infections opportunistes de l'immunodéprimé (thème partagé de l'UE) |
| `traitement-prevention` | Traitement et prévention (thème partagé de l'UE) |

Les huit libellés sont à ajouter à `THEME_LABELS`
(`app/src/med_engine/application/scopes.py`), bloc « parasitologie » ; les trois
derniers sont communs à plusieurs chapitres de l'UE (plan C16, §0.5).

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-parasito-aspergillose-pneumocystose` — Ronéosaure, « FC n°9 Mycoses de l'immunodéprimé _ Aspergillose, Pneumocystose » (10 p.), `PARASITO-MYCOLOGIE/…` | **2025-26** | **la base** : chaque note du cours porte sa page ; c'est ce que le lecteur ouvre (`chapitre=`) |
| `src-annales-7-mycoses-de-l-immunodeprime-aspergillose-et-pneumocystose` — Ronéosaure, « 7. Mycoses de l'immunodéprimé _ aspergillose et pneumocystose » (6 p., table p. 5-6) | 2024-25 | les 22 questions ; déclaration à cinq champs, la règle des chapitres écrits en parallèle (aucun autre chapitre ne déclare ce fichier) |
| `src-cours-parasito-aspergillose-pneumocystose-2425` — Ronéosaure, FC n°7 (AC), Dr Cornu (17 p.) | 2024-25 | appoint, cité dans le texte des cartes à la page (PaO2 p. 16, aspergillome opéré p. 5, anticorps des formes chroniques p. 9, une seule espèce humaine p. 12, réanimation p. 3, 14) |
| Charonéo 2023-24, « 9. Parasitologie - Aspergillose et Pneumocystose » | 2023-24 | cité dans une seule justification, sans être déclaré : la réanimation et les candidoses invasives (p. 4), pour 2020/2021 S1 Q. 11 C |
| FC n°5, 6, 7, 8, 10 du Ronéosaure 2025-26 | 2025-26 | citées à la page dans les justifications d'annales qui touchent leur sujet (amoebose hépatique, toxoplasmose cérébrale, dermatophytes, Candida et Cryptococcus, gale profuse), sans être déclarées : ce sont les fiches d'autres chapitres |
| erratas : cours 2025-26 (`Erratas de Parasitologie mycologie.docx`), cours 2024-25, annales 2024-25 | — | aucune entrée sur ce cours ni sur ce polycopié. L'errata 2024-25 corrige deux mots du cours 2024-25 (« LVA », « Colitis ») qu'aucune carte ne cite |
| `src-sujets-parasito-2425` — sujets de parasitologie-mycologie 2024/2025, session 1 (examen du 10/01/2025, 14 p.), sans chemin | 2024-25 | 2024/2025 S1 QROC 3 et 4, par `SRC["sessions"]` ; **aucun corrigé**, réponses déduites du cours ; déclaration commune aux dix chapitres de l'UE, champ pour champ |

Vérifications hors du cours, citées dans la carte qui s'en sert : les cours
nationaux de l'ANOFEL (UMVF, 2014), « Aspergilloses et autres champignons
filamenteux opportunistes » (aspergillome et hémoptysies, taille des conidies,
galactomannane, classes d'antifongiques, signe du halo) et « Pneumocystose »
(réactivation récusée, stade infectant, corticothérapie adjuvante, alternatives
au cotrimoxazole) ; Edman et coll., *Nature*, 1988 (le reclassement de
Pneumocystis) ; Richard et coll., *mBio*, 2018 (le kyste, un asque issu d'une
reproduction sexuée) ; l'étymologie (Wiktionnaire, TLFi, Gaffiot, Bailly).

## Ce que le cours a dicté

- **La seule ligne rouge**, la triade « dyspnée, toux sèche, fièvre » de la
  pneumocystose (p. 8), a sa QCM (`asp-qc-clinique-pneumo` A), son texte à trous
  (`asp-fa-pneumo-clinique`) et deux annales (2023/2024 S2 QROC 2, 2017/2018 S2
  QROC 4).
- **Les étoiles** de la professeure (« Aspergillus », « Cycle », « Entités
  cliniques aspergillaires ») marquent les diapositives des cartes
  `asp-qc-aspergillus`, `asp-qc-cycle`, `asp-qc-formes`.
- Le gris est celui des titres de parties : carté. Aucun passage « pas à
  retenir ».
- **Ce qui appartient à d'autres chapitres n'est pas carté** (plan C16, §2) : la
  tête aspergillaire et la conidiogenèse (« Agents fongiques ») ne paraissent
  que dans la légende d'une figure ; la toxoplasmose cérébrale et la
  cryptococcose ne sont que des propositions d'annales ; le mannane et
  l'antigène cryptococcique ne sont cités que dans 2019/2020 S1 Q3, rangée ici.

## Les erreurs du Ronéosaure 2025-26

Chacune est dite par **ATTENTION**, sans genre, dans la carte qui porte la
notion.

| Page | Ce que dit le Ronéosaure | Ce qui est juste | Carte |
|---|---|---|---|
| 2, 3 | « AspergillOME = non pathogène » ; « la forme aspergillome est non pathogène » | non INVASIF : l'aspergillome est une maladie, opérée (cours 2024-25, p. 5), qui saigne (hémoptysies dans près de 60 % des cas, ANOFEL) | `asp-qc-aspergillome` E ; rappel dans `asp-rv-ome-ose` |
| 5 | « 3 classes d'antifongiques » : azolés, « la gastrofongine », échinocandines, amphotéricine B | aucun antifongique ne s'appelle ainsi (vraisemblablement la caspofungine, mal entendue) ; trois classes : azolés, échinocandines, amphotéricine B (ANOFEL) | `asp-qc-antifongiques` D |
| 7 | les corps intrakystiques de Pneumocystis, nés « suite à une multiplication asexuée » | la diapositive du cycle montre une « conjugaison entre grandes formes trophiques » avant le kyste (p. 8), celle du Giemsa dit « asques ou kystes, corps intrakystiques ou ascospores » (p. 7), le ronéo dit la reproduction « probablement sexuée aussi » (p. 8) : le kyste est un asque, issu d'une reproduction sexuée (Richard et coll., *mBio*, 2018). La proposition ne note plus le mode de multiplication | `asp-qc-biologie-pneumo` D |
| 3 | « des manifestations allergiques en produisant des toxines nécrosantes, ce qui favorise les lésions épithéliales » | deux mécanismes : les toxines nécrosantes lèsent l'épithélium ; l'allergie relève de la réponse Th2 et de la sensibilisation aux mycotoxines (cours 2024-25, p. 5 ; ANOFEL) | `asp-qc-pouvoir-pathogene` C |
| 9 | « hypoxie grave si SpO2 < 60 mmHg » | PaO2 < 60 mmHg, aux gaz du sang (cours 2024-25, p. 16 ; ANOFEL) | `asp-qc-gravite` A |
| 9 | oxygénothérapie et corticothérapie, « alternatives moins efficaces » au cotrimoxazole | point douteux, aussi dans le cours 2024-25 (p. 16) : ce sont des traitements adjuvants ; les alternatives sont la pentamidine, l'atovaquone (ANOFEL). Aucune proposition ne le note | `asp-qc-traitement-pneumo`, explication |

Sans ATTENTION, parce qu'aucune réponse n'en dépend (dit dans la carte quand
elle cite le passage) : « les cardiologues » pour les radiologues (p. 5,
`asp-qc-suspicion` D) ; « lavage broncho pulmonaire » (p. 6) ;
« aspergoire » pour l'aspersoir (p. 2) ; « considéré comme un parasite
(jusqu'à 1980) » quand le reclassement date de 1988 (p. 7, `asp-qc-histoire`) ;
« Pneumocystis carnii », « ß-glycane », « avant l'âge de ¾ ans » (p. 7) ;
« Triméthropine » (p. 9) ; « trophozoïtes (comme dans Plasmodium) = spores »
(p. 7), non carté tel quel, discuté dans 2021/2022 S1 Q. 3 E ; la mucoviscidose
donnée comme exemple d'immunodépression (p. 2), non cartée (c'est le terrain de
l'ABPA, cours 2024-25, p. 4).

## Ce que les annales ont dicté

| Savoir | Questions |
|---|---|
| La pneumocystose : clinique, triade, imagerie | 2017/2018 S1 Q13, 2023/2024 S2 QROC 2, 2022/2023 S1 QROC 3, 2019/2020 S2 QROC 5, 2017/2018 S2 QROC 4 |
| Pneumocystis : espèce, réservoir, réactivation, culture, LBA, PCR | 2022/2023 S2 Q. 7, 2021/2022 S1 Q. 3, 2020/2021 S1 Q. 12, 2020/2021 S2 QROC 2, 2024/2025 S1 QROC 4 |
| L'aspergillose pulmonaire invasive : quand la suspecter (fièvre sous antibiotiques, dyspnée, hémoptysie, douleur thoracique) | 2024/2025 S1 QROC 3 |
| Le diagnostic biologique de l'aspergillose invasive | 2017/2018 S1 Q. 15, 2017/2018 S2 Q. 14, 2022/2023 S2 QROC 4, 2018/2019 S1 QROC 5, 2019/2020 S1 Q3 |
| Aspergillus fumigatus : biologie, pouvoir pathogène | 2020/2021 S1 Q. 11, 2019/2020 S2 Q. 5, 2022/2023 S1 Q. 4, 2020/2021 S2 QROC 3 |
| Les deux mycoses opposées, les infections opportunistes | 2023/2024 S1 QROC 4 et QROC 5, 2022/2023 S2 Q. 3, 2018/2019 S1 QROC 4 |

Deux paires posent la même question à deux sessions, chacune avec sa carte : la
triade (2023/2024 S2 QROC 2, 2017/2018 S2 QROC 4), les examens de l'aspergillose
pulmonaire invasive (2022/2023 S2 QROC 4, 2018/2019 S1 QROC 5). 2024/2025 S1
QROC 4 (les deux méthodes du diagnostic de la pneumocystose) redemande, en
d'autres mots, 2020/2021 S2 QROC 2 (le LBA ; l'examen direct et la PCR).

La 23e question du polycopié, 2021/2022 S1 QROC 3 (modes de transmission
parasitaire), est aussi imprimée pour la même session dans le polycopié n°5 :
elle est cartée une seule fois, dans « Parasitoses digestives « exotiques » »
(plan C16, §4).

## Les clés qui ne sont pas reprises telles quelles

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2019/2020 S1 Q3 (antigènes circulants fongiques dans le sérum) | ACE | **ACD** | D, l'aspergillose invasive : le galactomannane sérique en est l'antigène (FC n°9 2025-26, p. 6), le corrigé de 2018/2019 S1 QROC 5 du même polycopié le cite, l'ANOFEL en fait « un argument biologique majeur ». E, les dermatophyties : une mycose superficielle se diagnostique sur la lésion (FC n°7 2025-26, p. 4 et 7). ACE est vraisemblablement une coquille pour ACD. `officielle=False`, conflits déclarés sur D et E |
| 2022/2023 S1 Q. 4 (aspergillose invasive) | « {B} », corrigé non officiel | B | confirmé par le cours (p. 2-6) ; non marqué officiel |
| 2022/2023 S1 QROC 3 (pneumocystose du patient VIH) | corrigé non officiel, entre accolades | ce corrigé | confirmé par le cours (p. 8) ; non marqué officiel |
| 2024/2025 S1 QROC 3 (signes cliniques de l'aspergillose pulmonaire invasive) | aucune (sujet sans corrigé) | fièvre > 48 h sous antibiotiques, souvent isolée ; parfois dyspnée, hémoptysie, douleur thoracique ; chez le neutropénique | réponse déduite du cours (p. 4-5) ; non marquée officielle |
| 2024/2025 S1 QROC 4 (deux méthodes du diagnostic de la pneumocystose) | aucune (sujet sans corrigé) | sur le LBA : l'examen direct après coloration, la PCR ; pas de culture ; β-D-glucane en appoint | réponse déduite du cours (p. 7, 9), conforme au corrigé officiel de 2020/2021 S2 QROC 2 ; non marquée officielle |

Reprises, avec une remarque dans la carte : **2020/2021 S1 Q. 11 C** (la
réanimation prolongée, cotée fausse : c'est le terrain des candidoses
invasives, cours 2023-24 p. 4 ; un ATTENTION dit que la FC 2025-26 cite la
grippe et le covid sévères, patients de réanimation) ; **2021/2022 S1 Q. 3 E**
(« inhalation de spores ou de conidies », cotée fausse : les conidies sont
celles d'Aspergillus, le stade infectant de Pneumocystis est inconnu) ; les
coquilles imprimées des énoncés, gardées telles quelles
(« candidosevulvo-vaginale », « cryptococcoseneuro-méningée », « champignon
opportunistes », « exacte(s) ?) »).

Cas ouvert : aucun.

## Le schéma cliquable et la planche

| Fichier | Ce qu'on clique | Cartes |
|---|---|---|
| `asp-spectre-nu.svg` (`asp-zo-spectre`) | sur la courbe en U de la diapositive « Des aspergilloses » (p. 3) : l'aspergillose invasive aiguë, la semi-invasive, l'aspergillome et les formes chroniques, les formes allergiques | 4 |

Redessiné sans légende : la courbe et les deux flèches de l'axe
(« Dysfonctionnement immunitaire », « Hyperactivité immunitaire »), qui ne
nomment aucune forme. Chaque zone entoure le seul tronçon de courbe qu'elle
désigne (la branche gauche coupée à `Y_COUPE`, le creux séparé des deux
branches par `X_COUPE_GAUCHE` et `X_COUPE_DROITE`), et deux zones voisines
partagent leur ligne de coupe : un pavage, sans recouvrement d'aire. Rendu
avec les zones superposées et vérifié point par point, tout le trait de la
courbe, épaisseur comprise, tombe dans une zone et une seule. La diapositive
est en correction ; la version légendée, `asp-spectre.svg`, tirée des mêmes
constantes, illustre `asp-rv-ome-ose`.

**La planche** `asp-pl-api` : la diapositive « Aspergillose pulmonaire invasive :
terrain neutropénique » (p. 5), légendes effacées par
`scripts/planche_depuis_image.py` — cinq numéros (signe du halo ; condensation,
nodule ; croissant gazeux ; neutropénie ; PNN > 500, sortie d'aplasie), quatre
intrus (aspergillome, infiltrat interstitiel, pleurésie, lymphopénie CD4). Les
durées J0-J5, J5-J10, J10-J20 restent visibles : la carte demande quel signe
appartient à quelle période. Le sous-titre « terrain neutropénique », l'étiquette
« Retardé » et l'encadré « Excavation => Croissant gazeux » sont effacés avec le
numéro qu'ils donnaient. « Verre dépoli » n'est pas un intrus : le cours
2024-25 appelle ainsi le contour flou du halo (p. 7). L'aperçu de contrôle a
été relu ; deux rectangles ont été agrandis (le sous-titre, le soulignement de
« Condensation »).

**Illustrations** : 30 QCM sur 37 (81 %) portent une diapositive de la fiche en
correction ; 60 notes sur 88 (les deux QROC 2024/2025 prennent le scanner de
l'aspergillose invasive et le Giemsa de Pneumocystis). Les sept QCM sans figure (`asp-qc-antigenes`,
`asp-qc-traitement`, `asp-qc-antifongiques`, `asp-qc-terrains`,
`asp-qc-gravite`, `asp-qc-traitement-pneumo`, 2019/2020 S1 Q3) n'en ont pas dans
la fiche : le diagnostic indirect et les traitements n'y sont que du texte.

## Le lexique

Dix termes, aux pages relevées à l'œil dans la fiche 2025-26 (PDF sans texte) :
aspergillome (p. 2, 3), moisissure (2), neutropénie (4, 5, 6), galactomannane
(6), opportuniste (2, 8), thermotolérance (3), angio-invasion (3), lavage
broncho-alvéolaire (5, 8, 9), verre dépoli (9), ergostérol (7). Chacun dit son
origine grecque ou latine (l'ergostérol, mot français formé sur l'ergot de
seigle et le stérol, le dit comme `lex-biguanide`).

**« Neutropénie » existe déjà** dans le lexique de la biostatistique
(`lex-neutropenie`, `biostat_phases_1_2`). Les identifiants de notes sont
uniques dans la bibliothèque : le terme est repris ici sous
`lex-neutropenie-parasito`, avec la même étymologie, comme
`lex-phagocytose-bmcp` l'a fait pour la phagocytose.

Les étymologies nouvelles — dix racines (`aspergillum (latin)`,
`mucere (latin)`, `manna (latin, du grec)`, `invadere (latin)`,
`lavare (latin)`, `bronch(o)-`, `alveolus (latin)`, `vitrum (latin)`,
`polire (latin)`, `ergot (français)`) et les dix termes — sont **proposées** pour
`scripts/etymologies.json`, avec leurs sources ; la table n'est pas modifiée par
ce chapitre. Les définitions et les racines disent déjà, mot pour mot, ce
qu'`appliquer_etymologies.py` en écrira (vérifié en simulant le script sur la
table complétée). Les racines réemployées gardent la clé de la table : `-ome`,
`neutr(o)-`, `-pénie`, `galact(o)-`, `opportunus (latin)`, `therm(o)-`,
`tolerare (latin)`, `angi(o)-`, `stér(é)-`.

## Questions pour Vincent

1. **2019/2020 S1 Q3** (antigènes circulants) : la table imprime ACE, la carte
   retient ACD (l'aspergillose invasive vraie, les dermatophyties fausses),
   `officielle=False`, conflit déclaré. C'est la proposition du plan (question 2
   du plan C16) : la valides-tu, ou préfères-tu que la carte réponde comme la
   table ?
2. **L'examen du 5 janvier 2027** n'est pas déclaré (`EXAMENS`), comme dans
   tous les chapitres existants (question 5 du plan C16) : faut-il le déclarer
   dans les chapitres des UE de janvier ?
3. **Oxygénothérapie et corticothérapie**, « alternatives moins efficaces » au
   cotrimoxazole : la formule est dans les ronéos 2024-25 et 2025-26, donc
   probablement sur la diapositive de la professeure. Elle n'est notée dans
   aucune proposition, seulement signalée dans l'explication de
   `asp-qc-traitement-pneumo`. Faut-il en faire une proposition « comme le
   professeur » à la parution du ronéo 2026-27 ?

## À relire

Aucune carte `a-relire` : chaque carte de cours porte sa page dans la fiche
2025-26, relue en image, et chaque annale sa clé relue sur la table imprimée
(p. 5-6), ou déduite à la page pour les deux QROC de 2024/2025. À la parution du ronéo 2026-27 de ce cours, relire toutes les cartes
contre lui : les pages, les chiffres (500 PNN/mm³ et 7 jours, 40 % de
mortalité, J0-J5-J10-J20, 15 % de mortalité, 200 CD4/mm³, 3 semaines de
cotrimoxazole, les chiffres mondiaux), et les six erreurs ci-dessus.


## L'échelle : Simple → Moyen → Annale (C20, 19/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 5 janvier. Sous les annales, 45 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 6 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`) ; les QROC reçoivent le schéma nu.

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `aspergillus` | 9 | 1 | 3 |
| `aspergillose-invasive` | 11 | 1 | 4 |
| `pneumocystis` | 9 | 1 | 3 |
| `pneumocystose-clinique` | 6 | 1 | 5 |
| `diagnostic-biologique` | 7 | 1 | 5 |
| `immunodeprime` | 3 | 1 | 4 |

**Le schéma** `ech-aspergillose-pneumocystose`, « Aspergillose et pneumocystose · le champignon, l'hôte, le diagnostic », donne 63 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_ASPERGILLOSE_PNEUMOCYSTOSE`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Sans marche** :
- asp-an-2223s2-q3 A, B, E : l'amoebose hépatique, la toxoplasmose cérébrale et la gale commune relèvent d'autres cours (FC n°5, 6 et 10 2025-26) ; le schéma de ce chapitre ne les porte pas, ces lettres restent sans pastille.
- asp-an-1920s1-q3 A, B, C, E : le mannane de Candida, la candidose vulvo-vaginale, l'antigène cryptococcique et les dermatophyties relèvent des FC n°8 et n°7 ; seule l'aspergillose invasive (D, l'item du conflit) a ses marches et sa pastille. Le mannane et l'antigène cryptococcique ne servent ici que de distracteurs.
- asp-an-1819s1-qroc4 : la cryptococcose, troisième réponse attendue, relève de la FC n°8 ; l'aspergillose et la pneumocystose ont leurs marches (porte d'entrée, transmission).
- asp-an-2223s2-qroc4 et asp-an-1819s1-qroc5 : les β-(1,3)-D-glucanes, que les deux corrigés acceptent pour l'aspergillose invasive, n'ont pas de case dans la région Aspergillus (le cours les dit non spécifiques, p. 6) : la notion est portée par la Moyen asp-ech-m5 C, posée sur « Le diagnostic », et la case du β-1,3-D-glucane de Pneumocystis ; une seconde ligne de glucane aurait donné le trou de l'autre.

## Régénérer

```powershell
cd contenu\chapitres\parasito_aspergillose_pneumocystose
..\..\..\app\.venv\Scripts\python.exe generer.py
```

La planche se refait depuis `app/`, si ses rectangles changent :
`uv run --with pillow python ../.claude/skills/nouveau-chapitre/scripts/planche_depuis_image.py ../contenu/chapitres/parasito_aspergillose_pneumocystose asp-pl-api --apercus <brouillon>`.
