# Mycoses superficielles — paquet Parasitologie et mycologie

79 notes, 136 cartes. Chapitre `chap-ue-parasito-fc10` de l'UE Parasitologie
et mycologie (ordre 7). Cours du **Pr Sendid, le 25/11/2025**, « Mycoses
superficielles » (FC n°7 du Ronéosaure 2025-26, 10 pages, la dernière
blanche) ; annales du polycopié « 9 & 10 » du Ronéosaure 2024-25 (13
questions, 9 sessions) et du sujet 2024/2025 de l'UE (1 question, sans
corrigé). Examen de janvier (5 janvier 2027).

**Une fiche provisoire.** Aucun ronéo 2026-27 de parasitologie n'est paru :
le chapitre est carté sur le Ronéosaure 2025-26 (décision de Vincent du
02/10), et le ronéo de l'année corrigera les cartes à sa parution. La source
porte son année dans son auteur : chaque carte de cours a le tag
`cours-2025-26` et le badge « Cours 2025-26 ». Aucune carte ne dit « Absent du
cours 2026-27 », et les erreurs du Ronéosaure sont dites par un ATTENTION sans
genre : la liste `contenu/ERRATA_RONEOS_2026-27.md` ne concerne que les ronéos
2026-27.

**Le PDF de la FC n°7 n'a pas de couche texte** : il a été lu page par page
en image, et les pages des cartes et du lexique ont été relevées à l'œil
(`chercher_pages.py` ne trouve rien dans ce PDF).

**Un brouillon existait** (run interrompu le 03/10) : `schemas.py` et treize
figures dans `media/`, ni `donnees.py` ni `annales.py`. Les treize figures ont
été vérifiées une à une contre les pages 3 à 7 (toutes justes, gardées). Les
deux schémas étaient justes sur le fond ; trois défauts de mise en page ont
été corrigés (légende du favus coupée au bord, étiquettes de l'ongle posées sur
le dessin, pied de page sur le médaillon), et la note de la zone « microïde »
suit désormais le schéma b de la p. 5 (petites spores en amas épars). Tout le
reste a été écrit dans cette tâche.

**Relecture contradictoire (05/10).** Chaque carte a été relue contre la page
qu'elle cite, chaque clé contre la table imprimée (couleurs du PDF comprises),
chaque figure et chaque zone sur un rendu. Ce qui a changé :

- le schéma des sièges posait la loupe sur le pied **gauche** d'une silhouette
  vue de face, sous le titre « pied droit » : elle est maintenant sur le pied
  droit, à gauche du dessin ;
- « E. floccosum n'attaque jamais le cheveu » citait ANOFEL, qui ne le dit
  pas : la source est le cahier Bioforma n°31 (« Les dermatophytes », 2004,
  p. 50), qui le dit en toutes lettres (`msu-an-2324s2-q8` B,
  `msu-qc-kerion-espece` E) ;
- l'errata du prurit n'est pas une contradiction de la fiche : le cours 2023-24
  porte la même phrase au même endroit, à la fin de la description des macules
  du pityriasis versicolor ; l'ATTENTION est passée de `msu-qc-malassezioses` D
  à `msu-qc-pv` E (voir le tableau ci-dessous) ;
- le texte à trous des groupes écologiques se trahissait (« telluriques »
  caché d'un côté, écrit de l'autre) : il est réécrit en cinq trous ;
- la QROC « périonyxis » est retirée : c'était la définition du terme
  « Périonyxis », que le plan range au lexique de la FC n°8 ; la distinction
  reste ici (recto-verso, texte à trous, QCM, zone du schéma) ;
- détails : le kétoconazole oral a été suspendu en 2011 par l'Afssaps
  (aujourd'hui ANSM) ; le compte des annales du pityriasis versicolor (3 QROC,
  pas 4) ; la proposition d'étymologies remise dans la structure de la table.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 28 | 28 |
| QRU | 3 | 3 |
| Texte à trous | 12 | 59 |
| QROC | 10 | 10 |
| Recto-verso | 14 | 14 |
| Schéma cliquable | 2 | 12 |
| Lexique | 10 | 10 |

Dont **14 annales** : 5 QCM (QRM) et 9 QROC (recto-verso), sur 10 sessions,
de 2017/2018 S1 à 2024/2025 S1 (la Q10 du sujet 2024/2025, clé déduite). Les
26 QCM du cours ont une justification par proposition, comme les annales.
**Illustrations** : 28 QCM sur 31 (90 %), 54 notes sur 79 ; les trois QCM sans figure (facteurs favorisants, diagnostic et
traitement des malassezioses) n'en ont pas dans la fiche, dont les p. 8-9 n'ont
aucune image.

Sept thèmes, dans l'ordre du cours :

| Clé | Libellé |
|---|---|
| `dermatophytes` | Dermatophytes : généralités et genres |
| `teignes-cuir-chevelu` | Teignes du cuir chevelu |
| `parasitisme-pilaire` | Parasitisme pilaire |
| `dermatophyties` | Sycosis, peau glabre, intertrigos, onychomycoses |
| `culture-dermatophytes` | Culture et identification |
| `malassezioses` | Malassezioses |
| `diagnostic-biologique` | Diagnostic biologique (partagé par l'UE, plan C16 § 0.5) |

Les sept libellés sont à ajouter à `THEME_LABELS`
(`app/src/med_engine/application/scopes.py`) ; `diagnostic-biologique` l'est
peut-être déjà par un chapitre voisin, au même libellé.

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-parasito-mycoses-superficielles` — Ronéosaure, « FC n°7 Mycoses superficielles » (10 p.), `PARASITO-MYCOLOGIE/…` | **2025-26** | **la base** : chaque note du cours porte sa page ; c'est ce que le lecteur ouvre (`chapitre=`) |
| `src-annales-9-10-mycoses-de-l-immunodeprime-mycoses-superficielles` — Ronéosaure, « 9 & 10 - mycoses de l'immunodéprimé & mycoses superficielles » (11 p.) | 2024-25 | les 13 questions et leur table de corrections (p. 9-11) |
| FC n°10 - Mycoses superficielles (Ronéosaure 2024-25, 12 p.) et « 7. Parasitologie - Mycoses superficielles » (2023-24, 10 p.) | 2024-25, 2023-24 | appoint, cité dans le texte à la page, non déclaré (le squelette déclare déjà le cours 2024-25) : T. soudanense, les anthropophiles, le favus de l'enfance, le godet favique |
| FC n°8 2025-26 (Candidose, cryptococcose) | 2025-26 | citée dans le texte (p. 3 : périonyxis, « pied d'athlète » candidosique ; p. 4 : perlèche et muguet ; p. 7 : candidose invasive), fiche d'un autre chapitre |
| `src-sujets-parasito-2425` — sujets de parasitologie-mycologie 2024/2025, session 1 (examen du 10/01/2025, 14 p.), sans chemin | 2024-25 | 2024/2025 S1 Q10, par `SRC["sessions"]` ; **aucun corrigé**, clé déduite du cours ; déclaration commune aux dix chapitres de l'UE, champ pour champ |
| errata de la promo 2025-26 (`Erratas de Parasitologie mycologie.docx`) ; errata 2024-25 du cours et des annales | — | quatre entrées sur la FC n°7, reprises ci-dessous ; rien sur ce cours ni sur ces annales en 2024-25 |

**La déclaration du polycopié « 9 & 10 » est partagée** avec le chapitre
`parasito_candidose_cryptococcose`, qui prend les 25 autres questions : même
identifiant, mêmes champs (`id`, `kind`, `titre`, `chemin_relatif`, `auteur`),
selon la forme fixée pour C16, recopiée à l'identique de ce chapitre : le
`titre` est le nom du fichier sans « .pdf », espace finale comprise, comme le
nom réel sur le disque.

Vérifications hors des cours, citées dans la carte qui s'en sert : ANOFEL,
« Dermatophytoses ou dermatophyties » (UMVF, 2014 : eczéma marginé de Hébra au
pli inguinal, favus sans guérison à la puberté et à faible fluorescence
vert-jaune, T. soudanense, épidermophytie circinée) ; collège de dermatologie,
item 87 (UMVF : « toujours pathogènes », « respectent toujours les
muqueuses », pli inguinal) ; cahier Bioforma n°31, « Les dermatophytes »
(2004, p. 50 : E. floccosum n'attaque jamais le cheveu ; gaines dense, lâche
et continue du parasitisme pilaire) ; Afssaps (2011, aujourd'hui ANSM) et EMA
(2013) pour le kétoconazole oral ; l'étymologie (TLFi, Bailly, Gaffiot, LSJ,
Wiktionnaire).

## Ce que la fiche a dicté

- **« Tombe tout le temps à l'examen : savoir reconnaître les teignes ! »**
  (p. 4) et **« Les questions portent souvent sur la différence entre la
  teigne microsporique et teigne trichophytique, le parasitisme pilaire »**
  (p. 8) : propositions `indispensables` sur `msu-qc-teignes` (C) et
  `msu-qc-microsporique` (A, B) ; deux cas cliniques en QRU ; le recto-verso
  `msu-rv-tondantes` ; le schéma cliquable du parasitisme pilaire.
- **« QROC type exam : que signifie kérion ? que signifie sycosis ? »**
  (p. 6) : `msu-qr-kerion`, `msu-qr-sycosis`.
- **« Pityriasis versicolor (EXAM ++++) »** (p. 8) : `msu-qc-pv` (B
  indispensable), un texte à trous, quatre annales.
- **« Identification (pas au programme) »** (p. 7, en gris) et **« JAMAIS de
  caractéristique morphologique ou d'identification d'espèce »** (p. 8) : les
  deux cartes de morphologie et d'identification, `msu-qc-genres` et
  `msu-qc-identification`, portent le tag `edn`.
- Le gris du ronéo n'est ici que celui des titres de parties et du bloc
  « Identification » : il se carte (règle du Ronéosaure), le second avec `edn`.
- Rien de rouge dans cette FC.
- Frontière avec FC n°8 (plan § 2) : l'onychomycose à Candida avec périonyxis
  n'est citée ici que pour la distinguer (`msu-rv-onychomycoses`, zone
  « repli péri-unguéal ») ; ses cartes sont dans `parasito_candidose_cryptococcose`.

## L'errata de la promo et les erreurs du cours

Chacune est dite dans la carte qui porte la notion ; un ATTENTION nu quand la
carte s'écarte de la fiche.

| Page | Ce que dit la fiche | Ce qui est retenu | Carte |
|---|---|---|---|
| 4 | teigne microsporique sans « pseudo-alopécie » | ajoutée (errata de la promo ; corrigé de 2020/2021 S2 QROC 4 ; cours 2023-24 p. 4) | `msu-qc-microsporique` A, `msu-fa-microsporique` |
| 5 | favus « à l'âge adulte », sans godet | de l'enfance à l'âge adulte, pas de guérison à la puberté, godet favique (errata ; cours 2023-24 p. 5, 2024-25 p. 6 ; ANOFEL) — **ATTENTION** | `msu-qc-favus` C, D, E ; `msu-fa-favus` |
| 6 | peau glabre : « lésions sous forme d'érythème » | érythème prurigineux (errata ; cours 2023-24 p. 6, 2024-25 p. 7) | `msu-qc-peau-glabre` E |
| 8 | (errata, description des macules) « un prurit n'est signalé que dans les atteintes folliculaires diffuses » | **point douteux** : le cours 2023-24 porte la même phrase, déformée, à la fin de la description des macules du pityriasis versicolor (p. 8) ; elle vise donc ces macules et concorde avec la fiche (prurit inconstant). Lue comme une règle de toutes les malassezioses, elle contredirait la dermatite séborrhéique (habituel) et le pityriasis capitis (fréquent), p. 8-9. La carte garde la fiche — **ATTENTION** | `msu-qc-pv` E (ATTENTION) ; dit aussi dans `msu-qc-malassezioses` D et son explication |
| 6 | eczéma marginé de Hébra « au niveau des aisselles » (déjà en 2023-24 et 2024-25) | « grands plis » à l'examen ; la référence le place d'abord au pli inguinal (ANOFEL ; collège de dermatologie) — **ATTENTION** | `msu-qc-intertrigos` A (ATTENTION) ; dit aussi dans `msu-qr-hebra` |
| 9 | kétoconazole « crème, gélule ou shampooing » | la voie orale n'est plus autorisée en France contre les mycoses depuis 2011 (Afssaps, aujourd'hui ANSM ; EMA 2013) — **ATTENTION** | `msu-qc-traitement` A (ATTENTION) ; dit aussi dans `msu-qr-ketoconazole` |

Sans ATTENTION, parce qu'aucune réponse n'en dépend : « Agent de beaucoup de
liaisons » (lésions) pour E. floccosum et « Trychophyton schoenleinii » (p. 7),
« Ilssont » (p. 2). Le ronéo écrit aussi que les dermatophytes
« appartiennent tous » aux Ascomycètes, puis range ceux sans reproduction
sexuée connue dans les Deutéromycètes (p. 3) : dit dans l'explication de
`msu-qc-reproduction`, sans carte qui en dépende.

## Ce que les annales ont dicté

| Savoir | Questions |
|---|---|
| Les teignes tondantes, microsporiques et trichophytiques, et leur parasitisme pilaire | 2023/2024 S1 Q.6, 2022/2023 S1 Q.9, 2020/2021 S2 QROC 4, 2017/2018 S1 QROC 4 |
| Le pityriasis versicolor : lésions, sièges, diagnostic | 2023/2024 S1 QROC 3, 2022/2023 S1 QROC 5, 2021/2022 S2 QROC 1 |
| Les agents des teignes tondantes et des onychomycoses | 2023/2024 S2 Q.8, 2022/2023 S2 QROC 5 |
| Le diagnostic d'une teigne tondante | 2021/2022 S2 QROC 2 |
| Les groupes écologiques, la contamination, la culture | 2020/2021 S1 QROC 5, 2019/2020 S2 Q.4 |
| Les lésions à Malassezia | 2023/2024 S2 QROC 5 |
| Les sièges des dermatophyties : plis, cuir chevelu, ongles ; ni muqueuse ni organe profond | 2024/2025 S1 10) (et 2019/2020 S2 Q.4 A, les muqueuses) |

2022/2023 S1 QROC 5 est aussi dans le polycopié n°2 (« Agents fongiques »),
sans correction : carté une fois, ici. Les 25 autres questions du polycopié
« 9 & 10 » sont dans `parasito_candidose_cryptococcose`.

## Les schémas cliquables

| Fichier | Ce qu'on clique | Cartes |
|---|---|---|
| `parasitisme-pilaire-nu.svg` (`msu-zo-parasitisme`) | cinq cheveux : endo-ectothrix microsporique, endothrix trichophytique, favique, ectothrix mégaspore et microïde du kérion | 5 |
| `sieges-mycoses-nu.svg` (`msu-zo-sieges`) | cuir chevelu (teigne tondante), sourcils et plis nasogéniens (dermatite séborrhéique), barbe (sycosis), thorax et cou (pityriasis versicolor) ; au pied : plis interdigitaux (pied d'athlète), bord libre de l'ongle (onychomycose à dermatophyte), repli péri-unguéal (périonyxis à Candida) | 7 |

Le parasitisme pilaire est redessiné d'après les p. 4-5, dans un ordre qui
n'est pas celui du cours, pour qu'on ne le devine pas : ce qui distingue les
cheveux, c'est où sont les éléments fongiques (dedans, dehors), la taille et
la densité des spores, la longueur du cheveu, le bulbe détruit et le godet du
favus, la peau enflammée du kérion. Les sièges sont une silhouette de face et
un pied droit vu de dessus, en médaillon. Les versions légendées, tirées des
mêmes constantes, sont en correction ; aucune légende sur les versions nues.

## Les clés qui ne sont pas reprises telles quelles

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2022/2023 S1 Q.9 (teignes trichophytiques) | ACD, en gris, « pas de correction officielle » | ACD, non marquée officielle | corrigé du secrétaire ; la clé est celle du cours (p. 5) |
| 2019/2020 S2 Q.4 (dermatophytes) | DE, en gris **foncé** (#666666 dans le PDF ; le gris clair des sessions non officielles est #999999, les clés officielles #000000), sans la mention « pas de correction officielle » | DE, non marquée officielle | statut incertain : le gris foncé n'est expliqué nulle part ; la clé est celle du cours (p. 2, 4-5, 7) et du collège de dermatologie (« toujours pathogènes », « respectent toujours les muqueuses ») |
| 2022/2023 S1 QROC 5 (pityriasis versicolor) | corrigé en gris, non officiel | ce corrigé, complété du cours (p. 8) | non marqué officiel |
| 2017/2018 S1 QROC 4 (teignes tondantes) | corrigé en gris, non officiel, sous « QROC : » sans numéro, coupé sur une virgule | complété : les deux teignes tondantes et leur parasitisme pilaire (p. 4-5 ; corrigé de 2020/2021 S2 QROC 4) | le corrigé ne disait pas le parasitisme pilaire que la question demande ; non marqué officiel |
| 2024/2025 S1 10) (sites touchés par les dermatophytes) | aucune (sujet sans corrigé) | **ABD**, non marquée officielle | clé déduite du cours : intertrigo interdigital (p. 6), teignes du cuir chevelu (p. 4-5), onychomycoses (p. 6) ; la bouche est le domaine de Candida (FC n°8 2025-26, p. 4), l'endocarde celui d'une infection profonde, et les dermatophytes, kératinophiles, respectent les muqueuses (p. 2 ; collège de dermatologie) |

Aucune clé imprimée n'est contredite par le cours : pas de `CONFLITS`. Repris
avec une remarque : **2023/2024 S2 Q.8 E** (T. soudanense, hors de la FC
2025-26, dans les cours 2023-24 et 2024-25 et chez ANOFEL) ; **2020/2021 S1
QROC 5** (les anthropophiles du corrigé viennent du cours 2024-25).

Cas ouvert : le statut du gris foncé de 2019/2020 S2 (question 3 ci-dessous).

## Le lexique

Dix termes, aux pages relevées à l'œil dans la fiche 2025-26 : dermatophyte
(p. 1-8), teigne (1, 4, 5, 6, 8), kérion (5, 6, 7), sycosis (6, 7), favus (5,
7), onychomycose (1, 4, 6), kératinophile (2, 8), endothrix (4, 5), alopécie
(5), pityriasis versicolor (8, 9). Chacun dit son origine grecque ou latine.
Aucun n'est accueilli ailleurs dans l'application (« Mycose » est dans
`immuno_infectieux`, « Périonyxis » est prévu en FC n°8).

Les étymologies nouvelles — dix racines (`onych(o)-`, `kérat(o)-`,
`trich(o)- / -thrix`, `tinea (latin)`, `kérion (grec)`, `syc(o)-`,
`favus (latin)`, `alopex (grec)`, `pityr(o)-`, `versicolor (latin)`) et les
dix termes — sont **proposées** pour `scripts/etymologies.json`, avec leurs
sources ; la table n'est pas modifiée par ce chapitre. Les définitions et les
racines disent déjà, mot pour mot, ce qu'`appliquer_etymologies.py` en
écrira (vérifié). Les racines réemployées gardent la clé de la table :
`derm(o)-`, `-phyte`, `myc(o)-`, `-ose`, `-phile`, `endo-`. La racine `-phyte`
n'y cite pas la FC de sémantique, qui l'enseigne au sens d'« excroissance
pathologique » (ostéophyte) : ici, c'est la plante.

## À relire

Aucune carte `a-relire` : chaque carte de cours porte sa page dans la fiche
2025-26, chaque annale sa clé vérifiée (déduite à la page pour celle de
2024/2025). À la parution du ronéo 2026-27 de ce
cours, relire toutes les cartes contre lui : pages, chiffres (80 % de
M. canis, 80 % de T. rubrum, 25-30 °C, 3-4 semaines, moins de 10 minutes), le
favus « à l'âge adulte », l'eczéma marginé « aux aisselles », le kétoconazole
en gélule, et le prurit des malassezioses.

## Questions pour Vincent

1. **L'examen du 5 janvier 2027** (question 5 du plan C16) : faut-il le
   déclarer (`EXAMENS`) dans les chapitres des quatre UE de janvier ? Comme le
   plan le propose, ce chapitre ne le déclare pas, comme tous les chapitres
   existants.
2. **Le prurit des malassezioses** : l'errata de la promo (« un prurit n'est
   signalé que dans les atteintes folliculaires diffuses ») ajoute une phrase
   que le cours 2023-24 place à la fin de la description des macules du
   pityriasis versicolor. La carte la lit ainsi, comme une précision sur ces
   macules (prurit inconstant), et garde la fiche pour les autres lésions
   (point douteux, `msu-qc-pv` E). D'accord ?
3. **Le gris foncé de 2019/2020 S2** (Q.4 ici, Q.2 dans le chapitre de la
   candidose) : ni noir officiel, ni gris clair « pas de correction
   officielle ». La carte prend la clé, confirmée par le cours, sans la
   marquer officielle. Faut-il la tenir pour officielle ?
4. **L'eczéma marginé de Hébra** : le professeur le place aux aisselles trois
   années de suite ; la référence, au pli inguinal. La carte demande « grands
   plis » et dit les deux. Préfères-tu qu'elle réponde « aisselles », comme le
   professeur ?


## L'échelle : Simple → Moyen → Annale (C20, 19/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 5 janvier. Sous les annales, 34 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 5 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`) ; les QROC reçoivent le schéma nu.

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `dermatophytes` | 6 | 1 | 2 |
| `teignes-cuir-chevelu` | 12 | 1 | 5 |
| `dermatophyties` | 4 | 1 | 2 |
| `malassezioses` | 7 | 1 | 3 |
| `diagnostic-biologique` | 5 | 1 | 2 |

**Le schéma** `ech-mycoses-superficielles`, « Les mycoses superficielles · d'où, où, comment les reconnaître », donne 45 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_MYCOSES_SUPERFICIELLES`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Tag `edn`** (passage « pas à retenir ») : `msu-ech-s5`.

**Sans marche** :
- msu-an-1920s2-q4 B : « opportunistes » — la FC 2025-26 ne qualifie pas les dermatophytes ainsi ; la clé repose sur le collège de dermatologie (UMVF), hors des sources de l'échelle : ni marche ni pastille.
- msu-an-2324s2-q8 B : qu'E. floccosum n'attaque pas le cheveu n'est pas dans la FC 2025-26 (cours 2024-25, cahier Bioforma) ; le schéma ne dit de lui que son groupe anthropophile, où la lettre est posée, sans marche qui le prépare.
- msu-an-2324s2-q8 E : T. soudanense n'est pas dans la FC 2025-26, qui ne cite que T. violaceum et T. tonsurans (cours 2024-25 et 2023-24, ANOFEL) ; la lettre est posée sur la teigne trichophytique, mais aucune marche ne nomme cette espèce, que la fiche de l'année ne cite pas.
- msu-an-2324s1-q6 A : « dues à des dermatophytes » n'a pas de marche propre : le titre de région « Dermatophytes » et la case des dermatophytes l'écrivent, un trou ne pourrait donc pas le cacher ; la lettre est posée sur la case des dermatophytes.
- msu-an-2223s2-qroc5 : la seconde réponse, les levures (Candida, avec un périonyxis), relève de la FC n°8 ; seule l'onychomycose à dermatophyte (T. rubrum, bord libre) a ses marches.

## Régénérer

```powershell
cd contenu\chapitres\parasito_mycoses_superficielles
..\..\..\app\.venv\Scripts\python.exe generer.py
```

`generer.py` est la copie exacte de
`.claude/skills/nouveau-chapitre/scripts/generer_modele.py`.
