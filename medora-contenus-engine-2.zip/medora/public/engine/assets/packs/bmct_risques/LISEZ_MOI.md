# Les risques médicamenteux — paquet BMCT

210 notes, 269 cartes. Chapitre `chap-ue-bmct-fc9` de l'UE BMCT, neuvième de
l'UE. **Cours du 16/10/2026, de 8 h à 11 h, Pr S. Gautier, en trois ronéos Ronéo &
Juliette 2026-27** (parties 1, 2 et 3 ; l'en-tête de la partie 1 imprime
« Semaine n°5 », celui de la partie 2 « n°06 » et « Pr S. Gauthier »). Réaligné sur
elles le 19/10/2026 ; il était carté depuis le 02/10 (C14) sur la FC n°9 du
Ronéosaure 2025-26 (Pr Gautier, 20/10/2025), qui n'est plus qu'un appoint. Annales :
le polycopié « Risque médicamenteux, rapport bénéfice-risque » du Ronéosaure
2024-25 (17 sessions, de 2015/2016 à 2023/2024) et la Q19 du sujet 2024/2025.
Examen : partiel du mercredi 4 novembre 2026.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 119 | 119 |
| QRU (marches Simple) | 42 | 42 |
| Texte à trous | 16 | 70 |
| QROC | 10 | 10 |
| Recto-verso | 13 | 13 |
| Lexique | 8 | 8 |
| Schéma cliquable | 1 | 6 |
| Planche à légender | 1 | 1 |

Dont **79 annales** sur 18 sessions (74 QCM, 5 rédactionnelles en recto-verso),
**51 marches de l'échelle** (42 Simple, 9 Moyen) et **36 QCM de cours**. **160 QCM sur
161 illustrés (99 %)**, 193 notes sur 210. **105 cartes de cours citent le ronéo
2026-27 à leur page** (sans badge « Cours 2025-26 ») ; **18 sont absentes du cours
2026-27** (tag `absent-2026`) ; **15 cartes portent un piège du ronéo** (thème
« Pièges des ronéos ») ; une carte reste `a-relire`.

Six thèmes, dans l'ordre du cours, déjà dans `THEME_LABELS`
(`app/src/med_engine/application/scopes.py`) ; le réalignement n'en ajoute aucun :

| Clé | Libellé |
|---|---|
| `benefice-risque` | Balance bénéfice-risque |
| `benefice-medicament` | Le bénéfice : nature, SMR, ASMR |
| `risque-medicamenteux` | Le risque médicamenteux |
| `eim` | Effets indésirables médicamenteux |
| `pharmacovigilance` | Pharmacovigilance |
| `prescrire-risque` | Évaluer le risque avant de prescrire |

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-bmct-rsq-2627-1` — « Risque médicamenteux » (8 p.), `BMCT/RISQUE MÉDICAMENTEUX 1.pdf` | **2026-27** | **partie 1**, 8 h-9 h : la balance, la réévaluation (p. 2), AstraZeneca (p. 3), le décideur et la victime, l'évaluation globale, le SMR (p. 4), l'ASMR, les bénéfices (p. 5-6), le risque, les essais, la pharmacovigilance, le thalidomide (p. 6-7), le placebo, le risque réel, vécu, perçu (p. 7-8) ; `SRC["fiche"]`, ce que le lecteur ouvre ; 33 notes |
| `src-fc-bmct-rsq-2627-2` — « Risques médicamenteux 2 » (8 p., la dernière vide), `BMCT/RISQUE MÉDICAMENTEUX 2.pdf` | **2026-27** | **partie 2**, 9 h-10 h : l'incertitude, les trois facettes du risque (p. 2-4), la prescription personnalisée, la prévention cardiovasculaire, les critères intermédiaires (p. 4-5), les questions avant de prescrire, la définition (p. 5), l'évitabilité, l'aléa, les situations favorisantes, l'attendu (p. 6), l'inattendu, la gravité, l'identification (p. 7) ; `fiche=FC2` ; 32 notes |
| `src-fc-bmct-rsq-2627-3` — « Risque médicamenteux (3) » (14 p., p. 13-14 presque vides), `BMCT/RISQUE MÉDICAMENTEUX 3.pdf` | **2026-27** | **partie 3**, 10 h-11 h : la base publique, le diagnostic iatrogène (p. 2), le surdosage, la pharmacodépendance, l'addiction (p. 3-4), l'évaluation bénéfice/risque, déprescrire (p. 4-5), déclarer (p. 5-6), les acteurs, le signal, le rétatrutide (p. 6-8), la lamotrigine (p. 8-12), la metformine (p. 12) ; `fiche=FC3` ; 40 notes |
| `src-fc-bmct-rsq-2526` — FC n°9, « Les risques médicamenteux » (17 p.) | 2025-26 | **appoint** (`SRC["cours"]`, sans `chapitre=`) : ce que le ronéo 2026-27 ne reprend pas, cité « FC 2025-26, p. 12 » ; les figures les plus nettes (`SRC["medias"]`) ; la source des **18 cartes absentes**, qui la citent à leur page (`fiche=FC2526`) |
| `src-annales-bmct-risque` — « Risque médicamenteux, rapport bénéfice-risque » (21 p.) | 2024-25 | 17 sessions, table p. 19-21 ; déclaré **à l'identique** de `bmct_variabilite`, qui en carte les QCM d'interactions |
| `src-sujets-bmct-2425` — Sujets de BMCT 2024/2025, session 1 (20 p.) | 2024-25 | la Q19, sujet sans corrigé ; `SRC["sessions"]["2024/2025 S1"]` |
| tableau d'erreurs BMCT de la promo 2026-27 | 2026-27 | deux lignes au 19/10/2026, sur la pharmacocinétique et la pharmacodynamie : **rien sur ces trois ronéos** |

Les textes citent « partie 1, p. 5 » (ronéo 2026-27) ou « FC 2025-26, p. 12 ». Lus en
appoint, sans être déclarés : la FC n°9 2024-25 (Ronéosaure 2024-25) et le cours
2023-24 (Charonéo, n°9) du même professeur ; les cartes qui s'y appuient le disent
(« cours 2024-25, p. 16 »). Les trois fiches de l'année se copient dans le dossier des
PDF de l'application par `outils/copier_les_cours.py`, lancé avec le dossier des
ronéos 2026-27 (`Ajouts/[NUMERIQUE] Ronéo & Juliette 26-27 19 10 2026/S1/CM`), hors du
bac à sable.

Les en-têtes des ronéos, des erratas et du polycopié portent des noms d'étudiants :
aucun n'est repris.

## Ce qui correspond à quoi

| FC 2025-26 | Ronéo 2026-27 |
|---|---|
| I-II Introduction, la balance, la grossesse et les paliers (p. 2-3) | partie 1, p. 2 : la balance, la réévaluation, les corticoïdes de l'enfant, l'Esbriet, l'hypertendu de 60 et 90 ans — **plus de grossesse** |
| II.A-B L'hépatite B, les deux échelons, l'ASMR, le GLP-1 (p. 3-4) | partie 1, p. 3-5 : AstraZeneca, le décideur et la victime, l'évaluation globale, le SMR et l'ASMR, le GLP-1 en bénéfice collatéral — **plus d'hépatite B** |
| III. Le bénéfice : essais, phases, quatre bénéfices (p. 4-6) | partie 1, p. 4-6 : la preuve de l'efficacité, quatre bénéfices dont le « disease modifier » (mucoviscidose) ; partie 2, p. 4 : les critères intermédiaires — **plus de rougeole à 9 mois** |
| IV.A-C Le risque, ses chiffres, la pharmacovigilance, le spray (p. 6-7) | partie 1, p. 5-7 : les essais centrés sur l'efficacité, les vasoconstricteurs, le thalidomide, les soignants vaccinés un dimanche — **plus de 95 / 15-20 / 1 %** |
| IV.D L'évolutivité : COVID, pholcodine, hypertendu, IPP (p. 7-10) | partie 1, p. 3, 5, 7 ; partie 3, p. 4-5 : AstraZeneca, le retrait, déprescrire le tramadol — **plus de pholcodine ni d'IPP** |
| IV.E Réel, vécu, ressenti ; l'antibiotique (p. 10) | partie 1, p. 8 ; partie 2, p. 2-5 : réel, vécu, **perçu** ; les questions avant de prescrire — **plus de H1N1** |
| V. L'effet indésirable : définition, aléa, formes, types, gravité, identifier (p. 10-13) | partie 2, p. 5-7 ; partie 3, p. 2-4 : définition, évitabilité, aléa, situations favorisantes, attendu et inattendu, gravité, identification, diagnostic iatrogène, surdosage, dépendance — **plus d'effet contre événement, de dents jaunes ni de troubles cognitifs** |
| VI.A La pharmacovigilance : limites pré-AMM, Europe, acteurs (p. 13-14) | partie 3, p. 5-8 : les essais contre la vie réelle, déclarer, les acteurs, les firmes, du signal à l'alerte, le rétatrutide — **plus de pays rapporteur ni de VigiBase** |
| VI.B-C La lamotrigine, les déclarations (p. 14-16) | partie 3, p. 5-6, 8-12 |
| VII Évaluation et modulation, les dix éléments (p. 17) | partie 3, p. 4 : l'évaluation par questions et son schéma — **plus de dix éléments ni de contraceptif d'Europe de l'Est** |
| — | **nouveau** : le placebo, l'homéopathie, l'incertitude (partie 1, p. 7-8 ; partie 2, p. 2) ; la prévention cardiovasculaire (partie 2, p. 4) ; la pharmacodépendance et l'addiction (partie 3, p. 3-4) ; la metformine (partie 2, p. 4 ; partie 3, p. 12) |

## Le réalignement du 19/10/2026

Les 101 notes de cours de la version 2025-26 (hors lexique), échelle comprise, ont été
relues une à une contre les trois ronéos.

**Relues et confirmées (83), qui citent désormais leur page de l'année** (et perdent le
badge « Cours 2025-26 ») ; chaque justification a été réécrite sur le ronéo 2026-27,
et ce que seul le cours 2025-26 porte le dit (« FC 2025-26, p. 9 ; absent du ronéo
2026-27 ») :

| Partie | Notes |
|---|---|
| 1 (28) | `rsq-qc-balance`, `rsq-qc-reevaluer`, `rsq-fa-balance`, `rsq-ech-s1`, `rsq-ech-s2`, `rsq-ech-s3` (p. 2) ; `rsq-qc-covid`, `rsq-qr-55-ans` (p. 3) ; `rsq-qc-perceptions`, `rsq-rv-echelons`, `rsq-ech-s7`, `rsq-ech-m7`, `rsq-ech-s17`, `rsq-ech-s21` (p. 4) ; `rsq-qc-glp1`, `rsq-fa-asmr`, `rsq-fa-types-benefice`, `rsq-rv-smr-asmr` (p. 5) ; `rsq-qc-benefice`, `rsq-qc-risque`, `rsq-ech-s11`, `rsq-ech-m8`, `rsq-ech-s19`, `rsq-ech-s22`, `rsq-ech-m5` (p. 6) ; `rsq-fa-risque-evolutif`, `rsq-ech-s6` (p. 7) ; `rsq-ech-s9` (p. 8) |
| 2 (27) | `rsq-qc-interpretation`, `rsq-fa-trois-risques` (p. 2) ; `rsq-ech-s31` (p. 3) ; `rsq-ech-s5`, `rsq-ech-s10`, `rsq-ech-s39` (p. 4) ; `rsq-qc-eim`, `rsq-fa-avant-prescrire`, `rsq-fa-eim-definition`, `rsq-ech-s12`, `rsq-ech-s13`, `rsq-ech-s14`, `rsq-ech-s30`, `rsq-ech-m9` (p. 5) ; `rsq-qc-types-gravite`, `rsq-fa-facteurs-favorisants`, `rsq-rv-alea-evitabilite`, `rsq-rv-types`, `rsq-ech-s32`, `rsq-ech-s33`, `rsq-ech-s37`, `rsq-ech-m1`, `rsq-ech-m2`, `rsq-ech-m6` (p. 6) ; `rsq-qc-identifier`, `rsq-ech-s35`, `rsq-ech-s36` (p. 7) |
| 3 (28) | `rsq-ech-s38` (p. 3) ; `rsq-qc-europe`, `rsq-fa-limites-pre-amm`, `rsq-ech-s18`, `rsq-ech-s20`, `rsq-ech-s24`, `rsq-ech-s28`, `rsq-ech-s29` (p. 5) ; `rsq-qc-post-amm`, `rsq-qc-declaration`, `rsq-fa-acteurs`, `rsq-ech-s23`, `rsq-ech-s40`, `rsq-ech-s42`, `rsq-ech-m4` (p. 6) ; `rsq-rv-centralise`, `rsq-ech-s25`, `rsq-ech-s27`, `rsq-ech-m3` (p. 7) ; `rsq-qr-crpv`, `rsq-zo-pharmacovigilance`, `rsq-ech-s26` (p. 8) ; `rsq-qc-lamotrigine`, `rsq-fa-lamotrigine` (p. 9) ; `rsq-ech-s41` (p. 10) ; `rsq-qr-lamisil`, `rsq-ech-s15` (p. 11) ; `rsq-ech-s34` (p. 12) |

**Ce que le ronéo 2026-27 dit autrement, et ce qui a été réécrit** :

- **L'obligation de déclarer vaut pour tous les effets** (« théoriquement obligatoire
  pour tous les effets indésirables », partie 3, p. 6 ; « le texte de loi oblige »,
  p. 5), ce que dit le droit depuis 2012 ; en pratique, on remonte surtout les
  significatifs, les graves et les inattendus. La FC 2025-26 la limitait aux « graves ou
  inattendus (décret 2005) », et la carte le portait en « ATTENTION — c'est le cours
  lui-même, daté » : il n'y a plus d'erreur du cours. Réécrits : `rsq-qc-declaration` A,
  la marche `rsq-ech-s40` (« Tous les effets indésirables ») **et sa case du schéma**
  (« Obligation : tous les effets »), la constante `_DECLARER` des annales.
- **Le risque « perçu »** remplace le « ressenti » (partie 1, p. 8 ; partie 2, p. 3) :
  le troisième trou de `rsq-fa-trois-risques` et la proposition B de
  `rsq-qc-interpretation`.
- **Quatre bénéfices, dont le « disease modifier »** (la mucoviscidose, partie 1,
  p. 6) à la place du bénéfice « établi sur un critère intermédiaire » : le troisième
  trou de `rsq-fa-types-benefice`. Le critère intermédiaire reste du cours, comme moyen
  de suivre un traitement préventif ou chronique (partie 2, p. 4) : la marche
  `rsq-ech-s10` le cite là.
- **L'addiction : les opioïdes, les benzodiazépines, les psychotropes** (partie 2,
  p. 6 ; partie 3, p. 3), et non plus les laxatifs et les corticoïdes : le texte de
  `rsq-fa-facteurs-favorisants`, la marche `rsq-ech-s38` **et sa case du schéma**
  (« pharmacodépendance, addiction » : la ligne effacée dit la réponse de la marche,
  « la pharmacodépendance »).
- **L'Europe décide** : les signaux « remontent au niveau national où ils prennent la
  décision de le reporter à l'Europe où toutes les décisions se prennent » (partie 3,
  p. 5) ; le pays rapporteur n'est plus dit. La marche `rsq-ech-s24` demande désormais
  ce que fait l'échelon européen, **et sa case du schéma** dit « elle prend les
  décisions ».
- **L'hypertendu de 60 et 90 ans** (partie 1, p. 2) remplace celui de 45 à 80 ans : les
  propositions A et E de `rsq-qc-reevaluer`.
- **Les questions avant de prescrire** ajoutent l'historique et l'observance, la
  fonction hépatique, et une durée « précisée » (partie 2, p. 5 ; partie 3, p. 5) :
  `rsq-fa-avant-prescrire` (cinquième trou) et la figure `avant-prescrire.svg`.
- **L'attendu « fréquent et peu grave », « mécanisme pharmacologique » ; l'inattendu
  « rare et souvent grave », « pas pharmacologique »** (partie 2, p. 6-7) : ce que seul
  le cours 2024-25 disait est désormais du cours, et les annales de l'attendu et de
  l'inattendu le citent.
- **L'aléa thérapeutique** : « un événement indésirable grave et imprévisible survenant
  sans qu'aucune faute ni mesure préventive ne puisse l'éviter », avec l'allergie
  mortelle à un laxatif (partie 2, p. 6) : `rsq-fa-eim-definition`,
  `rsq-rv-alea-evitabilite`, `lex-alea-therapeutique`.
- **La lamotrigine** : sur le marché français en 1995, ses toxidermies dès les six
  premiers mois (partie 3, p. 8-9) ; la proposition A de `rsq-qc-lamotrigine` ne date
  plus le rectificatif de 1997, que la justification garde ; le cas de 2008 devient un
  décollement de 100 % et une leçon d'éducation thérapeutique (p. 10-11).
- **AstraZeneca** : `rsq-qr-55-ans` demande désormais l'âge retenu **en France** (le
  ronéo 2026-27 dit « moins de 30 ans », la recommandation britannique : point
  douteux, plus bas) ; la proposition C de `rsq-qc-covid` ne donne plus d'âge.
- **Le SMR et l'ASMR** : l'ASMR I « très rare, novateur », V « plus de 80 % des
  médicaments » (partie 1, p. 5) : `rsq-fa-asmr` et `rsq-rv-smr-asmr`. L'« ATTENTION —
  prise de notes » de la FC 2025-26 sur « I = Novateur » est retirée : novateur décrit le
  niveau I, que la HAS nomme « majeure » ; la carte le dit sans en faire une erreur.
- **L'ANSM** : la diapositive des acteurs l'abrège « Agence Nationale de Sécurité des
  médicaments » (partie 3, p. 6) ; ce que la carte `rsq-fa-acteurs` tenait pour une
  prise de notes du ronéo 2025-26 vient donc de la diapositive. Le texte de 2026-27
  donne le nom complet (p. 7) ; la carte le dit, sans ATTENTION.
- **Le spray nasal** : le ronéo 2026-27 parle juste des vasoconstricteurs du rhume
  (partie 1, p. 5) ; l'ATTENTION sur « l'eau de mer » de 2025-26 devient une remarque
  (`rsq-qc-risque` E).

**Notes nouvelles (24)**, sur ce que le cours 2026-27 apporte :

| Note | Ce qu'elle carte |
|---|---|
| `rsq-qc-balance-desequilibre` | la balance qui penche vers le bénéfice pour prescrire, la contre-indication, l'Esbriet, la réévaluation, les corticoïdes de l'enfant (partie 1, p. 2) |
| `rsq-qc-astrazeneca` | le suivi intensif, les thromboses du sujet jeune, le bénéfice selon l'âge, le risque individuel qui alerte le collectif, les soignants malades (partie 1, p. 3, 7) |
| `rsq-qc-nature-benefice` | la preuve de l'efficacité, un bénéfice qui peut être moins de risques, l'origine jamais traitée, le « disease modifier », le préventif difficile à faire accepter (partie 1, p. 4-6) |
| `rsq-qc-vaccin-collectif` | le pari du collectif, la réanimation évitée, la chaîne de contamination, la rougeole du bébé (partie 1, p. 6-7) |
| `rsq-qc-placebo` | pas d'effet sans effet indésirable, le placebo qui soulage, l'inexplicable, le perçu difficile à combattre (partie 1, p. 7-8 ; partie 2, p. 2-3) |
| `rsq-qc-trois-facettes` | le risque réel des vaccins à ARN, le vécu qu'on respecte, la myocardite aiguë, le perçu qui résiste (partie 2, p. 2-3) |
| `rsq-qc-prevention-cv` | prévention primaire, phase aiguë, prévention secondaire, critères intermédiaires, risque digestif de l'antibiotique (partie 2, p. 4-5) |
| `rsq-qc-cinq-questions` | les questions avant de prescrire (partie 2, p. 5) |
| `rsq-qc-evitabilite-alea` | la définition, l'effet secondaire non nocif, l'évitabilité, l'aléa (partie 2, p. 5-6) |
| `rsq-fa-gravite` | létal, la vie en danger, invalidité ou incapacité ; le non-grave qui compte (partie 2, p. 7) |
| `rsq-qc-iatrogene` | la base publique, écrit ou non écrit, le CRPV en cas de doute, le diagnostic iatrogène, le rétatrutide (partie 3, p. 2, 7) |
| `rsq-qc-dependance`, `rsq-rv-dependance-addiction` | le surdosage accidentel, 3 g de paracétamol, pharmacodépendance contre addiction, ne pas arrêter brutalement, l'ordonnance sécurisée du tramadol et de la codéine (partie 3, p. 3-4) |
| `rsq-qc-evaluation-br` | estimer le risque et le bénéfice, maîtriser, optimiser, guéri à J7, une durée précisée (partie 3, p. 4-5) |
| `rsq-qc-firmes` | les rapports périodiques, déclarer au CRPV et non au laboratoire, le laboratoire partisan, la veille sur internet, les beaux patients des essais (partie 3, p. 5-7) |
| `rsq-qc-signal-alerte` | les cas graves remontés tout de suite, la banque de données, le CRPV qui aide à prescrire, déclarer l'anecdotique, le thalidomide (partie 3, p. 6-8) |
| `rsq-qc-lamotrigine-cas` | l'aléa sauf imprudence, les boutons et l'angine, les génériques de 2005, l'éducation thérapeutique, la double responsabilité (partie 3, p. 10-12) |
| `rsq-qc-metformine` | l'acidose lactique attendue et évitable, la déshydratation, le mécanisme, l'accompagnement (partie 3, p. 12 ; partie 2, p. 4) |
| `rsq-qr-bdpm`, `rsq-qr-thalidomide`, `rsq-qr-education` | la base de données publique des médicaments ; le thalidomide, 1961 ; l'éducation thérapeutique (partie 3, p. 2, 6, 11) |
| `rsq-rv-sjs-lyell` | Stevens-Johnson et Lyell, selon l'étendue du décollement (partie 3, p. 9-10) |
| `lex-toxidermie`, `lex-pharmacodependance` | deux termes du lexique (plus bas) |

## Ce que le cours a dicté

- **Aucun rouge** dans les trois ronéos 2026-27 en dehors des titres ; le gras du texte
  (la prescription personnalisée, la réévaluation, l'évitabilité, l'aléa, le texte de
  loi qui oblige, les 8 premières semaines, l'éducation thérapeutique) a sa carte.
- **Le gris** (partie 2, p. 2-3 : les questions des étudiants sur le placebo des
  nouveau-nés, les effets à long terme des vaccins, le patient qui refuse le rappel ;
  partie 3, p. 3 : la définition du surdosage ; p. 5 : le laboratoire « partisan », la
  question sur la déclaration au laboratoire ; p. 8 : la vente illégale en ligne) est la
  voix des rédacteurs, et se carte comme le reste (décision du 25/09) :
  `rsq-qc-trois-facettes` C-D, `rsq-ech-s31`, `rsq-qc-firmes`, `rsq-qc-dependance`.
  Aucun ronéo ne définit son gris comme hors programme. Pas de carte sur la réponse
  au placebo des nouveau-nés (l'environnement, la dépression maternelle), hors du sujet.
- **Les diapositives** font foi : le système français (« 30 CRPV », partie 3, p. 7), les
  acteurs en France (« depuis juin 2011 », p. 6), la pyramide des acteurs (p. 8), les
  essais contre la vie réelle (p. 5), l'évaluation du rapport bénéfice/risque (p. 4),
  les lettres de 2010 sur la lamotrigine (p. 11) ; toutes illustrent une correction.
- **Ce qui n'est pas carté ici** parce qu'un autre chapitre le tient : les phases I à
  III (`bmct_pharmacodynamie`) ; les interactions et la déprescription
  (`bmct_variabilite`) ; le circuit cérébral de l'addiction (`bmct_neurotransmission`).

## Ce que les annales ont dicté

| Savoir | Questions |
|---|---|
| La pharmacovigilance en France : réseau régional, terrain, Europe, patients, firmes | 2023/2024 Q16 ; 2022/2023 S1 et 2021/2022 S1 Q.17 ; 2018/2019 S1 Q.12 ; 2018/2019 S2 Q.14 ; 2017/2018 S1 Q.14 ; 2017/2018 S2 Q.16 ; 2016/2017 S1 Q12 ; 2016/2017 S2 Q15 ; 2015/2016 S1 Q15 ; 2015/2016 S2 Q17 |
| Ce qu'est un effet indésirable, ce qu'il entraîne (observance, déclaration) | 2024/2025 S1 Q19 ; 2021/2022 S2 Q.16 ; 2020/2021 S2 Q.16 ; 2019/2020 S1 Q.18 ; 2018/2019 S1 Q.15, Q.17 ; 2018/2019 S2 Q.13 ; 2017/2018 S1 Q.15 ; 2017/2018 S2 Q.13 ; 2016/2017 S1 Q13 ; 2016/2017 S2 Q14 ; 2015/2016 S1 Q18 ; 2015/2016 S2 Q15 |
| L'effet attendu et l'inattendu | 2022/2023 S1 et S2, 2021/2022 S1 Q.18 ; 2020/2021 S1 Q.16 ; 2019/2020 S2 Q.18 ; 2016/2017 S2 Q17 ; 2015/2016 S1 Q16 |
| Les facteurs favorisants | 2023/2024 Q18 ; 2022/2023 S1 et 2021/2022 S1 Q.20 ; 2020/2021 S2 Q.14 ; 2019/2020 S2 Q.15 |
| Les limites de l'évaluation pré-AMM | 2023/2024 Q15 ; 2021/2022 S2 Q.18 ; 2020/2021 S2 Q.18 ; 2018/2019 S1 Q.18 ; 2017/2018 S2 Q.15 ; 2015/2016 S1 Q19 ; 2015/2016 S2 Q16 |
| Identifier les effets : notification, épidémiologie, registres | 2022/2023 S1 et 2021/2022 S1 Q.19 ; 2020/2021 S2 Q.17 ; 2019/2020 S1 Q.19 |
| L'évaluation individuelle avant de prescrire | 2023/2024 Q17 ; 2022/2023 S2 Q17 ; 2020/2021 S1 Q.15 ; 2019/2020 S1 Q.15 |
| Le risque, toujours au regard du bénéfice | 2023/2024 Q19 ; 2021/2022 S2 Q.17 ; 2019/2020 S2 Q.14 ; 2017/2018 S1 Q.13 ; 2016/2017 S2 Q13 ; 2015/2016 S1 Q14 |
| Informer, déclarer, les conditions de survenue | 2023/2024 Q20 ; 2021/2022 S2 Q.19 ; 2017/2018 S2 Q.14 ; 2016/2017 S1 Q17 ; 2015/2016 S2 Q14 |
| La balance : collective et individuelle, acceptabilité, décision | 2021/2022 S2 Q.15 ; 2020/2021 S2 Q.19 ; 2019/2020 S1 Q.20 ; 2019/2020 S2 Q.20 ; 2018/2019 S2 Q.16, Q.18 ; 2016/2017 S1 Q18 ; 2015/2016 S1 Q20 |
| La iatrogénie et ses conséquences | 2022/2023 S1 Q.16 ; 2020/2021 S1 Q.14 ; 2020/2021 S2 Q.13 |
| Le bénéfice | 2017/2018 S2 Q.18 |
| Les dix éléments (rédactionnelles) | 2022/2023 S2 QROC (corrigé) ; 2018/2019 S1 QROC2 ; 2016/2017 S1 QROC1 |
| Le développement ne suffit pas ; la pharmacovigilance en schéma (rédactionnelles) | 2019/2020 S2 QROC2 ; 2015/2016 S2 QROC2 |

**Chaque clé a été relue contre le ronéo 2026-27 : aucune n'est contredite par lui.** Il
en confirme plusieurs que seuls les cours d'avant portaient : l'inattendu « rare et
souvent grave », « pas pharmacologique » (2020/2021 S1 Q.16 B) ; l'obligation de
déclarer pour tous, qui rend fausses « seuls les graves inattendus » (2023/2024 Q20 B,
2017/2018 S2 Q.14 B) et « selon la loi, seulement les graves » (2016/2017 S1 Q17 B) ;
l'information du patient, l'éducation thérapeutique (2023/2024 Q20 A ; 2021/2022 S2
Q.19 E ; 2016/2017 S1 Q17 D). Les justifications citent désormais le ronéo 2026-27
(« partie 2, p. 6 ») là où il dit la même chose, la FC 2025-26 ailleurs ; les
illustrations des annales pré-AMM et du bénéfice passent aux figures de l'année
(`rsq-essais-vie-reelle.png`, `benefices-types.svg`), celle de la rédactionnelle sur la
pharmacovigilance à la pyramide des acteurs (`rsq-acteurs-pyramide.png`).

**Pas recartés ici** : les sept QCM d'interactions (2021/2022 S2 Q.20, 2018/2019 S2
Q.15, 2016/2017 S1 Q14 et Q15, 2016/2017 S2 Q16 et Q18, 2015/2016 S1 Q17) et le QROC 2
de 2020/2021 S1 (interaction pharmacocinétique), tous dans `bmct_variabilite` ; la Q.16
de 2018/2019 S1, déjà `pdg-an-1819s1-q16`. La 2021/2022 S2 Q.19 en reprend l'énoncé mot
pour mot : autre session, carte ici.

**La Q.16 orpheline de 2016/2017 S1** : la table donne « Q16 : BE » ; le polycopié n'a
pas d'énoncé entre la Q15 et la Q17. Rien à carter. **La table range le QROC 2 de
2018/2019 sous la session 2**, le polycopié sous la session 1 : la carte suit le
polycopié.

## Les clés qui ne sont pas reprises telles quelles

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2020/2021 S2 Q.14 | CD | ACD | « le mode de vie », mot pour mot vrai en 2023/2024 Q18, 2022/2023 S1 et 2021/2022 S1 Q.20 ; tabac, alcool, alimentation (FC n°5, p. 21-22) |
| 2020/2021 S2 Q.19 | ABDE | ABD (4 propositions) | la proposition E manque au polycopié |
| 2019/2020 S2 Q.14 | ABE | BE | A « à prendre en compte indépendamment du bénéfice » : contre cinq sessions et le cours (« est-ce qu'il est acceptable au regard du bénéfice ? », partie 3, p. 4). Deux lectures, dites dans la carte : « quel que soit le bénéfice » serait vrai — point douteux, question ci-dessous |
| 2016/2017 S1 Q17 | BDE | CDE | table décalée ; B « selon la loi, seuls les graves » faux partout, et faux selon la loi, que le ronéo 2026-27 cite (partie 3, p. 5-6) ; C vrai en 2015/2016 S2 |
| 2016/2017 S1 Q18 | BD | BDE | table décalée ; E vrai mot pour mot en 2018/2019 S2 Q.16 et 2015/2016 S1 Q20 |
| 2016/2017 S2 Q17 | BD | B | D « Quincke sous IEC faciles à identifier » : faux en 2015/2016 S1 Q16, faux en clinique |
| 2022/2023 S2 QROC | corrigé imprimé | repris | seule rédactionnelle corrigée |
| 2019/2020 S2 QROC2 ; 2018/2019 S1 QROC2 ; 2016/2017 S1 QROC1 ; 2015/2016 S2 QROC2 | « pas de correction » | versos déduits du cours | dit dans chaque carte (« clé déduite du cours, absente de la table de corrections ») |
| 2024/2025 S1 Q19 (`rsq-an-2425s1-q19`) | aucune (sujet sans corrigé) | **BCE**, `officielle=False` | la 2021/2022 S2 Q.16 (BCE), A durcie d'un « toujours » : un effet indésirable survient aux posologies normales (partie 2, p. 5), avec ou sans situation favorisante (p. 6) ; mauvaise élimination (p. 6), déclaration du grave (partie 3, p. 6), observance (partie 2, p. 7) |

Toutes les autres clés sont reprises telles quelles. Les points discutés dans la carte
sans changer la clé :

| Question | Clé | Le point |
|---|---|---|
| 2019/2020 S2 Q.15 D | BCE | « le mode de vie » faux sous « situations d'utilisation du médicament », vrai ailleurs sous « facteurs » — point douteux |
| 2020/2021 S2 Q.17 A et E | BCD | « sont identifiés (signal) » par l'épidémiologie, « de façon automatisée » : faux ; vrais sous « peuvent être identifiés » (2022/2023 S1, 2021/2022 S1) — **cas ouvert** |
| 2023/2024 Q16 A | AD | « 30 centres » : la diapositive du cours, encore en 2026-27 (partie 3, p. 7) ; 31 CRPV aujourd'hui — `ATTENTION (cours)` |
| 2018/2019 S1 Q.12 A ; 2017/2018 S1 Q.14 A | BD ; BC | « système régional » seul, « système centralisé » seul : faux ; « régional et centralisé » vrai — nuance |
| 2020/2021 S1 Q.14 D | AC | « peut ne pas avoir de conséquences néfastes » faux selon la clé ; le cours 2023-24 (p. 3) disait le risque iatrogène « bénéfique ou toxique » ; la figure de 2025-26 et 2026-27 le dit « toxique non souhaité » (partie 1, p. 2) : ATTENTION, point douteux, clé gardée |

Chaque contradiction est déclarée dans `CONFLITS` (27 entrées, inchangées) sur les deux
questions qui se contredisent : la carte contestée, et ses contreparties.

## Les erreurs des ronéos 2026-27

Le tableau d'erreurs BMCT de la promo ne relève rien sur ces trois ronéos au 19/10/2026 :
toutes les erreurs ci-dessous ont été trouvées en relisant, et vont dans
`contenu/ERRATA_RONEOS_2026-27.md` (que la tâche ne touche pas : elles sont données pour
y être reportées). Aucun ronéo n'est corrigé ; chaque erreur est portée par une carte,
avec son genre. À l'examen, on répond d'abord comme le professeur.

**Prise de notes fausse** (`ATTENTION (prise de notes)`) :

| Partie, page | Le ronéo dit | Ce qui est juste | Carte |
|---|---|---|---|
| 3, p. 10 et 12 | « toxicomanie bulleuse » | la toxidermie bulleuse, que le même ronéo nomme ainsi p. 9 à 11 (« Σ de Lyell » sur la diapositive, p. 9) | `rsq-qc-lamotrigine-cas` (B) |

**C'est le cours lui-même** (`ATTENTION (cours)` : « À l'examen : … », puis « La
référence : … ») :

| Partie, page | Le cours dit | La référence | Carte |
|---|---|---|---|
| 3, p. 7 (diapositive) | « 30 CRPV » (déjà la FC 2025-26, p. 14) | 31 centres régionaux aujourd'hui (ANSM), les « plus de 30 centres » du texte (p. 5) ; à l'examen, 30 | `rsq-ech-s26` (C), `rsq-rv-centralise`, `rsq-an-2324s1-q16` (A) |

**Points douteux** (`ATTENTION (douteux)`), dits dans la carte sans changer sa clé :

| Partie, page | Le point | Carte |
|---|---|---|
| 1, p. 3 | AstraZeneca « interdit pour les jeunes de moins de 30 ans » : c'est la recommandation britannique (JCVI, 7 avril 2021, puis moins de 40 ans le 7 mai) ; en France, la HAS l'a réservé aux 55 ans et plus le 19 mars 2021, comme le disait le cours 2025-26 (p. 8). Et l'expérience anglaise « entre novembre 2020 et janvier 2021 » : autorisé au Royaume-Uni le 30 décembre 2020, injecté à partir du 4 janvier 2021 | `rsq-qc-astrazeneca` (C), `rsq-qr-55-ans`, `rsq-qc-covid` (C) |
| 1, p. 3 | les thromboses du vaccin d'AstraZeneca apparues « en avril », à Rouen, puis « notamment en Israël » : le signal date de mars 2021 (suspension en France le 15 mars, HAS le 19 mars), et Israël n'a pas employé ce vaccin (campagne Pfizer ; Times of Israel, avril 2021) | `rsq-qc-astrazeneca` (B) |
| 1, p. 8 ; 2, p. 2 | le risque réel des vaccins à ARN : « 27 % » d'arrêts de travail « pendant 4 jours » (partie 1) ou « de 2 à 3 jours » (partie 2) ; aucune source ne tranche. Les « 5 % de covid graves » restants, eux, ne sont pas une erreur : 1 forme grave contre 30, 96,7 % d'efficacité à six mois (Thomas et al., NEJM 2021) | `rsq-qc-trois-facettes` (B) |
| 1, p. 8 | le Spasfon, sans effet bénéfique démontré, « ni d'effets indésirables d'ailleurs » : son RCP mentionne éruptions, urticaire, œdème de Quincke, choc anaphylactique (BDPM) | `rsq-qc-placebo` (C) |
| 2, p. 5 | « à différencier de l'effet indésirable secondaire » (un antidiabétique qui fait maigrir) : c'est un effet secondaire, non nocif ; « indésirable secondaire » se contredit | `rsq-qc-evitabilite-alea` (B) |
| 3, p. 4 | le tramadol et la codéine « passés en régime de prescription de stupéfiant » : depuis le 1er mars 2025, une ordonnance sécurisée (ANSM), une partie des règles des stupéfiants, sans en être | `rsq-qc-dependance` (E) |
| 3, p. 6 | les rapports des firmes « tous les 6 mois, puis au bout de 2 ans tous les ans, et au bout de 5 ans tous les 5 ans » : c'est l'ancien rythme ; aujourd'hui, sauf date fixée par l'Europe, six mois pendant deux ans, un an pendant deux ans, puis trois ans (directive 2010/84/UE, art. 107 quater ; liste EURD) | `rsq-qc-firmes` (A) |
| 3, p. 7 | le rétatrutide, « l'asso de 3 peptides (GIP, GLP1, Glucagon) » : un seul peptide, agoniste des trois récepteurs (Jastreboff et al., NEJM 2023) | `rsq-qc-iatrogene` (E) |
| 3, p. 10 | le Stevens-Johnson, « un décollement de 10-15 % du revêtement cutané » : moins de 10 % ; de 10 à 29 %, le syndrome de chevauchement ; 30 % et plus, le Lyell (PNDS « Nécrolyse épidermique », HAS, 2023) | `rsq-rv-sjs-lyell` |
| 3, p. 12 | la metformine, « on arrête le ttt pendant 3j » en cas de déshydratation : le RCP demande un arrêt temporaire, sans durée, et de contacter un professionnel de santé (Glucophage, rubrique 4.4) | `rsq-qc-metformine` (C) |
| 2, p. 3 (en gris) | la vaccination « inventée par Pasteur il y a 150 ans » : la vaccine de Jenner date de 1796 ; Pasteur a fait les premiers vaccins atténués (choléra des poules, 1879-1880 ; charbon, 1881 ; rage, 1885), ce que les « 150 ans » arrondissent | aucune |
| 3, p. 7 | l'ANSM « avec son centre à Paris » : son siège est à Saint-Denis | aucune |

## Les erreurs du Ronéosaure 2025-26

Le Ronéosaure n'est pas le ronéo de l'année : ses erreurs restent dites par un
**ATTENTION nu**, sans genre, dans la carte qui tient la notion ; elles n'entrent pas
dans `contenu/ERRATA_RONEOS_2026-27.md`. Celle des « 30 CRPV », que le ronéo 2026-27 redit,
a pris le genre de l'année. L'obligation « graves ou inattendus (décret 2005) » n'est
plus une erreur du cours : le ronéo 2026-27 dit l'obligation pour tous.

| Page | Le ronéo 2025-26 dit | Retenu | Sorte | Carte |
|---|---|---|---|---|
| 3 | les AINS « formellement contre-indiqués dans la grossesse » | contre-indiqués dès 24 SA (6e mois), à éviter avant (ANSM ; FC n°5 p. 14) | point douteux | `rsq-qc-grossesse-douleur` C (absente) |
| 4 | les analogues du GLP-1 « peuvent provoquer des fasciites nécrosantes » | gangrène de Fournier et surrisque d'amputation : les gliflozines (ANSM, EMA) | point douteux | `rsq-qc-glp1` E |
| 4 | myocardite post-vaccinale « 0,1 % », « aucun mort » | au plus ≈ 0,01 % chez l'homme de 12-29 ans (EPI-PHARE 2021) | point douteux | `rsq-qc-covid` |
| 5 | phase I au Royaume-Uni : « la mort de quatre participants » | TGN1412 (2006) : aucun mort ; BIA 10-2474 (Rennes, 2016) : un mort | point douteux | `rsq-qc-benefice` |
| 7 | spray d'« eau de mer » vasoconstricteur | les décongestionnants vasoconstricteurs ; le ronéo 2026-27 dit juste (partie 1, p. 5) | remarque, sans ATTENTION | `rsq-qc-risque` E |
| 8-9 | pholcodine : « en 2009, la Suède », « la France en 2024 » | Suède 1989, Norvège 2007 ; France 8/09/2022 (ANSM) | point douteux | `rsq-fa-pholcodine` (absente) |
| 9 | IPP : « 8 semaines » au plus, « 10 ans » en moyenne | HAS 2022 : 4 semaines, 4 à 8 dans l'œsophagite | point douteux | `rsq-qc-reevaluer` C |
| 10 | H1N1 « en 2011 », « risque réel nul » | 2009-2010 ; 312 décès en France (InVS) | point douteux | `rsq-fa-trois-risques` |
| 14 | « ANSM (agence nationale de sécurité des médicaments) » | l'abréviation de la diapositive elle-même (partie 3, p. 6), non une prise de notes ; le nom complet dans le texte de 2026-27 (p. 7) | remarque, sans ATTENTION | `rsq-fa-acteurs` |
| 3 | ASMR « I = Novateur » | le cours 2026-27 dit « très rare, novateur » ; la HAS, « majeure » : une description, non une erreur | remarque, sans ATTENTION | `rsq-fa-asmr` |

**L'errata de la promo 2025-26** (p. 16) proposait « interaction entre le lamictal et le
xeroquel » : **rejeté**, et le ronéo 2026-27 le confirme : « après recherche, pas
d'interaction » (partie 3, p. 12 ; `rsq-qc-lamotrigine` C).

## Les schémas et les figures

**Cinq figures du ronéo 2026-27**, extraites en PNG à leur résolution d'origine
(partie 3) : l'évaluation du rapport bénéfice/risque (p. 4, `rsq-rapport-benefice-risque.png`),
les essais contre la vie réelle (p. 5, `rsq-essais-vie-reelle.png`), les acteurs en
France (p. 6, `rsq-acteurs-france.png`), la pyramide des acteurs de la pharmacovigilance
française (p. 8, `rsq-acteurs-pyramide.png`), les lettres de 2010 sur la lamotrigine
(p. 11, `rsq-lamotrigine-2010.png`). **Trois autres sont les mêmes diapositives que la FC
2025-26**, plus nettes là : la balance (partie 1, p. 2), le décideur et la victime
(partie 1, p. 4), le système français (partie 3, p. 7) ; on garde la version nette, et la
légende cite les deux pages. **Aucune photographie de patient** : le Lyell de la
partie 3, p. 9, n'est pas repris. Les quatre autres figures de la FC 2025-26
(l'évaluation globale, avant la commercialisation, de la déclaration à l'action, les dix
éléments) n'illustrent plus que les cartes de 2025-26 et quelques annales.

**Cinq figures redessinées** (`schemas.py`) pour les corrections : `eim-types.svg` et
`avant-prescrire.svg`, réécrites sur la partie 2 ; trois nouvelles, `benefices-types.svg`
(les quatre bénéfices), `trois-risques.svg` (réel, vécu, perçu) et
`surdosage-dependance.svg` (surdosage, pharmacodépendance, addiction).

**Un schéma cliquable**, `pharmacovigilance.svg` (6 zones : déclarants, CRPV, ANSM, EMA,
OMS, firmes), relu sur la pyramide des acteurs de la partie 3, p. 8 : les phrases des
zones citent l'année ; VigiBase et le pays rapporteur y restent, dits « FC 2025-26 ».

**La planche à légender des dix éléments** (`rsq-pl-balance`) est **absente du cours
2026-27** : elle garde la diapositive de la FC 2025-26 (p. 17), parce que trois
rédactionnelles d'annales demandent ces dix points.

**160 QCM sur 161 illustrés (99 %)**, 193 notes sur 210. Sans figure : `rsq-qc-vaccins`
(absente du cours 2026-27).

## Le lexique

Huit termes, chacun avec son **origine grecque ou latine** ; pages mesurées dans le texte
des trois ronéos 2026-27 (`chercher_pages.py`, page de garde exclue), puis de la FC
2025-26 :

| Terme | Origine | Pages 2026-27 |
|---|---|---|
| Pharmacovigilance | grec phármakon + latin vigilantia | partie 1 p. 6-7 ; partie 2 p. 7 ; partie 3 p. 2, 5-10, 12 |
| Iatrogène | grec iatrós + -genḗs | partie 3 p. 2 |
| Aléa thérapeutique | latin alea + grec therapeutikós | partie 2 p. 5-6 ; partie 3 p. 10-12 |
| Mésusage | mot français, de mésuser | partie 3 p. 3-4 |
| **Toxidermie** (nouveau) | grec toxikón + dérma | partie 3 p. 9-11 |
| **Pharmacodépendance** (nouveau) | grec phármakon + latin dependere | partie 2 p. 6 ; partie 3 p. 3-4 |
| Anaphylaxie | grec aná + phúlaxis (Richet, 1902) | — (FC 2025-26, p. 8, 9, 11) |
| Curare | espagnol curare, du caraïbe urari — ni grec ni latin | — (FC 2025-26, p. 8, 9, 11) |

Les deux termes nouveaux reprennent des racines de la table commune (`tox(i)-`,
`derm(o)-`, `pharmac(o)-`, `dependere (latin)`) ; ils sont proposés à `etymologies.json`
(brouillon `etym/bmct_risques.json`, vérifiés sur le Dictionnaire de l'Académie
française, le TLFi et le Wiktionnaire), et leurs textes sont déjà écrits dans la forme
que `appliquer_etymologies.py` produirait. Aucun n'existait dans un autre paquet.
« Addiction » n'est pas pris : le chapitre de la neurotransmission l'emploie davantage.

## L'échelle : Simple → Moyen → Annale (C20, 16/10/2026 ; relue le 19/10)

L'échelle étendue à la BMCT pour l'examen du 4/11 : sous les annales, 42 cartes Simple
(`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 9 cartes
Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction).
Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`) ; les QROC
reçoivent le schéma nu.

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `benefice-risque` | 4 | 1 | 8 |
| `benefice-medicament` | 2 | 1 | 1 |
| `risque-medicamenteux` | 10 | 2 | 16 |
| `eim` | 10 | 2 | 25 |
| `pharmacovigilance` | 9 | 2 | 20 |
| `prescrire-risque` | 7 | 1 | 9 |

**Le schéma** `ech-risque`, « Risque médicamenteux », donne 126 fichiers (complet,
troués, à lettres), décrit dans `schemas.py` (`ECH_RISQUE`, `TROUS_*`, `LETTRES_*`) et
dessiné par `echelle.py`, copie exacte du modèle du skill. Sa légende cite désormais le
ronéo 2026-27.

**Le réalignement du 19/10** : les 51 marches ont été relues contre les trois ronéos.
48 citent leur page de l'année et leurs justifications sont réécrites sur lui. **Trois
marches changent, avec leur case du schéma**, parce que le ronéo 2026-27 change le fait
qu'elles portaient : `rsq-ech-s40` (l'obligation de déclarer : « tous les effets
indésirables » ; case « Obligation : tous les effets »), `rsq-ech-s38` (la dépendance par
les opioïdes et les benzodiazépines ; case « pharmacodépendance, addiction »),
`rsq-ech-s24` (l'Europe prend les décisions ; case « elle prend les décisions »). Les
clés ne bougent pas (A, B, C toujours réparties ; Moyen d'une à trois vraies), aucun
libellé visible ne donne la case vide. **Trois marches sont absentes du cours 2026-27**,
leur fait restant vrai : `rsq-ech-s4` (« moins de 1 % » de risques graves),
`rsq-ech-s8` (le contraceptif d'Europe de l'Est), `rsq-ech-s16` (les études animales) ;
leurs cases restent sur le schéma.

**Sans marche** (les pages sont celles de la FC 2025-26) :
- Mode de vie — 2023/2024 Q18 A, 2022/2023 S1 Q.20 A, 2021/2022 S1 Q.20 A, 2020/2021 S2 Q.14 A, 2019/2020 S2 Q.15 D : absent de la liste des facteurs (p. 13, et partie 2, p. 6), la notion vient de la FC n°5 et ses clés se contredisent (CONFLITS) ; une marche trancherait.
- Surdosage volontaire — 2023/2024 Q18 B, 2022/2023 S1 Q.20 B, 2021/2022 S1 Q.20 B, 2020/2021 S2 Q.14 B, 2019/2020 S2 Q.15 A : le cours dit « surdosage accidentel » (partie 2, p. 6 ; partie 3, p. 3) sans parler du volontaire ; la justification s'appuie sur le cours 2023-24 (p. 15). La marche s30 (posologies normales) en donne le fond.
- Classe du médicament — 2020/2021 S2 Q.14 E : « faux selon la clé », aucune page du cours.
- Conséquences de la iatrogénie — 2022/2023 S1 Q.16 A-D, 2020/2021 S2 Q.13 A-D, 2020/2021 S1 Q.14 A : écologiques, économiques, éthiques, chimiques, dépenses de santé ; aucun cours ne les nomme.
- 2020/2021 S1 Q.14 D — « peut ne pas avoir de conséquences néfastes » : point douteux déclaré dans CONFLITS ; aucune marche, pour ne pas trancher.
- Gravité de la pathologie — la moitié de 2018/2019 S2 Q.16 D, 2016/2017 S1 Q18 E et 2015/2016 S1 Q20 D : le SMR n'a pas de case sur le schéma ; s3 ne prépare que l'autre moitié, les alternatives.
- Activité physique — 2023/2024 Q17 D, 2022/2023 S2 17. D, 2020/2021 S1 Q.15 B, 2019/2020 S1 Q.15 B : le cours ne la nomme pas ; seule la liste fermée des questions (s12-s14, m9 A) y répond.
- 2020/2021 S2 Q.16 B — la mauvaise métabolisation : FC n°5 (p. 15-16, 21), autre chapitre.
- Sous-notification et effet non expliqué — 2023/2024 Q15 B E, 2020/2021 S2 Q.18 C E : justifiés par le cours 2023-24 (p. 9).
- Pharmacoépidémiologie et détection automatisée — 2022/2023 S1 Q.19 A B, 2021/2022 S1 Q.19 A B, 2020/2021 S2 Q.17 A E, 2019/2020 S1 Q.19 E, 2018/2019 S2 Q.16 C, 2016/2017 S1 Q18 B, 2017/2018 S2 Q.16 C, 2015/2016 S1 Q20 A : aucun cours ne la porte, et 2020/2021 S2 Q.17 A et E est un cas ouvert (CONFLITS).
- 2019/2020 S1 Q.19 C — les registres de patients : une seule mention (lamotrigine, FC 2025-26, p. 15), sans case.
- 2019/2020 S2 Q.20 A — l'acceptabilité ne dépend pas de l'agence : « faux selon la clé », sans page du cours.
- 2018/2019 S1 Q.15 C — l'effet hors AMM : la définition de 2012 (CSP, art. R. 5121-152), pas celle du cours, « aux posologies normalement utilisées » (partie 2, p. 5).
- 2018/2019 S2 Q.16 B — le rôle des patients dans la décision : pas de phrase du cours qui le porte, sinon l'alerte des troubles du cycle (partie 3, p. 7).
- 2018/2019 S2 Q.18 C — les mesures d'adaptation (le vaccin restreint selon l'âge, partie 1, p. 3) : pas de case ; le schéma garde l'évolution jusqu'au retrait (s6).
- Arrêt ou contre-indication systématique — 2017/2018 S1 Q.15 B, 2016/2017 S1 Q13 C, 2015/2016 S1 Q18 C : le cours 2024-25 (p. 18) et le ronéo 2026-27 (le non-grave, on s'en accommode, partie 3, p. 2), sans case.
- 2017/2018 S2 Q.18 A — le bénéfice « très rarement symptomatique » : cours 2023-24 (p. 8) ; « peu de médicaments curatifs » (partie 1, p. 6).
- Paracétamol, Quincke sous IEC, acide valproïque in utero — 2016/2017 S2 Q17 C D E, 2015/2016 S1 Q16 C D E : hors du cours de ce chapitre (cours 2023-24, FC n°5) ; le D est en CONFLITS, aucune marche ne le touche.

## Absent du cours 2026-27

Dix-huit cartes **entières** que les trois ronéos du 16/10/2026 ne portent plus. Elles
restent, citent la FC n°9 2025-26 à leur page (`fiche=FC2526`, donc avec le badge
« Cours 2025-26 »), prennent le tag `absent-2026` et la phrase « Absent du cours
2026-27 » en tête de l'explication (`ABSENTS_2026`, `ORIGINE_ABSENTS`) :

| Carte | Ce que le cours 2026-27 ne dit plus |
|---|---|
| `rsq-fa-paliers`, `rsq-qc-grossesse-douleur` | la douleur de la femme enceinte : les paliers, le paracétamol et l'autisme, les AINS |
| `rsq-qr-sep` | le vaccin contre l'hépatite B et la sclérose en plaques (la rumeur revient pour la COVID, en risque perçu : `rsq-qc-perceptions` B) |
| `rsq-fa-chiffres-risque`, `rsq-ech-s4` | 95 % de bénéfice, 15 à 20 % d'effets fréquents, moins de 1 % de graves |
| `rsq-qc-vaccins`, `rsq-qr-rougeole` | les adolescents vaccinés à 9 mois, le vaccin peu efficace chez l'âgé |
| `rsq-fa-pholcodine`, `rsq-qc-pholcodine` | la pholcodine et les curares |
| `rsq-qc-formes-eim` | les dents jaune fluo et les troubles cognitifs sous acide valproïque (le réflexe iatrogène reste : `rsq-qc-iatrogene`) |
| `rsq-qr-evenement`, `rsq-rv-effet-evenement` | l'effet contre l'événement indésirable |
| `rsq-fa-europe` | l'AMM européenne, le pays rapporteur, le remboursement |
| `rsq-qr-vigibase` | VigiBase, VigiLyze |
| `rsq-ech-s16` | les études animales, la tératogenèse |
| `rsq-qc-smr-asmr`, `rsq-ech-s8` | le contraceptif retiré en France, gardé en Europe de l'Est ; la France et les États-Unis |
| `rsq-pl-balance` | la diapositive des dix éléments de l'évaluation bénéfice/risque |

## À relire

**Une carte `a-relire`** : `rsq-an-1920s2-qroc2` (pourquoi le développement ne suffit
pas, les outils en vie réelle), dont le verso rassemble plusieurs pages, deux cours et
deux annales : aucune page ne le porte entier.

## Questions pour Vincent

- **AstraZeneca, 30 ou 55 ans ?** Le ronéo 2026-27 écrit le vaccin « interdit pour les
  jeunes de moins de 30 ans » (partie 1, p. 3) : c'est la recommandation britannique ; en
  France, il a été réservé aux 55 ans et plus, ce que disait le cours 2025-26. La carte
  `rsq-qr-55-ans` demande l'âge retenu **en France** (55 ans) et dit le doute. Si la
  professeure a vraiment parlé de 30 ans en cours, faut-il une carte sur le chiffre
  britannique ?
- **2020/2021 S2 Q.17** (« sont identifiés (signal) ») : la clé imprimée, BCD, est
  gardée, et A et E portent un ATTENTION. Garder BCD, ou tenir A et E pour vrais ?
- **2016/2017 S1, la table décalée** : CDE pour la Q17, BDE pour la Q18, la « Q16 : BE »
  orpheline non cartée. À confirmer sur un autre exemplaire du sujet.
- **2019/2020 S2 Q.14 A** (« à prendre en compte indépendamment du bénéfice ») : la
  carte retient BE contre la clé imprimée ABE. Garder BE, ou revenir à ABE ?
- **La planche des dix éléments** reste, absente du cours 2026-27, pour les trois
  rédactionnelles qui la demandent. Faut-il en faire une sur le schéma de l'évaluation
  du rapport bénéfice/risque de 2026-27 (partie 3, p. 4) ?

## Décisions prises en route

- **Une carte n'est confirmée que si sa notion centrale est dans le cours de l'année** ;
  ses propositions de 2025-26 le disent une à une (« FC 2025-26, p. 2 ; absent du ronéo
  2026-27 »). `rsq-qc-vaccins` (la rougeole à 9 mois) et `rsq-qc-formes-eim` (les deux
  cas) sont absentes même si une de leurs propositions est encore enseignée.
- **Les cartes absentes citent la FC 2025-26 à leur page** (`fiche=FC2526`, comme
  `bmcp_proteines`) plutôt que sans page : le badge « Cours 2025-26 » reste, la page
  aussi.
- **Les figures identiques** restent celles de la FC 2025-26, plus nettes ; la légende
  cite les deux pages.
- **Les trous changés** : `rsq-fa-types-benefice` c3 (« disease modifier »),
  `rsq-fa-trois-risques` c3 (« perçu »), `rsq-fa-avant-prescrire` c5 (« précisée »).
- **Les erreurs datées** se répondent à l'examen comme le professeur (« 30 CRPV ») ; la
  carte donne le fait d'aujourd'hui.
- **`EXAMENS` n'est pas déclaré** : le partiel du 4/11 se règle dans l'application.
- **Les questions répétées** d'une session à l'autre ont chacune leur carte.

## La contre-relecture du 19/10/2026

Un second passage a relu chaque carte nouvelle ou changée contre sa page et sa figure,
pour la réfuter. Ce qu'il a changé :

- **Les « 5 % de covid graves »** (partie 1, p. 8) ne sont pas une erreur : à six mois,
  l'essai de Pfizer compte 1 forme grave sous vaccin contre 30 sous placebo (96,7 %,
  Thomas et al., NEJM 2021). L'ATTENTION de `rsq-qc-trois-facettes` B ne garde que les
  « 4 jours » contre « 2 à 3 jours ».
- **AstraZeneca écarté « parce que les vaccins à ARN existaient »** : le ronéo 2026-27 ne
  le dit pas (partie 1, p. 3 : la balance des moins de 30 ans) ; c'est la FC 2025-26
  (p. 7-8). Les citations sont corrigées dans `rsq-fa-balance`, `rsq-qc-balance` B,
  `rsq-qc-covid` C, `rsq-ech-s3` A, `rsq-qr-55-ans` et l'annale 2021/2022 S2 Q.15 E ;
  « pas de risque grave sans alternative » cite la FC 2025-26 (p. 6, 17) et l'Esbriet
  (partie 1, p. 2) dans 2020/2021 S2 Q.19 D et 2019/2020 S2 Q.20 C.
- **Deux points douteux de plus** sur la même page, dits dans `rsq-qc-astrazeneca` B :
  les thromboses apparues « en avril » (le signal date de mars 2021) et « notamment en
  Israël », qui n'a pas employé ce vaccin.
- **`rsq-qc-cinq-questions` C** demandait si le médicament était « le plus récent de sa
  classe », que le cours ne rendait pas clairement faux (« s'assurer qu'il n'y ait pas
  de nouveaux traitements », partie 1, p. 5) : remplacé par « le patient réclame-t-il ce
  médicament ? », faux et tiré du tramadol (partie 3, p. 4).
- **La case du schéma de `rsq-ech-s38`** dit « pharmacodépendance, addiction » : la ligne
  effacée est la réponse de la marche.
- **Les explications de `rsq-ech-s11` et `rsq-ech-m8`** comptent les quatre bénéfices de
  l'année (le « disease modifier » à la place du critère intermédiaire).

## Régénérer

```powershell
..\..\..\app\.venv\Scripts\python.exe generer.py
```
