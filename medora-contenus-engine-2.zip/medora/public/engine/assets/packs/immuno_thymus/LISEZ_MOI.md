# Thymus et lymphopoïèse T — paquet Immunologie

77 notes, 147 cartes. Chapitre `chap-ue-immunologie-fc5` de l'UE Immunologie,
ordre 5. Cours du **Pr Dubucquoi, le 02/10/2026**, « TCR et lymphopoïèse T » :
**la base est le ronéo 2026-27** (Ronéo & Juliette, 16 pages), sur lequel le
chapitre a été réaligné le 11/10/2026. Il était carté jusque-là sur la FC n°5
du Ronéosaure 2025-26 (même professeur, 13 pages), qui n'est plus qu'un appoint.
Annales de huit sessions (huit QCM, trois QROC), tirées du Ronéosaure 2024-25 et,
pour 2024/2025, du sujet déposé le 15/10/2026. Examen de novembre.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| Texte à trous | 11 | 74 |
| QRM | 31 | 31 |
| QRU | 3 | 3 |
| QROC | 13 | 13 |
| Recto-verso | 7 | 7 |
| Lexique | 10 | 10 |
| Schéma cliquable | 2 | 9 |
| **Total** | **77** | **147** |

Dont **11 annales** sur 8 sessions : 8 QRM et 3 QROC rédactionnels (en
recto-verso, avec le corrigé imprimé). **31 QCM sur 34 illustrés (91 %)**,
55 notes sur 77. **9 cartes portent un piège du ronéo** (thème « Pièges des
ronéos »). **Aucune carte absente du cours 2026-27.**

Six thèmes, dans l'ordre du cours, tous déjà dans `THEME_LABELS` :

| Clé | Libellé |
|---|---|
| `recepteur-t` | Le récepteur T (TCR) et son complexe de signalisation |
| `recombinaison-vdj` | Réarrangements V(D)J et diversité du répertoire (partagé avec l'ontogenèse B) |
| `thymus` | Le thymus (partagé avec immuno_organes) |
| `differenciation-thymocytes` | Étapes de différenciation des thymocytes |
| `repertoire` | Répertoire et éducation des lymphocytes (partagé avec immuno_temporelle) |
| `lt-peripheriques` | Les LT matures et leurs sous-populations |

Une clé qui porte un chiffre est lue comme une provenance (`scopes.is_theme`) :
d'où `recepteur-t` plutôt que `tcr-cd3`.

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-immuno-thymus-2627` — Ronéo & Juliette, « TCR et lymphopoïèse T » (16 p.) | **2026-27** | **la base**, déclarée avec `chapitre=` : `IMMUNOLOGIE/TCR ET LYMPHOIESE T.pdf`. Cours du 02/10/2026, 11 h-12 h : le TCR (reconnaissance, structure, CD3, gènes et diversité, bilan, p. 2-8), le thymus et la lymphopoïèse T (lobule, cheminement, sélections, AIRE, avidité, répertoire amputé, p. 9-13), les co-récepteurs, le pool des LT, la production au cours de la vie (p. 14-16). Les 56 notes du cours portent leur page ; c'est ce que le lecteur ouvre |
| `src-fc-immuno-thymus` — Ronéosaure, « FC n°5 Thymus et lymphopoiëse » (13 p.) | 2025-26 | **appoint**, sans `chapitre=` : ce qu'il disait de plus (« 90 % » de mort par négligence, la thymectomie, la « question d'examen » BCR-TCR) est cité dans le texte des cartes ; il reste la page de `lex-thymectomie` |
| `src-annales-immuno-thymus` — Ronéosaure, « IMMUNO n°5- Thymus et lymphopoïèse T » (6 p.) | 2024-25 | neuf des dix annales, table p. 5-6 |
| `src-annales-immuno-reponse-t` — Ronéosaure, « IMMUNO n°9 - Réponse adaptative T et mémoire » (9 p.) | 2024-25 | la question 2016/2017 S1 Q4 (le répertoire T) |
| `src-sujets-immuno-2425` — sujet de système immunitaire 2024/2025, session 1 (3 p.) | 2024-25 | dépôt du 15/10/2026 : la Q3 (`SRC["sessions"]["2024/2025 S1"]`) ; sujet sans corrigé, clé déduite du cours ; déclaré à l'identique dans chaque chapitre d'immunologie qui en a une question |
| corrigé officiel des QROC 2023/2024 (02/11/2023) | 2023-24 | dépôt du 15/10/2026 : celui du QROC 2, comparé à la carte ; cité, pas déclaré (la session garde son polycopié) |
| tableau d'erreurs d'immunologie 2026-27 | 2026-27 | aucune entrée sur ce cours au 11/10/2026 (deux, sur le CMH) |
| erratas d'annales d'immunologie 2024-25 | 2024-25 | aucune entrée sur ces questions |

Les vérifications faites hors du cours sont citées dans la carte qui s'en sert :
Janeway's Immunobiology (CD3, ITAM, chronologie β puis α au stade DN puis DP,
environ 2 % de thymocytes double positifs qui survivent, Lck, chromosomes des
gènes d'immunoglobulines, règle 12/23) ; Probst et al., Eur J Immunol 2004
(espaceur de 23 des gènes Vα) et Franchini et al., PLoS One 2009 (Vβ et 3'Dβ à
23, 5'Dβ et Jβ à 12) ; Call et al., Cell 2002 (stœchiométrie du CD3) ; Padovan et al., Science 1993 (deux chaînes α) ; Klein
et al., Nat Rev Immunol 2014 (CMH II des mTEC) ; Watanabe et al., Nature 2005
(Hassall, TSLP) ; French et al., J Clin Invest 1992 (clusterine au centre des
corps de Hassall, hypothèse de l'élimination des débris d'apoptose) ; Ferre et
al., JCI Insight 2016 (triade de l'APECED) ; Palmer, Front Immunol 2013
(involution thymique précoce) ; Douek et al., Nature 1998 (production thymique
chez l'adulte).

## Le réalignement sur le ronéo 2026-27 (11/10/2026)

**Toutes les notes ont été relues sur le ronéo de l'année.** Les 56 notes du
cours portent désormais sa page et citent la fiche 2026-27 : elles perdent le
badge « Cours 2025-26 ». Les annales citent ses pages dans leurs justifications.
Le gris du ronéo 2026-27 n'est pas défini (voir plus bas).

**Ce que le ronéo 2026-27 dit autrement, et ce qui a été réécrit** (23 notes) :

- **Le plan** : deux grandes parties au lieu de cinq ; les co-récepteurs, le
  pool des LT et la production au cours de la vie sont des parties à part.
  Toutes les sections et toutes les pages des cartes ont changé.
- **Le CD3** (`thy-fa-cd3`, `thy-qc-cd3`) : le ronéo 2026-27 insiste sur le CD3
  marqueur de tous les LT (CD19 pour les LB), sur les motifs ITAM et sur le
  « signal 1 », ou cognate ; il ne parle plus de rapprochement des TCR ni de
  phosphorylation. Le texte à trous et deux propositions suivent.
- **Le cheminement des thymocytes** (`thy-fa-etapes`, `thy-qc-dn-dp`) : une
  diapositive nouvelle (p. 10) — entrée des progéniteurs à la jonction
  cortico-médullaire, DN dans la corticale externe, « l'événement fondateur du
  LT, c'est d'exprimer un TCR » (en rouge), ETR à la sortie.
- **Les chiffres** (`thy-fa-chiffres`, `thy-qc-positive` C, `thy-qr-negligence`) :
  plus de « 90 % » de mort par négligence ; 98 % des thymocytes éliminés au total
  (p. 13), et une spécificité sur un million (p. 8).
- **Le répertoire amputé** (`thy-fa-lt-matures`, `thy-qc-lt-matures`,
  `thy-rv-double-restriction`) : « amputé, restreint, linéaire » (p. 13) au lieu
  de « doublement restreint » ; endocytose au lieu de « dégradation lysosomale »
  pour la classe II (p. 11).
- **La production au cours de la vie** (`thy-fa-cinetique`, `thy-qc-cinetique`) :
  activité maximale in utero, fonctionnement fortement réduit après
  l'adolescence, tissu adipeux, stock de LT constitué dans les premières années ;
  la thymectomie n'y est plus (propositions remplacées, dit dans l'explication).
- **Le thymus** (`thy-qc-thymus`) : les épithéliales qui « nourrissent » en
  facteurs de croissance ne sont plus dans le cours (C remplacée par les CPA
  émigrées de la moelle) ; E porte désormais sur les corps de Hassall (rôle clé
  dans la tolérance), avec leur point douteux ; la clé passe de ACD à **ADE**.
- **La sélection positive** (`thy-qc-positive`) : « avidité intermédiaire » au
  lieu d'« affinité faible à modérée » (p. 13).
- **Les co-récepteurs** (`thy-qc-corecepteurs`, `thy-rv-corecepteurs`) :
  stabilisation et renforcement du signal, kinases, « deux à pousser sur la
  pédale » ; co-récepteurs, pas co-stimulation (p. 14), avec la figure de la
  diapositive 26.
- **La « question d'examen » BCR-TCR** (`thy-qc-bcr-tcr`, `thy-rv-bcr-tcr`) n'est
  plus écrite comme telle ; le professeur fait « sans cesse le parallèle » (p. 2)
  à chaque étape, et les deux cartes le suivent (marqueur CD19/CD3, sélection
  positive propre au LT).
- **Les LT γδ** (`thy-rv-gamma-delta`) sont en noir (p. 2) : ils perdent le tag
  `edn` que leur donnait le gris « pas à apprendre » de 2025-26.
- **Les corps de Hassall** (`thy-qr-hassall`) : la question ne dit plus
  « épithéliale » ; elle reprend la diapositive, « rôle clé dans la tolérance
  immunitaire ».
- Retouches de formulation, pages refaites : `thy-fa-tcr`, `thy-fa-negative`,
  `thy-qc-reconnaissance`, `thy-qc-structure`, `thy-qc-combinatoire`.

**Les erreurs du Ronéosaure 2025-26 ont disparu** : le ronéo 2026-27 écrit
« restriction syngénique » (en rouge), « Bilan » et « diversité d'association »,
« unique complexe CMH-peptide », et donne le nom d'émigrants thymiques récents
aux LT qui sortent du thymus. Les ATTENTION sans genre qui les signalaient sont
retirés ; les cartes le disent en une phrase (`thy-qr-syngenique`,
`thy-qc-cheminement`).

**Notes nouvelles** (10) : `thy-qc-cd3-marqueur` (le CD3 marqueur, ITAM, signal
1, CD3 γδ ≠ TCR γδ, p. 4) ; `thy-fa-signaux` (heptamère, nonamère, 12 et 23,
boucle excisée, p. 6) ; `thy-qc-cheminement` (entrée, DN, cTEC, ETR, p. 10-11) ;
`thy-qc-education` (« pas trop », répertoire unique, pas de sélection positive
pour le LB, antigènes non présentables, p. 11-13) ; `thy-qc-aire-apeced`
(« pas la totalité », homunculus immunologique, APS-1/APECED, p. 12) ;
`thy-qc-pool` (clones T, 10¹² LT, 0,01 à 0,1 % par pathogène, stock constitué
tôt, p. 14-16) ; `thy-qr-etr` ; `thy-qr-deletion` ; et deux termes de lexique,
`lex-deletion-clonale` et `lex-polyendocrinopathie`.

**Les figures** : les dix figures de la FC 2025-26 sont remplacées, sous les
mêmes noms, par celles du ronéo 2026-27 (les mêmes diapositives, en meilleure
résolution) ; deux sont nouvelles, `cheminement-thymocytes.png` (p. 10) et
`corecepteurs-cd4-cd8.png` (p. 14) ; les trois vignettes des sélections
(`selections-thymiques.png`, FC 2025-26 p. 9-10), sans équivalent dans le ronéo
de l'année, sont retirées et remplacées par le cheminement et la courbe
d'avidité.

## Ce que le cours a dicté

- **Le gris n'est pas défini** : le ronéo 2026-27 n'en dit rien en introduction.
  Ce sont les titres des diapositives et une remarque des rédacteurs, « Les LT
  non-conventionnels ne sont pas le sujet de ce cours » (p. 2) : leur voix, qui
  se carte comme le reste (`thy-rv-gamma-delta`, sans `edn`).
- **Le rouge** : la reconnaissance spécifique (TCR) et la transmission
  intracellulaire (CD3) (p. 4) ; « une quasi-infinité de TCR (10¹⁵) » et les
  « réarrangements intrachromosomiques somatiques » (p. 4) ; « l'événement
  fondateur du LT, c'est d'exprimer un TCR » (p. 10) ; la « restriction
  syngénique » (p. 11). Chacun a sa carte.
- **Ce que le professeur attend** (p. 4) : savoir que le TCR est αβ ; la
  structure du CD3, « je m'en fous un peu » — l'important est que le CD3 est
  l'identité moléculaire du LT (`thy-qc-cd3`, `thy-qc-cd3-marqueur`).
- **Les pièges que le ronéo signale lui-même** : CD3 γδ et TCR γδ (p. 4), CDR3 et
  CD3 (p. 8), les chromosomes inversés à l'oral, la diapositive faisant foi
  (p. 5), « les LT ne sont pas produits dans la moelle osseuse » (p. 10).
- **Ce qui n'est pas recarté** parce qu'un chapitre existant le porte : l'anatomie
  du thymus, son involution générale, DiGeorge (immuno_organes) ; la restriction
  au soi comme rôle du HLA, le TCR sur les berges et le peptide (immuno_cmh) ; le
  répertoire générique et le « pari sur l'avenir » (immuno_temporelle).

## Ce que les annales ont dicté

| Savoir | Questions |
|---|---|
| Sélection positive et négative : où, sur quelles cellules, quels thymocytes | 2023/2024 QROC 2, 2022/2023 S1 Q.3, 2021/2022 S1 Q. 3, 2020/2021 S1 Q. 3, 2016/2017 S1 Q.3, 2015/2016 S1 Q.5 |
| Les trois mécanismes de la diversité | 2022/2023 S1 QROC 1, 2021/2022 S1 QROC 4, 2016/2017 S1 Q4 (IMMUNO n°9) |
| Cinétique de la production thymique | 2022/2023 S1 Q.3 A, 2021/2022 S1 Q. 3 E, 2020/2021 S1 Q. 3 A-B, 2016/2017 S1 Q.3 C, 2015/2016 S1 Q.5 A |
| Le TCR : hétérodimère, monovalent, un seul type, jamais muté, toujours avec CD3 | 2021/2022 S2 Q.1, 2024/2025 S1 Q3 |

Les autres questions d'IMMUNO n°5 sont déjà en cartes, avec les mêmes clés :
2023/2024 Q3 dans immuno_cmh (`cmh-an-2324-q3`) ; 2020/2021 S1 Q.1, 2020/2021 S2
Q.3 et « 2018/2019 S1 » Q.4 dans immuno_organes. Elles ne sont pas recopiées.

| Session | N° | Clé imprimée | Retenu | Polycopié | Carte |
|---|---|---|---|---|---|
| 2024/2025 S1 | 3. | aucune (sujet sans corrigé) | ABCD, déduite | sujet 2024/2025 | `thy-an-2425s1-q3` |
| 2023/2024 S1 | QROC 2 | corrigé imprimé | corrigé | n°5 | `thy-an-2324-qroc2` |
| 2022/2023 S1 | Q.3 | BE | BE | n°5 | `thy-an-2223s1-q3` |
| 2022/2023 S1 | QROC 1 | corrigé imprimé | corrigé | n°5 | `thy-an-2223s1-qroc1` |
| 2021/2022 S1 | Q. 3 | ABCDE | ABCDE | n°5 | `thy-an-2122s1-q3` |
| 2021/2022 S1 | QROC 4 | corrigé imprimé | corrigé | n°5 (= n°4) | `thy-an-2122s1-qroc4` |
| 2021/2022 S2 | Q.1 | ABDE | ABDE | n°5 | `thy-an-2122s2-q1` |
| 2020/2021 S1 | Q. 3 | BDE | BDE | n°5 | `thy-an-2021s1-q3` |
| 2016/2017 S1 | Q.3 | BE | BE | n°5 | `thy-an-1617s1-q3` |
| 2016/2017 S1 | Q4 | ACDE | ACDE | **n°9** | `thy-an-1617s1-q4` |
| 2015/2016 S1 | Q.5 | BD | BD | n°5 | `thy-an-1516s1-q5` |

Anomalies, chacune dite dans sa carte : IMMUNO n°5 imprime « Année 2023/2024 »
sans session (rangée en S1, comme `cmh-an-2324-q3`) ; « est (ou sont
exacte(s)? », parenthèse non fermée (2021/2022 S1 Q. 3, gardée) ; le QROC 4 de
2021/2022 S1 est aussi dans IMMUNO n°4, « vu pour le LB » (une carte, ici) ;
2016/2017 S1 Q4 vient d'IMMUNO n°9, et le générateur ne connaît qu'une source
par session : la carte affiche IMMUNO n°5 et son `explain` nomme IMMUNO n°9 ;
« le thymus devient fonctionnel dès la naissance » (faux, 2022/2023 S1 Q.3 A)
voisine avec « il est fonctionnel dès la naissance » (vrai, 2019/2020 S2 Q. 6 C,
immuno_organes) — les deux tiennent, la carte le dit.

## Les annales du dépôt du 15/10/2026

- **2023/2024, QROC 2** (`thy-an-2324-qroc2`) : son verso a été comparé au
  **corrigé officiel** des QROC (02/11/2023) ; il porte déjà chacun de ses
  éléments (corticale, doubles positifs, cTEC, reconnaissance globale, restriction
  syngénique, simples positifs ; médullaire, mTEC, CD, macrophages, signal de mort,
  tolérance centrale, élimination des LT « trop » autoréactifs). Rien à compléter ;
  la carte était déjà `officielle`.
- **2024/2025 S1, Q3** (le TCR) : `thy-an-2425s1-q3`, clé déduite du cours,
  illustrée par le complexe TCR-CD3 (p. 3). Rangée ici, chapitre du TCR, bien que
  sa voisine de 2023/2024 (Q.3) soit dans `immuno_cmh` : elle reformule trois de
  ses idées (A, D, E) et en ajoute deux (le CD3, les deux chaînes).

## Les clés qui ne sont pas reprises telles quelles

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2024/2025 S1 Q3 (`thy-an-2425s1-q3`) | aucune (sujet sans corrigé) ; le PDF déposé surligne A, B, C | **ABCD**, déduite du cours, non officielle | le TCR sur tous les LT (p. 10), toujours avec le CD3 (p. 3-4), deux chaînes (p. 2-3), jamais muté (p. 13), pas de forme soluble (p. 2). **D est un conflit déclaré** : le surlignage du PDF l'omet, mais la grille officielle de 2023/2024 (Q.3 D) et la table de 2021/2022 S2 (Q.1 D) cotent vraie la même idée. Ce surlignage, d'auteur inconnu, ne couvre que les Q1 et Q3 du sujet |

Les sept clés et les trois corrigés imprimés sont repris, `officielle`.
Relues contre le ronéo 2026-27, aucune ne cote faux ce que le cours de l'année
dit juste. **Une nuance est déclarée dans `CONFLITS`**, clé gardée :

| Question | Clé | La nuance |
|---|---|---|
| 2020/2021 S1 Q. 3 B, vraie | BDE | « elle persiste toute la vie » : le ronéo 2026-27 titre « Produit-on des LT toute sa vie ? » et répond que, pour les LT, « ce n'est pas du tout le cas » (p. 15), en comparaison des LB ; mais le thymus « reste actif après la naissance » et il reste des thymocytes à 40 ans (moins de 2 %) : la production décline sans s'arrêter (Douek et al. 1998) |

Et une prise de notes du ronéo (l'involution « à partir de 30 ans ») est dite
dans la justification de 2021/2022 S1 Q. 3 E, qui reste vraie : la diapositive
lui donne raison. Cas ouvert : aucun.

## Les erreurs du ronéo 2026-27

Aucune entrée sur ce cours dans le tableau d'erreurs d'immunologie de la promo au
11/10/2026 : toutes sont trouvées en relisant. Le ronéo n'est pas corrigé ;
chaque erreur est portée par une carte, avec son genre, et la carte retient la
bonne lecture. À reporter dans `contenu/ERRATA_RONEOS_2026-27.md`.

**C'est le cours lui-même** (`ATTENTION (cours)`, avec « À l'examen » puis « La
référence ») :

| Page | Le ronéo dit | Ce qui est juste | Carte |
|---|---|---|---|
| 3 | le CD3 est « un ensemble de 5 chaînes invariantes : γ, δ, ε et ζ × 2 » — comme le Ronéosaure 2025-26 (p. 3) | quatre sortes de chaînes en trois dimères (CD3γε, CD3δε, ζζ), six chaînes, ce que dessine la diapositive de la même page (Janeway ; Call et al., Cell 2002) | `thy-qc-cd3` (E) |
| 5, 10 | tous les réarrangements, β puis α, « au stade double négatif » ; le DN « commence à exprimer un TCR » — comme la diapositive p. 10 et le Ronéosaure 2025-26 (p. 5) | seule la chaîne β se réarrange au stade DN (pré-TCR) ; la chaîne α se réarrange chez le double positif (Janeway) — ce que suggère la diapositive p. 6, « ADN réarrangé dans les thymocytes DP » | `thy-qc-dn-dp` (C), `thy-fa-etapes` |
| 6 | « chaque gène V est suivi » d'un heptamère et d'un nonamère séparés par 12 nucléotides, « chaque gène J est précédé » de la même structure séparée par 23 — comme la diapositive, qui porte sur l'ADN des chromosomes 7 et 14 | dans les loci α et β du TCR, c'est l'inverse : V à 23, J à 12, Dβ à 12 en 5' et à 23 en 3' (Probst et al., Eur J Immunol 2004 ; Franchini et al., PLoS One 2009) ; le schéma est celui du locus κ des immunoglobulines (Vκ 12, Jκ 23). La règle générale, 12 avec 23, est juste | `thy-fa-signaux` |

**Prise de notes fausse** (`ATTENTION (prise de notes)`) :

| Page | Le ronéo dit | Ce qui est juste | Carte |
|---|---|---|---|
| 15 | « involution thymique à partir de 30 ans environ » | « fonctionnement fortement réduit après l'adolescence » (diapositive de la même page) ; « involution : débute à l'adolescence » (Ronéosaure 2025-26, p. 13) ; l'involution commence même avant la puberté (Palmer, Front Immunol 2013) | `thy-qc-cinetique` (E), `thy-fa-cinetique`, `thy-an-2122s1-q3` (E) |

**Points douteux** (`ATTENTION (douteux)`), dits dans la carte sans changer sa clé :

| Page | Le point | Carte |
|---|---|---|
| 9 | les corps de Hassall, « endroits où se rassemblent des thymocytes morts par apoptose » : ce sont des couches concentriques de cellules épithéliales médullaires (« structure épithéliale particulière », Ronéosaure 2025-26, p. 8 ; histologie) ; qu'ils servent à éliminer les débris d'apoptose n'est qu'une hypothèse (French et al., J Clin Invest 1992) | `thy-qc-thymus` (E), `thy-qr-hassall` |

L'espaceur de 12 donné au gène V et celui de 23 au gène J (p. 6) a d'abord été
classé « douteux » ; la relecture du 11/10 l'a passé en « cours » : la
diapositive le dessine elle-même, et les deux loci du TCR ont l'inverse, ce que
la littérature établit pour Vα, Vβ et Jβ (et Jα par la règle 12/23).

**Un écart entre deux ronéos 2026-27 du même professeur**, dit par un `ATTENTION`
sans genre : 98 % des thymocytes éliminés ici (p. 13), « environ 95 % » des
cellules produites dans Organisation temporelle (p. 10) — deux ordres de grandeur
(`thy-fa-chiffres`, `thy-qc-diversite` D).

**Signalé par le ronéo lui-même, et non repris comme erreur** : à l'oral, le
professeur a inversé les chromosomes (« 14 pour β, 7 pour α ») ; le ronéo écrit
juste et prévient (`thy-fa-genes`, `thy-qc-genes`, `thy-qu-chromosome`).

## Absent du cours 2026-27

**Aucune carte entière** : tout ce que portait le Ronéosaure 2025-26 est repris
par le ronéo de l'année, parfois autrement. `ABSENTS_2026` est vide. Ce que seul
le cours 2025-26 disait ne tient plus qu'en propositions isolées, remplacées par
des propositions de l'année, et chaque carte le dit dans son explication :

| Notion de 2025-26 | Où elle était | Ce qu'elle devient |
|---|---|---|
| après une thymectomie, le taux de LT diminue plus rapidement (p. 13) | `thy-qc-cinetique` E, `thy-fa-cinetique` | E porte sur l'involution « vers 30 ans » ; dit dans l'explication |
| les épithéliales « nourrissent » en facteurs de croissance les LT (p. 8) | `thy-qc-thymus` C | C porte sur les CPA émigrées de la moelle ; dit dans l'explication |
| environ 90 % des thymocytes meurent par négligence (p. 9) | `thy-qc-positive` C, `thy-fa-chiffres`, `thy-qr-negligence` | « un tri phénoménal » et 98 % au total ; dit dans l'explication |
| « Question d'examen : comparer BCR et TCR » (p. 3, en rouge) | `thy-qc-bcr-tcr`, `thy-rv-bcr-tcr` | « le parallèle du professeur » ; dit dans l'explication |
| « les valeurs (pourcentages) sont à apprendre » (p. 12) | `thy-fa-populations`, `thy-qc-populations` | les valeurs restent (p. 15) ; la consigne est dite de 2025-26 |

Le terme **`lex-thymectomie`** n'est plus dans le cours 2026-27 : sa définition le
dit, et sa page reste celle de la FC 2025-26 (sans `chapitre=`).

## Les schémas cliquables

| Fichier | Ce qu'on clique | Carte |
|---|---|---|
| `lobule-thymique-nu.svg` | d'après la figure p. 9 : la capsule, la zone de prolifération et de sélection positive (corticale), la jonction cortico-médullaire, la zone de la sélection négative (médullaire), un corps de Hassall | `thy-zo-lobule` (5 cartes) |
| `avidite-nue.svg` | d'après la courbe p. 13 : la mort par négligence, la sélection positive, le seuil d'affinité, la sélection négative | `thy-zo-avidite` (4 cartes) |

Six annales demandent où se passent la prolifération et les deux sélections ; la
courbe d'avidité résume les trois devenirs du thymocyte. Les zones du lobule
sont demandées par leur fonction, pas par leur nom. La médullaire est un polygone
dont le corps de Hassall est le trou (règle pair-impair) : les deux zones ne se
recouvrent pas. Les notes des zones citent le ronéo 2026-27 ; celle de la
jonction dit l'entrée des progéniteurs T (p. 10). Les figures légendées du ronéo
sont en correction.

## Les figures

Onze figures du ronéo 2026-27, extraites en PNG (900 px de large au plus, 256
couleurs), toutes du côté de la correction ; aucune n'a de nom d'étudiant. Les
deux images de la dernière page (des mèmes) ne sont pas reprises.

| Fichier | Page (diapositive) | Cartes (entre autres) |
|---|---|---|
| `tcr-alpha-beta.png` | 2 (4) | `thy-fa-tcr`, `thy-qc-reconnaissance`, `thy-qc-structure`, `thy-qc-bcr-tcr`, `thy-rv-bcr-tcr` |
| `complexe-tcr-cd3.png` | 3 (5) | `thy-fa-cd3`, `thy-qc-cd3`, `thy-qc-cd3-marqueur`, `thy-qr-cd3`, `thy-an-2122s2-q1`, `thy-an-2425s1-q3` |
| `genes-tcr.png` | 5 (8) | `thy-fa-genes`, `thy-qc-genes`, `thy-qu-chromosome` |
| `diversite-combinatoire.png` | 6 (9) | `thy-fa-signaux`, `thy-fa-diversite`, `thy-qc-combinatoire`, `thy-qr-rag`, annales de la diversité |
| `diversite-jonctionnelle.png` | 6 (10) | `thy-qc-jonctionnelle`, `thy-qr-tdt`, `thy-an-2223s1-qroc1` |
| `tcr-cdr3-peptide.png` | 7 (11) | `thy-qc-diversite`, `thy-qr-cdr3` |
| `lobule-thymique-tec.png` | 9 (16) | `thy-qc-thymus`, `thy-qr-hassall`, `thy-zo-lobule`, annales |
| `cheminement-thymocytes.png` | 10 (18) | `thy-fa-etapes`, `thy-qc-dn-dp`, `thy-qc-cheminement`, `thy-qc-positive`, `thy-qc-negative`, `thy-qc-aire-apeced`, `thy-qu-aire`, `thy-qr-etr`, annales |
| `courbe-avidite.png` | 13 (24) | `thy-qc-avidite`, `thy-qc-education`, `thy-qc-lt-matures`, `thy-fa-chiffres`, `thy-zo-avidite` |
| `corecepteurs-cd4-cd8.png` | 14 (26) | `thy-qc-corecepteurs`, `thy-rv-corecepteurs` |
| `thymus-age.png` | 15 (29) | `thy-qc-cinetique`, `thy-fa-cinetique`, `thy-qc-pool` |

Les trois QCM non illustrés (`thy-qc-exclusion`, `thy-qc-populations`,
`thy-qu-ordre`) n'ont pas de figure dans le ronéo.

## Le lexique

Dix termes, pages mesurées dans le texte du ronéo 2026-27 (la logique de
`chercher_pages.py`, avec pymupdf ; le plan de la p. 1 n'est pas compté) :

| Terme | Origine | Pages (ronéo 2026-27) |
|---|---|---|
| Thymocyte | grec θύμος + κύτος | 4, 5, 8-13, 15 |
| Hétérodimère | grec ἕτερος + δι- + μέρος | 2 |
| Monovalent | grec μόνος + latin valens | 3 |
| Syngénique | grec σύν + -γενής | 11, 12 |
| Ectopique | grec ἔκτοπος | 12 |
| Exclusion allélique | latin exclusio + grec ἀλλήλων | 8 |
| Thymectomie | grec θύμος + ἐκτομή | — (FC 2025-26, p. 13 : absent du cours 2026-27) |
| Tolérance centrale | latin tolerantia + centralis | 12 |
| **Délétion clonale** (nouveau) | latin deletio + grec κλών | 11, 12, 13 |
| **Polyendocrinopathie** (nouveau) | grec πολύς + ἔνδον + κρίνω + πάθος | 12 |

Aucun n'était accueilli ailleurs (« Thymopoïèse » l'est par immuno_organes ;
« paratope », « clone », « épitope », « immunosénescence » par d'autres
chapitres d'immunologie : non repris). Les racines que les FC de sémantique
enseignent citent leur page ; les autres s'affichent en gris, « hors FC ». **Une
racine nouvelle (`deletio (latin)`) et les deux termes nouveaux** sont proposés
pour `etymologies.json` (Wiktionnaire, TLFi, Gaffiot), dans le brouillon
d'étymologies du chapitre ; les définitions portent déjà la phrase que
`appliquer_etymologies.py` écrirait. Les huit autres termes y sont déjà.

## À relire

**0 carte `a-relire`** : chaque note du cours cite sa page du ronéo 2026-27, et
chaque annale sa source ; la seule clé déduite (2024/2025 Q3) l'est du cours, pages
citées. Reste ouvert, et dit sur la carte : l'origine du surlignage A, B, C du sujet
2024/2025 (Q3 D). Reste à faire hors du chapitre : copier le PDF
`IMMUNOLOGIE/TCR ET LYMPHOIESE T.pdf` dans le dossier des PDF de l'application
(`outils/copier_les_cours.py`, hors du bac à sable), et reporter les erreurs
ci-dessus dans `contenu/ERRATA_RONEOS_2026-27.md`.

## L'échelle : Simple → Moyen → Annale (C20, 16/10/2026)

Le pilote de l'immunité innée, étendu au reste de l'immunologie pour l'examen du 4/11 (choix de Vincent, 15/10). Sous les annales, 27 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 7 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`) ; les QROC reçoivent le schéma nu.

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `recepteur-t` | 7 | 2 | 2 |
| `recombinaison-vdj` | 7 | 1 | 3 |
| `thymus` | 6 | 1 | 1 |
| `repertoire` | 7 | 3 | 5 |

**Le schéma** `ech-thymus`, « Le TCR et l'éducation thymique · reconnaître, diversifier, trier », donne 43 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_THYMUS`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu les dix chapitres ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Sans marche** :
- thy-an-2425s1-q3 A : pas de carte Simple — « tout LT porte un TCR » se lirait dans la case du CD3 (« toujours associé au TCR », « marqueur de tous les LT ») ; préparée par la Moyen thy-ech-m1 (D).
- thy-an-2223s1-q3 C : pas de carte Simple — les HLA des mTEC se déduiraient de la ligne « LT CD4 : HLA II · LT CD8 : HLA I » ; préparée par thy-ech-m6 (A).
- thy-an-1516s1-q5 C : pas de carte Simple — l'ordre DN → sélection positive → sélection négative est le dessin même, une case vide n'y cacherait rien ; préparée par thy-ech-m5 (C).

## Régénérer

```powershell
..\..\..\app\.venv\Scripts\python.exe generer.py
```

## Questions pour Vincent

- (11/10) Corps de Hassall : le classement est resté « douteux ». Votre cours 2025-26 dit « structure épithéliale », mais un rôle d'élimination des débris d'apoptose est proposé dans la littérature. Si le professeur l'a dit tel quel à l'oral, faut-il passer au genre « cours » ?
- (11/10) Signaux de recombinaison (p. 6) : je les ai passés en « cours », puisque la diapositive elle-même met 12 après le V et 23 avant le J. La carte dit de répondre comme la diapositive à l'examen. Ce choix vous convient-il ?
- (11/10) Les LT γδ perdent le tag `edn` : ils sont en noir p. 2, et seule une remarque grise des rédacteurs dit qu'ils « ne sont pas le sujet de ce cours ». Faut-il les garder hors partiel (edn) ?
- (11/10) Faut-il ajouter une session EXAMENS (examen du 04/11/2026) aux chapitres d'immunologie ? Aucun n'en déclare pour l'instant.
