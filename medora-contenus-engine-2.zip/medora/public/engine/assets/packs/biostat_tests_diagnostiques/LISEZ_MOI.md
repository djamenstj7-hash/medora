# Tests diagnostiques — paquet Biomédecine quantitative

126 notes, 188 cartes. Chapitre `chap-ue-biomed-quanti-fc6` de l'UE
Biomédecine quantitative, troisième de l'UE. Cours du **Pr G. Ficheur, le
22/10/2025, de 8 h à 9 h**, dans le **Ronéosaure 2025-26** (FC n°3, 7 pages) ;
les annales de deux polycopiés du Ronéosaure 2024-25 (68 questions, 18
sessions). Examen : partiel du mercredi 16 décembre 2026.

**Fiche provisoire** (C15, décision de Vincent du 02/10) : le cours de l'année
2026-27 n'est pas encore paru. Chaque carte de cours cite la FC 2025-26 à sa
page et porte le badge « Cours 2025-26 » ; le ronéo 2026-27 corrigera les cartes
quand il sortira. `donnees.py` porte `ANNEE_COURS = "2025-26"`. Aucune carte ne
dit « Absent du cours 2026-27 », et les erreurs du Ronéosaure sont dites par un
ATTENTION sans genre : la liste des erreurs de la promo,
`contenu/ERRATA_RONEOS_2026-27.md`, ne concerne que les ronéos 2026-27.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 86 | 86 |
| QRU | 1 | 1 |
| Texte à trous | 10 | 59 |
| QROC | 12 | 12 |
| Recto-verso | 6 | 6 |
| Schéma cliquable | 2 | 15 |
| Planche à légender | 1 | 1 |
| Lexique | 8 | 8 |

Dont **68 annales** sur 18 sessions (2015/2016 à 2023/2024) : 67 du polycopié
« 6. Tests diagnostiques », une du polycopié « 15 - Analyse médico-économique »
(2023/2024 S2, Q.5). Les 19 autres QCM sont des questions de cours.

Sept thèmes, dans l'ordre du cours ; toutes les clés sont nouvelles (plan C15),
et leurs libellés restent à ajouter à `THEME_LABELS`
(`app/src/med_engine/application/scopes.py`) :

| Clé | Libellé | Notes |
|---|---|---|
| `gold-standard` | Gold standard et test de référence | 5 |
| `tableau-contingence` | Tableau de contingence d'un test | 28 |
| `valeurs-intrinseques` | Sensibilité et spécificité | 25 |
| `valeurs-extrinseques` | Valeurs prédictives et prévalence | 19 |
| `depistage` | Stratégies de dépistage | 5 |
| `courbe-roc` | Courbe ROC et aire sous la courbe | 29 |
| `concordance` | Concordance et coefficient kappa | 7 |

`valeurs-extrinseques`, `courbe-roc`, `depistage` et `concordance` sont
partagées avec l'IRM de la prostate (FC n°4), où leur libellé dit vrai aussi.

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-biomed-tdg-2526` — Ronéosaure, « FC n°3 Tests diagnostics » (7 p.) | 2025-26 | le cours ; `SRC["fiche"]`, ses 17 figures ; fiche provisoire en attendant le ronéo 2026-27 |
| `src-annales-6-tests-diagnostiques` — « 6. Tests diagnostiques » (34 p.) | 2024-25 | 16 sessions, table p. 33-34 |
| `src-annales-15-analyse-medico-economique` — « 15 - Analyse médico-économique » (19 p.) | 2024-25 | la Q.5 de 2023/2024 S2 ; table p. 19 |

Les deux polycopiés d'annales sont déclarés dans la forme commune de C15 (id
tiré du nom de fichier, titre = nom sans extension — deux espaces finales
comprises pour le second —, chemin, auteur), pour que les chapitres qui les
citent aussi (médico-économie, scores, IRM) les déclarent à l'identique. Lus en
appoint, sans être déclarés : le cours 2024-25 (FC n°6, Pr Puech), pour
comprendre une annale ; le cours 2025-26 des scores cliniques (FC n°1, p. 13),
cité pour l'aire sous la courbe ; les erratas des cours 2025-26 et des annales
2024-25, qui n'ont aucune entrée pour ce cours.

Les pages citées sont celles du PDF ; la p. 1 est la page de garde et le plan,
et le ronéo imprime la page du PDF moins un. Les en-têtes des ronéos, des
erratas et des polycopiés portent des noms d'étudiants : aucun n'est repris. Le
polycopié d'annales attribue ces questions au « Pr Puech » : l'attribution n'est
pas reprise.

## Ce que le cours a dicté

- **Le rouge** est celui des titres, de « positifs » (p. 5 : positif si et
  seulement si les deux tests le sont), de « test sans intérêt » et de « test
  2 » (p. 6) : chacun a sa carte (`tdg-fa-deux-temps`, `tdg-qc-auc`,
  `tdg-qc-colorectal`).
- **Le gris** est la voix des rédacteurs (« le prof passe vite », l'exemple de
  ChatGPT, une phrase de ChatGPT pour la concordance théorique, p. 6-7) : il se
  carte comme le reste (décision du 25/09) — `tdg-rv-modele-predictif` et
  l'option E de `tdg-qc-roc`. La phrase de ChatGPT n'est pas reprise ; la carte
  de la concordance théorique suit la diapositive.
- **Ce qui n'est pas carté ici** (plan C15) : les chiffres de l'étude de Lille
  sur l'IRM (VPN 94 %, VPP 56 %, ASC, κ 0,58) et les huit annales du PSA « selon
  la population » et « PSA puis imagerie » (`biostat_irm_prostate`) ; la courbe
  ROC comme discrimination d'un score (`biostat_scores`) ; la 2017/2018 S1 QCM
  n° 10, sur la validation d'un score, rangée dans ce polycopié (`biostat_scores`).
- **Les exercices chiffrés** (`tdg-qc-calcul-tableau`, `tdg-qc-bayes`,
  `tdg-qc-ia-scintigraphie`, `tdg-qc-kappa-calcul`, `tdg-qr-calcul-vpp`,
  `tdg-qr-calcul-kappa`) appliquent les formules du cours à d'autres chiffres
  que ceux des annales, pour que le calcul ne se retienne pas par cœur.

## Les erreurs du Ronéosaure 2025-26

Le Ronéosaure n'est pas le ronéo de l'année : chaque erreur est portée par un
**ATTENTION nu** dans la carte qui tient la notion, la sorte dite dans le texte,
et rien n'entre dans `contenu/ERRATA_RONEOS_2026-27.md`.

| Page | Le ronéo dit | Retenu | Sorte | Carte |
|---|---|---|---|---|
| 3 | la spécificité, « utilisé[e] plutôt dans les diagnostics d'exclusion » | un test très spécifique sert au diagnostic de certitude (la p. 4 du même ronéo) ; c'est un test très sensible qui, négatif, exclut | prise de notes | `tdg-qc-specificite` D |
| 6 | l'aire sous la courbe ROC « toujours comprise entre 0,5 et 1 » (diapositive « 0.5 ≤ AUC ≤ 1 », comme le cours 2024-25, p. 7) | l'AUC va de 0 à 1 ; sous la diagonale, AUC < 0,5, « on fait exprès de se tromper » (FC n°1 2025-26, p. 13). À l'examen : 0,5 = sans intérêt, et une AUC < 0,5 n'est jamais une bonne qualité | le cours lui-même | `tdg-qc-auc` E ; la zone « sous la diagonale » de `tdg-zo-roc` |

Aucune proposition de carte ne repose sur la phrase fausse : la carte demande
ce qui vaut des deux côtés (une AUC de 0,45 n'est pas bonne).

## Ce que les annales ont dicté

| Savoir | Questions |
|---|---|
| Une sensibilité (ou une spécificité) donnée : définition, critère intrinsèque, gold standard, pas la VPP | 16 : 2023/2024 S1 Q1 et S2 Q.5 (spécificité 87 %) ; 87 % en 2022/2023 S1, 2020/2021 S1, 2019/2020 S2 ; 97 % en 2022/2023 S2, 2021/2022 S2 ; 77 % en 2020/2021 S2, 2018/2019 S2, 2017/2018 S1 et S2 ; variantes en 2021/2022 S1 (88 %, cas-témoins), 2018/2019 S1 (95 %, VPN), 2016/2017 S1 (92 %, AUC), 2015/2016 S1 et S2 (92 %) |
| Le tableau de contingence du PSA : Se, Sp, VPP, prévalence | 13 : tableau 20/3/80/47 (2021/2022 S1 Q27, 2019/2020 S1 Q38, 2018/2019 S2, 2017/2018 S1 et S2, 2016/2017 S2, 2015/2016 S1), 30/3/70/47 (2022/2023 S1, 2020/2021 S1, 2019/2020 S2), 20/6/80/94 (2023/2024 S1, 2022/2023 S2, 2021/2022 S2) |
| Le test d'Alzheimer : VP, FP, VN, FN, sensibilité | 10 : clé A quand E dit 0,2 (2023/2024, 2022/2023 S2, 2021/2022 S2), AE quand E dit 0,8 |
| La courbe ROC : méthode géométrique, Se et Sp, AUC, indépendance de la prévalence | 15 |
| Le critère « C » = carré de la distance au point parfait, seuil 2 ng/ml | 4 : 2019/2020 S1 Q39, 2017/2018 S1 Q40, 2016/2017 S2 Q3, 2015/2016 S2 Q11 |
| Deux échantillons à 40 et 20 % de malades : Se et Sp identiques, VPP et VPN différentes | 10, clé ABCD |

Chaque session a sa carte, et l'explication renvoie aux autres. Les tableaux des
énoncés (contingence, critère « C ») sont recopiés en texte, une ligne par ligne
du tableau.

## Les schémas cliquables et la planche

**Deux schémas cliquables** (`schemas.py`), chacun avec sa version légendée en
correction :

| Fichier | Ce qu'on clique | Pourquoi ce dessin |
|---|---|---|
| `contingence.svg` | les quatre cases (VP, FP, FN, VN) et les cinq totaux, chacun nommé par la valeur dont il est le dénominateur (Se, Sp, VPP, VPN, proportion de malades) — 9 zones | le tableau « toujours présenté de cette manière » (p. 3), avec les en-têtes M, NM, T+, T− des énoncés ; c'est l'erreur des annales que ce schéma attrape : une ligne pour une colonne |
| `roc.svg` | le point parfait, le seuil de la méthode géométrique, un seuil très sensible, un seuil très spécifique, la diagonale, la région sous la diagonale — 6 zones | les onze points de la figure de la p. 6 (le plus proche du point parfait est bien (0,17 ; 0,73), distance² 0,10) ; les axes ne sont pas nommés sur le schéma nu : savoir où est la sensibilité fait partie de la question |

**Une planche à légender**, `tdg-pl-histogrammes` (`planche_depuis_image.py`) :
la figure de la p. 5 — deux distributions, non-malades et malades, coupées par
le seuil de positivité —, ses neuf légendes effacées (VN, FP, VP, FN, tests
négatifs et positifs, non-malades, malades, seuil) ; trois intrus
(sensibilité, spécificité, valeur prédictive positive). L'aperçu de contrôle a
été regardé : aucun reste de lettre, les courbes à peine entamées.

**Dix-sept figures de la FC 2025-26**, extraites en PNG (captures de
diapositives, et la figure d'un manuel reproduite p. 5), réduites à 1000 px de
large au plus et en 256 couleurs. **87 QCM sur 87 illustrés**, 106 notes sur 126.

## Les clés qui ne sont pas reprises telles quelles

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2018/2019 S1 Q2 | AC | AB (`officielle=False`, CONFLITS B, C) | la colonne 2018/2019 S1 de la table (AC, ACD, CDE, ABD) ne va avec aucun énoncé : elle compterait vraie « la sensibilité fait partie des critères de validité extrinsèque » et fausse la définition de la sensibilité |
| 2018/2019 S1 Q3 | ACD | BD (`officielle=False`, CONFLITS A, B, C) | même colonne : elle compterait vraie une AUC « inférieure à 0,05 » de bonne qualité et la méthode géométrique « obligatoire » |
| 2018/2019 S1 Q4 | CDE | ABCD (`officielle=False`, CONFLITS A, B, E) | même colonne ; la question est mot pour mot celle de neuf autres sessions, clé ABCD |
| 2016/2017 S2 Q1 | C | AB, clé déduite | la colonne 2016/2017 S2 (1.C, 2.CE, 3.BCDE, 4.BD) recopie la table de la régression linéaire de la même session |
| 2016/2017 S2 Q3 | BCDE | AC, clé déduite | idem |
| 2015/2016 S2 Q9 | BC | AC, clé déduite | la colonne « session 2 » porte, sous les n° 9 à 12, les clés de la session 1 : la S2 n'a pas de clé |
| 2015/2016 S2 Q10 | AC | A, clé déduite | idem (elle compterait vraie une AUC « inférieure à 0,05 ») |
| 2015/2016 S2 Q11 | CD | ACD, clé déduite | idem (elle compterait fausse « la courbe ROC représente la validité intrinsèque ») |

Reprises de la colonne voisine, et gardées officielles : **2015/2016 S1 Q1-3**
(BC, AC, CD), que la table imprime dans la colonne « session 2 » sous les n° 9
à 11, la colonne « session 1 » recopiant la régression linéaire 2015/2016 S1
(ACD, CD, BD) ; l'explication de chaque carte le dit. Les autres anomalies,
sans effet sur les clés : les tableaux 20/6/80/94 comptent 200 patients pour
« 150 » annoncés (les clés suivent le tableau) ; « négatif (T) » sans le signe
moins (énoncé gardé tel quel) ; « 2023/2024 » sans session (rangée en S1). Le
plan C15 relevait des valeurs manquantes (le « 400 » de 2017/2018 S2 Q19, le
« 100/150 » de 2019/2020 S1 Q38, S2 Q2 et 2017/2018 S1 Q39) : relues sur le PDF,
elles sont imprimées.

La « 2021/2022 S1 » Q25 E (un test utilisable « dans les études de cohorte, mais
pas dans les études cas-témoins », donnée fausse) déborde la FC 2025-26 : clé
reprise, justifiée par le calcul de Se et Sp chez des malades et des témoins et
par le cours 2024-25 (p. 5).

## Le lexique

Huit termes, ceux du plan C15 ; aucun n'existait (vérifié contre les `lex-*`
de tous les paquets). Pages mesurées dans le texte de la FC 2025-26, page de
plan et en-têtes exclus, ligatures normalisées (`chercher_pages.py` ne voit pas
« spécificité », écrit avec la ligature fi : relu avec PyMuPDF) :

| Terme | Origine | Pages |
|---|---|---|
| Sensibilité | latin sensibilitas (sensibilis) | 3, 5, 6 |
| Spécificité | latin specificus (species + facere) | 3, 5, 6 |
| Prévalence | latin praevalentia, par l'anglais prevalence | 2-5 |
| Intrinsèque | latin intrinsecus | 3, 4 |
| Extrinsèque | latin extrinsecus | 3, 4 |
| Dépistage | de- + pistare, par l'italien pista | 2-6 |
| Concordance | latin concordantia (cum + cor) | 2, 7 |
| Mammographie | latin mamma + grec γράφειν | 2, 7 |

`pré- (latin)` cite la FC de sémantique (2/2, p. 10). Les racines nouvelles
(`sentire`, `species`, `intrinsecus`, `extrinsecus`, `pistare`, `cor`, `mamma`)
et les huit termes sont proposés à la table commune (`etymologies.json`),
vérifiés sur le TLFi, le Littré, le Wiktionnaire et le Gaffiot ; les textes du
lexique sont déjà écrits dans la forme que `appliquer_etymologies.py`
produirait. `pré- (latin)`, `valere (latin)`, `-fier, de facere (latin)`,
`dé- (latin)`, `cum (latin)` et `-graphie` reprennent les clés existantes —
`dé-` y est le préfixe d'intensité de « dépister » (TLFi).

## Questions pour Vincent

1. **La session de « 2023/2024 »** : l'en-tête du polycopié ne la dit pas ; les
   questions 1 à 5 sont rangées en session 1 (proposition du plan : la session 2
   pose la même question sous le numéro 5, dans le polycopié médico-économique).
   L'explication de `tdg-an-2324s1-q1` le dit.
2. **2015/2016 S1** : les clés sont prises dans la colonne voisine de la table
   (« session 2 », n° 9 à 11) et gardées officielles, parce qu'elles sont
   imprimées et vont exactement avec les énoncés. Faut-il plutôt les marquer
   non officielles ?
3. **L'aire sous la courbe** : classée « le cours lui-même » (diapositive
   « 0.5 ≤ AUC ≤ 1 »), proposition du plan ; la carte ne pose aucune proposition
   dont le verdict en dépende. À confirmer quand le ronéo 2026-27 paraîtra.
4. **Une planche en plus du plan** (les histogrammes de la p. 5), à côté des deux
   zones prévues : elle entraîne la lecture du seuil (VN, FP, FN, VP), que les
   annales n'interrogent qu'en texte.
5. **Le titre du polycopié médico-économique** : le fichier s'appelle
   « 15 - Analyse médico-économique  .pdf », deux espaces avant `.pdf`. La règle
   commune (titre = nom sans extension) garde ces deux espaces finales dans le
   titre de `src-annales-15-analyse-medico-economique` ; le chapitre
   médico-économique doit le déclarer à l'identique. Les garder, ou les retirer
   partout ?
6. **La clé de thème `concordance`** (plan C15, partagée avec l'IRM de la
   prostate) est un mot qu'une autre UE pourrait vouloir (le contrôle de
   concordance en transfusion, la concordance des jumeaux en génétique), avec
   un autre sens que « Concordance et coefficient kappa ». Le plan la garde ;
   une clé plus précise (`concordance-kappa`) devrait se décider avant que le
   chapitre de l'IRM ne l'emploie.

## À relire

**Aucune carte `a-relire`** : chaque carte cite une page de la FC 2025-26, et
chaque clé d'annale a été vérifiée proposition par proposition, table relue sur
le PDF.

**Relecture contradictoire (02/10)** : chaque carte de cours relue sur sa page
de la FC ; les 68 énoncés comparés mot pour mot au texte des deux polycopiés,
chaque clé à leur table (p. 33-34 et p. 19) ; les figures et les deux schémas
regardés en rendu, zones superposées. Corrigés : la justification de
« Spécificité = 3/50 » sur le tableau 20/6/80/94 (3/50 = 6/100 y est bien
1 − Sp, et non une valeur étrangère au tableau) ; l'explication de 2016/2017 S2
Q1 (quatre propositions de 2021/2022 S1 Q27 et une de 2019/2020 S1 Q38, et non
les cinq de la première) ; l'ATTENTION de 2018/2019 S1 Q3 C, qui cite désormais
les deux tables qui posent l'aire « inférieure à 0,05 » ; le verso de
`tdg-rv-fp-fn` ; la bande de la diagonale de `roc.svg`, raccourcie pour ne
plus toucher la courbe près du point (1 ; 1), et la légende de la zone,
sortie de la région « sous la diagonale ».

Reste à Vincent :

- quand le ronéo 2026-27 paraîtra, relire chaque carte sur lui et retirer le
  badge « Cours 2025-26 » ;
- `copier_les_cours.py` avec le dossier `…/S1 25-26/examen décembre` du
  Ronéosaure 2025-26, hors du bac à sable, pour que la fiche s'ouvre dans
  l'application ;
- les sept libellés de thème à ajouter à `THEME_LABELS`.

## L'échelle : Simple → Moyen → Annale (C20, 18/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 16 décembre. Sous les annales, 22 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 8 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`).

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `tableau-contingence` | 4 | 2 | 23 |
| `valeurs-intrinseques` | 4 | 2 | 16 |
| `valeurs-extrinseques` | 4 | 1 | 10 |
| `courbe-roc` | 10 | 3 | 19 |

**Les schémas** sont au nombre de 2 : `ech-tableau-contingence`, « Le test binaire · son tableau et ses valeurs » (8 Simple, 4 Moyen, 39 annales ; 52 fichiers), et `ech2-roc-prevalence`, « Un test diagnostique · la prévalence, le seuil, la courbe ROC » (14 Simple, 4 Moyen, 29 annales ; 48 fichiers). Une carte ou une annale va au schéma de son mécanisme. Ils sont décrits dans `schemas.py` (`ECH_TABLEAU_CONTINGENCE`, `ECH2_ROC_PREVALENCE`, avec leurs `TROUS_*` et `LETTRES_*`, un `FICHIERS.update` chacun) et dessinés par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Sans marche** :
- tdg-an-2122s1-q25 E — le test « utilisable en cohorte, pas en cas-témoins » déborde la FC 2025-26, qui ne traite aucun type d'étude (la justification de l'annale s'appuie sur le cours 2024-25, absent des sources de cette échelle) ; la lettre est posée sur « Sensibilité », qui se calcule chez les seuls malades.
- tdg-an-1617s1-q9 E — l'aire sous la courbe ROC relève du thème courbe-roc et du schéma de l'autre rédacteur ; ce schéma n'a pas de case ROC, la lettre est posée sur « Sensibilité » (une valeur prise à un seul seuil ne donne pas l'aire).
- tdg-an-1516s1-q1 E — l'usage d'un test chez des sujets dont on ignore le statut n'est pas une ligne de la FC ; la lettre est posée sur « Sensibilité », dont la carte s5 dit seulement qu'elle se calcule chez les malades.

## Régénérer

```powershell
..\..\..\app\.venv\Scripts\python.exe generer.py
```

La planche numérotée se refait depuis `app/` (Pillow n'est pas une dépendance
du projet) :

```powershell
uv run --with pillow python ../.claude/skills/nouveau-chapitre/scripts/planche_depuis_image.py ../contenu/chapitres/biostat_tests_diagnostiques tdg-pl-histogrammes --apercus <brouillon>
```
