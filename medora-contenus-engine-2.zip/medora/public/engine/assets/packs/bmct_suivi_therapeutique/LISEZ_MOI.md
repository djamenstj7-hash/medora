# Suivi thérapeutique pharmacologique — paquet BMCT

87 notes, 142 cartes. Chapitre `chap-ue-bmct-fc3` de l'UE BMCT (identifiant du
squelette), troisième chapitre de l'UE. **Base : le ronéo 2026-27** (Ronéo &
Juliette, « Suivi thérapeutique pharmacologique », 8 p.), cours du **Pr S. Gautier,
le 28/09/2026, de 10 h 30 à 11 h**. Le chapitre avait été fait le 02/10 (C14) sur la
FC n°3 du Ronéosaure 2025-26 (Pr Deplanque, 13 p.) ; il a été **réaligné le
11/10/2026** sur le ronéo de l'année, carte par carte, comme `immuno_cmh` le 03/10.
Annales : 17 QCM sur 16 sessions (Ronéosaure 2024-25) et trois questions du sujet
2024/2025 (déposé le 15/10/2026), pour le partiel du mercredi 4 novembre 2026.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 44 | 44 |
| Texte à trous | 13 | 65 |
| QROC | 12 | 12 |
| Recto-verso | 8 | 8 |
| Lexique | 8 | 8 |
| Schéma cliquable | 1 | 4 |
| Planche à légender | 1 | 1 |

Dont **20 annales** sur 17 sessions, de 2015/2016 S1 à 2024/2025 S1 : les 17 QCM
verbatim du polycopié, et du sujet 2024/2025 (session 1, sans corrigé) les Q12
et Q13 (`stp-an-2425s1-q12`, `stp-an-2425s1-q13`) et la QR1 du Pr Deplanque,
« les principales indications et limites du dosage », en recto-verso
(`stp-an-2425s1-qr1`, `ANNALES_QROC`). La grille officielle de la faculté (dépôt
du 15/10/2026) confirme la clé de 2023/2024 S1 Q.11 (AC) ; pour la Q.10, elle
imprime ACDE comme le polycopié, et la carte garde CDE (voir plus bas). Le PDF du
sujet 2024/2025 porte une correction surlignée en bleu, officieuse et d'origine
inconnue (le même surligneur reproduit 37 des 40 clés officielles de 2023-24) :
non déclarée, elle sert de seconde opinion, et donne les mêmes clés aux Q12 (CD)
et Q13 (ACE).

| Les 59 notes de cours (hors annales et lexique) | Nombre |
|---|---|
| relues sur le ronéo 2026-27 et confirmées (`page` = page du ronéo de l'année) | 22, dont 7 réécrites |
| nouvelles, sur le ronéo 2026-27 | 10 (et un terme de lexique) |
| **absentes du cours 2026-27** (`ABSENTS_2026`, tag `absent-2026`) | 27 |

**32 notes citent le ronéo 2026-27** à leur page et n'ont plus le badge « Cours
2025-26 ». **7 cartes portent un piège du ronéo** (thème « Pièges des ronéos »).
**42 QCM sur 44 illustrés** (95 %).

Cinq thèmes, dans l'ordre du cours, tous dans `THEME_LABELS` : `suivi-therapeutique`
(« Suivi thérapeutique : définition et paramètres »), `marge-therapeutique`
(« Marge thérapeutique étroite »), `puissance` (« Puissance et relation dose-effet »,
celui de la FC n°1), `concentration-effet` (« Relation concentration-effet »),
`dosage` (« Doser un médicament »). Aucun thème nouveau.

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-bmct-stp` — Ronéo & Juliette, « Suivi thérapeutique pharmacologique » (8 p.), `BMCT/SUIVI THÉRAPEUTIQUE PHARMACOLOGIQUE.pdf` | **2026-27** | **la fiche** (`chapitre=`, `SRC["fiche"]`) : introduction, définition et bornes (p. 2-3), contexte (p. 3-4), quels médicaments (p. 4-5), paramètres PK et PD (p. 5), efficacité et puissance (p. 6), relation concentration-effet (p. 6), quand et pourquoi doser (p. 7) ; la p. 8 est vide |
| `src-fc-bmct-stp-2526` — Ronéosaure, FC n°3 (13 p.) | 2025-26 | **appoint** (le cours du Pr Deplanque) ; `SRC["cours"]` et `SRC["medias"]` ; source des 27 cartes absentes, qu'elles citent à leur page (`fiche=FC2526`) ; n'a plus `chapitre=` |
| `src-annales-bmct-stp` — Ronéosaure, « BMCT - Suivi thérapeutique pharmacologique » (8 p.) | 2024-25 | 16 sessions, 17 QCM, table de corrections p. 7-8 |
| `src-sujets-bmct-2425` — Sujets de BMCT 2024/2025, session 1 (20 p.) | 2024-25 | les Q12, Q13 et la QR1, sujet sans corrigé ; `SRC["sessions"]["2024/2025 S1"]` ; déclaré à l'identique par tous les chapitres de BMCT qui en cartent une question |
| tableau des erreurs BMCT 2026-27 | 2026-27 | **vide** au 11/10/2026 (en-tête seul) |

Le ronéo 2026-27 dit son code (p. 1) : **rouge = le diaporama, noir = ce qui a été
dit**. Il n'a ni gris ni quiz. C'est ce code qui permet de trier ses erreurs : quand
le noir contredit le rouge de la même page, c'est une prise de notes.

Références extérieures citées dans les cartes : EMA, EPAR d'Eliquis (apixaban) ;
Jastreboff et al., N Engl J Med 2023 (rétatrutide, triple agoniste GIP, GLP-1,
glucagon) ; ICSH, Gosselin et al., Thromb Haemost 2018, et les propositions du GIHP
(apixaban : pas de fourchette thérapeutique, 30 ng/mL avant une chirurgie urgente) ;
Garcia et al., Chest 2012 (héparine liée aux protéines plasmatiques) ; ANSM, recherche obligatoire du déficit en DPD par l'uracilémie avant le
5-FU ou la capécitabine (depuis 2019) ; HAS 2024, stratégie thérapeutique du diabète
de type 2 (HbA1c) ; Holford et Sheiner, Clin Pharmacokinet 1981 (le modèle Emax) ;
et, pour les cartes absentes, le RCP de Téralithe 250 mg et Liu et al., Anesth Analg
2011, comme avant.

Les en-têtes des ronéos, les erratas et le polycopié d'annales portent des noms
d'étudiants : aucun n'est repris.

`copier_les_cours.py` se lance avec le dossier des ronéos 2026-27 (`…/S1/CM`), hors du
bac à sable, pour que le lecteur ouvre la fiche (`BMCT/SUIVI THÉRAPEUTIQUE
PHARMACOLOGIQUE.pdf`).

## Ce qui a changé contre le Ronéosaure 2025-26

**Le cours a changé de professeur et de taille** : une demi-heure du Pr Gautier au
lieu d'une heure du Pr Deplanque, sept parties au lieu de quatre, et plus aucun quiz.
Ce qui reste : la définition, la marge étroite, les paramètres PK et PD, efficacité
et puissance (la même diapositive des molécules A, B, C), la relation
concentration-effet (réduite à l'effet direct réversible), les raisons de doser
(les cinq mêmes), quels médicaments doser. Ce qui part : voir « Absent du cours
2026-27 ». Ce qui arrive :

- **l'introduction par l'exemple** (p. 2) : le 5-FU et le polymorphisme de ses
  enzymes de métabolisation, les immunosuppresseurs (rejet en insuffisance, toxicité
  hépatique ou rénale en excès), les anticoagulants, l'héparine non fractionnée sans
  posologie standard → `stp-qc-introduction`, `stp-qr-heparine`, `stp-qr-5fu` ;
- **les bornes d'une concentration thérapeutique** (p. 3) : le rétatrutide, dont le
  dosage ne dit que la présence ; l'apixaban, sous 30 ng/mL pas d'effet, au-delà de
  450 ng/mL toxique, 250 ng/mL au bloc → `stp-qc-bornes`, `stp-rv-bornes`, et un
  schéma redessiné, `bornes-concentration.svg` ;
- **les trois situations du STP** (p. 3-4) : marge étroite, effet qu'on ne peut pas
  suivre cliniquement (pas de biopsie pour le rejet ; la pression artérielle,
  l'hémoglobine glyquée, le cholestérol quand on peut), risque médicamenteux sévère
  → `stp-fa-contexte`, `stp-qc-contexte` ;
- **la relation concentration-effet comme condition du STP** (p. 6) →
  `stp-fa-concentration-effet`, `stp-qc-concentration-effet` ;
- **les raisons de doser**, avec la soumission chimique et l'association B qui fait
  baisser A (p. 7) → `stp-qc-pourquoi-doser`.

**Les 22 notes confirmées** portent `page` (ronéo 2026-27) et des justifications qui
citent ses pages ; une proposition isolée du seul cours 2025-26 le dit dans sa propre
justification (« d'après le cours 2025-26 (FC n°3, p. 3 ; absent du cours 2026-27) ») :

| Note | Page 2026-27 | Ce qui a changé |
|---|---|---|
| `stp-fa-definition` | 3 | **réécrite** : « adaptation individuelle » (c3) au lieu d'« un patient » |
| `stp-fa-marge` | 3 | **réécrite** : les exemples de la diapositive (immunosuppresseurs, certains antibiotiques, lithium) au lieu de la digoxine, du lithium et des AVK, dits dans l'explication |
| `stp-fa-parametres-pd` | 5 | **réécrite** : « cholestérol » (c3) au lieu de « LDL-cholestérol » ; les couples médicament-marqueur passent dans l'explication |
| `stp-fa-efficacite-puissance` | 6 | **réécrite** : DA50 ou EC50, « dose ou concentration » ; ATTENTION (prise de notes) |
| `stp-fa-interets-dosage` | 7 | **réécrite** : « association à un médicament qui modifie sa pharmacocinétique » (c5) |
| `stp-fa-quels-doser` | 4 | **réécrite** : « anticancéreux (le 5-FU) » (c4) au lieu de « cytotoxiques » |
| `stp-qc-efficacite-puissance` | 6 | **réécrite** : D devient « B est plus puissante que C », fausse, avec l'ATTENTION (prise de notes) ; l'énoncé dit que C atteint la moitié de son effet maximal à la même dose que B (relecture du 11/10 : « à des doses voisines » ne permettait pas de juger D) ; la figure du ronéo 2026-27 en correction |
| `stp-qc-definition` | 3 | D (la génétique) dite du cours 2025-26 |
| `stp-qc-marge-etroite` | 3 | B et C (la digoxine) dites du cours 2025-26 ; l'ATTENTION nu sur « trop fiable » (ronéo 2025-26) n'a plus lieu d'être |
| `stp-qc-raisonnement` | 4 | B (Synapse) dite du cours 2025-26 |
| `stp-qc-parametres-pk` | 5 | E (l'ASC des immunosuppresseurs) dite du cours 2025-26 |
| `stp-qc-parametres-pd` | 5 | justifications |
| `stp-qc-quantitatif-qualitatif` | 6 | justifications ; les exemples (hypnotique, cholestérol) dits du cours 2025-26 ; C cite la DE50 du cours de pharmacodynamie générale 2026-27 (Pr Bordet, partie 2, p. 2) |
| `stp-qc-generalites-dosage` | 6 | A (« presque jamais impératif ») dite du cours 2025-26 |
| `stp-qc-quels-medicaments` | 4 | justifications |
| `stp-qr-stp` | 2 | — |
| `stp-qr-inr` | 5 | explication |
| `stp-qr-emax` | 6 | explication |
| `stp-rv-efficacite-puissance` | 6 | ATTENTION (prise de notes) ; la figure du ronéo 2026-27 |
| `stp-rv-ec50-ce50` | 6 | explication |
| `stp-rv-dosage-genotypage` | 7 | explication |
| `stp-zo-efficacite-puissance` | 6 | les notes des zones citent la p. 6 |

**Les annales** restent verbatim ; leurs justifications citent désormais leur source
en toutes lettres (« ronéo 2026-27, p. 6 » ou « FC n°3 2025-26, p. 11 ; absent du
cours 2026-27 »). **Aucune clé n'a changé** : le ronéo 2026-27 confirme l'efficacité et
la puissance, l'observance, le polymorphisme et la marge étroite ; les limites du
dosage, le contexte du prélèvement, le mode d'administration et le nouveau-né ne
sont que dans le cours 2025-26.

## Les erreurs du ronéo 2026-27

Aucun tableau de la promo (vide au 11/10) : toutes ont été trouvées en relisant, et
chacune est portée par une carte avec son genre. À l'examen, on répond d'abord
comme le professeur ; ici, les deux prises de notes de la p. 6 sont démenties par la
diapositive de la même page (le rouge du ronéo) et par le cours 2025-26 ; les deux
autres sont des fautes de nom : Eliquis compté comme un second médicament, alors que
le ronéo l'emploie ailleurs pour l'apixaban (« Eliquis a une grande marge
thérapeutique », p. 3), et « Hg » pour Hb, une faute de transcription.
Les points douteux, eux, ne changent aucune clé : la carte dit ce qui est établi, et
ce que le cours a dit.

**Prises de notes fausses** (`ATTENTION (prise de notes)`) :

| Page | Le ronéo dit | Ce qui est juste | Carte |
|---|---|---|---|
| 6 | sous les définitions, en noir : l'efficacité, « la proportion dont on a besoin pour avoir un effet maximum, ex : DA50 = dose à laquelle on a 50 % de l'effet » ; la puissance, « donc effet maximum induit par la molécule » | efficacité = Emax, puissance = DA50 ou EC50 : la diapositive en rouge sur la même page ; FC n°3 2025-26, p. 7 | `stp-fa-efficacite-puissance`, `stp-rv-efficacite-puissance` |
| 6 | « Ici, B est plus puissant que C » | sur la diapositive, B et C ont la même DA50 (un seul pointillé vertical) ; B a l'Emax le plus haut : B est plus **efficace** que C ; « la molécule A est la plus puissante et la molécule B est la plus efficace » (FC n°3 2025-26, p. 7) | `stp-qc-efficacite-puissance` (D), `stp-rv-efficacite-puissance` |
| 3 | les anticoagulants « les + prescris : Apixaban et Eliquis », comme deux médicaments | Eliquis est le nom de marque de l'apixaban (EMA, EPAR d'Eliquis) | `stp-qc-bornes` (E) |
| 4 | « mon critère de suivi c'est mon Hg glyquée » | l'hémoglobine glyquée, HbA1c (Hb ; Hg est le mercure) — HAS 2024 | `stp-qc-contexte` (D) |

**C'est le cours lui-même** (`ATTENTION (cours)`) : aucune.

**Points douteux** (`ATTENTION (douteux)`), dits dans la carte sans changer sa clé :

| Page | Le point | Carte |
|---|---|---|
| 6 | « on doit avoir une relation linéaire », ce que l'on trouve dans le sang « proportionnel à l'effet attendu » (texte noir) : la diapositive dit « relation directe » ; la relation concentration-effet est une courbe qui plafonne (modèle Emax, sigmoïde en échelle logarithmique ; Holford et Sheiner 1981 ; FC n°3 2025-26, p. 6 et 9), à peu près linéaire seulement bien en dessous de l'EC50 — mot de la professeure ou raccourci de la prise de notes, rien ne tranche | `stp-qc-concentration-effet` (C) |
| 3 | le rétatrutide, « analogue de GLP1 et GIP » : c'est un triple agoniste, GIP, GLP-1 et glucagon (Jastreboff et al., N Engl J Med 2023) — la description est incomplète, et rien ne dit si le glucagon a été dit en cours | `stp-qc-bornes` (B) |
| 3 | l'apixaban : « <30ng/ml pas efficace si >450ng/ml toxique » — l'apixaban n'a pas de fourchette thérapeutique établie, seulement des concentrations attendues sous traitement (pic de 91 à 321 ng/mL à 5 mg deux fois par jour ; ICSH, Gosselin et al., Thromb Haemost 2018) ; 30 ng/mL est le seuil sous lequel une chirurgie urgente à haut risque hémorragique est jugée possible (GIHP), aucun seuil toxique de 450 ng/mL n'est publié. La carte garde les chiffres du cours | `stp-qc-bornes` (C) |
| 2 | la variabilité intra-individuelle de l'héparine non fractionnée, « (ce qu'on mange ou pas) » — c'est la variabilité des AVK (vitamine K, p. 3) ; l'héparine varie parce qu'elle se lie à des protéines plasmatiques autres que l'antithrombine (Garcia et al., Chest 2012, recommandations de l'ACCP) | `stp-qc-introduction` (D) ; `stp-qr-heparine` ne reprend plus l'alimentation |

**Non carté, invérifiable** : p. 5, la canicule et « une augmentation considérable de
morts (+7000) » — le ronéo ne dit pas de quelle canicule il s'agit, et le chiffre ne
sert aucune notion du cours.

## Les erreurs du Ronéosaure 2025-26

Le Ronéosaure n'est pas la ronéo de l'année : ses erreurs restent portées par un
**ATTENTION nu**, sans genre, dans les cartes absentes qui tiennent la notion ; rien
n'entre dans `contenu/ERRATA_RONEOS_2026-27.md`.

| Page | Le ronéo 2025-26 dit | Retenu | Carte |
|---|---|---|---|
| 3 | le lithium : une marge « à quelques nanogrammes près » | il se dose en **mmol/L** (p. 12) | `stp-qc-lithium` (C) |
| 10 | le quiz IV, en E, recopie le E du quiz III | la carte prend le E du même quiz en 2024-25 ; la réponse BCE ne change pas | `stp-qc-quiz-dosage` (E) |
| 12 | « avec l'INR pour l'isoniazide » | **INH**, l'isoniazide | `stp-qc-cas-particuliers` (E) |
| 12 | lithium : le rapport globules rouges/plasma, « meilleur marqueur de toxicité » | point douteux ; le suivi se fait sur la lithiémie plasmatique (RCP Téralithe 250 mg) | `stp-qc-lithium` (E) |
| 13 | l'AIVOC réglée sur « le relâchement musculaire » | point douteux ; l'écran de la diapositive montre l'index bispectral | `stp-qc-modeles-aivoc` (D) |

Deux erreurs de 2025-26 ne sont plus portées par un ATTENTION, la carte ayant été relue
sur le ronéo 2026-27 qui ne les fait pas : « dose trop fiable » (p. 2,
`stp-qc-marge-etroite`) et l'ASC « concentration à un moment donné » (p. 4,
`stp-qc-parametres-pk` D, qui le rappelle entre parenthèses).

## Absent du cours 2026-27

Vingt-sept cartes entières ne sont pas dans le cours du Pr Gautier. Elles portent le
tag `absent-2026`, disent en tête de leur explication « Absent du cours 2026-27 : il
n'y a pas de version 2026-27 de cette carte ; elle vient du cours du Pr Deplanque de
l'an dernier (Ronéosaure 2025-26, FC n°3)… », et citent la FC n°3 2025-26 à leur page
(`fiche=FC2526`), jamais le ronéo de l'année.

| Partie du cours 2025-26 | Cartes |
|---|---|
| Relations dose-effet et dose-concentration, intégration PK/PD (p. 4-7) | `stp-fa-pkpd`, `stp-qc-quiz-dose-effet`, `stp-qc-variabilite`, `stp-qc-dose-concentration`, `stp-rv-saturations` |
| Mécanisme d'action : aspirine, AVK (p. 8-9) | `stp-fa-mecanismes`, `stp-qc-quiz-concentration-effet`, `stp-qc-mecanisme`, `stp-qr-aspirine`, `stp-qr-facteurs-avk`, `stp-rv-avk-suivi` |
| Mode d'administration : Cmax, Cmin, Css (p. 9-10) | `stp-fa-repetee`, `stp-qc-administration`, `stp-qr-residuel`, `stp-pl-administration-repetee` |
| Paramètres PK propres au cours 2025-26 : la méningite, l'ASC des immunosuppresseurs (p. 4) | `stp-qr-lcs`, `stp-qr-asc-immuno` |
| Place du dosage : quiz, limites, prélèvement, cas particuliers (p. 10-12) | `stp-qc-quiz-dosage`, `stp-fa-limites`, `stp-qc-limites`, `stp-rv-prelevement`, `stp-qc-cas-particuliers`, `stp-qr-acetylation` |
| Le lithium, la fenêtre thérapeutique en chiffres (p. 12) | `stp-fa-lithium`, `stp-qc-lithium` |
| Modèles de population, AIVOC (p. 13) | `stp-qc-modeles-aivoc`, `stp-qr-aivoc` |

## Ce que le cours a dicté

- **Le code du ronéo** (p. 1) : le rouge est la diapositive, le noir l'oral. Les
  cartes citent la diapositive entre guillemets quand elle tranche.
- **Ni gris ni quiz** : tout se carte. Les trois quiz du Pr Deplanque restent, absents.
- **Le plan** fait les sections des cartes (I à VII).
- **La seule figure** du ronéo, la diapositive des molécules A, B et C (p. 6), est
  extraite à sa résolution d'origine (`efficacite-puissance-2026.png`, 321 × 140 px) ;
  la même diapositive, nette, reste celle de la FC n°3 2025-26.

## Ce que les annales ont dicté

Deux questions surtout, posées presque mot pour mot d'une session à l'autre :

| Savoir | Questions |
|---|---|
| Le dosage : observance, limites, polymorphisme, contexte, fenêtre étroite | 2023/2024 S1 Q.11, 2022/2023 S1 Q.9, 2021/2022 S1 Q.12, 2020/2021 S2 Q.10, 2019/2020 S1 Q.9, 2018/2019 Q.6, 2017/2018 S1 Q.8, 2016/2017 S2 Q.8, 2015/2016 S1 Q.9 ; et, à rédiger, la QR1 de 2024/2025 S1 (indications et limites du dosage) |
| Efficacité (Emax) et puissance (DA50), jamais synonymes | 2024/2025 S1 Q12, 2023/2024 S1 Q.10, 2022/2023 S2 Q.9, 2021/2022 S2 Q.9, 2020/2021 S1 Q.11, 2019/2020 S2 Q.9, 2017/2018 S2 Q.8, 2016/2017 S1 Q.6, 2015/2016 S2 Q.9 |
| La relation concentration-effet (le quiz de la FC n°3 2025-26, p. 8) | 2024/2025 S1 Q13 |

D'où le schéma cliquable et le recto-verso sur l'efficacité et la puissance, et le
soin mis aux cartes de dosage. **Les copies entre polycopiés** (« 2023/2024 » Q10 et
Q11, « 2022/2023 » Q6 du polycopié de variabilité) n'ont qu'une carte chacune, ici.

## Les clés qui ne sont pas reprises telles quelles

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2023/2024 S1 Q.10 | ACDE | **CDE**, `officielle=False`, ATTENTION sur A, déclaré dans `CONFLITS` | A, « Pour un médicament donné, la DA50 est la dose pour laquelle 50% des sujets présentent un effet », est donnée vraie par la table. Or « Puissance = dose ou concentration nécessaire pour engendrer 50 % de l'effet maximum (DA50 ou EC50) » (diapositive du ronéo 2026-27, p. 6) ; « Puissance (DA50 ou CE50) : dose pour laquelle on a 50 % de l'effet maximal » (FC n°3 2025-26, p. 7 ; cours 2024-25, p. 8) ; la part des sujets qui répondent est la CE50 d'une réponse qualitative (FC n°3 2025-26, p. 9), et le cours de pharmacodynamie générale 2026-27 l'appelle DE50, qu'il oppose à la DA50 d'une réponse graduelle (« Pharmacodynamie générale 2 », Pr Bordet, p. 2). L'errata des annales BMCT de la promo relève la même erreur. **La grille officielle de la faculté** (02/11/2023, déposée le 15/10/2026) imprime aussi ACDE : relu sur le cours, A reste clairement faux, et la carte le dit dans son ATTENTION et son explication. |
| 2024/2025 S1 Q12 (`stp-an-2425s1-q12`) | aucune (sujet sans corrigé) | **CD**, `officielle=False` | 2019/2020 S2 Q.9 (B) retournée : la puissance se lit à la DA50, l'efficacité à l'Emax ; le plus puissant est actif à la plus FAIBLE dose ; aucune corrélation (ronéo 2026-27, p. 6 ; FC n°3 2025-26, p. 7) |
| 2024/2025 S1 Q13 (`stp-an-2425s1-q13`) | aucune (sujet sans corrigé) | **ACE**, `officielle=False` | le quiz de la FC n°3 2025-26 (p. 8), dont la correction imprimée donne ACE — la B passée de « signifie qu'il existe » à « implique nécessairement », toujours fausse (l'aspirine, p. 8-9) ; B, D et E ne sont que dans le cours 2025-26, et leurs justifications le disent |
| 2024/2025 S1 QR1 (`stp-an-2425s1-qr1`) | aucune (sujet sans corrigé) | verso construit sur le cours, `officielle=False` | les indications : ronéo 2026-27, p. 3-5 et 7, et FC n°3 2025-26, p. 11-12 ; les limites, seulement dans la FC n°3 2025-26 (p. 11), et les bornes dans le ronéo 2026-27 (p. 3) |

Les seize autres clés sont reprises telles quelles ; le ronéo 2026-27 n'en contredit
aucune. **Cas ouvert** : la Q.10 A — la clé est celle du Pr Deplanque, et son cours
comme ceux du Pr Gautier et du Pr Bordet en 2026-27 disent le contraire. À remonter à
Vincent.

## Les schémas et les figures

**Un schéma cliquable** (`schemas.py`), avec sa version légendée en correction :
`efficacite-puissance.svg`, l'Emax de A, l'Emax de B, la DA50 de A, la DA50 de B (4
zones, 4 cartes), d'après la diapositive du ronéo 2026-27 (p. 6), la même qu'en
2025-26 (p. 7).

**Deux figures redessinées** pour les corrections : `fenetre-therapeutique.svg`
(prises répétées dans une fenêtre étroite) et, nouvelle, **`bornes-concentration.svg`**
(ronéo 2026-27, p. 3-4) : l'apixaban et ses bornes (30 et 450 ng/mL, 250 ng/mL au
bloc, les chiffres du cours), une marge étroite (lithium, immunosuppresseurs), une
molécule nouvelle sans bornes (le rétatrutide). Elle illustre `stp-qc-bornes`,
`stp-rv-bornes` et l'annale 2022/2023 S1 Q.9 (« tout médicament peut faire l'objet
d'un dosage »).

**Une planche à légender**, `stp-pl-administration-repetee` (FC n°3 2025-26, p. 10),
absente du cours 2026-27.

**Les figures** : la diapositive des molécules A, B, C du ronéo 2026-27 (p. 6 :
`stp-qc-efficacite-puissance`, `stp-rv-efficacite-puissance`, l'annale 2017/2018 S2
Q.8) ; dix figures de la FC n°3 2025-26 (le Ronéosaure part avec le chapitre, accord
de Vincent du 29/09), légendées avec leur page : raisonnement du STP (p. 3),
variabilité (p. 5), intégration PK/PD et facteurs de variation PK (p. 6),
dose-concentration et molécules A, B, C (p. 7), ASC (p. 9), administration répétée
(p. 10), modèle de population et AIVOC (p. 13). Le ronéo 2026-27 n'a pas d'autre
figure.

**42 QCM sur 44 illustrés (95 %)**, 65 notes sur 87 (les deux QCM et la QR1 du
sujet 2024/2025 prennent le schéma de l'efficacité et de la puissance,
l'administration répétée et la fenêtre thérapeutique). Les deux QCM sans figure :
`stp-qc-parametres-pd` et `stp-qc-mecanisme` (absente).

## Le lexique

Huit termes, chacun avec son **origine grecque ou latine**. Pages mesurées dans le
texte du ronéo 2026-27 d'abord, puis de la FC n°3 2025-26 :

| Terme | Origine | Pages |
|---|---|---|
| Posologie | grec pósos + lógos | 2026-27 : 2, 4, 7 ; 2025-26 : 2, 3, 10 |
| Bactéricide | grec baktēría + latin caedere | 2026-27 : 5 ; 2025-26 : 4 |
| **Antirétroviral** (nouveau) | grec antí + latin retro + virus | 2026-27 : 5 |
| Spectrométrie | latin spectrum + grec métron | 2025-26 : 11 |
| Phénotypage | grec phaínō + túpos | 2025-26 : 11 |
| Hypnotique | grec hupnōtikós, par le latin | 2025-26 : 8 |
| Antiagrégant | grec antí + latin aggregare | 2025-26 : 8 |
| Anesthésie | grec anaisthēsía, par le latin | 2025-26 : 13 |

Les cinq derniers ne sont plus dans le cours 2026-27 ; ils restent, avec leurs pages
2025-26. « Antirétroviral » est proposé à la table commune (`etymologies.json`) : ses
trois racines (`anti-`, `retro (latin)`, `virus (latin)`) y sont déjà, sous les mêmes
clés ; son texte est écrit dans la forme que `appliquer_etymologies.py` produirait.

## Ce qui est laissé aux autres chapitres

La distinction effet indésirable / effet secondaire et le sildénafil (FC n°9) ; le
plateau en 5 demi-vies, la dose de charge, le fractionnement comme notions de
pharmacocinétique (FC n°2) ; les facteurs de variabilité en détail (FC n°5, le cours
du Pr Gautier) ; la définition de la DA50 et de la DE50 (`pdg-fa-doses50`, FC n°1).

## Décisions prises en route

- **`EXAMENS` n'est pas déclaré**, comme dans la FC n°1 : l'import réécrirait la
  portée d'une session d'examen.
- **Réaligner sans perdre** (11/10) : une carte dont le ronéo 2026-27 garde la notion
  est relue et cite sa page ; une proposition du seul cours 2025-26 y reste, et le dit ;
  une carte dont toute la notion a quitté le cours est absente, pas réécrite. Sept
  cartes confirmées ont été réécrites là où le ronéo 2026-27 change un trou ou une
  proposition (voir le tableau).
- **Les cartes absentes citent la FC n°3 2025-26 à leur page** (`fiche=FC2526`), plutôt
  que sans page comme dans `immuno_cmh` : la page reste lisible, et la source n'a plus
  `chapitre=`.
- **La figure du ronéo 2026-27** est petite ; la diapositive nette de 2025-26 reste
  sur les autres cartes d'efficacité et de puissance.
- **Le lithium** et **l'AIVOC** gardent leurs points douteux de 2025-26, dans leurs
  cartes absentes.

## À relire

**Aucune carte `a-relire`** : chaque note cite sa page, dans le ronéo 2026-27 ou, pour
les 27 cartes absentes, dans la FC n°3 2025-26, ou une clé de la table de corrections ;
les trois questions du sujet 2024/2025 citent la page de chaque réponse.
Reste à Vincent :

- la Q.10 A de 2023/2024 (DA50 et 50 % des sujets) : clé du professeur — celle du
  polycopié, et de la grille officielle de la faculté déposée le 15/10/2026 — contre
  les deux cours ;
- les quatre points douteux du ronéo 2026-27 (la relation « linéaire », le rétatrutide,
  les bornes de l'apixaban, l'héparine et l'alimentation).

## L'échelle : Simple → Moyen → Annale (C20, 16/10/2026)

L'échelle du pilote de l'immunité innée, étendue à la BMCT pour l'examen du 4/11 (Vincent, 16/10 : « on continue pour les chapitres que je vais avoir à l'examen »). Sous les annales, 20 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 5 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`) ; les QROC reçoivent le schéma nu.

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `puissance` | 6 | 2 | 9 |
| `concentration-effet` | 6 | 1 | 1 |
| `dosage` | 8 | 2 | 10 |

**Le schéma** `ech-suivi-therapeutique`, « Le suivi thérapeutique · de la courbe dose-effet au dosage », donne 45 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_SUIVI_THERAPEUTIQUE`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

## Régénérer

```powershell
..\..\..\app\.venv\Scripts\python.exe generer.py
```

## Questions pour Vincent

- (11/10) 2023/2024 S1 Q.10 A (la DA50, « dose pour laquelle 50 % des sujets présentent un effet ») : la carte retient faux (CDE, non officielle). La clé imprimée du Pr Deplanque la donne vraie. Contre elle, sa FC 2025-26, la diapositive du Pr Gautier (ronéo 2026-27, p. 6) et le cours du Pr Bordet de cette année : sa « Pharmacodynamie générale 2 », p. 2, définit la DA50 sur une réponse graduelle et la DE50 sur 50 % de la population. On garde faux ? (15/10 : la grille officielle de la faculté dit aussi ACDE ; la carte garde CDE et le dit.)
- (11/10) « Ici, B est plus puissant que C » (p. 6) est classé en prise de notes. Sur la diapositive, B et C n'ont qu'un pointillé de DA50 pour deux, et le texte noir de la même page échange déjà efficacité et puissance. Tu confirmes cette lecture de la figure ?
- (11/10) Apixaban (p. 3) : le ronéo donne « <30 ng/mL pas efficace, >450 ng/mL toxique ». Aucune référence ne fixe de fourchette thérapeutique ni de seuil toxique pour l'apixaban, et 30 ng/mL est un seuil de sécurité avant une chirurgie urgente. La carte garde les chiffres du cours avec un ATTENTION (douteux) : ça te va, ou tu préfères qu'on ne carte plus ces chiffres ?
- (11/10) Héparine (p. 2) : le ronéo attribue sa variabilité intra-individuelle à « ce qu'on mange ou pas ». C'est vrai des AVK, pas de l'héparine, qui varie par sa liaison aux protéines plasmatiques. C'est noté en point douteux sur stp-qc-introduction : d'accord ?
- (11/10) « Apixaban et Eliquis » (p. 3) reste classé en prise de notes. Le fait est certain (Eliquis = apixaban), et le ronéo emploie lui-même « Eliquis » pour l'apixaban plus bas sur la page. On garde ce genre ?
