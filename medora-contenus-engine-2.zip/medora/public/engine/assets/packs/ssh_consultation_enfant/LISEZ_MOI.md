# Santé mentale : consultation avec l'enfant et l'adolescent — paquet SSH

83 notes, 151 cartes. Chapitre `chap-ue-ssh-fc13` de l'UE SSH (examen du
6 janvier 2027, écrit). Cours du **Pr Jardri, le 09/12/2025**, « Santé
mentale : consultation avec l'enfant et l'adolescent » (FC n°15 du
Ronéosaure 2025-26, 11 pages) ; annales du polycopié SSH 13 du Ronéosaure
2024-25 (10 questions, 10 sessions, 9 cartes).

**Une fiche provisoire.** Le ronéo 2026-27 de ce cours n'est pas paru : le
chapitre est carté sur le Ronéosaure 2025-26 (décision de Vincent du 02/10), et
le ronéo de l'année corrigera les cartes à sa parution. La source porte son
année dans son auteur : chaque carte de cours prend le tag `cours-2025-26` et
l'écran montre « Cours 2025-26 ». Aucune carte ne dit « Absent du cours
2026-27 » ; les erreurs du Ronéosaure sont dites par un ATTENTION sans genre
(précédent d'`immuno_innee`), et la liste des erreurs de la promo,
`contenu/ERRATA_RONEOS_2026-27.md`, n'est pas touchée : elle ne concerne que les
ronéos 2026-27.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 14 | 14 |
| QRU | 1 | 1 |
| Texte à trous | 15 | 73 |
| QROC | 22 | 22 |
| Recto-verso | 19 | 19 |
| Schéma cliquable | 2 | 12 |
| Lexique | 10 | 10 |

Dont **9 annales**, toutes en recto-verso (`ANNALES_QROC`, `type="basic"`) :
l'examen de SSH est rédactionnel (« 10 QROC + 1 QR »), et le polycopié n'imprime
que des QR. Les 15 QCM du cours ont une justification par proposition.

Huit thèmes :

| Clé | Libellé | |
|---|---|---|
| `cadre-consultation` | Le cadre de la consultation et l'alliance thérapeutique | nouveau |
| `temps-consultation` | Les temps de la consultation : enfant et adolescent | nouveau |
| `relation` | La relation triangulaire | celui de `semio_enfant`, même libellé (le travail avec les parents) |
| `observation-interactions` | L'observation et les interactions parents-bébé | nouveau |
| `parole-jeu-dessin` | Parler, jouer, dessiner | nouveau |
| `psychomoteur` | Développement psychomoteur | celui de `semio_enfant`, même libellé (les repères d'âge) |
| `annonce-psychotherapie` | L'annonce et la psychothérapie | nouveau |
| `dispositifs-medico-sociaux` | Les dispositifs médico-sociaux de l'enfant | nouveau, hors plan (l'annale « Plus au programme ») |

Les six libellés nouveaux sont à ajouter à `THEME_LABELS`
(`app/src/med_engine/application/scopes.py`, bloc « ssh ») : c'est le seul
test rouge du chapitre, `test_tout_theme_du_paquet_a_son_libelle`. Le tag `edn`
(« Pour les EDN (hors partiel) ») a déjà son libellé.

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-ssh-enfant` — Ronéosaure, « FC n°15 Santé mentale » (11 p.), `SSH/FC n°15 Santé mentale.pdf` | **2025-26** | **la base** : chaque note du cours porte sa page ; c'est ce que le lecteur ouvre (`chapitre=`) |
| `src-annales-ssh-13-consultation-psychiatrique-avec-l-enfant-et-l-adolescent` — « SSH 13 - Consultation psychiatrique avec l_enfant et l_adolescent » | 2024-25 | les dix questions ; déclarée avec les seuls champs de la règle commune (aucun autre chapitre ne la déclare) |
| `src-cours-ssh-enfant-2425` — Ronéosaure, FC n°13 (14 p.) | 2024-25 | appoint : les trois niveaux d'interactions (p. 6), les âges du pointage (p. 6-7), les procédures du dessin et les étapes graphiques (p. 10-11) ; une carte la cite à sa page (`cons-rv-graphisme`, badge « Cours 2024-25 ») |
| `src-roneo-ssh-enfant-2324` — Charonéo, « 4. SSH - Consultation psychiatrique… » (8 p.) | 2023-24 | appoint, cité dans le texte des cartes : les âges (p. 4), le mutisme (p. 5), les procédures actives et passives (p. 5), les étapes graphiques (p. 6) |
| erratas du Ronéosaure : cours 2025-26 (`Erratas SSH.docx`) et annales 2024-25 | — | une entrée sur la FC n°15 (p. 11, « psychopathie » → psychopathologie), reprise ; rien sur SSH 13 |

Vérifications hors des cours, citées dans la carte qui s'en sert : la grille
nationale de repérage des troubles du neuro-développement (HAS, février 2020 ;
livret « Détecter les signes d'un développement inhabituel chez les enfants de
moins de 7 ans ») ; monparcourshandicap.gouv.fr et le Code de l'action sociale
et des familles, art. D312-59-1 (les dispositifs médico-sociaux) ; le DSM-5
(le mutisme sélectif) ; Flavell (1976), Premack et Woodruff (1978) et le
modèle intégratif de Lysaker (2005) (la métacognition, la théorie de
l'esprit) ; Endevelt-Shapira et al., Science Advances 2021 (l'odeur maternelle
et la synchronie cérébrale, que décrit le cours 2024-25 ; l'étude que cite le
ronéo 2025-26 n'est pas nommée, et la carte ne lui en prête aucune).

## Ce que le cours a dicté

- **Ni gris ni rouge** dans la FC n°15 2025-26.
- **« Le mot clé de tout le cours » : l'alliance thérapeutique** (p. 2). Elle a
  sa QROC, son texte à trous, un QCM, le schéma de correction
  `cadre-confiance.svg` et son terme de lexique.
- **Une consigne du professeur** : les compétences graphiques, « on ne sera pas
  interrogé là-dessus » (p. 10). Leur carte de cours (`cons-rv-graphisme`, faite
  sur le cours 2024-25, p. 10-11) et l'annale 2019/2020 S2 portent le tag `edn`.
- **Ce qui appartient à d'autres chapitres n'est pas carté** (plan C16, §3) :
  la médecine de précision de l'introduction (p. 2) est à `ssh_litterature` ;
  le secret professionnel et le secret partagé, à `ssh_responsabilite` — ici,
  seulement l'étanchéité du cadre ; la relation triangulaire de la pédiatrie, à
  `semio_enfant` — ici, seulement ce que la consultation pédopsychiatrique y
  ajoute (le secret de famille, la culpabilité à transformer).

## Ce que les annales ont dicté

| Session | Sujet | Carte | Réponse tirée de |
|---|---|---|---|
| 2023/2024 S1 | trois compétences sociales, avec leur âge | `cons-an-2324s1-qr` | FC 2025-26, p. 7-9 ; les âges des autres années dits |
| 2022/2023 S2 | chronologie d'accueil d'un enfant et de sa famille | `cons-an-2223s2-qr` | p. 2-5 |
| 2020/2021 S1 | quatre niveaux d'interactions comportementales | `cons-an-2021s1-qr` | p. 7 ; cours 2024-25, p. 6 |
| 2019/2020 S1 = 2017/2018 S1 | trois dispositifs médico-sociaux, acronymes développés (« Plus au programme ») | `cons-an-1920s1-qr` (une carte, deux sessions) | aucun cours : sources officielles citées ; `edn` |
| 2019/2020 S2 | âges du bonhomme têtard, de la maison transparente, du paysage en perspective | `cons-an-1920s2-qr` | cours 2024-25, p. 10-11 ; 2023-24, p. 6 ; `edn` |
| 2018/2019 S1 | cinq étapes du développement moteur de 2 à 12 ans | `cons-an-1819s1-qr` | aucun cours : deux lectures ; `edn`, `a-relire` |
| 2017/2018 S2 | deux procédures d'utilisation du dessin, un exemple chacune | `cons-an-1718s2-qr` | p. 10 ; procédures actives et passives des cours 2023-24 et 2024-25 |
| 2016/2017 S2 | chronologie d'accueil d'un adolescent et de sa famille | `cons-an-1617s2-qr` | p. 3-5 |
| 2015/2016 S1 | quatre modalités d'exploration clinique complémentaires de l'examen physique | `cons-an-1516s1-qr` | p. 6-11 : observer, parler, jouer, dessiner |

Ce qui revient : les temps de la consultation (deux sessions), les repères du
développement (trois), le dessin (deux), les quatre stratégies.

## Les clés qui ne sont pas reprises telles quelles

Le polycopié n'imprime **aucune clé** : « Pas de correction officielle des QR
(Bon courage…) (Voir cours de SSH) ». Les neuf cartes sont donc des clés
déduites, `officielle=False`, et leur explication commence par le dire.
`CONFLITS` est vide (il ne se déclare que sur une proposition de QCM).

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2023/2024 S1 (compétences sociales) | aucune | les âges de la FC 2025-26, les autres années dites | les âges changent chez le même professeur (2025-26 : 9-10, 12-15, 15 mois ; 2024-25 : 6-9, 9-12, 12-15 ; 2023-24 : 9, 12-15, 15-18) ; l'ordre ne change pas ; l'ATTENTION donne la référence (grille 2020 : attention conjointe à 12 mois, pointage pour attirer l'attention à 18 mois) |
| 2019/2020 S1 et 2017/2018 S1 (dispositifs médico-sociaux) | aucune | CAMSP, CMPP, SESSAD, IME, ITEP ; CDAPH de la MDPH ; le CMP, sanitaire | hors de tout cours lu ; « Plus au programme » imprimé par le polycopié ; une carte pour les deux sessions |
| 2019/2020 S2 (compétences graphiques) | aucune | têtard 3 ans, maison transparente 4-5 ans, perspective 9-12 ans | cours 2024-25 et 2023-24 ; la grille 2020 attend le têtard à 4 ans (90 % des enfants), dit dans la carte |
| 2018/2019 S1 (développement moteur 2-12 ans) | aucune | deux lectures : les cinq étapes graphomotrices du cours (2 à 12 ans), et la motricité globale de la grille 2020 (2 à 6 ans) | **cas ouvert**, dit dans la carte (`a-relire`) |

## Les erreurs et les écarts du Ronéosaure 2025-26

Chacun est dit par un **ATTENTION sans genre**, dans la carte qui porte la
notion.

| Page | Ce que dit le Ronéosaure | Ce qui est juste | Carte |
|---|---|---|---|
| 11 | « classifications compatibles avec la psychopathie » | psychopathologie : errata de la promo (sans avis du bureau), et le cours 2024-25 oppose lecture nosographique et lecture psychopathologique (p. 11-12) | `cons-qc-objectifs`, `cons-rv-symptome-souffrance` |
| 7-8 | proto-impératif 9-10 mois, proto-déclaratif 12-15 mois, attention conjointe vers 15 mois | ce sont les âges de l'année ; 2024-25 et 2023-24 en donnent d'autres, la grille 2020 aussi : la carte suit 2025-26 et dit tout | `cons-fa-pointages`, `cons-qc-pointages`, `cons-an-2324s1-qr` |
| 8 | la métacognition, « se représenter l'état mental d'autrui » | c'est le cours lui-même (même formule en 2024-25, p. 6) : à l'examen, comme le cours ; la référence : au sens strict, la connaissance de sa propre cognition (Flavell, 1976), l'état mental d'autrui étant la théorie de l'esprit — un sens large que la psychiatrie emploie aussi (Lysaker, 2005) | `cons-qc-metacognition` C ; le terme `lex-metacognition` donne les deux sens |
| 9 | le trouble anxieux, la phobie sociale, rattachés au mutisme « total » | point douteux, sans doute une prise de notes : les cours 2023-24 et 2024-25 et le DSM-5 rattachent l'anxiété sociale au mutisme sélectif invalidant ; le verso de la carte suit cette lecture et dit celle de la FC 2025-26 | `cons-rv-mutisme` |

Sans ATTENTION, parce qu'aucune réponse n'en dépend : le squiggle, inventé par
« un pédiatre célèbre » (p. 10), est de D. W. Winnicott, que nomment les cours
2023-24 et 2024-25 (`cons-qr-squiggle`) ; l'étude d'hyperscanning « publiée dans
Science Advances » (p. 8) n'est pas nommée, et la carte ne lui prête pas de
référence.

## Les schémas cliquables

| Fichier | Ce qu'on clique | Cartes |
|---|---|---|
| `frise-developpement-nu.svg` (`cons-zo-frise`) | sept repères d'âge sur une frise de la naissance à 5 ans : regard mutuel, pointages proto-impératif et proto-déclaratif, attention conjointe, jeu symbolique, premières phrases, théorie de l'esprit | 7 |
| `temps-consultation-nu.svg` (`cons-zo-temps`) | les temps de la première consultation : trois chez le petit enfant, deux chez l'adolescent | 5 |

La frise porte les âges sur l'axe et des cases vides : on clique la case
rattachée au bon âge. Les temps sont des cases numérotées, sans personnage ni
légende : la question nomme ce qu'on fait dans le temps (« recueillir le motif
et les antécédents d'un petit enfant », « chercher pourquoi un adolescent
consulte aujourd'hui »). Les versions légendées, tirées des mêmes constantes,
sont en correction.

**Écart au plan** : le plan prévoyait trois temps chez l'adolescent (seul,
parents, tous ensemble), six zones. Le cours n'en décrit que deux : « vous
proposez de recevoir d'abord leur fille ou leur fils […] Et dans un deuxième
temps, vous allez recevoir tout le monde » (p. 4) ; les cours 2023-24 et
2024-25 aussi. Recevoir les parents seuls serait d'ailleurs l'occasion du
secret de famille que le cours apprend à éviter (p. 5-6). Le schéma a donc cinq
zones.

**Illustrations** : 14 QCM sur 15 (93 %) portent une figure en correction, 54
notes sur 83. Trois figures de la fiche, extraites en PNG — le regard mutuel et
l'hyperscanning (p. 8), la poupée et la dînette (p. 9 ; l'image est pâlie dans
le ronéo, son contraste a été rétabli), le panneau « Ne pas faire
d'interprétation sauvage ! » (p. 10) — et cinq schémas redessinés : le cadre et
la confiance (p. 2), les lieux des symptômes (p. 4-5), les niveaux
d'interactions (p. 7), le déroulé de toute la consultation (p. 2-11), le
contrat de soins tripartite (p. 11). Le QCM sans figure, `cons-qc-parents`, n'en
a pas dans la fiche.

## Le lexique

Dix termes, aux pages mesurées dans la fiche 2025-26 (plan exclu) : alliance
thérapeutique (p. 2, 3, 11), accordage affectif (7), prosodie (7), pointage (7,
8), attention conjointe (8), métacognition (8), théorie de l'esprit (8),
mutisme (9), jeu symbolique (9), psychothérapie (11). Chacun dit son origine
grecque ou latine.

Les étymologies nouvelles sont **proposées** dans
`scratchpad/etym/ssh_consultation_enfant.json` (la table
`scripts/etymologies.json` n'est pas modifiée) : treize racines (`ligare
(latin)`, `affectus (latin)`, `pros- (grec)`, `ôdê (grec)`, `punctum (latin)`,
`tendere (latin)`, `jungere (latin)`, `cognitio (latin)`, `theôria (grec)`,
`spiritus (latin)`, `mutus (latin)`, `jocus (latin)`, `sumbolon (grec)`) et les
dix termes, vérifiés sur le TLFi, le Bailly, le Gaffiot et le Wiktionnaire.
Les définitions et les racines disent déjà, mot pour mot, ce
qu'`appliquer_etymologies.py` en écrira (appliqué avec la table et la
proposition, sans toucher la table). Les racines réemployées gardent la clé
de la table : `ad- (latin)`, `cor (latin)`, `cum (latin)`, `méta-`,
`psych(o)-`, `-thérapie`. Deux racines nouvelles ont une homonyme dans la table,
dite dans leurs sources : `ôdê (grec)` (le chant) n'est pas `-ode` (le chemin),
`mutus (latin)` (muet) n'est pas `mutare (latin)` (changer).

Laissés à d'autres chapitres : « anamnèse » (`lex-anamnese`, déjà pris),
« homéostasie » (`lex-homeostasie`, déjà pris), « médecine de précision »
(`ssh_litterature`).

## À relire

**Une carte `a-relire`** : `cons-an-1819s1-qr`, le développement moteur de 2 à
12 ans (2018/2019 S1). Aucun cours ne porte cette liste ; la carte donne deux
lectures. Le tag se retire quand Vincent aura dit laquelle le professeur
attendait (ou à la parution d'un cours qui la porte).

À la parution du ronéo 2026-27 de ce cours, relire toutes les cartes contre
lui : les pages, les âges des repères (pointages, attention conjointe, jeu
symbolique), la métacognition, le mutisme, et la consigne sur les compétences
graphiques.

## Questions pour Vincent

1. **Le développement moteur de 2 à 12 ans** (2018/2019 S1) : le plan propose
   de la carter avec `edn` et `a-relire`, réponse vérifiée sur une source sûre ;
   c'est fait. Mais la question visait-elle la motricité globale (la grille
   2020, qui s'arrête à 6 ans) ou les cinq étapes graphomotrices du cours, qui
   vont exactement de 2 à 12 ans ? La carte donne les deux.
2. **Les dispositifs médico-sociaux** (2019/2020 S1 = 2017/2018 S1), « Plus au
   programme » : cartés avec `edn`, comme le plan le propose. À garder ?
3. **Les libellés des six thèmes nouveaux**, dont `dispositifs-medico-sociaux`
   (hors plan, pour l'annale « Plus au programme »), à ajouter à
   `THEME_LABELS`.
4. **`EXAMENS`** : aucun chapitre SSH n'en déclare ; le plan propose une seule
   session `exam-ssh-jan-2027` (6 janvier 2027) pour toute l'UE, à décider une
   fois.
5. **Les étymologies proposées**, à fusionner dans
   `scripts/etymologies.json`.

## L'échelle : Simple → Moyen → Annale (C20, 19/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 5 janvier (BMCP) ou du 6 janvier (SSH, papier). Sous les annales, 25 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 4 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`) ; les QROC reçoivent le schéma nu.

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `temps-consultation` | 8 | 1 | 2 |
| `observation-interactions` | 3 | 1 | 1 |
| `parole-jeu-dessin` | 5 | 1 | 2 |
| `psychomoteur` | 9 | 1 | 3 |
| `dispositifs-medico-sociaux` | 0 | 0 | 1 |

**Le schéma** `ech-consultation`, « La consultation avec l'enfant · temps, stratégies, repères », donne 30 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_CONSULTATION`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Tag `edn`** (passage « pas à retenir ») : `cons-ech-s24`, `cons-ech-s25`, `cons-ech-s26`.

**Constantes ajoutées** à `annales.py` (`_SCHEMA_LETTRES`, `_SCHEMA_NU`) : les annales de SSH sont toutes des QROC, rangées dans `ANNALES_QROC` ; chacune reçoit le schéma nu, et les marches la préparent sans lettre.

**Sans marche** :
- cons-an-1920s1-qr (et sa jumelle 2017/2018 S1), les dispositifs médico-sociaux : aucune marche, la notion n'est dans aucun cours lu (2023-24 à 2025-26) et le polycopié la dit « Plus au programme » ; le thème dispositifs-medico-sociaux n'a donc pas de Moyen. L'annale ne reçoit pas non plus le schéma nu : il ne porte rien de ses dispositifs.
- cons-an-1819s1-qr, la lecture « motricité globale » (grille HAS 2020) : hors cours, pas de marche ; seule la lecture graphique du cours (FC n°13 2024-25) est préparée, en edn, et seulement par ses trois âges que demande aussi 2019/2020 S2 (têtard, maison transparente, perspectives). Les étapes « 2 ans, décharges motrices » et « 6-8 ans, personnages distincts » n'ont plus de marche à elles : sur une frise de cinq âges, les distracteurs de chaque carte se lisaient dans les autres lignes de la case ; elles restent dans les justifications de s24 à s26.

## Régénérer

```powershell
cd contenu\chapitres\ssh_consultation_enfant
..\..\..\app\.venv\Scripts\python.exe generer.py
```
