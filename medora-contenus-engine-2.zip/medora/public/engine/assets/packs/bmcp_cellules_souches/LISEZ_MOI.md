# Cellules souches et différenciation cellulaire — paquet BMCP

80 notes, 152 cartes. Chapitre `chap-ue-bmcp-fc12` de l'UE BMCP (ordre 13).
Cours du **Pr Marchetti, le 31/10/2025**, « Cellules souches et différenciation
cellulaire » (FC n°13 du Ronéosaure 2025-26, 10 pages) ; annales du polycopié
BMCP 12 du Ronéosaure 2024-25 (21 QCM, 17 sessions), et la Q.3 du sujet de 2024/2025,
sans corrigé. Examen du 5 janvier 2027.

**Une fiche provisoire.** Le ronéo 2026-27 de ce cours n'est pas paru : le
chapitre est carté sur le Ronéosaure 2025-26 (tâche C16, décision de Vincent du
02/10), et la ronéo de l'année corrigera les cartes à sa parution. La source
porte son année dans son auteur : chaque carte de cours montre « Cours
2025-26 ». Aucune carte ne dit « Absent du cours 2026-27 », et les erreurs du
ronéo sont dites par un ATTENTION sans genre : la liste de la promo,
`contenu/ERRATA_RONEOS_2026-27.md`, ne concerne que les ronéos 2026-27.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 40 | 40 |
| QRU | 1 | 1 |
| Texte à trous | 14 | 83 |
| QROC | 8 | 8 |
| Recto-verso | 5 | 5 |
| Schéma cliquable | 1 | 4 |
| Planche à légender | 1 | 1 |
| Lexique | 10 | 10 |

Dont **22 annales** (QRM), sur 18 sessions, de 2015/2016 S1 à 2024/2025 S1 :
tout le polycopié BMCP 12, et la Q.3 du sujet de 2024/2025 (examen du 09/01/2025,
sans corrigé, déposé le 15/10/2026). Les 19 QCM du cours (18 QRM, 1 QRU) ont une
justification par proposition, comme les annales. **40 QCM sur 41 sont
illustrés** (le seul qui ne l'est pas : les essais de thérapie cellulaire, p. 6,
sans figure) ; 65 notes sur 80 en tout.

Six thèmes, dans l'ordre du cours, tous nouveaux (plan C16, § 0.9) :

| Clé | Libellé |
|---|---|
| `proprietes-cs` | Propriétés et potentialités des cellules souches |
| `cse` | Cellules souches embryonnaires |
| `organoides` | Différenciation in vitro et organoïdes |
| `bioethique-embryons` | Bioéthique : embryons, lignées, clonage |
| `clonage` | Reprogrammation nucléaire et clonage |
| `ips` | Cellules souches pluripotentes induites (iPS) |

Les six libellés sont dans `THEME_LABELS`
(`app/src/med_engine/application/scopes.py`) depuis l'intégration du 05/10. `bioethique` (génétique, « Lois de bioéthique et
encadrement des tests ») n'est pas réemployé : il parle d'autre chose.

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-bmcp-csd-2526` — Ronéosaure, « FC n°13 Cellules souches et différenciation cellulaire » (10 p.), `BMCP/…` | **2025-26** | **la base** : chaque note du cours porte sa page ; c'est ce que le lecteur ouvre (`chapitre=`) |
| `src-annales-bmcp-12-cellules-souches-et-differenciation-cellulaire` — « BMCP 12 - Cellules souches et différenciation cellulaire » (8 p.) | 2024-25 | les 21 questions et leur table de corrections (p. 8) ; déclaration aux champs fixés par la tâche, à recopier à l'identique par tout chapitre qui prendrait une question de ce polycopié |
| `src-cours-bmcp-csd-2425` — FC n°12 (AC), même cours (12 p.) | 2024-25 | la diapositive du **clonage thérapeutique** (p. 8), absente du ronéo 2025-26 : figure de correction et planche à légender |
| `src-cours-bmcp-csd-2324` — Charonéo 2023-24, même cours (10 p.) | 2023-24 | deux diapositives que le ronéo 2025-26 décrit sans les reproduire : le **tableau des lignages** obtenus à partir de CSE (p. 4) et les **pays européens** qui autorisent la recherche sur l'embryon (p. 7) |
| FC n°11 2025-26 (sénescence et thérapies ciblées, `bmcp_senescence`) | 2025-26 | citée dans le texte, à la page, sans être déclarée : la hiérarchie tumorale et les cellules souches de la LMC (p. 10) |
| `src-sujets-bmcp-2425` — « Sujets de BMCP 2024/2025, session 1 » (30 p.) | 2024-25 | le sujet de l'examen du 09/01/2025, **sans corrigé** (dépôt `Annales_15102026/`, 15/10/2026) : sa Q.3 ; `SRC["sessions"]["2024/2025 S1"]` ; déclaré à l'identique dans tous les chapitres de BMCP qui en cartent une question |
| errata du Ronéosaure : cours 2025-26 (`Erratas BMCP.docx`) et annales 2024-25 | — | aucune entrée sur la FC n°13 ni sur le polycopié BMCP 12 |

Le polycopié BMCP 11 n'est pas déclaré : sa seule question de cellules souches
(2023/2024 S1 Q.6) est la copie de celle de BMCP 12, cartée une fois, ici, et
nommée dans la justification.

Vérifications hors du cours, citées dans la carte qui s'en sert : le Code de la
santé publique (art. L2151-1 à L2151-9, loi du 2 août 2021), le Code civil
(art. 16-4) et le Code pénal (art. 214-2) ; Wilmut et al. (Nature 1997) pour
Dolly ; Takahashi et Yamanaka (Cell 2006, 2007) pour les facteurs de
reprogrammation ; Mandai et al. (N Engl J Med 2017) pour l'essai DMLA ;
Al-Hajj et al. (PNAS 2003), Dontu et al. (Genes Dev 2003), Phillips et al.
(JNCI 2006), Li et al. (JNCI 2008), Bao et al. (Nature 2006), Cheshier et al.
(Stem Cells Dev 2007), Cheng et al. (Science 2000), Walter et al. (Nature
2015), Mani et al. (Cell 2008), Pittenger et al. (Science 1999), Lancaster et
al. (Nature 2013) pour les propositions d'annales hors du cours ;
l'étymologie (TLFi, Bailly, Gaffiot, Wiktionnaire).

## Ce que le cours a dicté

- **Le rouge du ronéo** (ce qu'il met en avant) a sa carte : les trois
  propriétés et la division asymétrique (p. 2) ; les quatre potentialités et les
  cellules souches adultes (p. 3) ; les CSE et leur différenciation in vitro
  (p. 3-4) — le « utilisées en thérapeutique » du rouge de la p. 3 n'a pas de
  carte à lui : la p. 6 le nuance aussitôt (« ça se fait beaucoup moins ») ; les deux avantages des CSE (p. 6) ; la
  différenciation « unidirectionnelle et irréversible » et les gènes
  ré-exprimables (p. 7) ; clonage thérapeutique, médecine personnalisée,
  tolérance immunitaire (p. 8) ; le principe des iPS, le rendement de 1/10⁴, la
  limite de l'approche (p. 9).
- **Le gris** se réduit à deux remarques des rédacteurs (« c'est donc la
  problématique de ce cours », p. 2 ; la légende des couleurs de la diapositive
  des pays, p. 7) : cartées comme le reste.
- **Le vert** du ronéo (exemples : feeders de souris, Dolly, intestin de souris,
  drépanocytose) a ses cartes : ce sont des exemples que les annales et le
  professeur emploient.
- Aucun passage « à ne pas retenir » dans cette FC.

## Ce que les annales ont dicté

21 questions, toutes sur le même modèle de cinq propositions qui reviennent
presque mot pour mot : la division asymétrique (13 questions), le droit —
clonage thérapeutique interdit, lignées permises pour la recherche, essais
permis, clonage reproductif interdit (13) —, les organoïdes (11), la masse
interne du blastocyste (10), les lignées de CSE (9), le risque majeur des iPS
(7), l'auto-renouvellement illimité des CSE (6), leur immunogénicité (3).
D'où les cartes de cours sur ces mêmes points, sous un autre angle (QROC de la
masse interne, recto-verso clonage/iPS, QCM du droit), pour que l'annale ne se
réussisse pas par cœur.

| Session | N° | Clé imprimée | Retenue | Thème |
|---|---|---|---|---|
| 2024/2025 S1 | Q.3 | aucune (sujet sans corrigé) | **ABCE**, déduite | CSE — 2017/2018 S2 Q.22 à trois mots près |
| 2023/2024 S1 | Q.6 | BCE | BCE | propriétés (aussi BMCP 11, Q.6, BCE) |
| 2022/2023 S1 | Q.8 | ACDE | ACDE | iPS (en-tête « 2023/2022 ») |
| 2022/2023 S2 | Q.4 | ABDE | ABDE | organoïdes (en-tête « 2023/2022 ») |
| 2021/2022 S1 | Q.11 | BC | BC | CSE |
| 2021/2022 S2 | Q.12 | ABCD | ABCD | bioéthique |
| 2020/2021 S1 | Q.16 | aucune | **BCE**, déduite | propriétés |
| 2020/2021 S1 | Q.17 | aucune | **ADE**, déduite | iPS |
| 2020/2021 S2 | Q.18 | ABCDE | ABCDE | CSE |
| 2019/2020 S1 | Q.14 | ABCE | ABCE | bioéthique |
| 2019/2020 S1 | Q.15 | ACDE | ACDE (`a-relire`) | propriétés — hors cours |
| 2019/2020 S2 | Q.16 | aucune | **ABCD**, déduite | propriétés |
| 2018/2019 S1 | Q.12 | ACDE | ACDE | CSE |
| 2018/2019 S1 | Q.13 | ABE | ABE (B signalée) | bioéthique |
| 2018/2019 S2 | Q.14 | ABCDE | ABCDE | organoïdes |
| 2017/2018 S1 | Q.20 | BCDE | BCDE | propriétés |
| 2017/2018 S1 | Q.21 | BDE | BDE | iPS |
| 2017/2018 S2 | Q.22 | ABCDE | ABCDE | CSE |
| 2016/2017 S1 | Q.24 | BDE | BDE | clonage |
| 2016/2017 S2 | Q.23 | ABCDE | ABCDE | CSE (fragment « 24) … tests compa » non repris) |
| 2015/2016 S1 | Q.13 | ABCDE | ABCDE | propriétés |
| 2015/2016 S2 | Q.14 | ACDE | ACDE | propriétés |

Propositions hors du cours 2025-26, dites comme telles dans leur
justification, avec leur source : les cellules souches mésenchymateuses
(2018/2019 S1 Q.13 E, appuyée sur la diapositive p. 7), l'hémorragie et les CSH
et la radio-chimiothérapie qui enrichit en cellules souches tumorales
(2015/2016 S1 Q.13 B, E), l'épuisement du pool et la transition
épithélio-mésenchymateuse (2015/2016 S2 Q.14 C, D), les iPS et les organoïdes
cérébraux (2017/2018 S1 Q.21 E). La hiérarchie tumorale et la LMC (2015/2016
Q.13 D, Q.14 E) s'appuient sur la FC n°11 2025-26, p. 10.

## Les schémas cliquables et la planche

| Fichier | Ce qu'on fait | Cartes |
|---|---|---|
| `potentialites.svg` (nu) / `potentialites-legende.svg` | la frise de la diapositive p. 3, redessinée en quatre stades (ovocyte fécondé et morula, blastocyste, os long de l'adulte, peau de l'adulte) ; on clique des cellules totipotentes, pluripotentes, multipotentes, unipotentes | 4 |
| `csd-pl-clonage.png` / `csd-clonage-therapeutique.png` | la diapositive du clonage thérapeutique (FC n°12 2024-25, p. 8), ses dix légendes anglaises effacées ; une liste fermée de légendes françaises et trois intrus (mère porteuse, fécondation, embryon surnuméraire) | 1 |
| `clonage-ips.svg` | ne se clique pas : le clonage, thérapeutique ou reproductif, et les iPS, d'après les p. 7-10 ; illustre quinze corrections | — |

Le schéma nu ne nomme que les stades, jamais une structure ni une potentialité.
Le **sang de cordon**, que la diapositive range parmi les pluripotentes, n'est
pas dessiné : il ferait une seconde réponse « pluripotente », et le cours y
contredit la référence (voir plus bas) ; la version légendée le cite. Le
trophoblaste n'est pas une zone : seule la masse interne est pluripotente. Les
six noyaux dessinés dans la masse interne sont tous dans son polygone, à plus
d'un rayon du bord (`NOYAUX_MCI`) : à la relecture, trois débordaient dans la
cavité, et un clic sur eux aurait été compté faux.

La planche garde le titre « CLONAGE THERAPEUTIQUE » et les dessins ; les
rectangles effacés sont dans `donnees.py` (`efface=`), et l'image numérotée se
refait avec `planche_depuis_image.py`. Un point d'encre d'un pixel reste au bord
de la flèche noire, près du n°10.

## Les clés qui ne sont pas reprises telles quelles

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2020/2021 S1 Q.16 | « aucune correction » | BCE (`officielle=False`) | la question de 2023/2024 S1 Q.6 (BCE), à un mot près |
| 2020/2021 S1 Q.17 | « aucune correction » | ADE (`officielle=False`), **B et C douteuses** | B « lignées de cellules souches adultes » : le cours ne parle de lignées que pour les CSE ; C « reprogrammation de cellules souches adultes » : l'alternative au clonage reprogramme des cellules différenciées. Proposition du plan, appliquée et signalée (CONFLITS sur B et C) |
| 2019/2020 S2 Q.16 | « pas de correction » | ABCD (`officielle=False`) | les cinq propositions sont cotées ailleurs (E = 2017/2018 S1 Q.20 A, fausse) |
| 2024/2025 S1 Q.3 | aucune (sujet sans corrigé) | **ABCE** (`officielle=False`) | reprise de 2017/2018 S2 Q.22, 2018/2019 S2 Q.14 et 2020/2021 S2 Q.18 (ABCDE) : A perd « par définition », B dit « sont isolées », D dit « limitée » au lieu d'« illimitée » — fausse, l'auto-renouvellement des CSE est illimité (p. 3, 6) |
| 2018/2019 S1 Q.13 B | ABE | **ABE gardée**, ATTENTION | vraie en 2019 ; depuis la loi du 2 août 2021, seule l'importation des CSE exige une autorisation, la conservation et la recherche relèvent d'une déclaration (CSP, art. L2151-6, -8, -9). Conflit déclaré, cas ouvert |

Aucune clé imprimée n'est contredite par le cours. Aucune entrée de l'errata
des annales BMCP ne porte sur ce polycopié.

## Les erreurs du ronéo 2025-26 (ATTENTION nu)

| Page | Le ronéo | Retenu | Sorte | Carte |
|---|---|---|---|---|
| 3 | les cellules souches du sang de cordon « ont une caractéristique de cellules souches pluripotentes » | à l'examen : pluripotentes, comme la diapositive ; la référence : surtout des CSH, multipotentes | le cours lui-même (diapositive, et cours 2024-25 et 2023-24) | `csd-qc-cs-adultes` (E) |
| 4 | « à partir du mésoderme : des cellules cardiaques, des kératinocytes » | à l'examen : mésoderme, comme le tableau du professeur ; la référence : les kératinocytes viennent de l'ectoderme de surface | le cours lui-même — **le plan disait « prise de notes »** : le tableau de la diapositive, reproduit dans le Charonéo 2023-24 (p. 4), range bien « keratinocytes » sous « mesoderm » | `csd-qc-feuillets` (E) |
| 7 | « par un décret de 2006 (1ère loi de bioéthique…) » | premières lois de bioéthique : 1994 ; le décret de 2006 applique la loi de 2004 | prise de notes (le ronéo 2024-25 ne dit que « par un décret de 2006 ») | `csd-qc-origine-cse` (B) |
| 9 | un cocktail de gènes injecté « pour la différencier » | pour la reprogrammer (« dédifférencier », ronéo 2024-25) | prise de notes | `csd-qc-ips` (A) |
| 9 | « Oct 4, Nanog, KLF 4, Sox 2 » et c-Myc en « 5° gène » | les quatre facteurs de Yamanaka : Oct4, Sox2, Klf4, c-Myc ; Nanog est du cocktail de Thomson | point douteux | `csd-fa-ips`, `csd-qc-ips` (C) |
| 9 | essai DMLA « effectué sur 6 patients », « le premier aura une amélioration visuelle » | à l'examen : un premier patient amélioré, des mutations chez le deuxième, l'essai arrêté ; la référence : six patients prévus, deux inclus, un seul greffé, acuité stabilisée (Mandai et al., 2017) | le cours lui-même : l'amélioration revient chaque année (ronéo 2024-25 p. 9, « sur 2 patients » ; Charonéo 2023-24 p. 9, « 2 patients sur 6 ») | `csd-qc-ips-essais` (C) |

Le plan signalait aussi « décret de 2006 » et « différencier » comme points
douteux ; la comparaison avec le ronéo 2024-25 les range en prise de notes.
L'essai DMLA, absent du plan, avait d'abord été rangé en point douteux ; la
relecture l'a rangé en « cours lui-même », puisque les trois années le
racontent de la même façon.

## Le lexique

Dix termes, tous accueillis ici, avec leur origine latine ou grecque :
Totipotent, Pluripotent, Multipotent, Unipotent, Blastocyste, Embryoïde,
Organoïde, Allogénique, Tératome, Parthénogenèse. Pages mesurées dans le PDF de
la FC n°13 (`chercher_pages.py`). Les racines que la FC de sémantique enseigne
(-blaste, allo-, géno-, térat(o)-, -genèse) citent sa page ; les autres sont
grises, « hors FC ».

**Épigénétique**, que le plan donnait à ce chapitre, est laissé à
`immuno_reponse_t`, qui a déjà la note `lex-epigenetique` : un second terme du
même identifiant écraserait le sien à l'import. **Unipotent** le remplace.

Les étymologies nouvelles (7 racines, 10 termes) sont versées dans
`.claude/skills/nouveau-chapitre/scripts/etymologies.json` (intégration du
05/10) ; le texte de
`donnees.py` est déjà celui qu'écrirait `appliquer_etymologies.py` (vérifié).

## À relire

**1 carte** porte le tag `a-relire` : `csd-an-1920s1-q15`, les cellules souches
de cancer mammaire (CD44, CD24, anoïkis), qu'aucun cours ne porte ; sa clé
imprimée est vérifiée sur la littérature. Le tag se retire si Vincent garde la
carte.

## Questions pour Vincent

1. **BMCP 12, 2019/2020 S1 Q.15** (cellules souches de cancer mammaire) : hors
   de tous les cours de cellules souches. Cartée, justifiée sur la littérature,
   `a-relire` (proposition du plan). La garder, ou l'écarter ?
2. **2020/2021 S1 Q.17, sans clé** : B (lignées de cellules souches adultes) et
   C (reprogrammation de cellules souches adultes comme alternative au clonage)
   sont retenues fausses, clé ADE, comme le propose le plan. D'accord ?
3. **2018/2019 S1 Q.13 B** : la clé imprimée (vraie) est gardée, alors que la loi
   de 2021 a remplacé l'autorisation par une déclaration pour la recherche et la
   conservation des CSE. Garder « vrai », ou passer la proposition à faux avec
   `officielle=False` ?
4. **Les kératinocytes du mésoderme** (p. 4) : le plan y voyait une erreur de
   prise de notes ; le tableau du professeur (Charonéo 2023-24) les y range
   lui-même. La carte dit donc « à l'examen : mésoderme ; la référence :
   ectoderme ». D'accord ?
5. **La planche du clonage** vient de la diapositive 2024-25 (légendes
   anglaises), le ronéo 2025-26 n'ayant pas de figure du clonage ; les légendes
   à choisir sont en français. Ça convient ?

## Intégration (05/10)

- Les libellés de thèmes sont dans `THEME_LABELS`
  (`app/src/med_engine/application/scopes.py`), bloc « BMCP FC n°6 à 22 ».
- Les étymologies proposées (racines et termes) sont versées dans
  `.claude/skills/nouveau-chapitre/scripts/etymologies.json` ;
  `appliquer_etymologies.py` n'a rien réécrit, les textes du lexique étant
  déjà à sa forme.

## L'échelle : Simple → Moyen → Annale (C20, 19/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 5 janvier (BMCP) ou du 6 janvier (SSH, papier). Sous les annales, 28 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 7 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`).

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `proprietes-cs` | 6 | 1 | 7 |
| `cse` | 6 | 1 | 6 |
| `organoides` | 2 | 1 | 2 |
| `bioethique-embryons` | 4 | 1 | 3 |
| `clonage` | 1 | 1 | 1 |
| `ips` | 9 | 2 | 3 |

**Le schéma** `ech-cellules-souches`, « Les cellules souches · d'où elles viennent, à quoi elles servent », donne 58 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_CELLULES_SOUCHES`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Sans marche** :
- csd-an-1920s1-q15 A, B, D, E : CD44, CD24, anoïkis et résistance aux radio- et chimiothérapies des cellules souches de cancer mammaire, hors de tout cours de cellules souches (justifiées sur la littérature, carte a-relire) ; lettres posées sur la case la plus proche (risque pour la tumeur, adultes pour les cellules souches adultes, reprog pour la TEM). Seule C (l'auto-renouvellement) a sa marche, csd-ech-s2.
- csd-an-1516s1-q13 B, D, E : l'hémorragie qui active les CSH et la radio-chimiothérapie qui enrichit en cellules souches tumorales sont hors du cours 2025-26 ; la hiérarchie tumorale est dans la FC n°11 2025-26 (bmcp_senescence), qui n'est pas une source de ce chapitre ; lettres posées sur la case la plus proche (risque pour la tumeur, adultes pour les cellules souches adultes, reprog pour la TEM).
- csd-an-1516s2-q14 C, D, E : l'épuisement du pool et la transition épithélio-mésenchymateuse sont hors du cours 2025-26 ; la LMC, maladie de la cellule souche, est dans la FC n°11 2025-26 ; lettres posées sur la case la plus proche (risque pour la tumeur, adultes pour les cellules souches adultes, reprog pour la TEM).
- csd-an-2021s1-q17 B : « lignées de cellules souches adultes », point douteux sans clé (CONFLITS) ; le cours ne parle de lignées que pour les CSE, aucune marche ne le tranche à sa place ; la lettre est posée sur la case des cellules souches adultes.
- csd-an-1819s1-q13 D : le cours 2025-26 ne dit rien du risque des cellules souches adultes en thérapie (le Charonéo 2023-24, p. 6, dit le risque tumoral « inhérent à toutes les cellules souches ») ; la clé (faux) se déduit de ce que le cours 2025-26 attache le risque tumoral aux CSE et aux iPS ; aucune marche, la lettre est posée sur la case des cellules souches adultes.
- csd-an-1718s1-q21 E : le cours dit seulement que les iPS s'utilisent comme les lignées (p. 10), pas qu'elles font des organoïdes cérébraux (la justification s'appuie sur Lancaster et al., Nature 2013) ; la lettre est posée sur la case « Les iPS aujourd'hui ».

## Régénérer

```powershell
cd contenu\chapitres\bmcp_cellules_souches
..\..\..\app\.venv\Scripts\python.exe generer.py
```

`generer.py` est la copie exacte de
`.claude/skills/nouveau-chapitre/scripts/generer_modele.py`. L'image numérotée
de la planche se refait, depuis `app/`, avec
`uv run --with pillow python ../.claude/skills/nouveau-chapitre/scripts/planche_depuis_image.py ../contenu/chapitres/bmcp_cellules_souches csd-pl-clonage --apercus <brouillon>`.
