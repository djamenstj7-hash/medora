# Méthodes d'études en cytogénétique — paquet Génétique

121 notes, 179 cartes. Chapitre `chap-ue-genetique-fc2` de l'UE Génétique.
Cours du **Dr P. Plante-Bordeneuve, le 17/11/2025** (l'en-tête écrit
« Pr. Bordeneuve »), « Méthodes d'études en cytogénétique conventionnelle et
moléculaire » (FC n°2 du Ronéosaure 2025-26, 13 pages) ; annales du polycopié
de génétique n°2 du Ronéosaure 2024-25 (57 questions, 17 sessions). Examen du
16 décembre 2026.

**Une fiche provisoire.** Le ronéo 2026-27 de ce cours n'est pas paru au
02/10/2026 : le chapitre est carté sur le Ronéosaure 2025-26 (tâche C15,
décision de Vincent du 02/10), et le ronéo de l'année corrigera les cartes à
sa parution. La fiche porte son année dans son auteur (« Ronéosaure
2025-26 ») : chaque carte de cours prend le tag `cours-2025-26` et le badge
« Cours 2025-26 ». Aucune carte ne dit « Absent du cours 2026-27 », et les
erreurs du Ronéosaure sont dites par un ATTENTION sans genre : la liste
`contenu/ERRATA_RONEOS_2026-27.md` ne concerne que les ronéos 2026-27.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 78 | 78 |
| QRU | 4 | 4 |
| Texte à trous | 12 | 60 |
| QROC | 10 | 10 |
| Recto-verso | 5 | 5 |
| Schéma cliquable | 2 | 12 |
| Lexique | 10 | 10 |

Dont **57 annales** (55 QRM, 2 QRU — l'ordre des étapes du caryotype, une
seule séquence juste), sur 17 sessions, de 2015/2016 S1 à 2023/2024 S2. Les
25 QCM du cours ont une justification par proposition, comme les annales ;
cinq reprennent tels quels les quiz Wooclap du cours (p. 6, 9, 11, 12) et
sont marqués comme clés officielles, puisque le ronéo en imprime le corrigé.

Huit thèmes, dans l'ordre du cours :

| Clé | Libellé |
|---|---|
| `chromosome-structure` | Chromatine et structure du chromosome |
| `caryotype` | Le caryotype : prélèvement, culture, banding |
| `lecture-caryotype` | Lire un caryotype : classement et formule |
| `fish` | La FISH et ses sondes |
| `oncogenetique` | Gènes de fusion et oncohématologie |
| `cgh-array` | CGH-array (ACPA), CNV et leur interprétation |
| `cartographie-optique` | Cartographie optique du génome |
| `resolution-couverture` | Résolution et couverture des tests génétiques (partagé avec `genet_tests` et `genet_sequencage`, même libellé) |

Les huit libellés sont à ajouter à `THEME_LABELS`
(`app/src/med_engine/application/scopes.py`) ; aucun ne porte de chiffre,
aucune clé n'en recouvre une existante. Le seul échec de
`tests/test_paquets.py` sur ce chapitre est ce libellé manquant.

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-genet-cyt-2526` — Ronéosaure, « FC n°2 Méthodes d_études en cytogénétique » (13 p.), `GÉNÉTIQUE/…` | **2025-26** | **la base** : chaque note du cours porte sa page ; c'est ce que le lecteur ouvre (`chapitre=`) |
| `src-annales-2-methodes-d-etudes-en-cytogenetique-conventionnelle-et-moleculaire` — Ronéosaure, polycopié n°2 (19 p.) | 2024-25 | les 57 questions et leur table de corrections (p. 19) |
| cours de cytogénétique 2023-24 (Charonéo) et 2024-25 (Ronéosaure), Dr E. Boudry | 2023-24, 2024-25 | appoint, cité dans le texte des cartes, à la page, sans être déclaré : puce 60k, mosaïques de moins de 20-30 %, délétion en mosaïque, LAM de l'inv(16), 75-80 °C de la dénaturation |
| FC n°1 (Pr Petit) et FC n°4 (Dr Plante-Bordeneuve) 2025-26 | 2025-26 | citées dans le texte : délais du trophoblaste et de l'amniocentèse (FC n°1 p. 15), polyploïdie et disomie uniparentale (FC n°4 p. 3, 6) |
| erratas : cours 2025-26 (`Erratas Génétique.docx`), annales 2024-25 | — | les entrées de cours sur la FC n°2, reprises (voir plus bas) ; aucune entrée d'annales sur le polycopié n°2 |

Le nom de la fiche est en NFD sur le disque ; `chemin_relatif` l'écrit en
NFC, comme `copier_les_cours.py` compare les noms. **La déclaration du
polycopié d'annales n°2 est partagée** : elle est copiée, champ pour champ, de
celle de `genet_tests`, qui imprime la suite du cas du couple de 2016/2017 S1
(son identifiant écrit « d-etudes ») ; `genet_chromosomes`, qui carte la
2016/2017 S1 Q12 de ce polycopié, doit la reprendre à l'identique — au
02/10, il l'écrit encore `…-methodes-detudes-…`, à aligner dans ce chapitre-là.

**Le PDF est la version imprimée.** L'errata 2025-26 annonce trois images
ajoutées p. 8 de la version numérique (la peinture du 5, l'oncogénétique, le
chromosome Philadelphie) : ce PDF ne les porte pas, et garde les phrases que
l'errata corrige.

## Ce que le cours a dicté

- **Rien de « pas à retenir », pas de gris.** Tout est carté, sauf le
  syndrome « de Katell » (p. 6), cité à côté de Di George et qu'aucun cours ne
  permet d'identifier.
- **Les quiz Wooclap** (p. 3 et 6 sur le chromosome, p. 9 sur la FISH, p. 11
  et 12 sur la cytogénétique et la CGH-array) sont des cartes : cinq tels
  quels avec leur corrigé (`gcy-qc-chromosome`, `gcy-qc-fish-quiz`,
  `gcy-qc-cgh-quiz`, `gcy-qc-resolution-quiz`, `gcy-qc-cgh-detecte`), celui de
  la p. 3 repris et complété (`gcy-qc-genome` : sa proposition « l'ADN est
  présent dans le cytoplasme », cotée fausse, oublie l'ADN mitochondrial ; elle
  n'est pas reprise).
- **Les entrées de l'errata 2025-26** sur la FC n°2 sont dans les cartes :
  annotation des bandes du centromère vers l'extérieur (`gcy-qc-classement`
  C-D, zone « bras p ») ; « séquence ribosomale » = séquences répétées (zone
  « acrocentrique ») ; sondes oligonucléotidiques, complémentarité de bases
  (`gcy-qc-fish-principe` A) ; délétions plus sévères que les duplications
  (`gcy-fa-cnv-criteres`) ; la CGH-array ne voit ni mutation génique ni anomalie
  équilibrée, détecte des polymorphismes, renvoie au caryotype ou à la FISH
  pour le mécanisme et le conseil génétique (`gcy-qc-cgh-limites`,
  `gcy-rv-cgh-av-lim`) ; le titre « technique innovante (pas séquençage) »
  qualifie la cartographie optique (`gcy-fa-cog`).

## Les erreurs du Ronéosaure 2025-26

Chacune est dite par **ATTENTION**, sans genre, dans la carte qui porte la
notion ; le texte qui suit le mot dit sa sorte (« erreur de prise de notes »,
« point douteux », « incohérence interne ») et sa source.

| Page | Ce que dit le Ronéosaure | Ce qui est juste | Sorte | Carte |
|---|---|---|---|---|
| 8 | l'inversion du 16 et la sonde de dissociation : « diagnostic de certitude de leucémie myéloïde chronique » | une leucémie aiguë myéloïde (LAM4 à éosinophiles, CBFB-MYH11) — cours 2023-24 p. 14, 2024-25 p. 9 ; la LMC, c'est la t(9;22) décrite juste après | prise de notes | `gcy-qc-oncogenetique` C, `gcy-rv-sondes-onco` |
| 10 | « on calcule en log base de 2 : log(2) = 0 » | log2(1) = 0, le rapport 2/2 (cours 2023-24 p. 16 et 2024-25 p. 11) | prise de notes | `gcy-fa-log`, `gcy-qc-log2` D |
| 5 | les polyploïdies, « plusieurs chromosomes en nombre irrégulier » | un lot haploïde entier en plus, 69 ou 92 chromosomes (FC n°4 2025-26, p. 3) | prise de notes | `gcy-qc-anomalies` B |
| 5 | hétérochromatine variable des « bras courts 1, 9, 16, Y » | blocs polymorphes sur les bras longs : 1qh, 9qh, 16qh, Yq12 (ISCN) ; le cours 2024-25 ne dit pas de bras | point douteux | `gcy-qc-anomalies` E |
| 4 | trophoblaste « à partir de 12 SA », liquide amniotique « à partir de 14 semaines » | FC n°1 2025-26 p. 15 : 11-13 SA et à partir de 16 SA ; cours 2023-24 (p. 5) et 2024-25 (p. 4) : 12-14 SA et plus de 16 SA | point douteux ; la carte suit la FC n°1 et ne demande pas le chiffre | `gcy-qc-prenatal` C |
| 3, 5 | un gène fait « 20 kb » (quiz p. 3), « 30 kb » (p. 5) | quelques dizaines de kb (cours 2023-24 : 20 à 30 kb) | incohérence interne ; le chiffre n'est pas demandé | `gcy-fa-ordres-grandeur` |
| 11 | « les délétions sont plus importantes que le reste » | plus sévères que les duplications (errata 2025-26) | prise de notes | `gcy-fa-cnv-criteres` |
| 11 | « vers la région 22q1.1 » | 22q11.2 | coquille, sans ATTENTION | `gcy-qr-tbx1` |

Sans ATTENTION, parce qu'aucune réponse n'en dépend : le chromosome 1 à
« 263 Mb » (p. 5 ; environ 249 Mb dans l'assemblage GRCh38, dit dans
`gcy-fa-ordres-grandeur`) ; « 10 Mb (10 mégabases, 107pb) » (p. 2, l'exposant
de 10^7 perdu) ; la CGH-array « 100x que caryotype (150Kb) » (p. 9), quand la
p. 2 dit 100 kb (`gcy-fa-resolution` dit 100 à 150 kb selon la puce).

## Ce que les annales ont dicté

| Savoir | Questions |
|---|---|
| Visible au caryotype, en FISH métaphasique, en CGH-array ? | 2023/2024 S1 Q8 ; S2 Q10 ; 2022/2023 S1 Q10 ; S2 Q19, Q20 ; 2021/2022 S1 Q5, Q6, Q7 ; S2 Q26, Q27 ; 2020/2021 S2 Q6, Q7 ; 2019/2020 S1 Q19, Q20 ; 2017/2018 S2 Q19 ; 2016/2017 S2 Q20, Q21 ; 2015/2016 S1 Q25 ; S2 Q20 ; 2018/2019 S1 Q30 |
| Les étapes et les pièges du caryotype (colchicine, choc hypotonique, banding, métaphase) | 2023/2024 S1 Q6 ; S2 Q9 ; 2022/2023 S1 Q1 ; 2021/2022 S2 Q24 ; 2020/2021 S1 Q28 ; S2 Q5 ; 2019/2020 S2 Q28 ; 2018/2019 S1 Q28 ; 2017/2018 S1 Q16 ; S2 Q17 ; 2016/2017 S1 Q1, Q2 ; S2 Q19 ; 2015/2016 S2 Q28 |
| La FISH : interphase, peinture, sondes, dissociation | 2023/2024 S1 Q7 ; 2022/2023 S1 Q9 ; S2 Q18 ; 2021/2022 S2 Q25 ; 2020/2021 S1 Q29 ; 2019/2020 S2 Q29 ; 2018/2019 S1 Q29 ; 2017/2018 S2 Q18 ; 2017/2018 S1 Q17 (MLL) |
| La CGH-array : hybridation compétitive, cassure, CNV, sondes | 2023/2024 S2 Q11 ; 2021/2022 S1 Q8 ; 2020/2021 S1 Q30 ; 2019/2020 S1 Q21 ; 2016/2017 S1 Q3 ; S2 Q22 |
| Di George et délétion terminale : quelle technique ? | 2020/2021 S2 Q29 ; 2017/2018 S1 Q19 ; 2019/2020 S2 Q4 |
| Lire une figure (FISH, profils de CGH-array) | 2019/2020 S1 Q17 ; S2 Q30 ; 2018/2019 S1 Q26 ; 2017/2018 S1 Q18, Q20 |

**Six figures sont la question** (`illustration_question`, découpées du
polycopié, p. 9, 11, 13, 14) : la photographie de FISH 22q11.21/22q13.3, les
profils 21 et X, la FISH télomérique 3p/3q, la sonde MLL, les profils 10 et
12, la FISH 7q11.23 — dont le titre imprimé, coupé au bord, nomme le locus du
gène de l'élastine « délété dans le syndrome d… » sans dire lequel. La
correction de chacune porte une figure du cours.

Le polycopié compte 58 questions ; la **2016/2017 S1 Q12** (le caryotype du
couple aux fausses couches) est dans `genet_chromosomes`, avec la suite du cas
(Q13-Q14, polycopié n°1, `genet_tests`).

## Les schémas cliquables et les figures

| Fichier | Ce qu'on clique | Cartes |
|---|---|---|
| `gcy-chromosome-nu.svg` (`gcy-zo-chromosome`) | les deux télomères, le bras p, le centromère, le bras q du grand chromosome métaphasique, à gauche ; le métacentrique, le submétacentrique, l'acrocentrique parmi les trois de droite | 8 |
| `gcy-profil-cgh-nu.svg` (`gcy-zo-profil-cgh`) | un gain à +0,58, une délétion homogène à −1, une délétion en mosaïque, deux spots isolés non retenus | 4 |

Chaque libellé du chromosome dit de quel dessin il parle : les trois
silhouettes ont aussi des bras, un centromère et des télomères, et le grand
chromosome est lui-même submétacentrique ; sans cela, un clic juste sur un
autre dessin vaudrait zéro. Pour la même raison, le profil n'a **pas de zone
« région normale »** : il en porte cinq, entre les anomalies, et une zone n'en
couvrirait qu'une. Les zones du profil sont tirées des segments qui dessinent
les spots (`SEGMENTS`, `SPOTS_ISOLES`), et les légendes des deux versions
d'une même table de positions.

Le cours n'a ni schéma du chromosome ni profil de CGH-array dessiné : les
deux sont redessinés d'après ce qu'il décrit (p. 3, 5, 10-11), sans une
légende ; le profil est fictif, avec un bruit reproductible, et garde ses
graduations (−1,5 à +1,5 par demi-unité, sans le 0,58, qu'il faut situer).
La zone « mosaïque » vient du cours 2023-24 (p. 19) : la FC 2025-26 dit
seulement que la CGH-array manque les mosaïques faibles, et deux annales
demandent de distinguer une duplication en mosaïque d'une duplication
homogène. Les versions légendées, tirées des mêmes constantes, sont en
correction. Deux figures de synthèse, sans zone, illustrent les corrections :
**les sept étapes du caryotype** (`gcy-caryotype-etapes.svg`, p. 4-6) et **ce
que voit chaque technique** (`gcy-techniques.svg`, p. 2-12 ; « non dit » pour
ce que la FC ne dit pas de la cartographie optique).

Sept figures de la fiche sont extraites en PNG (p. 5, 6, 7 ×3, 8, 10). Le
cadre de la FISH centromérique (p. 7) déborde sur la FISH télomérique qui la
suit : elle est rognée au bas de sa propre photographie. La diapositive
Wooclap des étapes du caryotype (p. 6) n'est pas reprise : elle liste les
étapes dans le désordre de la question, pas dans celui de la réponse.

**Illustrations** : 82 QCM sur 82 portent une figure en correction ; 111 notes
sur 121.

## Les clés qui ne sont pas reprises telles quelles

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2017/2018 S2 Q18 (FISH) | ABC | **ABCE** | E, « la peinture chromosomique peut être utilisée pour rechercher une insertion chromosomique », est vraie : la FC 2025-26 montre la peinture du 5 qui affirme son insertion dans le 1 (p. 8), comme les cours 2023-24 (p. 14) et 2024-25 (p. 9). Conflit déclaré, carte non marquée officielle |

**Point douteux, clé imprimée reprise** : **2016/2017 S1 Q2 E**, « la technique
de FISH est presque 100 x plus résolutive que le caryotype », cotée vraie. Le
cours 2025-26 dit « 100x » de la CGH-array (p. 9) et donne à la FISH 200 à
400 kb, soit 25 à 50 fois le caryotype ; le cours 2023-24 disait 150 kb, près
de 70 fois. La carte garde la clé, le dit par un ATTENTION, porte le tag
`a-relire`, et le point est déclaré dans `CONFLITS` (deux conflits en tout) :
un point douteux se déclare même quand la clé imprimée est gardée, comme dans
`bmct_variabilite`.

Reprises, avec une remarque dans la carte : **2020/2021 S1 Q30 E** (imprimée
tronquée, « Toutes les variations du nombre », fausse dans toute lecture) ;
**2019/2020 S1 Q17 E** (« Di Georges ») et **2020/2021 S2 Q29** (« délétion
22q11.21 »), énoncés gardés ; **2017/2018 S1 Q20** (la photographie porte son
titre, qui nomme le syndrome). Les notions hors du cours 2025-26 — Williams-
Beuren, Cri-du-chat, puce 60k, gène MLL, bandes RHG, Prader-Willi — sont
dites « hors du cours 2025-26 » dans leur justification, avec leur source ;
aucune question n'en dépend entièrement.

## Questions pour Vincent

1. **2016/2017 S1 Q2 E** (« presque 100 x ») : la clé imprimée est reprise
   comme point douteux. La garder, ou la coter fausse sur le cours 2025-26 ?
2. **2017/2018 S2 Q18 E** : retenue vraie contre la table (ABC → ABCE), sur
   la p. 8 du cours. D'accord ?
3. **La version numérique corrigée de la FC n°2** (celle de l'errata, avec les
   trois images de la p. 8) existe-t-elle quelque part ? Si oui, la déposer :
   les pages et les figures la suivront.
4. Les délais du trophoblaste et de l'amniocentèse diffèrent entre la FC n°2
   (12 SA, 14 semaines) et la FC n°1 (11-13 SA, 16 SA) : la carte suit la FC
   n°1 et ne demande pas le chiffre. Le ronéo 2026-27 tranchera.

## Le lexique

Dix termes, aux pages mesurées dans la fiche 2025-26 (`chercher_pages.py`, la
p. 1 comptée seulement hors du plan) : pangénomique (2, 3, 9-12), caryotype
(2-12), métaphase (2, 3, 5, 6, 7, 9, 11), interphase (6, 7, 9), centromère (3,
5, 6, 7), télomère (3, 6, 7), euchromatine (3, 4, 6), hétérochromatine (3, 4,
5), fluorochrome (7), hybridation (10). Fluorochrome est mesuré à la main sur
le texte de PyMuPDF : pypdf lit la ligature « ﬂ » et ne trouve pas le mot.
« Hétérozygote », que les annales de ce polycopié emploient, est laissé à
`genet_mendelien`, dont la FC le définit. Chacun dit son origine grecque ou
latine.

Les étymologies nouvelles — neuf racines (`pan-`, `caryo-`, `méta-`, `-phase`,
`inter (latin)`, `télo-`, `-chrome / chromat-`, `fluor- (latin)`,
`hybrid- (latin)`) et les dix termes — sont **proposées** dans
`scratchpad/etym/genet_cytogenetique.json`, avec leurs sources (TLFi,
Wiktionnaire, Bailly, Gaffiot, FC de sémantique 2026-27) ; la table n'est pas
modifiée par ce chapitre. Les définitions et les racines disent déjà, mot pour
mot, ce qu'`appliquer_etymologies.py` en écrira. `inter (latin)` reprend la
clé et le sens (« entre, parmi ») que proposent aussi `immuno_infectieux` et
`immuno_reponse_t`, et `-chrome / chromat-` la clé de `genet_chromosomes` :
une racine, une clé. Les racines réemployées
gardent la clé de la table : `géno-`, `-type`, `centrum (latin)`, `-mère`,
`eu-`, `hétéro-`. Celles que la FC de sémantique enseigne citent sa page :
`caryo-` (1/2, p. 8), `géno-` (1/2, p. 6), `-chrome / chromat-` (2/2, p. 7),
`télo-` et `-mère` (2/2, p. 10), `eu-` (2/2, p. 6), `hétéro-` (2/2, p. 5).

## À relire

Une carte `a-relire` : `gcy-an-1617s1-q2`, pour le point douteux de sa
proposition E. Toutes les cartes de cours portent leur page dans la fiche
2025-26. À la parution du ronéo 2026-27 de ce cours, relire toutes les cartes
contre lui : pages, chiffres (résolutions, 20 000 CNV chez 500 personnes,
25 %, délais prénataux), et les erreurs ci-dessus.

## Relecture (02/10/2026)

Chaque carte relue contre la page de la FC qu'elle cite, chaque clé d'annale
contre la table imprimée (p. 19, relue en image) et l'errata, chaque énoncé
d'annale contre le texte du polycopié (mot pour mot), chaque citation des
cours 2023-24 et 2024-25 à sa page. Corrigé : les zones ambiguës des deux
schémas (voir plus haut) ; la FISH centromérique rognée ; la sorte de chaque
erreur du Ronéosaure dite dans son ATTENTION ; le point douteux de 2016/2017
S1 Q2 déclaré dans `CONFLITS` ; « la photographie le dit dans son titre »
(2017/2018 S1 Q20 E), faux, le titre étant coupé ; la FISH interphasique, qui
ne verrait « aucune anomalie équilibrée » — c'est vrai des sondes
télomériques, pas des sondes de dissociation ou de fusion ; « trois annales »
et non quatre pour le distracteur du choc hypotonique ; un « enfant »
hypotonique (p. 7) et non un nouveau-né ; « influe » (p. 4) et non « décide »
pour le terme de la grossesse ; le risque, et non la certitude, d'un enfant
déséquilibré pour un porteur de translocation (p. 8).


## L'échelle : Simple → Moyen → Annale (C20, 18/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 16 décembre. Sous les annales, 57 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 12 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`).

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `caryotype` | 15 | 3 | 14 |
| `lecture-caryotype` | 7 | 2 | 8 |
| `fish` | 14 | 3 | 13 |
| `oncogenetique` | 3 | 1 | 1 |
| `cgh-array` | 12 | 2 | 18 |
| `resolution-couverture` | 6 | 1 | 3 |

**Les schémas** sont au nombre de 2 : `ech-caryotype`, « Le caryotype · l'obtenir, le lire, puis passer la main » (31 Simple, 7 Moyen, 26 annales ; 65 fichiers), et `ech2-fish-cgh`, « Cytogénétique moléculaire · la FISH et la CGH-array » (26 Simple, 5 Moyen, 31 annales ; 63 fichiers). Une carte ou une annale va au schéma de son mécanisme. Ils sont décrits dans `schemas.py` (`ECH_CARYOTYPE`, `ECH2_FISH_CGH`, avec leurs `TROUS_*` et `LETTRES_*`, un `FICHIERS.update` chacun) et dessinés par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Sans marche** :
- gcy-an-1617s1-q2 D (la FISH ne verrait que les anomalies déséquilibrées) : un fait de la FISH, que portent les annales du thème fish (2023/2024 S1 Q7 D, 2022/2023 S1 Q9 E) et que préparent les marches du thème fish (schéma ech2-fish-cgh) ; lettre posée sur la case « FISH », sans marche ici.
- gcy-an-1617s1-q2 E (« presque 100 x » pour la FISH, point douteux déclaré dans CONFLITS, clé imprimée reprise) : la résolution de la FISH (200-400 kb) et le facteur 100 de la CGH-array sont des faits des thèmes fish et cgh-array ; gcy-ech2-s3 (B) et gcy-ech2-s22 (A), qui enseignent ces deux résolutions, portent l'ATTENTION de ce point douteux. Lettre posée sur la case « FISH », sans marche ici.
- gcy-an-1516s2-q28 A et B (le prélèvement fœtal proposé aux couples à risque ; la trisomie 21, la plus recherchée) : faits de la FC n°1 (p. 15) et de la FC n°4 2025-26, absents de la FC n°2 ; lettres posées sur « Le prélèvement » (A) et sur la case du nombre (B), sans marche.
- gcy-an-1516s1-q25 D (la disomie uniparentale) : notion de la FC n°4 2025-26 (p. 6), absente de la FC n°2 ; lettre posée sur la case de ce que voit le caryotype (nombre et structure, que la disomie ne change pas), sans marche.
- gcy-an-1516s2-q20 A (le syndrome de Prader-Willi) : hors du cours 2025-26, sa justification le dit ; lettre posée sur « Caryotype standard · microdélétions : non vues », sans marche.
- gcy-an-2021s2-q29 A, gcy-an-1718s1-q19 B et gcy-an-1920s2-q4 A (la FISH confirme la délétion) : la FISH sur phénotype évocateur, ou pour confirmer une anomalie, est un fait du thème fish (2021/2022 S2 Q25 C, 2019/2020 S2 Q29 C, 2019/2020 S1 Q17), préparé par gcy-ech2-s8 et gcy-ech2-s9 ; lettres posées sur la case « FISH », sans marche ici pour ne pas doubler ces cartes.
- gcy-an-2122s1-q6 C — la triploïdie vue en FISH métaphasique (trois signaux par sonde) est une déduction de la justification de l'annale ; la FC 2025-26 ne le dit pas : aucune carte, lettre posée sur la case des sondes (compter un chromosome).
- gcy-an-1718s1-q20 D, E — Cri-du-chat et Williams-Beuren sont hors du cours 2025-26 : aucune carte, lettres non posées (le raisonnement de la délétion, C, est préparé par gcy-ech2-s7).
- gcy-an-1920s2-q30 A et gcy-an-1718s1-q18 A — la puce 60k (60 000 sondes) est hors du cours 2025-26 (cours 2024-25, p. 10) : aucune carte, lettres non posées.
- gcy-an-1920s2-q30 D et gcy-an-1718s1-q18 D — « visible au caryotype ? » est un fait du caryotype (10 Mb, p. 2-3), que préparent gcy-ech-s16 et gcy-ech-m4 : pas de carte ici ; lettre posée sur la case « Sa résolution », dont la ligne repère porte les 10 Mb.
- gcy-an-1617s1-q3 B et gcy-an-1617s2-q22 D — « plus de sondes, plus de résolution » : la FC 2025-26 dit seulement que les puces sont plus ou moins résolutives (p. 10) ; le lien avec le nombre de sondes vient du cours 2023-24 (p. 17) : aucune carte, lettre posée sur la case « Sa résolution ».

## Régénérer

```powershell
cd contenu\chapitres\genet_cytogenetique
..\..\..\app\.venv\Scripts\python.exe generer.py
```

Les figures PNG ont été extraites de la fiche et du polycopié par PyMuPDF
(rendu de la zone de chaque image, 1100 px de large au plus) ; elles ne se
régénèrent pas avec le paquet.
