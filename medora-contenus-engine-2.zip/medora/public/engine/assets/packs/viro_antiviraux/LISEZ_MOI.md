# La lutte contre les virus — paquet Virologie

93 notes, 146 cartes. Chapitre `chap-ue-virologie-fc8` de l'UE Virologie
(ordre 9). Cours du **Pr Hober, le 05/12/2025**, « La lutte contre les virus »
(FC n°9 du Ronéosaure 2025-26, 13 pages écrites) ; annales des polycopiés
VIROLOGIE 8-9 et VIROLOGIE 10 du Ronéosaure 2024-25 (30 questions, 8
sessions) et du sujet de l'examen du 09/01/2025 (Q14 à Q20, sans corrigé). Examen de virologie le 5 janvier 2027.

**18/10/2026** : 4 questions du sujet de virologie 2025/2026 (examen du
08/01/2026, sans corrigé) — Q.18, Q.19, Q.20, Q.21 ; voir « Le sujet 2025/2026
».

**Une fiche provisoire.** Le ronéo 2026-27 de ce cours n'est pas paru (la
virologie 2026-27 commence le 06/10) : le chapitre est carté sur le
Ronéosaure 2025-26 (décision de Vincent du 02/10), et le ronéo de l'année
corrigera les cartes à sa parution. Aucune carte ne dit « Absent du cours
2026-27 » ; les erreurs du Ronéosaure sont dites par un ATTENTION sans genre,
et n'entrent pas dans `contenu/ERRATA_RONEOS_2026-27.md`, qui ne concerne que
les ronéos 2026-27. Chaque carte de cours porte le badge « Cours 2025-26 »
(ou « Cours 2024-25 » pour les trois cartes de l'introduction, ci-dessous).

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 57 | 57 |
| Texte à trous | 9 | 52 |
| QROC | 9 | 9 |
| Recto-verso | 7 | 7 |
| Schéma cliquable | 2 | 12 |
| Planche à légender | 1 | 1 |
| Lexique | 8 | 8 |

Dont **41 annales** (QRM), sur 10 sessions, de 2019/2020 S1 à 2025/2026 ;
16 QCM du cours, avec une justification par proposition comme les annales.

Sept thèmes :

| Clé | Libellé |
|---|---|
| `cibles-antivirales` | Antiviraux et étapes du cycle viral |
| `analogues-nucleosidiques` | Analogues de nucléosides et de nucléotides |
| `vih` | Le VIH (partagé avec `viro_pathogenes_3`) |
| `grippe` | La grippe (partagé avec `viro_pathogenes_1`) |
| `herpesviridae` | Les Herpesviridae (partagé avec `viro_pathogenes_2`) |
| `resistance-antiviraux` | Toxicité et résistance aux antiviraux |
| `immunotherapie-antivirale` | Immunothérapie antivirale |

Les sept libellés sont à ajouter à `THEME_LABELS`
(`app/src/med_engine/application/scopes.py`) ; aucun n'y est encore. Les
cartes de l'introduction (virucide, virostatique) sont rangées sous
`cibles-antivirales`. Le plan C16 proposait la clé `immunotherapie` : elle
devient `immunotherapie-antivirale` à la relecture, parce qu'un libellé de
thème vaut pour toutes les UE et qu'une immunothérapie des cancers (BMCT,
immunologie) voudrait la clé courte sans le mot « antivirale ».

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-viro-fc9` — Ronéosaure, « FC n°9 La lutte contre les virus » (14 p., la dernière vide), `VIROLOGIE/…` | **2025-26** | **la base** : chaque note du cours porte sa page ; c'est ce que le lecteur ouvre (`chapitre=`) |
| `src-annales-virologie-8-9-chimiotherapie-et-immunotherapie-antivirale` — « VIROLOGIE 8 - 9. Chimiothérapie et immunothérapie antivirale » (10 p.) | 2024-25 | ses 28 questions et sa table de corrections (p. 10) ; `SRC["annales"]` |
| `src-annales-virologie-10-vaccins-viraux` — « VIROLOGIE 10 - Vaccins viraux » (31 p.) | 2024-25 | deux questions (2020/2021 S2 Q.1, table p. 28 ; 2019/2020 S1 Q23, capture p. 17 et réponse p. 29) ; `SRC["sessions"]` de ces deux sessions |
| `src-sujet-viro-2425` — « Sujet de virologie 2024/2025, session 1 » (examen du 09/01/2025, 16 p., 30 QCM) | 2024-25 | ses questions 14 à 20 ; `SRC["sessions"]["2024/2025"]` ; sujet sans corrigé ; déclaration identique dans tous les chapitres de virologie qui en prennent une question |
| `src-cours2425-viro-fc8` — Ronéosaure, « FC n°8 Lutte contre les virus » (14 p.) | 2024-25 | appoint : l'introduction que le ronéo 2025-26 n'a pas transcrite (errata de la promo : « Manque l'introduction de "Lutte contre les virus" », les 8 dernières minutes du 25/11) — antiseptiques, désinfectants, virucide (p. 3), virostatique (p. 4-5) ; trois cartes la citent à la page (`fiche=`) |
| Cours 2024-25 « Lutte contre les virus II » (FC n°9) ; FC n°8 2025-26 (Pathogènes viraux 3) ; FC n°11 2025-26 (vaccins vivants) | 2024-25, 2025-26 | cités dans le texte, à la page, sans être déclarés : le nom tecovirimat, l'oseltamivir « bourgeonnement », l'antisens injecté dans l'œil (2024-25) ; l'IFN α du VHB, la sérovaccination VHB, les 48 semaines, « antiviraux (= virostatiques) » (FC n°8) ; l'éradication de la variole (FC n°11) |
| Erratas du Ronéosaure : cours 2025-26 (`Erratas Virologie.docx`) et annales 2024-25 | — | une entrée sur ce cours (l'introduction manquante, reprise par l'appoint) ; aucune sur VIROLOGIE 8-9 |

**Les deux polycopiés d'annales sont déclarés avec les seuls champs
communs** (identifiant tiré du nom de fichier, `kind`, `titre`,
`chemin_relatif`, `auteur`), pour que tout chapitre de virologie qui en prend
une question les déclare à l'identique ; aucun chapitre ne les déclarait
encore.

Vérifications hors du cours, citées dans la carte qui s'en sert : le
fomivirsen intravitréen, antisens de l'ARNm IE2 du CMV (FDA 1998, PubMed
11365956 ; `avx-qc-perspectives` E) ; le tecovirimat, inhibiteur de VP37
(F13L), la protéine d'enveloppement des orthopoxvirus (EPAR de l'EMA ;
2023/2024 S1 Q.18 B) ; le remdesivir, « nucleotide analog » pour la FDA
(notice de Veklury ; 2023/2024 S2 Q.16 D) ; le foscarnet, qui inhibe aussi la
transcriptase inverse du VIH (Drugs 1994, PubMed 7527325 ; 2022/2023 S1 Q.22
C). L'étymologie : Wiktionnaire, TLFi, Bailly, Gaffiot.

## Ce que le cours a dicté

- **La « question type examen »** (p. 9) : « à quelle étape du cycle viral les
  antiviraux agissent-ils ? Et vis-à-vis de quel virus ? ». Elle a son schéma
  cliquable (douze cartes, deux listes) pour l'étape, et sa planche, la figure
  de l'activation des analogues p. 3, pour le virus ; le texte à trous
  `avx-fa-virus-molecules` reprend la même figure.
- **Ce que le professeur a survolé** : la thérapie cellulaire, « pas vraiment
  abordée », et les vaccins, « survolés car abordés au prochain cours »
  (p. 13) : une phrase chacun, dans le recto-verso `avx-rv-passive-active`.
  Le traitement du VRS de ce passage (ribavirine, anticorps monoclonaux)
  paraît dans `avx-qc-ribavirine` et `avx-qc-imiquimod-sero`, parce que les
  annales le demandent.
- **L'introduction manquante** (errata) : le cours 2024-25 en donne trois
  cartes (`avx-qr-virucide`, `avx-rv-virucide-virostatique`,
  `avx-rv-antiseptique-desinfectant`), qui portent le badge « Cours 2024-25 ».
  Trois annales la demandent.
- **Le rouge et le gris** : la FC n°9 n'a ni l'un ni l'autre ; rien n'est
  écarté.

## Les erreurs du Ronéosaure 2025-26

Chacune est dite par **ATTENTION**, sans genre, dans la carte qui porte la
notion.

| Page | Ce que dit le Ronéosaure | Ce qui est juste | Carte |
|---|---|---|---|
| 11 | « Interféron (INF) de type 1 = alpha ou gamma » | type I = α et β ; γ = type II (la figure de la p. 12 : « IFNs type I (α, β) » ; cours 2024-25, FC n°9 p. 12) | `avx-qc-interferons` A, `avx-rv-types-ifn` |
| 13 | séroprophylaxie du nouveau-né d'une mère « HSV positive », menacé d'infection chronique et de cirrhose | le VHB : immunoglobulines anti-HBs puis vaccin (FC n°8 2025-26, p. 11 ; cours 2024-25, FC n°9 p. 14) | `avx-qc-imiquimod-sero` D |
| 11 | l'oligonucléotide antisens anti-CMV injecté « directement dans le muscle » | dans l'œil, par voie intravitréenne (cours 2024-25, FC n°9 p. 12 ; le fomivirsen) | `avx-qc-perspectives` E |
| 11 | traitements de l'hépatite C « parfois de 48 mois » (le cours 2024-25 l'écrit aussi, FC n°9 p. 12-13 : sans doute le mot du professeur à l'oral) | 48 semaines : la p. 12 du même ronéo, et la FC n°8 2025-26 p. 13 (génotypes 1, 4, 5) | `avx-qc-perspectives` C |
| 9 | « Inhibiteurs de ribonucléotides » (toxicité mitochondriale) | les inhibiteurs nucléosidiques de la transcriptase inverse, qui touchent l'ADN polymérase γ | `avx-qc-effets-secondaires` B, `avx-an-2526-q21` E |
| 9 | « tamiflu = tamivir » | Tamiflu est l'oseltamivir (cours 2024-25, FC n°9 p. 8 ; annales) | `avx-qc-grippe` C |
| 13 | « vaccins conventionnels = vivants inactivés » ; la phrase sur la grippe (« sans adjuvants », « pas contre-indiqué chez la femme enceinte ») | vivants ATTÉNUÉS (ROR, polio orale, fièvre jaune) ; la phrase sur la grippe décrit les vaccins inactivés (cours 2024-25, FC n°9 p. 14) | `avx-rv-passive-active` |

Sans ATTENTION, parce qu'aucune réponse n'en dépend : « l'Amantadine A » (p. 2 :
l'amantadine, active sur la grippe A ; dit dans `avx-qc-attachement-penetration`
C) ; « Paxclovid » (p. 8) ; le remdesivir « inséré dans le brin d'ARN viral
servant de matrice » (p. 6), que les cartes disent seulement « incorporé » ;
« on avait trouvé le remède pour lutter contre les cellules » (p. 12) ; « VRS :
A (le plus fréquent) et B (bronchiolite du nourrisson) » (p. 13), dans le
passage « pas vraiment abordé », non carté — le cours 2024-25 attribue la
bronchiolite au sous-type A.

## Ce que les annales ont dicté

| Savoir | Questions |
|---|---|
| L'aciclovir : prodrogue, entrée dans toutes les cellules, kinase virale, polymérase virale, terminateur de chaîne, HSV-1 | 2024/2025 Q15 ; 2023/2024 S1 et S2 Q.15 ; 2022/2023 S1 et S2 Q.23 ; 2021/2022 S1 et S2 Q.23 |
| Imiquimod, immunoglobulines, anticorps monoclonaux, interféron | 2024/2025 Q20 ; 2023/2024 S1 Q.20 ; 2022/2023 S1 et S2 Q.21 ; 2021/2022 S1 et S2 Q.21 |
| Maraviroc (CCR5), enfuvirtide (gp41), foscarnet (CMV, non incorporé), intégrase, INNTI | 2024/2025 Q14 ; 2023/2024 S2 Q.14 ; 2022/2023 S1 et S2 Q.22 ; 2021/2022 S1 et S2 Q.22 |
| Oseltamivir, pléconaril, antiprotéases (VIH, VHC, pas VHB), résistance par sélection | 2022/2023 S1 et S2 Q.24 ; 2021/2022 S1 et S2 Q.24 |
| Tecovirimat (monkeypox, maturation, sortie), grippe et libération | 2024/2025 Q18 ; 2023/2024 S1 et S2 Q.18 |
| Transcriptase inverse (dans la particule), INTI terminateurs, INNTI, remdesivir, amantadine | 2024/2025 Q16 ; 2023/2024 S1 et S2 Q.16 |
| Intégrase, protéase (dans la particule), Paxlovid, antiprotéases du VHC | 2024/2025 Q17 ; 2023/2024 S1 et S2 Q.17 |
| Toxicité hématopoïétique, mutations de pol (pas env), virus latents, charge virale | 2024/2025 Q19 ; 2023/2024 S1 et S2 Q.19 |
| Virucide, virostatique, éradication (variole, pas fièvre jaune) | 2020/2021 S2 Q.1, 2019/2020 S1 Q23 (VIROLOGIE 10) ; 2023/2024 S2 et 2024/2025 Q14 A |

Les sessions vont par deux : la session 2 reprend la session 1 en retournant
des propositions, ce que chaque `explain` signale (« le miroir de… »). Les 28
questions de VIROLOGIE 8-9 sont toutes ici, et les sept du sujet 2024/2025 qui
reprennent une à une les questions 14 à 20 de 2023/2024 ; VIROLOGIE 10 n'en donne que deux,
celles dont les réponses relèvent de la lutte contre les virus et non des
vaccins (le plan C16 les range ici) : leur `explain` nomme le polycopié.

## Le schéma cliquable et la planche

| Fichier | Ce qu'on clique | Cartes |
|---|---|---|
| `cycle-viral-nu.svg` (`avx-zo-cycle-molecules`) | l'étape où agit le maraviroc, l'amantadine, le pléconaril, l'aciclovir, le ritonavir, l'oseltamivir | 6 |
| `cycle-viral-nu.svg` (`avx-zo-cycle-mecanismes`) | l'étape où se joue le blocage gp120-CCR5, l'action de l'enfuvirtide, le blocage des poches de VP1, l'action du foscarnet, l'inhibition de l'enveloppement des poxvirus (tecovirimat), le blocage du clivage de l'acide sialique | 6 |

Un cycle redessiné sans une légende (`schemas.py`) : la cellule, le virus qui
s'attache en haut à gauche sur ses récepteurs, la vacuole d'endocytose, la
capside ouverte, le noyau où le génome se multiplie, les capsides qui
s'assemblent, le bourgeon et le virus parti en haut à droite. Six zones, une
par étape ; le dessin et les zones lisent les mêmes constantes. La version
légendée, `cycle-viral.svg`, porte les étapes et les molécules du cours, et
précise que la réplication se fait « dans le noyau ou le cytoplasme, selon le
virus » : elle est en correction. La seconde liste de l'ébauche du 03/10
demandait la névirapine à la réplication, dans le noyau du dessin, alors que
la transcription inverse du VIH se fait dans le cytoplasme : remplacée par le
foscarnet (CMV, polymérase d'un herpèsvirus, dans le noyau). AZT, névirapine
et « -gravir » restent cartés en QCM, en QROC et dans la planche.

**La planche** `avx-pl-analogues` : la figure de l'activation des analogues
(p. 3), noms effacés par `scripts/planche_depuis_image.py` — sept numéros
(aciclovir, ganciclovir, zidovudine, lamivudine, cidofovir, foscarnet, INNTI),
chacun désigné par l'ovale de son virus, sa toxicité et sa colonne
d'activation, dont les noms (« ACV MP »…) sont blanchis avec lui, comme les
mots « ganciclovir », « Cidofovir » et « Dérivé de pyrophosphate » ; ddI et
ddC restent lisibles. Quatre intrus : oseltamivir, pléconaril, ribavirine,
remdesivir. L'aperçu de contrôle a été relu ; le rectangle de l'INNTI a été
agrandi d'une ligne de pixels.

**Illustrations** : 56 QCM sur 57 (98 %) portent une figure de la fiche ou le
cycle légendé en correction ; 77 notes sur 93. Le seul QCM sans figure,
`avx-an-2021s2-q1` (virucide, virostatique, fièvre jaune), n'en a pas dans la
fiche. Seize figures de la fiche sont extraites en PNG (`IMAGES`, avec leur
page) ; deux s'ajoutent à l'ébauche du 03/10 : le cycle du SARS-CoV-2 (p. 6)
et les condylomes (p. 12).

## Le sujet 2025/2026 (18/10/2026)

Le sujet de virologie de l'examen du 08/01/2026 (cahier de 30 QCM,
`src-sujet-viro-2526`, sans corrigé), déposé le 18/10/2026, apporte 4
questions à ce chapitre (Q.18, Q.19, Q.20, Q.21) ; les autres questions vont
aux chapitres de leur cours. Aucune n'était déjà en cartes. Chaque clé est
déduite du cours 2025-26, l'année de l'examen, proposition par proposition et
page à l'appui (`officielle=False`) ; les propositions déjà posées d'autres
années ont servi de contre-épreuve, et l'explication dit chaque reprise.
Rédigées et contre-vérifiées le 18/10/2026 : un rédacteur, un sceptique qui a
refait chaque clé sur le cours, un critique de complétude. Le profil des clés
— A souvent vraie, trois ou quatre vraies par question — est celui des
sessions 1 officielles du Pr Hober (2021/2022 S1, 2023/2024 S1).

| Question | Clé imprimée | Retenue | Lecture |
|---|---|---|---|
| 2025/2026 Q.18 (`avx-an-2526-q18`) | aucune (sujet sans corrigé) | **ABDE** | Les antirétroviraux de l'entrée à la transcription inverse : maraviroc sur CCR5 (attachement), enfuvirtide sur la gp41 (pénétration), inhibiteurs nucléosidiques et non nucléosidiques d'une transcriptase inverse qui travaille dès l'arrivée dans le cytoplasme ; C nie l'existence d'un inhibiteur de la pénétration (faux). |
| 2025/2026 Q.19 (`avx-an-2526-q19`) | aucune (sujet sans corrigé) | **ABD** | Une étape, une molécule : pléconaril à la décapsidation des entérovirus, antiprotéases (ritonavir) à la maturation du VIH, tecovirimat à l'enveloppement des poxvirus, oseltamivir à la libération des virus grippaux ; C confond les deux protéases du VIH, la virale qui clive Gag-Pol et la cellulaire qui clive Env. |
| 2025/2026 Q.20 (`avx-an-2526-q20`) | aucune (sujet sans corrigé) | **AD** | L'aciclovir est un analogue de nucléoside sans –OH en 3' : il entre partout, n'est activé que par la kinase virale de la cellule infectée et termine la chaîne, sans muter le génome. |
| 2025/2026 Q.21 (`avx-an-2526-q21`) | aucune (sujet sans corrigé) | **BCE** | Les problèmes des antiviraux : une toxicité pour la moelle et les mitochondries, des résistances par mutation (pol pour la transcriptase inverse), des virus latents hors d'atteinte ; la résistance s'étudie aujourd'hui par séquençage, plus par culture. |

Ce qui est signalé :

- Coquilles gardées telles qu'imprimées : « corecepteur » (Q.18 A), « chaine »
  (Q.20 E), « moëlle » (Q.21 B).
- Q.19 D : le nom « tecovirimat » vient du cours 2024-25 (FC n°9, p. 7) ; le
  ronéo 2025-26 décrit l'inhibiteur de l'enveloppement des poxvirus sans le
  nommer (p. 8).
- Q.20 A : la FC n°11 appelle l'aciclovir « analogue de nucléotide » (p. 9) ; la
  FC n°9 (p. 3), qui fait foi ici, dit « analogue de nucléoside ».
- Q.21 E : le ronéo écrit « inhibiteurs de ribonucléotides » (p. 9) pour les
  inhibiteurs nucléosidiques de la transcriptase inverse ; carte ajoutée à sa
  ligne du tableau des erreurs.

## Les clés qui ne sont pas reprises telles quelles

Les 30 clés imprimées sont reprises, toutes officielles. Les sept de 2024/2025
sont déduites du cours, le sujet n'ayant pas de corrigé (`officielle=False`) :

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2024/2025 Q14 (`avx-an-2425-q14`) | aucune (sujet sans corrigé) | BC | virostatiques, pas virucides (cours 2024-25, FC n°8 p. 3-5) ; maraviroc sur CCR5, enfuvirtide sur la gp41 (p. 2) ; pléconaril à la décapsidation des entérovirus (p. 2) |
| 2024/2025 Q15 (`avx-an-2425-q15`) | aucune | ABDE | prodrogue, entre partout, première phosphorylation virale (p. 3, 9-10) ; sans OH en 3', terminateur de chaîne (p. 3) — l'aciclovir n'a pas de désoxyribose entier, nuance dite sans changer le verdict |
| 2024/2025 Q16 (`avx-an-2425-q16`) | aucune | ABCD | transcriptase inverse dans la particule (p. 5) ; l'amantadine, antigrippal de la pénétration (p. 2) |
| 2024/2025 Q17 (`avx-an-2425-q17`) | aucune | BCE | protéase dans la particule, gag-pol, ritonavir, antiprotéases du VHC (p. 7) |
| 2024/2025 Q18 (`avx-an-2425-q18`) | aucune | BC | tecovirimat : poxvirus, maturation (p. 8 ; cours 2024-25, FC n°9 p. 7) ; oseltamivir : neuraminidase, libération (p. 9) |
| 2024/2025 Q19 (`avx-an-2425-q19`) | aucune | CE | cytotoxicité (p. 9-10) ; pol et non env ; sélection (p. 2, 10) ; latence (p. 10) ; charge virale (p. 8) |
| 2024/2025 Q20 (`avx-an-2425-q20`) | aucune | AD | Ig polyvalentes contre la rougeole, anticorps monoclonaux (p. 13), imiquimod et IFN, condylomes à HPV (p. 12) ; **B** (monoclonaux anti-VRS « chez les personnes âgées ») retenue fausse, point douteux : le cours les donne aux nourrissons et aux « sujets fragiles », le vaccin aux 60 ans et plus (FC n°10 partie 2 p. 9). ATTENTION sur B, conflit déclaré |

Reprises, avec un ATTENTION déclaré dans `CONFLITS` :

| Question | Clé imprimée | Ce qui coince | Retenu |
|---|---|---|---|
| 2021/2022 S1 Q.24 A et 2021/2022 S2 Q.24 A | A vrai (« l'oseltamivir inhibe le bourgeonnement ») | le ronéo 2025-26 place l'oseltamivir à la libération, le virus déjà bourgeonné restant piégé (p. 9), et 2022/2023 S1 Q.24 A écrit « inhibe la libération » ; mais le professeur appelle l'étape « bourgeonnement » (cours 2024-25, FC n°9 p. 8) | clé reprise : à l'examen, vrai |
| 2023/2024 S2 Q.16 D | D vrai (« le remdesivir est un analogue de nucléoside qui n'est pas utilisé contre le VIH ») | le ronéo 2025-26 (p. 6), le cours 2024-25 et la notice FDA disent « analogue de nucléotide » (une prodrogue monophosphatée) | clé reprise : l'item se juge sur le VIH |
| 2022/2023 S1 Q.22 C | C faux (« le foscarnet est un antiviral actif sur le VIH ») | point douteux : le cours ne le dit actif que sur le CMV et HSV résistant (p. 3-4), mais le foscarnet inhibe aussi la transcriptase inverse du VIH (PubMed 7527325), sans indication contre lui | clé reprise : à l'examen, faux, comme le professeur |

Reprises, avec une nuance dans la carte :
**2023/2024 S1 Q.16 D** (le même « analogue de nucléoside » pour le
remdesivir, faux par le VIH) ; **2023/2024 S1 Q.18 C** (« un antiviral actif
sur les virus de la grippe agit à l'étape de libération » : vrai, par
l'oseltamivir). Énoncés imprimés tels quels : « vis -à-vis », « des
antiprotéases activent », « Les antiviraux ont activité virostatique. ».

Les propositions hors du cours 2025-26 le disent dans leur justification, avec
leur source : virucide et virostatique (cours 2024-25, FC n°8 p. 3-5 ; FC n°8
2025-26 p. 18), le nom tecovirimat (cours 2024-25, FC n°9 p. 7), le mot
« prodrogue » (cours 2024-25, FC n°8 p. 9), la fièvre jaune non éradiquée
(cours 2024-25, FC n°8 p. 3).

Cas ouverts : le foscarnet « actif sur le VIH » (ci-dessus), un point douteux
que la carte dit sans le trancher contre le professeur ; les anticorps
monoclonaux anti-VRS « chez les personnes âgées » (2024/2025 Q20 B), retenus
faux sans corrigé pour le confirmer.

## Le lexique

Huit termes, aux pages mesurées dans la FC n°9 2025-26
(`scripts/chercher_pages.py`) : analogue de nucléoside (p. 3-7, 10),
terminateur de chaîne (4, 6), pyrophosphate (4), transcriptase inverse (4, 5,
7, 10), antiprotéase (7, 8), oligonucléotide antisens (11), cytotoxicité (1,
10), immunothérapie (1, 11, 13). Chacun dit son origine grecque ou latine.
« Virostatique » et « virucide » ne sont pas dans le texte de la FC n°9
2025-26 : pas de terme de lexique, des cartes de cours sur l'appoint 2024-25.

Les étymologies nouvelles — trois racines (`analog- (grec)`, `catena
(latin)`, `scribere (latin)`) et les huit termes — sont **proposées** dans
`scratchpad/etym/viro_antiviraux.json`, avec leurs sources ; la table
`scripts/etymologies.json` n'est pas modifiée par ce chapitre. Les définitions
et les racines disent déjà, mot pour mot, ce qu'`appliquer_etymologies.py` en
écrira. Les racines réemployées gardent la clé de la table : `nuclé(o)-`,
`-ose (glucides)`, `terminus (latin)`, `pyr(o)-`, `phosph(o)-` (FC de
sémantique 2/2, p. 12), `trans- (latin)` (2/2, p. 11), `-ase`, `vertere
(latin)`, `anti-`, `prot(é)-`, `olig(o)-`, `cyt(o)- / -cyte` (1/2, p. 8),
`tox(i)-`, `immun(o)-`, `-thérapie` (1/2, p. 5). La clé `ana- (grec)` de la
table (« en remontant ; de nouveau ») ne convient pas à ἀνάλογος (« selon la proportion ») :
d'où la racine `analog- (grec)`. La racine « sens » d'antisens n'est pas
proposée : le français *sens* réunit le latin *sensus* et un francique
*\*sinn* (« direction »), et c'est ce second sens qui est en jeu.

## Questions pour Vincent

Les propositions du plan C16 sont appliquées, et chaque carte concernée le
dit ; elles restent à confirmer :

1. **Virucide et virostatique** viennent de l'introduction 2024-25, absente du
   ronéo 2025-26 (errata) : trois cartes de cours la reprennent avec le badge
   « Cours 2024-25 », et les trois annales qui la demandent (2023/2024 S2
   Q.14 A, 2020/2021 S2 Q.1 C-D, 2019/2020 S1 Q23 B-C) le disent. Les
   garder ainsi jusqu'au ronéo 2026-27 ?
2. **Le nom « tecovirimat »** n'est pas dans le ronéo 2025-26, qui décrit
   l'inhibiteur de la maturation des poxvirus sans le nommer (p. 8) ; deux
   annales le demandent (2023/2024 S1 et S2 Q.18). Il est gardé, cité au cours
   2024-25 (FC n°9, p. 7), dans les annales, le QCM `avx-qc-maturation` et la
   seconde liste du schéma.
3. **« L'oseltamivir inhibe le bourgeonnement »**, coté vrai deux fois : la
   clé du professeur est reprise, avec un ATTENTION qui dit que le cours
   parle de libération. Faut-il, à l'examen, répondre vrai comme le
   professeur (ce que fait la carte) ?
4. **Le remdesivir, « analogue de nucléoside »** pour le professeur,
   « de nucléotide » pour le ronéo : la carte suit la clé (l'item se juge sur
   le VIH), avec un ATTENTION.
5. **Le foscarnet « actif sur le VIH »**, coté faux (2022/2023 S1 Q.22 C) :
   le cours ne le dit actif que sur le CMV, mais il inhibe aussi la
   transcriptase inverse du VIH. La carte garde « faux » comme le professeur,
   avec un ATTENTION « point douteux ». C'est bon ?

## À relire

Aucune carte `a-relire` : chaque carte de cours porte sa page dans la fiche
2025-26 (ou dans l'appoint 2024-25), chaque annale sa clé imprimée, vérifiée —
ou, pour les sept de 2024/2025, sa clé déduite d'une page du cours.
L'ébauche du 03/10 (schemas.py et quatorze figures) a été relue et gardée,
sauf la névirapine de la seconde liste (ci-dessus). La relecture du 05/10
a repris toutes les cartes contre leur page : la proposition A de
`avx-qc-innti` faisait dériver la névirapine et la délavirdine des TIBO
(réécrite sur la phrase du cours) ; deux libellés de zone mal tournés ; les
« 48 mois » aussi dans le cours 2024-25 ; le foscarnet, signalé ; les
sources hors cours citées dans les cartes. À la parution du ronéo
2026-27 de ce cours, relire toutes les cartes contre lui : pages, les sept
erreurs ci-dessus, l'introduction (virucide, virostatique) qui devrait y
reparaître, et les cartes `cours-2024-25`.


## L'échelle : Simple → Moyen → Annale (C20, 19/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 5 janvier. Sous les annales, 42 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 9 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`).

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `cibles-antivirales` | 4 | 1 | 5 |
| `analogues-nucleosidiques` | 2 | 1 | 3 |
| `vih` | 9 | 2 | 8 |
| `grippe` | 5 | 1 | 5 |
| `herpesviridae` | 7 | 1 | 8 |
| `resistance-antiviraux` | 7 | 1 | 4 |
| `immunotherapie-antivirale` | 8 | 2 | 8 |

**Le schéma** `ech-lutte-antivirale`, « La lutte contre les virus · une étape, une cible », donne 93 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_LUTTE_ANTIVIRALE`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Sans marche** :
- avx-an-1920s1-q23 A — la variole éradiquée par la vaccination : la FC n°11 2025-26 (vaccins) le dit, hors des sources de ce chapitre et du schéma des antiviraux ; lettre non posée, faute de case.
- avx-an-2021s2-q1 B — la fièvre jaune non éradicable (réservoir animal, cours 2024-25, FC n°8, p. 3) : une notion des vaccins, hors du schéma ; lettre non posée, faute de case.

## Régénérer

```powershell
cd contenu\chapitres\viro_antiviraux
..\..\..\app\.venv\Scripts\python.exe generer.py
```

La planche se refait depuis `app/`, si ses rectangles changent :
`uv run --with pillow python ../.claude/skills/nouveau-chapitre/scripts/planche_depuis_image.py ../contenu/chapitres/viro_antiviraux avx-pl-analogues --apercus <brouillon>`.
