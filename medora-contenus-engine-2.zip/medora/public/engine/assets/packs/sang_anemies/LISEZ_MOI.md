# Grands types d'anémie — paquet Tissu sanguin

126 notes, 162 cartes. Chapitre `chap-ue-tissu-sanguin-fc5`, cinquième chapitre de
l'UE **Tissu sanguin**. **Cours du 07/10/2026, de 9 h à 11 h, Dr N. Gower, en deux
ronéos Ronéo & Juliette 2026-27** : la partie 1, « Grands types d'anémie : arbres
décisionnels et cas cliniques » (30 p.), et la partie 2, « Arbre décisionnel »
(10 p., cas cliniques, frottis, synthèse). Réaligné sur elles le 19/10/2026 ; il
était carté sur le cours du Pr Chauvet de 2024-25 (Ronéosaure 2024-25, FC n°5), qui
n'est plus qu'un appoint. Annales : 20 questions sur 6 sessions (polycopié du
Ronéosaure 2024-25 et sujet 2024/2025). Examen : partiel du mercredi 4/11/2026.

C'est le cours le plus clinique de l'UE : il part du VGM, décline les trois grands
types, leurs causes — jusqu'aux hémolyses corpusculaires et extra-corpusculaires —,
et finit sur neuf cas cliniques et la lecture du frottis.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 51 | 51 |
| QRU | 31 | 31 |
| QROC | 14 | 14 |
| Recto-verso | 13 | 13 |
| Texte à trous | 9 | 36 |
| Lexique | 7 | 7 |
| Schéma cliquable | 1 | 10 |

Dont **20 annales** (12 QCM, 8 QROC) sur 6 sessions, et l'échelle : **29 cartes
Simple, 8 cartes Moyen**. **77 QCM sur 82 illustrés (94 %)**, 92 notes sur 126.
**1 carte absente du cours 2026-27** (tag `absent-2026`), **20 cartes portent un
piège des ronéos** (thème « Pièges des ronéos »). Aucune carte `a-relire`.

Six thèmes, déjà dans `THEME_LABELS` ; le réalignement n'en ajoute aucun :
`demarche`, `clinique`, `microcytaire`, `regenerative`, `hemolyse`, `aregenerative`.

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-sang-anemies-2627-1` — « Grands types d'anémie : arbres décisionnels et cas cliniques », `Tissu sanguin/ANÉMIES ET ARBRE DÉCISIONNEL 1.pdf` (30 p.) | **2026-27** | **ronéo 1**, 9 h-10 h : physiologie, métabolismes, mécanismes, hémogramme normal, clinique (p. 2-7) ; microcytaire (p. 7-11) ; normo/macrocytaire arégénérative, B9-B12, Biermer, myélogramme et BOM (p. 11-15) ; hémolyse (p. 15-17) ; hémolyses corpusculaires et extra-corpusculaires (p. 18-24) ; cas cliniques 1 à 5 (p. 25-30). `SRC["fiche"]`, ce que le lecteur ouvre ; 98 notes |
| `src-fc-sang-anemies-2627-2` — « Arbre décisionnel », `Tissu sanguin/(ANÉMIE) ET ARBRE DÉCISIONNEL 2.pdf` (10 p.) | **2026-27** | **ronéo 2**, 10 h-11 h : méthode, cas cliniques 1 à 9 (p. 2-9), lecture du frottis (p. 9), synthèse et tolérance (p. 9-10) ; `fiche=FC2` ; 7 notes |
| `src-cours-sang-anemies` — FC n°5 du Pr Chauvet (22 p.) | 2024-25 | **appoint** (`SRC["cours"]`, sans `chapitre=`) : ce que les ronéos 2026-27 ne reprennent pas, et la source de la carte absente |
| `src-annales-sang-anemies` — polycopié d'annales (6 p.) | 2024-25 | 6 sessions, table de corrections |
| `src-sujets-sang-2425` — sujet 2024/2025, session 1 | 2024-25 | sans corrigé, clés déduites du cours |

Les textes citent « ronéo 1, p. 11 », « ronéo 2, p. 6 », « cours 2024-25, p. 11 » et
« FC 2025-26, p. 3 ». Lus en appoint, sans être déclarés : les FC 2025-26 du Pr Podvin
(« Grands types d'anémies ») et du Pr Gazeau (« Arbres décisionnels et cas
cliniques »). Les deux fiches de l'année se copient dans le dossier des PDF de
l'application par `outils/copier_les_cours.py`, lancé avec le dossier
`Ajouts/[NUMERIQUE] Ronéo & Juliette 26-27 19 10 2026/S1/CM`, hors du bac à sable.

Les en-têtes des ronéos nomment leurs rédacteurs et leurs correcteurs : aucun nom
n'est repris.

## Ce qui correspond à quoi

| Cours 2024-25 (Pr Chauvet) | Ronéo 2026-27 |
|---|---|
| I. Érythropoïèse, ingrédients, délais (p. 2-3) | ronéo 1, p. 2-3 (et les métabolismes du fer, de la B9, de la B12) |
| II. Définition, normes, syndrome anémique, VGM (p. 3-5) | ronéo 1, p. 4-7 (et les deux mécanismes, l'hémogramme normal) |
| III. Microcytaire : carence martiale, inflammation, thalassémie, bilan HAS (p. 5-10) | ronéo 1, p. 7-11 |
| IV. Régénérative : hémorragies, hémolyses, causes, bilan (p. 11-16) | ronéo 1, p. 15-25 ; ronéo 2, p. 4-9 |
| V. Non régénérative : myélogramme, BOM, B9-B12, Biermer, causes (p. 16-19) | ronéo 1, p. 11-15 |
| VI. Exercices (p. 19-22) | cas cliniques : ronéo 1, p. 25-30 ; ronéo 2, p. 2-9 |
| VII. Boîte à outils (p. 22) | **absente** — d'où la carte `ane-ech-s30` |
| — | **nouveau** : causes non hématologiques d'anémie normocytaire arégénérative, sphérocytose, HPN, G6PD et PK, AHAI, MAT, paludisme, lecture du frottis, tolérance |

## Le réalignement du 19/10/2026

Les 92 notes de la version 2024-25 ont été relues une à une contre les deux ronéos.
**71 citent désormais leur page de l'année** (et perdent toute marque d'une autre
année) : les 35 notes de cours et 36 des 37 marches de l'échelle ; les 20 annales
citent la page de l'année en source secondaire. Avec les 34 notes nouvelles, 105
notes du chapitre citent une page des ronéos 2026-27 (98 la partie 1, 7 la partie 2). Dans ces cartes, chaque
proposition que seul un cours précédent porte le dit dans sa justification
(« cours 2024-25, p. 7 ; le ronéo 2026-27 n'en parle pas »).

**Ce que le cours 2026-27 dit autrement, et ce qui a été réécrit** :

- **Le seuil des réticulocytes passe de 150 000/mm³ à 120 G/L**, dans le texte et
  sur l'arbre de la diapositive (ronéo 1, p. 11, 16, 24 ; ronéo 2, p. 9) ; norme
  25-100 G/L (diapositive, p. 5). Réécrits : `ane-qc-regenerative` A,
  `ane-fa-seuils` (c4), `ane-ech-s8` (options 20, 120, 150 G/L), `ane-ech-m3` B,
  le schéma de l'échelle (case « Réticulocytes ») et l'arbre cliquable. La QROC 3 de
  2021/2022 (`ane-an-qr-seuils`) répond 120 G/L et n'est plus officielle.
- **Les délais** : production d'un globule rouge en 7 jours, délai minimal de
  3 jours après une hémorragie (ronéo 1, p. 2) : `ane-qc-ingredients` E,
  `ane-fa-delais` (c1, c2), `ane-ech-s25` (options « 7 jours », « Moins de
  30 jours » — la durée de vie d'une hémolyse, p. 16). Crise réticulocytaire à
  7-10 jours, vers 300 000/mm³ (p. 9) : `ane-qc-traitement` E.
- **Le fer se donne toujours per os** (p. 9) : `ane-qc-traitement` D demande
  désormais la voie IV (fausse) ; la transfusion du cours 2024-25 passe dans sa
  justification.
- **Les normes de l'enfant sont « pas à savoir »** (p. 6) : `ane-qc-normes` B et C
  portent sur les seuils de l'adulte.
- **Les dysthyroïdies** sont rangées parmi les anémies normocytaires arégénératives
  non hématologiques (p. 12) ; `ane-qc-centrales` D porte sur la cirrhose.
- **La B9-B12** : la macrocytose « la plus grosse », évoquée dès 100 fL, au lieu
  du VGM > 120 fL (`ane-qc-b12` A, `ane-ech-s15` B).
- **L'HPN** : le gène PIG-A et l'ancre GPI de la figure (p. 20) ; « nocturne » par
  les urines porto du matin (`ane-rv-hpn`).
- **Les signes** de la carence martiale (ongles cassants au lieu de la
  koïlonychie, `ane-qr-perlecher`), les déclencheurs du favisme (médicaments
  oxydants, fièvre, infections, `ane-qr-favisme`), le mécanisme de l'anémie
  inflammatoire (hepcidine, `ane-rv-hepcidine`), la pâleur aux paumes
  (`ane-qc-syndrome` B, `ane-ech-m7` D), la triade de la MAT
  (`ane-rv-schizocytes`), le délai de régénération (`ane-rv-brutale`), le
  myélogramme et la BOM (`ane-rv-myelo-bom`), l'anémie mixte, désormais taguée `edn`
  (« à apprendre au moment des EDN », p. 10 : `ane-rv-mixte`).
- **Les figures** : les deux figures 2024-25 (`anemie-hemolyse-tda.png`,
  `anemie-reticulocytes.png`, cette dernière au seuil de 150 000) ne sont plus
  déclarées ; leurs fichiers restent dans `media/`. Douze figures de l'année les
  remplacent (ronéo 1, p. 4, 5, 7, 10, 15, 17, 20, 21, 24, 25 ; ronéo 2, p. 8, 9),
  extraites des PDF à 180 dpi, et chaque annale garde désormais une figure du cours.

**Notes nouvelles (34)**, sur ce que le cours 2026-27 apporte :

| Note | Ce qu'elle carte |
|---|---|
| `ane-qc-mecanismes` | anémie périphérique ou centrale, séparées par les réticulocytes (ronéo 1, p. 4) |
| `ane-qc-hemogramme-lecture` | hématies sans intérêt, VGM 80-100, CCMH, fausses polyglobulies, norme des réticulocytes (p. 5) |
| `ane-qc-metabolismes` | fer au duodénum et recyclé, B12 végétaux/FI/iléon, réserves de B9 (p. 3) |
| `ane-qc-carence-evolution` | ferritine → microcytose → anémie, correction inverse, crise réticulocytaire (p. 9) |
| `ane-qc-thal-mineure` | cas clinique 2 : microcytose disproportionnée, pseudo-polyglobulie, électrophorèse (p. 26-27) |
| `ane-qc-b12-causes` | Biermer, chirurgie gastrique, Crohn iléal, apport, bothriocéphale (p. 12-13) |
| `ane-qc-b9-b12-pieges` | pancytopénie, pseudo-MAT, hémolyse, réticulocytes bas, B9 seule (p. 12-13) |
| `ane-qc-myelogramme-richesse` | SMD, leucémie aiguë, myélome, aplasie et myélofibrose à la BOM (p. 14-15) |
| `ane-qc-corpusculaire` | membrane, enzyme, hémoglobine ; HPN seule acquise ; G6PD lié à l'X (p. 18-21) |
| `ane-qc-spherocytose` | dominante, intra-splénique, EMA et ektacytométrie, splénectomie (p. 18-19) |
| `ane-qc-hpn` | acquise, CD55/CD59, intravasculaire, thromboses, cytométrie de flux (p. 19-20) |
| `ane-qc-drepanocytose` | Hb S, normocytaire, Howell-Jolly, électrophorèse, allogreffe (p. 21-22) |
| `ane-qc-frottis-faucilles` | QRU, la photo du frottis en question : cas clinique 9 (ronéo 2, p. 8-9) |
| `ane-qc-howell-jolly` | QRU, la photo du frottis en question : corps de Howell-Jolly, asplénie (p. 21) |
| `ane-qc-extracorpusculaire` | TDA, MAT, causes infectieuses et toxiques, AHAI et son traitement (p. 22-25, 30) |
| `ane-qc-mat` | cas clinique 6 : MAT, triade, SHU typique, schizocytes (ronéo 2, p. 6) |
| `ane-qc-paludisme` | cas clinique 8 : retour du Mali, frottis et goutte épaisse, panier percé (ronéo 2, p. 7-8) |
| `ane-fa-bilan-martial` | le tableau du bilan du fer (p. 10) |
| `ane-fa-thalassemie` | 4 gènes alpha, 2 bêta ; létale, hémoglobinose H (p. 10) |
| `ane-fa-demarche` | la démarche pas à pas de la synthèse (ronéo 2, p. 9) |
| `ane-qr-normo-non-hemato` | causes non hématologiques d'anémie normocytaire arégénérative (p. 12) |
| `ane-qr-cvo` | déclencheurs des crises vaso-occlusives (p. 21) |
| `ane-rv-b9-seule` | jamais de B9 seule si la B12 manque aussi (p. 13) |
| `ane-rv-tolerance` | « Quelle est la tolérance ? » (ronéo 2, p. 9-10) |
| `ane-rv-bandelette` | bandelette positive, ECBU sans hématies : hémoglobinurie (p. 16) |
| `ane-rv-macro-regen` | une anémie hémolytique peut être macrocytaire (p. 23, 25) |
| `ane-rv-g6pd-dosage` | le dosage de la G6PD, en dehors d'une poussée (p. 20) ; ajoutée à la contre-relecture |
| 7 termes de lexique | voir plus bas |

## Absent du cours 2026-27

Une carte, `ane-ech-s30` (marche Simple : syndrome hémorragique cutanéo-muqueux et
fièvre → insuffisance médullaire). Elle vient de la boîte à outils du cours 2024-25
(p. 22), reprise par la FC des arbres 2025-26 (p. 6) ; aucun des deux ronéos du
07/10/2026 ne la reprend. Elle garde sa case dans le schéma de l'échelle, cite le
cours 2024-25 à sa page, porte le tag `absent-2026` et la phrase « Absent du cours
2026-27 » en tête de son explication.

## Les erreurs des ronéos 2026-27

Le tableau d'erreurs de la promo (19/10) en relève une pour ce cours ; les autres ont
été trouvées en relisant. Chacune est portée là où la notion se joue :

| Page | Ce que dit le ronéo | Ce qui est juste | Genre | Carte |
|---|---|---|---|---|
| ronéo 1, p. 22 | « alobratre » | allogreffe (tableau de la promo) | prise de notes | `ane-qc-drepanocytose` E |
| ronéo 1, p. 10 | thalassémie : « on produit des Hb qui sont malades » | Hb normale en quantité insuffisante (même page ; FC 2025-26, p. 11) | prise de notes | `ane-qc-thalassemie` A |
| ronéo 1, p. 17 | anticorps « à la surface de l'hémoglobine rouge » | du globule rouge (p. 29 ; ronéo 2, p. 5) | prise de notes | `ane-qc-bilan-hemolyse` E |
| ronéo 1, p. 17, 22, 23 | « anémie mimétique » | anémie hémolytique (p. 22, 24-25 ; ronéo 2, p. 5) | prise de notes | `ane-qc-extracorpusculaire` A |
| ronéo 1, p. 11 | réticulocytes « Norme : 20-100 G/L » | 25-100 G/L, diapositive p. 5 | prise de notes | `ane-qc-hemogramme-lecture` E |
| ronéo 1, p. 3 | B9 : « Très grosses réserves » | 2 à 4 mois (même page ; cours 2024-25 ; Manuel MSD) | prise de notes | `ane-qc-metabolismes` D, `ane-qc-b12` E |
| ronéo 1, p. 12 | la sleeve : l'estomac « produire de la B12 » | le facteur intrinsèque (même page) | prise de notes | `ane-qc-b12-causes` B |
| ronéo 1, p. 12 | hémolyse des carences par des « GR trop vieux » | érythropoïèse inefficace, hémolyse intramédullaire (p. 4 ; cours précédents ; Wu et al., Bioengineered 2021) | prise de notes | `ane-qc-b9-b12-pieges` C |
| ronéo 1, p. 14 | myélogramme : « aspect histologique » | cytologique (p. 13 ; cours précédents) | prise de notes | `ane-rv-myelo-bom` |
| ronéo 1, p. 19 | CD55/59, « protéine d'ancrage » ; « gène gemenique » | protéines GPI-ancrées ; mutant PIG-A (figure, p. 20) | prise de notes | `ane-rv-hpn` |
| ronéo 2, p. 6 | schizocytes = « globules blancs fragmentés » | hématies fragmentées (diapositive, p. 9) | prise de notes | `ane-qc-mat` D |
| ronéo 2, p. 9 | « Pas de frottis sanguin » | le frottis est l'un des deux examens (ronéo 2, p. 5 ; ronéo 1, p. 17, 25) | prise de notes | `ane-fa-demarche` |
| ronéo 2, p. 2, 5, 8 | « LDL augmente » | LDH, lactate déshydrogénases (ronéo 1, p. 17, 28) | prise de notes | `ane-fa-hemolyse` |
| ronéo 2, p. 4 | cas 4 : « haptoglobine augmentée → profil biologique d'hémolyse » | diminuée, comme le bilan du même cas (ronéo 2, p. 4 ; ronéo 1, p. 17, 28) | prise de notes | `ane-fa-hemolyse` |
| ronéo 1, p. 7 | « > 80 fL = normal / normocytaire » | 80-100 fL (même page ; diapositive p. 5) | prise de notes | `ane-fa-seuils` |
| ronéo 1, p. 6 | l'hémodilution fait « augmenter » la concentration plasmatique | elle augmente le volume plasmatique (p. 5 ; cours 2024-25, p. 3) | prise de notes | `ane-qc-definition` E |
| ronéo 1, p. 16 | hémolyse intravasculaire : « pas de splénomégalie » | « +/- » au tableau de la diapositive (p. 17 ; FC 2025-26, p. 8 ; cours 2024-25, p. 12) | prise de notes | `ane-rv-triade` |
| ronéo 1, p. 11 | « L'alpha-thalassémie est présente en Asie mais pas de bêta-thalassémie » | c'est le cours lui-même (FC 2025-26, p. 6 : bêta méditerranéenne, alpha en Afrique ou en Asie) ; à l'examen, alpha en Asie ; la référence : la bêta est fréquente en Asie du Sud-Est (Modell et Darlison, Bull OMS 2008, tableau 3) | cours | `ane-qc-thalassemie` |
| ronéo 1, p. 8 | « Si le fer est bas c'est égal à une carence martiale » | le fer sérique est bas aussi dans l'inflammation (tableau p. 10) ; « Fe » = ferritine sur l'arbre | douteux | `ane-qc-inflammatoire` E |
| ronéo 1, p. 19 | HPN, « la seule cause d'hémolyse intra vasculaire chronique » | la valve mécanique aussi ; la diapositive dit « penser HPN » (p. 25) | douteux | `ane-rv-hpn` |
| ronéo 1, p. 19 | sphérocytose : « toujours une histoire familiale » | forme dominante dans environ 75 % des cas, sinon récessive ou mutation nouvelle (MedlinePlus Genetics) | douteux | `ane-qc-spherocytose` A |
| ronéo 1, p. 19 | sphérocytose : « greffe de moelle osseuse » | absente des cours précédents ; rien ne tranche | douteux | `ane-qc-spherocytose` E |
| ronéo 1, p. 22 | allogreffe et thérapie génique, « traitements symptomatiques » | l'allogreffe HLA-identique de la fratrie est curative (Vidal ; Académie de médecine) | douteux | `ane-qc-drepanocytose` E |
| ronéo 1, p. 22 | AHAI « rarement primitif », puis primitive « dans la moitié des cas » | primitive dans la moitié des cas environ (Kalfa, ASH Education Program 2016) | douteux | `ane-qc-extracorpusculaire` |
| ronéo 1, p. 20 | « comme la liastrenie en hydrologie » | sans doute la myasthénie en neurologie | douteux | `ane-qr-favisme` |

Les `ATTENTION` nus disent deux années qui se contredisent : 120 G/L contre 150 000/mm³
(`ane-qc-regenerative`, `ane-fa-seuils`, `ane-ech-s8`, `ane-ech-m3`,
`ane-an-qr-seuils`), 7 jours contre 6-7 ou 5 (`ane-fa-delais`, `ane-ech-s25`), DFG
< 35 contre clairance < 30 mL/min (`ane-qc-centrales`), les réticulocytes devant
toute anémie de la FC 2025-26 (`ane-ech-s6`, `ane-ech-m3`, `ane-an-qr-dosage`),
l'errata « macrocytaire » de 2023/2024 QCM 7 (`ane-ech-m1`, `-m4`, `-s16`) et la
borne de 82 μm³ de 2020/2021 QCM 4 (`ane-ech-s4`, `-m2`).

## Les clés qui ne sont pas reprises telles quelles

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2021/2022, QROC 3 (`ane-an-qr-seuils`) | VGM 80/100 fL, réticulocytes **150 G/L** | **120 G/L** | le seuil du cours 2026-27, texte et diapositive (ronéo 1, p. 11, 16, 24 ; ronéo 2, p. 9) ; `officielle=False`, `ATTENTION` en tête de l'explication |
| 2024/2025, QCM 3 (`ane-an-2425-q3`) | aucune ; surlignée : CD | **CD** | frottis et test direct à l'antiglobuline (ronéo 1, p. 17, 24) |
| 2024/2025, QCM 4 (`ane-an-2425-q4`) | aucune ; surlignée : ABD | **ABD** | les trois causes de microcytose (ronéo 1, p. 7-11) |
| 2024/2025, QCM 7 (`ane-an-2425-q7`) | aucune ; surlignée : D | **D** | seuil 120 G/L, ferritine d'abord devant une microcytose (ronéo 1, p. 11) |
| 2024/2025, QROC 2 et 3 (cinq cartes) | aucune | réponses du cours | ronéo 1, p. 2-11, 25-26 ; ronéo 2026-27 de l'hémogramme, p. 14 |

Aucune clé de QCM n'est contredite par le cours 2026-27 : `CONFLITS` reste vide.
Les items de seuil des annales (« > 20 000/mm³ ») restent faux, à 120 comme à
150 000. L'errata des annales qui propose « macrocytaire » pour 2023/2024 QCM 7
n'est toujours pas suivi : le cours 2026-27 dit que l'IRC « ne donne jamais d'anémie
macrocytaire » (ronéo 1, p. 12). 2020/2021 QCM 2 B (l'indium) a désormais sa
justification : la méthode de référence marque les hématies au chrome 51 (ICSH 1980).

**La correction surlignée (officieuse)** des sujets 2024/2025 sert de seconde
opinion, jamais de clé : elle coïncide ici avec le cours.

**Trois questions du fascicule sont cartées ailleurs** (« Hémogramme et
myélogramme » : l'examen devant une microcytose, les polyglobulies, la polyglobulie
secondaire), et la clé de « 2019/2020, Q10 » n'a pas d'énoncé.

## L'échelle : Simple → Moyen → Annale (C20)

29 cartes Simple et 8 Moyen sous les annales, toutes relues sur les ronéos 2026-27 :

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `demarche` | 1 | 1 | 3 |
| `clinique` | 2 | 1 | 1 |
| `microcytaire` | 11 | 2 | 8 |
| `regenerative` | 4 | 1 | 3 |
| `hemolyse` | 7 | 2 | 3 |
| `aregenerative` | 4 | 1 | 2 |

Le schéma `ech-anemies` (`schemas.py`, `ECH_ANEMIES`) est redessiné d'après le ronéo
2026-27 et le dit dans sa légende ; une seule case a changé : « seuil : 120 G/L ».
Réécrits avec lui : `ane-ech-s8` (20, 120, 150 G/L), `ane-ech-m3` B (120 G/L),
`ane-ech-s25` (7 jours, 120 jours, moins de 30 jours), `ane-ech-s15` B
(« macrocytaire, souvent très marquée »), `ane-ech-s26` (le signe « majeur »,
l'haptoglobine, « le seul vraiment important »), `ane-ech-m7` D (la pâleur, « signe
direct »). Les clés Simple restent réparties entre A, B et C ; les Moyen gardent de
une à trois vraies. `ane-ech-s30` est la seule marche absente du cours de l'année.

Une coïncidence de chiffres, sans indice de forme : « 120 jours » (durée de vie)
et « 120 G/L » (seuil des réticulocytes) se lisent sur le même schéma ; chacune des
deux cases est effacée dans sa propre marche (`ane-ech-s25`, `ane-ech-s8`).

**Sans marche** : 2022/2023 QCM 8 B (le bleu de crésyl, ronéo 2026-27 des cellules
souches, p. 7), 2020/2021 QCM 2 B (l'isotope de référence, aucun cours) et
2020/2021 QCM 4 E (la TCMH, que la diapositive de l'hémogramme cite sans la définir).

## Le schéma cliquable : les causes, pas la démarche

`arbre-types-anemie.svg` : le VGM, les trois types, les causes de la microcytose,
les réticulocytes au seuil de **120 G/L**, et ce que chaque issue fait chercher. Le
FC n°3 porte la démarche ; celui-ci, les étiologies.

## Le lexique

Sept termes accueillis ici, avec leurs pages mesurées dans le texte des ronéos :
**anémie**, **microcytose**, **thalassémie**, **drépanocytose**, **sphérocytose**,
**schizocyte**, **hémoglobinurie**. Leur étymologie est écrite dans la définition ; les
propositions pour `etymologies.json` (sept termes, trois racines nouvelles :
`thalass(o)-`, `drépan(o)-`, `sphér(o)-`) attendent d'y être reportées. Les autres
chapitres de l'UE qui ont un lexique (`sang_gr`, `sang_exploration`,
`sang_hemorragies`) accueillent d'autres termes ; perlèche et ictère restent à la
sémiologie. Les pages de « microcytose » sont celles que mesure
`chercher_pages.py` (le mot, pas « microcytaire »).

## La contre-relecture du 19/10/2026

Un second relecteur a repris chaque carte nouvelle ou réécrite contre sa page et
son image. Ce qu'il a changé :

- **la thalassémie en Asie** passe de « douteux » à `ATTENTION (cours)` : la FC
  2025-26 rangeait déjà la bêta autour de la Méditerranée et l'alpha en Afrique
  ou en Asie (p. 6) ; la carte dit ce qu'on répond à l'examen, puis la référence ;
- **quatre erreurs de prise de notes** sont portées par une carte :
  « > 80 fL = normocytaire » (`ane-fa-seuils`), la « concentration plasmatique »
  de l'hémodilution (`ane-qc-definition` E), les « très grosses réserves » de B9
  (aussi sur `ane-qc-b12` E, qui en dépend), et « pas de splénomégalie » dans
  l'hémolyse intravasculaire, « +/- » au tableau (`ane-rv-triade`) ;
- **les sources** : Bioengineered 2021 (et non 2022) pour l'hémolyse des
  carences, avec sa nuance (une part hors de la moelle) ; MedlinePlus Genetics
  pour l'hérédité de la sphérocytose ; Kalfa 2016 pour l'AHAI ;
- **les explications** où un `ATTENTION (prise de notes)` ou `(douteux)` avalait
  la suite du texte (`ane-rv-hpn`, `ane-qr-favisme`, `ane-rv-myelo-bom`,
  `ane-fa-demarche`, `ane-fa-delais`) mettent le cours d'abord, l'avertissement
  ensuite : l'encadré court jusqu'à la fin du texte ;
- **une note nouvelle**, `ane-rv-g6pd-dosage` : le dosage de la G6PD se fait en
  dehors d'une poussée (ronéo 1, p. 20) ; et `ane-qr-cvo` cite les « 3 facteurs
  de l'hypoxie » de la page 22.

## Les stades ne sont pas cartés

Consigne de Vincent pour toute l'UE (18/09) : aucune carte ne fait nommer ou ordonner
les stades d'une lignée, ni le détail des facteurs de transcription.

## Questions pour Vincent

- Le seuil des réticulocytes : les cartes répondent 120 G/L, comme le cours 2026-27,
  et la QROC 3 de 2021/2022 n'est plus officielle. Faut-il garder 150 en réponse
  acceptable ?
- `CHAPITRE.semaine` écrit « Dr N. Gower », comme les en-têtes, et non « Pr ».
- Les deux anciennes figures 2024-25 restent dans `media/` sans être déclarées :
  les supprimer ?

## Régénérer

```
python generer.py
```
