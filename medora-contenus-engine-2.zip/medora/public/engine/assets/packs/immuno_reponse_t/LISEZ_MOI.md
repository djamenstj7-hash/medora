# La réponse immunitaire T — paquet Immunologie

112 notes, 178 cartes. Chapitre `chap-ue-immunologie-fc8` de l'UE Immunologie.
**Cours du Pr Collet, le 12/10/2026, de 12 h à 13 h (semaine 6), « Réponse
immunitaire T »** : un ronéo Ronéo & Juliette 2026-27 de 20 pages, déposé le
19/10/2026, la base du chapitre depuis ce jour. Le chapitre était carté depuis le
02/10/2026 (tâche C14) sur la FC n°8 du Ronéosaure 2025-26 (même professeure,
14/10/2025), qui n'est plus qu'un appoint. Annales : le polycopié IMMUNO n°9 du
Ronéosaure 2024-25 (17 questions, 12 sessions) et le sujet 2024/2025 déposé le
15/10/2026 (2 questions). Examen : partiel de novembre (mercredi 4/11/2026).

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 41 | 41 |
| QRU | 24 | 24 |
| Texte à trous | 14 | 71 |
| QROC | 9 | 9 |
| Recto-verso | 12 | 12 |
| Schéma cliquable | 2 | 11 |
| Lexique | 10 | 10 |

Dont **19 annales** : 12 QCM (QRM) et 7 QROC (recto-verso), sur 13 sessions, de
2015/2016 S1 à 2024/2025 S1 ; **32 marches de l'échelle** (22 Simple, 10 Moyen) ; et
21 QCM de cours. Chaque QCM a une justification par proposition. **65 QCM sur 65
illustrés**, 100 notes sur 112. **Toutes les cartes de cours (83) citent leur page du
ronéo 2026-27** et ont perdu le badge « Cours 2025-26 » ; **aucune n'est absente du
cours 2026-27** ; **7 cartes portent un piège du ronéo** (thème « Pièges des
ronéos ») ; aucune carte `a-relire`.

Six thèmes, dans l'ordre du cours. Les cinq premiers sont dans `THEME_LABELS`
(`app/src/med_engine/application/scopes.py`) ; **`cytotoxicite-lt` est nouveau** et
son libellé est à y ajouter, bloc « la réponse immunitaire T (FC n°8) » (sans lui,
`test_tout_theme_du_paquet_a_son_libelle` échoue pour ce chapitre) :

| Clé | Libellé |
|---|---|
| `lt-naifs` | Les LT naïfs et leur recirculation |
| `activation-lt` | Activation des LT : les trois signaux |
| `cytotoxicite-lt` | Cytotoxicité des lymphocytes T — **nouveau** |
| `polarisation-lt` | Polarisation des LT auxiliaires |
| `cooperations-lt` | Coopérations des LT auxiliaires |
| `lt-regulateurs` | Rétrocontrôles et LT régulateurs |

Pas de chiffre dans une clé ni dans un libellé (`scopes.is_theme`) : d'où
« Cytotoxicité des lymphocytes T » et non « des LT CD8 ». La seule carte `edn`
(FOXP3) prend le tag existant.

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-immuno-reponse-t-2627` (`FC1`) — « Réponse immunitaire T » (20 p.), `IMMUNOLOGIE/RÉPONSE IMMUNITAIRE T.pdf` | **2026-27** | **la base** : `SRC["fiche"]`, ce que le lecteur ouvre (`chapitre=`) ; chaque carte de cours porte sa page ; les figures (`SRC["medias"]`) |
| `src-fc-immuno-reponse-t` (`FC2526`) — Ronéosaure, « FC n°8 La réponse immunitaire T » (11 p.) | 2025-26 | **appoint** (`SRC["cours"]`, sans `chapitre=`) : cité « FC n°8 2025-26, p. 5 » quand une proposition dit ce que l'année a changé ; garde la page du terme « diapédèse », que le ronéo 2026-27 n'emploie plus |
| `src-annales-immuno-reponse-t` — Ronéosaure, « IMMUNO n°9 - Réponse adaptative T et mémoire » (9 p.) | 2024-25 | les 17 questions et leur table de corrections (p. 7-9) ; déclaration recopiée mot pour mot d'`immuno_thymus`, que reprend `immuno_memoire_t` |
| `src-sujets-immuno-2425` — sujet de système immunitaire 2024/2025, session 1 (3 p.) | 2024-25 | les Q2 et Q4 (`SRC["sessions"]["2024/2025 S1"]`) ; sujet sans corrigé, clés déduites du cours ; déclaré à l'identique dans chaque chapitre d'immunologie qui en a une question |
| `src-cours-immuno-reponse-t-2425` — Ronéosaure, FC n°6 (AC) « Activation et polarisation des LT », Pr Labalette (12 p.) | 2024-25 | appoint, cité dans le texte : le CD25 (p. 8), la bactéricidie des macrophages (p. 11), l'IL-6 du Th17 (p. 12) |
| FC n°9 2024-25, FC n°7, n°9 et n°11 2025-26 | 2024-25, 2025-26 | citées dans le texte, à la page, sans être déclarées : ce sont les fiches d'autres chapitres ; la FC n°11 2025-26 (Pr Lefèvre) sert de preuve pour le couple Fas – Fas ligand |
| tableau d'erreurs d'immunologie de la promo 2026-27 | 2026-27 | **rien sur ce cours** au 19/10/2026 (quatre entrées, sur trois autres cours) |

Les en-têtes des ronéos nomment leurs rédacteurs et leurs correcteurs : aucun nom
n'est repris. La fiche de l'année se copie dans le dossier des PDF de l'application
par `outils/copier_les_cours.py`, lancé avec le dossier des ronéos 2026-27
(`Ajouts/[NUMERIQUE] Ronéo & Juliette 26-27 19 10 2026/S1/CM`), hors du bac à sable.

## Ce qui correspond à quoi

| FC n°8 2025-26 | Ronéo 2026-27 |
|---|---|
| I. Introduction, génération des LT naïfs (p. 2) | I. Rappel de la thymopoïèse (p. 2-3), **plus détaillé** : sélections positive et négative, 98 % éliminés, répertoire réel 10⁸ à 10⁹ |
| II.A.1 État basal : caractères, ganglion, cortex profond (p. 2-3) | II.A (p. 3-5), **avec des chiffres neufs** : 10⁸ clones, ~1 000 LT par clone, ~5 000 LT par heure et par CD, 12 à 18 h dans un ganglion, CCL19, CCL21, CCR7 |
| II.A.2 Primo-infection, signaux 1, 2, 3 (p. 3-6) | II.B (p. 6-10), **avec la chronologie** : 4 à 7 jours, ×1 000 à ×10 000, une semaine |
| — | **III.A La cytotoxicité des LT CD8** (p. 10-11) : nouveau |
| II.B Différenciation fonctionnelle, Th1, Th2, Th17, plasticité (p. 6-9) | III.B (p. 11-15), **avec** le tableau des trois familles d'agresseurs (p. 11), la cascade en quatre temps (p. 12), le tableau récapitulatif (p. 14) |
| Coopération CD4-CD8, LT folliculaires helper (p. 9) | III.C (p. 15-16) |
| III.A CTLA-4, PD-1, LT régulateurs induits (p. 10) | IV.A-B (p. 17-18), **avec l'abatacept** (p. 17-18) et le microbiote (p. 18) |
| III.B LT régulateurs naturels, résumé (p. 11) | IV.C-D (p. 18-20), **avec** leur origine (thymocytes autoréactifs échappés), environ 3 % des LT CD4, le CTLA-4 constitutif, le prix Nobel 2025 |
| — | V. Récapitulatif général (p. 20) |

Deux pages du ronéo touchent un autre chapitre et n'y sont pas cartées : le rappel de
la thymopoïèse (p. 2-3), qui est le cours « TCR et lymphopoïèse T » (`immuno_thymus`),
et l'annonce de la réponse T mémoire (p. 6) et des LT CD8 mémoire (diapositive p. 15),
qui sont le cours de la mémoire (`immuno_memoire_t`). Les chiffres du thymus y servent
de rappel dans `rpt-qc-tolerance` et `rpt-qc-lt-naifs`.

## Le réalignement du 19/10/2026

Les 69 notes de la version 2025-26 et les 30 marches de l'échelle ont été relues une à
une contre le ronéo 2026-27. **Toutes sont confirmées** : chacune cite désormais sa
page de l'année, aucune ne va dans `ABSENTS_2026`. Une proposition que seul le cours
2025-26 portait le dit dans sa justification (« FC n°8 2025-26, p. 6 »).

**Ce que le ronéo 2026-27 dit autrement, et ce qui a été réécrit** :

- **Le répertoire** : 10⁸ clones, ~1 000 LT par clone (p. 3, 10), et non « plus de
  10 millions » et « 100 à 10 LT » : `rpt-fa-lt-naifs` (trou c2 : « 100 millions »),
  `rpt-qc-lt-naifs` C et D.
- **L'exemple** est la grippe, plus la rougeole : `rpt-qc-etapes` B (proposition
  réécrite), `rpt-qc-ganglion` D, `rpt-qc-signal-1` B.
- **Le signal 1 sélectionne, le signal 2 active** (résumé de la synapse, p. 9) ; le
  cours 2025-26 donnait la sélection au signal 2 : explication de `rpt-qc-signal-2`.
- **La cascade de messages** a quatre temps (p. 12), et la CD y joue deux rôles :
  `rpt-qc-differenciation` A, réécrite.
- **Les cytokines** : le texte cite maintenant l'IL-6 avec le TGF-β pour le Th17
  (p. 13) ; les polarisantes du Th1 et du Th2 sont « pas à retenir », les effectrices
  oui (« la réponse Th1, c'est l'IFN-γ », p. 12 ; « les trois grandes cytokines » du
  Th2, p. 13 ; l'IL-17 « à retenir si possible », p. 13) : `rpt-qc-cytokines-th`,
  `rpt-fa-th1`, `rpt-fa-th17`, `rpt-ech-s8`, `rpt-ech-s12`.
- **La plasticité** s'illustre par de l'IFN-γ en contexte Th2, et non plus par un Th1
  qui devient Th17 : `rpt-qc-plasticite` A et B (réécrites), `rpt-qr-epigenetique`.
- **L'antagonisme** vaut dans tous les sens : le Th2 réprime le Th1 et le Th17 (p. 14).
  La proposition D de 2020/2021 S1 Q4 a désormais sa marche (`rpt-ech-m9`), et la case
  « Interférences » du schéma de l'échelle dit « antagonisme : elles se répriment »,
  « plasticité au début, puis fixée ».
- **Les LT régulateurs naturels sont des LT CD4**, « environ 3 % des LT CD4 » (p. 19) :
  la proposition A de 2020/2021 S2 Q4 a désormais sa marche (`rpt-ech-m10`).
- **FOXP3** n'est plus en gris mais « pas à retenir à votre niveau » (p. 19) : la carte
  `rpt-qr-foxp3` garde son tag `edn`.
- **Les figures** : les 14 figures de la FC 2025-26 ont été remplacées par celles du
  ronéo 2026-27 (même nom de fichier quand c'est la même diapositive) ; s'y ajoutent dix
  diapositives et deux tableaux neufs. Le tableau des trois signaux et le bandeau Th1,
  Th2, Th17 de 2025-26, sans équivalent, sont retirés (remplacés par la synapse légendée
  et le tableau récapitulatif p. 14).

**Notes nouvelles (13)**, sur ce que le cours 2026-27 apporte :

| Note | Ce qu'elle carte |
|---|---|
| `rpt-fa-scan` | les adhérences non spécifiques, ~5 000 LT par heure et par CD, 12 à 18 h (p. 4-5) |
| `rpt-qc-expansion-clonale` | ×1 000 à ×10 000, ~1 000 LT par TCR, la limite de la prolifération, une semaine (p. 8-10, 17) |
| `rpt-qc-cytotoxicite`, `rpt-fa-cytotoxicite` | le CMH de classe I, la perforine, les granzymes, les caspases, les récepteurs mortifères (p. 10-11) |
| `rpt-fa-agresseurs` | les trois familles d'agresseurs, l'enkystement (p. 11) |
| `rpt-qr-aide-cd8` | l'IL-2 et l'IFN-γ des LT CD4 pour les LT CD8 (p. 15) |
| `rpt-qc-abatacept`, `rpt-qr-abatacept` | l'abatacept, CTLA-4 soluble, polyarthrite rhumatoïde (p. 17-18) |
| `rpt-fa-treg-induits` | TGF-β et IL-2, TGF-β et IL-10, le microbiote (p. 18) |
| `rpt-qc-treg-caracteristiques` | 3 % des LT CD4, CTLA-4 constitutif, l'échappement à la sélection négative (p. 18-19) |
| `rpt-ech-m9`, `rpt-ech-m10` | deux marches Moyen : l'antagonisme dans tous les sens, l'identité CD4 des Treg naturels |
| `lex-enkystement` | le terme du tableau des agresseurs (p. 11) |

## Ce que le cours a dicté

- **« À retenir : le mot « costimulation » et les noms CD28, CD80, CD86 »** (p. 7) ;
  **« À retenir : l'IL-2 »** (p. 8) ; **le CTLA-4, « nom à retenir »** (p. 17). Chacun a
  sa QROC (`rpt-qr-cd28`, `rpt-qr-chaine-alpha`, `rpt-qr-ctla4`), son trou
  (`rpt-fa-trois-signaux`, `rpt-fa-il2`, `rpt-fa-tolerance`), sa zone sur la synapse et un
  recto-verso qui les oppose (`rpt-rv-cd28-ctla4`).
- **« À retenir : les deux manières de faire de la cytotoxicité, et la perforine et les
  granzymes. Pas à retenir : les autres noms cités sur la diapo »** (p. 11) : les cartes
  de cytotoxicité demandent les deux mécanismes, jamais le côté de Fas et du Fas ligand.
- **Les cytokines** : les polarisantes du Th1 (IL-12, IFN-α, IFN-γ) et du Th2 (IL-4,
  TSLP) sont « pas à retenir » (p. 12-13), les effectrices sont à savoir (p. 12-14). Les
  annales du Pr Labalette demandent aussi les polarisantes : les cartes les gardent, et le
  disent. Le ronéo de la mémoire T (même semaine) demande « au moins une ou deux
  cytokines par polarisation ».
- **PD-1, « pas à retenir »** (p. 17) : une proposition (`rpt-qc-ctla4` D), pas de carte.
- **FOXP3, « pas à retenir à votre niveau »** (p. 19) : une seule carte,
  `rpt-qr-foxp3`, avec le tag `edn`.
- **Les questions guides** (p. 2) — vigilance des LT naïfs, signaux, étapes, adaptation
  à l'agresseur, emballement, auto-immunité — ont chacune leurs cartes, et le résumé
  final (p. 20) sa carte (`rpt-fa-tolerance`, `rpt-qc-tolerance`).
- **Le gris de ce ronéo** est un « complément ronéo 2025-2026 » des rédacteurs (p. 12) et
  le mot « stromales » (p. 4) : il se carte comme le reste (`rpt-qc-differenciation` B,
  `rpt-fa-recirculation`).

## Les erreurs du ronéo 2026-27

Chacune est portée par un **ATTENTION avec son genre** dans la carte qui joue la
notion ; elles entrent dans `contenu/ERRATA_RONEOS_2026-27.md` (section Immunologie,
« Réponse immunitaire T — Pr Collet, 12/10 »). Le tableau de la promo ne relève rien sur
ce cours.

| Page | Ce que dit le ronéo | Ce qui est juste | Genre | Carte |
|---|---|---|---|---|
| 4 | les HEV « à l'endroit où l'on passe de l'artériole à la veinule post-capillaire », un « petit renflement » | les HEV sont les veinules post-capillaires elles-mêmes, à endothélium haut (diapositive p. 5 ; Janeway) ; même phrase dans le Ronéosaure 2025-26 | prise de notes | `rpt-qc-ganglion` B |
| 5 | « de petites adhérences non spécifiques […], mais pas des adhérences non médiées par le TCR » | une négation de trop : les adhérences non spécifiques ne passent pas par le TCR (Ronéosaure 2025-26, p. 3) | prise de notes | `rpt-qc-ganglion` C |
| 8 | « à partir d'un LT naïf activé, on génère 100 à 1000 LT » | ×1 000 à ×10 000 : la diapositive p. 9 et le même ronéo p. 10, 17, 20 | prise de notes | `rpt-qc-expansion-clonale` A |
| 19 | (complément ronéo 2025-26) les thymocytes qui ne reconnaissent « pas du tout » les auto-antigènes « deviennent des LT conventionnels » | ils meurent par négligence (p. 2 du même ronéo et sa diapositive ; Klein et al., Nat Rev Immunol 2014) ; le LT conventionnel garde une faible affinité pour le soi | prise de notes | `rpt-qc-treg-naturels` B |
| 10-11 | la diapositive pose Fas sur le LT CD8 et le Fas ligand sur la cellule cible ; le texte la suit | le Fas ligand est sur le LT CD8, Fas sur la cible (Janeway ; diapositive de la FC n°11 2025-26, p. 9, Pr Lefèvre). À l'examen : les deux mécanismes, le côté des molécules n'étant « pas à retenir » | cours | `rpt-qc-cytotoxicite` E |
| 8-9 | le récepteur dimérique βγ de l'IL-2 « de faible affinité » (diapositive : « + » contre « +++ ») | le dimère βγ est d'affinité intermédiaire (Kd ≈ 10⁻⁹ M), la chaîne α seule de faible affinité. À l'examen : faible contre forte, comme le professeur | cours | `rpt-qc-il2` A |
| 19 | la diapositive des modes d'action des Treg naturels nomme « CD28 » la molécule de la CD que lie leur CTLA-4 | le CTLA-4 se lie aux CD80/86 de la CD ; le CD28 est sur le LT (diapositive p. 17 du même cours : « affinité +++ pour CD80-CD86 (>> CD28) » ; Qureshi et al., Science 2011). À l'examen : CTLA-4 – CD80/86 | cours | `rpt-qc-treg-naturels` E |
| 3 | les LT naïfs « font le tour de l'organisme en ~5 heures » | invérifié, et peu compatible avec les 12 à 18 h passées dans un ganglion (p. 5 ; Mandl et al., PNAS 2012 : 12 h à 21 h chez la souris) | douteux | `rpt-qc-lt-naifs` E |
| 7 | les CD80 et CD86 « ne sont exprimées que par les CD matures » | aussi par les LB et les macrophages activés (Janeway) ; la diapositive dit « exprimées par la CD mature » | douteux | `rpt-qc-signal-2` D |

Sans ATTENTION, parce qu'aucune réponse n'en dépend : « PCR » pour TCR (p. 2) ; « I-12 »
pour IL-12 dans le tableau récapitulatif (p. 14) ; l'intitulé de la partie III recopié de
la partie II (p. 10) et celui de IV.A recopié de III.C (p. 17) ; le cours de la mémoire
attribué au « Pr Dubois » (p. 6) — c'est le Pr Dubucquoi (ronéo « Contraction clonale et
réponse T mémoire », 14/10/2026) ; « 10¹¹ 10¹² lymphocytes » pour 10¹¹ à 10¹² (p. 3).

**Les erreurs du Ronéosaure 2025-26** que le ronéo 2026-27 n'a plus (« 100 à 10 LT » par
clone, « 2 % des LT totaux », « TLSP », « CTAL-4 », « gransine », « permutation
somatique ») sont dites dans les cartes, sans ATTENTION ; celle que le ronéo reprend en
« complément » (la sélection positive des thymocytes qui ne reconnaissent « pas du
tout ») a son ATTENTION de genre, ci-dessus.

## Ce que les annales ont dicté

| Savoir | Questions |
|---|---|
| La polarisation Th1, Th2, Th17 et ses cytokines (inductrices, produites, cibles, pathogènes) | 2024/2025 S1 Q4, 2022/2023 S1 Q2, 2020/2021 S1 Q4, 2019/2020 S2 Q10, 2016/2017 S1 question 7, 2016/2017 S2 Q9 ; QROC 2020/2021 S1, 2019/2020 S1, 2018/2019 S1, 2015/2016 S1 |
| Les LT régulateurs, naturels surtout : thymus, CD4, CD25, consommation d'IL-2, IL-10, tolérance périphérique | 2021/2022 S1 Q5, 2020/2021 S2 Q4, 2016/2017 S2 Q10 ; QROC 3 de 2023/2024 S1 et 2022/2023 S1 ; et 2024/2025 S1 Q4 D |
| L'activation du LT naïf : les trois signaux, CD28/CD80-86, CD40L, IL-2R de forte affinité, CTLA-4 | 2024/2025 S1 Q2, 2023/2024 S1 Q2 |
| Les devenirs du LT CD4 naïf activé | 2021/2022 S2 question 4, 2021/2022 S1 QROC 5 |

2021/2022 S2 question 4 est aussi imprimée dans IMMUNO n°7 (Pr Dubucquoi), avec la
même clé : elle n'est cartée qu'ici. Les six autres QCM d'IMMUNO n°9 sont dans le
chapitre de leur sujet (docstring d'`annales.py`). Aucune annale ne porte sur la
cytotoxicité des LT CD8 ni sur l'abatacept : le thème `cytotoxicite-lt` n'a pas
d'échelle.

Chaque annale porte maintenant `page`, la page du ronéo 2026-27 où se lit sa réponse :
elle cite la fiche de l'année en source secondaire.

## Les schémas cliquables

| Fichier | Ce qu'on clique | Cartes |
|---|---|---|
| `rpt-synapse-nue.svg` (`rpt-zo-synapse`) | le TCR sur le CMH II-peptide (signal 1), le CD4, le CD28 sur les CD80/86 (signal 2), le CD40 ligand sur le CD40, le CTLA-4 (le frein), le récepteur trimérique de l'IL-2, l'IL-2 sécrétée (signal 3) | 7 |
| `rpt-polarisation-nue.svg` (`rpt-zo-polarisation`) | la réponse Th1, la réponse Th2, la réponse Th17, le LT régulateur induit | 4 |

**La synapse** est redessinée d'après les diapositives du cours, les mêmes en 2025-26
(FC n°8, p. 4-5) et en 2026-27 (ronéo, p. 7 et 9) : un LT CD4 sur une cellule
dendritique mature, sans une légende. Les molécules se reconnaissent à la forme des
diapositives — le chevron noir du TCR, le collier de perles du CD4, les perles vert d'eau
du CD28 et orange des CD80/86, le pentagone du CD40 ligand ; les éclairs disent les
signaux, la barre d'arrêt le CTLA-4 (ajouté d'après la p. 17). À droite, l'IL-2 sort du
LT et revient sur son récepteur : la boucle autocrine de la p. 9. Le CD8 n'y est pas : le
choix du corécepteur selon la classe du CMH est le sujet du chapitre du CMH.

**Les polarisations** : au centre le LT CD4 naïf, et dans chaque quart un agresseur, le
LT polarisé et ses cibles — une cellule infectée, le LT CD8, le NK et le macrophage M1
(Th1) ; des vers, le LB et ses IgE, l'éosinophile, le macrophage M2 (Th2) ; des
bactéries et des levures, le neutrophile (Th17) ; des LT effecteurs freinés (LT
régulateur induit). Les couleurs des LT polarisés sont celles des figures du cours
(p. 12-13). Les versions légendées (`rpt-synapse.svg`, `rpt-polarisation.svg`), tirées
des mêmes constantes, sont en correction ; leur pied cite désormais le ronéo 2026-27, et
la légende du Th17 dit « induit par TGF-β, IL-6 ».

**Illustrations** : **65 QCM sur 65** portent une figure du ronéo 2026-27 ou un schéma
légendé en correction ; 100 notes sur 112. Dix-neuf diapositives extraites telles quelles
du PDF (réduites à 1 100 px de large, 256 couleurs) et cinq tableaux du ronéo rendus à
×2,2 (les caractères des LT naïfs p. 3, les agresseurs p. 11, le récapitulatif Th1, Th2,
Th17 et les interférences p. 14, les modes d'action des Treg naturels p. 19). La légende de
la diapositive de la cytotoxicité (p. 10) dit que Fas et le Fas ligand y sont inversés ;
celle de la diapositive des Treg naturels (p. 19), que le « CD28 » posé sur la CD en face
du CTLA-4 est en réalité les CD80/86.

## Les clés qui ne sont pas reprises telles quelles

Aucune clé de QCM imprimée n'est contestée, et le ronéo 2026-27 n'en contredit aucune :
les dix du polycopié gardent leur clé, et `CONFLITS` est vide.

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2019/2020 S1 QROC 4 (tableau Th1, Th2, Th17) | « pas de correction : voir cours » | cytokines et pathogènes du tableau récapitulatif (ronéo 2026-27, p. 14) | clé déduite du cours, non marquée officielle |
| 2024/2025 S1 Q2 (`rpt-an-2425s1-q2`) | aucune (sujet sans corrigé) | **BCE**, déduite, non officielle | activation dans le cortex profond, pas la médulla (p. 4-5) ; IL-2R trimérique et CD40L acquis (p. 8) ; CD28 déjà présent sur le LT (p. 7) ; CTLA-4 exprimé après l'activation (p. 17) |
| 2024/2025 S1 Q4 (`rpt-an-2425s1-q4`) | aucune (sujet sans corrigé) | **ABC**, déduite, non officielle | IFN-γ, IL-4, IL-17 (p. 12-14) ; le Treg naturel consomme l'IL-2 (p. 19) ; l'IL-12 est une cytokine polarisante du Th1 (p. 12), pas un produit du LT folliculaire helper |

Reprises, avec une remarque dans la carte : **2016/2017 S1 question 7, B** (« l'IFN- » : la
lettre γ perdue, la proposition gardée telle qu'imprimée) ; **2015/2016 S1 QROC**
(« IFN- », « TGF- » dans le corrigé : lettres rétablies dans le verso) ; **2020/2021 S1
QROC 2** (corrigé imprimé « QROC2 : 4. », un « 4. » sans objet ; l'énoncé, un tableau, est
recopié ligne à ligne, comme ceux de 2019/2020 S1 QROC 4 et 2015/2016 S1 QROC) ;
**2016/2017 S2** (« (Session 2)$ », un signe parasite) ; **2021/2022 S2** (« 4. » dans
l'énoncé, « Q4 » dans la table).

Cas ouvert : aucun sur les clés.

## Le lexique

Dix termes, aux pages mesurées dans le ronéo 2026-27 (`scripts/chercher_pages.py`,
19/10/2026) : cytokine (p. 8-20), interleukine (8-20, par ses abréviations, le mot n'est
jamais écrit), costimulation (7, 8, 10, 17, 18), anergie (8), synapse immunologique (6-10,
20), polarisation (1, 10-16, 18, 20), épigénétique (14, 20), quiescence (3, 5, 8),
enkystement (11) ; diapédèse garde la page 3 de la FC n°8 2025-26, le ronéo 2026-27 disant
« s'extravaser » (p. 4). Chacun dit son origine grecque ou latine.

**Enkystement** est nouveau : son étymologie (latin *in* + grec κύστις, avec les racines
`in- (latin, dans)` et `cyst-` de la table, réemployées telles quelles) est **proposée**
dans `scratchpad/etym/immuno_reponse_t.json`, avec ses sources (Wiktionnaire « enkyster »,
« kyste », « en- » ; Bailly ; Gaffiot) ; la table n'est pas modifiée par ce chapitre. La
définition dit déjà, mot pour mot, ce qu'`appliquer_etymologies.py` en écrira. Les neuf
autres termes ont leur étymologie dans la table depuis le 02/10.

## Questions pour Vincent

1. **Fas et Fas ligand.** La diapositive du Pr Collet (p. 10) pose Fas sur le LT CD8 et le
   Fas ligand sur la cible, et le texte la suit ; la diapositive du Pr Lefèvre (FC n°11
   2025-26, p. 9) et les manuels disent l'inverse. Le cours dit de ne pas retenir « les
   autres noms cités sur la diapo » : la carte ne demande que les deux mécanismes, et
   l'ATTENTION (cours) dit la référence. Faut-il, à l'examen, répondre comme la
   diapositive si une question tombe sur le côté ?
2. **Les cytokines polarisantes.** Le cours 2026-27 les dit « pas à retenir » pour le Th1
   et le Th2 ; les annales du Pr Labalette les demandent (IL-12, IL-4, IL-6, TGF-β).
   Appliqué : les cartes les gardent et le disent. Les marquer plutôt `edn` ?
3. **« Font le tour de l'organisme en ~5 heures »** (p. 3) : dit douteux, à ne pas
   apprendre. Une source du cours le confirme-t-elle (diapositive Récap sur Moodle) ?
4. **FOXP3**, « pas à retenir à votre niveau » (p. 19), garde sa carte `edn`
   (`rpt-qr-foxp3`) : la garder ?
5. **Deux pages pour d'autres chapitres** : le rappel de la thymopoïèse (p. 2-3 :
   98 % éliminés, répertoire réel 10⁸ à 10⁹, restriction syngénique) est le cours
   `immuno_thymus` ; l'annonce de la mémoire (p. 6) et la génération des LT CD8 mémoire
   par la coopération CD4-CD8 (diapositive p. 15) sont le cours `immuno_memoire_t`. Non
   cartés ici.

## À relire

Aucune carte `a-relire` : chaque carte de cours porte sa page dans le ronéo 2026-27,
chaque annale sa clé vérifiée sur le cours et sa page de l'année. Les neuf erreurs du
ronéo sont dans les cartes, avec leur genre.

**Relu par un sceptique le 19/10/2026** : chaque carte nouvelle ou réécrite contre sa
page et sa figure, chaque clé d'annale contre la table du polycopié. Deux corrections :
l'énoncé de 2020/2021 S2 Q4 avait perdu son « (ou sont) » imprimé, rétabli mot pour mot ;
et la diapositive p. 19 (« CD28 » sur la CD en face du CTLA-4) a désormais son
ATTENTION (cours), dans `rpt-qc-treg-naturels` E. Le point douteux des « ~5 heures » ne
cite plus de fréquence de recirculation que sa source ne donne pas.

## L'échelle : Simple → Moyen → Annale (C20, 16/10/2026 ; relue le 19/10/2026)

Le pilote de l'immunité innée, étendu au reste de l'immunologie pour l'examen du 4/11
(choix de Vincent, 15/10). Sous les annales, 22 cartes Simple (`niveau-simple`, une idée,
trois choix, le schéma troué dans la question) et 10 cartes Moyen (`niveau-moyen`, une
paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la
figure du cours et reçoit son schéma (`diagramme=`) ; les QROC reçoivent le schéma nu.

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `activation-lt` | 7 | 2 | 2 |
| `polarisation-lt` | 10 | 4 | 10 |
| `cooperations-lt` | 1 | 1 | 2 |
| `lt-regulateurs` | 4 | 3 | 5 |

**Le schéma** `ech-reponse-t`, « La réponse T · activer, polariser, freiner », donne
45 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py`
(`ECH_REPONSE_T`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du
modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux
marqueurs.

**Le réalignement du 19/10/2026** : chaque marche et chaque case du schéma ont été
relues sur le ronéo 2026-27 ; aucune clé ne change, chaque justification cite sa page de
l'année. Deux lignes de la case « Interférences » changent (« antagonisme : elles se
répriment », « plasticité au début, puis fixée ») : le ronéo 2026-27 généralise
l'antagonisme et ne donne plus l'exemple d'un Th1 devenu Th17. La légende du schéma cite
le ronéo 2026-27 (p. 4-20). Deux marches Moyen s'ajoutent, sur ce que le ronéo 2026-27
dit et que la FC 2025-26 taisait : `rpt-ech-m9` (le Th2 réprime le Th17, pour 2020/2021
S1 Q4 D) et `rpt-ech-m10` (les Treg naturels sont des LT CD4, pour 2020/2021 S2 Q4 A et
2016/2017 S2 Q10 A). Clés Simple toujours réparties : A 7, B 8, C 7 ; Moyen d'une à trois
vraies (les deux nouvelles en ont deux).

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales
et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les
figures du cours, et un critique de complétude a relu les dix chapitres ensemble : clés
réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Un désaccord entre cours, dit dans la carte** : `rpt-ech-m3` A porte un ATTENTION sur la
source de l'IFN-γ (cytokine polarisante du Th1 pour le ronéo 2026-27, p. 12 ; CD et NK
pour la FC n°8 2025-26, p. 7 ; « uniquement » NK et LT pour la FC n°11 2025-26, p. 13) ;
la proposition ne tranche pas.

**Sans marche** :
- `rpt-an-2122s2-q4` A : les LT mémoire centraux, sujet du chapitre de la mémoire ; la
  case « Autres devenirs » les nomme, sans marche.
- `rpt-an-1617s2-q10` A, en partie : le CD3 n'a pas de marche (le CD25 a `rpt-ech-m8` A,
  le CD4 `rpt-ech-m10` A).

## Régénérer

```powershell
cd contenu\chapitres\immuno_reponse_t
..\..\..\app\.venv\Scripts\python.exe generer.py
```

Les figures se réextraient du PDF de l'année avec PyMuPDF : dix-neuf images par leur
xref (17, 26, 29, 32, 33, 34, 38, 41, 42, 45, 48, 52, 55, 56, 61, 66, 69, 70, 73), réduites à
1 100 px de large et 256 couleurs, et cinq découpes rendues à ×2,2 (p. 3, 11, 14 deux
fois, 19), aux noms déclarés dans `IMAGES`.
