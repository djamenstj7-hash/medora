# Cellules souches et progéniteurs hématopoïétiques — paquet d'exemple

49 notes, 76 cartes. Premier chapitre de l'UE **Tissu sanguin**, Pr N. Duployez,
cours du 18/09/2026 (semaine 2, 8 h-9 h). Trois sources :

- **le ronéo 2026-27** (Ronéo & Juliette, 9 pages, `src-fc-sang-souches`), qui
  fait foi ;
- le ronéo 2024-25 (Ronéosaure, FC n°1, 13 pages, `src-cours-sang-souches`),
  sur lequel le chapitre avait été bâti ;
- le polycopié d'annales (9 sessions, 16 questions dont 7 QROC), dépouillé en
  entier.

## Relu sur le cours de l'année (25/09/2026)

Chaque note a été relue contre le ronéo 2026-27, texte et figures. Même
enseignant, même plan ; le cours est plus court (9 pages contre 13) et quelques
chiffres ont bougé. Une note vérifiée porte la page de ce ronéo (`page` dans
`donnees.py`) : sa source devient `src-fc-sang-souches` à cette page, et pour une
annale, cette page devient la source secondaire. Une note sans page garde le
ronéo 2024-25 pour source : ce sont celles de la section « Absent du cours
2026-27 ». Aucune note n'a été retirée, aucun identifiant n'a changé, aucune
clé n'a bougé.

Ce qui a changé dans le cours, et ce que les cartes en font :

| Point | 2024-25 | 2026-27 | Cartes |
|---|---|---|---|
| Localisation fœtale (p. 4) | îlots de Wolff-Pander à J21, puis le foie | îlots sans date, puis le foie **et la rate** du 40ᵉ jour au 6ᵉ mois, la moelle devenant progressivement le lieu principal à partir du 6ᵉ mois | `sso-qc-localisation`, `sso-an-2122s2-q3`, `sso-an-2021s1-q5` réécrites |
| Enfant, adulte (p. 4) | tous les os jusqu'à 4 ans | tous les os chez l'enfant, sans âge ; exclusivement médullaire chez l'adulte | idem, et `sso-an-1920s1-q6` |
| Ponction (p. 4) | sternum chez l'adulte, crête iliaque chez l'enfant | « sternum ou crêtes iliaques en général » | `sso-an-2223-q10` réécrite ; `sso-rv-myelogramme` gardée (voir plus bas) |
| Phénotype des CSH (p. 5) | CD34+, CD38−, HLA-DR− | CD34 seul | `sso-qc-proprietes`, `sso-qr-phenotype`, zone « csh » |
| CSH (p. 5) | — | moelle et sang de cordon, 0,01 %, mobilisables (cellules souches périphériques) | nouvelle carte `sso-qc-csh` |
| Quiescence (p. 5) | 90 % des cellules | 90 % du temps | `sso-qc-proprietes` (item B reformulé), `sso-an-2122s2-q3` |
| « Important pour l'examen » | sur les propriétés des CSH | disparu ; le corps du cours liste cinq propriétés, la conclusion quatre | explications de `sso-qc-proprietes`, `sso-fa-proprietes`, `sso-an-2122s2-q3` |
| Progéniteurs (p. 6-7) | CFU-GM : monocytes 7 j, PNN 14 j | 30-50 % en cycle ; progéniteurs E, MK, B, Eo et CFU-GM (figure) ; effet d'un traitement jugé vers 7 j | `sso-qc-progeniteurs` ; nouvelle carte `sso-qc-progeniteurs-myeloides` ; `sso-qr-cfugm` gardée |
| Facteurs de croissance (p. 8) | « seulement retenir EPO et G-CSF » ; restreints = EPO, G-CSF ; IL-6 cytokine pro-inflammatoire | consigne disparue ; trois types redéfinis ; EPO, G-CSF **et IL-6** donnés restreints | `sso-qc-regulation`, `sso-rv-facteurs` réécrites ; IL-6 et ordre des types en ATTENTION, non cartés |
| Niche (p. 9) | hypoxique, métabolisme réduit | trois rôles : protection, sécrétion de facteurs de croissance, interactions adhésives | `sso-rv-niche` réécrite ; item E de `sso-qc-regulation` gardé |
| Ajouts | — | MGG « seule coloration » (p. 4), 9 Gy chez Till et McCulloch (figure p. 4), myélémie (p. 8) | explications de `sso-fa-mgg`, `sso-qc-till`, `sso-an-qr-compartiments` |

La note C de `sso-qc-localisation` citait la mauvaise session : l'item « site
unique après la naissance » est coté faux en **2021/2022 S1** (QCM 3 B, le
conflit déclaré) ; en 2021/2022 S2, c'est l'item inverse qui est coté faux. Elle
le dit maintenant.

## Les ATTENTION de ce chapitre

Le ronéo 2026-27 ne sera pas corrigé (« les cours ne seront pas modifiés »). Le
tableau d'erreurs de la promo (version du 28/09/2026) relève une erreur dans ce
cours, la division asymétrique (p. 5, ligne ci-dessous), et sa version du
19/10/2026 une seconde, l'hémoglobine « du granulocyte » (p. 8), déjà portée par
`sso-qc-regulation` et `sso-ech-s17` ; les autres ont été trouvées à la relecture. La division asymétrique s'est révélée être la formule
de la diapositive du professeur : c'est le cours lui-même, pas une prise de
notes fausse. À l'examen, on répond d'abord comme le professeur (règle de
Vincent, 28/09) ; l'`ATTENTION` dit donc « c'est le cours lui-même », d'où
vient la formule, ce qu'on répond à l'examen, puis la référence. Les erreurs
et les contradictions sont portées par les cartes, là où elles se jouent, et
les erreurs du ronéo aussi par `contenu/ERRATA_RONEOS_2026-27.md` :

| Carte | Ce qui se contredit | Retenu |
|---|---|---|
| `sso-an-2122s1-q3`, item B | clé imprimée « faux » contre le cours (conflit déclaré dans `CONFLITS`) | le cours : vrai ; re-cité sur les p. 4 et 9 du ronéo 2026-27, la phrase de 2024-25 n'existant plus |
| `sso-qc-regulation`, item A ; `sso-ech-s17`, item C | l'exemple du ronéo (p. 8) : un facteur de transcription « qui se met sur le granulocyte pour produire de l'hémoglobine » — **relevé par le tableau d'erreurs de la promo** (19/10) | la définition ; l'exemple, faux deux fois (l'hémoglobine est érythrocytaire, p. 7 ; le facteur se fixe sur l'ADN), n'est pas carté : le détail des facteurs de transcription est hors programme (exclusion du 18/09) |
| `sso-rv-facteurs` (explication) | l'IL-6 : facteur restreint en 2026-27 (p. 8) ; en 2024-25, les restreints agissent « exclusivement sur un type cellulaire » (EPO, G-CSF) et l'IL-6 est une cytokine pro-inflammatoire qui agit aussi sur la lignée mégacaryocytaire ; le schéma classique la range parmi les facteurs de promotion | l'EPO et le G-CSF, restreints dans les deux années ; aucune carte ne demande de classer l'IL-6 (la note D de `sso-qc-regulation` ne la cite plus) |
| `sso-rv-facteurs` (explication) | les types de facteurs de croissance : en 2026-27 multipotents (CSH → progéniteur), promotion (progéniteur → précurseur), restreints (précurseur → mature) ; en 2024-25 promotion d'abord, puis multipotents, puis restreints — l'ordre classique | les restreints en dernier, où les deux années s'accordent ; aucune carte ne demande l'ordre des deux autres |
| `sso-qc-proprietes`, item A ; `sso-an-2122s1-q3`, item A | **c'est le cours lui-même** : la division asymétrique donnerait « une autre CSH et un précurseur » (p. 5), légende de la diapositive du Pr Duployez reproduite sur la page, déjà dans la FC n°1 2024-25 (p. 6) ; le même cours fait pourtant du progéniteur la première étape de différenciation (p. 6) et des facteurs multipotents le passage CSH → progéniteur (p. 8) — **relevée par le tableau d'erreurs de la promo** (28/09) | à l'examen, un item qui reprend la formule de la diapositive est vrai ; dans les quatre compartiments, la cellule qui suit la CSH est le progéniteur ; la référence : une CSH et un progéniteur (Giebel et al., *Blood* 2006) ; les items, vrais, ne bougent pas |
| `sso-fa-mgg` (explication) | le MGG « seule coloration utilisée en hématologie » (p. 4), puis le bleu de Crésyl pour les réticulocytes (p. 7) | le MGG, coloration de référence, pas la seule |
| `sso-fa-durees` (explication) | « une atteinte de toute l'hématopoïèse se voit d'abord sur les globules rouges » (p. 3) : pour un arrêt brutal de la production (aplasie, chimiothérapie), les durées de vie font attendre l'inverse ; dans une atteinte lente (myélodysplasie), l'anémie est souvent la première cytopénie découverte | point à discuter, pas une erreur avérée ; l'ordre d'apparition n'est pas carté |

## Absent du cours 2026-27

Ces cartes sont **gardées telles quelles** — question, réponse et clés — parce
que rien dans le ronéo 2026-27 ne les contredit ; leur explication dit
maintenant d'où vient leur contenu. À Vincent de décider s'il les garde.

| Carte | Ce qui est absent | Source restée |
|---|---|---|
| `sso-qr-cfugm` | les délais : monocyte en 7 jours, neutrophile en 14. Le 2026-27 garde le CFU-GM (figure p. 6) et le jugement à 7 jours, les monocytes « quelques jours avant » les neutrophiles | ronéo 2024-25 |
| `sso-rv-myelogramme` | la répartition sternum chez l'adulte, crête iliaque chez l'enfant | ronéo 2024-25 |
| `sso-qc-regulation`, item E | la niche hypoxique, qui rend faux « un milieu richement oxygéné » | la carte pointe sur le 2026-27 pour ses quatre autres items |
| `sso-qc-potence`, `sso-fa-potence`, `sso-rv-potence` | la hiérarchie des potences au-delà de « multipotente / totipotente » (p. 4-5) — déjà hors du cours en 2024-25, posée pour les annales (voir plus bas) ; tag `a-relire` | ronéo 2024-25 |

Détails absents gardés dans des cartes par ailleurs vérifiées : la liste des
tissus des cellules souches mésenchymateuses (`sso-rv-mesenchymateuses`, le
2026-27 dit « les autres tissus retrouvés dans la moelle osseuse ») et la
définition de l'endomitose (`sso-rv-endomitose`, le 2026-27 nomme les
endomitoses sans les définir). L'annale `sso-an-2324-q5` porte sur les
globules rouges : ses items A et B sont dans ce cours (hématies dépourvues de
noyau p. 2, 120 jours p. 3, sa source secondaire), les items B à E dans celui
des cellules matures du même jour (p. 2 et 5).

## À relire : 3 cartes

Trois notes portent le tag `a-relire` (`A_RELIRE` en fin de `donnees.py`) :
`sso-qc-potence`, `sso-fa-potence`, `sso-rv-potence`. Le cours n'oppose que la
CSH multipotente à la cellule totipotente ; le reste de leur contenu (zygote,
blastocyste, pluri- et unipotence, spermatogonie) n'est dans aucun des deux
ronéos, et seule une clé d'annales (« les précurseurs sont pluripotents » :
faux) le recoupe. Le tag se retire à la relecture, jamais avant. Les autres
cartes gardées absentes (`sso-qr-cfugm`, `sso-rv-myelogramme`, item E de
`sso-qc-regulation`) ont été vérifiées page à page sur le ronéo 2024-25 et ne le
portent pas.

## Deux schémas cliquables

Les figures du ronéo sont légendées : elles donneraient la réponse. Elles sont
donc redessinées nues dans `schemas.py`, et le dessin comme les zones corrigées
sortent des mêmes constantes.

- **Le tube de sang centrifugé** — trois couches à cliquer : 45 % d'hématies au
  fond, moins de 1 % de leucocytes et de plaquettes, 55 % de plasma (figure de
  la p. 2). La couche leucocytaire est dessinée plus épaisse qu'elle ne l'est :
  à l'échelle elle ferait deux pixels, et une zone de deux pixels ne se clique
  pas.
- **L'arbre de l'hématopoïèse** — sept boîtes : la cellule souche, les deux
  progéniteurs, les deux étages de précurseurs, les deux familles de cellules
  matures. Le choix de lignage se voit là où l'arbre se sépare.

Aucun QCM du chapitre ne porte encore d'illustration (0 sur 21) : les seules
figures sont celles du ronéo, qui ne se distribuent pas. Le hook le rappelle ;
un schéma redessiné et légendé pourrait en illustrer plusieurs.

## Ce que les annales répètent

Seize questions sur neuf sessions, et elles tournent autour de six faits :

| Ce qui tombe | Combien de fois |
|---|---|
| Les 4 propriétés de la CSH | 2 QROC |
| Les 5 leucocytes | 2 QROC |
| Les durées de vie, permutées | 3 QCM |
| Lignée lymphoïde contre myéloïde | 3 QCM |
| Les 4 compartiments | 1 QROC + 2 QCM |
| La localisation, fœtale et adulte | 3 QCM |

La conclusion du cours 2026-27 reprend d'ailleurs les quatre propriétés des CSH
une à une.

## La hiérarchie des potences

Le cours oppose multipotence et totipotence, et s'arrête là. Les annales, elles,
se servent des quatre niveaux — « les précurseurs sont des cellules
pluripotentes » est proposé et donné faux — et la table de corrections écrit
tantôt « multipotence », tantôt « pluripotence », pour la **même** QROC.

Trois cartes posent donc l'échelle complète, parce que c'est elle qui rend la
distinction lisible :

| | Ce qu'elle donne | Exemple |
|---|---|---|
| Totipotente | tout l'organisme + annexes | zygote, jusqu'à 4-8 cellules |
| Pluripotente | les 3 feuillets, pas le placenta | masse interne du blastocyste |
| **Multipotente** | **un seul tissu** | **la CSH** |
| Unipotente | un seul type de cellule | spermatogonie, cellule souche de la peau |

## Clés du polycopié non reprises telles quelles

La clé retenue est la bonne, pas la clé imprimée (règle de Vincent, 26/09) :
la question porte alors `cle_officielle` à faux, et la justification de l'item
dit que la correction imprimée n'est pas bonne, et pourquoi.

| Question | Clé imprimée | Retenu | Pourquoi | Source |
|---|---|---|---|---|
| 2021/2022 S1, QCM 3 B (`sso-an-2122s1-q3`) — « la moelle osseuse est le site unique de l'hématopoïèse après la naissance » | AE (B faux) | **ABE** (B vrai) | le ronéo 2026-27 dit l'hématopoïèse de l'adulte « exclusivement médullaire » (p. 4) et « exclusivement dans la moelle osseuse » (p. 9) ; le ronéo 2024-25 écrivait « après la naissance, l'hématopoïèse aura lieu uniquement dans la moelle osseuse » (p. 4), dont l'item est la reprise ; 2020/2021 QCM 5 C donne vrai à un item presque identique ; l'errata des annales rapporte la même correction | ronéos 2026-27 et 2024-25 ; Hématocell (université d'Angers), « Hématopoïèse, cellules souches hématopoïétiques, facteurs de croissance » : la moelle, « site exclusif de l'hématopoïèse à la naissance et pour toute la vie » |
| 2017/2018 S2, QROC 1 (`sso-an-qr-regulation`) — les types de facteurs de régulation | quatre, dont les micro-ARN | **trois**, la réponse à quatre acceptée | la table écrit elle-même que les micro-ARN « ne sont plus dans le cours » ; le cours 2026-27 en décrit trois (p. 8-9) | ronéo 2026-27 p. 8-9 |

L'objection qu'on pourrait faire à la première — que le mot « unique » ignore
l'hématopoïèse extra-médullaire pathologique, où le foie et la rate reprennent,
d'autant que l'item omet le « physiologique » des deux items voisins (2020/2021
QCM 5 C, 2021/2022 S2 QCM 3 B) — vaudrait aussi contre le cours lui-même et
contre la référence citée, qui ne le disent pas non plus. La carte donne les
deux lectures.

Sur la même question, l'item A (division asymétrique, vrai) garde sa clé
imprimée, qui est bonne. Le ronéo écrit que la division donne « une autre CSH
et un précurseur » (2026-27 p. 5) : c'est la légende de la diapositive du
Pr Duployez, déjà dans la FC n°1 2024-25 (p. 6), donc le **cours lui-même**,
pas une prise de notes fausse. À l'examen, un item qui reprend cette formule se
tient pour vrai. La référence : la division donne une CSH et un
**progéniteur**, cellule engagée que le même cours place en première étape de
différenciation (p. 6). Sources : Giebel et al., *Blood* 2006 ; Takano et al.,
*J Exp Med* 2004. Le tableau d'erreurs de la promo la relève (version du
28/09/2026). La justification de l'item le dit par « ATTENTION — c'est le
cours lui-même ».

## Deux exclusions de programme

Posées par Vincent, et elles valent pour toute l'UE. Le cours 2026-27 a déplacé
le terrain sous chacune ; elles sont gardées, et la question lui est posée.

- **Les stades de l'hématopoïèse ne sont pas à connaître.** Le ronéo 2024-25 le
  disait page 10 ; celui de 2026-27 dit « ne pas forcément apprendre les
  différents stades de l'érythropoïèse mais retenir les réticulocytes » (p. 7).
  Aucune carte ne demande donc de nommer ou d'ordonner un stade intermédiaire —
  proérythroblaste, promyélocyte, métamyélocyte. Restent au programme les quatre
  compartiments, les propriétés du compartiment des précurseurs, les
  particularités de lignée, qu'une question de 2019/2020 S2 interroge en les
  intervertissant, les durées globales, et les réticulocytes
  (`sso-rv-reticulocytes`).
- **Le détail des facteurs de transcription non plus.** Ce qui reste attendu
  tient en une ligne : ils sont l'un des trois types de régulation, et ils
  agissent sur l'ADN cible pour commander la différenciation. Le ronéo 2026-27
  garde les mécanismes coopératifs et compétitifs (p. 8) ; ils ne sont pas
  cartés. La consigne de 2024-25 de ne retenir que l'EPO et le G-CSF a disparu :
  les cartes citent l'EPO et le G-CSF, facteurs thérapeutiques et restreints ;
  l'IL-6, que le ronéo 2026-27 range parmi les restreints, n'est citée que dans
  l'ATTENTION de `sso-rv-facteurs`.

## Les sujets du dépôt du 15/10/2026

Trois annales de plus : le chapitre en compte 17, sur 10 sessions.

- **2024/2025, session 1** (`src-sujets-sang-2425`, que la session cite par
  `SRC["sessions"]`) : le QCM 1, la régulation de l'hématopoïèse
  (`sso-an-2425-q1`), et le QCM 2, les cellules du sang (`sso-an-2425-q2`,
  illustré par la figure des cinq leucocytes, p. 3). Le sujet n'a pas de
  corrigé : clés déduites du cours, `officielle=False`.
- **2023/2024, QROC 2** (`sso-an-qr-leucocytes-2324`) : les cinq leucocytes,
  et le lymphocyte, né d'un autre progéniteur, selon le corrigé officiel.
  Reprise mot pour mot de 2017/2018 S2, QROC 2 (`sso-an-qr-leucocytes`) : deux
  sessions, deux cartes. Le polycopié ne portait de 2023/2024 que le QCM 5 ; la
  carte garde la source de session en place (le polycopié) et dit d'où elle
  vient.

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2024/2025, QCM 1 (`sso-an-2425-q1`) | aucune (sujet sans corrigé) ; surlignée : ADE | **ADE** | facteurs de transcription sur l'ADN, facteurs de croissance sur un récepteur (p. 8-9) ; l'hypoxie et l'EPO, ronéo des cellules matures p. 3 |
| 2024/2025, QCM 2 (`sso-an-2425-q2`) | aucune ; surlignée : ACD | **ACD** | p. 3 et 7 ; le monocyte et les normes plaquettaires, ronéo des cellules matures p. 9-10 |

Coquilles du sujet, gardées telles quelles : « est (ou sont) exactes » sans
« (s) » à l'énoncé du QCM 1, et l'accord « Les facteurs de croissance nommé …
favorise » de son item E ; « relatives aux relatives aux » à l'énoncé du QCM 2.
Les exclusions de Vincent ne sont pas touchées : le QCM 1 ne demande que le mode
d'action des facteurs de transcription, aucun nom.

**La correction surlignée (officieuse).** Les sujets du dépôt portent des
réponses surlignées en bleu, posées en annotation sur le PDF après coup et
d'origine inconnue : ce n'est ni une grille ni un corrigé de la faculté, et elle
n'est pas déclarée comme source. Sur 2023/2024, elle reproduit la
grille officielle, sauf au QCM 9, où elle ajoute D. Sur 2024/2025, elle sert de
seconde opinion : quand la clé déduite du cours coïncide, l'explication le dit ;
quand elle diffère et que le cours tranche, la carte suit le cours, et l'item
en cause porte un `ATTENTION —` et une entrée `CONFLITS`. Les surlignages des
QROC 2024/2025 ne marquent que l'énoncé et n'apportent rien.

**2023/2024.** Clés confirmées par la grille officielle (dépôt du 15/10/2026) :
le QCM 5 (`sso-an-2324-q5`, ABC). À la Q9 de ce sujet, seul le surligneur ajoute D, la
grille dit AE.

## L'échelle : Simple → Moyen → Annale (C20, 16/10/2026)

L'échelle du pilote de l'immunité innée, étendue au tissu sanguin et aux trois derniers chapitres de sémiologie pour l'examen du 4/11 (Vincent, 16/10 : « on continue pour les chapitres que je vais avoir à l'examen »). Sous les annales, 23 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 7 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`) ; les QROC reçoivent le schéma nu.

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `hematopoiese` | 4 | 1 | 2 |
| `compartiments` | 4 | 1 | 3 |
| `csh` | 3 | 1 | 2 |
| `lignees` | 1 | 1 | 3 |
| `cellules` | 4 | 1 | 4 |
| `maturation` | 3 | 1 | 1 |
| `regulation` | 4 | 1 | 2 |

**Le schéma** `ech-hematopoiese`, « L'hématopoïèse · de la cellule souche au sang », donne 42 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_HEMATOPOIESE`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**La source.** Les marches citent la ronéo 2026-27 (`SRC["fiche"]`) ; le Ronéosaure 2024-25 sert d'appoint, nommé par `fiche=` quand un fait n'est que là, et la FC 2025-26 de contre-épreuve.

**Le générateur.** Depuis le 16/10, `generer.py` est la copie exacte du modèle du skill : le bloc « le générateur modèle » en fin de `donnees.py` déclare les sources dans `SRC` et range les QROC d'annales dans `ANNALES_QROC`, officielles comme avant. Le paquet est resté le même, à trois écarts voulus près (indentation, champs par défaut des cartes à zones, légende du média du schéma cliquable), plus le tag d'année `cours-2026-27` ou `cours-2024-25` sur les cartes de cours).

**ATTENTION posés** : la division asymétrique, « une autre CSH et un précurseur », est le cours lui-même (s2, liste des errata) ; le facteur de transcription « qui se met sur le granulocyte », une prise de notes (s17, liste des errata) ; trois types de régulation en 2026-27 contre quatre dans une clé de 2017/2018 (s19) ; la clé de 2021/2022 S1 QCM 3 B (s22, m1) ; 5 jours ici contre 6 à 7 jours dans le cours des anémies pour fabriquer un globule rouge (s9).

**Sans marche** :
- sso-an-2324-q5 C, D, E (membrane déformable, vitamines B9/B12 et anémies macrocytaires, fer de l'hémoglobine) : enseignés par la ronéo 2026-27 « Les cellules matures du sang » (sang_matures), absents des deux ronéos de ce chapitre
- sso-an-2021s2-q8 C (B9 et B12 pour la synthèse d'ADN) : même raison, ronéo des cellules matures
- sso-an-2425-q1 D (hypoxie et EPO) : ronéo des cellules matures (p. 3) ; ce cours dit seulement que l'EPO stimule la production des globules rouges (p. 8). La marche hem-ech-s9 prépare l'hypoxie qui appelle l'EPO
- sso-an-2425-q2 D, E (phagocytose du monocyte, normes plaquettaires constantes) : ronéo des cellules matures (p. 9-10)

## Régénérer

```
python generer.py
```

Le script écrit d'abord les deux SVG, puis valide : une justification manquante,
un trou de plus de deux mots, deux zones qui se recouvrent, une zone hors du
schéma, un thème qui ne porte qu'une carte, une page hors du ronéo 2026-27 — et
il refuse d'écrire.
