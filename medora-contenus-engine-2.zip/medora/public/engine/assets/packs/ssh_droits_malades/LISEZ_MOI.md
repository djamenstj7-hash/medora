# Droits des personnes malades et consentement aux soins — paquet SSH

81 notes, 146 cartes. Chapitre `chap-ue-ssh-droits-malades` de l'UE SSH,
`ordre=14`. Cours du **Pr J. Saison, le 05/12/2025** (8 h 30-10 h 30),
« Droits des personnes malades et consentement aux soins » : FC n°14 du
Ronéosaure 2025-26, 14 pages. **Une annale** : la QROC 9 du sujet de SSH
2024/2025, déposé le 15/10/2026. Examen de SSH du 6 janvier 2027, écrit
(10 QROC + 1 QR).

**18/10/2026** : 1 recto-verso du sujet de SSH 2025/2026 (examen du
09/01/2026, sans corrigé) — QROC 10 ; voir « Le sujet 2025/2026 ».

**Une fiche provisoire.** Le ronéo 2026-27 de ce cours n'est pas paru : le
chapitre est carté sur le Ronéosaure 2025-26 (tâche C14, décision de Vincent du
02/10/2026), et le ronéo de l'année corrigera les cartes à sa parution. La
source porte son année dans son auteur (« Ronéosaure 2025-26 ») : chaque carte
de cours prend le tag `cours-2025-26` et le badge « Cours 2025-26 ». Aucune
carte ne dit « Absent du cours 2026-27 », et les erreurs du Ronéosaure sont
dites par un ATTENTION sans genre (précédent d'`immuno_innee`) : la liste des
erreurs de la promo, `contenu/ERRATA_RONEOS_2026-27.md`, ne concerne que les
ronéos 2026-27.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 18 | 18 |
| Texte à trous | 16 | 72 |
| QROC | 23 | 23 |
| Recto-verso | 12 | 12 |
| Schéma cliquable | 2 | 11 |
| Lexique | 10 | 10 |

L'examen est rédactionnel : le chapitre est d'abord fait de QROC (un texte, une
date, un mot de la loi), de textes à trous qui se récitent (les textes en rouge
du cours) et de recto-verso pour les couples qu'on inverse (2005 et 2016, le
principe et l'exception) ; les 18 QCM portent les pièges, avec une
justification par proposition.

Huit thèmes, dans l'ordre du cours :

| Clé | Libellé |
|---|---|
| `normes-droits-patients` | Les sources des droits des patients |
| `droit-dignite` | Le droit à la dignité et au soulagement de la souffrance |
| `obstination-deraisonnable` | Obstination déraisonnable et arrêt des traitements |
| `palliatifs-sedation` | Soins palliatifs et sédation profonde et continue |
| `information-patient` | L'information du patient (partagé avec « La responsabilité médicale », même libellé) |
| `acces-dossier-medical` | Le dossier médical et son accès |
| `consentement-soins` | Le consentement aux soins |
| `consentement-situations` | Consentement : mineur, majeur protégé, urgence, directives anticipées |

Les huit libellés sont à ajouter à `THEME_LABELS`
(`app/src/med_engine/application/scopes.py`, bloc « ssh ») ; `information-patient`
n'y entre qu'une fois, pour les deux chapitres. Trois clés s'écartent du plan
C16 : `dignite` et `soins-palliatifs` y étaient des mots génériques qu'une autre
UE voudra (d'où `droit-dignite` et `palliatifs-sedation`), et `dossier-medical`
est déjà pris par l'informatique médicale (`info_financement`), avec un autre
libellé (d'où `acces-dossier-medical`).

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-ssh-droits` — Ronéosaure, « FC n°14 Droits des personnes malades et consentement aux soins » (14 p.), `SSH/…` | **2025-26** | **la base** : chaque note du cours porte sa page ; c'est ce que le lecteur ouvre (`chapitre=`) |
| Erratas du Ronéosaure : cours 2025-26 (`Erratas SSH.docx`) et annales 2024-25 | — | aucune entrée sur la FC n°14 ; l'errata des annales est vide |
| Polycopiés d'annales SSH 1 à 13 du Ronéosaure 2024-25 | 2024-25 | relus : aucune question ne porte sur ce cours |
| `src-sujets-ssh-2425` — « Sujets de SSH 2024/2025, session 1 » (examen du 10/01/2025, 1 QR et 10 QROC, sans corrigé), déposés le 15/10/2026 | 2024-25 | la source de la session 2024/2025 S1 et `SRC["annales"]` : la QROC 9 ; déclarée à l'identique dans tous les chapitres de SSH qui en cartent une question |
| `src-ed-ssh-laicite-2526` — Ronéosaure, « ED n°1 SSH », la laïcité, Pr Devinant (4 p.), `ED/SSH/…` | 2025-26 | appoint, cité dans le texte de l'annale : la neutralité de la seule fonction publique, la charte et ses limites, l'aumônier (p. 2-4) ; en attendant l'ED « Éthique et droit » de 2026-27, sans ronéo au 15/10 |
| `src-ed-ssh-consentement-2526` — Ronéosaure, « ED SSH N°2 », consentement et décision médicale partagée, Pr Devinant (4 p.), `ED/SSH/…` | 2025-26 | appoint, cité dans le texte de l'annale : le parent qui met l'enfant en danger, accepter et comprendre le refus (p. 2, 4) ; déclaré à l'identique dans `ssh_litterature` |

Vérifications hors du cours, citées dans la carte qui s'en sert : Légifrance
(articles L1110-5-1, L1111-4, L1111-6 et L1111-11 du code de la santé
publique, ce dernier dans ses versions de 2020 et de 2026 ; la loi n° 2026-404
du 26 mai 2026 lue au Journal officiel, dont le nouvel article L1110-10) ; la
loi n° 2026-794 du 18 août 2026 (son titre et sa date, sur Légifrance) ; les
autres articles cités (L1110-5-2, L1110-5-3, L1111-2, L1111-5, L1111-7, R4127-42,
R4127-43, L3212-1) d'après leur rédaction connue ; l'article R1112-35 (la saisine
du ministère public pour un mineur), relu sur les fiches juridiques de l'AP-HP et
de la MACSF, sans relecture sur Légifrance pour ce
chapitre ; l'arrêt de la CJUE du 26 octobre 2023 et le
décret n° 2023-1426 (gratuité de la copie du dossier) ; Louis Portes (1950) ;
l'étymologie (Wiktionnaire, Gaffiot, Bailly).

## Ce que le cours a dicté

- **Dix-sept passages rouges**, tous des textes de loi ou des « à retenir » :
  chacun a sa carte. La loi du 4 mars 2002 (« s'il y a un texte qu'il faut
  connaître c'est celui-ci ») : `droit-qr-loi-2002`, `droit-fa-lois`,
  `droit-qc-loi-2002` ; les lois Leonetti et Claeys-Leonetti :
  `droit-fa-lois`, `droit-rv-leonetti-claeys`, la frise ; le code civil :
  `droit-fa-code-civil` ; la souffrance « prévenue, prise en compte, évaluée et
  traitée » : `droit-fa-souffrance` ; l'article L1110-5 :
  `droit-fa-obstination` ; « arrêter le curatif n'est pas arrêter la prise en
  charge » : `droit-qc-obstination` C ; le droit de refuser un traitement :
  `droit-qc-arret` A, `droit-qr-article-refus` ; la sédation profonde et
  continue, « à retenir », et sa finalité : `droit-fa-sedation`,
  `droit-qc-sedation`.
- **Ce que le cours dit de ne pas retenir** : le jugement de Bordeaux (p. 5,
  « juste pour illustrer ») n'a pas de carte.
- **Le gris** de ce ronéo est la voix des rédacteurs, et il ne se définit pas
  comme hors programme : le plan des parties IV à VIII (p. 1), « la prof
  insiste » (p. 3), l'exemple des anesthésistes-réanimateurs (p. 3, une
  anecdote, sans carte), l'encadré sur les formulaires de consentement signés
  (p. 9), qui relève de la FC n°6.
- **Les frontières du plan C16** (§3) sont tenues. L'information comme
  obligation du médecin — loyale, claire, appropriée, son contenu, ses
  modalités, la charge de la preuve, ses destinataires — est à « La
  responsabilité médicale » (FC n°6) ; ce chapitre n'en carte que ce que la FC
  n°6 n'a pas : les fondements (article 35, L1111-2, la dignité selon la Cour
  de cassation), le caractère « continue », les frais, les trois limites.
  L'exception au refus d'être informé (la maladie transmissible) a sa carte
  dans « La responsabilité médicale » (`resp-qr-refus-information`) : ici, elle
  n'est ni un trou ni une proposition, seulement une phrase de contexte.
  L'euthanasie et le double effet sont à « Éthique : donner la mort » ; le don
  d'organes vécu par des parents, à « Littérature et médecine ».

## Les erreurs du Ronéosaure 2025-26

Chacune est dite par **ATTENTION**, sans genre, dans la carte qui porte la
notion. Aucune ne vient de l'errata 2025-26, qui n'a pas d'entrée sur la FC
n°14 : toutes ont été relevées à la lecture, et vérifiées sur Légifrance.

| Page | Ce que dit le Ronéosaure | Ce qui est juste | Carte |
|---|---|---|---|
| 6 | « Code de santé publique : Art L811-4 » (en rouge), le droit de refuser un traitement | l'article **L1111-4**, que le même cours cite juste p. 11-12 | `droit-qc-arret` A, `droit-qr-article-refus` |
| 14 | « les directives anticipées créées par la loi du 22 avril 2005 s'imposent au médecin » | en 2005, valables 3 ans et le médecin « en tient compte » ; elles s'imposent depuis la loi du 2 février 2016 (L1111-11), comme le dit le cours un paragraphe plus bas | `droit-qc-directives` B, `droit-rv-directives` |
| 14 | une personne sous protection juridique rédige ses directives « avec autorisation du juge **et** du conseil de famille » | « du juge **ou** du conseil de famille s'il a été constitué » (L1111-11, version de 2020) ; depuis la loi du 26 mai 2026, l'article renvoie à l'article 458 du code civil | `droit-rv-directives` |
| 4 | « la dignité selon le conseil national d'éthique » | le Comité consultatif national d'éthique (CCNE) | `droit-qc-dignite` |
| 5 | l'article L1110-5 (en rouge) pour l'obstination déraisonnable | la phrase citée est, depuis la loi du 2 février 2016, à l'article L1110-5-1 ; L1110-5 était juste en 2005. À l'examen, le cours dit L1110-5 | `droit-fa-obstination`, `droit-qc-obstination` B |

Sans ATTENTION, parce qu'aucune réponse n'en dépend : « L 1111:5 » pour
L1111-5 (p. 14, dit dans `droit-qc-mineur`) ; la définition légale des soins
palliatifs, qui omet « et à soutenir son entourage » (p. 6, dit dans
`droit-fa-definition-palliatifs`) ; l'exception des « informations recueillies
auprès de tiers », que le cours range dans la composition du dossier alors
qu'elle limite sa communication (p. 10, dit dans `droit-qc-dossier`) ; « le juge
autorise ou non l'acte » en cas de conflit (p. 13), quand la loi dit qu'il
autorise l'un ou l'autre à décider (dit dans `droit-qc-majeur-protege` D et la
zone « juge »).

## Depuis le cours : deux lois

Le cours (décembre 2025) présente deux textes en débat. Ce sont devenus des
lois : **la loi n° 2026-404 du 26 mai 2026** « visant à garantir l'égal accès
de tous à l'accompagnement et aux soins palliatifs » — elle réécrit l'article
L1110-10 (« l'accompagnement et les soins palliatifs », délivrés « de façon
précoce, active et continue »), inscrit le plan personnalisé d'accompagnement
à l'article L1110-10-1, crée les maisons d'accompagnement et de soins
palliatifs (établissements médico-sociaux), précise la procédure collégiale
(L1110-5-1) et fait renvoyer le dernier alinéa de L1111-11 à l'article 458 du
code civil — et **la loi n° 2026-794 du 18 août 2026** relative au droit à
l'aide à mourir. Les cartes gardent le cours, et le disent par un ATTENTION :
`droit-qc-fin-de-vie-textes`, `droit-rv-textes-fin-de-vie`,
`droit-qc-palliatifs` A, `droit-fa-definition-palliatifs`,
`droit-qr-plan-accompagnement`, `droit-qr-maisons-accompagnement`,
`droit-rv-directives` ; et sans ATTENTION, la procédure collégiale précisée
(`droit-qr-procedure-collegiale`). Le contenu des deux lois (conditions de
l'aide à mourir, plan personnalisé, maisons) n'est pas carté au-delà : le
ronéo 2026-27 dira ce que le cours en retient (question pour Vincent).

## Ce que les annales ont dicté

Aucun des onze polycopiés SSH du Ronéosaure 2024-25 (SSH 1 à 8, 10, 13) ne porte
ce cours, ce que le plan C16 avait vérifié et que la relecture confirme. Les
trois annales du délai de prescription sont à « La responsabilité médicale ».

Le sujet de SSH 2024/2025 (session 1, déposé le 15/10/2026, sans corrigé) en
apporte une, dans `annales.py` : la **QROC 9**, un cas — Monsieur P. refuse,
pour lui et pour son fils de 6 ans, un antibiotique intraveineux au nom d'un
interdit religieux ; la conduite à tenir, au regard de la laïcité et du
consentement. Le consentement, le refus et le mineur sont dans la FC n°14
(p. 11-14) ; la laïcité n'est dans aucun cours magistral, mais dans l'ED n°1
de 2025-26, que le verso cite. Les cartes du cours y préparent :
`droit-qr-article-refus`, le tableau du mineur, la décision partagée.

## Les schémas cliquables

| Fichier | Ce qu'on clique | Cartes |
|---|---|---|
| `frise-droits-nue.svg` (`droit-zo-frise`) | sept cases vides au-dessus de sept années (1936, 2002, 2005, 2007, 2016, 2020, 2021) : l'arrêt Mercier, la loi Kouchner, la loi Leonetti, la loi de 2007 sur la protection des majeurs, la loi Claeys-Leonetti, l'ordonnance de 2020, la loi de bioéthique | 7 |
| `majeur-protege-nu.svg` (`droit-zo-majeur-protege`) | les quatre issues de l'arbre du majeur protégé : il consent seul, son consentement assisté, l'autorisation de la personne chargée de la protection, le juge | 4 |

Les années de la frise et les deux questions de l'arbre sont imprimées : ce
qu'on sait ou non, c'est l'année d'un texte, et qui décide dans quel cas. Les
versions légendées (`frise-droits.svg`, `majeur-protege.svg`), tirées des mêmes
constantes, sont en correction.

**Illustrations** : la FC n°14 n'a aucune figure. 17 QCM sur 18 (94 %) portent
en correction un dessin redessiné d'après le texte (`schemas.py` : les sources
de la dignité, la décision d'arrêt des traitements, les soins palliatifs, la
sédation profonde et continue, le droit à l'information, l'accès au dossier,
les directives anticipées, la frise, l'arbre du majeur protégé) ou le tableau du
consentement du mineur, découpé de la p. 13 (`mineur-tableau.png`) ; 57 notes
sur 80. Le QCM sans figure, `droit-qc-don-organes`, n'a rien à montrer que le
texte à trous ne dise.

## Le sujet 2025/2026 (18/10/2026)

Les sujets de SSH de l'examen du 09/01/2026 (1 QR, 10 QROC,
`src-sujets-ssh-2526`, sans corrigé), déposés le 18/10/2026, apportent 1
recto-verso à ce chapitre (QROC 10). Aucun n'était déjà en cartes. Au verso,
la bonne réponse, tirée du ronéo 2026-27 quand il couvre la notion, sinon du
cours 2025-26, celui de l'année de l'examen ; ce qui dépasse le cours est dit
« hors cours », avec sa source (`officielle=False`). Rédigés et
contre-vérifiés le 18/10/2026 : un rédacteur, un sceptique, un critique de
complétude.

| Question | Ce que le verso répond | Voisine de |
|---|---|---|
| 2025/2026 S1 QROC 10 (`droit-an-2526s1-qroc10`) | l'exercice du culte n'est pas du prosélytisme ; neutralité de l'équipe, liberté de M. D., trois limites ; expliquer au voisin, ne pas interdire | `droit-an-2425s1-qroc9` |

Ce qui est signalé :

- La QROC 10, le fait religieux à l'hôpital public : la laïcité n'est dans aucun
  cours magistral, elle vient de l'ED n°1 de 2025-26 (p. 2-4) ; la circulaire
  du 2 février 2005 et la charte de la personne hospitalisée (2006), qui
  interdit « tout prosélytisme », sont hors cours. Rangée sous
  `normes-droits-patients` : aucun soin n'y est refusé, à la différence de
  2024/2025 S1 QROC 9 (sous `consentement-soins`).
- Aucune figure du chapitre ne sert la réponse : un schéma de la laïcité à
  l'hôpital est noté dans `IDEES.md`.

## Les clés qui ne sont pas reprises telles quelles

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2024/2025 S1 QROC 9 (refus religieux d'un père, pour lui et pour son fils) | aucune (sujet sans corrigé) | **clé déduite** : respecter le refus éclairé et réitéré du père ; pour l'enfant, les soins indispensables, le procureur si le dialogue échoue ; la neutralité de l'hôpital, la liberté religieuse du patient et ses limites | FC n°14 2025-26, p. 11-14 ; ED n°1 et n°2 de 2025-26 ; L1111-4, R.4127-43, R1112-35 du CSP |

Les cartes du cours suivent la FC n°14, et les cinq erreurs ci-dessus sont dites
là où elles se jouent.

Cas ouvert : aucun.

## Le lexique

Dix termes, aux pages mesurées dans la FC n°14 (page de plan exclue) :
paternalisme (p. 2, 11), démocratie sanitaire (3), dignité (3-6, 8, 11),
obstination déraisonnable (5, 6), soins palliatifs (5-8, 11), sédation (7, 8),
procédure collégiale (6, 8), directives anticipées (6, 14), personne de
confiance (6, 9, 12, 14), consentement présumé (12). Aucun n'était pris dans
l'UE ni ailleurs. La définition de la personne de confiance ajoute ce que le
cours ne dit pas (L1111-6 : désignée par écrit, son témoignage prévaut) et le
dit.

Les étymologies nouvelles — quatorze racines (`pater (latin)`,
`kratos (grec)`, `sanitas (latin)`, `dignitas (latin)`, `obstinare (latin)`,
`ratio (latin)`, `pallium (latin)`, `sedare (latin)`, `procedere (latin)`,
`collegium (latin)`, `dirigere (latin)`, `persona (latin)`, `fidere (latin)`,
`praesumere (latin)`) et les dix termes — sont **proposées** pour
`scripts/etymologies.json`, avec leurs sources ; la table n'est pas modifiée
par ce chapitre. Les définitions et les racines disent déjà, mot pour mot, ce
qu'`appliquer_etymologies.py` en écrira (vérifié en simulant la fusion). Les
racines réemployées gardent la clé de la table : `cum (latin)`,
`sentire (latin)`, `soin (français)`, `dêmos (grec)`, `dé- (latin)`,
`anticipare (latin)`.

## Questions pour Vincent

1. **Les deux lois de 2026.** La loi n° 2026-404 du 26 mai 2026 (soins
   palliatifs et accompagnement) et la loi n° 2026-794 du 18 août 2026 (aide à
   mourir) sont postérieures au cours. Proposition appliquée : les cartes
   gardent le cours de décembre 2025 et signalent la loi nouvelle par un
   ATTENTION ; le contenu des lois n'est pas carté avant le ronéo 2026-27. Faut-il
   carter dès maintenant les conditions de l'aide à mourir et le plan
   personnalisé d'accompagnement de l'article L1110-10-1 ?
2. **Trois clés de thème** diffèrent du plan (`droit-dignite`,
   `palliatifs-sedation`, `acces-dossier-medical`, voir plus haut) : à garder
   telles quelles dans `THEME_LABELS` ?
3. **`EXAMENS`** : comme les autres chapitres SSH, celui-ci n'en déclare pas ;
   le plan propose un seul `exam-ssh-jan-2027` (6 janvier 2027) pour toute l'UE,
   à décider une fois.

## À relire

Aucune carte `a-relire` : chaque carte de cours porte sa page dans la fiche
2025-26, relue contre le texte et, pour les principaux articles de loi, contre
Légifrance ; l'annale dit d'où vient chaque élément de sa réponse.

Relecture contradictoire (05/10/2026), carte par carte contre la FC n°14 :
- deux textes à trous se trahissaient eux-mêmes. Dans `droit-fa-lois`, le trou
  « Leonetti » était lu dans « Claeys-Leonetti », resté visible : il ne reste
  plus que le trou « Claeys ». Dans `droit-fa-sedation`, le « court terme » de
  l'hypothèse 1 se lisait dans l'hypothèse 2, qui dit désormais « dans le même
  délai » ;
- le trou « transmissible » de `droit-fa-limites-information` et la
  proposition C de `droit-qc-limites-information` doublaient la carte de « La
  responsabilité médicale ». La proposition C porte désormais sur l'étendue de
  l'impossibilité psychologique (p. 10) ;
- la figure de l'accès au dossier numérotait « 3. 48 heures, 4. 8 jours » ; elle
  suit maintenant l'ordre du cours (p. 10) : 3, le délai de réponse ; 4, le
  délai de réflexion.

Les faits tirés hors du cours ont été revérifiés : les deux lois de 2026 (le
Journal officiel et Légifrance), le décret n° 2023-1426 (R1111-2), la CJUE du
26 octobre 2023, L1111-4 (le juge en cas de désaccord), Louis Portes (30 janvier
1950), et le vote unanime de l'Assemblée du 27 mai 2025.

À la parution du ronéo 2026-27 de ce cours, relire toutes les cartes contre
lui : pages, numéros d'articles (L1110-5 ou L1110-5-1), ce que le cours garde
des lois de 2026 (définition des soins palliatifs, plan personnalisé,
maisons d'accompagnement, aide à mourir), et les cinq erreurs ci-dessus.

## L'échelle : Simple → Moyen → Annale (C20, 19/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 5 janvier (BMCP) ou du 6 janvier (SSH, papier). Sous les annales, 17 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 2 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`) ; les QROC reçoivent le schéma nu.

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `normes-droits-patients` | 7 | 1 | 1 |
| `consentement-soins` | 10 | 1 | 1 |

**Le schéma** `ech-laicite-consentement`, « À l'hôpital public · religion et consentement », donne 20 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_LAICITE_CONSENTEMENT`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Constantes ajoutées** à `annales.py` (`_SCHEMA_LETTRES`, `_SCHEMA_NU`) : les annales de SSH sont toutes des QROC, rangées dans `ANNALES_QROC` ; chacune reçoit le schéma nu, et les marches la préparent sans lettre.

**Sans marche** :
- droit-an-2526s1-qroc10 : la circulaire du 2 février 2005 et la charte de la personne hospitalisée de 2006, hors cours — dites dans l'explication de l'annale, sans marche
- droit-an-2425s1-qroc9 : la saisine du procureur, le médecin « défenseur de l'enfant » (R.4127-43) et l'article L1111-4 sur le refus du représentant légal, hors cours — sans marche ; l'ED n°2 dit seulement que le médecin « peut passer outre » (s17)

## Régénérer

```powershell
cd contenu\chapitres\ssh_droits_malades
..\..\..\app\.venv\Scripts\python.exe generer.py
```

`generer.py` est la copie exacte de
`.claude/skills/nouveau-chapitre/scripts/generer_modele.py`. Le tableau
`mineur-tableau.png` se redécoupe de la p. 13 de la FC (rectangle 46, 388, 522,
582 en points, 150 dpi).
