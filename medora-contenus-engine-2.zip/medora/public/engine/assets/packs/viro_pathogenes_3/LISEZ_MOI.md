# Pathogènes viraux III : système nerveux, prions, hépatites, VIH, EBV — paquet Virologie

131 notes, 194 cartes. Chapitre `chap-ue-virologie-fc7` de l'UE Virologie
(ordre 8). Cours du **Pr Hober, le 25/11/2025**, « Pathogènes viraux III »
(FC n°8 du Ronéosaure 2025-26, deux heures, 20 pages dont la dernière vide) ;
annales du polycopié VIRO n°7 du Ronéosaure 2024-25 (56 questions, 18
sessions) et deux du sujet de l'examen du 09/01/2025 (2024/2025 Q5 et Q13, sans
corrigé). Examen de virologie le **5 janvier 2027**.

**18/10/2026** : 4 questions du sujet de virologie 2025/2026 (examen du
08/01/2026, sans corrigé) — Q.14, Q.15, Q.16, Q.17 ; voir « Le sujet 2025/2026
».

**Une fiche provisoire.** Aucun ronéo 2026-27 de virologie n'est paru (le cours
commence le 06/10/2026) : le chapitre est carté sur le Ronéosaure 2025-26
(décision de Vincent du 02/10, C16), et le ronéo de l'année corrigera les cartes
à sa parution. La source porte son année dans son auteur : chaque carte de cours
montre « Cours 2025-26 ». Aucune carte ne dit « Absent du cours 2026-27 », et
les erreurs du Ronéosaure sont dites par un ATTENTION nu, sans genre : la liste
`contenu/ERRATA_RONEOS_2026-27.md` ne concerne que les ronéos 2026-27.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 90 | 90 |
| Texte à trous | 12 | 67 |
| QROC | 9 | 9 |
| Recto-verso | 8 | 8 |
| Schéma cliquable | 1 | 9 |
| Planche à légender | 1 | 1 |
| Lexique | 10 | 10 |

Dont **62 annales** (QRM, verbatim, une justification par proposition), sur 20
sessions, de 2015/2016 S1 à 2025/2026. Les 28 QCM du cours ont, eux aussi,
une justification par proposition.

Huit thèmes, dans l'ordre du cours (libellés du plan C16, tous à ajouter à
`THEME_LABELS`) :

| Clé | Libellé | Partagée avec |
|---|---|---|
| `snc` | Infections virales du système nerveux central | `viro_multiplication` |
| `prions` | Agents transmissibles non conventionnels (prions) | — |
| `mere-enfant` | Transmission mère-enfant et infections congénitales | `viro_multiplication`, `viro_vaccins_vivants` |
| `greffes-immunodeprimes` | Infections virales des greffés | — |
| `hepatites` | Virus des hépatites | `viro_vaccins` |
| `vhb-marqueurs` | Marqueurs sérologiques de l'hépatite B | — |
| `vih` | Le VIH | `viro_antiviraux` |
| `ebv` | Le virus d'Epstein-Barr | — |

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-viro-fc8` — Ronéosaure, « FC n°8 Pathogènes viraux 3 .pdf » (20 p.), `VIROLOGIE/…` | **2025-26** | **la base** : chaque note du cours porte sa page (l'index du PDF, couverture = p. 1) ; c'est ce que le lecteur ouvre (`chapitre=`) |
| `src-annales-virologie-7-pathogenes-viraux-iii` — Ronéosaure, « VIROLOGIE 7 - Pathogènes viraux III » (32 p.) | 2024-25 | les 56 questions et la table de corrections (p. 32) ; la figure 1 (p. 30-31) |
| `src-sujet-viro-2425` — « Sujet de virologie 2024/2025, session 1 » (examen du 09/01/2025, 16 p., 30 QCM) | 2024-25 | la session 2024/2025 (Q5, Q13 ; `SRC["sessions"]`) ; sujet sans corrigé ; déclaration identique dans tous les chapitres de virologie qui en prennent une question |
| Ronéosaure 2024-25, FC n°6 et n°7 (Pathogènes viraux II et III) | 2024-25 | relecture des p. 9-19 rédigées sans audio ; cités dans le texte, non déclarés |
| FC n°1 partie 2, n°2, n°3, n°4, n°9, n°10 partie 2 du Ronéosaure 2025-26 | 2025-26 | citées dans le texte, à la page (les fiches des autres chapitres de virologie) |
| erratas du Ronéosaure : cours 2025-26 (`Erratas Virologie.docx`) et annales 2024-25 | — | deux entrées sur la FC n°8 (p. 13, p. 16), reprises ; aucune sur VIRO n°7 |
| `TABLEAU DES ERREURS VIROLOGIE` 2026-27 (Ajouts) | 2026-27 | vide |

**La déclaration du polycopié VIRO n°7 est partagée** : `viro_multiplication`
et `viro_marqueurs` en prennent aussi des questions, et doivent la déclarer à
l'identique (mêmes champs, rien d'autre). Elle suit la règle des déclarations
parallèles de C16 (identifiant tiré du nom du fichier), et non l'identifiant
`src-annales-viro-7` du plan.

Vérifications hors du cours, citées dans la carte qui s'en sert : OMS
(aide-mémoire hépatite B : moins de 5 % de chronicité chez l'adulte), ICTV
(Kolmioviridae, genre Deltavirus), structure de l'enveloppe du VIH (trimère
d'hétérodimères gp120/gp41 non covalents), CDC 2023 (transmission
mère-enfant du VHC, environ 6 %), HAS (dépistage du VHC par les anticorps),
Inserm (dossier hépatite C : forme fulminante « dans moins de 1 % des cas »,
transmission sexuelle rare) ; l'étymologie (Wiktionnaire, CNRTL, Bailly,
Gaffiot).

## Ce que le cours a dicté

- **La seconde heure (p. 9-19) a été rédigée sans audio**, d'après une prise de
  notes et le Ronéosaure (gris, p. 9). Chaque chiffre de ces pages a été relu
  contre le cours 2024-25 (FC n°7) et contre les diapositives reproduites dans
  la fiche : ils concordent, aux erreurs près du tableau suivant. Aucune carte
  n'est restée `a-relire`.
- **Le gris** n'est que la voix des rédacteurs (un rappel sur le système
  nerveux, p. 2 ; l'avertissement de la p. 9) : rien à carter de plus. Pas de
  rouge dans cette FC.
- **Les annales du système nerveux et de la transmission mère-enfant** sont
  dans `viro_multiplication` (plan C16, §4) : ce chapitre carte le cours de ces
  pages (p. 2-3, 5-6) — trois QCM, deux textes à trous, une QROC et un recto-verso
  sur le système nerveux ; deux QCM et un texte à trous sur la transmission
  mère-enfant —, pas leurs annales.
- **Les chiffres non cartés**, parce que datés ou douteux : 300 000 porteurs du
  VHB et 600 000 du VHC en France (p. 12) ; 20 % de chronicité du VHC chez le
  nouveau-né (p. 12) ; 5 % par an de cancer sur cirrhose (p. 12) ; les 23 décès
  de l'ESB (p. 4).

## Les erreurs du Ronéosaure 2025-26

Chacune est dite par **ATTENTION**, sans genre, dans la carte qui porte la
notion.

| Page | Ce que dit le Ronéosaure | Ce qui est juste | Source de la correction | Cartes |
|---|---|---|---|---|
| 13 | « Ac anti-VHC : seule manière de détecter une forme chronique » | l'ARN du VHC présent au-delà de 6 mois ; les anticorps sont là dans la guérison comme dans la chronicité | errata de la promo ; diapositive p. 13 ; cours 2024-25 p. 7 | `pv3-qc-vhc-diagnostic` B, `pv3-rv-vhc-profils`, annales 2023/2024 S1 Q13 C, 2021/2022 S1 Q18 D, 2021/2022 S2 Q18 D, `pv3-an-2526-q15` D |
| 16 | rétrotranscription « en ADN simple brin » | d'une seule des deux molécules d'ARN (p. 15) | errata de la promo | `pv3-qc-vih-cycle` C |
| 11 | le VHD « appartient à la famille des hepadnaviridae » | genre Deltavirus, famille Kolmioviridae ; satellite du VHB (lui, Hepadnaviridae) | trouvée en relisant ; ICTV | `pv3-qc-vhd` C |
| 13 | la ribavirine « agit vis-à-vis de l'ADN polymérase » | analogue de nucléoside : ARN polymérase du VHC, IMPDH | trouvée en relisant ; FC n°9 2025-26 p. 7 | `pv3-qc-vhc-traitement` B |
| 9 | ARN « subgénomique » — le mot du professeur à l'oral (cours 2024-25 aussi ; la FC n°10 partie 2, p. 8 : « c'est faux ») | ARN prégénomique, celui de sa diapositive et de son annale | trouvée en relisant ; diapositive p. 8 ; annale 2017/2018 S1 Q28 B ; FC n°10 partie 2 p. 8 | `pv3-qc-vhb-cycle` B, annale 2017/2018 S1 Q28 B |
| 2 | « ARN messager lact (lact = lactence) » | les ARN LAT (latency-associated transcripts) | trouvée en relisant ; diapositive p. 2 | `pv3-qc-hsv-latence` B |
| 14 | gp120 et gp41 « liées de manière covalente » | liaison non covalente (la gp120 se détache à la fusion, p. 15) — c'est le cours lui-même (2024-25 aussi) | trouvée en relisant ; structure de l'Env du VIH | `pv3-qc-vih-structure` A ; note de la zone gp41 |
| 7 | VHB chronique chez l'adulte « 10 à 20 % » | les FC n°2 et n°3 disent 5 à 10 % ; l'OMS, moins de 5 % ; les annales cotent vrai les deux | plan C16 §16.8 | `pv3-qc-chronicite` A, annales 2023/2024 S2 Q13 B, 2015/2016 S2 Q29 E |
| FC n°1 b, 10 | le VIH « à symétrie hélicoïdale » | capside en cône tronqué ; les annales cotent faux « hélicoïdale » | FC n°8 p. 14 ; trois annales | annales 2023/2024 S1 Q5 A, 2019/2020 S2 Q15 A |

Sans ATTENTION, parce qu'aucune réponse n'en dépend : « ATCN » pour ATNC
(p. 3) ; « péril féco-oral » (p. 7) ; « foscavir », nom commercial du
foscarnet (p. 6, dit dans `pv3-qc-greffes`) ; « pneumocystis carinii » (p. 18,
la p. 17 dit *P. jirovecii*) ; les urines foncées « à cause des selles
non-éliminées » (p. 7 ; dit dans `pv3-qc-hepatites` C : c'est la bilirubine
conjuguée) ; « leuco-encéphalite » (p. 6) pour leucoencéphalopathie (p. 3).

## Ce que les annales ont dicté

| Savoir | Questions |
|---|---|
| Le VIH : capside en cône tronqué (ni icosaédrique ni hélicoïdale), trois enzymes embarquées, gp120 et CD4/corécepteur, gp41 et fusion, rétrotranscription cytoplasmique ; ARN avant p24 avant anticorps ; western-blot = anticorps | les 17 questions VIH, de 2016/2017 à 2024/2025 |
| Le VHC : ARN enveloppé, parentéral, cytoplasmique, chronique dans 70-80 % des cas ; anticorps = contact, ARN = statut ; génotypes ; AAD | 2022/2023 S1-S2 Q18, 2021/2022 S1-S2 Q18, 2017/2018 S1-S2 Q27, 2016/2017 S1-S2 Q29, 2015/2016 S1-S2 Q30 |
| Les hépatites ensemble : parentéral (B, C, D) / entéral (A, E), chiffres de chronicité, profils guéri et chronique du VHB | 2024/2025 Q13 ; 2023/2024 S1-S2 Q13, 2020/2021 S1 Q28 et S2 Q12, 2019/2020 S1-S2 Q13, 2018/2019 S1-S2 Q28 |
| Le VHB : ARN prégénomique, particules incomplètes, profil sérologique (figure 1) | 2017/2018 S1-S2 Q28, 2015/2016 S1-S2 Q29 |
| Les ATNC : protéine sans acide nucléique, PrPc → PrPsc riche en feuillets β, résistante à la protéinase K ; MCJ, ESB et vMCJ ; apoptose sans inflammation ; évolution longue ; transmission iatrogène et alimentaire | les 10 questions ATNC, de 2015/2016 à 2020/2021 |
| L'EBV : salive, LB, LT CD8 du syndrome mononucléosique, anticorps hétérophiles, VCA et EBNA, cancers | les 8 questions EBV |

Trois questions sont aussi dans le polycopié VIRO n°4 : 2021/2022 S1 Q18 et Q19
(même clé) et 2023/2024 S1 Q5 (sa clé seule, « Q5 / BCE »). Elles ne sont
cartées qu'une fois, ici, et leur explication le dit. Les 46 autres questions
de VIRO n°7 sont dans `viro_multiplication` (système nerveux, transmission
mère-enfant, persistance) et `viro_marqueurs` (intérêts et méthodes du
diagnostic).

**La figure 1** des sessions 2015/2016 S1 et S2 (Q29) est la question : elle est
montrée au-dessus de l'énoncé (`illustration_question`, image du polycopié
p. 30, la même à la p. 31), et la diapositive légendée de la p. 9 est en
correction.

## Le schéma cliquable et la planche

| Fichier | Ce qu'on clique | Cartes |
|---|---|---|
| `pv3-vih-particule-nue.svg` (`pv3-zo-vih`) | gp120, gp41, enveloppe, matrice, capside p24, deux ARN, transcriptase inverse, intégrase, protéase | 9 |

La particule est redessinée en couronnes concentriques, comme la diapositive de
la p. 14 : têtes de gp120, tiges de gp41, bicouche, couronne de matrice (des
anneaux, `annulus`) ; au centre, la paroi du cône tronqué (un anneau
trapézoïdal, dehors puis dedans), et dans le cône l'ARN et les trois enzymes.
Aucune légende sur la version nue ; la version légendée,
`pv3-vih-particule.svg`, tirée des mêmes constantes, est en correction de la
zone et de quatre annales VIH.

**Le brouillon du 03/10** (le générateur, ce schéma et 33 figures dans
`media/`, sans `donnees.py` ni `annales.py`) a été relu comme le reste : le
générateur est la copie exacte du modèle ; le schéma a été relu contre les
p. 14-15, seule la note de la gp41 a changé (la liaison « covalente » du
Ronéosaure, corrigée) ; chaque figure a été comparée à sa page et à son nom —
toutes justes. Deux figures que rien n'illustrait, la diffusion par le LCR et le
poliovirus (p. 2-3), ont été retirées de `media/` ; la rage illustre le texte à
trous des voies d'invasion.

**La planche** `pv3-pl-vhb-aigue` : la diapositive « Acute Hepatitis B Virus
Infection with Recovery » (p. 9), légendes anglaises effacées par
`scripts/planche_depuis_image.py` — six numéros (Ag HBe, Ac anti-HBe, Ac
anti-HBc totaux, Ag HBs, IgM anti-HBc, Ac anti-HBs), trois intrus (ADN du VHB,
Ag HBc, Ac anti-VHC). Le titre de la diapositive est gardé. L'aperçu de
contrôle a été relu ; deux restes de lettres (le « g » de HBeAg et de IgM) et
un trait de la courbe des anti-HBc totaux, entamé par le premier rectangle, ont
été repris. À la relecture, la hampe du « I » de IgM restait en gris pâle à
gauche du n° 5 : le rectangle a été élargi d'un pixel (x0 = 460) et la planche
refaite ; la courbe rouge n'est pas entamée.

**Illustrations** : 86 QCM sur 90 (96 %) portent une figure de la fiche ou la
particule légendée en correction ; 109 notes sur 131. Les quatre QCM sans
figure (`pv3-qc-congenitales`, `pv3-qc-perinatales`, `pv3-qc-greffes`,
`pv3-qc-vhd`) n'en ont pas dans la fiche (p. 5-6 et 11 sont sans image).

## Le sujet 2025/2026 (18/10/2026)

Le sujet de virologie de l'examen du 08/01/2026 (cahier de 30 QCM,
`src-sujet-viro-2526`, sans corrigé), déposé le 18/10/2026, apporte 4
questions à ce chapitre (Q.14, Q.15, Q.16, Q.17) ; les autres questions vont
aux chapitres de leur cours. Aucune n'était déjà en cartes. Chaque clé est
déduite du cours 2025-26, l'année de l'examen, proposition par proposition et
page à l'appui (`officielle=False`) ; les propositions déjà posées d'autres
années ont servi de contre-épreuve, et l'explication dit chaque reprise.
Rédigées et contre-vérifiées le 18/10/2026 : un rédacteur, un sceptique qui a
refait chaque clé sur le cours, un critique de complétude. Le profil des clés
— A souvent vraie, trois ou quatre vraies par question — est celui des
sessions 1 officielles du Pr Hober (2021/2022 S1, 2023/2024 S1).

| Question | Clé imprimée | Retenue | Lecture |
|---|---|---|---|
| 2025/2026 Q.14 (`pv3-an-2526-q14`) | aucune (sujet sans corrigé) | **ABCE** | Entérale : VHA et VHE ; parentérale : VHB, VHC, VHD ; le VHB abîme le foie par la réponse immunitaire, pas par lui-même ; le VHD aggrave le risque de forme fulminante. |
| 2025/2026 Q.15 (`pv3-an-2526-q15`) | aucune (sujet sans corrigé) | **BC** | L'Ag HBc reste dans le foie ; dans le sang circulent les antigènes HBs et HBe (direct) et les anticorps (indirect) ; pour le VHC, les anticorps disent le contact, l'ARN l'issue. |
| 2025/2026 Q.16 (`pv3-an-2526-q16`) | aucune (sujet sans corrigé) | **BCE** | La particule du VIH : une enveloppe à gp120 (attachement) et gp41 (fusion), une capside en cône tronqué de p24, trois enzymes ; le génome : trois gènes de structure et six de protéines non structurales. |
| 2025/2026 Q.17 (`pv3-an-2526-q17`) | aucune (sujet sans corrigé) | **ABCE** | L'EBV, un Gammaherpesvirinae transmis par la salive : l'oropharynx, puis les lymphocytes B ; une mononucléose au diagnostic sérologique ; la leucoplasie chevelue de l'immunodéprimé. |

Ce qui est signalé :

- Coquilles gardées telles qu'imprimées : « Le VHB et fortement cytocide » (Q.14
  D), « coinfection » (Q.14 E), « peut-être détecté » (Q.16 E).
- Q.15 D : l'ATTENTION de l'errata de la promo (« Ac anti-VHC : seule manière de
  détecter une forme chronique », p. 13), carte ajoutée à sa ligne du tableau
  des erreurs.
- Q.16 A : un ATTENTION rappelle que le tableau de classification de la FC n°1
  range les Retroviridae parmi les « Icosahedral » ; il dit la famille en
  gros, la capside du VIH est un cône tronqué (p. 14), et le professeur cote
  faux « capside icosaédrique » (2019/2020 S1 Q15 A, 2020/2021 S2 Q14 A,
  2022/2023 S1 Q20 A).
- Q.16 D : le texte du ronéo (p. 15) fait « réagir » avec le CD4 les trimères
  gp120-gp41 ; la diapositive de la même page, qui fait foi, donne
  l'attachement à la gp120 et la fusion à la gp41. Point de lecture, dit dans
  la justification, sans ATTENTION.
- Q.15 D et Q.17 D citent aussi l'ED 1 de virologie (Pr Hober, Ronéosaure
  2024-25), cité dans le texte comme les autres fiches d'appoint ; les clés
  tiennent sur la FC n°8 (p. 13 et 18).

## Les clés qui ne sont pas reprises telles quelles

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2016/2017 S1 Q29 (VHC) | BCD | **CD** | B, « le dépistage de l'infection repose sur la détection d'ARN viral », est fausse : le dépistage repose sur les anticorps anti-VHC, l'ARN confirme et dit le statut (FC n°8 p. 13 ; HAS) ; le professeur cote vrai « dépistage par les anticorps » en 2016/2017 S2 Q29 B et 2015/2016 S1 Q30 C ; la session 2 de la même année reprend la question en miroir (C, D, E y changent de sens) et y cote vrai « anticorps » en B. `officielle=False`, conflit sur B |
| 2024/2025 Q5 (`pv3-an-2425-q5`) | aucune (sujet sans corrigé) | **ABCE** | clé déduite du cours : ARN enveloppé, capside en cône tronqué (p. 14) ; p24 par ELISA, ARN plasmatique détectable, western-blot = anticorps (p. 17). `officielle=False` |
| 2024/2025 Q13 (`pv3-an-2425-q13`) | aucune (sujet sans corrigé) | **ABCD** | clé déduite du cours : VHB sexuel (p. 8) ; Ac anti-VHC = contact, pas guérison (p. 13) ; Ag HBs et anti-HBc dans l'infection récente (p. 9) ; pas d'anti-HBs chez le porteur chronique (p. 10). B, « 5 à 10 % », retenue vraie comme dans les annales, mais le cours dit aussi 10 à 20 % : ATTENTION sur B, conflit déclaré. `officielle=False` |

Reprises, avec une remarque dans la carte : **2023/2024 S2 Q13 B** et
**2015/2016 S2 Q29 E** (« 5 à 10 % » de chronicité du VHB, cotés vrais quand la
FC n°8 écrit 10 à 20 %) ; **2017/2018 S2 Q28 B** (« le génome est rétrotranscrit
en ADN », cotée fausse : c'est l'ARN prégénomique qui l'est) ; **2015/2016 S1 Q30
D** (hépatite C fulminante « dans 1 % », cotée fausse ; point douteux, posé
ci-dessous) ; **2015/2016 S2 Q30 A** (transmission du VHC « par les sécrétions
sexuelles », cotée fausse : rare mais possible, et le tableau de la p. 7 range
le VHC avec le VHB, « sang, sécrétions sexuelles… » — point douteux, dit dans la
carte) ; **2019/2020 S2 Q12 E** (« la
mort en quelques semaines ou mois », cotée vraie, comme « évolution longue »
ailleurs : ce que les clés refusent, ce sont les heures ou les jours).

Énoncés gardés tels qu'imprimés : « infecté pas le VHC » (2023/2024 S2 Q13 C, et
2024/2025 Q13 C),
« anti-EBNA sérique » et « hétérologues dirigés contres » (2022/2023 S1 Q19),
« mononucléés » (2015/2016 S2 Q28 C), « Creutzfeld-Jakob » (2018/2019 S2 Q27 D),
« riche en feuillets » sans β (2016/2017 S2 Q18 B), « virus de hépatites »
(2019/2020 S1 Q13) et « virus des hépatite » (2018/2019 S2 Q28) ; les titres de
2020/2021 S1 sans « ou » (« laquelle (lesquelles) est (sont) »).

## Questions pour Vincent

1. **L'hépatite C fulminante (2015/2016 S1 Q30 D, « dans 1 % des cas »).** La
   clé la cote fausse ; la FC 2025-26 ne donne aucun chiffre (« notion
   controversée », p. 12) ; l'Inserm la dit exceptionnelle, « dans moins de 1 %
   des cas ». Proposition du plan, appliquée : la clé imprimée, et la carte le
   signale (« point douteux ») avec sa source. À confirmer.
2. **Le VHB chronique chez l'adulte, 5 à 10 % ou 10 à 20 % (plan §16.8).** Le
   cours 2025-26 donne les deux, les annales ont coté vraies les deux.
   Proposition appliquée : les cartes disent les deux fourchettes et que 70 à
   80 % est toujours faux, sans trancher. Le ronéo 2026-27 dira peut-être le
   chiffre du professeur.
3. **gp120-gp41 « liées de manière covalente » (p. 14, et déjà en 2024-25).**
   C'est le cours lui-même ; la liaison est non covalente. Aucune annale ne
   l'a demandé : la carte le signale, sans changer de clé. Faut-il, à l'examen,
   répondre « covalente » si la question tombe ?
4. **Deux libellés de lexique adaptés** : le plan nommait « Fulminant » et
   « Mononucléose » ; les termes sont « Hépatite fulminante » et « Mononucléose
   infectieuse », parce que le compte d'annales cherche le mot entier et que
   les annales écrivent « fulminante » et « mononucléose infectieuse ». Les
   pages de « Hépatite fulminante » sont celles où le terme entier figure
   (p. 7, 10, 11), et non celles de l'adjectif seul (p. 8 et 12 en plus).
5. **Le VHC « transmis par les sécrétions sexuelles » (2015/2016 S2 Q30 A),
   cotée fausse.** La p. 12 ne cite pas la voie sexuelle ; le tableau de la p. 7
   range pourtant le VHC avec le VHB et le VHD, « sang, sécrétions
   sexuelles… » ; l'Inserm dit la transmission sexuelle rare, limitée aux
   partenaires multiples, aux pratiques traumatiques et à la co-infection VIH.
   Appliqué : la clé imprimée, avec un ATTENTION « point douteux » sur la
   carte. À confirmer.

## Le lexique

Dix termes, aux pages mesurées dans la fiche 2025-26 : méningite (p. 3),
encéphalite (3, 6), leucoencéphalopathie (3), prion (3-5), embryopathie (5),
fœtopathie (5), ictère (7, 8), cirrhose (6, 7, 11, 12), hépatite fulminante (7,
10, 11), mononucléose infectieuse (18). Chacun dit son origine grecque ou
latine.

Les étymologies nouvelles — six racines (`méning(o)-`, `encéphal(o)-`,
`ictér(o)-`, `cirrh(o)-`, `fulmin- (latin)`, `infect- (latin)`) et les dix
termes — sont **proposées** pour `scripts/etymologies.json` (fichier de travail
`etym/viro_pathogenes_3.json`), avec leurs sources ; la table n'est pas modifiée
par ce chapitre. Les définitions et les racines disent déjà, mot pour mot, ce
qu'`appliquer_etymologies.py` en écrira. Les racines réemployées gardent la clé
de la table : `-ite`, `leuc(o)-`, `-pathie`, `prot(é)-`, `embry(o)-`,
`fœt(o)- (latin)`, `-ose`, `mono-`, `nuclé(o)-`, `hépat(o)-` ; quatre citent la
FC de sémantique (`-pathie`, `mono-`, `leuc(o)-`, `-ose`).

## À relire

Aucune carte `a-relire` : chaque carte de cours porte sa page dans la fiche
2025-26, chaque annale sa clé de la table (p. 32), vérifiée — ou, pour les deux
de 2024/2025, sa clé déduite d'une page du cours ; l'énoncé de chaque annale a
été comparé, mot pour mot, au texte du polycopié ou du sujet. À la parution du
ronéo 2026-27 de ce cours, relire toutes les cartes contre lui : pages,
chiffres (chronicité du VHB, formes fulminantes, génotype 1b, fenêtre
virologique), et les erreurs du tableau ci-dessus.

## L'échelle : Simple → Moyen → Annale (C20, 19/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 5 janvier. Sous les annales, 73 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 13 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`).

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `prions` | 12 | 3 | 10 |
| `hepatites` | 26 | 3 | 22 |
| `vhb-marqueurs` | 4 | 1 | 3 |
| `vih` | 19 | 4 | 18 |
| `ebv` | 12 | 2 | 9 |

**Les schémas** sont au nombre de 2 : `ech-hepatites-ebv`, « Hépatites virales et EBV · virus, marqueurs, évolution » (42 Simple, 6 Moyen, 34 annales ; 83 fichiers), et `ech2-prions-vih`, « Prions et VIH · l'agent, la maladie, le diagnostic » (31 Simple, 7 Moyen, 28 annales ; 67 fichiers). Une carte ou une annale va au schéma de son mécanisme. Ils sont décrits dans `schemas.py` (`ECH_HEPATITES_EBV`, `ECH2_PRIONS_VIH`, avec leurs `TROUS_*` et `LETTRES_*`, un `FICHIERS.update` chacun) et dessinés par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Sans marche** :
- pv3-an-1516s2-q30 A : le VHC « transmis par les sécrétions sexuelles », coté faux, est un point douteux que le cours ne tranche pas (la p. 12 ne cite pas la voie sexuelle, le tableau de la p. 7 range le VHC avec le VHB, « sang, sécrétions sexuelles… ») ; aucune marche ne l'enseigne dans un sens ou dans l'autre, et la lettre est posée sur la case de la transmission.

## Régénérer

```powershell
cd contenu\chapitres\viro_pathogenes_3
..\..\..\app\.venv\Scripts\python.exe generer.py
```

La planche se refait depuis `app/`, si ses rectangles changent :
`uv run --with pillow python ../.claude/skills/nouveau-chapitre/scripts/planche_depuis_image.py ../contenu/chapitres/viro_pathogenes_3 pv3-pl-vhb-aigue --apercus <brouillon>`.
