# Mutations instables, anticipation — paquet Génétique

71 notes, 159 cartes. Chapitre `chap-ue-genetique-fc6` de l'UE Génétique.
Cours de la **Pr Florence Petit, le 01/12/2025**, « Mutations instables,
anticipation » (FC n°6 du Ronéosaure 2025-26, 10 pages) ; annales du
polycopié n°6 du Ronéosaure 2024-25 (13 questions sur six sessions). Examen du
16 décembre 2026.

**Une fiche provisoire.** Le ronéo 2026-27 de ce cours n'est pas paru au
02/10/2026 : le chapitre est carté sur le Ronéosaure 2025-26 (tâche C15,
décision de Vincent du 02/10), et le ronéo de l'année corrigera les cartes à
sa parution. La source porte son année dans son auteur : chaque carte de cours
(hors lexique) a le tag `cours-2025-26` et montre « Cours 2025-26 ». Aucune
carte ne dit « Absent du cours 2026-27 » ; les erreurs du Ronéosaure sont
dites par un ATTENTION sans genre, et n'entrent pas dans
`contenu/ERRATA_RONEOS_2026-27.md`, qui ne concerne que les ronéos 2026-27.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 33 | 33 |
| QRU | 2 | 2 |
| Texte à trous | 12 | 97 |
| QROC | 8 | 8 |
| Recto-verso | 6 | 6 |
| Schéma cliquable | 1 | 4 |
| Planche à légender | 1 | 1 |
| Lexique | 8 | 8 |

Dont **13 annales** (13 QRM), sur six sessions de 2016/2017 S1 à 2023/2024
S1. **22 QCM du cours** (20 QRM, 2 QRU) ; chaque QCM a une justification par
proposition. **33 QCM sur 35 sont illustrés** (le hook : 94 %), 61 notes sur
71 ; les deux QCM sans figure portent sur des signes cliniques (Steinert,
X fragile), que le cours ne montre qu'en vidéo ou pas du tout.

Six thèmes, dans l'ordre du cours, tous nouveaux (plan C15, 0.6), **à ajouter
à `THEME_LABELS`** (`app/src/med_engine/application/scopes.py`) — aucune clé
n'existe ailleurs :

| Clé | Libellé | Notes (dont annales) |
|---|---|---|
| `anticipation` | L'anticipation | 6 (2) |
| `mutations-instables` | Mutations instables : seuils, biais parental, mécanismes | 14 (3) |
| `consequences-expansion` | Conséquences moléculaires des expansions | 4 (0) |
| `steinert` | Dystrophie myotonique de Steinert | 13 (0) |
| `huntington` | Maladie de Huntington | 4 (0) |
| `x-fragile` | Syndrome de l'X fragile et prémutation FMR1 | 22 (8) |

Au regroupement (03/10), `THEME_LABELS` affiche `x-fragile` en « Syndrome de
l'X fragile et prémutation » : un libellé de thème ne porte aucun chiffre
(`test_le_chapitre_se_decoupe_en_themes_lisibles`), et FMR1 en porte un.

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-genet-ist-2526` — Ronéosaure, « FC n°6 Mutations instables » (10 p.), `GÉNÉTIQUE/FC n°6 Mutations instables.pdf` | **2025-26** | **la base** : chaque note du cours porte sa page ; c'est ce que le lecteur ouvre (`chapitre=`) ; ses figures illustrent les corrections |
| `src-annales-6-mutations-instables-et-anticipation` — « 6 - Mutations instables et anticipation » (4 p., table p. 4) | 2024-25 | les 13 cartes d'annales |
| cours 2024-25 (Ronéosaure) et 2023-24 (Charonéo), FC « Mutations instables » | — | cités dans le texte, sans être déclarés : « retenir le seuil de l'X fragile, pas interrogé sur le seuil des autres » (2024-25), « les chiffres ne sont pas à retenir » pour DMPK (2023-24), « toujours une augmentation » en transmission maternelle (2023-24), la stabilité de la prémutation en transmission paternelle, les expansions invisibles en ACPA et à l'exome (2023-24), « le syndrome de l'X fragile sera toujours transcrit [transmis] par la mère » (2024-25) |
| FC n°1, n°2, n°4, n°5, n°7 2025-26 | 2025-26 | citées dans le texte (test FMR1, CGH-array, disomie uniparentale, néomutations et âge paternel, Duchenne, hétéroplasmie) : ce sont les fiches d'autres chapitres |
| erratas : cours 2025-26 (`Erratas Génétique.docx`), annales 2024-25, cours 2024-25 | — | aucune entrée 2025-26 ni d'annales sur ce cours ; l'errata 2024-25 (« prématuration », colonne « Introns ») éclaire deux fautes recopiées en 2025-26 |

**La déclaration d'annales** suit la règle des chapitres écrits en parallèle
(identifiant `src-annales-<slug du nom du fichier>`, cinq champs exactement,
le titre avec l'espace finale du nom de fichier) ; aucun autre chapitre ne
déclarait ce polycopié.

Vérifications hors du cours, citées dans la carte qui s'en sert : Ashizawa et
al., Am J Hum Genet 1994 (contractions de la CTG : 3 % des transmissions
maternelles, 10 % des paternelles) ; Wittenberger et al., Fertil Steril 2007
(une prémutation chez 0,8 à 7,5 % des femmes à IOP sporadique, jusqu'à 13 %
à IOP familiale) ; Bean et Bayrak-Toydemir, Genet Med 2014, recommandations
de l'ACMG (seuils de Huntington) ; Monrós et al., Am J Hum Genet 1997 (pas
d'anticipation dans l'ataxie de Friedreich, récessive) ; Lin, Dion et
Wilson, Nat Struct Mol Biol 2006 (instabilité induite par la transcription) ; l'étymologie (TLFi par l'API du portail du
CNRTL, Bailly, Gaffiot, Wiktionnaire ; Babinski 1914 pour « anosognosie »).

## Ce que le cours a dicté

- **Le rouge du ronéo** a ses cartes : « À quel moment l'ADN est-il simple
  brin ? » (p. 3 : `gmi-fa-mecanismes`, `gmi-qc-structures`) et la conclusion
  (p. 10 : `gmi-fa-conclusion`, `gmi-qc-conclusion`).
- **« Les chiffres ne sont pas à retenir »** (tableau de Huntington, p. 8, en
  rouge) : aucune carte ne demande un seuil de CAG ; la figure illustre, et
  l'explication de `gmi-qc-huntington-genetique` donne la référence. Les seuils
  de DMPK (5-37, > 50 CTG) suivent la même règle (cours 2023-24 et 2024-25) :
  ils sont dans les justifications, aucune carte ne les demande (la
  relecture a retiré les deux propositions de `gmi-qc-steinert-genetique`
  qui les demandaient).
- **FMR1, « à retenir ++ pour les EDN »** (p. 1, 8, 10) : le thème le plus
  fourni (22 notes), avec ses seuils (45, 55, 200), qui se cartent.
- **Le gris** : les titres des deux vidéos (p. 5 et 7) — les trois choses que
  la vidéo du Steinert apprend à chercher sont en noir, et cartées
  (`gmi-qc-steinert-signes`) ; le renvoi au tableau du Ronéosaure (p. 4), dont
  les deux fautes sont dites ci-dessous. Huntington est « ++ développée en
  MED-3 » : le chapitre s'en tient à la page du cours.
- **Ce qui appartient à d'autres chapitres n'est pas carté** (plan C15, 0.5) :
  la pénétrance de Huntington selon l'âge (`genet_mendelien`), le test ciblé
  FMR1 (`genet_tests`), le site fragile en cytogénétique
  (`genet_cytogenetique`).
- **Aucune photographie de patient** : le cours n'en a pas. La coupe
  coronale de cerveau (p. 7) est une pièce anatomique, gardée.

## Les erreurs du Ronéosaure 2025-26

Chacune est dite par **ATTENTION**, sans genre, dans la carte qui porte la
notion.

| p. | Ce que dit le ronéo | Ce qui est retenu | Sorte | Carte |
|---|---|---|---|---|
| 4 | tableau de synthèse : « 3'UTR : toxicité ARN et protéine » | 3'UTR non traduit : toxicité de l'ARN seule (p. 6-7 ; la diapositive de la même page) | recopié du Ronéosaure 2024-25 | `gmi-qc-localisation` B, `gmi-fa-localisation` |
| 4 | tableau : colonne « Introns », exemple vide, pas de 5'UTR | le 5'UTR de FMR1, l'exemple de la perte de fonction (errata des cours 2024-25 ; diapositive p. 4, FXN en intron) | recopié du Ronéosaure 2024-25 | `gmi-qc-localisation` D, `gmi-fa-localisation` |
| 6 | « Maternelle : si > 50 CTG, elles causent toujours une expansion » | le cours lui-même (2023-24 : « toujours une augmentation »). À l'examen : l'expansion maternelle ; la référence : 3 % de contractions maternelles (Ashizawa 1994) | point douteux | `gmi-qc-steinert-transmission` B |
| 8 | diapositive : 36-37 CAG « parfois atteint », > 38 « atteint » | chiffres « pas à retenir » ; la référence : 36-39 pénétrance réduite, ≥ 40 complète (ACMG 2014) | le cours lui-même | `gmi-qc-huntington-genetique` (explication) |
| 10 | « La prématuration de FMR1 » | prémutation (même faute à l'errata 2024-25) | prise de notes | `gmi-qr-premutation` (et la définition du lexique) |
| 10 | prémutation : « 2-14 % des cas sporadiques » d'IOP, « 21 % des cas familiaux » | 0,8 à 7,5 % des sporadiques, jusqu'à 13 % des familiales (Wittenberger 2007) ; chiffres non demandés | point douteux | `gmi-qc-premutation` E |

Sans ATTENTION, parce qu'aucune réponse n'en dépend, mais dit dans la carte :
« 50 % d'entre eux présentent 11-14 CTG » pour 50 % des allèles (p. 6,
`gmi-fa-steinert`) ; l'absence d'expansion chez l'homme justifiée par
l'absence d'enfants des hommes atteints (p. 9), quand la raison est la
stabilité de la prémutation en méiose paternelle (`gmi-qc-fmr1-transmission`).
Coquilles sans conséquence : « staticiens » (p. 2), « instabilité
fonctionnelle (somatique) » (p. 6), « myopathie de Steinert » (p. 8), « Rique
FXTAS » (p. 9).

## Ce que les annales ont dicté

| Savoir | Questions |
|---|---|
| Le syndrome de l'X fragile : sexes, clinique, mécanisme, transmission | 2023/2024 S1 Q16, 2022/2023 S1 Q20, 2022/2023 S2 Q11, 2018/2019 S1 Q14, 2017/2018 S2 Q15, 2016/2017 S1 Q16 |
| La femme à 32 et 125 CGG : prémutation, IOP, FXTAS | 2023/2024 S1 Q15, 2022/2023 S2 Q10 |
| Les expansions : instabilité germinale et somatique, structures secondaires, « toujours un gain de fonction » | 2023/2024 S1 Q14, 2022/2023 S1 Q19, 2022/2023 S2 Q9 |
| L'anticipation : définition, biais parental, modes de transmission | 2022/2023 S2 Q12, 2018/2019 S1 Q1 |

### Les annales, session par session (clé retenue)

| Session | Polycopié, pages | Questions cartées ici |
|---|---|---|
| 2023/2024 S1 | n°6, p. 1-2 | Q14 ABC, **Q15 CDE** (lettres imprimées A, A, B, C, D), Q16 B (imprimée « 16. ») |
| 2022/2023 S1 | n°6, p. 2 | Q19 BCD, Q20 BDE |
| 2022/2023 S2 | n°6, p. 2-3 | Q9 AC, Q10 CDE, Q11 B, **Q12 BCD** (B : point douteux) |
| 2018/2019 S1 | n°6, p. 3-4 | Q1 BCDE, Q14 ABD |
| 2017/2018 S2 | n°6, p. 4 | Q15 ACD |
| 2016/2017 S1 | n°6, p. 4 | Q16 ACD |

Anomalies d'impression, dites dans les cartes : l'en-tête de gabarit
« BMCP - Annales, Professeur X » sur chaque page (ce sont bien les annales de
génétique de la Pr Petit) ; les lettres de la 2023/2024 S1 Q15 (deux « A »,
pas de « E » : la clé CDE se lit dans l'ordre de la 2022/2023 S2 Q10, même
énoncé, même clé) ; la 2023/2024 S1 Q16 imprimée « 16. » ; les polycopiés n°5
et n°6 impriment chacun une « 2018/2019 S1 » Q1 et Q14 d'énoncés différents
(un des deux en-têtes est faux, chacun garde le sien). Doublons, une carte par
session et l'explication renvoie à l'autre : Q15/Q10, Q16/Q11, 2017/2018 Q15
et 2016/2017 Q16.

## Les clés qui ne sont pas reprises telles quelles

Aucune : les 13 clés imprimées sont gardées, relues proposition par
proposition contre le cours 2025-26. Un point douteux est gardé à la clé
imprimée, avec ATTENTION, `CONFLITS` et le tag `a-relire` :

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2022/2023 S2 Q12 B, « l'anticipation peut concerner les affections autosomiques récessives » | BCD (B vraie) | **BCD**, clé officielle | c'est le cours (« tous les modes de transmission », p. 10 ; cours 2024-25) et la clé de la professeure ; mais l'exemple récessif, l'ataxie de Friedreich, ne montre pas d'anticipation (Monrós et al., Am J Hum Genet 1997 : récessive, elle touche une fratrie de parents porteurs sains). À l'examen : vrai ; « surtout récessive » reste faux (2018/2019 S1 Q1 A) |

`CONFLITS` : `gmi-an-2223s2-q12` (B). Une nuance sans conflit : la 2022/2023
S2 Q9 D (« elle a lieu durant la transcription », cotée fausse comme le cours)
dit dans sa justification que la recherche décrit aussi une instabilité
induite par la transcription (Lin et al. 2006), hors programme.

## Le schéma cliquable et la planche

| Fichier | Ce qu'on fait | Cartes |
|---|---|---|
| `gene-expansions.svg` (`gmi-zo-gene`) | cliquer le siège de l'expansion CGG de FMR1 (5'UTR), CAG de HTT (exon 1), GAA de FXN (intron 1), CTG de DMPK (3'UTR) | 4 |
| `gmi-localisation-numerotee.png` (`gmi-pl-localisation`) | légender la diapositive de la p. 4 : 5'UTR, exon (deux fois), intron, 3'UTR, « perte de fonction du gène », « toxicité de l'ARN » ; intrus : promoteur, codon stop, gain de fonction, toxicité de la protéine seule | 1 |

Le gène est redessiné nu d'après la diapositive de la p. 4 : aucun nom de
région n'est écrit, seuls l'ATG et le codon stop bornent la partie codante —
reconnaître le 5'UTR (avant l'ATG) et le 3'UTR (après le stop) fait partie de
la question. L'exon 2 et le promoteur ne portent pas de zone : un clic dessus
vaut zéro. Les UTR sont dessinés moins hauts que les exons codants. La
version légendée, tirée des mêmes constantes, est en correction et illustre
aussi sept notes du cours. Sous chaque siège, elle écrit la conséquence que la
diapositive code par la couleur de la case du gène : grise, la perte de
fonction (FXS FMR1, FRDA FXN) ; blanche, la toxicité de l'ARN (DM1 DMPK).

La planche est une capture de diapositive : chaque numéro dit son rectangle
à blanchir (`efface`, mesuré au pixel sur un agrandissement quadrillé) ; les
cases sont vidées en entier, leur cadre reste. Les gènes et leurs répétitions
restent écrits sous chaque segment : savoir que FMR1 est en 5'UTR fait la
réponse. Image numérotée par `scripts/planche_depuis_image.py --taille 15`
(la case de l'intron n'a que 14 px de haut) ; l'aperçu de contrôle a été
regardé.

## Le lexique

Huit termes, tous accueillis ici (plan C15, 0.7), pages remesurées dans le
PDF 2025-26 avec `chercher_pages.py` : **Anticipation** (2, 4, 5, 8, 10 — le
mot est dans l'en-tête de chaque page, « Mutations instable, anticipation » :
les pages ne comptent que le corps du texte, et la p. 1, le plan, est
exclue), **Prémutation** (10), **Triplet** (2, 6, 7, 8, 9 ; la p. 1 est le
plan), **Myotonie** (4-8), **Polyglutamine** (8), **Macroorchidie** (9 ;
« macro-orchidie » en annale), **Ptosis** (5, 6), **Anosognosie** (7).

Chaque définition finit par son étymologie et chaque racine dit la sienne,
écrites comme `appliquer_etymologies.py` les écrirait (vérifié). Les racines
déjà dans `etymologies.json` sont reprises sous leur clé exacte (`myo-`,
`-tonie`, `poly-`, `macro-`, `-ptose`, `a-/an-`, `pré- (latin)`,
`mutare (latin)`) ; quatre citent la FC de sémantique, comme dans les autres
chapitres qui les emploient (ajouté au regroupement du 03/10) : `-ptose` et
`a-/an-` (1/2, p. 3), `macro-` (2/2, p. 6), `pré- (latin)` (2/2, p. 10) ; les
nouvelles (`anticipare (latin)`, `gluten (latin)`,
`triplus (latin)`, `orchi-`, `noso-`, `-gnosie`) et les huit termes sont
proposés, vérifiés, dans `scratchpad/etym/genet_instables.json` — la table
n'est pas modifiée. « Triplet » vient du latin triplus, par le français
triple : sa racine est `triplus (latin)`, et non `tri-`, que la table dit
grecque.

## À relire

Une carte `a-relire` : `gmi-an-2223s2-q12`, le point douteux de la B
(l'anticipation dans les affections récessives). Le tag se retire quand le
ronéo 2026-27 ou Vincent tranche. Toutes les autres cartes citent leur page de
la FC 2025-26 ; les propositions d'annales hors de ce cours citent leur
source.

## Questions pour Vincent

1. **L'anticipation dans les maladies récessives** (2022/2023 S2 Q12 B) : la
   carte la garde vraie, comme la clé et le cours (« tous les modes de
   transmission »), avec un ATTENTION qui cite l'ataxie de Friedreich, où la
   littérature ne voit pas d'anticipation (Monrós et al., 1997). D'accord ?
2. **« Toujours une expansion » en transmission maternelle** (Steinert,
   p. 6) : la carte répond comme la professeure (deux années de cours le
   disent) et donne la référence (3 % de contractions maternelles). D'accord
   avec ce « point douteux » ?
3. **Les seuils de DMPK et de Huntington** : aucune carte ne les demande
   (« pas à retenir » en 2023-24 et 2024-25 ; seul celui de l'X fragile est
   interrogé). Faut-il quand même un texte à trous sur 5-37 et > 50 CTG ?
4. **La planche de la p. 4** garde les noms des gènes sous chaque segment
   (FXS FMR1, FRDA FXN, HD HTT, DM1 DMPK) : la planche teste donc « quel
   segment porte quel gène ». Faut-il les effacer aussi, pour une planche plus
   dure ?


## L'échelle : Simple → Moyen → Annale (C20, 18/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 16 décembre. Sous les annales, 24 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 4 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`).

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `anticipation` | 4 | 1 | 2 |
| `mutations-instables` | 6 | 1 | 3 |
| `x-fragile` | 14 | 2 | 8 |

**Le schéma** `ech-instables`, « Les répétitions instables · de l'anticipation à l'X fragile », donne 42 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_INSTABLES`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Sans marche** :
- gmi-an-2324s1-q14 D : la dystrophie de Duchenne n'est pas une maladie à expansion et n'est pas dans ce cours (FC n°5) ; aucune case ne la porte, la lettre se pose sur « Mutations instables ».
- gmi-an-2223s2-q12 D et gmi-an-1819s1-q1 E : « une répétition instable sous-tend l'anticipation » se lit dans tout le schéma, à commencer par son titre : une case vide s'y lirait ; la Moyen gmi-ech-m2 (C) les prépare.
- gmi-an-2223s1-q20 D et E : la mère d'un garçon atteint, prémutée ou mutée ; une case vide sur ce point se lirait dans « expansion : par la mère », et l'écrire ferait lire la case de gmi-ech-s17 ; la Moyen gmi-ech-m4 (D) les prépare.

## Régénérer

```powershell
cd contenu\chapitres\genet_instables
..\..\..\app\.venv\Scripts\python.exe generer.py
```

`generer.py` est la copie exacte de
`.claude/skills/nouveau-chapitre/scripts/generer_modele.py`. Les figures de
`media/` sont les images du PDF extraites à leur résolution d'origine
(PyMuPDF), sauf le tableau de FMR1 (p. 9), qui est du texte, rendu à 3× ; elles
se versionnent et partent avec le chapitre. L'image numérotée de la planche
se refait depuis `app/` :
`uv run --with pillow python ../.claude/skills/nouveau-chapitre/scripts/planche_depuis_image.py ../contenu/chapitres/genet_instables gmi-pl-localisation --taille 15 --apercus <brouillon>`.
