# Télésanté — paquet Informatique médicale

73 notes, 141 cartes. Chapitre `chap-ue-info-medicale-fc7` de l'UE
Informatique médicale, septième de l'UE. Cours du **Pr Guédon, le 01/12/2025,
de 8 h à 10 h**, dans le **Ronéosaure 2025-26** (FC n°7, 20 pages) ; l'unique
annale du polycopié du Ronéosaure 2024-25. Examen : partiel du mercredi
16 décembre 2026.

**Fiche provisoire** (C15, décision de Vincent du 02/10) : le cours de l'année
2026-27 n'est pas encore paru. Chaque carte de cours cite la FC 2025-26 à sa
page et porte le tag `cours-2025-26` (badge « Cours 2025-26 ») ; le ronéo
2026-27 la corrigera quand il sortira. `donnees.py` porte
`ANNEE_COURS = "2025-26"`.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 28 | 28 |
| QRU | 2 | 2 |
| Texte à trous | 14 | 78 |
| QROC | 12 | 12 |
| Recto-verso | 7 | 7 |
| Schéma cliquable | 1 | 5 |
| Planche à légender | 1 | 1 |
| Lexique | 8 | 8 |

Dont **une annale** (Q.14, session inconnue), seule question du polycopié.

Six thèmes, dans l'ordre du cours ; les six clés sont nouvelles, et leurs
libellés restent à ajouter à `THEME_LABELS`
(`app/src/med_engine/application/scopes.py`) :

| Clé | Libellé | Notes |
|---|---|---|
| `sante-numerique` | Santé numérique : données, outils, supports, services | 5 |
| `telesante-actes` | Télémédecine, télésoin et les cinq actes | 11 |
| `teleconsultation` | Téléconsultation | 12 |
| `telesurveillance` | Télésurveillance | 13 |
| `teleexpertise-assistance` | Téléexpertise, téléassistance, régulation | 13 |
| `cadre-telesante` | Cadre légal, responsabilités et éthique | 11 |

La réponse médicale (VIII, la régulation du SAMU) est rangée dans
`teleexpertise-assistance`, dont le libellé la nomme ; le télésoin (IX) dans
`telesante-actes`.

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-info-telesante-2526` — Ronéosaure, « FC n°7 - Télésanté » (20 p.) | 2025-26 | le cours ; `SRC["fiche"]`, ses trois figures (p. 10, 12, 15) |
| `src-annales-fc-n7-telesante` — « FC n°7 - Télésanté » (2 p.) | 2024-25 | une question, table p. 2 |

Le polycopié d'annales est déclaré ici pour la première fois, sous la forme
commune de C15 (identifiant tiré du nom du fichier, titre = nom du fichier sans
extension, espace finale comprise). Lus en appoint, sans être déclarés : le
cours 2024-25 du même professeur (Ronéosaure, 31 p.), pour comprendre l'annale
et les comptes du télésoin ; le cours 2023-24 du Dr Gérard (Charonéo,
« Données médicales et urbanisation du système de santé », p. 12), qui explique
la clé de l'annale ; les erratas des cours 2025-26 et 2024-25 et celui des
annales (rien pour ce cours en 2025-26 ; l'erreur 2024-25 sur les pacemakers,
qui traitaient des rythmes « trop rapides » au lieu de « trop lents », n'est
plus dans le ronéo 2025-26, p. 10).

Les en-têtes des ronéos, des erratas et du polycopié portent des noms
d'étudiants : aucun n'est repris.

## Ce que le cours a dicté

- **Le rouge** est abondant, et chaque rouge a sa carte : les définitions de la
  télémédecine et du télésoin (p. 4), de la téléexpertise (synchrone, secret,
  sécurité, p. 12), de la téléassistance (p. 14), de la réponse médicale
  (p. 15) ; les actes combinés (p. 14) ; l'observance recueillie et
  interrompue par le professionnel de santé (p. 12) ; la bonne médecine à
  distance et le parcours hybride (p. 15-16) ; la pratique de santé non
  commerciale, la vidéotransmission, les guides et référentiels (p. 16) ; les
  charges du porteur de projet et du professionnel, le tiers technologique
  (p. 17-18) ; le droit commun (p. 18) ; les quatre principes de l'éthique, la
  qualité de vie, les déserts numériques, le coût pour la société (p. 18-20).
- **Le gris** ne marque que les titres de sous-parties et l'échange sur la
  différence entre téléexpertise et demande d'avis (p. 13) : cité dans
  l'explication de `tls-qc-teleexpertise-deroulement`.
- **Ce qui n'est pas carté ici**, parce qu'un autre chapitre le tient (plan
  C15) : le RGPD en dates, la définition des données de santé, l'hébergeur HDS,
  la messagerie sécurisée, le DMP (`info_sante`) ; la PGSSI-S comme corpus de
  l'ANS et la cryptographie (`info_cryptographie`). Les cartes les citent.
- **Les chiffres** cartés sont ceux que le cours répète : 10 € et 20 € de la
  téléexpertise (p. 13), 80 % de déplacements inutiles (p. 19), 1968, 2009,
  2010, 2019, 2021. Les « 18 professionnels » du télésoin et les « 3 mois » de
  suivi des pacemakers sont cités, sans trou.

## Ce que les annales ont dicté

| Session | N° | Clé | Thème | Ce qu'elle demande |
|---|---|---|---|---|
| 20XX/20XX (inconnue) | Q.14 | BD | `teleexpertise-assistance` | la formation continue (A, faux), le SAMU (B), la psychiatrie (C, faux), la téléassistance dans l'AVC (D), la télésurveillance et le RGPD (E, faux) |

La légende dit que « toujours la même question revient » : une seule carte. Le
polycopié garde le gabarit d'une autre UE (« BMCP - Annales », « Professeur
X », « Année 20XX/20XX (Session X) ») ; la session est gardée telle
qu'imprimée, « 20XX/20XX », dont le tag (`20xx-20xx`) porte des chiffres et ne
devient donc pas un thème.

## Les clés qui ne sont pas reprises telles quelles

**Aucune.** Un point est discuté dans la carte (`ATTENTION`, déclaré dans
`CONFLITS`), sans changer la clé :

| Question | Clé | Le point | À l'examen |
|---|---|---|---|
| 20XX/20XX Q.14 D | BD | « grâce à la téléassistance … on peut demander l'avis d'un expert » : c'est la téléexpertise dans le cours 2025-26 (p. 12-14) et le code de la santé publique (art. R. 6316-1, 2°) ; la clé suit le cours 2023-24 (p. 12), qui définissait la téléassistance par le « besoin de l'avis d'un spécialiste » | vrai, comme la table |

A (la formation continue, faux) est juste à la clé ; la justification dit
pourquoi le partage entre pairs (p. 4) et la téléexpertise « apprenante »
(p. 14) n'en font pas une finalité.

## Les erreurs du ronéo 2025-26

Le Ronéosaure n'est pas le ronéo de l'année : chaque erreur est portée par un
**ATTENTION nu** dans la carte qui tient la notion, la sorte dite dans le texte,
et rien n'entre dans `contenu/ERRATA_RONEOS_2026-27.md`.

| Page | Le ronéo dit | Retenu | Sorte | Carte |
|---|---|---|---|---|
| 12 | la téléexpertise est le « 3ème acte de la télémédecine » (en rouge) | le deuxième : sa propre liste (p. 4), la diapositive (p. 15), le code de la santé publique (R. 6316-1, 2°) ; c'est le troisième acte *présenté* dans le cours | prise de notes | `tls-fa-teleexpertise`, `tls-fa-cinq-actes` |
| 4, 15 | les actes numérotés 1 téléconsultation, 2 téléexpertise, 3 téléassistance, 4 télésurveillance, 5 régulation (l'ordre de la diapositive) | le code de la santé publique numérote 3° télésurveillance, 4° téléassistance ; aucune carte ne demande ces deux rangs | le cours lui-même (l'ordre de la diapositive, non numérotée) | `tls-fa-cinq-actes` ; le schéma `telemedecine-telesoin.svg` le dit |
| 16 | « loi HPST du 29 juillet 2009 » (déjà dans le ronéo 2024-25, p. 29) | loi n° 2009-879 du 21 juillet 2009 (Légifrance) ; aucun trou sur le jour | le cours lui-même, sans doute | `tls-fa-cadre-legal` ; `cadre-legal.svg` |
| 16 | conventions avec la CNAM « = 17 auxiliaires de vie » | des auxiliaires médicaux (p. 4, 15) | prise de notes | `tls-qc-telesoin` |
| 15-16 | « 18 professionnels de santé » dans le télésoin, pharmaciens et auxiliaires (p. 15) ; « 17 » auxiliaires (p. 16) | le ronéo 2024-25 (p. 7) écrit « 18 au total » pour les seuls auxiliaires et en nomme dix-sept ; l'arrêté du 3 juin 2021 ne les dénombre pas, et les sources secondaires comptent les métiers de l'appareillage différemment ; aucune carte ne demande ces nombres | point douteux | `tls-qc-telesoin` |
| 14 | l'imagerie de l'AVC lue à distance par le radiologue : « Télésurveillance / Téléimagerie » | une interprétation ponctuelle, plus proche de la téléexpertise ; la télésurveillance suit des données dans la durée (p. 7) | point douteux | `tls-qc-actes-combines` ; `avc-actes-combines.svg` |

Sans ATTENTION, parce qu'aucune réponse n'en dépend : « Médecins,
sages-femmes, dentistes, chirurgiens dentistes » (p. 8 : les trois professions
médicales, dit dans `tls-qc-acteurs`) ; le « secret du respect médical »
(p. 12 : le secret médical, dit dans `tls-qc-teleexpertise`) ; le « Règlement
Général des Protections des Données » (p. 6) ; « EPHAD » (p. 11) ; les
« automesures du BNP » (p. 9, sans carte : le BNP est un dosage biologique).

## Les schémas et les figures

**Trois figures de la FC 2025-26**, extraites en PNG : l'arbre de la télésanté
(p. 15), la téléexpertise avec ses médecins requérant et requis (p. 12), les
prothèses rythmiques (p. 10). Aucune photographie de patient.

**Un schéma cliquable** (`schemas.py`), avec sa version légendée en correction :

| Fichier | Ce qu'on clique | Pourquoi ce dessin |
|---|---|---|
| `dai-telesurveillance.svg` | le défibrillateur et son antenne, le communicateur chez le patient, le serveur, le site internet sécurisé, l'équipe de soins (5 zones) | l'exemple 2 de la p. 3, la chaîne d'un service de télésanté : chaque lieu est un endroit où passent les données ; le patient endormi à gauche (transmission nocturne, transmetteur près du lit, p. 18), l'hôpital à droite |

**Une planche à légender** (`tls-pl-telesante`), d'après la diapositive de la
p. 15 (`planche_depuis_image.py`) : sept numéros — télémédecine, télésoin et les
cinq actes —, des cases blanchies de même largeur pour ne pas trahir la longueur
des mots ; intrus tirés du cours (téléassistance sociale, e-learning en santé,
téléimagerie, télérééducation). La seconde carte que le plan suggérait (l'ordre
du code de la santé publique) n'est pas faite : le ronéo et la diapositive ne
donnent pas cet ordre, et la carte des cinq actes le dit.

**Neuf figures redessinées** pour les corrections : la santé numérique (p. 2-3),
télémédecine et télésoin avec les cinq actes du code (p. 4, 12-15), la mise en
œuvre d'une téléconsultation (p. 5-6), le panorama de la télésurveillance
(p. 7-12), l'AVC et ses actes combinés (p. 13-14), le cadre légal (p. 15-17),
les responsabilités (p. 17-18), les quatre principes de l'éthique (p. 18-20),
et la version légendée du défibrillateur télésurveillé.

**27 QCM sur 30 illustrés (90 %)**, 55 notes sur 73. Sans figure :
`tls-qc-objectifs`, `tls-qc-teleconsultation-lieux`, `tls-qc-programmee` (aucune
figure ne montre les objectifs, les lieux ni les motifs de téléconsultation).

## Le lexique

Huit termes, ceux du plan C15 ; aucun n'existait (vérifié contre les `lex-*` de
tous les paquets et des plans C15-C16 : SSH accueille « Principisme », pas
« Bienfaisance »). Pages mesurées dans le texte de la FC 2025-26, en-têtes et
page de plan (p. 1) exclus ; trois termes citent aussi la FC1 (p. 12), le
défibrillateur la FC4 (p. 5), sous les identifiants de leurs chapitres.

| Terme | Origine | Pages (FC7) |
|---|---|---|
| Télémédecine | grec τῆλε + latin medicina | 2-4, 11-12, 14-19 |
| Télésoin | télé- + soin (mot français d'origine discutée) | 2-4, 15-16, 18 |
| Téléexpertise | grec τῆλε + latin expertus | 4, 12-16, 19 |
| Téléassistance | grec τῆλε + latin assistere | 2, 4, 14 |
| Télésurveillance | grec τῆλε + latin super + vigilare | 3-4, 7-12, 14-15, 18-20 |
| Requérant | latin requirere | 12-14 |
| Défibrillateur | latin de- + fibra | 3, 7-10, 15, 19 |
| Bienfaisance | latin bene + facere | 18-19 |

Racines proposées à la table commune
(`scratchpad/etym/info_telesante.json`) : `télé-`, `medicina (latin)`,
`soin (français)`, `experiri (latin)`, `assistere (latin)`, `sur- (latin)`
(l'entrée de `biostat_phase_4_eim`, recopiée à l'identique), `vigilare
(latin)`, `requirere (latin)`, `bene (latin)`, `facere (latin)` ; `dé- (latin)`
et `fibra (latin)` reprennent les clés existantes. `sur-` cite la FC de
sémantique (2/2, p. 9). Les textes du lexique sont déjà écrits dans la forme
que `appliquer_etymologies.py` produirait.

## Questions pour Vincent

1. **L'annale Q.14 D** : la table la donne vraie (« grâce à la téléassistance …
   demander l'avis d'un expert »), comme le cours 2023-24 ; le cours 2025-26 et
   le code de la santé publique appellent cela de la téléexpertise. Je garde la
   clé (BD) avec un ATTENTION qui dit les deux lectures. D'accord ?
2. **La loi HPST** : les ronéos 2024-25 et 2025-26 écrivent « 29 juillet 2009 »,
   le Journal officiel dit 21 juillet. Je n'ai mis aucun trou sur le jour et
   l'ATTENTION dit la date juste. Si la diapositive du Pr Guédon porte le 29,
   faut-il le dire « à l'examen » ?
3. **La réponse médicale** (deux notes : `tls-qc-reponse-medicale`,
   `tls-qr-lareng`) : le plan C15 range la partie VIII dans
   `telesante-actes`, mais donne au thème `teleexpertise-assistance` le
   libellé « Téléexpertise, téléassistance, régulation ». Je l'ai rangée là,
   pour que ce libellé dise vrai. Préfères-tu l'autre thème (et un libellé sans
   « régulation ») ?

## À relire

**Aucune carte `a-relire`** : toutes les notes citent une page de la FC 2025-26
ou une source sûre (Légifrance pour le code de la santé publique et la loi
HPST). Reste à Vincent :

- quand le ronéo 2026-27 paraîtra, relire chaque carte sur lui et retirer le
  badge « Cours 2025-26 » ;
- `copier_les_cours.py` avec le dossier `…/examen décembre` du Ronéosaure
  2025-26, hors du bac à sable, pour que la fiche s'ouvre dans l'application ;
- ajouter les six libellés de thèmes à `THEME_LABELS`.


## L'échelle : Simple → Moyen → Annale (C20, 18/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 16 décembre. Sous les annales, 9 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 1 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`).

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `teleexpertise-assistance` | 9 | 1 | 1 |

**Le schéma** `ech-telemedecine`, « La télésanté · la télémédecine et ses actes », donne 12 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_TELEMEDECINE`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

## Régénérer

```powershell
..\..\..\app\.venv\Scripts\python.exe generer.py
```

La planche numérotée se refait, depuis `app/`, par
`uv run --with pillow python ../.claude/skills/nouveau-chapitre/scripts/planche_depuis_image.py ../contenu/chapitres/info_telesante tls-pl-telesante --apercus <brouillon>`.
