# Phase IV et pharmacovigilance : effets indésirables médicamenteux — paquet Biomédecine quantitative

71 notes, 141 cartes. Chapitre `chap-ue-biomed-quanti-fc4` de l'UE
Biomédecine quantitative, dixième de l'UE. Cours du **Dr E. Gérard, le
19/11/2025, de 9 h à 10 h**, dans le **Ronéosaure 2025-26** (FC n°10, 10 pages) ;
deux questions d'annales du Ronéosaure 2024-25 (une session). Examen : partiel
du mercredi 16 décembre 2026.

**Fiche provisoire** (C15, décision de Vincent du 02/10) : le cours de l'année
2026-27 n'est pas encore paru. Chaque carte de cours cite la FC 2025-26 à sa
page et porte le badge « Cours 2025-26 » ; le ronéo 2026-27 corrigera les cartes
quand il sortira. `donnees.py` porte `ANNEE_COURS = "2025-26"`. Aucune carte ne
dit « Absent du cours 2026-27 », et les erreurs du Ronéosaure sont dites par un
ATTENTION sans genre : la liste des erreurs de la promo,
`contenu/ERRATA_RONEOS_2026-27.md`, ne concerne que les ronéos 2026-27.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 30 | 30 |
| Texte à trous | 12 | 79 |
| QROC | 12 | 12 |
| Recto-verso | 7 | 7 |
| Schéma cliquable | 1 | 4 |
| Planche à légender | 1 | 1 |
| Lexique | 8 | 8 |

Dont **2 annales** sur une session (2019/2020 S1), rangées dans le polycopié
« 13 - Régression logistique » ; les 28 autres QCM sont des questions de cours.
Ce chapitre n'a pas de polycopié d'annales propre.

Sept thèmes, dans l'ordre du cours (clés du plan C15). `eim` est partagée avec
`bmct_risques` (UE BMCT), même libellé, déjà dans `THEME_LABELS` ; les six
autres sont nouvelles, et leurs libellés restent à ajouter à `THEME_LABELS`
(`app/src/med_engine/application/scopes.py`) :

| Clé | Libellé | Notes |
|---|---|---|
| `eim` | Effets indésirables médicamenteux | 9 |
| `methodes-eim` | Méthodes de détection des EIM | 7 |
| `imputabilite` | Déclaration et imputabilité | 7 |
| `disproportionnalite` | Analyse de disproportionnalité | 5 |
| `reutilisation-donnees` | Réutilisation des données de santé | 4 |
| `regles-decision` | Règles de décision et leurs métriques | 16 |
| `data-mining` | Data-mining et arbres de décision | 15 |

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-biomed-eim-2526` — Ronéosaure, « FC n°10 - Phase IV et pharmacovigilance - EIM » (10 p.) | 2025-26 | le cours ; `SRC["fiche"]`, ses 13 figures et ses 7 tableaux ; fiche provisoire en attendant le ronéo 2026-27 |
| `src-annales-13-regression-logistique` — « 13 - Régression logistique » (13 p.) | 2024-25 | la session 2019/2020 S1, Q19 et Q21 (p. 8) ; table p. 13 |
| `src-fc-biomed-rlg-2526` — FC n°11, régression logistique | 2025-26 | citée par une page du lexique (« surajustement », p. 11), sous l'identifiant de son chapitre, sans être déclarée ici (comme `biostat_phases_1_2`) |

Le polycopié d'annales est déclaré dans la forme commune de C15 (id tiré du nom
de fichier, titre = nom sans extension, chemin, auteur), à l'identique de
`biostat_regression_logistique` et `biostat_scores`, qui le citent aussi. Lus en
appoint, sans être déclarés : les cours 2024-25 (« Phase IV, identification des
EIM », Dr Gérard) et 2023-24 (Charonéo), cités dans trois justifications ;
l'errata des cours 2025-26 (une entrée pour ce cours : « EIM rares », p. 2
imprimée, p. 3 du PDF) et celui des annales 2024-25 (aucune entrée « Phase
IV »).

Les pages citées sont celles du PDF ; la p. 1 est la page de garde et le plan,
et le ronéo imprime la page du PDF sur dix. Les en-têtes des ronéos, des
erratas et des polycopiés portent des noms d'étudiants : aucun n'est repris. Le
polycopié d'annales attribue ces questions au « Pr Décaudin » : l'attribution
n'est pas reprise.

## Ce que le cours a dicté

- **Le rouge** est celui des titres et de la colonne « Inconvénients » des
  tableaux : chaque inconvénient a sa proposition (`eim-qc-phases`,
  `eim-qc-declaration`, `eim-qc-base-pv`, `eim-qc-epidemiologie`,
  `eim-qc-reutilisation-limites`, `eim-qc-epilogue`).
- **Le gris** est la voix des rédacteurs, carté comme le reste (décision du
  25/09) : la diapositive des notations (p. 6, « pas expliqué à l'oral »,
  illustration de `eim-qc-regle`), la définition « selon ChatGPT » du
  data-mining (p. 7 : une ligne par patient, une colonne par variable, dite
  dans l'explication de `eim-fa-data-mining`) et la réutilisation des données
  « passée très rapidement » (p. 10, `eim-qr-pmsi`,
  `eim-qc-reutilisation-limites`). Le gris de la p. 9 (« le prof n'a pas
  détaillé » le calcul des fréquences) n'appelle pas de carte.
- **Les tableaux avantages / inconvénients** sont décalés dans le texte extrait
  du PDF ; ils sont attribués d'après l'image (p. 3 haut : phases 2-3 ; p. 3
  bas : déclaration ; p. 4 haut : disproportionnalité ; p. 4 bas :
  épidémiologie classique ; p. 5 haut : réutilisation des données) et extraits
  en PNG pour les corrections.
- **La définition de l'EIM** est celle du cours, « à doses normales, et non en
  cas de surdosage » (p. 2) ; les cartes rappellent que c'est la définition
  classique de l'OMS, et que le code de la santé publique inclut depuis 2012
  surdosage et mésusage (art. R. 5121-152 pour la définition, « réaction
  nocive et non voulue », sans condition de dose ; R. 5121-151 pour le champ
  de la pharmacovigilance, surdosage, mésusage, abus et erreur compris) —
  comme `bmct_risques`, qui ne cite que le R. 5121-152.
- **Frontières** (plan C15) : la notification spontanée et ses limites, la
  pharmaco-épidémiologie, le RR et l'OR, l'olmésartan sont au chapitre
  `biostat_pharmacovigilance` (FC n°9) ; l'EIM et le CRPV vus par la
  pharmacologie, à `bmct_risques`. Ce chapitre carte les méthodes de détection.

## Les erreurs du Ronéosaure 2025-26

Le Ronéosaure n'est pas le ronéo de l'année : chaque erreur est portée par un
**ATTENTION nu** dans la carte qui tient la notion, la sorte dite dans le texte,
et rien n'entre dans `contenu/ERRATA_RONEOS_2026-27.md`.

| Page | Le ronéo dit | Retenu | Sorte | Carte |
|---|---|---|---|---|
| 2 | le sildénafil « développé initialement contre l'hypertension pulmonaire », le priapisme « EIM fréquent » | développé par Pfizer contre l'angor ; érections observées chez les volontaires de phase I ; Viagra autorisé en 1998, l'HTAP en 2005 (Ghofrani et al., Nat Rev Drug Discov 2006) ; priapisme RARE (RCP de l'EMA, ≥ 1/10 000 et < 1/1 000). À l'examen : le message, un EIM peut mener à une nouvelle indication | point douteux | `eim-qc-sildenafil` B, `eim-qr-viagra` |
| 3 | phases 2 et 3 : « incapacité à détecter les EIM » | les EIM **rares** (errata de la promo, « pas encore corrigé sur la VN ») | prise de notes | `eim-qc-phases` C |
| 3 | « études cas / non-cas, soit des cas / témoins au sens classique » | et **non** des cas-témoins au sens classique : la phrase continue « car les témoins sont des patients ayant eu un EIM », et le tableau de la p. 4 dit les témoins atypiques. Le cours 2024-25 (p. 3) les appelait « études cas-témoins », « parfois appelées cas-non-cas », à témoins atypiques : la carte le dit, c'est « au sens classique » qui est faux | prise de notes | `eim-qc-disproportionnalite` E, `eim-rv-cas-non-cas` |
| 5 | les essais de phases 2 et 3, « un vrai schéma cas-témoin » | exposés contre non exposés (la phrase qui précède) : un schéma expérimental, randomisé | prise de notes | `eim-qc-recapitulatif` A |
| 9 | « est-ce qu'il faut arrêter le médicament ? (oui/non). Si oui, on pose alors une dernière condition : hypoalbuminémie » | la condition est « Arrêt médicament X ? », un fait observé ; l'hypoalbuminémie se teste chez les 30 patients dont le médicament X n'est **pas** arrêté (figure p. 8, règles p. 9, cours 2023-24 p. 8-9) | prise de notes | `eim-qc-avk-arbre` D |
| 10 | l'instabilité des arbres, « (ne peuvent concerner qu'un seul patient) » | une petite modification de l'échantillon peut changer toute la suite des divisions (Hastie, Tibshirani, Friedman, *The Elements of Statistical Learning*, 2009, § 9.2.4). À l'examen : « instabilité » est un inconvénient | point douteux | `eim-qc-epilogue` D |

Les quatre premières lignes sont celles du plan C15 ; les deux dernières ont
été trouvées en relisant (la p. 9 contre sa propre figure et le cours 2023-24 ;
la p. 10 contre une référence statistique).

## Ce que les annales ont dicté

| Polycopié | Session | N° | Clé imprimée | Retenue | Thème | Carte |
|---|---|---|---|---|---|---|
| 13 - Régression logistique | 2019/2020 S1 | Q19 | BDE | BDE | `imputabilite` | `eim-an-1920s1-q19` |
| 13 - Régression logistique | 2019/2020 S1 | Q21 | BC | BC | `regles-decision` | `eim-an-1920s1-q21` |

Deux savoirs : l'imputabilité juge un cas pris seul, sur la chronologie et la
plausibilité, sans risque relatif ni haut niveau de preuve ; une règle de
décision est binaire et probabiliste, sa confiance est une VPP et non une
sensibilité, et le support n'est pas « la métrique la plus importante ». Les
cartes de cours reprennent ces pièges (`eim-qc-imputabilite`, `eim-qc-confiance`,
`eim-qc-choisir-regle`, `eim-qc-regle`). L'énoncé de la Q21 imprime « règles de
décision,, » : gardé tel quel.

## Le schéma cliquable et la planche

**Un schéma cliquable** (`schemas.py`), avec sa version légendée en correction :

| Fichier | Ce qu'on clique | Pourquoi ce dessin |
|---|---|---|
| `regle-venn.svg` | C ∩ E (numérateur de la confiance et du support), C sans E (l'alerte à tort), E sans C (l'effet manqué), hors des deux (la VPN « sans intérêt ») — 4 zones | les deux diagrammes de Venn de la p. 6 : chaque métrique d'une règle n'est qu'une région rapportée à une autre ; on clique les régions, la correction donne les formules |

Les cercles sont deux disques de 125 px ; les croissants et la région
extérieure s'arrêtent à 3 px du cercle voisin, si bien qu'aucune zone n'en
touche une autre ; la région extérieure est un seul polygone percé, tracé comme
`geometry.annulus`. Les zones ont été testées : aucun recouvrement, chaque
région au bon endroit, le schéma rendu et regardé.

**Une planche à légender**, `eim-pl-arbre` (`planche_depuis_image.py`), prévue
par le plan : la diapositive de l'arbre de décision (p. 8), ses neuf légendes
effacées — racine, branches, feuille, nœud, sens de lecture, condition,
« n, f » avant la séparation, la branche où f diminue (n1, f1), celle où elle
augmente (n2, f2) — ; le paragraphe « Unité de base… », la bulle « n et f :
décrivent l'échantillon avant séparation » (vidée, la case reste) et les
formules, qui donnaient les réponses, sont effacés aussi. Quatre intrus :
support, confiance, condition redondante, rappel. L'aperçu de contrôle a été
regardé : le mot « Condition » chevauchait le tronc, effacé avec lui ; le
numéro 6 tient sa place.

**Dix-neuf figures de la FC 2025-26**, en PNG, réduites à 1000 px de large au
plus et en 256 couleurs : douze captures de diapositives et sept tableaux des
rédacteurs. **30 QCM sur 30 illustrés**, 50 notes sur 71.

## Les clés qui ne sont pas reprises telles quelles

Aucune. Les deux clés imprimées (BDE, BC) ont été vérifiées proposition par
proposition et sont justes ; aucun conflit (`CONFLITS = []`).

## Le lexique

Huit termes, ceux du plan C15 ; aucun n'existait (vérifié contre les `lex-*`
de tous les paquets, y compris les chapitres écrits en parallèle). Pages
mesurées dans le texte de la FC 2025-26, page de plan exclue (même règle que
`chercher_pages.py`, relue avec PyMuPDF) :

| Terme | Origine | Pages |
|---|---|---|
| Imputabilité | latin imputare (in + putare), par imputable | 3 |
| Disproportionnalité | latin dis- + proportio, par disproportion | 3, 5 |
| Priapisme | grec πριαπισμός (Πρίαπος), par le latin priapismus | 2 |
| Hypoalbuminémie | grec ὑπό + latin albumen + grec αἷμα | 9 |
| Surdosage | latin super + grec δόσις, par dose | 2, 8, 9 |
| Héparine | grec ἧπαρ | 5, 6, 7 |
| Anticoagulant | grec ἀντί + latin coagulare | 8 |
| Surajustement | latin super + ad + justus, par sur- et ajuster (l'anglais overfitting) | 10 (« sur-ajustement ») ; FC n°11, p. 11 |

Quatre racines citent la FC de sémantique (2/2), qui les enseigne dans ses
tableaux : `hypo-` (p. 10), `dis- (latin)` et `ad- (latin)` (p. 4, « dis- :
mouvement d'écartement », « ad- / af- : mouvement de rapprochement, vers »),
`sur- (latin)` (p. 9, « -sur : sur », exemple « surrénales », juste au-dessus
de « super- / supra- ») ; `dis-` comme dans `biostat_scores`, `sur-` comme dans
`info_telesante` (corrigé au regroupement du 03/10 : la relecture l'avait
laissée « hors FC », faute d'avoir vu la ligne « -sur »). Les racines nouvelles
(`putare`, `dis-`, `portio`, `Priapos`, `albumen`, `sur-`, `dosis`,
`coagulare`, `justus`) et les huit termes sont proposés à la table commune
(`etymologies.json`), vérifiés sur le TLFi (API du portail CNRTL), le Littré,
le Wiktionnaire, le Gaffiot et le Bailly ; les textes du lexique sont déjà
écrits dans la forme que `appliquer_etymologies.py` produirait (vérifié en
simulant la table fusionnée). `in- (latin, dans)`, `hypo-`, `-émie`,
`hépat(o)-`, `anti-` et `ad- (latin)` reprennent les clés existantes ; `dis-`,
`portio` et `justus` reprennent mot pour mot les propositions de
`biostat_scores`, `biostat_survie` et `biostat_regression_logistique`.

**Surajustement** a une page dans deux FC (plan C15, 19.4) : celle du
chapitre et la FC n°11, citée sous `src-fc-biomed-rlg-2526`. Le plan
d'informatique médicale le prévoyait aussi (FC n°8, apprentissage
automatique) ; `info_machine_learning` l'a laissé à ce chapitre (son
LISEZ_MOI le dit).

## Questions pour Vincent

1. **Deux erreurs de plus que le plan**, trouvées en relisant : le « si oui » de
   l'arbre des AVK (p. 9, prise de notes, prouvé par la figure et le cours
   2023-24) et la glose de l'instabilité des arbres (p. 10, classée point
   douteux, proposition retenue). Les deux sont dites sur la carte.
2. **Le sildénafil** est classé point douteux (proposition du plan) et non
   « le cours lui-même » : on ne sait pas si le professeur a dit
   « hypertension pulmonaire » ou si le ronéo a confondu avec l'indication de
   2005. La carte ne pose aucune proposition dont le verdict en dépende ; à
   relire sur le ronéo 2026-27.
3. **La définition de l'EIM** (« à doses normales, et non en cas de
   surdosage ») est cartée comme le cours la donne, avec la mention du CSP
   (surdosage et mésusage inclus depuis 2012), comme `bmct_risques`. À
   l'examen, répondre comme le cours.
4. **La racine `sur- (latin)`** (surdosage, surajustement) est proposée sous
   la même clé, avec le même contenu, par `info_telesante` (surveiller) ; elle
   a le même étymon, super, que `super- (latin)` proposée par
   `info_machine_learning` (superviser). Clé distincte parce que la forme
   française est sur- ; à fusionner si la table commune préfère une seule
   entrée. Au regroupement du 03/10, les deux clés sont entrées dans la table
   (la FC de sémantique enseigne « -sur » et « super- / supra- » sur deux
   lignes de sa p. 9) ; la question reste ouverte.

La clé de thème `reutilisation-donnees` est partagée, même libellé
(« Réutilisation des données de santé »), avec `info_reutilisation` (UE
d'informatique médicale) : un seul libellé à ajouter à `THEME_LABELS`.

## À relire

**Aucune carte `a-relire`** : chaque carte cite une page de la FC 2025-26, et
les deux clés d'annales ont été vérifiées proposition par proposition, table
relue sur le PDF (p. 13).

Relecture faite : chaque carte de cours relue sur sa page de la FC ; les deux
énoncés comparés mot pour mot au PDF du polycopié (p. 8) ; les figures, la
planche numérotée et le schéma regardés en rendu ; les zones testées (aucun
recouvrement, un point de chaque région tombe dans sa zone).

Reste à Vincent :

- quand le ronéo 2026-27 paraîtra, relire chaque carte sur lui et retirer le
  badge « Cours 2025-26 » ;
- `copier_les_cours.py` avec le dossier `…/S1 25-26/examen décembre` du
  Ronéosaure 2025-26, hors du bac à sable, pour que la fiche s'ouvre dans
  l'application ;
- les six libellés de thème à ajouter à `THEME_LABELS`.

## L'échelle : Simple → Moyen → Annale (C20, 18/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 16 décembre. Sous les annales, 9 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 2 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`).

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `imputabilite` | 5 | 1 | 1 |
| `regles-decision` | 4 | 1 | 1 |

**Le schéma** `ech-eim`, « Les EIM · déclarations, études, règles de décision », donne 14 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_EIM`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

## Régénérer

```powershell
..\..\..\app\.venv\Scripts\python.exe generer.py
```

La planche numérotée se refait depuis `app/` (Pillow n'est pas une dépendance
du projet) :

```powershell
uv run --with pillow python ../.claude/skills/nouveau-chapitre/scripts/planche_depuis_image.py ../contenu/chapitres/biostat_phase_4_eim eim-pl-arbre --apercus <brouillon> --taille 18
```
