# Rôle du stress oxydant en pathologie — paquet BMCP

154 notes. Troisième chapitre du bloc biochimie de l'UE **BMCP** (FC n°3),
cours du **Pr Dessein, 22/09/2026** (10 h-11 h et 11 h-12 h). Sources :

- **les deux ronéos 2026-27** (Ronéo & Juliette), qui font foi :
  partie 1, 14 pages (`src-fc-bmcp-stress-1`), et partie 2, 10 pages
  (`src-fc-bmcp-stress-2`) ;
- trois ronéos 2026-27 du **Pr Pigny**, fiches d'autres chapitres, déclarés ici
  sans `chapitre` parce que des cartes les citent : Métabolisme général
  cellulaire 1 (22/09) et 2 (23/09), Insuline 2 (23/09) ;
- le ronéo 2024-25 (Ronéosaure, FC n°3, 16 pages, `src-cours-stress`), sur
  lequel le chapitre avait été bâti, et l'errata BMCP 2024-25.

| Type | Nombre | Ce que c'est |
|---|---|---|
| `basic` | 70 | les couples et les définitions |
| `cloze` | 34 | les listes et les mécanismes (297 trous) |
| `qroc` | 28 | les mécanismes qui se racontent |
| `qrm` | 20 | les cinq quizz du ronéo 2024-25 et quinze QCM du cours 2026-27 |
| `zone` | 2 | les deux schémas cliquables (21 zones) |

Ce cours n'a **aucune annale** : les huit polycopiés d'annales de l'UE ont été
relus, aucun ne porte sur le stress oxydant. `annales.py` existe, ses listes
sont vides.

## Réaligné sur le cours de l'année (28/09/2026)

Chaque note a été relue contre les ronéos 2026-27, texte et figures. Une note
vérifiée porte la page où sa réponse se lit (`page`, et `fiche` quand ce n'est
pas la partie 1) : sa source devient ce ronéo à cette page. Une note que
l'année ne porte plus garde le ronéo 2024-25 pour source, porte le tag
`absent-2026` et le dit en tête de son explication. **Aucune note n'a été
retirée, aucun identifiant ni aucun type n'a changé** ; 36 notes sont nouvelles.

| Source citée | Notes |
|---|---|
| Stress oxydant 2026-27, partie 1 | 58 |
| Stress oxydant 2026-27, partie 2 | 33 |
| Métabolisme général cellulaire 2 (Pr Pigny) | 25 |
| Métabolisme général cellulaire 1 (Pr Pigny) | 7 |
| Insuline 2 (Pr Pigny) | 1 |
| Ronéo 2024-25, absentes du cours 2026-27 | 30 |

### La FC n°3 de 2024-25 était deux cours

Le ronéo 2024-25 portait en en-tête « Pr Pigny », en page de garde « Pr
Dessein », et disait reprendre le cours de l'année précédente du Pr Dessein —
d'où l'ancien chapitre, qui ne nommait personne. La lecture des ronéos 2026-27
tranche : ses parties I à III (cycle de Krebs amphibolique et anaplérose,
charge énergétique et AMPK, oncométabolisme) sont la fin du cours du **Pr
Pigny**, et elles sont en 2026-27 dans ses ronéos de métabolisme général
cellulaire ; les parties IV et V sont le cours du **Pr Dessein**, qui en
2026-27 est entièrement nouveau dans sa forme.

Les cartes des parties I à III restent dans ce chapitre (leurs identifiants ne
bougent pas) et citent le ronéo du Pr Pigny à sa page. Elles ne sont **pas**
marquées absentes : leur contenu est au programme de l'année, seulement dans un
autre cours. Le chapitre « Métabolisme général cellulaire » porte les mêmes
notions ; les réviser deux fois est le prix de ne pas toucher aux identifiants.

### Ce qui a changé dans le cours, et ce que les cartes en font

| Point | 2024-25 | 2026-27 | Cartes |
|---|---|---|---|
| Plan | Krebs, AMPK, Warburg, puis ROS et biomarqueurs | l'oxygène, la chaîne, les ROS, les défenses, le stress oxydant, cinq familles de pathologies, l'hormèse | 36 notes nouvelles |
| L'oxygène (p. 2-3) | — | 6 électrons de valence, biradical, accepteur ; 80 % énergétique / 20 % non énergétique ; réduction tétravalente au complexe IV | `sox-fa-09` réécrite ; `sox-fa-29`, `sox-co-oxygene`, `sox-rv-67` |
| L'énergie de la chaîne (p. 4-5) | ΔG0 < 0 exergonique | deux parties (oxydoréduction, phosphorylation) ; −0,32 / +0,82 V, 1,14 V, −220 kJ/mol, 20 kJ par proton, 10 protons, ΔΨ, Fo et F1 | `sox-fa-11` réécrite ; `sox-co-oxphos`, `sox-qr-24` |
| Ce qui majore les ROS (p. 6-7) | cyanure, effort du non-entraîné, excès de substrat | chaîne absente (cas théorique), blocage de la phosphorylation (oligomycine), excès d'oxygène (effort violent, oxygénothérapie hyperbare), excès de NADH | `sox-fa-13`, `sox-rv-50`, `sox-rv-62` réécrites ; `sox-fa-30`, `sox-co-problemes`, `sox-qr-23` |
| Nature des ROS (p. 8-10) | le radical hydroxyle « non chargé » diffuse | radicaux : demi-vie de la nano à la milliseconde, dégâts sur place ; non radicalaires : diffusent, franchissent les membranes, font des ROS secondaires ; trois ROS primaires | `sox-fa-15`, `sox-rv-37` à `-40`, `sox-qr-11` réécrites ; `sox-co-natures`, `sox-co-formation`, `sox-rv-66`, `sox-fa-31` |
| Fenton (p. 10) | Fe2+ ou Cu+, pH acide | métal réduit oxydé en Fe3+/Cu2+, non enzymatique, radical et anion hydroxyle | `sox-fa-16`, `sox-rv-40`, `sox-qr-14` réécrites |
| ROS secondaires (p. 10-12) | — | peroxynitrites, hydroperoxydes, acide hypochloreux (myéloperoxydase) ; rôles physiologiques | `sox-rv-35` réécrite ; `sox-fa-32`, `sox-co-secondaires`, `sox-qr-22` |
| Défenses enzymatiques (p. 12-14) | SOD (Cu, Mn ; cytosol, mitochondrie, périmembranaire), catalase, GPX « la plus importante », toutes au sélénium | SOD de première ligne, dismutation en deux temps, isoformes (Cu : SOD1, SOD3, qui portent aussi du zinc ; Mn : SOD2 matricielle) ; catalase peroxysomale ; GPX ; glutathion Glu-Cys-Gly ; **glutathion réductase** | `sox-fa-17`, `sox-rv-41` à `-43`, `sox-qr-12`, `-13`, `-21` réécrites ; `sox-co-enzymes`, `sox-rv-63`, `-64`, `sox-qr-25` |
| Défenses non enzymatiques (partie 2, p. 2-3) | chélateurs (dont l'albumine), vitamines C hydrophile et E | cofacteurs ; cycle vitamine E / vitamine C ; ferritine, transferrine, lactoferrine, hémopexine, céruloplasmine, **métallothionéines** ; **N-acétylcystéine** | `sox-fa-18`, `-19`, `-25`, `sox-rv-44` à `-46`, `-56`, `sox-qr-18` réécrites ; `sox-co-non-enzymatique`, `sox-qr-26`, `-27` |
| Stress oxydant (partie 2, p. 3-4) | déséquilibre ; diabète, arthrose, Alzheimer, obésité | déséquilibre, par surproduction ou défaut des défenses ; situations à risque ; cinq familles | `sox-fa-20`, `sox-rv-47`, `-48` réécrites ; `sox-fa-34`, `sox-co-situations`, `sox-rv-68` |
| Pathologies (partie 2, p. 4-8) | athérosclérose, iatrogénie | vieillissement, cardiovasculaire (LDL oxydées, NO), cancer (deux visages), neurodégénérescence, métabolique (AGE-RAGE) | `sox-fa-21`, `-24`, `sox-rv-49`, `-54`, `-55` réécrites ; `sox-fa-33`, cinq QCM, `sox-rv-69`, `-70`, `sox-qr-28` |
| Hormèse (partie 2, p. 9-10) | — | petite dose bénéfique, forte dose néfaste ; mitohormèse | `sox-co-hormese`, `sox-rv-65` |
| Biomarqueurs | MDA, isoprostanes, 8-OH-dG, sonde | absents | voir « Absent du cours 2026-27 » |

## Les ATTENTION de ce chapitre

Les ronéos 2026-27 ne seront pas corrigés ; aucun tableau d'erreurs BMCP
n'existe encore. Les erreurs et les contradictions sont donc portées par les
cartes, là où elles se jouent, et par `contenu/ERRATA_RONEOS_2026-27.md`. À
l'examen, on répond d'abord comme le professeur (règle de Vincent, 28/09) :
chaque erreur du ronéo 2026-27 a été triée, preuves à l'appui, entre une prise
de notes fausse (ce tableau), le cours lui-même (le tableau « C'est le cours
lui-même ») et le point douteux.

| Carte | Ce qui se contredit | Retenu | Source |
|---|---|---|---|
| `sox-fa-05`, `sox-rv-11`, `sox-qr-03` | la charge énergétique sans ½ devant l'ADP (2024-25 p. 4, et ces trois cartes) | (ATP + ½ ADP) / (ATP + ADP + AMP), la figure 2026-27 | Métabolisme général cellulaire 2, p. 3 ; Atkinson, Biochemistry 1968 |
| `sox-fa-15`, `sox-rv-39`, `sox-qr-11`, `sox-co-quizz5` (A) | le radical hydroxyle « non chargé » qui diffuse (2024-25 p. 11) ; « membrane permeable » sur la figure 2026-27 p. 10 | il réagit sur place : demi-vie de la nano à la milliseconde, pas de diffusion à distance (2026-27 p. 9 ; partie 2, p. 9) | Halliwell et Gutteridge, Free Radicals in Biology and Medicine, 2015 |
| `sox-fa-11`, `sox-rv-33` | « réaction exothermique » pour les −220 kJ/mol (2026-27 p. 5) | exergonique : c'est ΔG, pas ΔH | IUPAC, Gold Book ; le 2024-25 disait « exergonique » (p. 9) |
| `sox-fa-13` | « une fuite de protons par des protéines découplantes » arrêterait la chaîne et ferait des ROS (2026-27 p. 7) | un découplant accélère la chaîne et diminue le superoxyde ; retenu : l'inhibition de l'ATP synthase (oligomycine) | Korshunov, Skulachev et Starkov, FEBS Lett 1997 ; Brand et coll., Free Radic Biol Med 2004 |
| `sox-co-oxphos` (explication) | le canal Fo, « seul moyen » de retour des protons (2026-27 p. 5), contre la fuite par les protéines découplantes (p. 7 du même ronéo) | le Fo est la voie qui fait de l'ATP, pas la seule | ronéo 2026-27 p. 7 |
| `sox-fa-24`, `sox-rv-54` | radiothérapie « non ciblée », qui touche les cellules voisines (2024-25 p. 14) ; « dirigée spécifiquement sur la tumeur », effet local (2026-27, partie 2, p. 6) | le 2026-27 : local, limité au champ, où les tissus sains sont touchés aussi | — |
| `sox-rv-18` | l'autophagie, « mécanisme d'endocytose » (Métabolisme général cellulaire 2, p. 3) | l'autophagie dégrade du matériel intracellulaire ; l'endocytose fait entrer du matériel extérieur | Mizushima et Komatsu, Cell 2011 |
| `sox-rv-06` | la pyruvate carboxylase ferait passer « d'un dérivé à 4 atomes de carbone » à l'oxaloacétate (Métabolisme général cellulaire 1, p. 4) | le pyruvate a 3 carbones | La cellule, un carrefour du métabolisme, p. 8 |
| `sox-fa-07` | les cellules tumorales utilisent peu le cycle de Krebs « pour synthétiser le glucose » (Métabolisme général cellulaire 2, p. 4) | pour oxyder le glucose : le cycle de Krebs n'en synthétise pas | Métabolisme général cellulaire 1, p. 2-4 |
| `sox-co-quizz1` (C) | la formation des corps cétoniques « empêche la libération de protons » (Métabolisme général cellulaire 1, p. 8) | l'acétoacétate et le bêta-hydroxybutyrate sont des acides qui libèrent leurs protons : d'où l'acidose | correction 2024-25, p. 16 ; Laffel, Diabetes Metab Res Rev 1999 |
| `sox-co-quizz4` (D), `sox-rv-26`, `sox-rv-31`, zone `cx1` | le complexe I « NADH oxydase » (2024-25 p. 8) | NADH déshydrogénase (figure 2026-27 p. 11) | — |
| `sox-rv-29` | la réduction tétravalente « se fait avec libération d'eau et d'ATP » (2026-27 p. 3) | elle donne l'eau ; l'ATP vient du complexe V | ronéo 2026-27 p. 4-5 ; Métabolisme général cellulaire 2, p. 2 |
| `sox-rv-26` | « les coenzymes réduisent le NADH et le FADH2 » (Métabolisme général cellulaire 2, p. 2) | NADH et FADH2 sont les coenzymes réduits, que les complexes I et II réoxydent | ronéo stress oxydant 2026-27 p. 5 |
| `sox-rv-21` | la voie des pentoses phosphates « synthétise du ribose, des acides aminés, des acides gras, des acides nucléiques » (Métabolisme général cellulaire 2, p. 4) | elle fournit le ribose-5-phosphate et le NADPH2, qui sert à la synthèse des acides gras ; elle ne fait pas d'acides aminés | La cellule, un carrefour du métabolisme, p. 9 ; Patra et Hay, Trends Biochem Sci 2014 |

**C'est le cours lui-même** : la formule vient de la Pr Dessein — sa
diapositive, ou son cours des années précédentes —, et le ronéo la rapporte
fidèlement. La carte répond comme elle, et son `ATTENTION` dit, dans l'ordre,
« c'est le cours lui-même » et d'où vient la formule, « À l'examen : » ce
qu'on répond, puis « La référence : » le fait juste et sa source.

| Carte | Ce qui est écrit | D'où vient la formule | À l'examen | La référence |
|---|---|---|---|---|
| `sox-fa-17`, `sox-rv-43`, `sox-qr-13` | la GPX « sélénoenzyme avec 8 isoformes » (2026-27 p. 13, en gris) | le cours de la Pr Dessein, repris par la fiche 2024-25 : plusieurs formes de GPX « qui contiennent toutes du sélénium » (p. 12) ; le texte 2026-27 fait intervenir le sélénium (p. 14), la diapositive p. 12 le range parmi les défenses | la GPX est la sélénoenzyme du cours : vrai à « sélénoenzyme », « fait intervenir le sélénium », « toutes les isoformes » ; le verso de `sox-rv-43` dit « sélénoenzyme ». La question de `sox-qr-13` ne dit plus « toutes » | cinq des huit GPX humaines sont des sélénoprotéines, une nuance hors cours (Brigelius-Flohé et Maiorino, Biochim Biophys Acta 2013) |
| `sox-co-cardio` (B) | « NADH oxydases (NOX) » sur la diapositive des compartiments (partie 1, p. 11) | la diapositive de la Pr Dessein, montrée sans être développée, reproduite telle quelle | NADPH oxydases, comme le dit la partie 2 du même cours (p. 5 et 8) ; ne pas reprendre « NADH oxydases » | Bedard et Krause, Physiol Rev 2007 |

Les points douteux, signalés par « ATTENTION — point douteux » (ou « ATTENTION,
point douteux ») ou dans l'explication, sans trancher :

| Carte | Ce que dit le ronéo 2026-27 | Le doute | Source |
|---|---|---|---|
| `sox-co-secondaires` (B), `sox-fa-32`, `sox-qr-22` | la myéloperoxydase « avec un atome de chlore » (p. 11) | c'est la lecture littérale du schéma de la professeure, « Cl → MPO → HOCl », sans charge alors que les autres ions ont la leur ; « Cl » peut n'être qu'un raccourci, et l'oral n'est pas connu : on ne peut pas dire de qui vient l'imprécision. Retenu : l'ion chlorure, Cl−, qui est sûr ; la proposition B, qui ne dit ni atome ni ion, reste vraie | Klebanoff, J Leukoc Biol 2005 |
| `sox-fa-19`, `sox-rv-45` | la vitamine C « régénère le glutathion » (partie 2, p. 2) | dans le schéma classique, c'est le glutathion qui régénère la vitamine C, et la glutathion réductase (NADPH) le glutathion | Meister, J Biol Chem 1994 |
| `sox-rv-23` | le 2-désoxy-glucose « bloque le passage de glucose à travers la membrane » (Métabolisme général cellulaire 2, p. 4) | il entre par les transporteurs, et c'est le 2-désoxy-glucose-6-phosphate qui bloque la glycolyse | Pajak et coll., Int J Mol Sci 2020 |
| `sox-fa-21` | la NOX oxyde « les LDL circulantes » (partie 2, p. 5) | l'oxydation se fait surtout dans l'intima, où les LDL sont retenues | Steinberg et Witztum, Arterioscler Thromb Vasc Biol 2010 |
| `sox-co-secondaires` (C), `sox-fa-32`, `sox-qr-22` | l'acide hypochloreux « formé dans les lysosomes du macrophage » (p. 11) | la MPO est surtout celle des neutrophiles et des monocytes ; la proposition C ne nomme pas la cellule et reste vraie | Klebanoff, J Leukoc Biol 2005 |
| `sox-fa-15` | radicaux « sans diffusion à distance » (p. 9), radical hydroxyle « membrane permeable » (figure p. 10) | les deux se concilient : neutre, il pourrait traverser, mais il réagit sur place | Halliwell et Gutteridge, 2015 |

Et une phrase ambiguë, qui n'est pas une erreur : après la réaction de Fenton,
« se sont les 3 ROS primaires » semble compter l'anion hydroxyle (p. 10) ; les
trois sont le superoxyde, le peroxyde d'hydrogène et le radical hydroxyle, et la
figure laisse l'ion hydroxyde hors de l'accolade — dit dans `sox-rv-66`.

## La clé du QUIZZ 3, qui n'est pas reprise

Le ronéo 2024-25 cote FAUSSE la proposition « dans une cellule cancéreuse,
l'entrée du pyruvate dans le cycle de Krebs est réduite », au motif qu'elle
serait *augmentée* pour produire plus d'ATP. C'est l'inverse du corps du même
cours (« la cellule cancéreuse utilise très peu le cycle de Krebs », p. 6), et
la clé imprimée nie la proposition A de sa propre question. **Le cours 2026-27
tranche dans le même sens** : les cellules tumorales « utilisent très peu le
cycle de Krebs » (Métabolisme général cellulaire 2, p. 4).

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| QUIZZ 3 (`sox-co-quizz3`), proposition C | AD | **ACD**, `cle_officielle: false` | le corps du cours 2024-25 et le cours 2026-27 ; l'errata 2024-25 relève le point, colonne « avis bureau » vide |

Si l'item retombe, répondre selon la physiologie et signaler l'ambiguïté.

## Absent du cours 2026-27

Ces trente cartes sont **gardées telles quelles** — question, réponse — parce que
rien dans les ronéos 2026-27 ne les contredit ; leur explication dit en tête
d'où vient leur contenu. Elles ont été cherchées dans les deux ronéos du Pr
Dessein **et** dans ceux du Pr Pigny, où la partie I à III de l'ancienne FC a
migré. À Vincent de décider s'il les garde.

| Cartes | Ce qui est absent | Ce que le 2026-27 en dit |
|---|---|---|
| `sox-fa-03`, `sox-rv-08`, `sox-rv-09`, `sox-rv-10`, `sox-qr-01`, `sox-qr-02`, `sox-qr-20` | l'anaplérose ; la glutamine, acide aminé le plus concentré du sang, qui entre par la glutaminase au niveau de l'alpha-cétoglutarate | la glutamine « se branche » sur le cycle de Krebs, les tumeurs en sont avides, on inhibe la glutaminase (Métabolisme général cellulaire 2, p. 4) |
| `sox-rv-03`, `sox-rv-04`, `sox-rv-05` | les couples oxaloacétate–aspartate, alpha-cétoglutarate–acide glutamique ; les transaminases dosées pour le foie | aspartate, alanine et glutamate glucoformateurs (Métabolisme général cellulaire 1, p. 9) |
| `sox-fa-04`, `sox-rv-13` | les quatre critères d'activité d'une voie ; les trois compartiments de la néoglucogenèse | la charge énergétique (MGC 2, p. 3), la LDH (MGC 1, p. 5), les navettes mitochondrie-cytosol (MGC 1, p. 2-4) |
| `sox-qr-05` | mTOR, inhibée par l'AMPK | l'AMPK inhibe les voies anaboliques (MGC 2, p. 3) |
| `sox-fa-22`, `sox-rv-51`, `sox-rv-53` | les mutations des complexes I et III ; le régime méditerranéen (flavonoïdes, acides gras polyinsaturés, resvératrol) | suralimentation, sport régulier (partie 2, p. 3) ; déficit en complexe I (partie 2, p. 7) |
| `sox-fa-23`, `sox-rv-52`, `sox-qr-15` | NRF2, libéré par les polyphénols | Nrf2 surexprimé par certaines tumeurs (figure, partie 2, p. 7) |
| `sox-fa-26`, `sox-fa-27`, `sox-fa-28`, `sox-rv-57` à `sox-rv-61`, `sox-qr-16`, `sox-qr-17`, `sox-qr-19` | les biomarqueurs : sonde, MDA, isoprostanes, 8-OH-dGuanine, antioxydants érythrocytaires | la demi-vie des radicaux (partie 1, p. 9) ; la peroxydation lipidique parmi les effets néfastes (figure p. 12) |

Détails de 2024-25 gardés dans des cartes par ailleurs vérifiées, et dits dans
leur explication : « amphibolique » et les transaminases (`sox-fa-01`), le
rétrocontrôle du lactate et l'acide glutamique second métabolite (`sox-fa-07`,
`sox-rv-20`), « homéostasie énergétique » (`sox-fa-05`), mTOR et le jeûne
(`sox-fa-06`, `sox-rv-16`), « multimoléculaires » et le cyanure sur le complexe
IV (`sox-fa-10`, `sox-rv-32`, `sox-qr-09`), « l'ATP synthase donne le tempo »
(`sox-fa-12`, `sox-rv-36`), « difficiles à doser » (`sox-fa-14`), le pH acide
de Fenton (`sox-fa-16`, `sox-rv-40`), l'albumine (`sox-fa-18`, `sox-rv-44`), la
GPX « la plus importante » (`sox-co-quizz5` B, sa clé), les essais de vitamine
C chez le patient cancéreux (`sox-fa-25`, `sox-rv-56`), les rats entraînés
(`sox-rv-62`).

## Les figures du ronéo

Dix-sept figures des ronéos 2026-27, extraites en PNG avec leur page
(`IMAGES`), illustrent les corrections, jamais les questions : 18 QCM sur 20
sont illustrés, 44 notes sur 154.

| Fichier | Page |
|---|---|
| `dioxygene.png` | partie 1, p. 3 |
| `oxphos-deux-parties.png` | partie 1, p. 4 |
| `couplage-engrenages.png` | partie 1, p. 6 |
| `reduction-monovalente.png` | partie 1, p. 8 |
| `cascade-fenton.png` | partie 1, p. 10 (Munro et Treberg, J Exp Biol 2017) |
| `ros-secondaires.png` | partie 1, p. 11 |
| `ros-deux-visages.png`, `defenses-deux-systemes.png` | partie 1, p. 12 |
| `sod-dismutation.png` | partie 1, p. 13 |
| `vieillissement.png` | partie 2, p. 5 |
| `cardiovasculaire.png` | partie 2, p. 6 |
| `cancer-deux-visages.png` | partie 2, p. 7 |
| `neurodegeneration.png`, `metabolique-age-rage.png` | partie 2, p. 8 |
| `synthese-pathologies.png` | partie 2, p. 9 |
| `charge-energetique.png`, `oncometabolisme.png` | Métabolisme général cellulaire 2, p. 3 |

## Les deux schémas cliquables

* `chaine-respiratoire.svg` — les cinq complexes dans l'ordre, le gradient de
  protons, et **les deux sièges de la fuite d'électrons**, I et III, à 1 % au
  repos. Le complexe I y est la NADH déshydrogénase ; le complexe II est la
  succinate déshydrogénase du cycle de Krebs, et l'ATP se fait au complexe V,
  jamais au IV.
* `ros-cascade.svg` — de l'oxygène à l'eau : superoxyde, SOD, peroxyde
  d'hydrogène, puis catalase ou glutathion peroxydase. Et la bifurcation de
  Fenton, **seule branche sans issue** : aucune enzyme ne neutralise le radical
  hydroxyle. Les zones catalase et GPX se distinguaient par « fortes » et «
  faibles » concentrations, un critère qu'aucun des deux cours ne donne ; elles
  se reconnaissent maintenant par le peroxysome et par le glutathion.

## Deux défauts du ronéo 2024-25, conservés et signalés

* **Une proposition en double.** Les QUIZZ 1 et 3 posent le même item mot pour
  mot — « la glutamine réalimente le cycle de Krebs au niveau de
  l'oxaloacétate », faux, c'est l'alpha-cétoglutarate. Les deux questions sont
  gardées, le doublon est dit.
* **« Spectrophotométrie de masse »** (p. 15) : la technique est la
  spectrométrie de masse, que les cartes gardent (`sox-fa-27`, `sox-rv-59`,
  `sox-qr-16`).

## À relire : 0 carte

Les 35 cartes qu'un audit avait taguées `a-relire` ont été tranchées une à une
pendant le réalignement : relues contre une page d'un ronéo 2026-27, ou du
ronéo 2024-25 pour les absentes. Ce que l'audit reprochait et qui a été corrigé :
la formule de la charge énergétique (le ½ ADP), le nom du complexe I, le « 1 % »
devenu tapable (`sox-fa-12`), le trou « roue » (`sox-fa-13`), « margarine » et
« cassis » (`sox-fa-19`), « soignant » (`sox-fa-24`), le trou qui se donnait sa
réponse (`sox-fa-15`, `sox-fa-17`), « pro- oxydante » (`sox-fa-25`), les réponses
exactes trop longues ou trop courtes (`sox-qr-04`, `-05`, `-06`, `-18`), les
acceptables manquants (`sox-qr-17`, `-21`), le critère hors cours de la cascade.

Changer le contenu d'un trou ne renumérote rien : la carte d'un trou est
attachée à son rang, pas à son texte. « trois » (`sox-fa-04`) et « cinq »
(`sox-fa-10`) sont donc devenus « 3 » et « 5 », qui se tapent. Restent tels
quels, parce que c'est l'écriture du ronéo : « 0,8-0,9 » dans `sox-fa-05`
(« 0.8-0.9 » est accepté aussi ; `sox-qr-03` accepte les deux formes) et
« 8-OH-dGuanine » dans `sox-fa-28` (absente). Le tag `a-relire` se remet sur une
carte dont on doute.

## Relecture critique (28/09/2026)

Une seconde lecture, carte par carte, contre les pages citées et des sources
de référence, a corrigé :

* `sox-co-problemes` E : le distracteur « une dépense énergétique élevée chez
  un sujet bien nourri » contredisait la proposition B (un effort violent est
  une dépense élevée, et il majore les ROS). Remplacé par « un entraînement
  sportif régulier et non excessif », faux selon le cours (p. 7 ; partie 2,
  p. 3).
* `sox-fa-16` : la réécriture était passée de sept trous à six, ce qui aurait
  détaché la septième carte ; un septième trou est rendu (Fe3+).
* La SOD : SOD1 et SOD3 portent du zinc en plus du cuivre (`sox-fa-17`,
  `sox-rv-41`, `sox-qr-12`, `sox-co-enzymes` B) ; « la SOD contient du zinc »
  est vrai.
* `sox-rv-21` : la voie des pentoses phosphates ne fait ni acides aminés ni
  acides gras (erreur de Métabolisme général cellulaire 2, p. 4, que la carte
  avait reprise) : ribose-5-phosphate et NADPH2.
* Trois ATTENTION de plus (`sox-rv-29`, `sox-rv-26`, `sox-rv-21`) et trois
  points douteux (`sox-rv-23`, `sox-fa-21`, `sox-fa-19`), dans les tableaux
  ci-dessus.
* Zone `fuite3` du schéma de la chaîne : les situations qui majorent la fuite
  sont celles du cours 2026-27, plus le cyanure de 2024-25.

## Régénérer

```
python generer.py
```

Le générateur de ce chapitre n'est pas le modèle du skill : il a gagné, comme
ceux des chapitres `sang_*`, la page du ronéo de l'année (`page`, `fiche`),
`ABSENTS_2026` et `ORIGINE_ABSENTS`, et les images à trois éléments. Il refuse
d'écrire sur une page hors de son document, une fiche non déclarée, ou une carte
absente qui citerait une fiche de l'année.
