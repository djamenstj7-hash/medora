# Littérature et médecine — paquet SSH

123 notes, 211 cartes. Chapitre `chap-ue-ssh-litterature` de l'UE SSH (examen
écrit du 6 janvier 2027). **Base : la ronéo Ronéo & Juliette 2026-27
« Littérature 1 »** (14 pages) : cours du 28/09/2026, 11 h-12 h, **Pr
Aubert-Baillot**, sur **« Le Lambeau »** de Philippe Lançon (2018), le livre de
l'année. Réaligné sur elle le 11/10/2026. C'est la **première partie** du cours :
la suite n'est pas encore parue.

**18/10/2026** : 1 recto-verso du sujet de SSH 2025/2026 (examen du
09/01/2026, sans corrigé) — QR ; voir « Le sujet 2025/2026 ».

Le chapitre était carté depuis le 02/10 sur le cours du **Pr Sabot** de 2025-26
(Ronéosaure, FC n°8 et n°9, sur « Réparer les vivants »). Ce cours reste
l'appoint : ce que la ronéo 2026-27 ne traite pas encore y garde ses cartes, avec
le badge « Cours 2025-26 ». Une annale : la QR du sujet de SSH 2024/2025, sur le
livre de cette année-là, « Cytomégalovirus » d'Hervé Guibert (déposé le 15/10/2026).

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 26 | 26 |
| QRU | 3 | 3 |
| Texte à trous | 21 | 100 |
| QROC | 36 | 36 |
| Recto-verso | 18 | 18 |
| Schéma cliquable | 3 | 12 |
| Lexique | 16 | 16 |
| **Total** | **123** | **211** |

L'examen de SSH est rédactionnel (« 10 QROC + 1 QR ») : le chapitre est surtout
fait de QROC, de textes à trous et de recto-verso ; les QCM portent les pièges,
avec une justification par proposition. **27 QCM sur 29 sont illustrés**
(93 %), 89 notes sur 123.

| | Notes |
|---|---|
| citent la ronéo 2026-27 (tag `cours-2026-27`, sans badge) | **42** : 41 nouvelles, 1 relue |
| gardent le cours 2025-26 (tag `cours-2025-26`, badge « Cours 2025-26 ») | 63 |
| dont **absentes du cours 2026-27** (`absent-2026`) | 12 |
| dont **en attente des ronéos suivantes** | 51 |
| lexique | 16 (7 nouveaux) |
| portent un piège de la ronéo 2026-27 (thème « Pièges des ronéos ») | 8 |

Huit thèmes. Les trois premiers sont **nouveaux** : leurs libellés sont à
ajouter à `THEME_LABELS` (`app/src/med_engine/application/scopes.py`, bloc
« ssh ») ; les cinq autres y sont déjà.

| Clé | Libellé | Notes | Dont 2026-27 |
|---|---|---|---|
| `le-lambeau` | Le Lambeau, de Philippe Lançon | 12 | 12 |
| `medecine-narrative` | La médecine narrative | 17 | 5 (et 12 absentes) |
| `cinq-caracteristiques` | Médecine et littérature : cinq caractéristiques communes | 18 | 18 |
| `competences-narratives` | Les compétences narratives du médecin | 7 | 7 |
| `litterature-ethique` | Littérature, médecine et éthique | 19 (dont l'annale) | — |
| `recitherapie` | Biographies hospitalières et récithérapie | 9 | — |
| `imagination-morale` | Imagination morale et imagination clinique | 9 | — |
| `transplantation-ethique` | Mort, don et corps : l'éthique de la transplantation | 15 | — |

(Comptes hors lexique ; les 16 termes ont le seul tag `lexique`.)

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-ssh-litterature-2627-1` — « Littérature 1 » (14 p.), `SSH/LITTÉRATURE 1.pdf` | **2026-27** | **la base** (`SRC["fiche"]`, `chapitre=`) : ce que le lecteur ouvre ; présentation du Lambeau et de son genre (p. 2-3), la médecine narrative (p. 4-12), la victime, la suture, l'intertextualité (p. 12-14) |
| `src-fc-ssh-litterature-1` — « FC n°8 littérature et médecine .pdf » (7 p.), `SSH/…` | 2025-26 | appoint (`SRC["cours"]`, `fiche=F1`), sans `chapitre=` ; source des 10 cartes absentes |
| `src-fc-ssh-litterature-2` — « FC n°9 Littérature et médecine.pdf » (8 p.), `SSH/…` | 2025-26 | appoint (`fiche=F2`), sans `chapitre=` |
| `src-sujets-ssh-2425` — « Sujets de SSH 2024/2025, session 1 » (examen du 10/01/2025, 1 QR et 10 QROC, sans corrigé), déposés le 15/10/2026 | 2024-25 | la source de la session 2024/2025 S1 et `SRC["annales"]` : la QR ; déclarée à l'identique dans tous les chapitres de SSH qui en cartent une question |
| `src-cours-ssh-cytomegalovirus-2425` — Ronéosaure, « FC n°15 (AC) - Cytomégalovirus », Pr Devinant (8 p.) | 2024-25 | appoint : le cours sur le livre de 2024-25 ; les deux sens de la dignité et de l'autonomie (p. 7), chaque passage que cite l'annale (p. 5-8) ; source du schéma `dignite-autonomie.svg` |
| `src-ed-ssh-consentement-2526` — Ronéosaure, « ED SSH N°2 », consentement et décision médicale partagée, Pr Devinant (4 p.), `ED/SSH/…` | 2025-26 | appoint, cité dans le texte de l'annale (p. 2, 4) ; déclaré à l'identique dans `ssh_droits_malades` |
| tableau d'erreurs SSH de la promo 2026-27 | 2026-27 | **rien sur ce cours** au 11/10/2026 (une seule entrée, sur l'histoire de la médecine) |
| `Erratas SSH.docx` (cours 2025-26) | — | une entrée sur ce cours : « enjeux épiques » pour éthiques (FC n°9, p. 6), sans effet sur une carte |

Une carte relue sur la ronéo de l'année cite « ronéo 2026-27, p. 5 » ; une carte
du cours 2025-26 cite « p. 5 » (FC n°8) ou « partie 2, p. 5 » (FC n°9). Le nom du
PDF de l'année est en NFC sur le disque. La fiche se copie dans le dossier des PDF
de l'application par `outils/copier_les_cours.py`, lancé avec le dossier des ronéos
2026-27, hors du bac à sable.

L'en-tête de la ronéo nomme ses rédacteurs et son correcteur : aucun nom n'est repris.

## Le réalignement du 11/10/2026

**Un autre professeur, un autre livre.** Le cours 2025-26 du Pr Sabot était bâti
sur « Réparer les vivants » (Maylis de Kerangal) ; celui du Pr Aubert-Baillot l'est
sur « Le Lambeau ». La première séance 2026-27 couvre, dans l'ordre :

| Ronéo 2026-27 | Ce qui y correspond en 2025-26 |
|---|---|
| I. Le Lambeau : présentation, genre (p. 2-3) | — (nouveau ; l'intrigue de « Réparer les vivants » n'avait pas été cartée) |
| II.A Principe de la médecine narrative (p. 4) | FC n°8, II.B : Rita Charon, Narrative Medicine (2006), sa définition |
| II.B L'entretien patient-médecin (p. 4) | FC n°8, II.B : l'EBM et ses limites, l'écoute |
| II.C Les cinq caractéristiques communes (p. 5-10) | — (nouveau) |
| II.D Les trois compétences narratives (p. 10-12) | FC n°8, II.B : les trois pratiques (anamnèse narrative, journal réflexif, lecture) |
| III.A Une pratique récente (p. 12) | — |
| III.B-E Victime, suture, intertextualité (p. 12-14) | — (nouveau) |

La médecine narrative, que la ronéo traite **en entier** (p. 4-12), y est
présentée autrement : le principe, cinq caractéristiques et trois compétences
remplacent la définition de 2006, la critique de l'EBM, les trois pratiques et les
douze secondes. Ces cartes-là sont **absentes du cours 2026-27**. Le reste du cours
2025-26 (la médecine de précision, les médecins écrivains, les biographies
hospitalières, l'imagination morale, l'éthique de la transplantation) n'est pas
traité par cette première séance : ses cartes sont **en attente**.

**Relue et confirmée (1)**, qui cite désormais la ronéo 2026-27 :

| Carte | Page | Ce qui a changé |
|---|---|---|
| `litt-qr-charon` | p. 4 | la question demande à qui l'on doit le concept (non plus qui a publié en 2006) ; la réponse donne le portrait du cours 2026-27 (docteur en littérature et en médecine, interniste, Columbia) ; la réponse attendue ne change pas |

**Relues et laissées au cours 2025-26 (2)**, à la relecture du 11/10 :

| Carte | Pourquoi elle reste sur la FC n°8 | Ce qu'elle gagne |
|---|---|---|
| `litt-qc-narrative` | quatre propositions sur cinq ne sont que dans le cours 2025-26 : le livre de 2006 (A), la définition (B), la critique de l'EBM (C, E) ; ce sont les notions de `litt-fa-charon` et de `litt-qc-apports`, absentes. Confirmée sur la ronéo, elle aurait perdu le badge en interrogeant sur ce que le cours de l'année ne dit pas | **absente** ; propositions et clé inchangées (ABDE) ; chaque justification dit ce que la ronéo 2026-27 en dit (p. 4, 6, 12) |
| `litt-qc-attention` | « quelle pratique développe l'attention narrative ? » (la lecture) porte sur les trois pratiques de 2025-26, comme `litt-fa-pratiques`, absente ; en 2026-27, lire **et** écrire travaillent l'attention (p. 10) | **absente**, énoncé, propositions et clé de 2025-26 (C) ; B et l'explication disent ce qu'en dit la ronéo 2026-27 |

Une première version de la relecture avait réécrit `litt-qc-attention` sur les trois
compétences, sous le même identifiant : une note réécrite garde ses révisions et son
échéance (`app/CLAUDE.md`), et une question jamais vue serait arrivée avec l'intervalle
d'une autre. La question des trois compétences est donc une carte nouvelle,
`litt-qc-trois-competences`.

**Notes nouvelles (48)**, sur ce que la ronéo 2026-27 apporte :

| Thème | Notes |
|---|---|
| `le-lambeau` (12) | `litt-qc-lambeau`, `litt-fa-lambeau`, `litt-qr-nuit-des-rois`, `litt-qr-bertolus`, `litt-qc-genre`, `litt-rv-ecriture-vitale` (p. 2-3) ; `litt-qc-victime`, `litt-fa-victime` (p. 12-13) ; `litt-qc-suture`, `litt-qr-intertextualite`, `litt-rv-trois-oeuvres`, `litt-rv-suture` (p. 13-14) |
| `medecine-narrative` (4) | `litt-fa-principe`, `litt-qc-entretien`, `litt-qr-mise-en-intrigue` (p. 4) ; `litt-qr-annees-1990` (p. 12) |
| `cinq-caracteristiques` (18) | `litt-fa-cinq`, `litt-qc-cinq` (p. 5) ; la temporalité : `litt-fa-temporalite`, `litt-qc-temporalite`, `litt-qr-objet-transitionnel` (p. 5-6) ; la singularité : `litt-fa-singularite`, `litt-qc-singularite`, `litt-rv-relation-therapeutique` (p. 6-7) ; causalité et contingence : `litt-qc-causalite`, `litt-qr-contingence` (p. 7) ; l'intersubjectivité : `litt-qc-intersubjectivite`, `litt-qr-textualite`, `litt-qr-bivalente` (p. 8) ; l'éthique : `litt-qc-ethique-narrative`, `litt-qr-fiction` (p. 8-9), `litt-qc-connais-toi`, `litt-qr-gnothi`, `litt-rv-connaissance-soi` (p. 9-10) |
| `competences-narratives` (7) | `litt-fa-competences`, `litt-qc-competences`, `litt-qc-trois-competences` (QRU), `litt-zo-competences` (p. 10-12) ; `litt-qr-solution-continuite`, `litt-rv-representation` (p. 11) ; `litt-qr-affiliation` (p. 12) |
| lexique (7) | `lex-intersubjectivite`, `lex-intertextualite`, `lex-suture`, `lex-victime`, `lex-fiction`, `lex-solution-de-continuite`, `lex-affiliation` |

## Ce que le cours a dicté

- **Ni rouge ni gris** dans la ronéo 2026-27 : rien n'est annoncé hors programme.
  Le plan (p. 1) annonce trois notions en III (A-C) ; le texte en traite cinq
  (A-E, avec l'intertextualité et la suture des textes) : toutes sont cartées.
- **Deux listes que le cours sépare** et que les cartes font travailler l'une
  contre l'autre (`litt-qc-cinq`, `litt-qc-trois-competences`) : les **cinq
  caractéristiques communes** à la médecine et à la littérature (temporalité,
  singularité, causalité et contingence, intersubjectivité, éthique) et les
  **trois compétences narratives** du médecin (attention, représentation,
  affiliation). Ce sont les « narrative features of medicine » et les trois
  mouvements de Rita Charon (Narrative Medicine, 2006).
- **Le livre de l'année est carté** (thème `le-lambeau`), parce que le cours en
  fait sa matière : son auteur, son genre, les exemples qu'il donne (La Nuit des
  rois, le livre de jazz, Proust à chaque descente au bloc, les métaphores, les
  trois œuvres de la suture des textes). L'intrigue de « Réparer les vivants »
  n'avait pas été cartée en 2025-26 ; elle ne l'est toujours pas.
- **Ce qui appartient à d'autres chapitres n'est pas repris** : la causalité a son
  cours en épistémologie (`ssh_epistemologie`), et « Contingence » son terme de
  lexique dans `ssh_sida` ; `litt-qr-contingence` n'en carte que la définition du
  cours.
- **Vérifications hors du cours, citées dans la carte qui s'en sert** : la liste des
  lauréats du prix Renaudot et l'Encyclopædia Universalis (« Le Lambeau ») ;
  La Libre Belgique (23/04/2018, mis à jour le 05/11/2018 : douze mois d'hôpital,
  dix-sept opérations, un menton refait avec le péroné) ; l'entretien de Charline
  Bourgeois-Tacquet au CNC (2026) ; le TLFi (victime, fiction, suture, texte,
  solution, affiliation) ; Twelfth Night, IV, 1 ; Pausanias, X, 24, 1, et Platon,
  Phèdre, 229e ; EBSCO Research Starters, « Narrative medicine » ; Kidd et Castano
  (Science, 2013), Panero et al. (J Pers Soc Psychol, 2016) et Berns et al. (Brain
  Connectivity, 2013) ; OpenStax Microbiology, 19.3.

## Les annales

Aucun polycopié d'annales SSH du Ronéosaure 2024-25 n'interroge ce cours. Le
sujet de SSH 2024/2025 (session 1, déposé le 15/10/2026, sans corrigé) en apporte
une, dans `annales.py` : **la QR**, sur « Cytomégalovirus » d'Hervé Guibert, le
livre de 2024-25 — le consentement selon la décision médicale partagée y est-il
respecté ? deux passages ; les sens de « dignité » et d'« autonomie », un exemple
chacun. Le livre a changé (« Le Lambeau » en 2026-27) : le verso sépare **ce qui
reste au programme** (la décision partagée, les deux dignités, les deux
autonomies) de **ce qui tient au livre de 2024-25** (les passages et les
exemples), et dit que la même question porterait cette année sur Le Lambeau. La
carte n'est pas « absente » en entier : seule sa seconde moitié tient au livre.
Les passages sont ceux que cite le cours du Pr Devinant de 2024-25 (FC n°15,
p. 5-8), et eux seuls : aucun n'a été relu sur le livre, aucun n'est inventé.
Un schéma redessiné, `dignite-autonomie.svg`, illustre la correction.

Deux questions voisines sont ailleurs : la question rédactionnelle de 2023/2024
sur le « roman au programme » (Schnitzler, « Mourir ») dans `ssh_epistemologie`,
et celle de 2022/2023 S1 sur « Une mort très douce » (Beauvoir) dans
`ssh_donner_la_mort`. Le sujet d'examen pose une question sur le livre de
l'année — en 2022/2023, 2023/2024 et 2024/2025 : le thème `le-lambeau` la
prépare.

## Les schémas et les figures

La ronéo 2026-27 n'a qu'une image, le logo de l'équipe (p. 1). Tout est redessiné
dans `schemas.py`, et le dessin des zones lit les mêmes constantes que les zones.

| Fichier | Ce qu'on clique | Cartes |
|---|---|---|
| `competences-narratives-nu.svg` (`litt-zo-competences`, 2026-27) | l'attention, la représentation, l'affiliation, et l'action thérapeutique où elles culminent | 4 |
| `medecine-narrative-nu.svg` (`litt-zo-narrative`, 2025-26, **absente**) | l'EBM, l'anamnèse narrative, le journal réflexif, la lecture | 4 |
| `redefinition-mort-nu.svg` (`litt-zo-mort`, 2025-26) | l'arrêt cardiaque, le coma dépassé, la mort cérébrale, la greffe | 4 |

Onze figures nouvelles, légendées, du côté de la correction (page de la ronéo
2026-27) : la chronologie du Lambeau (p. 2-3) ; l'entre-deux du genre et le pacte
éthique du récit (p. 2-3, 8-9) ; les cinq caractéristiques (p. 4-12) ; les
compétences narratives (p. 10-12) ; le temps du médecin et celui du patient
(p. 5-6) ; la catégorie et la singularité (p. 4, 6-7) ; causalité et contingence
(p. 7) ; l'intersubjectivité (p. 8) ; « connais-toi toi-même » (p. 9-10) ; les
trois sens du mot victime (p. 12-13) ; la suture des tissus et celle des textes
(p. 13-14). Les huit figures du cours 2025-26 restent, sur leurs cartes. Une
vingtième, pour l'annale de 2024/2025 : les deux sens de la dignité et de
l'autonomie (`dignite-autonomie.svg`, d'après le cours de 2024-25 sur
Cytomégalovirus, p. 7, redit en 2025-26 et 2026-27).
**Les 14 QCM nouveaux sont tous illustrés** ; les deux QCM sans figure restent ceux
de 2025-26 (`litt-qc-medecins-ecrivains`, `litt-qc-consentement`).

## Les erreurs de la ronéo 2026-27

Le tableau d'erreurs SSH de la promo ne relève rien sur ce cours (11/10/2026).
Toutes ces erreurs ont été trouvées en relisant la ronéo ; chacune porte son genre,
juste après le mot ATTENTION, dans la carte qui la joue.

| Page | La ronéo dit | Ce qui est juste | Genre | Carte |
|---|---|---|---|---|
| 2 | Le Lambeau « a gagné le prix Renaudot » | Le prix Femina (5 novembre 2018), puis un « prix spécial » du jury Renaudot, le Femina le rendant inéligible au Renaudot ; le Renaudot 2018 est allé à Valérie Manteau (Le Sillon) — liste des lauréats du prix Renaudot ; Universalis | prise de notes | `litt-qc-lambeau` (A) |
| 5 | le temps du patient « relève d'un éternel permanent » | l'« éternel présent » de la douleur et de la maladie, comme la ronéo l'écrit elle-même p. 4 et à la fin de la p. 5 | prise de notes | `litt-fa-temporalite` |
| 13 | le sens tragique de « victime » apparaît « à partir du XVIIIe siècle », chez Racine et Corneille | le XVIIe siècle : Corneille (1606-1684), Racine (1639-1699), Phèdre (1677) ; le TLFi atteste « personne qui subit la haine, les tourments, les injustices de quelqu'un » dès 1606 | prise de notes | `litt-qc-victime` (C), `litt-fa-victime` |
| 2 | le film « La Vie d'une femme » « réalisé en mémoire de Chloé Bertolus » | la réalisatrice dit avoir rencontré la Pr Bertolus pour préparer le film, qu'elle a conseillé sur le tournage, et que son héroïne n'est pas inspirée d'elle (entretien au CNC, 2026) ; rien n'y parle d'un hommage posthume | douteux | `litt-qr-bertolus` |
| 5 | « descendre 20 fois au bloc » | dix-sept opérations en douze mois d'hôpital (La Libre Belgique, 2018) ; le nombre n'est pas à retenir | douteux | `litt-qc-temporalite` (B) |
| 5 | des « greffes de visage » « difficilement acceptées par le corps » | une greffe de visage est une allogreffe ; Lançon a été reconstruit avec ses propres tissus (péroné, peau de la cuisse), qui ne sont pas rejetés (La Libre Belgique, 2018 ; OpenStax Microbiology, 19.3) | douteux | `litt-qc-suture` (B) |
| 10 | lire et écrire permettent « d'étendre la zone cérébrale de l'empathie », ce que montreraient des études | les études mesurent la théorie de l'esprit après une lecture (Kidd et Castano, Science, 2013), effet que la réplication à plusieurs laboratoires ne retrouve pas (Panero et al., 2016) ; l'imagerie montre une connectivité accrue, passagère pour l'essentiel, pendant la lecture d'un roman (Berns et al., Brain Connectivity, 2013), pas une « zone de l'empathie » qui s'étendrait. À l'examen : lire et écrire développent l'attention et l'empathie | douteux | `litt-qc-competences` (B) |

Vérifiés et justes, donc sans ATTENTION : Rita Charon, docteur en médecine et en
littérature, à Columbia ; la médecine narrative développée dans les années 1990
(le terme date de 2000, le livre de 2006 : la carte le dit) ; Bernard Pivot et le
Goncourt, qui ne couronne pas un récit non fictif ; La Nuit des rois la veille de
l'attentat ; fiction, du latin « façonner » ; la suture, du latin sutura ;
l'objet transitionnel de Winnicott ; « Connais-toi toi-même » à Delphes, maxime
que Socrate fait sienne.

## Les erreurs du Ronéosaure 2025-26

Dites par un **ATTENTION** nu, sans genre, dans la carte qui porte la notion :
les cartes 2025-26 sont en attente ou absentes, et la liste des erreurs de la
promo ne concerne que les ronéos 2026-27.

| Page | Ce que dit le Ronéosaure | Ce qui est juste | Carte |
|---|---|---|---|
| FC n°8, p. 3 | His First Operation relate « la première expérience d'amputation pour un jeune médecin » | un étudiant de première année vient assister à sa première opération (un cancer de la parotide) et s'évanouit avant qu'elle ait lieu : le patient n'a pas supporté le chloroforme (texte de Conan Doyle, 1894, Wikisource) | `litt-qc-medecins-ecrivains` (explication) |
| FC n°8, p. 3 (gris) | « Alexandre Soljenltysme, Le pavillon des cancéreux (1957) » | Soljenitsyne ; roman achevé en 1966, publié en 1968 en Occident | `litt-rv-maladie-recit` |
| FC n°9, p. 5 | « L'article d'Anne Carole » | Anne Carol, « Une histoire médicale des critères de la mort », Communications n° 97, 2015 | `litt-qr-carol` |
| FC n°9, p. 6 | « les parents conservent le droit de refuser le don même si la loi établit ce consentement présumé » | en droit, les proches rapportent l'opposition que le défunt aurait exprimée (art. L1232-1 du CSP) | `litt-qc-consentement` (explication), `litt-an-2526s1-qr` (explication) |

## Le sujet 2025/2026 (18/10/2026)

Les sujets de SSH de l'examen du 09/01/2026 (1 QR, 10 QROC,
`src-sujets-ssh-2526`, sans corrigé), déposés le 18/10/2026, apportent 1
recto-verso à ce chapitre (QR). Aucun n'était déjà en cartes. Au verso, la
bonne réponse, tirée du ronéo 2026-27 quand il couvre la notion, sinon du
cours 2025-26, celui de l'année de l'examen ; ce qui dépasse le cours est dit
« hors cours », avec sa source (`officielle=False`). Rédigés et
contre-vérifiés le 18/10/2026 : un rédacteur, un sceptique, un critique de
complétude.

| Question | Ce que le verso répond | Voisine de |
|---|---|---|
| 2025/2026 S1 QR (`litt-an-2526s1-qr`) | la situation et les personnages du livre de 2025-26 ; le consentement aux soins valide (libre, éclairé, préalable, et ses exceptions) ; le consentement présumé du don, et le refus du défunt que rapportent les proches ; l'éthique du corps et de la mort redéfinie | `litt-an-2425s1-qr` |

Ce qui est signalé :

- La QR porte sur « Réparer les vivants » (Maylis de Kerangal, 2014), le livre
  de 2025-26 présenté par le Pr Sabot (FC n°8 et n°9) ; en 2026-27, le livre
  est « Le Lambeau ». Seul le point 1 du verso tient au livre, comme pour
  `litt-an-2425s1-qr` ; les points 2 à 4 (le consentement aux soins, le don
  d'organes, l'éthique) restent au programme.
- ATTENTION nu dans l'explication : la FC n°9 donne aux parents le droit de
  refuser le don (p. 6) ; en droit, les proches témoignent de l'opposition du
  défunt (L1232-1). Carte ajoutée à la ligne du tableau des erreurs du
  Ronéosaure.
- Hors cours, cités avec leur source : les articles L1232-1, L1232-2, L1232-4,
  L1232-5, R1232-1, R1232-2, R1232-4-4 et suivants (décret du 11 août 2016) et
  R4127-36 du CSP, les articles 16-1-1 et 16-3 du code civil. L'âge de Simon,
  dix-neuf ans, vient du roman.

## Les clés qui ne sont pas reprises telles quelles

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2024/2025 S1 Q.R (Cytomégalovirus : consentement, dignité, autonomie) | aucune (sujet sans corrigé) | **clé déduite** : non, pas pleinement respecté (des soins sans lui, une information qu'il apprend par hasard) ; deux dignités (ontologique, morale et sociale), deux autonomies (fonctionnelle, personnelle), chacune avec un passage cité par le cours | FC n°15 2024-25, p. 5-8 ; FC n°14 2025-26, p. 3-4, 11-12 ; ronéo 2026-27 d'éthique, p. 5 ; ED n°2 de 2025-26, p. 2, 4 |

Aucune clé de cours n'a changé :
`litt-qc-attention` garde la clé de 2025-26 (la lecture développe l'« attention
narrative ») et passe absente, ce que sa justification B et son explication
rapprochent de la ronéo 2026-27 (lire **et** écrire travaillent l'attention, p. 10).
Aucune carte ne cote vraie une phrase fausse de la ronéo : la proposition en cause
est écrite juste, et l'ATTENTION dit ce que porte la ronéo.

## Le lexique

Seize termes, pages mesurées dans les PDF (`chercher_pages.py`, page du plan
exclue), chacun avec son origine grecque ou latine.

**Sept nouveaux**, de la ronéo 2026-27 :

| Terme | Pages (ronéo 2026-27) | Racines nouvelles |
|---|---|---|
| Intersubjectivité | p. 5, 8 | `subjectivus (latin)` |
| Intertextualité | p. 13 | `texere (latin)` |
| Suture | p. 13, 14 | `suere (latin)` |
| Victime | p. 12, 2, 7, 13 | `victima (latin)` |
| Fiction | p. 8, 2, 3, 9 | `fingere (latin)` |
| Solution de continuité | p. 11, 13 | `solutio (latin)`, `continuus (latin)` |
| Affiliation | p. 10, 12 | `filius (latin)` |

La première page citée est celle qui définit le terme : c'est elle qui fait la
provenance. Les racines déjà dans la table sont reprises à leur clé exacte
(`inter (latin)`, `ad- (latin)`). **Trois termes relus** : « Médecine narrative »
(définition réécrite sur la ronéo 2026-27, p. 4, 2, 3, 6, 12, puis FC n°8),
« Empathie » (p. 10) et « Métaphore » (p. 4, 9) gagnent leurs pages de l'année.
Les six autres (« Anamnèse narrative », « Récithérapie », « Imagination morale »,
« Polyphonie », « Phénoménologie », « Mort cérébrale ») n'apparaissent pas dans la
ronéo 2026-27 et gardent leurs pages de 2025-26 ; le lexique n'a pas de marque
« absent ».

Les sept termes et les huit racines nouvelles sont proposés, vérifiés (TLFi par
l'API du CNRTL, Wiktionnaire, Gaffiot par Logeion), dans
`scratchpad/etym/ssh_litterature.json`, à la suite des propositions du 02/10, déjà
fusionnées : `etymologies.json` n'a pas été touché. Les textes du `LEXIQUE` sont
écrits comme `appliquer_etymologies.py` les écrirait après fusion (vérifié terme à
terme). Laissés à d'autres chapitres : « Contingence » (`ssh_sida`), « Causalité »
(`ssh_epistemologie`), « Préjudice » (`ssh_responsabilite`), « Alliance
thérapeutique » (`ssh_consultation_enfant`).

## Absent du cours 2026-27

Douze cartes **entières** que la ronéo 2026-27 remplace dans la médecine narrative,
qu'elle traite en entier (p. 4-12). Elles restent, citent leur page de la FC n°8
2025-26 (`fiche=F1`, badge « Cours 2025-26 »), et prennent le tag `absent-2026` et
la phrase « Absent du cours 2026-27 » en tête de l'explication (`ABSENTS_2026`,
`ORIGINE_ABSENTS`).

| Carte | Ce que le cours 2026-27 ne dit plus | Ce qui la remplace |
|---|---|---|
| `litt-fa-charon` | Narrative Medicine (2006) et la définition « reconnaître, absorber, interpréter, être ému » | le principe (`litt-fa-principe`, p. 4) |
| `litt-qc-narrative` | le livre de 2006, la définition, la critique de l'EBM (quatre propositions sur cinq) | le principe, la singularité, l'effet thérapeutique (`litt-fa-principe`, `litt-qc-singularite`, `litt-qc-competences`) |
| `litt-fa-apports`, `litt-qc-apports` | les apports face à l'EBM : facteurs contextuels, histoire familiale, ressources propres, alliance thérapeutique | l'entretien, la singularité, la relation bivalente (`litt-qc-entretien`, `litt-qc-singularite`, `litt-qc-intersubjectivite`) |
| `litt-fa-pratiques`, `litt-zo-narrative`, `litt-qc-attention` | les trois pratiques : anamnèse narrative, journal réflexif, lecture, et l'« attention narrative » que développe la lecture | les trois compétences (`litt-fa-competences`, `litt-qc-trois-competences`, `litt-zo-competences`) |
| `litt-fa-ecoute`, `litt-qc-anamnese`, `litt-qr-anamnese` | l'anamnèse narrative (mots, rythme, priorités, silences, non-dits) | l'attention (`litt-qc-competences`, p. 10) |
| `litt-qr-douze-secondes` | le médecin qui interrompt au bout de douze secondes | — |
| `litt-qr-journal` | le journal réflexif du soignant | lire et écrire (p. 10) |

## En attente des ronéos suivantes

Cinquante et une cartes du cours 2025-26 sur des sujets que la première séance
2026-27 ne traite pas. Elles restent telles quelles, citent leur page de la FC n°8
(`fiche=F1`) ou n°9 (`fiche=F2`) et gardent le badge « Cours 2025-26 ». Elles
seront relues à la parution des ronéos suivantes, ou passeront absentes si la fin
du cours ne les reprend pas.

| Sujet (cours 2025-26) | Cartes |
|---|---|
| L'éthique, lien entre littérature et médecine (FC n°8, p. 2 ; FC n°9, p. 2) | `litt-qc-ethique-lien`, `litt-fa-ethique`, `litt-qr-ethique`, `litt-fa-enjeux`, `litt-rv-apports` |
| Les limites du discours technique, la médecine de précision (FC n°8, p. 2-3) | `litt-qc-precision`, `litt-fa-precision`, `litt-qr-personnalisee`, `litt-qr-stratifiee`, `litt-rv-malentendu`, `litt-qr-dimensions`, `litt-rv-maladie-recit` |
| Les médecins écrivains (FC n°8, p. 3) | `litt-qc-medecins-ecrivains`, `litt-qr-red-lamp`, `litt-qr-salle-6`, `litt-rv-distance` |
| Biographies hospitalières et récithérapie (FC n°8, p. 5-6) | `litt-qc-recitherapie`, `litt-qc-biographie`, `litt-fa-recitherapie`, `litt-fa-fin-de-vie`, `litt-qr-festival`, `litt-qr-identite`, `litt-rv-patient-soignant`, `litt-qr-bilan`, `litt-qr-heritage` |
| Imagination morale et clinique, tolérance à l'ambiguïté (FC n°8, p. 6-7) | `litt-qc-imagination`, `litt-fa-imagination`, `litt-qr-imagination-clinique`, `litt-qr-ambiguite`, `litt-qr-inquietude`, `litt-rv-incertitude` |
| Polyphonie et empathie (FC n°9, p. 3-4) | `litt-qc-empathie`, `litt-rv-empathie`, `litt-qr-film-choral` |
| L'éthique de la transplantation : temporalités, corps, mort redéfinie, consentement, corps restauré, vocabulaire (FC n°9, p. 3-8) | `litt-fa-urgences`, `litt-qc-corps`, `litt-rv-corps`, `litt-fa-mort`, `litt-qc-mort`, `litt-qr-coma-depasse`, `litt-qr-dates`, `litt-qr-carol`, `litt-zo-mort`, `litt-qc-consentement`, `litt-qr-substitution`, `litt-rv-organes`, `litt-fa-respect`, `litt-qr-article-2`, `litt-rv-restauration`, `litt-fa-annonce`, `litt-qc-annonce` |

Ce qui se voit déjà : la ronéo 2026-27 cite l'empathie (p. 10, 12), la mise en
intrigue et les métaphores (p. 4, 9, 11), sans reprendre ces cartes-là ; la
transplantation tenait au roman de 2025-26 et a peu de chances de revenir avec
« Le Lambeau », qui parle de reconstruction, non de greffe d'organes.

## Décisions prises en route

- **Absent seulement dans la partie que la ronéo traite en entier** : la médecine
  narrative. Une carte n'est confirmée que si ce qu'elle interroge est dans le cours
  de l'année ; une proposition isolée de 2025-26 le dit dans sa justification. Une
  carte dont presque toutes les propositions sont de 2025-26 reste sur la FC n°8 et
  passe absente (`litt-qc-narrative`, relue le 11/10).
- **Les cartes 2025-26 gardent leur page** : `fiche=F1` est écrit sur les 39 qui
  citaient la FC n°8 par défaut, et sur les deux remises sur elle à la relecture
  (`litt-qc-narrative`, `litt-qc-attention`), puisque `SRC["fiche"]` est désormais la ronéo
  2026-27 ; leur source dans le paquet est inchangée.
- **Aucune carte réécrite sur une autre question** : une note réécrite garde ses
  révisions. La question des trois compétences est une carte nouvelle
  (`litt-qc-trois-competences`), et `litt-qc-attention` garde la sienne, absente ;
  `litt-qr-charon` ne change que la formulation de sa question, pas la réponse
  attendue.
- **Le nombre d'opérations n'est pas carté**, ni le nombre de chapitres du livre
  (« 20 chapitres », p. 2, invérifié) ni les ventes (200 000 exemplaires, p. 3 : la
  presse en compte 150 000 avant le Femina) : rien ne se joue sur un chiffre
  incertain.
- **`EXAMENS` n'est pas déclaré**, comme dans les autres chapitres SSH.

## Questions pour Vincent

- (11/10) Les 17 cartes de l'éthique de la transplantation (FC n°9 2025-26, liées à Réparer les vivants) : faut-il les passer absentes dès maintenant, puisque le livre a changé, ou attendre la fin du cours comme le veut la règle ? Pour l'instant, elles attendent.
- (11/10) Faut-il déclarer un examen SSH unique pour toute l'UE, exam-ssh-jan-2027 (6 janvier 2027) ? Aucun chapitre SSH n'a d'EXAMENS pour l'instant.
- (11/10) J'ai fait une règle d'une décision de relecture : une question changée de fond prend un nouvel identifiant, et l'ancienne carte reste, absente. C'est ce qui est arrivé à litt-qc-attention, devenue litt-qc-trois-competences. Faut-il l'écrire dans .claude/rules/cartes.md pour les autres réalignements ? D'autres chapitres ont réécrit des cartes sous le même identifiant, mais sur la même notion.

1. **Les trois libellés de thème** (`le-lambeau`, `cinq-caracteristiques`,
   `competences-narratives`) sont à ajouter à `THEME_LABELS` ; le test
   `test_tout_theme_du_paquet_a_son_libelle` échoue jusque-là.
2. **Les cartes de la transplantation (FC n°9)** : les passer absentes dès
   maintenant, puisque le livre a changé, ou attendre la fin du cours, comme le
   veut la règle ? Elles attendent.
3. **Un examen** : aucun chapitre SSH ne déclare d'`EXAMENS` ; un seul
   `exam-ssh-jan-2027` (6 janvier 2027) pour toute l'UE serait à décider une fois.

## Sans illustration

Sans objet : 26 QCM sur 28 sont illustrés.

## À relire

Aucune carte `a-relire` : chaque note cite sa page dans la ronéo 2026-27, ou dans
la FC n°8 ou n°9 2025-26 ; ce qui vient d'ailleurs est vérifié et cité dans la
carte. L'annale de 2024/2025 cite le livre de Guibert à travers le cours qui lui
était consacré (FC n°15 2024-25), sans relecture du livre : si le livre revient,
les passages se relisent sur lui.

## L'échelle : Simple → Moyen → Annale (C20, 19/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 5 janvier (BMCP) ou du 6 janvier (SSH, papier). Sous les annales, 14 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 2 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`) ; les QROC reçoivent le schéma nu.

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `litterature-ethique` | 4 | 1 | 1 |
| `transplantation-ethique` | 10 | 1 | 1 |

**Le schéma** `ech-consentement-don`, « Consentir, donner, rester digne », donne 17 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_CONSENTEMENT_DON`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Constantes ajoutées** à `annales.py` (`_SCHEMA_LETTRES`, `_SCHEMA_NU`) : les annales de SSH sont toutes des QROC, rangées dans `ANNALES_QROC` ; chacune reçoit le schéma nu, et les marches la préparent sans lettre.

**Sans marche** :
- litt-an-2526s1-qr, point 1 : la situation et les personnages de « Réparer les vivants », livre de 2025-26 — le livre de 2026-27 est « Le Lambeau » : pas de marche sur un livre qui n'est plus au programme
- litt-an-2526s1-qr, point 3 : le constat de la mort encéphalique, le registre comme moyen principal du refus, le mineur donneur (articles R1232-1 et suivants, L1232-2), hors cours — sans marche
- litt-an-2425s1-qr, points 4 et 5 : les passages de « Cytomégalovirus », livre de 2024-25 — plus au programme, sans marche

## Régénérer

```powershell
cd contenu\chapitres\ssh_litterature
..\..\..\app\.venv\Scripts\python.exe generer.py
```

`generer.py` est la copie exacte de
`.claude/skills/nouveau-chapitre/scripts/generer_modele.py`.
