# Sénescence cellulaire et thérapie ciblée — paquet BMCP

87 notes, 144 cartes. Chapitre `chap-ue-bmcp-senescence` de l'UE BMCP, ordre 11.
**Réaligné le 11/10/2026 sur le ronéo de l'année** : « Thérapie ciblée, mort
cellulaire et sénescence cellulaire » (Ronéo & Juliette 2026-27, 6 pages), cours du
**Pr Marchetti du 02/10/2026** (9 h-10 h selon l'en-tête). Malgré son titre, ce
ronéo ne tient **que la sénescence** ; la thérapie ciblée n'a pas encore de ronéo
2026-27, et ses cartes restent faites sur la FC n°11 du Ronéosaure 2025-26 (Pr
Marchetti, 28/10/2025). Annales : deux polycopiés du Ronéosaure 2024-25 (BMCP 10 et
BMCP 11, 17 sessions de 2015/2016 à 2023/2024), et le sujet de 2024/2025, sans
corrigé (Q2, Q4, QROC 2). Examen : mardi 5 janvier 2027.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 46 | 46 |
| QRU | 1 | 1 |
| Texte à trous | 11 | 63 |
| QROC | 11 | 11 |
| Recto-verso | 7 | 7 |
| Schéma cliquable | 1 | 6 |
| Planche à légender | 1 | 1 |
| Lexique | 9 | 9 |

Dont **29 annales** sur 18 sessions : 20 QCM du polycopié BMCP 10 (une
question de sénescence par session), 6 QCM de thérapies ciblées du polycopié
BMCP 11, et, du sujet de 2024/2025 (examen du 09/01/2025, sans corrigé, déposé le
15/10/2026), la Q2 (sénescence), la Q4 (thérapies ciblées) et le QROC 2 (les étapes
de la caractérisation de la cible, un recto-verso). Et 19 QCM de cours. **47 QCM sur
47 illustrés (100 %)**, 77 notes sur 87. **6 cartes portent un piège du ronéo 2026-27** (thème « Pièges des ronéos »).
**Aucune carte absente du cours 2026-27.**

| Cours cité | Cartes de cours | Badge |
|---|---|---|
| ronéo 2026-27 (`SRC["fiche"]`) | 24 — toute la sénescence | aucun |
| FC n°11 2025-26 (`fiche=FC2526`) | 25 — toute la thérapie ciblée | « Cours 2025-26 », en attente |

Six thèmes, dans l'ordre du cours, déjà dans `THEME_LABELS`
(`app/src/med_engine/application/scopes.py`) ; le réalignement n'en ajoute aucun :

| Clé | Libellé | Notes |
|---|---|---|
| `senescence` | Sénescence : limite de Hayflick et cellule sénescente | 18 |
| `telomeres` | Télomères, télomérase et sénescence prématurée | 16 |
| `longevite` | Sénescence, longévité et pathologies du vieillissement | 11 |
| `therapies-ciblees` | Thérapies ciblées | 16 |
| `glivec` | Imatinib (Glivec), BCR-ABL et LMC | 11 |
| `resistances-ciblees` | Résistances aux thérapies ciblées | 6 |

(et le lexique, 9 notes, hors thème.) `therapies-ciblees` et `resistances-ciblees`
sont partagées avec `bmcp_tests_biologiques`, au même libellé.

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-bmcp-snc-2627` — « THÉRAPIE CIBLÉE, MORT CELLULAIRE ET SÉNESCENCE CELLULAIRE.pdf » (6 p., la dernière vide), `BMCP/` | **2026-27** | **la base** : la sénescence (p. 2-5) ; `SRC["fiche"]`, avec `chapitre=`, ce que le lecteur ouvre ; 9 figures ; ni rouge ni gris |
| `src-fc-bmcp-snc-2526` — « FC n°11 Sénescence cellulaire et thérapie ciblée  .pdf » (11 p., deux espaces avant `.pdf`) | 2025-26 | `SRC["cours"]` et `SRC["medias"]`, sans `chapitre=` : la thérapie ciblée (p. 5-11), en attente du ronéo de l'année, et l'appoint de la sénescence (p. 2-5) |
| `src-annales-bmcp-10-…` — « BMCP 10 - Morts cellulaire, sénescence réplicative, thérapies ciblées » (18 p.) | 2024-25 | 20 questions ; table p. 18 |
| `src-annales-bmcp-11-…` — « BMCP 11 - Tests biologiques en médecine personnalisée » (6 p.) | 2024-25 | 6 questions ; table p. 6 |
| `src-sujets-bmcp-2425` — « Sujets de BMCP 2024/2025, session 1 » (30 p.) | 2024-25 | le sujet de l'examen du 09/01/2025, **sans corrigé** (dépôt `Annales_15102026/`, 15/10/2026) : Q2, Q4 et QROC 2 ; `SRC["sessions"]["2024/2025 S1"]` ; déclaré à l'identique dans tous les chapitres de BMCP qui en cartent une question |
| tableau d'erreurs BMCP de la promo 2026-27 | 2026-27 | **aucun** au 11/10/2026 (pas de fichier dans `Ajouts/`) |

Dans les textes, « p. N » renvoie à la source de la carte : le ronéo 2026-27 pour la
sénescence, la FC 2025-26 pour la thérapie ciblée ; les annales le disent en toutes
lettres (« pages du ronéo 2026-27 », « FC 2025-26, p. N »).

Lus en appoint, sans être déclarés : MORT CELLULAIRE 1 et 2 (ronéos 2026-27 du
même matin, cartés dans `bmcp_morts_cellulaires` : la sénescence y est « classée
dans la mort cellulaire par analogie », MC1 p. 2) ; la FC n°10 2025-26 (p. 18,
l'ouverture de la sénescence) ; le cours 2024-25 du même professeur (FC n°10,
sénescence p. 21-27) ; le cours 2023-24 n°13 « Thérapies ciblées en oncologie »
(Charonéo) ; la FC n°9 2025-26 (p53, p. 18) et la FC n°12 2025-26 (addiction
oncogénique, BRAF). Les en-têtes des ronéos et des polycopiés portent des noms
d'étudiants : aucun n'est repris.

La fiche de l'année se copie dans le dossier des PDF de l'application par
`outils/copier_les_cours.py`, avec le dossier des ronéos 2026-27
(`Ajouts/[NUMERIQUE] Ronéo & Juliette 26-27 11 10 2026/S1/CM`), hors du bac à sable.

## Ce qui a changé au réalignement (11/10/2026)

**Le plan est le même** : histoire (Carrel, Hayflick), cellule sénescente
(morphologie, β-galactosidase à pH 6, arrêt en G1), sénescence réplicative
(télomères, télomérase), sénescence induite par un stress, longévité et pathologies
du vieillissement. Chaque carte de sénescence est relue sur le ronéo 2026-27 et
porte sa page ; aucune clé ne change.

**Ce que le ronéo 2026-27 apporte, et où c'est carté :**

- les dates dans le texte (Carrel 1912, Hayflick 1959) et la contamination de
  l'échantillon de Carrel par des cellules embryonnaires (`snc-qc-historique`,
  `snc-rv-carrel-hayflick`) ;
- la β-galactosidase « hydrolase acide présente dans les lysosomes », « on la voit
  en bleu » (`snc-qc-beta-galactosidase`, `snc-qr-ph`) ;
- p53, « le gardien du génome » : **nouvelle QROC** `snc-qr-p53` ;
- les cellules avec et sans télomérase : **nouvelle figure** (p. 4) ;
- l'excès d'O2 : environ **40 divisions** ; les formes réactives de l'oxygène
  (anions superoxydes, peroxyde d'hydrogène) ; les conséquences du stress oxydant,
  dont l'altération de la communication cellulaire et les agrégats de protéines :
  **nouveau texte à trous** `snc-fa-stress-oxydant`, un sixième trou dans
  `snc-fa-oxygene`, la E de `snc-qc-stress-oxydant` réécrite ;
- le tableau des espèces avec ses écarts (souris 15 ± 5, homme 60 ± 20 doublements
  de population) (`snc-qc-longevite`, `snc-fa-longevite`) ;
- **la brebis Dolly** : **nouveau QCM** `snc-qc-dolly` ;
- la progéria : « une centaine de cas rapportés », la progérine qui fragilise le
  noyau et casse l'ADN, le transcriptome des fibroblastes de sujets de 40 ans :
  **nouveau QCM** `snc-qc-progerine` ;
- le transcriptome et le sécrétome, en gras : **deux termes de lexique**.

**Ce que le ronéo 2026-27 ne dit plus**, sans que ce soit une carte entière (chaque
fois, la justification de la proposition le dit et cite la FC 2025-26) : le
« volume x10 » de la cellule sénescente (`snc-qc-cellule-senescente` A, devenu
« volume plus important » dans `snc-fa-cellule-senescente`) ; l'« enzyme de la
jeunesse éternelle » (attribuée aux cours 2024-25 et 2025-26 dans la définition de
`lex-telomerase`) ; l'âge du diagnostic de la progéria, vers 2 ans, et ses
signes (`snc-qc-progeria` C et E) ; la perte de fonction des protéines oxydées.
« Nom des molécules pas à savoir » (ATM, H2AX), écrit en 2025-26, a disparu : le
ronéo 2026-27 les nomme sans les écarter (`snc-qc-telomeres` C). L'« ostéoarthrite »
des cours 2024-25 et 2025-26 (l'arthrose) y devient « arthrite » : une prise de
notes (plus bas) ; `snc-qc-longevite` D dit désormais « lésions du cartilage », que
les deux formulations partagent.

**Les figures** de la sénescence sont celles du ronéo 2026-27, extraites en PNG et
réduites à 1100 px au plus, **sous le même nom** que les captures de la FC 2025-26
qu'elles remplacent (bien plus nettes) : Carrel, la courbe de Hayflick (p. 2), les
cellules jeunes et sénescentes, la β-galactosidase, les télomères (p. 3 — le PDF
coupe la figure en bas de page, l'image est entière), Hayflick à trois pressions
d'O2 (p. 4), le tableau des espèces, la lamine dans la progéria (p. 5) ; plus une
nouvelle, `snc-telomerase.png` (p. 4). Elles sont déclarées avec leur source
(troisième élément d'`IMAGES`).

## Les erreurs du ronéo 2026-27

Pas de tableau d'erreurs BMCP de la promo au 11/10 : toutes sont trouvées en
relisant. Chacune est portée dans la carte, avec son genre.

| Page | Le ronéo dit | Retenu | Genre | Carte |
|---|---|---|---|---|
| 2 | « Hayflick démontre que la sénescence arrive bien après un certain temps » | après un certain nombre de divisions : la même page dit « non du temps écoulé », et les cellules congelées un an font encore leurs 40 divisions ; FC 2025-26 p. 2 | prise de notes | `snc-qc-historique` D |
| 4 | « les cellules germinales adultes (dont les cellules souches) » | les cellules souches adultes sont somatiques, une catégorie à part : FC 2025-26 p. 4, cours 2024-25 p. 26 ; Morrison et al., Immunity 1996 | prise de notes | `snc-qc-telomerase` D, `snc-fa-telomerase` |
| 5 | « arthrite et lésions du cartilages » | les cours 2024-25 (p. 27) et 2025-26 (p. 5) écrivent « ostéoarthrite et lésions du cartilage » : l'ostéoarthrite (osteoarthritis) est l'arthrose, maladie dégénérative du cartilage (MeSH D010003), et non l'arthrite, inflammation de l'articulation | prise de notes | `snc-qc-longevite` D |
| 2 | les cellules « rentrent en phase de sénescence pour mourir par apoptose » | c'est le cours lui-même (FC 2025-26 p. 2, FC n°10 2025-26 p. 18). À l'examen : la cellule sénescente est vivante, métaboliquement active. La référence : le fibroblaste sénescent, celui de Hayflick, reste viable et résiste à l'apoptose (Wang, Cancer Res 1995 ; Childs et al., EMBO Rep 2014, qui note que les cellules endothéliales sénescentes y sont plus sensibles) | cours | `snc-qc-cellule-senescente` E |
| 5 | Dolly, morte à 6 ans, « ce qui montre bien le lien entre sénescence cellulaire et longévité » | euthanasiée à 6 ans et demi pour un adénocarcinome pulmonaire ovin (rétrovirus JSRV) ; télomères plus courts de 20 % (Shiels et al., Nature 1999), mais quatre clones de la même lignée ont vieilli normalement (Sinclair et al., Nat Commun 2016) | point douteux | `snc-qc-dolly` D |

Le Ronéosaure 2025-26 tenait déjà l'erreur de l'apoptose pour une prise de notes (« puis
meurent par apoptose », démenti à la p. 3) ; qu'une troisième équipe de rédacteurs
l'écrive en 2026-27 la fait passer au cours lui-même. La carte ne change pas de
clé : même pour le professeur, la cellule qui atteint la limite de Hayflick entre
d'abord en sénescence, vivante.

Sans carte ni ATTENTION, parce que ce sont des coquilles sans effet sur le sens :
« BCMP » pour BMCP dans l'en-tête ; la partie « II » du plan, numérotée « D » dans le
texte ; « artérosclérose » ; « certain ombre de division » (p. 5).

## Absent du cours 2026-27

**Aucune carte.** Le ronéo 2026-27 couvre toute la sénescence du cours 2025-26 ;
il n'en retire que des détails, dits dans la justification de la proposition qui
les porte (voir plus haut). `ABSENTS_2026 = []`.

## En attente des ronéos suivantes

**Toute la thérapie ciblée** : le ronéo 2026-27 porte « thérapie ciblée » dans son
titre mais ne la traite pas, et aucun autre ronéo de l'année ne l'a encore fait au
11/10 (en 2025-26, elle tenait la seconde heure du cours du 28/10). Ces cartes
gardent la FC n°11 2025-26 à leur page (`fiche=FC2526`) et le badge « Cours
2025-26 » ; elles ne sont pas « absentes », elles attendent leur ronéo :

- **QCM de cours** (9) : `snc-qc-trois-differences`, `snc-qc-decouverte-structure`,
  `snc-qc-mab-nib`, `snc-qc-etapes-cible`, `snc-qc-bcr-abl`, `snc-qc-il3`,
  `snc-qc-glivec`, `snc-qc-limites`, `snc-qc-kinome` ;
- **textes à trous** (4) : `snc-fa-mab-nib`, `snc-fa-etapes-cible`, `snc-fa-glivec`,
  `snc-fa-limites` ;
- **QROC et recto-verso** (10) : `snc-qr-validee`, `snc-qr-promoteur`,
  `snc-qr-serendipite`, `snc-qr-mutations`, `snc-qr-kinome`, `snc-qr-gist`,
  `snc-rv-cytostatique`, `snc-rv-trois-differences`, `snc-rv-etapes`,
  `snc-rv-mab-nib` ;
- **le schéma cliquable** `snc-zo-cibles` et **la planche** `snc-pl-glivec` ;
- **les six annales du BMCP 11** (clés relues sur la FC 2025-26 et le cours
  2023-24, inchangées) ;
- **quatre termes de lexique** : Cytostatique, Translocation, Sérendipité, Kinome
  (pages de la FC 2025-26).

Quand le ronéo paraîtra : le déclarer dans `SOURCES` (`chapitre=` ; la thérapie
ciblée en `fiche=` sur ses cartes, ou en `SRC["fiche"]` s'il tient tout), relire
chaque carte dessus, et seulement alors juger ce qui en serait absent.

## Ce que les annales ont dicté

| Savoir | Questions |
|---|---|
| La corrélation positive avec la longévité (souris, homme, tortue) | dix sessions, de 2015/2016 S1 à 2020/2021 S2 |
| Le stress oxydant et la sénescence prématurée | douze |
| La progéria, « maladie des lamines », et la progérine | huit |
| La télomérase, qui n'accélère pas la sénescence ; les cellules qui l'expriment | sept ; neuf |
| Les cellules sénescentes vivantes, métaboliquement actives | cinq |
| La culture à 3 % d'O2 : vingt doublements de plus | quatre |
| L'imatinib : analogue de l'ATP, inactif sur les cellules souches, c-KIT | cinq questions du BMCP 11 |
| Les anti-EGFR : KRAS, irinotécan, toxicité cutanée | cinq questions du BMCP 11 (cours 2023-24 ; absents du cours 2025-26 ; la thérapie ciblée n'a pas encore de ronéo 2026-27) |

Le sujet de 2024/2025 reprend ces classiques : sa Q2 est la 2023/2024 Q5 à trois items
près (A et E mot pour mot), sa Q4 oppose thérapie ciblée et chimiothérapie
conventionnelle, anticorps et inhibiteur de kinase (FC 2025-26, p. 5-6), et son QROC 2
demande les quatre étapes de la cible (p. 7), que la FC annonçait comme « question posée
les années précédentes en examen ».

Les 20 questions de sénescence sont relues sur le ronéo 2026-27 : toutes leurs
clés tiennent, leurs justifications citent ses pages, et leurs figures sont celles
de l'année. La 2023/2024 Q5 est imprimée deux fois, dans le BMCP 10 et le BMCP 11,
avec la même clé : **une seule carte**, rangée au BMCP 10.

## Les clés qui ne sont pas reprises telles quelles

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| BMCP 11, 2020/2021 S1 Q15 | BCDE | **BDE**, `officielle=False` | C, « l'imatinib est particulièrement actif contre les cellules souches leucémiques », est fausse : la FC 2025-26 dit qu'il en est « exclu » (p. 10), le résumé du professeur qu'il « n'est pas actif contre les cellules souches tumorales » (cours 2023-24, p. 12), et quatre sessions concordent. ATTENTION, CONFLITS |
| BMCP 10, 2020/2021 S1 Q14 | aucune (« aucune correction ») | ABDE, déduite du cours | C (« les cellules cancéreuses rentrent spontanément en sénescence ») fausse : télomérase (ronéo 2026-27, p. 4) |
| BMCP 10, 2019/2020 S2 Q14 | aucune (« pas de correction ») | ACDE, déduite du cours | à la A près, la 2019/2020 S1 Q12 (clé ACDE) |
| Sujet 2024/2025 S1 Q2 (sénescence) | aucune (sujet sans corrigé) | **ABDE**, déduite du cours | A, p. 2 ; B, arrêt irréversible en G1 (p. 3) ; C fausse, les cellules tumorales ont une télomérase (p. 4) ; D, transcriptome et sécrétome (p. 3) ; E, p. 5 (ronéo 2026-27) |
| Sujet 2024/2025 S1 Q4 (thérapies ciblées) | aucune (sujet sans corrigé) | **CDE**, déduite du cours | A fausse, c'est la chimiothérapie conventionnelle, non spécifique, qui donne de nombreux effets secondaires (FC 2025-26, p. 5) ; B fausse, l'inhibiteur prend le site de l'ATP de la kinase (p. 6) ; C, D, E, p. 6 |
| Sujet 2024/2025 S1 QROC 2 (étapes de la cible) | aucune (sujet sans corrigé) | verso déduit du cours | les quatre questions de la FC 2025-26, p. 7 — cible potentielle, prometteuse, validée, inhibiteur — et BCR-ABL (p. 8-10) |

Une clé reprise mais discutée dans la carte (ATTENTION, CONFLITS) :

| Question | Clé | Le point | À l'examen |
|---|---|---|---|
| BMCP 10, 2018/2019 S1 Q10 A | ABCE | « activité béta-galactosidase à pH acide » : le cours dit « à ph 6 », et le ronéo 2026-27 « hydrolase acide présente dans les lysosomes » (p. 3) ; pH 6 est acide, mais l'enzyme lysosomale, présente dans toutes les cellules, travaille au mieux vers pH 4 ; c'est sa détection à pH 6 qui signe la sénescence (Dimri, PNAS 1995 ; Kurz, J Cell Sci 2000) | vrai, comme la clé ; retenir « pH 6 » |

Coquilles du polycopié réparées sans toucher au sens, et dites dans la carte : le
« β » perdu de « la -galactosidase » (2022/2023 S1 Q6 D, 2018/2019 S2 Q13 E) ; les
propositions D et E de 2019/2020 S2 Q14 imprimées sur une même ligne ; la colonne
« 2021/2022 Session 2 » de la table du BMCP 10 qui porte la session 1 ; l'en-tête
« 2022/2024 » du BMCP 11 (2023/2024) ; « NKRAS » (2021/2022 Q10 D), gardé tel
qu'imprimé.

## Les erreurs du Ronéosaure 2025-26 (thérapie ciblée)

Le Ronéosaure n'est pas le ronéo de l'année : ses erreurs sont portées par un
**ATTENTION nu**, la sorte dite dans le texte, et n'entrent pas dans
`contenu/ERRATA_RONEOS_2026-27.md`. Il ne reste que celles de la thérapie ciblée ;
celle de la p. 2 (« puis meurent par apoptose ») est devenue une erreur du ronéo
2026-27, plus haut.

| Page | Le ronéo dit | Retenu | Sorte | Carte |
|---|---|---|---|---|
| 5 | la colonne du tableau titrée « Thérapie cellulaire » | thérapie ciblée | prise de notes | `snc-qc-trois-differences` |
| 6 | les inhibiteurs de kinase, « métabolisme rapide : on doit donc prendre beaucoup de prises par jour » | le cours lui-même (même phrase en 2023-24, p. 3) : à l'examen, vrai ; la référence : l'imatinib se prend une fois par jour (demi-vie ≈ 18 h, RCP), le nilotinib deux | le cours lui-même | `snc-qc-mab-nib` E |
| 8 | le Glivec, « première thérapie ciblée en oncologie, sortie en 2001 » | premier inhibiteur de tyrosine kinase ; le rituximab (1997) et le trastuzumab (1998) l'ont précédé | point douteux | `snc-qc-glivec` (explication) |
| 9 | l'ATP « hydrolysé par une ATPase », « le phosphate de l'ADP va se lier au substrat » | la kinase transfère le phosphate γ de l'ATP sur la tyrosine ; l'ADP est ce qui reste | prise de notes | `snc-qc-glivec` E |
| 11 | « garder le traitement pendant moins de 5 ans » | la diapositive de la p. 10 : « ttt au moins 5 ans et après arrêt surveillance » (cours 2023-24 p. 7 ; ELN 2020) | prise de notes | `snc-qc-limites` D |
| 11 | les TKI de 2e et 3e générations « sortis en 2014 », « efficaces même en présence de ces mutations » | dasatinib 2006, nilotinib 2007, sans effet sur T315I ; seul le ponatinib (2012) la couvre parmi les TKI de la poche de l'ATP, et l'asciminib (2021, poche myristoyl) | point douteux | `snc-qc-limites` E |

## Les schémas et les figures

**Neuf figures du ronéo 2026-27** pour la sénescence (voir plus haut) et **sept de
la FC 2025-26** pour la thérapie ciblée : le tableau des trois différences (p. 5),
la chronologie des anticancéreux, anticorps et inhibiteur (p. 6), BCR-ABL,
l'expérience IL-3 (p. 8), le mécanisme du Gleevec (p. 9), les cellules souches
tumorales (p. 10), la TEP d'un GIST (p. 11).

| Fichier | Ce qu'on clique ou légende | Pourquoi ce dessin |
|---|---|---|
| `cibles-therapies-ciblees.svg` (zone, 6 zones) | le ligand ; le domaine extracellulaire (site de l'anticorps) ; la membrane ; le domaine kinase du récepteur (site du -nib) ; BCR-ABL, kinase cytoplasmique (cible de l'imatinib) ; le noyau | la figure de la p. 6 et le texte des p. 6-9 de la FC 2025-26, redessinés nus ; version légendée en correction |
| `snc-pl-glivec` (planche, 7 numéros) | BCR-ABL (deux fois), ATP, phosphate (deux fois), ADP, imatinib ; intrus : GTP, AMP, trastuzumab, récepteur HER2, interleukine 3 | les deux panneaux de la diapositive p. 9 de la FC 2025-26, légendes effacées (`planche_depuis_image.py`) |
| `echelle-cibles.svg` (figure) | — | les quatre questions de la p. 7, de la cible potentielle à l'inhibiteur : illustre `snc-fa-etapes-cible`, `snc-qc-etapes-cible`, `snc-rv-etapes` |

La sénescence n'a ni planche ni schéma cliquable : ses figures sont des captures de
diapositives, et une seule porte une suite de légendes, la cascade des télomères
(p. 3 : perte de protection, cassure double brin, réparation, ATM et H2AX, p53
stabilisée, arrêt irréversible). Elle pourrait devenir une planche
(`planche_depuis_image.py`) ; la QROC `snc-qr-p53` et `snc-qc-telomeres` C en
tiennent déjà l'essentiel.

## Le lexique

Neuf termes ; aucun n'existait ailleurs (vérifié contre les `lex-*` de tous les
paquets). Pages mesurées dans le texte des ronéos, en-têtes exclus — le titre
courant du ronéo 2026-27 contient « sénescence » à chaque page.

| Terme | Origine | Pages |
|---|---|---|
| Sénescence | latin senescere | ronéo 2026-27 p. 2-5 ; FC 2025-26 p. 2-4 |
| Télomérase | grec τέλος + μέρος + -ase | ronéo 2026-27 p. 4 ; FC 2025-26 p. 4 |
| Progéria | grec προγήρως | ronéo 2026-27 p. 5 ; FC 2025-26 p. 5 |
| **Transcriptome** (nouveau) | latin transcribere + grec σῶμα, par l'anglais transcriptome | ronéo 2026-27 p. 3, 5 ; FC 2025-26 p. 3 |
| **Sécrétome** (nouveau) | latin secretio + grec σῶμα, par l'anglais secretome | ronéo 2026-27 p. 3 ; FC 2025-26 p. 3 |
| Cytostatique | grec κύτος + στατικός | FC 2025-26 p. 5 |
| Translocation | latin trans + locatio | FC 2025-26 p. 8 |
| Sérendipité | anglais serendipity (Walpole, 1754) | FC 2025-26 p. 9, 11 |
| Kinome | grec κινέω + σῶμα | FC 2025-26 p. 11 |

Transcriptome et sécrétome sont en gras dans le ronéo 2026-27 (p. 3) et les
annales les demandent (2018/2019 S1 Q10 E, 2017/2018 S1 Q18 E, 2015/2016 S1 Q18 E).
Leurs racines sont déjà dans la table (`trans- (latin)`, `scribere (latin)`,
`secernere (latin)`, `-ome (de génome)`) ; leurs étymologies sont proposées dans
`scratchpad/etym/bmcp_senescence.json`, et les textes du lexique sont déjà écrits
dans la forme que `appliquer_etymologies.py` produirait. Hypoxie, que le ronéo met en
gras (p. 4), n'est pas prise : aucune annale de ce chapitre ne l'emploie, celles de
`bmcp_morts_cellulaires` si (l'apoptose des territoires hypoxiques) — c'est là son
chapitre d'accueil.

**Laissés à un autre chapitre** : Télomère et Cytotoxique sont déjà des notes
(`lex-telomere` dans `genet_cytogenetique`, `lex-cytotoxique` dans
`immuno_temporelle`).

## Questions pour Vincent

- (11/10) « pour mourir par apoptose » (p. 2) : je l'ai rangé dans le cours lui-même, et non dans la prise de notes, parce que trois équipes de rédacteurs l'écrivent sur deux ans. La carte ne change pas : à la limite de Hayflick, la cellule entre d'abord en sénescence et reste vivante. D'accord ?
- (11/10) « arthrite » pour « ostéoarthrite » (p. 5) : je l'ai classé en prise de notes, puisque les deux années précédentes écrivent « ostéoarthrite », c'est-à-dire l'arthrose. Il est porté en ATTENTION sur snc-qc-longevite D. D'accord pour l'ajouter à la liste de la promo ?
- (11/10) La brebis Dolly : la carte répond comme le cours et explique en point douteux pourquoi l'exemple ne prouve pas le lien entre sénescence et longévité. À garder ainsi ?
- (11/10) β-galactosidase « à pH acide » (2018/2019 S1 Q10 A) : la clé est reprise (vrai) et signalée comme point douteux, et le ronéo 2026-27 (« hydrolase acide ») va dans son sens. On garde le conflit ou on le lève ?
- (11/10) La cascade des télomères (p. 3) est la seule figure légendée de la sénescence. Faut-il en faire une planche à légender ?

1. **La cellule sénescente « pour mourir par apoptose »** : rangée au cours
   lui-même, parce que trois équipes de rédacteurs l'écrivent sur deux ans. La
   carte garde sa clé (la cellule à la limite de Hayflick entre d'abord en
   sénescence, vivante). D'accord avec ce tri ?
2. **La brebis Dolly** : la carte répond comme le cours et dit en point douteux
   pourquoi l'exemple ne prouve rien. À garder ainsi ?
3. **La β-galactosidase « à pH acide »** (2018/2019 S1 Q10 A) : la clé est
   reprise (vrai), signalée point douteux ; le ronéo 2026-27, qui dit « hydrolase
   acide », va dans le sens de la clé.
4. **Un chapitre hors squelette** (`chap-ue-bmcp-senescence`, 22e chapitre BMCP, à
   l'ordre 11) : toujours à confirmer.

## À relire

**Aucune carte `a-relire`** : chaque carte de sénescence cite une page du ronéo
2026-27, chaque carte de thérapie ciblée une page de la FC 2025-26, du cours 2023-24
ou 2024-25, ou une source sûre nommée. Relu au réalignement : chaque carte de
sénescence et chaque annale de sénescence contre le ronéo 2026-27, page par page ;
les neuf figures regardées une à une.

Reste à Vincent :

- `copier_les_cours.py` avec le dossier des ronéos 2026-27, hors du bac à sable,
  pour que la fiche de l'année s'ouvre dans l'application ;
- quand le ronéo de la thérapie ciblée paraîtra, réaligner les 25 cartes en
  attente ;
- `contenu/COUVERTURE.md`, `CHANGELOG.md` et `contenu/ERRATA_RONEOS_2026-27.md` ne
  sont pas touchés par ce réalignement, fait en parallèle d'autres : à mettre à jour
  avec la vague.

## L'échelle : Simple → Moyen → Annale (C20, 19/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 5 janvier (BMCP) ou du 6 janvier (SSH, papier). Sous les annales, 37 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 8 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`) ; les QROC reçoivent le schéma nu.

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `senescence` | 10 | 2 | 10 |
| `telomeres` | 8 | 2 | 7 |
| `longevite` | 3 | 1 | 4 |
| `therapies-ciblees` | 11 | 1 | 4 |
| `glivec` | 1 | 1 | 1 |
| `resistances-ciblees` | 4 | 1 | 3 |

**Le schéma** `ech-senescence-therapie`, « Sénescence et thérapie ciblée · deux mécanismes », donne 74 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_SENESCENCE_THERAPIE`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Sans marche** :
- snc-an-2324s1-q7 E (les thérapies ciblées des mélanomes mutés) : FC n°12 2025-26 et cours 2023-24, hors des sources du chapitre ; lettre posée sur la case « Petite molécule (-nib) ».
- snc-an-2021s1-q15 D et snc-an-1920s1-q13 D (l'échappement aux inhibiteurs de BRAF) : FC n°12 2025-26 et cours 2023-24, hors des sources ; l'échappement au Glivec, lui, est préparé par snc-ech-s36 et s37 ; lettres posées sur « Ses limites ».
- snc-an-2021s1-q15 E, snc-an-2021s2-q19 D et E, snc-an-1920s1-q13 E, snc-an-1819s1-q14 E, snc-an-2122s1-q10 D (les anti-EGFR : KRAS, irinotécan, toxicité cutanée) : cours 2023-24 seulement, absents des cours 2025-26 et 2026-27 ; lettres posées sur la case de l'anticorps monoclonal, la famille des anti-EGFR.
- snc-an-1819s1-q14 B (des cibles qui ne sont pas toutes des tyrosine kinases : BRAF, le VEGF) : FC n°12 2025-26, hors des sources ; lettre posée sur « Petite molécule (-nib) ».
- snc-an-1819s1-q14 C (l'addiction aux oncogènes) : FC n°12 2025-26, p. 3, hors des sources ; lettre posée sur « Caractériser la cible ».
- En partie seulement : snc-an-1718s2-q20 E et snc-an-1617s2-q21 E (p53 régule l'apoptose, l'autophagie et la sénescence) — la sénescence est préparée par snc-ech-s9 et m4 ; l'apoptose (FC n°9 2025-26) et l'autophagie (hors des cours) n'ont pas de marche.

## Régénérer

```powershell
..\..\..\app\.venv\Scripts\python.exe generer.py
```
