# Principes de base et réglementation en transfusion — paquet d'exemple

31 notes, 52 cartes. Onzième et dernier chapitre de l'UE **Tissu sanguin**,
Pr Mendel, semaine 7. Après les groupes et les produits, l'acte lui-même et le
droit qui l'encadre.

## Huit étapes, dans l'ordre

`acte-transfusionnel.svg`, redessiné nu — dix boîtes, aucun mot dessus. Savoir
l'ordre, c'est savoir ce qui a été omis quand quelque chose tourne mal.

1. information pré-transfusionnelle — **tracée**, sans formulaire signé
2. prescription — **acte médical**, même en urgence vitale
3. bilan : phénotypage ABO-RH-KEL1 + **RAI (72 h)**
4. transport
5. réception — vérifier la péremption ; l'horodatage ouvre les **6 heures**
6. **contrôle ultime pré-transfusionnel**
7. surveillance
8. information post-transfusionnelle et suivi

## Le dernier verrou, et son dédoublement

| | Concordance | Compatibilité |
|---|---|---|
| Pour quels produits | **tous les PSL** | **CGR seulement**, même en urgence |
| Où | au lit du patient | au lit du patient |

Trois unités : **lieu** (au lit), **temps** (receveur et produit ensemble),
**action** (une seule personne, sans interruption de tâche). Les deux accidents
que raconte le cours — du plasma ABO incompatible, dont trois litres — ont été
des défauts de **concordance**, sur des produits sans carte de compatibilité.

La carte n'est **pas** une détermination de groupe : elle vérifie la seule
compatibilité ABO.

## Trois niveaux d'urgence

Ce qui les distingue n'est pas le délai mais **ce dont on dispose** :

| | Délai | Disponible |
|---|---|---|
| Relative | 2 à 3 h | deux groupes **et** la RAI |
| Vitale | < 30 min | deux groupes, **pas** de RAI |
| Vitale immédiate | sans délai | **ni groupe ni RAI** — culots O |

## Après

Contrôle de l'efficacité (hémoglobine, numération), **ordonnance de RAI à 1-3
mois** — c'est elle qui dépiste l'immunisation, effet indésirable retardé au
diagnostic purement biologique. Poches vides gardées **4 heures** minimum.

Devant un effet indésirable immédiat : arrêter, garder la voie, prendre les
constantes, prévenir le médecin, l'hémovigilance **dans les 8 heures**, et l'EFS.

## Clés d'annales non reprises telles quelles

La clé retenue est la bonne, pas la clé imprimée (règle de Vincent, 26/09) :
la question porte alors `cle_officielle` à faux, et la justification de l'item
dit que la correction imprimée n'est pas bonne, et pourquoi.

| Question | Clé imprimée | Retenu | Pourquoi | Source |
|---|---|---|---|---|
| 2022/2023, QCM 6 C (`trf-an-2223-q6`) — « la carte de contrôle ultime pré-transfusionnel est réalisée pour tous les PSL » | CDE (C vrai) | **DE** (C faux) | la carte est le dispositif du contrôle de compatibilité ABO, réservé aux CGR (et granulocytes) ; seul le contrôle de concordance vaut pour tous les PSL | cours p. 11 ; instruction n° DGS/PP4/2026/97 du 19 juin 2026 relative à la réalisation de l'acte transfusionnel, qui remplace celle du 16 novembre 2021 (DGS/PP4/DGOS/PF2/2021/230) sans changer cette règle |

## Le dépôt du 15/10/2026

- **QCM 9 de 2023/2024** (`trf-an-2324-q9`, AE) : clé confirmée par la grille
  officielle (dépôt du 15/10/2026). Seul le surligneur du sujet (correction
  officieuse, d'origine inconnue) ajoute D, « les prélèvements pour groupes
  sanguins doivent être réalisés après la transfusion » ; la grille dit AE.
  Prélevés après la transfusion, les groupes ne liraient plus que le sang du
  donneur mêlé à celui du patient.
- **QROC 5 de 2023/2024** (`trf-an-qr-post`) : confrontée au corrigé officiel,
  qui attend le contrôle de l'hémoglobine, l'ordonnance de RAI entre 1 et 3 mois
  et l'information du patient ; la réponse précise désormais le contenu de cette
  information, le nombre et le type de PSL transfusés.

## L'échelle : Simple → Moyen → Annale (C20, 16/10/2026)

L'échelle du pilote de l'immunité innée, étendue au tissu sanguin et aux trois derniers chapitres de sémiologie pour l'examen du 4/11 (Vincent, 16/10 : « on continue pour les chapitres que je vais avoir à l'examen »). Sous les annales, 12 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 3 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`) ; les QROC reçoivent le schéma nu.

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `urgence` | 5 | 1 | 2 |
| `cupt` | 5 | 1 | 1 |
| `surveillance` | 2 | 1 | 1 |

**Le schéma** `ech-acte`, « L'acte transfusionnel · huit étapes, trois urgences », donne 18 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_ACTE`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**La source.** Les marches citent le cours 2024-25 du chapitre, sur lequel ses cartes et les justifications de ses annales sont bâties (décision de Vincent, 16/10 : pas de ronéo 2026-27 parue). La FC 2025-26 du Ronéosaure a servi de contre-épreuve : un fait qui change d'une année à l'autre porte un `ATTENTION`, ou n'a pas de marche.

**Le générateur.** Depuis le 16/10, `generer.py` est la copie exacte du modèle du skill : le bloc « le générateur modèle » en fin de `donnees.py` déclare les sources dans `SRC` et range les QROC d'annales dans `ANNALES_QROC`, officielles comme avant. Le paquet est resté le même, à trois écarts voulus près (indentation, champs par défaut des cartes à zones, légende du média du schéma cliquable).

**ATTENTION posés** : le formulaire et la prescription, que la FC 2025-26 décrit autrement (information tracée au dossier, sages-femmes prescriptrices : s1, s2) ; la clé imprimée de 2022/2023 QCM 6 sur la carte de contrôle ultime (s7, s8, m2).

## Régénérer

```
python generer.py
```
