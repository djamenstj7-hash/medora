# Facteurs de variabilité de la réponse aux médicaments — paquet BMCT

148 notes, 214 cartes. Chapitre `chap-ue-bmct-fc5` de l'UE BMCT, cinquième de
l'UE. **Base : les deux ronéos 2026-27 du 05/10/2026** (Ronéo & Juliette,
Pr S. Gautier), depuis le 19/10/2026 ; la FC n°5 du Ronéosaure 2025-26 (cours du
07/10/2025) en appoint ; les annales de trois polycopiés du Ronéosaure 2024-25
(12 sessions) et du sujet 2024/2025. Examen : partiel du mercredi 4 novembre
2026.

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-bmct-var-2627-1` (`FC1`) — « Facteurs et variabilités de réponses aux médicaments 1 » (12 p., 8 h-9 h) | 2026-27 | `SRC["fiche"]` : introduction et essais cliniques (p. 2-3), les facteurs (p. 4), l'enfant (p. 4-8), le sujet âgé (p. 8-11) ; quatre figures (p. 4, 6, 9, 10) |
| `src-fc-bmct-var-2627-2` (`FC2`) — « Facteurs de variabilités de réponses aux médicaments 2 » (12 p., 9 h-10 h) | 2026-27 | `fiche=FC2` : sujet âgé et fragilité (p. 2-3), poids extrêmes (p. 3-4), grossesse (p. 4-6), génétique et états pathologiques (p. 6), insuffisances rénale et hépatique (p. 7-8), interactions (p. 8-11) ; deux figures (p. 3, 4) |
| `src-fc-bmct-var-2526` (`FC2526`) — Ronéosaure, « FC n°5 facteurs de variabilité » (23 p.) | 2025-26 | `SRC["cours"]` : un appoint, la source des 18 cartes absentes du cours 2026-27 et de douze figures |
| `src-annales-bmct-var` — « Facteurs de variabilité de la réponse du médicament » (8 p.) | 2024-25 | 8 sessions, table p. 8 |
| `src-annales-bmct-risque` — « Risque médicamenteux, rapport bénéfice-risque » (21 p.) | 2024-25 | 7 QCM d'interactions ; table p. 19-21 |
| `src-annales-bmct-meta` — « Pharmacologie du métabolisme » (9 p.) | 2024-25 | le cas de la metformine ; table p. 7-8 |
| `src-sujets-bmct-2425` — Sujets de BMCT 2024/2025, session 1 (20 p.) | 2024-25 | les Q17, Q18, Q20 et la QR2, sujet sans corrigé |

Une carte relue sur le cours de l'année porte `page` (et `fiche=FC2` pour la
partie 2) : elle cite la ronéo à cette page, sans badge « Cours 2025-26 ». Les
textes citent « partie 1, p. 5 », « partie 2, p. 9 », et « FC 2025-26, p. 21 »
pour ce que l'année ne reprend pas. Une annale dont la réponse se lit dans la
ronéo de l'année porte aussi `page` : 30 annales sur 35 citent cette page en
source secondaire. Les cartes absentes citent la FC 2025-26 à leur page
(`fiche=FC2526`).

Lus en appoint, sans être déclarés : le cours 2023-24 du même professeur
(Charonéo, n°6) ; l'errata des cours 2025-26 et celui des annales. Les en-têtes
des ronéos, des erratas et des polycopiés portent des noms d'étudiants : aucun
n'est repris.

Pour que les deux ronéos s'ouvrent dans l'application : `copier_les_cours.py`
avec le dossier des ronéos du 19/10, hors du bac à sable.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 67 | 67 |
| QRU (marches Simple) | 31 | 31 |
| Texte à trous | 15 | 74 |
| QROC | 14 | 14 |
| Recto-verso | 10 | 10 |
| Lexique | 9 | 9 |
| Schéma cliquable | 2 | 9 |

Dont **35 annales** sur 13 sessions (inchangées, mot pour mot) et **38 marches**
de l'échelle. Les 104 notes de cours : **86 citent la ronéo 2026-27**, 18 sont
« Absent du cours 2026-27 ».

Sept thèmes, dans l'ordre du cours ; leurs libellés sont tous dans
`THEME_LABELS` : `variabilite`, `enfant-age`, `poids-obesite`,
`grossesse-medicament`, `pharmacogenetique`, `insuffisances`, `interactions`.

## Ce qui a changé contre le Ronéosaure (relecture du 19/10/2026)

Les deux ronéos suivent le plan de la FC 2025-26 et le précisent :

- **Nouveau, et carté** : les essais cliniques — population uniforme, phase 3,
  effets rares invisibles (`var-qc-essais`) ; le nouveau-né et le nourrisson —
  classes d'âge, rein, enzymes, eau (`var-qc-nouveau-ne`) ; le poids d'adulte
  d'un enfant ne suffit pas, pipettes, données pédiatriques (`var-qc-enfant-poids`) ;
  les formes galéniques, l'écrasement, les listes OMEDIT et HUG
  (`var-qc-galenique-enfant`) ; les tétracyclines (`var-qr-tetracyclines`) ; les
  précautions chez le sujet âgé, l'AOD qui s'accumule sans bruit
  (`var-qc-sujet-age-precautions`) ; la liste de Laroche (`var-qr-laroche`) ; la
  fragilité et ses signes précurseurs (`var-qc-fragilite`) ; les poids extrêmes
  (`var-qc-poids-extremes`) ; les risques de la grossesse, le mycophénolate, les
  25 ans pour prouver une toxicité (`var-qc-risques-grossesse`) ; les stades de
  l'insuffisance rénale (`var-fa-stades-ir`) ; l'insuffisance rénale aiguë et la
  canicule (`var-qc-ira-canicule`) ; l'évaluation de l'insuffisance hépatique
  (`var-qc-ih-indicateurs`) ; le ritonavir et la P-gp (`var-qc-ritonavir`) ; la
  conduite devant une interaction (`var-qc-iam-pratique`). 17 notes nouvelles en
  tout, avec deux termes de lexique.
- **Réécrites** (texte, option ou réponse) : sept textes à trous
  (`var-fa-trois-risques`, `-ages`, `-enfant`, `-sujet-age-pd`, `-fragilite`,
  `-grossesse-pk`, `-specificite`), l'option C de `var-qc-enfant` (la gentamicine
  de 2026-27 remplace la ceftazidime de 2025-26), l'option C de `var-ech-s30`
  (la « contre-indication relative » existe en 2026-27 : c'est l'association
  déconseillée), les QROC `var-qr-comprime` (6 ans, non plus 6-7) et
  `var-qr-inappropries`, les versos de `var-rv-pd-pk` et `var-rv-ir-ih`. Toutes
  les justifications citent désormais la page de l'année.
- **Les figures** : cinq viennent de la ronéo 2026-27, plus nettes — les quatre
  âges de la vie (partie 1, p. 4), l'exposition-réponse de l'enfant (p. 6), le
  déclin des fonctions (p. 9), l'héparine selon l'IMC (partie 2, p. 4), sous
  leur nom d'avant, et la fragilité (partie 2, p. 3), dans
  `var-fragilite-2627.png`. Les douze autres restent celles de la FC 2025-26 ; la
  légende cite la page de 2026-27 qui reprend la même diapositive (le sujet âgé
  et le sujet jeune, réannoté à la main en 2026-27, p. 10 ; les modifications
  pharmacodynamiques ; les poids extrêmes ; induction et inhibition, à laquelle
  la partie 2, p. 11 renvoie).

## Absent du cours 2026-27

Dix-huit cartes, dans `ABSENTS_2026` : le générateur les tague `absent-2026` et
écrit « Absent du cours 2026-27 » en tête de leur explication. Elles citent la
FC 2025-26 à leur page. La contre-relecture du 19/10 en a sorti deux, dont la
ronéo 2026-27 tient le sujet : `var-qc-periodes` (les deux risques de la
grossesse, partie 2, p. 5-6) et `var-qc-autres-facteurs` (alimentation,
tolérance, dépendance, partie 1, p. 4 ; le tabac, partie 2, p. 11) ; leurs
propositions de 2025-26 le disent une à une.

| Notion de la FC 2025-26 | Cartes |
|---|---|
| Effets indésirables, preuve de l'activité (Spasfon, p. 3) | `var-qr-effets-indesirables` |
| Revoir le patient à quinze jours (p. 9) | `var-qr-revoir` |
| Antibiotiques au-delà de 120 kg ; chirurgie bariatrique (p. 10-11) | `var-qr-antibiotiques`, `var-qc-bariatrique` |
| Organogenèse semaine par semaine, AVK (p. 14) | `var-fa-organogenese` |
| 5-FU et DPD (p. 15) | `var-qr-dpd` |
| Codéine et CYP2D6 (p. 15-16) | `var-rv-allaitement-codeine`, `var-ech-s24`, `var-ech-m6` |
| Seuil de 30 mL/min (p. 16) | `var-qr-dfg` |
| L'exemple de la tolérance et de la dépendance, le paracétamol (p. 22) | `var-rv-tolerance-codeine`, `var-fa-paracetamol` |
| Pamplemousse, millepertuis, alcool, repas (p. 21-23) | `var-fa-plantes`, `var-rv-alcool`, `var-ech-s4`, `-s6`, `-s7`, `-s8` |

Une proposition isolée de 2025-26, dans une carte que l'année porte, le dit dans
sa justification (« FC 2025-26, p. 15, absent du cours 2026-27 ») : les femmes
enceintes écartées des essais et le Spasfon (`var-qc-introduction` B, D), la
rythmicité de l'enfant (`var-qc-posologie-enfant` B, C), les IEC et ARA2
(`var-qc-depakine-iec` C, E), la DPD et le méthotrexate (`var-qc-5fu` B, E), le
paracétamol de l'insuffisant hépatique (`var-qc-ih` E), les abaques à 120 kg
(`var-qc-obesite` D), l'évolution de la perméabilité placentaire
(`var-qc-placenta-ains` B), la P-gp et les anticancéreux (`var-qc-pgp` C), les
semaines de l'organogenèse, le tout ou rien et les AVK (`var-qc-periodes` B, C,
D), le repas, le paracétamol, les plantes et les benzodiazépines
(`var-qc-autres-facteurs` B, C, D, E). Le
CYP2D6 et la codéine sont au cours 2026-27 de pharmacodynamie générale
(`bmct_pharmacodynamie`).

## Les erreurs des ronéos 2026-27

Le tableau d'erreurs BMCT de la promo ne relève rien sur ces deux ronéos au
19/10 : toutes sont trouvées en relisant. Chacune est portée par un
`ATTENTION` à son genre, dans la carte qui tient la notion, et passe dans
`contenu/ERRATA_RONEOS_2026-27.md`.

| Ronéo, page | La ronéo dit | Ce qui est juste | Genre | Carte |
|---|---|---|---|---|
| 1, p. 3 | un effet « rare » touche 1 personne sur 10 000, voire 100 000 | « rare » = 1/10 000 à 1/1 000, « très rare » < 1/10 000 (CIOMS, guide du RCP) ; le raisonnement tient | douteux | `var-qc-essais` B |
| 1, p. 4 | l'obésité parmi les états pathologiques fréquents | le schéma du professeur met le « métabolisme » parmi les états physiologiques, le plan de la ronéo aussi ; à l'examen, comme le schéma | douteux | `var-fa-facteurs` |
| 1, p. 4 | nouveau-né « 0 à 2 mois », nourrisson dès 2 mois | nouveau-né à terme jusqu'à 28 jours, nourrisson de 28 jours à 23 mois (diapositive FC 2025-26, p. 4 ; ICH E11) | prise de notes | `var-qc-nouveau-ne` A |
| 1, p. 5 | filtration de l'adulte « à 6 mois » | « au bout d'un an », dit la même page ; DFG adulte entre 1 et 2 ans (EMEA, CPMP/PEG/35132/03) | prise de notes | `var-qc-nouveau-ne` B |
| 1, p. 5 | dose plus forte car « la distribution de médicaments lipophiles est compliquée » | c'est l'eau : Vd par kilo plus grand des hydrophiles (gentamicine ; Pacifici 2010) | douteux | `var-qc-nouveau-ne` D |
| 1, p. 5 | « l'antadys (ibuprofène) » | l'Antadys est du flurbiprofène, à partir de 15 ans (RCP, BDPM) | prise de notes | `var-qc-enfant-poids` A |
| 1, p. 6 | « moins d'efficacité » faute des mêmes concentrations ; « plus d'efficacité (la puissance […] différente) » | la diapositive de la page : un effet maximal plus bas à concentration égale ; puissance et efficacité séparées | prise de notes | `var-qc-posologie-enfant` D |
| 1, p. 6 | le canal artériel « du cœur droit au cœur gauche », fermé « au 1er cri » (repris de la ronéo 2025-26) | il relie l'artère pulmonaire à l'aorte ; fermeture fonctionnelle en 12-24 h, anatomique en 2-3 semaines (StatPearls) | douteux | `var-qr-canal-arteriel` |
| 1, p. 6 | méningite de l'enfant : « mal de ventre » | agitation, irritation, refus alimentaire (cours 2023-24), signes « diminués » (FC 2025-26) ; nourrisson : fièvre, irritabilité, fontanelle bombée (Vidal) | prise de notes | `var-qc-ei-enfant` D |
| 1, p. 7 | tétracyclines : « marche que pendant la grossesse » | dents en formation, de la seconde moitié de la grossesse à 8 ans (RCP doxycycline) | prise de notes | `var-qr-tetracyclines` |
| 1, p. 7 | IRS : « flambée de suicides » « dans les années 2010 » | alertes de 2003-2004 (FDA, 2003 et 15/10/2004) ; Afssaps 2005 ; même datation en 2025-26 | **cours** | `var-qc-ei-enfant` B |
| 1, p. 7 | IRS « contre-indiqués » avant 15 ans | déconseillés dans la dépression avant 18 ans (Afssaps 2005), fluoxétine dès 8 ans | douteux | `var-qc-ei-enfant` (explication) |
| 1, p. 7 | acidité gastrique « pH = 4 » (phrase recopiée de la ronéo 2025-26) | pH à jeun 1 à 2 (Dressman, Pharm Res 1990) | douteux | `var-qc-galenique-enfant` D |
| 2, p. 4 | « IMC < 30 = dose normale », « IMC > 30 = augmentation des doses » : 30 sans conduite | le tableau de la même page (GIHP-GFHT, repris de la diapositive) dit « IMC ≥ 30 kg/m² » : on augmente à partir de 30 ; l'image fait foi | prise de notes | `var-qr-imc` (explication) |
| 2, p. 5 | fœtotoxicité : « modification de la formation des organes » | croissance et fonctionnement des organes formés (FC 2025-26, p. 14) | prise de notes | `var-qc-risques-grossesse` B |
| 2, p. 5 | ibuprofène : « toxicité rénale (fermeture du canal artériel…) » | le canal artériel est une atteinte cardiovasculaire, l'oligoamnios l'atteinte rénale (FC 2025-26, p. 14) | prise de notes | `var-qc-placenta-ains` E |
| 2, p. 6 | risque malformatif « 20 % soit 1 sur 5 », neurodéveloppemental « 50 % soit 1 sur 2 » (sous le mycophénolate) | Dépakine : ~11 % et 30-40 % (ANSM) ; mêmes chiffres en 2025-26 et 2023-24 ; à l'examen, 1 sur 5 et 1 sur 2 | **cours** | `var-qc-depakine-iec` D |
| 2, p. 6 | « l'élimination de la créatine » | la créatinine (même phrase) | prise de notes | `var-qc-ir` B |
| 2, p. 7 | « ponction rénale » | fonction rénale | prise de notes | `var-qc-ira-canicule` E |
| 2, p. 8 | « acidose statique » | acidose lactique (FC 2025-26 ; corrigé 2022/2023) | prise de notes | `var-qc-metformine` C |
| 2, p. 8 | « facteur sain » | facteur V | prise de notes | `var-qc-ih-indicateurs` B |
| 2, p. 9 | Kaletra : « le baxiloide » | le lopinavir (RCP du Kaletra) | prise de notes | `var-qc-ritonavir` (explication) |
| 2, p. 9 | le ritonavir du Kaletra présenté comme bloqueur de la P-gp | surtout inhibiteur du CYP3A4 qui métabolise le lopinavir (RCP, 5.2) | douteux | `var-qc-ritonavir` B |
| 2, p. 10 | « cytochrome P453-A14 » | CYP3A4 | prise de notes | `var-qc-iam-pratique` (explication) |
| 2, p. 11 | l'inducteur augmente « tous les cytochromes » | non spécifique, plusieurs mais pas tous (CYP2D6 ; Zhou 2009) ; à l'examen, « non spécifique » | douteux | `var-fa-specificite` |

Sans carte, parce qu'aucune n'en dépend : « 7 000-9 000 morts de cet été »
(partie 2, p. 7, invérifiable), « cytochrome C 1 à 4 » (p. 11, phrase
incompréhensible), et les coquilles (« marché thérapeutique », « antécédent
parient », « START and STOP » pour les listes STOPP et START, que la carte
`var-qr-laroche` nomme juste).

**Les erreurs du Ronéosaure 2025-26** restent dites par un `ATTENTION` nu, sans
genre, et n'entrent pas dans la liste : l'organogenèse « 0 à 2 mois » et les
membres « 7e et 8e semaine » (`var-fa-organogenese`, `var-qc-periodes` A), les
« anticoagulants de type ADK » (`var-fa-ir-demarche`), « l'absorption […] au
niveau de l'estomac » (`var-qc-bariatrique` B), les IEC et ARA2 « au bout de
6 mois » (`var-qc-depakine-iec` C), la DPD « divisée de moitié »
(`var-qc-5fu` C), la codéine (« P452D6 », « rapide », « 20 % » : 
`var-rv-allaitement-codeine`, `var-ech-s24`, `var-ech-m6`), la dépendance par
métabolisme (`var-rv-tolerance-codeine`), la P-gp « protéine des flux » rangée
parmi les enzymes (`var-qc-pgp` D, les marches `s34`, `s35`, `m9`, l'annale
2020/2021 S1 Q19 E).

## Ce que les annales ont dicté

| Savoir | Questions |
|---|---|
| Le sujet âgé : rein, foie, volume de distribution, interactions, révision de l'ordonnance | 2020/2021 S1 Q13 et 2018/2019 Q8 (mot pour mot), 2019/2020 Q11, 2017/2018 Q9 ; effets centraux, fragilité, observance : 2024/2025 S1 Q20 |
| Les facteurs de variabilité : le patient, le médicament, les autres facteurs ; physiologiques ou pathologiques | 2024/2025 S1 Q17 et Q18 |
| Induction et inhibition enzymatiques : interaction pharmacocinétique, caractéristiques, tableau | 2024/2025 S1 QR2 |
| L'enfant : cibles, système nerveux, voie IM, masse grasse, induction maternelle | 2021/2022 Q13, 2020/2021 S2 Q11, 2018/2019 Q7 |
| Ce qui modifie l'effet des médicaments | 2021/2022 Q15, 2020/2021 S2 Q12, 2017/2018 Q10 |
| Le CYP3A4 : inhibiteurs, inducteurs | 2020/2021 S1 Q18, 2019/2020 Q16, 2020/2021 S2 Q15 |
| La P-gp | 2020/2021 S1 Q19, 2019/2020 Q17 |
| Le polymorphisme du CYP2D6 | 2020/2021 S1 Q12, 2019/2020 Q10 |
| Ce qu'est une interaction : deux à deux, PD ou PK, cliniquement significative | 2021/2022 Q14 ; risque : 2021/2022 S2 Q.20, 2018/2019 S2 Q.15, 2016/2017 S1 Q14 et Q15, 2016/2017 S2 Q16 et Q18, 2015/2016 S1 Q17 (= 2016/2017 S2 Q18) |
| Le cas de la metformine | 2022/2023 S1 QROC 1 a-c (métabolisme) |
| Les points d'une interaction pharmacocinétique | 2020/2021 S1 QROC n°2 (aussi au polycopié de risque) |

**Les copies, non recartées** : dans le polycopié de variabilité, la « 2023/2024 »
Q.9 (déjà `pdg-an-2324-q9`), Q.10 et Q.11 (suivi thérapeutique, FC3) ; la
« 2022/2023 » Q6, Q7 et Q8, mot pour mot des questions de 2018/2019 — l'en-tête
est erroné, et l'explication des deux cartes de 2018/2019 le dit. Le QROC2 de
2020/2021 S1 du polycopié de risque est le QROC des interactions : une seule
carte, ici.

**Les clés relues contre le cours 2026-27** : aucune n'est contredite ; la ronéo
de l'année confirme le sujet âgé, l'enfant, la P-gp « protéine d'efflux » (ce
qui conforte la clé de 2020/2021 S1 Q19 E), les niveaux des interactions et leur
signification clinique.

## Les clés qui ne sont pas reprises telles quelles

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2020/2021 S1 QROC n°2 (interaction pharmacocinétique) | aucune (« AUCUNE CORRECTION, vérifier le cours ») | verso déduit du cours (partie 2, p. 9-11 ; FC 2025-26, p. 19-22), `officielle=False` | la table ne donne rien ; le polycopié de risque, qui pose la même question, non plus |
| 2024/2025 S1 Q17 (`var-an-2425s1-q17`) | aucune (sujet sans corrigé ; surlignée ACD) | **ACD**, `officielle=False` | le patient, le médicament, l'alimentation (partie 1, p. 4) ; bénéfices et risques sont ce qui varie (p. 3) |
| 2024/2025 S1 Q18 (`var-an-2425s1-q18`) | aucune (sujet sans corrigé ; surlignée **ABCE**) | **ABE**, `officielle=False`, ATTENTION sur C, `CONFLITS` | âge, grossesse, génétique : la physiologie du patient ; l'insuffisance rénale est un état pathologique, l'addiction un « autre facteur » (partie 1, p. 4). La correction surlignée ajoute C : le cours la contredit |
| 2024/2025 S1 Q20 (`var-an-2425s1-q20`) | aucune (sujet sans corrigé ; surlignée A) | **A**, `officielle=False` | BHE plus perméable, effets centraux (partie 2, p. 2) ; clairances diminuées, effets indésirables, robuste-fragile-dépendant, observance difficile |
| 2024/2025 S1 QR2 a-c (`var-an-2425s1-qr2a` à `-qr2c`) | aucune (sujet sans corrigé) | réponses construites sur le cours, `officielle=False` | interactions PD et PK (partie 2, p. 9-10), niveaux (p. 10), le tableau de la diapositive (FC 2025-26, p. 21), auquel renvoie la partie 2, p. 11 |

Toutes les autres clés sont reprises telles quelles. Quatre points sont discutés
dans la carte (`ATTENTION`, déclarés dans `CONFLITS`), sans changer la clé :

| Question | Clé | Le point | À l'examen |
|---|---|---|---|
| 2024/2025 S1 Q18 C | ABE (déduite) | l'insuffisance rénale, donnée vraie par la correction surlignée (officieuse) : le schéma du professeur et la ronéo 2026-27 la rangent parmi les états pathologiques | faux |
| 2020/2021 S1 Q19 E | BD | « intervient dans la métabolisation » donnée fausse : la clé est juste ; la ronéo 2025-26 se trompait, la ronéo 2026-27 dit « protéine d'efflux » | faux |
| 2017/2018 Q10 B | ACDE | le jus de pomme, donné sans effet : les jus de fruits, pomme comprise, diminuent l'absorption de la fexofénadine (Dresser, Clin Pharmacol Ther 2002) | faux, comme la clé |
| 2017/2018 Q10 E | ACDE | « tomates et anti-vitamine K » : le principe est juste, l'exemple faible | vrai |

Les propositions absentes des cours, reprises comme la clé et justifiées sur
des sources sûres : la masse grasse du prématuré (Friis-Hansen, 1961 ; Bansal
et al., Pediatr Med 2024), la maturité du système nerveux à 6 mois, la voie
intramusculaire de l'enfant (Kearns, NEJM 2003), la P-gp rénale, inhibée par le
pamplemousse, et la résistance par mutation de son gène ; le captopril
(2020/2021 S1 Q12 C, 2019/2020 Q10 C), l'exemple classique de la
pharmacogénétique des années 1980 (Oates et al., Br J Clin Pharmacol 1982).

## Les schémas et les figures

**Dix-sept figures**, captures de diapositives (1000 px de large au plus, 256
couleurs) : cinq de la ronéo 2026-27 (voir plus haut), douze de la FC 2025-26 —
la courbe des zones thérapeutiques (p. 2), le schéma des facteurs (p. 3), les
classes d'âge (p. 4), sujet âgé contre sujet jeune (p. 7), les deux diapositives
du sujet âgé (p. 8), l'obésité (p. 10), le placenta (p. 13), les périodes
critiques (p. 14), l'insuffisance rénale (p. 16), le foie (p. 18), induction et
inhibition (p. 21). Aucune photographie de patient. La ronéo 2026-27 n'a pas
d'autre figure (sa p. 12 de la partie 2 est une image sans rapport avec le
cours).

**Deux schémas cliquables** (`schemas.py`), chacun avec sa version légendée en
correction :

| Fichier | Ce qu'on clique | Pourquoi ce dessin |
|---|---|---|
| `zones-therapeutiques.svg` | zone toxique, zone thérapeutique, zone d'inefficacité, le pic qui suit la prise de 168 h, le creux de 192 h | la courbe de la FC 2025-26 (p. 2), recalculée ; la marge thérapeutique est au cours 2026-27 (partie 1, p. 8) |
| `grossesse-risques.svg` | le « tout ou rien », l'organogenèse, la période fœtale avant le 6e mois, la période où tout AINS est contre-indiqué | la figure de la FC 2025-26 (p. 14), en semaines d'aménorrhée ; le cours 2026-27 en garde les deux risques, malformatif puis fœtotoxique (partie 2, p. 5-6) |

**Deux figures redessinées** pour les corrections : `interactions-pd-pk.svg`
(partie 2, p. 9-11 : « bénéfique ou délétère », la contre-indication relative)
et `pgp-efflux.svg` (partie 2, p. 9, 11 ; l'induction « non spécifique » n'y dit
plus « tous les CYP »).

**93 QCM sur 98 illustrés (95 %)**, 120 notes sur 148. Sans figure :
`var-qc-ei-enfant`, `var-qc-galenique-enfant`, `var-qc-5fu` (aucune figure
du cours ne montre ce qu'elles demandent) et les deux annales du CYP2D6.
`var-qc-autres-facteurs` prend le schéma des facteurs (contre-relecture du
19/10).

## L'échelle : Simple → Moyen → Annale

L'échelle du pilote de l'immunité innée (C20, 16/10/2026) : 31 cartes Simple
(`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et
7 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à
lettres en correction). Chaque annale garde la figure du cours et reçoit son
schéma (`diagramme=`) ; les QROC reçoivent le schéma nu.

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `variabilite` | 6 | 1 | 5 |
| `enfant-age` | 12 | 1 | 8 |
| `pharmacogenetique` | 1 | 1 | 2 |
| `insuffisances` | 2 | 1 | 3 |
| `interactions` | 10 | 3 | 17 |

**Relue le 19/10/2026 sur les deux ronéos 2026-27** : 32 marches citent leur
page de l'année ; six (`s4`, `s6`, `s7`, `s8` — repas, pamplemousse,
millepertuis, alcool — et `s24`, `m6` — la codéine) n'ont plus de version
2026-27 et sont dans `ABSENTS_2026`. Une seule marche change de proposition :
`var-ech-s30` C, « la contre-indication relative » devenue « la
contre-indication », parce que la ronéo 2026-27 nomme ainsi l'association
déconseillée (partie 2, p. 10) — la clé reste B. Le schéma `ech-variabilite`
(`schemas.py`, `ECH_VARIABILITE`) garde ses cases ; sa légende cite les deux
ronéos et la FC 2025-26, ses titres perdent leurs pages, et la case de
l'induction dit « non spécifique : CYP et P-gp » au lieu de « toutes les
enzymes ». Les clés Simple restent réparties entre A, B et C, les Moyen ont de
une à trois vraies, chaque marche finit par « ↗ Prépare ».

**Sans marche** : 2122-q13, 2021s2-q11, 1819-q7 C ; 2021s1-q12, 1920-q10 A, C,
D, E ; 2021s1-q18, 1920-q16 B-E ; 2021s2-q15 A, B, D, E ; 1920-q17 D, E ;
1718-q10 B ; 2122s2-q20 A, D, E ; 1617s1-q14 B ; 1617s2-q18 A, D ; 1516s1-q17
A, D ; 1617s1-q15 A ; 1617s2-q16 E : absents des cours (voie IM, CYP2D6, listes
du CYP3A4, deux à deux, essais, topique, antagonisme). 2425s1-q17 C : le bloc
médicament n'a pas de case propre.

## Le lexique

Neuf termes ; aucun n'existait ailleurs (vérifié contre les `lex-*` de tous les
paquets). Pages mesurées dans le texte des PDF (`chercher_pages.py`) :

| Terme | Origine | Pages |
|---|---|---|
| Déprescription | latin de- + praescriptio | FC 2025-26, p. 4, 9 (le mot n'est plus en 2026-27) |
| Fœtotoxicité | latin fetus + grec toxikón | partie 2, p. 5, 6 ; FC 2025-26, p. 14 |
| Bariatrique | grec báros + iatrós | FC 2025-26, p. 10, 11 |
| Prématuré | latin praematurus | partie 1, p. 6 ; FC 2025-26, p. 5 |
| Transplacentaire | latin trans + placenta | partie 2, p. 6 ; FC 2025-26, p. 13 |
| Acidose | latin acidus + grec -ōsis | partie 2, p. 8 ; FC 2025-26, p. 7 |
| Observance | latin observantia | partie 1, p. 11 ; partie 2, p. 2 ; FC 2025-26, p. 9 |
| **Pharmacogénétique** (nouveau) | grec phármakon + genetikós | partie 1, p. 3 |
| **Nourrisson** (nouveau) | latin nutritio | partie 1, p. 4 |

Les deux termes nouveaux et la racine `génét-` (grec γενετικός) sont proposés à
la table commune (`etymologies.json`), vérifiés sur le Wiktionnaire, le TLFi, le
Bailly et le Gaffiot ; leurs textes sont déjà écrits dans la forme que
`appliquer_etymologies.py` produirait. `pharmac(o)-` et `nutrire (latin)`
reprennent les clés existantes. `Gériatrie` et `Polymédication` sont déjà
accueillis par `semio_age`.

## Décisions prises en route

- **`EXAMENS` n'est pas déclaré** : le partiel du 4/11 se règle dans
  l'application.
- **Les cartes absentes citent la FC 2025-26 à leur page** (`fiche=FC2526`),
  plutôt que sans page : l'écran montre « Cours 2025-26 · p. 15 », et la source
  ne porte pas `chapitre=`.
- **Les figures de 2026-27 remplacent leurs reprises de 2025-26 sous le même
  nom** quand c'est la même diapositive, plus nette ; la diapositive « sujet âgé
  et sujet jeune » reste celle de 2025-26, la ronéo 2026-27 l'ayant réannotée à
  la main.
- **Les chiffres de la Dépakine** (1 sur 5, 1 sur 2) sont rattachés à la Dépakine,
  bien que la ronéo 2026-27 les imprime sous l'exemple du mycophénolate : le même
  professeur les donnait pour la Dépakine en 2025-26 et en 2023-24, et le risque
  « neurodéveloppemental » n'est pas celui du mycophénolate.
- **La contre-relecture du 19/10/2026** (un second relecteur, sur les PNG des
  deux ronéos) a gardé la relecture et corrigé six points : `var-qc-periodes`
  et `var-qc-autres-facteurs` sortent de `ABSENTS_2026` (page de 2026-27,
  propositions de 2025-26 dites une à une ; la seconde prend le schéma des
  facteurs) ; `var-qr-imc` porte l'`ATTENTION (prise de notes)` de l'IMC > 30
  contre le tableau ≥ 30 (l'image fait foi) ; les annales 2021/2022 Q15,
  2020/2021 S2 Q12 et 2017/2018 Q10 citent la partie 1, p. 4 (les facteurs, le
  patient qui « boit », p. 2) ; `var-qc-5fu` C et `var-qr-dpd` renvoient au
  suivi thérapeutique du 28/09/2026 (p. 2), le « cours précédent » de la
  ronéo ; la diapositive des 20 % d'inappropriés est attribuée à la FC 2025-26
  (p. 8), dont la partie 2 reprend les puces.
- **Le seuil bas du schéma des zones** est à 90 mg/L (la figure le place vers
  105), pour que le creux à l'équilibre reste visiblement dans la zone
  thérapeutique ; c'est un schéma, pas une mesure.

## Sans illustration

L'objectif de la moitié des QCM est atteint (94 %) : rien à signaler.

## À relire

**Aucune carte `a-relire`** : chaque carte cite sa page, dans l'une des deux
parties de la ronéo 2026-27 ou, pour les dix-huit cartes absentes, dans la FC
n°5 2025-26.

## Questions pour Vincent

- L'**obésité** : la ronéo 2026-27 la range parmi les états pathologiques
  (partie 1, p. 4), le schéma et le plan du professeur sous le métabolisme,
  physiologique. Les cartes suivent le schéma ; le confirmer en cours ou avec un
  camarade qui a la diapositive ?
- Les **chiffres de la Dépakine** (1 sur 5, 1 sur 2) imprimés sous le
  mycophénolate : la diapositive de 2026-27 les rattache-t-elle bien à la
  Dépakine ?
- Faut-il des marches pour les notions **nouvelles** de 2026-27 (nouveau-né,
  fragilité, poids extrêmes, insuffisance rénale aiguë, conduite devant une
  interaction) ? Aucune annale ne les teste encore.

## Régénérer

```powershell
..\..\..\app\.venv\Scripts\python.exe generer.py
```
