# Introduction à la sociologie : impacts des phénomènes sociaux sur la santé — paquet SSH

77 notes, 139 cartes. Chapitre `chap-ue-ssh-fc10` de l'UE SSH, `ordre=12`.
Cours de la **Pr M. Darmon, le 28/11/2025** : FC n°12 « Introduction à la
sociologie » (6 p.) et FC n°13 « Sociologie » (10 p., la dernière blanche) du
Ronéosaure 2025-26. **Une annale** : la QROC 8 du sujet de SSH 2024/2025 (le
gradient social de santé), déposé le 15/10/2026. Examen du 6 janvier 2027,
écrit, « 10 QROC + 1 QR ».

**18/10/2026** : 2 recto-verso du sujet de SSH 2025/2026 (examen du
09/01/2026, sans corrigé) — QROC 6, QROC 7 ; voir « Le sujet 2025/2026 ».

**Une fiche provisoire.** Le ronéo 2026-27 de ce cours n'est pas paru : le
chapitre est carté sur le Ronéosaure 2025-26 (décision de Vincent du 02/10),
et le ronéo de l'année corrigera les cartes à sa parution. Les deux sources
portent « Ronéosaure 2025-26 » dans leur auteur : chaque carte prend le badge
« Cours 2025-26 ». Aucune carte ne dit « Absent du cours 2026-27 », et les
erreurs du Ronéosaure sont dites par un ATTENTION sans genre (précédent
d'`immuno_innee`) ; la liste `contenu/ERRATA_RONEOS_2026-27.md` ne concerne
que les ronéos 2026-27.

**Un chapitre pour deux fiches.** Même jour, même professeure : la FC n°13
reprend exactement où s'arrête la FC n°12 (le parcours post-AVC, « I - Classe
de santé »), et sa conclusion referme la vignette de l'HTA qui ouvrait la
FC n°12. Le squelette nomme ce chapitre `fc10`, « Inégalités sociales en
santé » — le cours du Pr Devinant en 2024-25, sur le même sujet.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 17 | 17 |
| Texte à trous | 14 | 70 |
| QROC | 22 | 22 |
| Recto-verso | 12 | 12 |
| Schéma cliquable | 3 | 9 |
| Lexique | 9 | 9 |

Le format de l'examen (QROC et QR, aucun QCM) dicte la part des QROC, des
textes à trous et des recto-verso ; les QCM portent les pièges (le couple
santé/médecine, les trois moments, assignation et hiérarchisation, le sens des
écarts d'espérance de vie). Chaque QCM a une justification par proposition.

Sept thèmes, tous nouveaux, dans l'ordre du cours :

| Clé | Libellé | Notes |
|---|---|---|
| `sociologie-sante` | Sociologie de la santé : objets et méthodes | 12 |
| `inegalites-sociales` | Les inégalités sociales de santé | 10 |
| `classe-sante` | Classe sociale et santé | 12 |
| `genre-sante` | Genre et santé | 10 |
| `esperance-vie` | Espérance de vie, longévité et morbidité | 8 |
| `reeducation-avc` | Le parcours post-AVC, entre classe et genre | 11 |
| `biologique-social` | L'articulation du biologique et du social | 3 |

Les sept libellés sont à ajouter à `THEME_LABELS`
(`app/src/med_engine/application/scopes.py`, bloc « ssh ») : c'est le seul
échec attendu de `tests/test_paquets.py` pour ce chapitre. Une carte porte en
plus le tag `edn` (déjà libellé).

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-ssh-sociologie-1` — « FC n°12 Introduction à la sociologie » (6 p.), `SSH/…` | **2025-26** | **la base**, partie 1 : `SRC["fiche"]` ; vignette, sociologie de la santé et de la médecine, méthodes, trois moments, ISS, classe et gradient, parcours post-AVC ; cinq diapositives |
| `src-fc-ssh-sociologie-2` — « FC n°13 Sociologie » (10 p.), `SSH/…` | **2025-26** | **la base**, partie 2 : `fiche=` sur ses cartes ; rééducation, cancers, gradient inversé, genre, espérance de vie, parcours genrés, conclusion ; aucune figure |
| polycopié « SSH 10 - Inégalités sociales en santé » | 2024-25 | « Pas d'annales sur ce cours » : non déclaré, rien à citer (`annales.py` le dit) |
| `src-sujets-ssh-2425` — « Sujets de SSH 2024/2025, session 1 » (examen du 10/01/2025, 1 QR et 10 QROC, sans corrigé), déposés le 15/10/2026 | 2024-25 | la source de la session 2024/2025 S1 et `SRC["annales"]` : la QROC 8, seule annale du chapitre ; déclarée à l'identique dans tous les chapitres de SSH qui en cartent une question |
| `src-cours-ssh-inegalites-2425` — Ronéosaure, « FC n°10 - Inégalités sociales en santé », Pr Devinant (9 p.) | 2024-25 | appoint : le cours de l'année de l'annale (le gradient, les Whitehall studies, le Black report, p. 4-5 ; ISS et pauvreté, p. 7), cité dans le texte de la carte |
| errata du cours 2025-26 (`Erratas SSH.docx`) et des annales 2024-25 | — | aucune entrée sur ces deux FC ni sur ce polycopié |

Les deux fiches sont déclarées avec `chapitre=` : elles ne s'ouvriront dans
l'application qu'une fois copiées dans le dossier des PDF de cours
(`outils/copier_les_cours.py`, question commune aux vagues BMCT, immunologie et
SSH du Ronéosaure 2025-26). Le nom de la FC n°12 est en NFD sur le disque ; le
`chemin_relatif` est écrit en NFC.

Vérifications hors du cours, citées dans la carte qui s'en sert : Insee
Première n°1687 (2018 : 13 ans d'écart chez les hommes, 8 chez les femmes),
n°1584 (2016 : espérance de vie à 35 ans des cadres et ouvriers, hommes et
femmes, 2009-2013), bilan démographique 2023 (85,7 et 80,0 ans) ; Burgess,
*Circulation: Cardiovascular Interventions*, 2022 ; Vimalananda et al.,
*Women's Health Issues*, 2011 ; Loretti, *La fabrique des inégalités sociales
de santé*, Presses de l'EHESP, 2021 ; Becker et al., *Boys in White*, 1961 ;
recommandations AHA « Prevention of Stroke in Women » (Bushnell et al., 2014) ;
l'étymologie (TLFi par l'API du portail CNRTL, Gaffiot, Bailly, Wiktionnaire).

## Ce que le cours a dicté

- **Ni gris ni rouge** dans les deux fiches (vérifié à l'extraction des
  couleurs). Le gras du ronéo — sociologie, rapports sociaux, articulation du
  biologique et du social, « gradient de santé (notion importante) »,
  consensus épidémiologique, accès aux soins — a ses cartes.
- **Une consigne** : les chiffres de l'évolution de l'écart d'espérance de vie
  entre femmes et hommes « ne sont pas à retenir » (FC n°13, p. 6). Ils vivent
  dans un seul texte à trous, `soc-fa-ecart-histoire`, tagué `edn` ; l'idée
  — un avantage qui varie avec l'histoire n'est pas seulement biologique — est
  au programme (`soc-qc-esperance-genre` C, `soc-qr-pratiques-risque`). Les
  autres chiffres (13 ans, 6 ans, 85,7/80,0, un an, 4,6/2,7 ans, délai × 3)
  restent cartés.
- **Pas cartés** : la diapositive de la p. 5 garde sa partie « méthodologie »
  mais perd la couverture du livre de la professeure (*Réparer les cerveaux*,
  l'image d'un éditeur), coupée à l'extraction ; les noms que le ronéo écrit
  sans certitude (l'article de l'*Encyclopédie critique du genre*, p. 4 ;
  l'auteure de la bande dessinée de l'AVC post-partum, p. 7) ; les questions
  d'étudiants de la p. 4, sauf leur conclusion (une évaluation est aussi un
  entraînement ; une grosse partie des données est objective), reprise dans
  `soc-qc-forme-scolaire` E.
- **Rien n'est pris aux autres chapitres** (plan C16, §3) : la « construction
  sociale » au sens de Hacking et la stigmatisation sont à `ssh_sida` ;
  l'information et le consentement, à `ssh_responsabilite` et
  `ssh_droits_malades`. La rééducation post-AVC (classe et genre) est à ce
  chapitre.

## Les points signalés

Le Ronéosaure 2025-26 n'a pas d'erreur sur une réponse ; trois formules sont
signalées par **ATTENTION**, sans genre, dans la carte qui porte la notion.

| Page | Ce que dit le Ronéosaure | Ce qui est juste | Carte |
|---|---|---|---|
| FC n°12, p. 2 | *Boys in White*, « ouvrage qui aborde les années d'internat et comment apprendre à devenir interne » | l'enquête de Becker, Geer, Hughes et Strauss (1961, *Student Culture in Medical School*) suit les étudiants de l'école de médecine du Kansas | `soc-qc-sante-medecine`, explication |
| FC n°13, p. 7 | « les maladies cardiovasculaires (infarctus, AVC) sont moins fréquentes chez les femmes », puis « les femmes sont plus touchées par l'AVC » | en effectifs et sur la vie entière, oui (elles vivent plus longtemps ; Framingham) ; à âge égal, l'incidence est en général plus faible chez elles (AHA, Bushnell et al., 2014) — point douteux, aucune carte n'en fait une réponse | `soc-rv-paradoxe-cv`, explication |
| FC n°13, p. 6 | « domination de genre : les femmes vivent plus longtemps que les hommes » | la phrase dit le renversement : si les dominations se cumulaient, les femmes vivraient moins longtemps | `soc-qc-esperance-genre` E |

Sans ATTENTION, parce qu'aucune réponse n'en dépend, mais dit dans la carte :
« Aurore LAURETTI, la fabrique des inégalités de santé » (FC n°13, p. 3) pour
Aurore **Loretti**, *La fabrique des inégalités **sociales** de santé*
(`soc-fa-endurance`, `soc-qc-cancers`) ; les « 13 ans » entre les 5 % les plus
riches et les plus pauvres, qui sont l'écart des hommes (8 ans chez les femmes)
(`soc-qc-ecarts-esperance` A, `soc-qr-treize-ans`) ; « Insee, 2024 » pour les
chiffres de 2023 publiés en janvier 2024 (`soc-qc-esperance-genre` A,
`soc-qr-esperance-femmes`) ; « différent du genre biologique » pour « du sexe
biologique » (`soc-qc-genre-definition`, explication). Une coquille sans
conséquence : « comme pas » pour « comme ça » (FC n°13, p. 6).

## Ce que les annales ont dicté

Une seule question, du sujet de 2024/2025 (QROC 8) : expliquer le gradient
social de santé et sa signification pour les inégalités sociales de santé. Elle
vient du cours du Pr Devinant de 2024-25 ; le cours de 2025-26 dit la notion
« importante » et la porte aussi (FC n°12, p. 3-5). Les cartes du cours y
préparent : `soc-qc-gradient`, `soc-qr-gradient`, `soc-rv-cumul-gradient`,
`lex-gradient-de-sante`.

## Le sujet 2025/2026 (18/10/2026)

Les sujets de SSH de l'examen du 09/01/2026 (1 QR, 10 QROC,
`src-sujets-ssh-2526`, sans corrigé), déposés le 18/10/2026, apportent 2
recto-verso à ce chapitre (QROC 6, QROC 7). Aucun n'était déjà en cartes. Au
verso, la bonne réponse, tirée du ronéo 2026-27 quand il couvre la notion,
sinon du cours 2025-26, celui de l'année de l'examen ; ce qui dépasse le cours
est dit « hors cours », avec sa source (`officielle=False`). Rédigés et
contre-vérifiés le 18/10/2026 : un rédacteur, un sceptique, un critique de
complétude.

| Question | Ce que le verso répond | Voisine de |
|---|---|---|
| 2025/2026 S1 QROC 6 (`soc-an-2526s1-qroc6`) | non : le gradient est un ordonnancement régulier de la santé à chaque échelon de la hiérarchie sociale, pas l'écart entre pauvres et riches | `soc-an-2425s1-qroc8` |
| 2025/2026 S1 QROC 7 (`soc-an-2526s1-qroc7`) | non : l'assignation (stéréotypes, biais) n'est qu'un des trois processus du genre, avec la construction (socialisation) et la hiérarchisation (domination) | — |

Ce qui est signalé :

- La QROC 6 est voisine de 2024/2025 S1 QROC 8 (le gradient social de santé) :
  la question est ici fermée, et le verso commence par réfuter la confusion du
  gradient avec l'écart entre pauvres et riches. Hors cours : les 13 ans
  d'écart sont ceux des hommes, 8 ans chez les femmes (Insee Première n° 1687,
  2018).
- La QROC 7 : le cours range stéréotypes et biais sous l'« assignation », l'un
  des trois processus du genre ; il ne les définit pas en une phrase, et les
  définitions du verso suivent ses exemples. « Différent du genre biologique »
  (FC n°13, p. 4) pour « du sexe biologique » : dit sans ATTENTION.

## Les clés qui ne sont pas reprises telles quelles

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2024/2025 S1 QROC 8 (le gradient social de santé) | aucune (sujet sans corrigé) | **clé déduite** : un ordre régulier de la santé selon la position sociale, à chaque échelon ; les ISS traversent toute la société, pas seulement les pauvres ; expliquer les petites différences | FC n°12 2025-26, p. 3-5 ; FC n°10 2024-25 (Pr Devinant), p. 4-5 et 7 |

`CONFLITS = []`.

## Les schémas et les figures

| Fichier | Ce qu'on clique, ou ce qu'il montre | Cartes |
|---|---|---|
| `social-sante-moments-nu.svg` | trois scènes d'un parcours (une vie ; une plainte et la route du cabinet ; un service) : où se situe chacun des trois moments où le social agit | `soc-zo-moments` (3 cartes) |
| `genre-processus-nu.svg` | trois scènes tirées des exemples du cours, **hors de l'ordre de la définition** (domination, socialisation, stéréotypes, de gauche à droite) : on ne répond pas en comptant | `soc-zo-genre-processus` (construction, assignation, hiérarchisation) et `soc-zo-genre-noms` (socialisation, stéréotypes, domination) : 6 cartes |
| `social-sante-moments.svg`, `genre-processus.svg` | les mêmes scènes, légendées, en correction | 3 et 7 notes |
| `gradient-escalier.svg` | la coupure en deux groupes (ce que le gradient n'est pas), le gradient, le gradient inversé | 2 notes |
| `esperance-classe-genre.svg` | espérance de vie à 35 ans des hommes et des femmes cadres et ouvriers (Insee) ; à la naissance | 7 notes |
| `sur-delai-avc.svg` | le témoin et la patiente : pourquoi le délai est trois fois plus long | 4 notes |
| `vignette-hta.png`, `definition-iss.png`, `gradient-sante.png`, `avc-methode.png`, `avc-consensus.png` | les cinq diapositives de la FC n°12 (p. 2, 3, 4, 5, 5), réduites à 1 100 px et quantifiées | 18 notes, dont l'annale `soc-an-2425s1-qroc8` |

**QCM illustrés : 13 sur 17** (76 %). Les quatre autres
(`soc-qc-sante-medecine`, `soc-qc-classe`, `soc-qc-cancers`,
`soc-qc-traitements`) n'ont pas de figure dans le cours, et un dessin n'y
apprendrait rien de plus que la justification.

## Le lexique

Neuf termes, chacun avec son origine grecque ou latine (vérifiée au TLFi par
l'API du portail CNRTL, au Gaffiot, au Bailly, au Wiktionnaire) ; les pages
sont mesurées dans le texte des deux PDF (motif de `chercher_pages.py`, page de
garde exclue), en comptant aussi, pour « Inégalités sociales de santé », les
pages qui disent « inégalités sociales » (FC n°12, p. 5 ; FC n°13, p. 4) et,
pour « Ethnographie », celle qui dit « méthode ethnographique » (FC n°12,
p. 5) :

| Terme | Pages FC n°12 | Pages FC n°13 |
|---|---|---|
| Sociologie | 2-6 | 2-9 |
| Inégalités sociales de santé | 3, 5 | 4 |
| Gradient de santé | 4-5 | 3-4 |
| Ethnographie | 3, 5 | — |
| Classe sociale | 2, 4-5 | 2-3, 6, 9 |
| Genre | 2-3 | 2, 4-9 |
| Socialisation | — | 5, 7-8 |
| Stéréotype | — | 4-5, 8 |
| Surmorbidité | — | 6 |

Racines reprises de la table, à l'identique : `-logie, de logos (grec)` (avec
la FC de sémantique 1, p. 5), `-graphie`, `in- (latin)`, `stér(é)-`, `-type`,
`sur- (latin)` (avec la FC de sémantique 2, p. 9, « super- / supra- », comme
les autres chapitres), `morbus (latin)`. Racines nouvelles, proposées avec les
neuf termes dans `scratchpad/etym/ssh_sociologie.json` (la table n'est pas
modifiée) : `socius (latin)`, `aequalis (latin)`, `sanitas (latin)`,
`gradus (latin)` (le TLFi tire *gradient* de *gradus*, « degré », et non de
`gradi`), `ethn(o)-`, `classis (latin)`, `genus (latin)` — celle-ci est
enseignée par la FC de sémantique 1, p. 6 (tableau « GEN- / -GÈNE / GON- » :
« genus (genre, race) »), qu'elle cite. `socius (latin)` et `sanitas (latin)`
sont proposées aussi par `ssh_sida` et `ssh_droits_malades` : elles leur sont
alignées à l'identique (« socius, socialis » ; « sanitas (de sanus, sain) »),
pour une seule entrée à la fusion. Les phrases
d'étymologie écrites dans `donnees.py` sont exactement celles que produira
`appliquer_etymologies.py` une fois la proposition fusionnée.

## Questions pour Vincent

1. **Le cours 2026-27.** Le squelette donne à ce chapitre le titre du cours
   2024-25 du Pr Devinant (« Inégalités sociales en santé ») ; le Ronéosaure
   2025-26 porte le cours de la Pr Darmon. Si le ronéo 2026-27 change encore
   de professeur, faut-il garder `chap-ue-ssh-fc10` et passer les cartes
   « Absent du cours 2026-27 » au cas par cas (proposition appliquée : on
   garde l'identifiant du squelette) ?
2. **Les 4,6 et 2,7 ans** de vie avec de fortes limitations (FC n°13, p. 7)
   n'ont pas de source dans le cours, et je ne les retrouve pas tels quels
   dans les publications de la Drees (qui varient selon l'âge et l'année). La
   carte `soc-qr-limitations` répond comme le cours et le dit ; à revoir sur
   la diapositive ou la ronéo 2026-27.
3. **Le PDF des fiches** : `outils/copier_les_cours.py` doit connaître le
   dossier « ROneosaure 2025-2026 sans annles/S1 25-26/examen janvier » et le
   préfixe `SSH/` (question commune à toute la vague du Ronéosaure 2025-26).

## À relire

Aucune carte `a-relire` : chaque carte porte sa page (et `fiche=` pour la
FC n°13), chaque chiffre a été relu sur sa page, et l'annale dit d'où vient sa
réponse.

## L'échelle : Simple → Moyen → Annale (C20, 19/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 5 janvier (BMCP) ou du 6 janvier (SSH, papier). Sous les annales, 22 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 3 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`) ; les QROC reçoivent le schéma nu.

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `inegalites-sociales` | 11 | 2 | 2 |
| `genre-sante` | 11 | 1 | 1 |

**Le schéma** `ech-classe-genre`, « Le social dans la santé · classe et genre », donne 26 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_CLASSE_GENRE`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Constantes ajoutées** à `annales.py` (`_SCHEMA_LETTRES`, `_SCHEMA_NU`) : les annales de SSH sont toutes des QROC, rangées dans `ANNALES_QROC` ; chacune reçoit le schéma nu, et les marches la préparent sans lettre.

**Sans marche** :
- soc-an-2425s1-qroc8, le lien du gradient avec l'amplitude des inégalités de richesse (Japon, Suède) : dans le seul cours 2024-25, pas de marche ; le reste du cours 2024-25 (Whitehall, double inégalité, ISS et pauvreté) est préparé avec fiche=src-cours-ssh-inegalites-2425.

## Régénérer

```powershell
cd contenu\chapitres\ssh_sociologie
..\..\..\app\.venv\Scripts\python.exe generer.py
```
