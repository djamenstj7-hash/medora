# Arbre décisionnel et cas clinique de l'hémostase primaire — paquet Tissu sanguin

99 notes, 136 cartes. Chapitre `chap-ue-tissu-sanguin-fc8`, huitième de l'UE
**Tissu sanguin**. **Cours du 14/10/2026, de 10 h à 11 h, Pr A. Rauch, ronéo Ronéo &
Juliette 2026-27** « Principes d'exploration et sémiologie des syndromes
hématologiques (fin) — Arbres décisionnels et cas cliniques » (26 p.). Réaligné sur
elle le 19/10/2026 ; il était carté depuis septembre sur la FC n°8 du Ronéosaure
2024-25 (Pr Rauch, 18/10/2024), qui n'est plus qu'un appoint. Annales : le fascicule
« Principes d'exploration et sémiologie des syndromes hématologiques », commun aux FC
n°7 et n°8 (Ronéosaure 2024-25), et le sujet 2024/2025 déposé le 15/10/2026. Examen :
partiel de novembre (mercredi 4/11/2026).

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 45 | 45 |
| QRU | 28 | 28 |
| Texte à trous | 8 | 36 |
| QROC | 9 | 9 |
| Recto-verso | 6 | 6 |
| Schéma cliquable | 1 | 10 |
| Lexique | 2 | 2 |

Dont **21 annales** sur 12 sessions (13 QCM, 8 QROC), **28 marches de l'échelle**
(22 Simple, 6 Moyen) et 32 QCM de cours, dont 11 nouveaux sur ce que la ronéo
2026-27 apporte. **59 QCM sur 73 illustrés (81 %)**, 62 notes sur 99. **1 carte
absente du cours 2026-27** (tag `absent-2026`), **4 cartes portent un piège des
ronéos** (thème « Pièges des ronéos »). Aucune carte `a-relire`.

Sept thèmes, tous déjà dans `THEME_LABELS` (`purpura`, « Le purpura », vient de
`sang_hemorragies`) : `exploration`, `bilan`, `melange`, `willebrand`, `hemophilie`,
`cas`, `purpura`.

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-sang-exploration` — « Arbres décisionnels et cas cliniques » (26 p.), `Tissu sanguin/ARBRES DECISIONNELS ET CAS CLINIQUES.pdf` | **2026-27** | **la fiche** (`SRC["fiche"]`, `chapitre=`), cours de 10 h ; 69 notes la citent, et 17 annales en source secondaire |
| `src-fc-sang-exploration-9h` — « Principes d'exploration et sémiologie des syndromes hémorragiques » (12 p.), `Tissu sanguin/SYNDROMES HEMORRAGIQUES.pdf` | **2026-27** | le cours de 9 h de la même matinée, fiche de `sang_hemorragies`, déclaré ici **sans `chapitre=`** et sous un identifiant propre (`fiche=FC9H`) : 8 cartes et 4 annales dont la notion est passée dans ce cours-là |
| `src-cours-sang-exploration` — FC n°8 (14 p.) | 2024-25 | **appoint** (`SRC["cours"]`, sans `chapitre=`) : la carte absente, la figure de la transmission (p. 8) ; l'auteur dit désormais son année, « Ronéosaure 2024-25 » |
| `src-annales-sang-exploration` | 2024-25 | 16 questions sur 11 sessions |
| `src-sujets-sang-2425` | 2024-25 | QCM 10, QROC 4 et 5 du sujet 2024/2025, sans corrigé |
| tableau d'erreurs Tissu sanguin de la promo | 2026-27 | aucune ligne sur les cours de 9 h et de 10 h au 19/10/2026 |

Les textes citent « p. 12 » (ronéo de 10 h), « ronéo de 9 h, p. 8 », « ronéo 2026-27
de 8 h, p. 6 » (le cours de physiologie de `sang_hemostase`, cité en texte
seulement), « FC 2024-25, p. 6 » et « FC 2025-26, p. 7 » (Swan & Ronéo, FC n°9 du
Pr Rauch, « Arbres décisionnels de l'hémostase primaire », lu en contre-épreuve).
Lus en appoint, sans être déclarés : les erratas des cours 2024-25 et 2025-26 (rien
de neuf sur ce cours). Les en-têtes des ronéos nomment leurs rédacteurs et leurs
correcteurs : aucun nom n'est repris.

La fiche se copie dans le dossier des PDF de l'application par
`outils/copier_les_cours.py`, lancé avec le dossier des ronéos 2026-27 du 19/10
(`Ajouts/[NUMERIQUE] Ronéo & Juliette 26-27 19 10 2026/S1/CM`), hors du bac à sable.

## Ce qui correspond à quoi

| FC n°8 2024-25 | Ronéo 2026-27 |
|---|---|
| I.A Hémostase primaire : thrombopénie, EDTA, citrate, frottis (p. 2) | ronéo de 9 h, p. 7-8 ; seuil et risque, p. 5 ; le frottis et le micro-caillot ne sont plus cités |
| I.A Willebrand : dosages, variations du taux, étiologies (p. 2-3) | p. 6-9 ; ronéo de 9 h, p. 8-9 |
| I.A Thrombopathie (hors programme, p. 3) | ronéo de 9 h, p. 9 : principe, Bernard-Soulier, Glanzmann, sans détail technique |
| I.B Préparation de l'échantillon, bilan standard (p. 3-5) | p. 3-4 ; ronéo de 9 h, p. 10-12 |
| II.A TQ isolé, TCA isolé, test du mélange, ACC, Rosner (p. 6-8) | p. 9-12, 17 |
| II.B Hémophilie : transmission, circonstances, diagnostic (p. 8-9) | p. 12-15 |
| — (passé par le professeur en 2024-25) | **nouveau** : risques évolutifs et prise en charge de l'hémophilie (p. 15-16) |
| II.C Willebrand : circonstances, diagnostic positif (p. 9-10) | p. 6-8 |
| — | **nouveau** : tableau des types (p. 7), type 2B (p. 7), diagnostic différentiel d'un déficit isolé en VIII, Willebrand acquis (p. 8-9), SAPL (p. 10-12) |
| — | **nouveau** : synthèse, déficits combinés, CIVD (p. 17-20) |
| III Cas clinique n°1, Anna (p. 10-14) | p. 20-23 (raisonnement seul : la diapositive des résultats n'est pas reproduite) |
| Cas n°2 et n°3 (p. 12-13, non cartés) | p. 23-25 |
| — | **nouveau** : conduite à tenir devant un purpura (p. 5, 25) |

## Le réalignement du 19/10/2026

Les 80 notes de la version précédente — 59 de cours, 21 annales — ont été relues une
à une contre la ronéo de 10 h, et contre celle de 9 h quand la notion y est passée.

**Relues et confirmées sur la ronéo de 10 h (50)**, qui citent désormais leur page :

| Partie | Notes |
|---|---|
| Exploration (p. 3-5) | `exp-qc-plasma`, `exp-qc-voies`, `exp-fa-voies`, `exp-ech-s3`, `exp-ech-s5`, `exp-ech-s6` (p. 3) ; `exp-qc-quatre`, `exp-fa-normes`, `exp-ech-s9`, `exp-zo-bilan` (p. 4) ; `exp-ech-s2` (p. 5) |
| Willebrand (p. 6-8) | `exp-qc-vwf-dosages`, `exp-qc-vwf-types`, `exp-qc-vwf-clinique`, `exp-fa-types`, `exp-ech-s15` (p. 6) ; `exp-rv-groupe-o`, `exp-rv-bilan-normal` (p. 7) ; `exp-ech-s13`, `exp-ech-m4` (p. 8) |
| Bilan et mélange (p. 9-17) | `exp-qc-tq-isole`, `exp-qc-tca-isole`, `exp-rv-vii`, `exp-ech-s7`, `exp-ech-s8`, `exp-ech-m2`, `exp-ech-s10`, `exp-ech-s12` (p. 9) ; `exp-qc-melange`, `exp-qc-acc` (p. 10) ; `exp-qr-melange`, `exp-ech-s11`, `exp-ech-m3` (p. 12) ; `exp-fa-melange` (p. 17) |
| Hémophilie (p. 12-15) | `exp-ech-s16` (p. 12) ; `exp-qc-transmission`, `exp-ech-s19`, `exp-ech-s17`, `exp-ech-m5` (p. 13) ; `exp-qc-diagnostic`, `exp-ech-s18` (p. 14) ; `exp-rv-vwf-hemophilie`, `exp-ech-s20` (p. 15) |
| Cas n°1 (p. 21-22) | `exp-cas-bilan`, `exp-cas-etiologies` (p. 21) ; `exp-cas-types`, `exp-cas-famille`, `exp-cas-type1`, `exp-cas-type2n`, `exp-ech-s14` (p. 22) |

**Relues sur la ronéo de 9 h (8)** (`fiche=FC9H`) : `exp-qc-numeration`,
`exp-rv-artefactuelle`, `exp-ech-s1`, `exp-ech-m1` (p. 7) ; `exp-qc-orientation`
(p. 9) ; `exp-qc-tubes`, `exp-fa-tubes`, `exp-ech-s4` (p. 10).

Dans ces cartes, une proposition que seul un cours d'une autre année porte le dit
dans sa justification (« FC 2024-25, p. 2 ; les ronéos 2026-27 n'en parlent pas »).

**Ce que la ronéo 2026-27 dit autrement, et ce qui a été réécrit** :

- **La thrombopathie** n'est plus « hors programme » : le cours de 9 h en donne le
  principe et nomme Bernard-Soulier et Glanzmann (p. 9). La proposition B de
  `exp-qc-orientation`, « le diagnostic de thrombopathie fait partie du programme »,
  ne pouvait plus être dite fausse : elle devient « la recherche d'une thrombopathie
  se fait en première intention, dans tout laboratoire de ville » (faux : seconde
  intention, laboratoire spécialisé) ; la A dit « en première intention ».
- **Le déficit acquis en facteur Willebrand** entre au diagnostic différentiel
  (sujet âgé, gammapathie monoclonale, sténose aortique, cancer, p. 9) :
  `exp-qc-vwf-types`, `exp-qc-deficit-viii-dd`.
- **Le bilan standard** : « essentiellement deux grands paramètres », TQ et TCA
  (p. 3), et non plus trois éléments avec le fibrinogène — `exp-qr-bilan-standard`
  devient absente ; `exp-qc-tubes`, la zone du bilan et la QROC 4 (2/2) le disent.
- **Le facteur VII** : deux causes, héréditaire et transitoire (sepsis) (p. 9) ; le
  début d'AVK des cours 2024-25 et 2025-26 reste, dit comme tel, dans
  `exp-qc-tq-isole` D, `exp-rv-vii` (recto réécrit : « pour quelles raisons », non
  plus « trois raisons »), la marche s8 et la case du schéma.
- **L'anticoagulant circulant de l'enfant** se recontrôle à **12 semaines** (p. 10),
  non plus « normalisé en deux mois » ; persistant, il fait chercher un SAPL :
  `exp-qc-acc`, la zone « non corrigé ».
- **Le type 3** laisse **2 à 3 %** de facteur VIII (p. 7), non plus 2 à 4 % :
  `exp-rv-vwf-hemophilie`, `exp-qc-diagnostic` E. Sous 1 %, « hémophilie A sévère »
  (p. 15).
- **Le taux de Willebrand** : groupe O, inflammation (protéine de la phase aiguë),
  grossesse, âge (p. 7 ; ronéo de 9 h, p. 8) ; le stress et l'exercice ne sont plus
  cités : `exp-qc-vwf-dosages` E, `exp-rv-groupe-o`.
- **Le ratio du TCA** est normal « inférieur ou égal à 1,2 » (p. 4) : `exp-fa-normes`
  dit « jusqu'à 1,2 ».
- **Le type 2N** porte, en gris, « (Pas de question sur ça cette année) » (p. 8) :
  `exp-cas-type2n` et la QROC 5 b le disent dans leur explication.
- **Le cas n°1** : la ronéo 2026-27 en donne le raisonnement sans reproduire les
  résultats ; les énoncés gardent les chiffres de 2024-25, et le contrôle des
  plaquettes sur citrate (180 G/L) est dit « version 2024-25 du cas » — la ronéo
  2026-27, elle, lit la numération comme une vraie thrombopénie, sans contrôle sur
  citrate (p. 20-21), ce que `exp-cas-bilan` E et `exp-cas-etiologies` disent. Pour la jeune
  fille au Willebrand normal, la ronéo ne retient que la conductrice (p. 22) ; la clé
  CE de `exp-cas-type2n` (2N ou conductrice) reste, le 2N restant compatible (p. 8).
- **La phase d'initiation** ne convertit que « 5 % de la prothrombine », freinée par le
  TFPI (ronéo 2026-27 de 8 h, p. 12) : la justification de 2021/2022 S2 QCM 10 D, qui
  disait « moins de 1 % », suit l'année ; la clé (D faux) ne change pas.
- **L'échelle** : `exp-ech-s20` C, « hémophilie A ou anticoagulant circulant »,
  devient « hémophilie B ou Willebrand sévère » : la ronéo 2026-27 range l'hémophilie
  acquise — un anticoagulant circulant anti-VIII — parmi les causes d'un déficit isolé
  en VIII (p. 8, 11), ce qui rendait le distracteur discutable.

**Notes nouvelles (19)**, sur ce que le cours 2026-27 apporte :

| Note | Ce qu'elle carte |
|---|---|
| `exp-qc-vwf-profils` | le tableau des types : type 1 proportionnel, rapport < 0,7 des 2A-2B-2M, gain de fonction du 2B, VIII du type 3 (p. 7-8) |
| `exp-qc-deficit-viii-dd` | conductrice, hémophilie A mineure (gène F8), hémophilie acquise (p. 8) |
| `exp-qc-sapl` | signes cliniques et biologiques, lupus, persistance au-delà de 12 semaines (p. 10-12) |
| `exp-qc-hemophilie-revelation` | âge de la marche, formes mineures à l'âge adulte, deux tiers familiaux, sévérités (p. 12-14) |
| `exp-qc-hemophilie-evolution` | arthropathie, allo-immunisation, desmopressine, anticorps mimétiques, TFPI et antithrombine (p. 15-16) |
| `exp-qc-deux-allonges` | voie commune, ACC rare sur le TQ, vitamine K, cirrhose, facteur V et greffe (p. 17-18) |
| `exp-qc-civd` | facteur tissulaire, consommation, thromboses, LAM promyélocytaire, traiter la cause (p. 18-20) |
| `exp-qc-purpura` | confirmer, chercher la gravité, signes d'une thrombopénie sévère (p. 5, 25) |
| `exp-cas2-hemarthrose`, `exp-cas2-arbre` | le cas n°2 : hémarthrose du petit garçon, arbre généalogique (p. 23-24) ; la photo et l'arbre sont la question |
| `exp-cas3-hemophilie-acquise` | le cas n°3 : hématome de la cuisse d'un homme âgé (p. 24-25), chiffres de la version 2024-25 (FC 2024-25, p. 13) |
| `exp-fa-severite`, `exp-fa-plaquettes`, `exp-fa-civd` | sévérités de l'hémophilie (p. 12), seuils plaquettaires (p. 5), biologie de la CIVD (p. 20) |
| `exp-ech-s21`, `exp-ech-s22`, `exp-ech-m6` | trois marches sur la case nouvelle du schéma, « TCA et TQ allongés » (p. 17-20) |
| `lex-hemophilie`, `lex-hemarthrose` | le lexique (ci-dessous) |

## Les figures

Toutes en correction, sauf les deux photos et l'arbre des cas n°2 et n°3, qui sont
la question (`illustration_question`) — rien n'y est légendé. Découpées à 200 dpi
dans le PDF de la ronéo 2026-27, déclarées dans `IMAGES` avec leur page.

| Fichier | Page | Ce que c'est |
|---|---|---|
| `exp-voies-tq-tca.png` | 4 | les deux ellipses du TCA et du TQ, la voie commune, « sauf FXIII » |
| `exp-willebrand-types.png` | 7 | la diapositive « La maladie de Willebrand : diagnostic positif » |
| `exp-tca-tq-allonges.png` | 17 | le schéma de synthèse des TCA et TQ allongés |
| `exp-civd-purpura.png` | 18 | lésions cutanées d'une CIVD |
| `exp-cas2-genou.png`, `exp-cas2-arbre.png` | 23-24 | le cas n°2 |
| `exp-cas3-hematome.png` | 24 | le cas n°3 |
| `exp-transmission-hemophilie.png` | FC 2024-25, p. 8 | la transmission liée à l'X (la ronéo 2026-27 n'a pas de figure) |

## Les erreurs des ronéos 2026-27

Aucune n'est au tableau d'erreurs de la promo. Toutes trouvées en relisant. Les
deux erreurs de la ronéo de 9 h (p. 9 et 10) tombent dans sa partie II, l'exploration,
que ce chapitre carte : elles sont portées ici, et `sang_hemorragies` renvoie ici.

| Page | Ce que dit la ronéo | Ce qui est juste | Genre | Carte |
|---|---|---|---|---|
| 10 h, p. 6 | le TCA peut être allongé « chez les patients qui présentent un déficit secondaire en facteur Willebrand » | c'est le déficit secondaire en **facteur VIII** qui l'allonge : la même page plus haut, la p. 7, la FC 2025-26 (p. 3) | prise de notes | `exp-qc-vwf-clinique` C |
| 9 h, p. 10 | « une couche intermédiaire contenant les plaquettes et les leucocytes, c'est le plasma pauvre en plaquettes » | le PPP est le **plasma surnageant**, débarrassé des plaquettes ; la couche intermédiaire est celle des leucocytes et des plaquettes (ronéo de 10 h, p. 3 ; FC 2024-25, p. 4) | prise de notes | `exp-qc-plasma` B |
| 9 h, p. 9 | le tableau des types : type 2 « Qualitatif (il en existe deux types) » | **quatre** sous-types, 2A, 2B, 2M (dominants) et 2N (récessif) : ronéo de 10 h, p. 6, et la diapositive du diagnostic positif, p. 7 ; FC 2024-25, p. 10 ; FC 2025-26, p. 3 | prise de notes | `exp-qc-vwf-types` B |
| 10 h, p. 16 | « Dans l'hémophilie B, les traitements permettent d'inhiber certains inhibiteurs physiologiques de la coagulation, comme le TFPI ou l'antithrombine » | ces traitements de rééquilibrage sont autorisés dans les **deux** hémophilies : fitusiran (anti-antithrombine, A ou B, FDA 03/2025), marstacimab (anti-TFPI, A ou B sans inhibiteur, FDA 10/2024) | douteux | `exp-qc-hemophilie-evolution` E |

Coquilles sans conséquence, non portées : « purpura fulminens » (p. 19),
« conductrices obligatoire » (p. 13), « (vitropression) » accolé à l'orthostatisme
(p. 5) — le sens est donné p. 25 et dans la ronéo de 9 h (p. 3, 5).

## Absent du cours 2026-27

Une carte entière, `exp-qr-bilan-standard` : les « trois éléments » du bilan de
coagulation standard (TQ, TCA, fibrinogène), quand les ronéos 2026-27 ne mesurent
« essentiellement » que le TQ et le TCA (10 h, p. 3 ; 9 h, p. 10). Elle cite la FC n°8
2024-25 (p. 4) et porte le tag `absent-2026`.

Restent dans des cartes relues, dits comme tels dans leur justification : le
micro-caillot et le frottis (FC 2024-25, p. 2), le début d'AVK (FC 2024-25, p. 6 ;
FC 2025-26, p. 7), le stress et l'exercice qui élèvent le Willebrand (FC 2024-25,
p. 3), le type 3 récessif et « un cas par million » (FC 2024-25, p. 3 et 10 ; FC
2025-26, p. 2-5), la normalisation « en deux mois » (FC 2024-25, p. 7).

## Les clés d'annales qui ne sont pas reprises telles quelles

La clé retenue est la bonne, pas la clé imprimée (règle de Vincent, 26/09) : la
question porte alors `cle_officielle` à faux, et la justification de l'item dit que la
correction imprimée n'est pas bonne, et pourquoi. Le réalignement ne change aucune
clé : la ronéo 2026-27 confirme chacune.

| Question | Clé imprimée | Retenu | Pourquoi | Source |
|---|---|---|---|---|
| 2019/2020 S2, QCM 5 C (`exp-an-1920s2-q5`) — « la vitamine K est le cofacteur d'une gamma-carboxylase hépatique nécessaire à l'action anticoagulante des facteurs II, VII, IX et X » | ABC (C vrai) | **AB** (C faux) | les facteurs II, VII, IX et X sont procoagulants ; les vitamine K dépendants anticoagulants sont les protéines C et S | cours n°6 p. 17 ; ronéo 2026-27 de 8 h, p. 13 (« nécessaire à l'activité des facteurs II, VII, IX et X ») ; errata des annales ; Pharmacorama |
| 2024/2025, QCM 10 C (`exp-an-2425-q10`) — « l'hémophilie est de transmission autosomique récessive liée à l'X » | aucune (sujet sans corrigé) ; surlignée : CE | **CDE** (C vrai) — cas ouvert | la formule accole deux termes qui s'excluent ; c'est celle du ronéo 2025-26 du professeur (FC n°9, p. 9), et la seule qui nomme l'X. La ronéo 2026-27 n'écrit plus que « récessive liée au chromosome X » (p. 12-13) | `ATTENTION —` et `CONFLITS` |
| 2024/2025, QCM 10 D (`exp-an-2425-q10`) — « une fille d'hémophile est conductrice obligatoire » | aucune ; surlignée : non cochée | **vrai** | dit en toutes lettres (p. 13) | `ATTENTION —` et `CONFLITS` |
| 2024/2025, QROC 4 et 5 (quatre cartes) | aucune | réponses du cours | TCA p. 3-4 ; Willebrand p. 22-23, où la ronéo 2026-27 corrige exactement ces deux profils (type 1 ; type 2N ou hémophilie A mineure chez un garçon) | — |

Le même errata 2024-25 montre un étudiant contester l'item voisin de 2019/2020 S2
QCM 5 — « la synthèse hépatique est diminuée » — et le bureau lui opposer le bon
raisonnement : la synthèse a lieu, c'est l'activation qui manque. La clé imprimée
(faux) tient.

**La correction surlignée (officieuse)** des sujets du dépôt du 15/10 sert de seconde
opinion : quand le cours tranche contre elle, la carte suit le cours, et l'item porte
un `ATTENTION —` et une entrée `CONFLITS`. Coquille du sujet, gardée telle quelle :
« autosomique récessive liée à l'X » (QCM 10 C). 2023/2024 : le QCM 2 est confirmé par
la grille officielle (D).

## L'échelle : Simple → Moyen → Annale (C20, 16/10/2026 ; réalignée le 19/10)

22 cartes Simple (`niveau-simple`) et 6 cartes Moyen (`niveau-moyen`), sous les
annales. Clés des Simple : 8 A, 7 B, 7 C ; Moyen d'une à trois vraies.

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `exploration` | 5 | 1 | 4 |
| `bilan` | 8 | 2 | 8 |
| `melange` | 3 | 1 | 4 |
| `willebrand` | 2 | 1 | 3 |
| `hemophilie` | 4 | 1 | 2 |

**Le schéma** `ech-exploration`, « Explorer l'hémostase · du tube à l'arbre
décisionnel » (`schemas.py`, `ECH_EXPLORATION`), dessiné par `echelle.py`, copie
exacte du modèle. Sa légende cite désormais les ronéos 2026-27 (10 h, p. 3-25 ; 9 h,
p. 7-11), « complétées par les cours 2024-25 et 2025-26 ». **Une case nouvelle**, « TCA
et TQ allongés : la voie commune » (un seul facteur bas : héréditaire ; déficit combiné
vitamine K dépendant ; CIVD ; p. 17-20), porte trois marches (s21, s22, m6) et les
lettres de trois annales jusque-là sans marche sur ce point : 2021/2022 QCM 10 B,
2019/2020 QCM 5 E, 2019/2020 S2 QCM 5 B. Toutes les marches citent leur page de
l'année ; les justifications citent la ronéo de 10 h ou de 9 h, et plus jamais
« cours n°6 ».

**Contre-relecture du 19/10/2026 : trois trous trahis, corrigés.** La légende, imprimée
sous chaque variante trouée, disait « le début d'AVK vient des cours 2024-25 » : elle
donnait la réponse de s8 ; elle ne nomme plus aucune case. La case nouvelle montre
« AVK, carence, malabsorption : II, VII, IX, X » pendant s8, et la case « TQ allongé
isolément » associe le VII au début d'AVK pendant s22 : les distracteurs de s8
(« héréditaire, sepsis, groupe O » ; « inflammation, virose, début d'AVK ») et de s22
(« V, VII, VIII, X » ; « II, VII, XI, XII ») gardent chacun une part juste, pour que le
mot visible ne départage plus rien. La première ligne de la case nouvelle ne liste plus
les facteurs de la voie commune (« un seul facteur bas : héréditaire, rare ») : ils
désignaient, par élimination, les réponses de s7 et de s9.

**ATTENTION posés** (sans genre : ils portent sur l'annale, pas sur la ronéo 2026-27) :
la FC 2025-26 écrit « transmission autosomique récessive » pour l'hémophilie, formule
de 2024/2025 QCM 10 C (s16, m5) ; la correction surlignée officieuse de 2024/2025
QCM 10 ne coche pas D (s17, m5).

**Sans marche** :
- exp-an-2122s1-q10 E, exp-an-1819s1-q5 E, exp-an-1516s1-q3 B : la valeur des
  D-dimères — les ronéos 2026-27 ne les citent qu'avec la CIVD (p. 20)
- exp-an-2122s2-q10 A, B, D, E : physiologie (Willebrand à l'agrégation, facteur XIII,
  initiation), enseignée dans `sang_hemostase`, et plasmine
- exp-an-1920s2-q5 C, D, E : vitamine K et phase d'initiation, enseignées dans
  `sang_hemostase` ; C porte le conflit « action anticoagulante »
- exp-an-1516s1-q4 E : l'INR — absent des cours
- exp-an-qr-tca-causes : l'héparine — absente des ronéos 2026-27

## Le lexique

Deux termes, accueillis ici parce que ce cours est celui de l'hémophilie et que ses
annales emploient l'un et l'autre (cinq annales pour hémophilie, une pour hémarthrose ;
aucune dans `sang_hemorragies`, qui les laisse à ce chapitre) : **hémophilie** (ronéo de
10 h, p. 2, 7-8, 11-16, 21-25 ; ronéo de 9 h, p. 2, 6-7) et **hémarthrose** (10 h,
p. 6, 13-14, 16, 23 ; 9 h, p. 2-3, 5-6), mesurées dans le texte des PDF
(`chercher_pages.py`). Leurs étymologies sont écrites dans les définitions et proposées
pour `etymologies.json`, sans racine nouvelle : hémophilie, αἷμα + φίλος, avec la racine
« -phile » de la table (celle de neutrophilie et d'hyperéosinophilie), qui cite la FC de
sémantique (1/2, p. 4) ; hémarthrose, αἷμα + ἄρθρωσις, « sang + articulation », comme
le Wiktionnaire (« arthrose dans le sens de articulation ») et comme `lex-arthrose`.
« Purpura », « pétéchie » et « thrombopathie » sont laissés à `sang_hemorragies`, dont
le cours de 9 h les définit.

## Questions pour Vincent

1. **Le type 2N** porte dans la ronéo 2026-27, en gris, « (Pas de question sur ça cette
   année) » (p. 8). `exp-cas-type2n` (2N ou conductrice) et la QROC 5 b de 2024/2025 le
   disent dans leur explication, sans tag. Faut-il leur poser le tag `edn` (« Pour les
   EDN, hors partiel ») ?
2. **Les cartes passées dans le cours de 9 h** (tubes, EDTA, citrate : 8 cartes, 4
   annales) citent la ronéo de 9 h sous un identifiant propre, sans `chapitre=`. Elles
   restent ici ; les déplacer dans `sang_hemorragies` changerait leur chapitre, ce
   qu'on ne fait pas sans ton accord.

## Régénérer

```
..\..\..\app\.venv\Scripts\python.exe generer.py
```

Le script écrit d'abord les SVG, puis valide : une justification manquante, un
trou de plus de deux mots, deux zones qui se recouvrent, une page hors de sa fiche,
un conflit déclaré mais non signalé — et il refuse d'écrire.
