# Physiologie de l'hémostase primaire et de la coagulation — paquet Tissu sanguin

82 notes, 120 cartes. Chapitre `chap-ue-tissu-sanguin-fc6`, sixième chapitre de
l'UE **Tissu sanguin**. **Cours du Pr A. Rauch du 14/10/2026, 8 h-9 h, en une ronéo
Ronéo & Juliette 2026-27** (« Hémostase primaire et coagulation », 14 p.). Réaligné
sur elle le 19/10/2026 ; il était carté sur la FC n°6 du Ronéosaure 2024-25, qui
n'est plus qu'un appoint. Annales : 14 QCM et 5 QROC sur 12 sessions (Ronéosaure
2024-25). Examen : partiel de novembre (mercredi 4/11/2026).

Le professeur prévenait en 2024-25 qu'il est « assez compliqué de renouveler les
questions d'examen, donc en refaisant les annales on a facilement la moyenne ». Le
fascicule lui donne raison : une poignée de faits y reviennent sans cesse.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 36 | 36 |
| QRU | 22 | 22 |
| Texte à trous | 8 | 37 |
| QROC | 8 | 8 |
| Recto-verso | 7 | 7 |
| Schéma cliquable | 1 | 10 |

Dont **19 annales** (13 QRM, 1 QRU, 5 QROC) sur 12 sessions, de 2015/2016 à
2023/2024 ; 17 QCM de cours ; et l'échelle, 21 cartes Simple et 6 cartes Moyen.
**56 QCM sur 58 illustrés (97 %)** — neuf figures de la ronéo 2026-27, le schéma de
l'échelle —, 71 notes sur 82. **2 cartes absentes du cours 2026-27** (tag
`absent-2026`), **10 cartes portent un piège de la ronéo** (thème « Pièges des
ronéos »). Rien n'est `a-relire`.

Sept thèmes, déjà dans `THEME_LABELS` (`app/src/med_engine/application/scopes.py`) ;
le réalignement n'en ajoute aucun : `primaire` (Hémostase primaire), `recepteurs`
(Récepteurs plaquettaires), `willebrand` (Le facteur Willebrand), `facteurs` (Les
facteurs de la coagulation), `modele` (Le modèle cellulaire), `inhibiteurs`
(Inhibiteurs et fibrinolyse), `bilan` (Le bilan de coagulation).

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-sang-hemostase-2627` — « Hémostase primaire et coagulation » (14 p., la dernière vide), `Tissu sanguin/HEMOSTASE PRIMAIRE ET COAGULATION.pdf` | **2026-27** | **la base** : `SRC["fiche"]`, ce que le lecteur ouvre (`chapitre=`) ; 61 notes la citent à leur page, les annales en source secondaire ; les neuf figures (`SRC["medias"]`) |
| `src-cours-sang-hemostase` — FC n°6, Ronéosaure 2024-25 (17 p.) | 2024-25 | **appoint** (`SRC["cours"]`, sans `chapitre=`) : la base jusqu'au 19/10/2026, désormais la source des **2 cartes absentes** et de ce que la ronéo 2026-27 ne dit plus ; son auteur dit maintenant l'année, d'où le badge « Cours 2024-25 » des cartes absentes |
| `src-fc-sang-hemostase-2526` — FC n°7, Ronéosaure 2025-26 (11 p.) | 2025-26 | appoint, déclaré : la ronéo 2026-27 la reprend presque mot pour mot ; elle seule donne les 95 % de thrombine de l'amplification (p. 10) |
| `src-annales-sang-hemostase` — « HEMATO n°6 », annales du Ronéosaure 2024-25 (11 p.) | 2024-25 | les annales, verbatim |
| tableau d'erreurs de tissu sanguin de la promo 2026-27 | 2026-27 | aucune entrée sur ce cours au 19/10/2026 |
| erratas de tissu sanguin du Ronéosaure (cours 2024-25, 2025-26, annales) | 2024-25, 2025-26 | les granules « alpha et bêta » de 2024-25 (corrigés « delta ») ; la clé de 2020/2021 QCM 8 ; « Willebrand, ligand du GP1b » ; rien d'autre sur ce cours |

Les textes citent « p. 12 » (ronéo 2026-27), « cours 2024-25, p. 16 » ou « FC
2025-26, p. 10 ». La fiche de l'année se copie dans le dossier des PDF de
l'application par `outils/copier_les_cours.py`, lancé avec le dossier des ronéos
2026-27 (`Ajouts/[NUMERIQUE] Ronéo & Juliette 26-27 19 10 2026/S1/CM`), hors du bac
à sable. Aucun nom d'étudiant n'est repris : ni des en-têtes des ronéos, ni des
erratas.

## Ce qui correspond à quoi

La ronéo 2026-27 suit le plan du cours 2024-25 du même professeur, et reprend
presque mot pour mot la FC 2025-26 :

| Cours 2024-25 | Ronéo 2026-27 |
|---|---|
| I. Introduction, objectifs de l'item 216 (p. 2-3) | I. Définition, objectifs EDN (p. 2) |
| II-A. Généralités (p. 3-4) | II-A. Principe, avec la **vasoconstriction réflexe** (p. 3) |
| II-B. Le vaisseau, les plaquettes, le myélogramme (p. 4-6) | II-B-1, 2. Le vaisseau (p. 3), les plaquettes (p. 4) — sans le myélogramme |
| II-B. Récepteurs plaquettaires (p. 6-7) | récepteurs aux protéines adhésives et aux agonistes solubles, en tableaux (p. 4-6) |
| granules « alpha et bêta » (p. 8) | ultrastructure : granules alpha et denses, leur contenu (p. 6) |
| II-B. Le facteur Willebrand (p. 8-9) | II-B-3. Le Willebrand, **sa maladie et ses trois types**, **ADAMTS13 et le PTT** (p. 6-7) |
| II-C, D. Étapes, résumé (p. 9-10) | II-C. Étapes et points clés (p. 8-9) |
| III-A, B. Définition, deux modèles (p. 11) | III-A, B (p. 9-10) |
| III-C. Facteurs, membranes, calcium (p. 12-15) | III-C (p. 10-11), avec le **tube citraté** |
| III-D. Modèle en Y (p. 15) | III-D, le détail des trois voies et sa figure (p. 11) |
| III-E. Modèle cellulaire (p. 15-17) | III-E (p. 12-13) |
| III-F. Fibrinoformation, déficit en XIII (p. 17) | III-E-4. Fibrinoformation, **transglutaminase** — sans le déficit en XIII (p. 13) |

Le plan de la ronéo annonce une partie « 4. La fibrinolyse » (p. 1) ; le texte la
remplace par la fibrinoformation (p. 13) : la fibrinolyse n'est que définie (p. 2-3).

## Le réalignement du 19/10/2026

Les 75 notes de la version 2024-25 (30 notes de cours, 26 marches de l'échelle, 19
annales) ont été relues une à une contre la ronéo 2026-27.

**Relues et confirmées, qui citent désormais leur page de l'année** (et perdent le
badge de l'année passée) : toutes les notes de cours sauf les deux absentes —
`hst-qc-generalites` (p. 2), `hst-qc-vaisseau`, `hst-qr-compartiments` (p. 3),
`hst-fa-plaquettes`, `hst-ech-s10` (p. 4), `hst-qc-recepteurs`,
`hst-qc-antiplaquettaires`, `hst-ech-s7` (p. 5), `hst-qc-granules`, `hst-ech-s8`
(p. 6), `hst-qc-willebrand`, `hst-fa-willebrand`, `hst-ech-s11`, `hst-ech-m3` (p. 7),
`hst-qc-etapes`, `hst-fa-etapes`, `hst-ech-s1` à `-s6`, `hst-ech-m1`,
`hst-ech-m2` (p. 8), `hst-qc-modeles`, `hst-qr-thrombine`, `hst-ech-s20` (p. 9),
`hst-qc-facteurs`, `hst-qc-familles`, `hst-qr-hemophilies`, `hst-rv-xii`,
`hst-rv-cofacteurs`, `hst-ech-s12`, `hst-ech-s13`, `hst-ech-m4` (p. 10),
`hst-rv-phospholipides`, `hst-rv-bilan`, `hst-ech-s9` (p. 11), `hst-qc-initiation`,
`hst-qc-complexes`, `hst-fa-complexes`, `hst-fa-phases`, `hst-rv-ft`, `hst-zo-modele`,
`hst-ech-s14`, `-s16`, `-s17`, `-s18`, `hst-ech-m5` (p. 12), `hst-qc-fibrine`,
`hst-fa-vitk`, `hst-ech-s15`, `-s19`, `hst-ech-m6` (p. 13). Chaque justification cite
désormais les pages de l'année ; une proposition que seul un cours passé porte le dit
(« cours 2024-25, p. 17 ; la ronéo 2026-27 n'en parle pas »).

**Ce que la ronéo 2026-27 dit autrement, et ce qui a été réécrit** :

- **Les 5 % de l'initiation.** « Seulement 5 % de la prothrombine » est convertie à
  l'issue de l'initiation (p. 12, comme la FC 2025-26, p. 10), et non plus « moins de
  1 % de la thrombine totale » (cours 2024-25, p. 16). `hst-fa-phases` est réécrit :
  ses trous 4 et 5 demandent « 5 % » et « TFPI » au lieu de « 1 % » et « 95 % » ; la
  justification B de `hst-qc-initiation`, la note A de `hst-an-1718s2-q5`, la marche
  `hst-ech-s14` et la zone `peu-thrombine` du schéma cliquable (étiquette « 5 % » au
  lieu de « < 1 % ») le disent, avec un `ATTENTION` nu qui rappelle l'ancien chiffre.
- **La numération plaquettaire** : 150 à 400 G/L, 450 « dans certains référentiels »
  (p. 4 et la diapositive) ; `hst-fa-plaquettes` est réécrit en six trous (bornes,
  thrombopénie et risque hémorragique, thrombocytose et risque de thrombose).
- **Le facteur tissulaire au cours d'un sepsis** est exprimé par les cellules
  endothéliales et les monocytes (p. 12) ; les cellules tumorales ne sont plus
  citées : le verso de `hst-rv-ft` est réécrit, l'explication garde le cours 2024-25.
- **Le XII** : un taux indosable, un TCA « extrêmement allongé », aucun saignement
  (p. 10) ; le verso de `hst-rv-xii` est réécrit.
- **Le modèle en Y** sert à interpréter un bilan anormal et à savoir quel facteur
  doser (p. 11) : le verso de `hst-rv-bilan` le dit ; la correspondance TQ/TCA reste,
  tirée de la FC 2025-26 (p. 11).
- **Les granules** sont alpha et denses (p. 6) : la ronéo 2026-27 dit juste là où la
  ronéo 2024-25 et la FC 2025-26 écrivaient « bêta » (`hst-qc-granules` C).
- **La vasoconstriction réflexe** entre au cours (p. 3) : l'annale 2017/2018 S2 QCM 6 A
  a désormais sa lettre et sa marche.

**Notes nouvelles (7)**, sur ce que le cours 2026-27 apporte :

| Note | Ce qu'elle carte |
|---|---|
| `hst-qc-agonistes` | les deux familles de récepteurs, les RCPG des agonistes solubles, P2Y1 et P2Y12, TP, le cangrélor (p. 4-6, 8-9) |
| `hst-qc-plaquettes` | 2-4 µm, thrombopoïétine, mégacaryocyte, thrombocytose et thrombose, seuil de 150 G/L (p. 4) |
| `hst-qc-adamts13` | multimérisation, ADAMTS13 et le domaine A2, le PTT congénital ou acquis et ses trois conséquences (p. 7, 9) |
| `hst-qc-endothelium` | vasoconstriction réflexe, thrombomoduline, sérotonine, endothélium au repos, simultanéité des deux processus (p. 3, 6) |
| `hst-fa-modele-y` | les voies extrinsèque, intrinsèque et commune (p. 11) |
| `hst-fa-fibrinoformation` | thrombine, liaisons non covalentes, XIII activé par la thrombine, transglutaminase (p. 13) |
| `hst-ech-s21` | marche Simple : la vasoconstriction réflexe (p. 3), qui prépare `hst-an-1718s2-q6` A |

Laissé à un autre chapitre : les trois types de la maladie de Willebrand (p. 6) sont
déjà cartés dans `sang_exploration` (`exp-qc-vwf-types`, `exp-fa-types`), comme le
tube citraté et son délai de 2 à 4 h ; ici, l'explication de `hst-qc-willebrand` les
résume et y renvoie, et seul `hst-qc-facteurs` E cite le tube citraté.

**Les annales** restent verbatim. Chacune porte désormais la page de la ronéo 2026-27
où se lit sa réponse (source secondaire), sauf trois que la ronéo n'aborde pas — les
deux sur les inhibiteurs physiologiques et `hst-an-qr-tca` —, et, quand la ronéo en a
une, la figure qui fait foi (`illustration`), à côté de son schéma à lettres. Aucune clé n'est
contredite par le cours de l'année.

## La relecture sceptique du 19/10/2026

Chaque carte nouvelle ou modifiée a été relue contre sa page de la ronéo (texte et
image), chaque citation du cours 2024-25 et de la FC 2025-26 contre leur texte, et
les références externes en ligne. Le générateur reproduisait exactement le paquet
du réalignement ; aucun identifiant ni aucun type n'avait changé, aucune note
n'avait disparu. Ce que la relecture a changé :

- **Une erreur de plus** (p. 13) : la phrase « le facteur XIII, lui-même activé par
  la thrombine qui, grâce à une activité transglutaminase… » prête l'activité à la
  thrombine ; `ATTENTION (prise de notes)` dans `hst-fa-fibrinoformation`.
- `hst-qc-facteurs` A disait « Ils sont tous synthétisés par le foie » : faux pour le
  facteur tissulaire, que des cellules de la paroi expriment (p. 11-12). La
  proposition reprend les mots du cours (« glycoprotéines plasmatiques synthétisées
  au niveau du foie », p. 10), et sa justification le dit.
- `hst-fa-vitk` : la prose avant les deux ATTENTION (l'annale de la vitamine K
  tombait dans l'encadré du cours) ; « À l'examen » répond comme le professeur (les
  AVK visent la γ-carboxylation), « La référence » dit que la carboxylase n'est pas
  leur cible directe.
- `hst-qc-fibrine` A : le mot « hydrostatique » vient du cours 2024-25 lui-même, qui
  appelle ainsi les liaisons non covalentes ; la justification le dit.
- `hst-rv-phospholipides` : la fiche Eurofins Biomnis citée ne répond plus (404) ;
  remplacée par la fiche du CHU de Lille et celle de l'OQLF.
- `hst-qc-willebrand` : son explication porte maintenant la p. 6, la maladie de
  Willebrand et ses trois types, qu'aucune carte du chapitre ne citait.
- Le point douteux du tube citraté est reformulé : le délai de 4 h est une règle
  courante, c'est son explication qui reste sans source.

## Les ATTENTION

- **2020/2021 QCM 8** (`hst-an-2021s1-q8`, D et E), la clé imprimée « CE » : inchangé,
  les justifications citent désormais la ronéo 2026-27 (p. 5, 6, 8, 9) ; repris par les
  marches `hst-ech-s6`, `-s7`, `-s8`, `-m2`.
- **Le chiffre de l'initiation**, 5 % contre moins de 1 % : `hst-qc-initiation` B,
  `hst-fa-phases`, `hst-ech-s14` (ATTENTION nu : deux années qui se contredisent).
- **Les erreurs de la ronéo 2026-27**, avec leur genre (section suivante).

## Les erreurs de la ronéo 2026-27

Le tableau d'erreurs de la promo ne relève rien sur ce cours ; toutes ont été trouvées
en relisant la ronéo page par page.

| Page | La ronéo dit | Ce qui est juste | Source | Genre | Carte |
|---|---|---|---|---|---|
| 5 | Les récepteurs aux protéines adhésives sont « des récepteurs couplés à des protéines G (RCPG) que l'on retrouve dans la MEC » | Ce sont des glycoprotéines de la membrane plaquettaire (GPVI, superfamille des immunoglobulines ; GPIb-IX-V, protéines riches en leucines ; αIIbβ3, intégrine), pas des RCPG ; ce sont leurs ligands qui sont dans la MEC | la ronéo, p. 4 ; FC 2025-26, p. 4 ; Bergmeier et Hynes, Cold Spring Harb Perspect Biol 2012 | prise de notes | `hst-qc-agonistes` A |
| 5 | Le récepteur du Willebrand, « GPIb/X/IV » | Le complexe GPIb-IX-V | FC 2025-26, p. 4 (« GPIb-V-IX ») ; annale 2021/2022 QCM 9 (« GPIb/IX/V ») | prise de notes | `hst-qc-recepteurs` B, `hst-an-2122s1-q9` A |
| 8 | La voie de signalisation de l'adhésion, une « cascade interplaquettaire » | INTRAplaquettaire | la ronéo, p. 5 ; FC 2025-26, p. 5 | prise de notes | `hst-qc-etapes` A |
| 10 | « Déficit en F-VII : hémophilie A » | Déficit en facteur VIII | l'en-tête du même tableau ; FC 2025-26, p. 8 ; cours 2024-25, p. 12 | prise de notes | `hst-qc-familles` A, `hst-qr-hemophilies` |
| 10 | La vitamine K, nécessaire à l'activation « post-transcriptionnelle » | POST-TRADUCTIONNELLE : la γ-carboxylation se fait sur la protéine traduite | la phrase suivante et la p. 13 ; FC 2025-26, p. 8 | prise de notes | `hst-fa-vitk` |
| 11 | En laboratoire, « on peut également activer la coagulation à l'aide d'activateurs différents, comme par les plaquettes activées » | Au laboratoire, on active par le facteur tissulaire ou par un activateur de la phase contact, sur un plasma pauvre en plaquettes ; les plaquettes activées sont la surface de la coagulation in vivo | FC 2025-26, p. 9 et 11 ; CHU de Lille, fiche PRA-FI-HEM-010 (plasma citraté pauvre en plaquettes, d'après le GFHT) ; OQLF, fiche « temps de céphaline kaolin » (la céphaline, « équivalent du facteur 3 plaquettaire ») | prise de notes | `hst-rv-phospholipides` |
| 13 | Le clivage modifie la « polarisation hydrostatique » du fibrinogène | Ses charges ÉLECTROSTATIQUES : le départ des fibrinopeptides, chargés négativement, démasque des sites qui s'emboîtent surtout par des interactions électrostatiques | cours 2024-25, p. 17 (« la polarisation des charges électrostatiques » ; le même cours dit « hydrostatiques » les liaisons non covalentes qui suivent, d'où le mot) ; Duval et al., J Thromb Haemost 2020 ; la FC 2025-26 (p. 11) portait déjà la confusion | prise de notes | `hst-qc-fibrine` A |
| 13 | « le facteur XIII, lui-même activé par la thrombine qui, grâce à une activité transglutaminase, permet la formation de liaisons covalentes » | L'activité transglutaminase est celle du XIII activé ; la thrombine est une sérine-protéase | FC 2025-26, p. 11 (« facteur XIII (lui-même activé par la thrombine) qui grâce à une activité transglutaminase… ») ; la ronéo, p. 10 (sérine-protéases) ; Mutch et al., J Thromb Haemost 2010 | prise de notes | `hst-fa-fibrinoformation` |

**Quand c'est le cours lui-même** :

| Page | Le cours dit | La référence | À l'examen | Carte |
|---|---|---|---|---|
| 10 | La γ-carboxylase, « cible thérapeutique » des antivitamines K (et la FC 2025-26, p. 8) | Les AVK n'inhibent pas la carboxylase elle-même : ils agissent sur le cycle de réduction de la vitamine K (vitamine K époxyde réductase), dont la forme réduite est le cofacteur de la carboxylase (RCP de la Coumadine, 5.1) | répondre comme le cours : les AVK visent la γ-carboxylation des facteurs II, VII, IX et X, et empêchent leur activation, pas leur synthèse (cours 2024-25, p. 13) | `hst-fa-vitk` |

**Point douteux** : p. 11, le délai de 4 h du tube citraté attribué à un effet du
citrate « limité dans le temps » (comme la FC 2025-26, p. 9, qui parle de
pseudo-déficits). Le délai lui-même est une règle courante (« 4 heures pour la
plupart des tests » à température ambiante, guide pré-analytique d'HORIBA Medical, qui
renvoie au GFHT pour le détail par test) ; c'est l'explication qui ne trouve pas de
source : un délai dépassé fausse les résultats par l'activation ou la dégradation de
certains facteurs, pas par un épuisement de la chélation. Aucune carte ne la porte.

## Absent du cours 2026-27

Deux cartes (`ABSENTS_2026`, tag `absent-2026`), dont l'explication s'ouvre sur
« Absent du cours 2026-27 » et cite le cours 2024-25 (FC n°6, p. 8 et 17) et la FC
2025-26 (p. 6 et 11) :

| Carte | Ce qu'elle demande | Ce que la ronéo 2026-27 garde |
|---|---|---|
| `hst-rv-chaperonne` | la demi-vie du VIII, de 10-12 h à 2 h sans Willebrand | le rôle chaperon : transport, stabilisation, allongement de la demi-vie (p. 7), sans chiffres |
| `hst-rv-fxiii` | l'hémorragie à la chute du cordon, le dosage spécifique du XIII | le rôle du XIII dans la fibrinoformation (p. 13) |

Propositions isolées d'une autre année, qui le disent dans leur justification : la
rareté du déficit en XIII et son absence du bilan standard (`hst-qc-fibrine` D, E) ;
la transmission autosomique dominante de la maladie de Willebrand (`hst-qc-familles`
C) ; le myélogramme d'une thrombopénie (`hst-qc-vaisseau`, explication) ; l'âge et le
sexe sans effet sur les normes plaquettaires (`hst-qc-vaisseau` E) ; les cellules
tumorales (`hst-qc-initiation`, `hst-rv-ft`) ; le rôle de la phase contact dans les
thromboses (`hst-rv-xii`).

## Le schéma cliquable

`modele-cellulaire.svg`, redessiné nu — dix boîtes à cliquer, aucun mot dessus, les
seules étiquettes étant « 5 % » (l'initiation) et « 95 % » (amplification et
propagation, FC 2025-26, p. 10). Il répond à la question que le modèle en Y ne sait
pas traiter : **pourquoi l'hémophile saigne**.

| | |
|---|---|
| Initiation | facteur tissulaire + VIIa → seulement **5 %** de la prothrombine convertie (p. 12) |
| Amplification | la thrombine active les plaquettes et les cofacteurs V et VIII (p. 12) |
| Propagation | les deux complexes, sur plaquettes **activées** : génération explosive de thrombine (p. 13) |

L'initiation ne dépend **ni du VIII ni du IX** : elle est normale chez l'hémophile.
Ce sont les deux phases suivantes qui s'effondrent (p. 13). Les deux complexes
suivent le même patron — une enzyme, un cofacteur, un substrat :

| | Enzyme | Cofacteur | Substrat |
|---|---|---|---|
| **Ténase** | IXa | VIIIa | X |
| **Prothrombinase** | Xa | Va | II |

## Ce que le fascicule redemande

- **les trois étapes de l'hémostase primaire** — adhésion, activation, agrégation :
  deux QROC, même réponse ;
- **les trois rôles du facteur Willebrand** — adhésion via GPIb, agrégation via
  αIIbβ3, transport du facteur VIII ;
- **les quatre facteurs vitamine K dépendants** — II, VII, IX, X ;
- **les rôles de la thrombine**, posés sous quatre jeux de propositions.

Le piège récurrent est la substitution d'un seul mot : IX pour VIII, P2Y12 pour
PAR-1, ADP pour thromboxane, XII pour XIII, ténase pour prothrombinase. La ronéo
2026-27 en commet elle-même deux (VII pour VIII, « GPIb/X/IV »).

Le polycopié déborde le cours sur les inhibiteurs physiologiques (antithrombine,
protéine C), la fibrinolyse (plasmine, tPA) et l'interprétation du bilan (TCA, temps
de Quick) : ces questions restent cartées ici, sous `inhibiteurs` et `bilan`, et leur
explication dit « HORS COURS ». La ronéo 2026-27 ne nomme que la thrombomoduline
(p. 3) et le TFPI (p. 12).

## Clés d'annales non reprises telles quelles

La clé retenue est la bonne, pas la clé imprimée (règle de Vincent, 26/09) : la
question porte `cle_officielle` à faux, et la justification de chaque item en cause
dit que la correction imprimée n'est pas bonne, et pourquoi.

| Question | Clé imprimée | Retenu | Pourquoi | Source |
|---|---|---|---|---|
| 2020/2021, QCM 8 D (`hst-an-2021s1-q8`) — « la thrombine (facteur IIa) peut activer les plaquettes par l'intermédiaire du récepteur PAR-1 » | CE (D faux) | **CD** (D vrai) | la thrombine est l'activateur plaquettaire le plus puissant, par PAR-1 ; 2019/2020 S2 QCM 6 B donne vrai au même item | ronéo 2026-27, p. 6 et 8 ; cours 2024-25, p. 7 et 10 ; errata des annales ; Académie nationale de médecine |
| 2020/2021, QCM 8 E (`hst-an-2021s1-q8`) — « les propriétés anti-agrégantes plaquettaires de l'aspirine reposent sur l'inhibition de l'interaction entre l'ADP et le récepteur P2Y12 » | CE (E vrai) | **CD** (E faux) | l'aspirine inhibe la COX-1, donc le thromboxane A2 ; ce sont les inhibiteurs de P2Y12 qui bloquent l'ADP | ronéo 2026-27, p. 5, 6, 9 ; errata des annales ; médecine/sciences 2020 |

Une question non cartée : **2016/2017 session 2**, dont le polycopié imprime deux
énoncés sans aucune clé. **2023/2024** : la clé du QCM 1 (CDE) est confirmée par la
grille officielle (dépôt du 15/10/2026) et par la correction surlignée du sujet
(officieuse).

## L'échelle : Simple → Moyen → Annale (C20, 16/10/2026)

Sous les annales, **21 cartes Simple** (`niveau-simple`, une idée, trois choix, le
schéma troué dans la question) et **6 cartes Moyen** (`niveau-moyen`, une paire à ne
pas confondre, le schéma à lettres en correction). Chaque annale garde la figure de
la ronéo et reçoit son schéma (`diagramme=`) ; les QROC et les deux annales sans
lettre à poser (`hst-an-2021s1-q10`, `hst-an-1718s2-q1`) reçoivent le schéma nu.

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `primaire` | 6 | 1 | 4 |
| `recepteurs` | 5 | 1 | 2 |
| `willebrand` | 1 | 1 | 1 |
| `facteurs` | 2 | 1 | 3 |
| `modele` | 5 | 1 | 4 |
| `inhibiteurs` | 2 | 1 | 4 |
| `bilan` | 0 | 0 | 1 |

Clés des cartes Simple : 7 A, 7 B, 7 C ; les Moyen ont de une à trois vraies.

**Le schéma** `ech-hemostase`, « Hémostase primaire et coagulation · de la brèche au
caillot », donne 40 fichiers (complet, 21 troués, 18 à lettres). Il est décrit dans
`schemas.py` (`ECH_HEMOSTASE`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`,
copie exacte du modèle du skill.

**Le réalignement du 19/10/2026.** Chaque case a été relue sur la ronéo 2026-27, qui
les confirme toutes (p. 3-13) ; la légende du schéma la cite désormais, avec le cours
2024-25 et la FC 2025-26 en appoint. Une case est ajoutée en bas à droite,
« Lésion vasculaire · vasoconstriction réflexe · puis adhésion, activation,
agrégation » (p. 3), avec la marche `hst-ech-s21` (clé B) et la lettre A de
`hst-an-1718s2-q6`, rouge (la vasodilatation de l'énoncé est fausse). Chaque marche
cite sa page de l'année (`page`, fiche de l'année) et ses justifications citent les
pages de la ronéo 2026-27 ; `hst-ech-s14` garde son `ATTENTION` sur le chiffre de
l'initiation, réécrit sur les 5 % de l'année. Les renvois « ↗ Prépare … » ont perdu
leurs séparateurs parasites (« C, ,,  , E » est devenu « C, E »).

**Sans marche** :
- `hst-an-2021s1-q10` A-E : antithrombine, héparine, protéine C, thrombomoduline
  comme cofacteur, CIVD — absents des trois cours (la CIVD n'est qu'un objectif EDN,
  p. 2) ; ni marche ni lettre
- `hst-an-1718s2-q1` A-E : l'antithrombine, absente des trois cours ; ni marche ni
  lettre
- `hst-an-1718s2-q2` C, D, E : tPA, plasmine, hyperfibrinolyse — la fibrinolyse n'est
  que définie (p. 2-3)
- `hst-an-1819s2-q9` E : la plasmine — même raison
- `hst-an-1920s1-q2` E : thrombomoduline et protéine C — la ronéo nomme la
  thrombomoduline (p. 3), pas la protéine C
- `hst-an-1516s1-q1` C, E : antithrombine et plasmine ; lettres posées sur
  l'agrégation et l'activation, où l'item se joue
- `hst-an-qr-vitk` : malabsorption, cholestase, cirrhose — absentes du cours, qui ne
  donne que les AVK (p. 10)
- `hst-an-qr-fviii` : l'hémophilie A acquise — absente de ce cours
- `hst-an-qr-tca` : le TCA n'est pas développé par ce cours ; seul le XII, qui
  l'allonge sans faire saigner (p. 10), l'est (`hst-ech-s12`)

## Questions pour Vincent

- **Un lexique pour le tissu sanguin ?** Aucun chapitre de l'UE n'en a ; celui-ci
  pourrait accueillir hémostase, thrombopénie, thrombocytose, mégacaryocyte,
  fibrinolyse, zymogène. Pas fait sans ton accord.
- **Le délai du tube citraté** (4 h, p. 11) : la ronéo l'explique par un effet du
  citrate « limité dans le temps » ; c'est classé « point douteux », sans carte. Si
  le professeur l'a dit ainsi en amphi, la formule peut devenir un `ATTENTION (cours)`.
- **Quatre figures sont des diapositives entières que la page recadre** : les
  plaquettes (`plaquettes-diapositive.png`, la page ne montre que la photographie,
  p. 4), le calcium (`calcium-tube-citrate.png`, le schéma du complexe seul, p. 11),
  les complexes et l'amplification (`tenase-prothrombinase.png`,
  `amplification-thrombine.png`, sans titre ni légende, p. 12). Les images sont dans
  le PDF de l'année et viennent du professeur ; `hst-qc-facteurs` E cite le texte
  caché de la diapositive du calcium. Les garder entières ?

## Régénérer

```
..\..\..\app\.venv\Scripts\python.exe generer.py
```

Le script écrit d'abord les SVG, puis valide : une justification manquante, un
trou de plus de deux mots, deux zones qui se recouvrent, une page hors de la fiche,
un conflit déclaré mais non signalé — et il refuse d'écrire.
