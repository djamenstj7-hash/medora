# Radioprotection — paquet BMCP

72 notes, 159 cartes. Chapitre `chap-ue-bmcp-fc14` de l'UE BMCP, quinzième de
l'UE (`ordre=15`, le numéro de la FC 2025-26). Cours du **Pr Semah, le
21/11/2025**, en deux parties d'une heure (10 h-11 h, puis 11 h-12 h), dans le
**Ronéosaure 2025-26** (FC n°15, deux PDF de 8 pages) ; les annales du
polycopié BMCP 14 du Ronéosaure 2024-25 (8 QCM sur 4 sessions) et deux QCM du
**sujet de 2024/2025 S1** (examen du 09/01/2025, sans corrigé, déposé le
15/10/2026). Examen : mardi 5 janvier 2027.

**Fiche provisoire** (C16, décision de Vincent du 02/10) : le cours de l'année
2026-27 n'est pas encore paru. Chaque carte de cours cite la FC 2025-26 à sa
page (`page=`, et `fiche=` pour la partie 2) ; le badge « Cours 2025-26 » vient
de l'auteur des deux sources. Le ronéo 2026-27 corrigera les cartes quand il
sortira.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 31 | 31 |
| QRU | 1 | 1 |
| Texte à trous | 14 | 90 |
| QROC | 10 | 10 |
| Recto-verso | 5 | 5 |
| Schéma cliquable | 2 | 13 |
| Lexique | 9 | 9 |

Dont **10 annales** (QCM) sur 5 sessions. **32 QCM sur 32 sont illustrés**, du
côté de la réponse.

Six thèmes, dans l'ordre du cours, **tous nouveaux** : leurs libellés sont dans `THEME_LABELS` (`app/src/med_engine/application/scopes.py`) depuis l'intégration du 05/10.

| Clé | Libellé | Notes |
|---|---|---|
| `sources-irradiation` | Sources d'irradiation naturelles et artificielles | 18 |
| `accidents-nucleaires` | Accidents nucléaires : INES, Tchernobyl, Fukushima | 9 |
| `effets-biologiques` | Effets stochastiques et déterministes | 6 |
| `limites-doses` | Public, patient, travailleur : limites de dose | 8 |
| `principes-radioprotection` | Justification, optimisation, limitation | 9 |
| `moyens-protection` | Moyens de protection, PCR et dosimétrie | 13 |

## Les sources et leurs années

| Source | Id | Rôle |
|---|---|---|
| FC n°15 partie 1 radioprotection (Ronéosaure 2025-26, 8 p.) | `src-fc-bmcp-rdp1-2526` | fiche du chapitre (`SRC["fiche"]`), cartes de la partie 1 |
| FC n°15 partie 2 radioprotection (Ronéosaure 2025-26, 8 p.) | `src-fc-bmcp-rdp2-2526` | seconde fiche, `fiche=P2` sur ses cartes |
| BMCP 14 - Radioprotection (Ronéosaure 2024/2025, 4 p.) | `src-annales-bmcp-14-radioprotection` | les annales |
| Sujets de BMCP 2024/2025, session 1 (examen du 09/01/2025, 30 p., sans corrigé) | `src-sujets-bmcp-2425` | la session 2024/2025 S1 (Q29, Q30) ; déclarée à l'identique dans tous les chapitres de BMCP qui en tirent une question |

Les deux fiches portent `chapitre=` : `outils/copier_les_cours.py` les copie dans
le dossier des PDF de l'application (`BMCP/FC n°15 partie 1 radioprotection.pdf`
et `… partie 2 …`). Le polycopié d'annales est déclaré avec les seuls champs
communs à tous les chapitres qui le citent : `bmcp_bases_physiques` déclarera
le même fichier pour sa question 2023/2024 S1 Q21.

Appoints cités dans les justifications, sans carte qui en dépende entièrement :
le ronéo 2024-25 « FC n°14 - La radioprotection » (la radiographie à 0,06 mSv,
p. 15 ; « la dosimétrie ne protège pas », p. 17 ; les « millions de morts » de
Tchernobyl, p. 12) et le cours 2023-24 « 16. BMCP - Imagerie : la
radioprotection » (la dose efficace en sievert, p. 13 ; 20 000 cancers de la
thyroïde chez les moins de 18 ans, p. 15). Sources sûres : CIPR, publication
103 (dose efficace) ; décision n° 2019-DC-0667 de l'ASN, homologuée le
23/05/2019 (NRD) ; page « NRD » et page « L'exposition à la radioactivité
naturelle en France » de l'ASNR ; décret n° 2018-437 (cristallin) ; loi du
21/05/2024 (ASNR) ; UNSCEAR (rapport 2008, livre blanc 2018) et Forum
Tchernobyl (2005).

## Ce que le cours a dicté

- **Le rouge** : une seule phrase, « La Dose maximale dans la population est de
  1 mSv / an sauf applications médicales » (partie 1, p. 2) — `rdp-qr-limite-public`,
  `rdp-qc-introduction` A, `rdp-fa-limites`.
- **« Bien retenir les pourcentages »** (partie 1, p. 6) : le camembert de
  l'IRSN — `rdp-fa-camembert`, `rdp-qc-camembert`, la zone `rdp-zo-camembert`.
- **« IMPORTANT »** sur la diapositive « Quatre règles et 3 principes »
  (partie 2, p. 6) — `rdp-fa-principes`, `rdp-qc-principes`, `rdp-qr-alara`.
- **Le gris** (exemples de la cave bretonne, de Fukushima, de l'ISS) se carte
  comme le reste (décision du 25/09), en explications.
- **Ce que le professeur a dit de laisser** : la distinction contamination /
  exposition, « notion peu approfondie par le prof » (partie 1, p. 3), n'a que
  son terme de lexique ; la surveillance des travailleurs exposés, « ne sont
  pas à apprendre pour l'examen » (partie 2, p. 7), n'a aucune carte.
- Ce que d'autres chapitres cartent (plan C16, § 0.7) : les données
  dosimétriques du compte rendu (FC 16), la dose d'une TEP au FDG (FC 18), les
  dangers des rayons X au scanner (FC 21).

## Ce que les annales ont dicté

| Polycopié | Session | N° | Clé imprimée | Retenu | Carte | Remarque |
|---|---|---|---|---|---|---|
| BMCP 14 | 2023/2024 S1 | Q27 | ADE | ADE | `rdp-an-2324s1-q27` | |
| BMCP 14 | 2023/2024 S1 | Q28 | BCD | BCD | `rdp-an-2324s1-q28` | |
| BMCP 14 | 2022/2023 (S1) | Q29 | ABCD | ABCD | `rdp-an-2223s1-q29` | « Année 2022/2023 » sans session |
| BMCP 14 | 2022/2023 (S1) | Q30 | ABC | ABC | `rdp-an-2223s1-q30` | idem |
| BMCP 14 | 2018/2019 (S1) | Q29 | ACDE | ACDE | `rdp-an-1819s1-q29` | dose efficace, hors cours 2025-26 ; sans session |
| BMCP 14 | 2018/2019 (S1) | Q30 | BC | BC | `rdp-an-1819s1-q30` | NRD, hors cours 2025-26 (ATTENTION dans l'explication) ; sans session |
| BMCP 14 | 2017/2018 (S2) | Q27 | AC | AC | `rdp-an-1718s2-q27` | E : le piège du radon « tellurique » ; sans session |
| BMCP 14 | 2017/2018 (S2) | Q28 | BC | BC | `rdp-an-1718s2-q28` | D : CONFLIT avec le ronéo 2025-26 ; sans session |
| sujet 2024/2025 | 2024/2025 S1 | Q29 | aucune (sujet sans corrigé) | BCD | `rdp-an-2425s1-q29` | reprise de 2023/2024 S1 Q28 : l'énoncé ajoute « à la radioprotection et », A dit « et de radiologie » pour « ou de radiologie » ; le reste mot pour mot |
| sujet 2024/2025 | 2024/2025 S1 | Q30 | aucune (sujet sans corrigé) | E | `rdp-an-2425s1-q30` | neuve ; A : le piège du radon « tellurique » |

La neuvième question du polycopié, 2023/2024 S1 Q21 (les modalités d'imagerie),
est cartée dans `bmcp_bases_physiques`.

Ce qui revient : les moyens de protection, temps, distance, écran, et la gélule
d'iode qui n'en est pas un (trois fois, dont 2024/2025 Q29) ; la composition de
l'exposition moyenne, un tiers de radon et un tiers de médical (trois fois, dont
2024/2025 Q30) ; l'absence de limite pour le patient (quatre propositions).

## Les clés qui ne sont pas reprises telles quelles

**Aucune** des huit clés imprimées n'est contestée : elles sont justes et
reprises (`officielle`). Les deux questions de 2024/2025 n'ont **aucune clé
imprimée** (sujet sans corrigé) : clés déduites du cours, `officielle=False`.

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2017/2018 Q28 D | fausse | fausse (clé officielle) | La clé est juste ; c'est le ronéo 2025-26 qui écrit les cancers de la thyroïde « chez les personnes âgées et chez les enfants » (partie 2, p. 3). Déclaré dans `CONFLITS`, ATTENTION dans la justification de D. |
| 2018/2019 Q30 | BC | BC | Les NRD sont absents des cours 2025-26 et 2024-25 : la clé est vérifiée sur la décision n° 2019-DC-0667 (grandeurs PDS, IDSV, PDL, MBq ; radiologie conventionnelle et scanographie ; évaluations transmises chaque année à l'IRSN, deux actes par appareil ou par service, d'après le bilan NRD 2019-2021 de l'IRSN — à l'ASNR depuis le 01/01/2025 ; « pas des limites de dose »). |
| 2017/2018 Q27 E | fausse | fausse | Juste au sens de l'IRSN (cosmique 7 % + tellurique 14 %), mais le ronéo range le radon dans l'origine tellurique (partie 1, p. 4) : la justification dit le piège. |
| 2024/2025 S1 Q29 | aucune (sujet sans corrigé) | BCD (`officielle=False`) | Clé déduite du cours, la même que celle, officielle, de 2023/2024 S1 Q28, que la question reprend : temps, distance, écran (partie 2, p. 8) ; pas de dosimètre à lecture directe pour tous (A), pas de gélule d'iode (E). |
| 2024/2025 S1 Q30 | aucune (sujet sans corrigé) | E (`officielle=False`) | Clé déduite du cours : un tiers médical (partie 1, p. 6) ; le tellurique ne fait que 14 % (A faux — le même piège du radon que 2017/2018 Q27 E, tranché de la même façon que sa clé officielle), les rejets 1 % (B), pas de limite pour le patient (C, partie 2 p. 4-5), une exposition tellurique qui « dépend fortement des régions » (D, partie 1 p. 4). |

## Les erreurs du ronéo 2025-26

Signalées par un **ATTENTION nu** (le Ronéosaure n'est pas la ronéo de
l'année) ; rien n'entre dans `contenu/ERRATA_RONEOS_2026-27.md`. L'errata de la
promo 2025-26 (`Erratas BMCP.docx`) n'a aucune entrée pour ce cours, celui des
annales aucune pour BMCP 14.

| Page | Le ronéo | Retenu | Sorte | Cartes |
|---|---|---|---|---|
| partie 2, p. 5 | « ASN est devenue l'ANSR depuis 2024 », « IRN + ASN = ANSR » | **ASNR**, Autorité de sûreté nucléaire et de radioprotection, née le 1er janvier 2025 de l'ASN et de l'**IRSN** (loi du 21/05/2024) ; la diapositive écrit « ASNR » | prise de notes | `rdp-qc-asnr` (A), `rdp-qr-asnr`, `rdp-fa-reglementation` |
| partie 2, p. 3 | cancers de la thyroïde « chez les personnes âgées et chez les enfants » | les sujets exposés enfants ou adolescents (UNSCEAR 2018 ; cours 2023-24, p. 15) ; le ronéo dit lui-même qu'aucune autre tranche d'âge n'a augmenté | prise de notes | `rdp-qc-tchernobyl`, `rdp-qr-thyroide`, `rdp-an-1718s2-q28` (D) |
| partie 1, p. 6 | radiographie du thorax « 0,02 mSv » | 0,06 sur la diapositive ; 0,02 est la radiographie dentaire panoramique (et le ronéo 2024-25, p. 15, dit 0,06) | prise de notes | `rdp-qc-medical` (A) |
| partie 1, p. 5 | rayons cosmiques « émis par le soleil », « plus on se rapproche du Soleil, plus on en a » | origine galactique et solaire ; la dose croît avec l'altitude, la latitude, l'activité solaire (ASNR) | point douteux | `rdp-fa-cosmique`, `rdp-qc-cosmique` |
| partie 1, p. 6 | le scanner abdomino-pelvien « (TAP) » « retrouvé en France » à 9 mSv | 10 mSv sur la figure de l'IRSN, 9 au CHU après optimisation (la flèche de la diapositive) ; un TAP est thoraco-abdomino-pelvien | point douteux | `rdp-qc-medical` (D) |
| partie 2, p. 8 | seringue de FDG « à 50 cm », « à 10 cm de plus » : 252 puis 63 µSv | un facteur 4 suppose une distance doublée (loi du carré de la distance) ; 50 → 60 cm ne divise que par 1,44 ; même texte dans le ronéo 2024-25 | point douteux | `rdp-qc-moyens` (B) |
| partie 2, p. 2 | « En 1896, Becquerel découvre que la radioactivité naturelle est dangereuse : elle brûle » | 1896 est la découverte de la radioactivité ; la brûlure de Becquerel (tube de radium dans la poche du gilet) et l'expérience de Pierre Curie datent de 1901 | point douteux | `rdp-qc-pionniers` (A) |
| partie 2, p. 3 (et partie 1, p. 6) | à Fukushima, « une dose maximale de 200 mSv » pour les travailleurs | la limite d'urgence a été relevée de 100 à 250 mSv le 14/03/2011 par le gouvernement japonais ; les 6 travailleurs « > 250 mSv » du ronéo sont ceux qui l'ont dépassée | point douteux | `rdp-qc-fukushima` (C) |

Une imprécision laissée sans carte : le Kerala, « le pays le plus touché » par
la radioactivité tellurique (partie 1, p. 4), est un État de l'Inde, et
d'autres régions dépassent ses doses ; la carte `rdp-fa-tellurique` le dit
« un exemple du cours », sans le classement.

## Les schémas et les figures

| Fichier | Ce qu'on clique | Cartes |
|---|---|---|
| `exposition-moyenne.svg` | la part d'une source dans les 4,5 mSv : médical, radon, tellurique, aliments-eau-tabac, cosmique (5 zones ; le liseré des installations, < 1 %, n'est pas une zone) | `rdp-zo-camembert` |
| `echelle-doses.svg` | un repère sur une échelle logarithmique de 0,1 à 10 000 mSv : cosmique 0,3, public 1, moyenne 4,5, scanner abdomino-pelvien 9-10, travailleur 20, liquidateurs 120, peau 500, pompiers > 1 000 (8 zones) | `rdp-zo-echelle-doses` |
| `trois-moyens.svg` | rien : un dessin de correction, temps (21 → 250 µSv), distance (dose ÷ 4 quand elle double), écran | QCM et textes des moyens |

Le camembert est redessiné nu (pourcentages imprimés, sources effacées) et
légendé pour la correction ; les deux arcs « origine naturelle » et « origine
artificielle » séparent le médical (34 %) du radon (33 %), que l'œil ne
départage pas. L'échelle reprend la pyramide des doses de la partie 1, p. 2.

Quinze figures du ronéo, extraites en PNG dans `media/` (captures de
diapositives) : pyramide des doses (p1 p. 2), frise historique (p1 p. 3), carte
de l'uranium (p1 p. 4), exposition médicale et camembert de l'IRSN (p1 p. 6),
Hiroshima et échelle INES (p1 p. 7), application de l'échelle INES (p1 p. 8),
pénétration des rayonnements (p2 p. 2, **la photographie de la main brûlée
coupée** : aucune photographie de patient), tableau stochastiques /
déterministes (p2 p. 2), réglementation et codes (p2 p. 5), « Quatre règles et 3
principes » (p2 p. 6), limites de dose (p2 p. 7), zones et trèfles (p2 p. 8).

## Le lexique

Neuf termes, ceux du plan C16 (§ 13), aucun déjà dans l'UE ni ailleurs dans le
dépôt : Irradiation, Contamination, Tellurique, Stochastique, Déterministe,
Radiodermite, Radiosensible, Cataracte, Dosimétrie. Pages mesurées dans les deux
PDF (motif de `chercher_pages.py`, sur le texte de PyMuPDF) ; « Contamination »
garde sa page de la partie 1 (la notion « peu approfondie ») et celle de la
partie 2 (p. 8, la contamination interne).

Étymologies vérifiées (Wiktionnaire, Gaffiot, Bailly, TLFi par la table) et
proposées dans `scratchpad/etym/bmcp_radioprotection.json` : quatre racines
nouvelles — `radi- (latin)` (radius, rayon ; enseignée sous cette forme par la
FC de sémantique 2/2, p. 12, et proposée sous la même clé par
`bmcp_bases_imagerie` et `bmcp_medecine_nucleaire`), `contaminare (latin)`,
`tellus (latin)`, `stochos (grec)` — et les neuf termes. Racines déjà dans la table, reprises à
l'identique : `in- (latin, dans)`, `terminus (latin)`, `derm(o)-`, `-ite`,
`sentire (latin)`, `cata- (grec)` (sémantique 2/2, p. 10), `dosis (grec)`,
`-métrie`. Les définitions portent déjà leur phrase d'étymologie, écrite au
format de `appliquer_etymologies.py`.

## Questions pour Vincent

1. **Les sessions de trois années.** Le polycopié BMCP 14 imprime « Année
   2022/2023 », « Année 2018/2019 » et « Année 2017/2018 » sans session, et sa
   table aussi. Proposition du plan, appliquée et dite sur chaque carte :
   2022/2023 et 2018/2019 en **session 1**, comme les questions d'imagerie de
   ces années dans les polycopiés voisins ; 2017/2018 en **session 2**, parce que
   la session 1 a déjà une Q28 (le scanner, BMCP 19) et que la session 2 a des
   Q26, Q29 et Q30 d'imagerie et rien en 27-28. Les identifiants
   (`rdp-an-2223s1-…`, `rdp-an-1819s1-…`, `rdp-an-1718s2-…`) suivent cette
   proposition.

## Décisions prises en route

- **Le brouillon du 03/10**, laissé par une passe interrompue (`schemas.py` et
  quinze PNG, sans `donnees.py`), a été relu comme un travail neuf : chaque
  image comparée à la page qu'elle cite (toutes justes, la photo de patient
  bien coupée) ; les deux schémas gardés, avec deux corrections — le repère du
  scanner abdomino-pelvien, « 9 mSv en France », devenu « 9 à 10 mSv » (10 sur
  la figure de l'IRSN, 9 au CHU), et la mention « bilan 2014-2019 » retirée du
  pied du camembert, faute de l'avoir vérifiée. Ajout de `trois-moyens.svg`.
- Le gradient de l'échelle des doses ne se voit pas dans le rendu de MuPDF ; il
  s'affiche dans un navigateur (vérifié).
- La QRU du cristallin (`rdp-qc-cristallin`) suit le cours (« 20 mSv / an,
  depuis 2023 ») et le décret n° 2018-437 ; les valeurs de la catégorie B et du
  public viennent du tableau de la diapositive (p2 p. 7).
- **Relecture critique (05/10)** : chaque carte relue contre sa page, chaque
  figure contre la sienne, les deux schémas rendus avec leurs zones
  superposées. Corrigé : la limite de Fukushima (200 mSv dans le ronéo, 250 mSv
  en réalité), dite par un ATTENTION nu sur `rdp-qc-fukushima` ; la
  justification C des NRD (fréquence et nombre d'actes, d'après le bilan
  2019-2021 de l'IRSN) ; la clé de racine `radi- (latin)`, alignée sur la FC de
  sémantique et les chapitres voisins ; « personne de compétence en
  radioprotection », la forme du ronéo, acceptée pour `rdp-qr-pcr` ; un fond
  blanc sous les légendes de l'échelle des doses, que la grille barrait ; le
  pied de `trois-moyens.svg`, ramené aux écrans du cours (vitre au plomb, murs).
- `rdp-codes.png` (partie 2, p. 5 : accord international, codes de la santé
  publique et du travail) est déclarée mais n'illustre aucune carte : aucune
  carte ne porte sur les codes.

## À relire

Aucune carte `a-relire` : chaque carte de cours cite sa page, les deux
annales hors du cours 2025-26 (dose efficace, NRD) s'appuient sur des sources
sûres nommées dans leurs justifications, et les deux de 2024/2025 (sans
corrigé) se tranchent sur les pages du cours.

## Intégration (05/10)

- Les libellés de thèmes sont dans `THEME_LABELS`
  (`app/src/med_engine/application/scopes.py`), bloc « BMCP FC n°6 à 22 ».
- Les étymologies proposées (racines et termes) sont versées dans
  `.claude/skills/nouveau-chapitre/scripts/etymologies.json` ;
  `appliquer_etymologies.py` n'a rien réécrit, les textes du lexique étant
  déjà à sa forme.
- `radi- (latin)` n'a qu'une entrée, commune avec `bmcp_bases_imagerie`,
  `bmcp_medecine_nucleaire` et `bmcp_bases_physiques`.

## L'échelle : Simple → Moyen → Annale (C20, 19/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 5 janvier (BMCP) ou du 6 janvier (SSH, papier). Sous les annales, 29 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 4 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`).

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `sources-irradiation` | 10 | 1 | 3 |
| `accidents-nucleaires` | 4 | 1 | 1 |
| `principes-radioprotection` | 7 | 1 | 3 |
| `moyens-protection` | 8 | 1 | 3 |

**Le schéma** `ech-radioprotection`, « La radioprotection · d'où vient la dose, qui protéger, comment », donne 44 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_RADIOPROTECTION`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Sans marche** :
- 2018/2019 S1 Q29 A (rdp-an-1819s1-q29) : la dose efficace en sievert — le cours 2025-26 ne la définit pas (seul le cours 2023-24 le dit, p. 13) et le schéma écrit ses doses en mSv partout : une case vide ne cacherait pas l'unité ; la lettre est posée sur « Exposition moyenne en France ».
- 2018/2019 S1 Q30 A, B, C, D (rdp-an-1819s1-q30) : les niveaux de référence diagnostiques sont absents des cours 2025-26 et 2024-25 (décision ASN 2019-DC-0667) ; les lettres sont posées sur « Optimisation », dont les NRD sont l'outil, et E est préparée par rdp-ech-s17 (le patient n'a pas de limite).
- 2017/2018 S2 Q28 E (rdp-an-1718s2-q28) : le bilan des morts de Tchernobyl selon les Nations unies n'est pas dans le cours 2025-26, qui ne donne que les décès des pompiers ; lettre posée sur « Tchernobyl (1986) ».

## Régénérer

```powershell
cd contenu\chapitres\bmcp_radioprotection
..\..\..\app\.venv\Scripts\python.exe generer.py
```

`generer.py` est la copie exacte de
`.claude/skills/nouveau-chapitre/scripts/generer_modele.py`.
