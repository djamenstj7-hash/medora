# Pharmacodynamie de la neurotransmission — paquet BMCT

107 notes, 180 cartes. Chapitre `chap-ue-bmct-fc8` de l'UE BMCT, huitième de
l'UE. **Cours du Pr David Devos du 12/10/2026, de 8 h à 9 h, dans le ronéo
« Neurotransmission » de Ronéo & Juliette 2026-27** (12 p., déposé le
19/10/2026). Réaligné sur lui le 19/10/2026 ; il était carté depuis le 02/10
(tâche C14) sur la FC n°8 du Ronéosaure 2025-26 (Pr Devos, 14/10/2025, 7 p.),
qui n'est plus qu'un appoint. Annales : le polycopié « Pharmacologie de la
neurotransmission » du Ronéosaure 2024-25 (15 sessions) et deux questions du
sujet 2024/2025 (déposé le 15/10/2026). Examen : partiel du mercredi
4 novembre 2026.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 45 | 45 |
| QRU (marches Simple) | 24 | 24 |
| Texte à trous | 13 | 81 |
| QROC | 7 | 7 |
| Recto-verso | 6 | 6 |
| Lexique | 10 | 10 |
| Schéma cliquable | 1 | 6 |
| Planche à légender | 1 | 1 |

Dont **19 annales** (QCM) sur 16 sessions, de 2015/2016 S1 à 2024/2025 S1 : tout
le polycopié (17), et les Q2 et Q3 du sujet 2024/2025 (`ntr-an-2425s1-q2`,
`ntr-an-2425s1-q3`), deux questions neuves sans corrigé, clés déduites du cours.
Le PDF du sujet porte une correction surlignée en bleu, officieuse et d'origine
inconnue (le même surligneur reproduit 37 des 40 clés officielles de 2023-24) :
non déclarée, elle sert de seconde opinion, et donne les mêmes clés (ABD, ACD).
Les clés 2023/2024 S1 (Q1 BCD, Q2 BC) sont confirmées par la grille officielle de
la faculté (dépôt du 15/10/2026). **22 QCM de cours**, dont 7 nouveaux, et
**28 marches de l'échelle** (24 Simple, 4 Moyen). **69 QCM sur 69 illustrés
(100 %)**, 94 notes sur 107. **Aucune carte absente du cours 2026-27** ;
**16 cartes portent un piège du ronéo** (thème « Pièges des ronéos »).

Six thèmes, dans l'ordre du cours, tous déjà dans `THEME_LABELS`
(`app/src/med_engine/application/scopes.py`) ; le réalignement n'en ajoute aucun :

| Clé | Libellé | Notes |
|---|---|---|
| `neurotransmetteurs` | Neurotransmetteurs et noyaux | 29 |
| `modulation-synaptique` | Moduler une synapse | 18 |
| `dopamine` | Système dopaminergique | 23 |
| `addiction` | Addiction et récompense | 4 |
| `serotonine` | Système sérotoninergique | 10 |
| `acetylcholine-centrale` | Système cholinergique central | 13 |

(et les 10 termes du lexique, sans thème.)

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-bmct-ntr-2627` — « Neurotransmission » (12 p., la dernière vide), `BMCT/NEUROTRANSMISSION.pdf` | **2026-27** | **la fiche** (`SRC["fiche"]`, constante `FC1`, `chapitre=`) : ce que le lecteur ouvre, la page que cite chaque carte, ses onze figures |
| `src-fc-bmct-ntr-2526` — FC n°8, « Pharmacodynamie de la neurotransmission » (7 p.) | 2025-26 | **appoint** (`SRC["cours"]`, constante `FC2526`, sans `chapitre=`) : ce que le ronéo 2026-27 ne redit pas, et quatre figures qu'il ne reprend pas |
| `src-annales-bmct-pharmacologie-de-la-neurotransmission` — « BMCT - Pharmacologie de la neurotransmission » (7 p.) | 2024-25 | 15 sessions, 17 QCM, table p. 6-7 |
| `src-sujets-bmct-2425` — Sujets de BMCT 2024/2025, session 1 (20 p.) | 2024-25 | les Q2 et Q3, sujet sans corrigé ; `SRC["sessions"]["2024/2025 S1"]` ; déclaré à l'identique par tous les chapitres de BMCT qui en cartent une question |
| tableau d'erreurs BMCT de la promo 2026-27 | 2026-27 | **rien sur ce cours** au 19/10/2026 (deux entrées, sur la pharmacocinétique) |

Les textes citent « p. 5 » pour le ronéo 2026-27 et « FC 2025-26, p. 5 » pour le
Ronéosaure. Lus en appoint, sans être déclarés : le ronéo 2024-25 du même cours
(FC n°6 2024-25) et le cours 2023-24 (Charonéo), pour comprendre une annale ou
trancher une erreur ; l'errata des cours 2025-26 et celui des annales. La fiche de
l'année se copie dans le dossier des PDF de l'application par
`outils/copier_les_cours.py`, lancé avec le dossier des ronéos 2026-27
(`Ajouts/[NUMERIQUE] Ronéo & Juliette 26-27 19 10 2026/S1/CM`), hors du bac à
sable.

Les en-têtes des ronéos, de l'errata et du polycopié portent des noms
d'étudiants : aucun n'est repris.

## Ce qui correspond à quoi

Le ronéo 2026-27 suit le plan de la FC 2025-26, et lui ajoute deux parties :

| FC 2025-26 | Ronéo 2026-27 |
|---|---|
| I.A Généralités (p. 2) | I.A Introduction (p. 2) — et l'étiopathologie |
| I.B Les six neurotransmetteurs, leur part des neurones (p. 2) | I.B Le tableau des neurotransmetteurs, la balance excito-inhibitrice (p. 2-3) |
| Les noyaux et leurs maladies (p. 3) | Les noyaux, « à titre informatif » (p. 3) |
| II.A Les trois voies dopaminergiques (p. 3) | II.A (p. 3-4) |
| II.B Transmission synaptique (p. 3-4) | II.B (p. 4) |
| II.C Synthèse de la dopamine, récepteurs D1 à D5 (p. 4) | II.C (p. 4-5) : le schéma de la synthèse et de la libération, le TDAH, la cocaïne, les deux familles, D2 et D3 dans le striatum |
| II.D Agonistes et antagonistes (p. 5) | II.D (p. 5-6), la diapositive de sélectivité des récepteurs DA |
| II.E Rôles, pathologies, médicaments, substances (p. 5-6) | II.E (p. 6) : rôles, médicaments, cocaïne, addiction ; schéma de synthèse sur la dopamine et médicaments de 2026 (p. 7) |
| III. Sérotonine, récepteurs, implications cliniques (p. 6-7) | III.A-C (p. 7-8) |
| — | **III.D Cibles pharmacologiques des antidépresseurs (p. 9)** |
| IV. Noyau de Meynert, synapse cholinergique (p. 7) | IV.A-B (p. 9-10) |
| — | **IV.C Implication clinique : les démences (p. 10-11)** |

## Le réalignement du 19/10/2026

Les 95 notes de la version 2025-26 ont été relues une à une contre le ronéo
2026-27. **Toutes gardent leur notion centrale dans le cours de l'année** :
toutes portent désormais la page de l'année (`page=`) et perdent le badge
« Cours 2025-26 ». Chaque proposition, chaque trou ou chaque détail que seul le
cours 2025-26 porte le dit dans sa justification (« FC 2025-26, p. 3 ; le ronéo
2026-27 ne le dit pas »).

| Page 2026-27 | Notes |
|---|---|
| 2 | `ntr-fa-moduler`, `ntr-fa-proportions`, `ntr-fa-roles`, `ntr-qc-synapse`, `ntr-qc-neurotransmetteurs`, `ntr-qr-glutamate`, marches `s1`, `s2`, `s3`, `s4`, `s8`, `s11` |
| 3 | `ntr-fa-noyaux`, `ntr-fa-voies`, `ntr-qc-noyaux`, `ntr-qc-voies`, `ntr-zo-noyaux`, marches `s5`, `s12`, `m2` |
| 4 | `ntr-fa-etapes`, `ntr-fa-catabolisme-da`, `ntr-qc-transmission`, `ntr-qc-catabolisme-da`, `ntr-rv-voies`, `ntr-pl-synapse`, marches `s14`, `s15`, `s27`, `s30`, `m6`, `m4` |
| 5 | `ntr-qc-recepteurs-da`, `ntr-qc-agonistes`, `ntr-qr-dat`, `ntr-rv-parkinson-schizophrenie`, `ntr-rv-familles-d`, marches `s19`, `s28`, `s29` |
| 6 | `ntr-fa-dopamine-roles`, `ntr-fa-substances`, `ntr-qc-animal`, `ntr-qc-role-dopamine`, `ntr-qc-cocaine`, `ntr-qr-prolactine`, marches `s6`, `s7`, `s20`, `s21`, `s25` |
| 7 | `ntr-fa-serotonine-synthese`, marche `s10` |
| 8 | `ntr-qc-serotonine`, `ntr-qc-serotonine-clinique`, `ntr-qr-clozapine`, `ntr-qr-5ht3`, `ntr-qr-sumatriptan`, marche `s9` |
| 9 | `ntr-fa-meynert`, `ntr-qc-meynert`, `ntr-rv-mao` |
| 10 | `ntr-qc-alzheimer`, `ntr-rv-fin-action`, marches `s22`, `m7` |
| 11 | `ntr-fa-alzheimer`, marche `s23` |

Les 17 annales et les 8 termes de lexique sont relus aussi : les justifications
citent la page de l'année, le lexique ses pages 2026-27 puis celles de 2025-26.

**Ce que le ronéo 2026-27 dit autrement, et ce qui a été réécrit** :

- **Le tableau des neurotransmetteurs** (p. 2) : le GABA « frein, grand
  ralentisseur » (anesthésie générale, épilepsie) ; la dopamine « motricité,
  émotion, plaisir », un déficit fait la maladie de Parkinson, un excès
  l'addiction ; la noradrénaline « vigilance, éveil, système fight ».
  `ntr-fa-roles` est réécrit sur lui (le trou c5 devient « plaisir », au lieu de
  « anticipation » ; les autres trous restent) ; la marche `s6` et la ligne
  « Dopamine » du schéma de l'échelle disent « plaisir, motivation, récompense ».
- **Les parts des neurones** : seuls le GABA et le glutamate (30 à 40 % chacun)
  restent ; les 2 % et 1-2 % des quatre autres (`ntr-fa-proportions` c4 à c6,
  plusieurs justifications) viennent de la figure de la FC 2025-26, citée comme
  telle.
- **Les noms des noyaux sont « pas à connaître (mis à titre informatif) »** : il
  faut « uniquement retenir que toutes les sources se trouvent au niveau du tronc
  cérébral » (p. 3). Le noyau de Meynert reste au programme (titre du IV.A, p. 9 ;
  annale 2024/2025 S1 Q3 A). La carte de zone `ntr-zo-noyaux`, qui ne demande que
  des noms et des lieux, prend le tag `edn` (« Pour les EDN (hors partiel) ») ;
  les autres le disent dans leur explication.
- **La voie mésolimbique** : dépression, anxiété, apathie, addiction, obésité ; la
  schizophrénie en exemple (p. 4). `ntr-fa-voies` remplace la bipolarité par la
  dépression et l'apathie (mêmes trous) ; `ntr-rv-voies` est réécrit.
- **« Vésiculation »** (p. 4), au lieu de « vésiculisation » : le trou c2 de
  `ntr-fa-etapes` suit l'année.
- **Le TDAH** : « le flux tonique inhibiteur n'est pas assez fort » (p. 5) ;
  `ntr-fa-catabolisme-da` est réécrit (dopamine mise en vésicules parce que,
  libre, elle s'oxyde et peut tuer le neurone ; TDAH par flux tonique inhibiteur
  trop faible), mêmes cinq trous.
- **La synapse cholinergique et les démences** (p. 10-11) : nausées, vomissements
  et **vertiges** (la diarrhée n'est plus citée), et l'anticholinestérasique
  « ne constitue pas un traitement curatif ». `ntr-fa-alzheimer` est réécrit : le
  trou c4 devient « vomissements », c5 « curatif » (il demandait la recapture
  impossible, que l'année ne dit plus) ; `ntr-qc-alzheimer` C et la marche `m7` C
  disent « vertiges ».
- **Le système cholinergique est « holocrânien »** (p. 9) : `ntr-fa-meynert` c5
  le demande, au lieu de la mémoire qu'altère la scopolamine (FC 2025-26, dite
  dans l'explication).
- **Les familles D1 (D5) et D2 (D3, D4)** sont enfin justes dans le ronéo
  (p. 5) ; l'effet sur l'adénylate cyclase n'y est plus (`ntr-rv-familles-d`,
  `ntr-qc-recepteurs-da` E le disent de la FC 2025-26).
- **L'halopéridol, la clozapine « fine », le Largactil, la schizophrénie
  génétique, le bipolaire, le DAT nommé, la prise « explosive », la sérotonine
  qui détend, les étudiants canadiens, la scopolamine, la recapture impossible**
  ne sont plus dans le cours : les propositions qui les portent le disent, sans
  que leur carte devienne absente.
- **Les figures** : onze figures du ronéo 2026-27 (dont six nouvelles) remplacent
  celles de la FC 2025-26 dans les cartes qui citent l'année ; voir plus bas.

**Notes nouvelles (12)**, sur ce que le cours 2026-27 apporte :

| Note | Ce qu'elle carte |
|---|---|
| `ntr-qc-balance` | information électrique et chimique, la neurotransmission partie chimique, la balance excito-inhibitrice, « on ne peut pas être très fin », l'étiopathologie (p. 2-3) |
| `ntr-fa-synthese-liberation` | la synthèse du schéma : transporteurs d'acides aminés, vésicules, transport axonal, calcium, réserpine, MAO-B et COMT (p. 5) |
| `ntr-qr-striatum-d2-d3` | **la consigne en rouge** : les récepteurs D2 et D3 dans le striatum, important dans la maladie de Parkinson (p. 5) |
| `ntr-rv-automatismes` | les boucles cortex → noyaux gris centraux → cortex, les automatismes, Parkinson maladie de l'automatisme (p. 3) |
| `ntr-qc-parkinson` | L-DOPA et barrière, IMAO-B, ICOMT, agoniste D2, anticholinergiques sur M1, les médicaments de 2026 (p. 5-7) |
| `ntr-qc-addiction` | voie finale commune, épuisement des réserves, addiction secondaire, cocaïne et cœur (p. 6) |
| `ntr-qc-agressivite` | les deux expériences (souris, déficit en MAO-A), le 5-HIAA, les TOC à forte dose, le LSD (p. 8) |
| `ntr-qc-antidepresseurs` | recapture (vortioxétine), MAO-A, agonistes 5-HT, sérotonine intestinale et nausées (p. 7-9) |
| `ntr-qc-recepteurs-ach` | holocrânien, muscarinique couplé à une protéine G, nicotinique canal, cognition, xanoméline (p. 9-10) |
| `ntr-qc-demences` | l'acétylcholine diminuée dans toutes les démences, la figure DMP, MCL, MA, l'anticholinestérasique non curatif (p. 11) |
| `lex-dopaminergique`, `lex-holocranien` | deux termes du lexique (voir plus bas) |

## Ce que le cours a dicté

- **Le rouge** : « Retenir uniquement les localisations des récepteurs D2 et D3 :
  le striatum → Important dans la maladie de Parkinson » (p. 5) :
  `ntr-qr-striatum-d2-d3`, `ntr-qc-recepteurs-da` C, `lex-striatum`.
- **« À ABSOLUMENT retenir »** (p. 5) : agoniste D2 → maladie de Parkinson ;
  antagoniste D2 → psychose et schizophrénie (`ntr-rv-parkinson-schizophrenie`,
  `ntr-qc-agonistes`, `ntr-qc-parkinson` D). **« À connaître »** (p. 6) : agoniste
  D1/D2 antiparkinsonien, agoniste D3 antidépresseur, antagonistes D1/D2 et D4
  antipsychotiques (`ntr-qc-animal`, marche `s21`).
- **« /!\ Ce médicament ne constitue pas un traitement curatif » (p. 11)** :
  `ntr-fa-alzheimer` c5, `ntr-qc-demences` C.
- **« Pas à connaître »** : les noms des noyaux (p. 3 ; voir plus haut, tag `edn`
  sur la carte de zone) ; la diapositive de la migraine « au-delà des triptans »
  (p. 8) et celle des nouvelles cibles des antidépresseurs (p. 9) : aucune carte ne
  les demande, elles sont seulement nommées dans une explication.
- **Le gris** : « mécanisme à ne pas retenir, uniquement connaître les premières
  étapes clés » de la synthèse de la dopamine (p. 4) — aucune carte sur ses
  métabolites ; et deux questions de rédacteurs (p. 3, 6), cartées comme le reste
  (décision de Vincent du 25/09). Le ronéo ne définit pas son gris comme hors
  programme.
- **Le vert « en 2026 »** des diapositives (nouveaux médicaments : foslévodopa,
  L-DOPA LP, opicapone, safinamide, tavapadon, vortioxétine, eskétamine,
  xanoméline) : cité dans les explications et dans deux propositions
  (`ntr-qc-parkinson` C, `ntr-qc-recepteurs-ach` E), sans en faire un savoir
  central.
- **Ce qui n'est pas carté ici**, parce qu'un autre chapitre le tient (plan
  C14) : l'aire tegmentale ventrale et le noyau accumbens, le récepteur D3 de
  l'euphorie, le GABA-A et les benzodiazépines, le circuit de la récompense
  (`bmct_pharmacodynamie`) ; la synthèse des catécholamines jusqu'à la
  noradrénaline, la synapse cholinergique périphérique, les récepteurs N et M du
  système nerveux végétatif, les anticholinestérasiques périphériques, la
  scopolamine (`bmct_snv`).

## Ce que les annales ont dicté

| Savoir | Questions |
|---|---|
| Augmenter ou inhiber la neurotransmission : précurseur, recapture, dégradation, récepteurs pré et post-synaptiques, canaux sodiques et calciques | 2021/2022 S1 Q.3, 2021/2022 S2 Q. 3, 2020/2021 S1 Q. 4, 2019/2020 S2 Q.1, 2018/2019 S1 Q. 1, 2016/2017 S1 Q1, 2016/2017 S2 Q1 |
| Ce qui rend la neurotransmission complexe | 2021/2022 S1 Q.2, 2019/2020 S1 Q. 4 et 2017/2018 S2 Q2 (mot pour mot) |
| Neurotransmetteurs : abondance, effet activateur, corps cellulaires dans le tronc, déficit compensable, mésolimbique et addiction, recapture contre MAO, nombre de récepteurs D | 2023/2024 S1 Q1 et Q2, 2022/2023 S1 Q. 2 (= 2023/2024 Q1), 2020/2021 S2 Q3 |
| Dopamine : tyrosine hydroxylase, dopa décarboxylase, clozapine, antagonisme D1-D2 | 2022/2023 S2 Q2 |
| Activer l'acétylcholine (AVC, maladie d'Alzheimer) | 2015/2016 S1 Q4, 2015/2016 S2 Q4 |
| Le rôle de chaque neurotransmetteur : noradrénaline et vigilance, sérotonine et impulsivité ou anxiété, GABA qui freine, voie mésocorticale et cognition | 2024/2025 S1 Q2 |
| Meynert, CAT et acétylcholinestérase, déficit cholinergique des démences, tryptophane, sérotonine antidépressive | 2024/2025 S1 Q3 |

**Deux en-têtes du polycopié sont faux**, et la table de corrections les
rétablit : la deuxième « Année 2019/2020 (Session 1) » (Q.1, inhibition) est la
session 2 ; la première « Année 2016/2017 (Session 2) » (Q1, activation) est la
session 1. Les cartes portent la session vraie (`ntr-an-1920s2-q1`,
`ntr-an-1617s1-q1`), et leur explication le dit.

**Les canaux sodiques voltage-dépendants** (six questions) ne sont dans aucun
cours ; le ronéo 2024-25 (p. 2) dit seulement que bloquer la transmission le long
de l'axone arrête tout. **Les canaux calciques** le sont désormais : la libération
s'accompagne d'une augmentation du calcium, qui peut la moduler (p. 5). Les
justifications s'appuient sur la physiologie — le sodium propage le potentiel
d'action, le calcium déclenche l'exocytose. Les clés imprimées sont cohérentes
entre elles.

## Les clés qui ne sont pas reprises telles quelles

Les 17 clés imprimées sont justes et reprises telles quelles, sans conflit
(`CONFLITS = []`) ; relues contre le ronéo 2026-27, aucune n'est contredite.
L'errata des annales BMCT ne porte pas sur ce polycopié. Les deux questions du
sujet 2024/2025 n'ont pas de corrigé :

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2024/2025 S1 Q2 (`ntr-an-2425s1-q2`) | aucune (sujet sans corrigé) | **ABD**, `officielle=False` | noradrénaline, vigilance ; sérotonine et impulsivité ; GABA frein, le glutamate accélérateur de la mémoire ; voie mésocorticale intellectuelle (p. 2, 4, 8) ; la sérotonine détend (FC 2025-26, p. 2) |
| 2024/2025 S1 Q3 (`ntr-an-2425s1-q3`) | aucune (sujet sans corrigé) | **ACD**, `officielle=False` | Meynert source d'acétylcholine (p. 3, 9) ; la CAT synthétise, l'acétylcholinestérase dégrade (p. 10) ; l'acétylcholine diminuée dans toutes les démences (p. 11) ; tryptophane essentiel (p. 7) et antidépresseurs sérotoninergiques (p. 9) |

## Les erreurs du ronéo 2026-27

Le tableau d'erreurs BMCT de la promo ne relève rien sur ce cours au 19/10/2026 :
toutes les erreurs ci-dessous ont été trouvées en relisant, et vont dans
`contenu/ERRATA_RONEOS_2026-27.md`. Aucun ronéo n'est corrigé ; chaque erreur est
portée par une carte, avec son genre. À l'examen, on répond d'abord comme le
professeur.

**Prises de notes fausses** (`ATTENTION (prise de notes)`) :

| Page | Le ronéo dit | Ce qui est juste | Carte |
|---|---|---|---|
| 3 | le striatum : une « queue », le noyau caudé, et une « patate », « le globus pallidus externe et interne » | striatum = noyau caudé + putamen ; le globus pallidus, accolé au putamen dans le noyau lenticulaire, n'en fait pas partie (diapositive du même ronéo, p. 10 : « Interneurones striataux (caudate, putamen, N accumbens…) » ; ronéo 2023-24, p. 5 ; StatPearls, « Neuroanatomy, Putamen ») | `ntr-fa-voies` |
| 5 | l'anti-D2 rend parkinsonien parce qu'« en cherchant à pallier l'antagonisme de D2 causant la psychose, on peut hyperactiver les récepteurs D2 et trop augmenter la transmission dopaminergique » | c'est le blocage du D2 du striatum, une transmission dopaminergique trop basse, qui donne le syndrome parkinsonien (FC 2025-26, p. 5, même professeur : « si on bloque trop fort le D2 … il devient parkinsonien » ; ronéo 2024-25, p. 8 : « Blocage D2 : effets moteurs extra-pyramidaux (nigro-strié) » ; StatPearls, « Extrapyramidal Side Effects ») | `ntr-qc-agonistes` (C), `ntr-rv-parkinson-schizophrenie` |
| 2 | le GABA et le glutamate représentent « près de 80 % de la composition du neurone » | 30 à 40 % des neurones chacun, soit 60 à 80 % des neurones (même page ; FC 2025-26, figure p. 2) | `ntr-fa-proportions` |
| 8 | la mutation de la MAO-A cause « une faible excrétion de 5-HIAA », puis « l'accumulation de 5-HIAA est à l'origine de retard mental, d'irritabilité et d'agressivité » | sans MAO-A, la sérotonine s'accumule et le 5-HIAA baisse ; la conclusion du ronéo lui-même est « l'excès de sérotonine rend agressif », et la diapositive du même cours, reprise par le ronéo 2024-25 (p. 9), dit « faible excrétion 5-HIAA » (Brunner et al., Science 1993 ; OMIM 300615) | `ntr-qc-agressivite` (D) |
| 9 | « il n'existe pas encore d'agonistes de récepteurs sérotoninergiques découverts » | les diapositives du même cours en citent quatre : triptans (5-HT1B/1D) et lasmiditan (5-HT1F) p. 8, vortioxétine (5-HT1A) et psilocybine (5-HT2A) p. 9 — trois sont sur le marché européen (Imigrane, BDPM ; Rayvow, EMA 2022 ; la vortioxétine, « AMM UE ») ; en 2024-25, le cours disait le 5-HT1D « stimulé » par le sumatriptan (ronéo 2024-25, p. 8) | `ntr-qc-antidepresseurs` (C) |

**C'est le cours lui-même** (`ATTENTION (cours)` : « À l'examen : … », puis « La
référence : … ») :

| Page | Le cours dit | La référence | Carte |
|---|---|---|---|
| 3 | les noyaux, Meynert compris, « en haut du tronc cérébral » ; « toutes les sources se trouvent au niveau du tronc cérébral » (quatre années de suite : ronéos 2023-24, 2024-25, FC 2025-26 ; le ronéo 2024-25 place pourtant Meynert « dans le diencéphale », p. 10) | le noyau basal de Meynert est dans le prosencéphale basal, sous la commissure antérieure, comme le dessinent les figures des p. 3 et 10 (Liu et al., Acta Neuropathol 2015) ; à l'examen, les corps cellulaires dans le tronc | `ntr-fa-noyaux`, `ntr-ech-s5`, `ntr-ech-s12`, `ntr-ech-m2` |
| 10 | l'acétylcholinestérase sépare « l'acétate et la choline pour qu'ils soient réabsorbés dans le neurone présynaptique » ; la diapositive ramène « choline + acétate » par un transporteur (FC 2025-26, p. 7 : « qui seront réabsorbées ») | seule la choline est recaptée, par le transporteur de haute affinité de la choline ; l'acétyl-CoA vient du métabolisme du neurone (Purves, Neuroscience, « Acetylcholine » ; figure de la synapse cholinergique du ronéo 2026-27 du système nerveux végétatif, p. 10 : la choline seule revient par un transporteur, l'acétate reste dans la fente) | `ntr-rv-fin-action`, `ntr-qc-alzheimer` (E) |

**Points douteux** (`ATTENTION (douteux)`), dits dans la carte sans changer sa clé :

| Page | Le point | Carte |
|---|---|---|
| 5 | le TDAH, où « le flux tonique inhibiteur n'est pas assez fort, donc le flux permanent est trop haut » : la phrase se contredit (le flux permanent est le tonique), et la référence trouve une libération tonique diminuée, phasique augmentée (Badgaiyan et al., PLoS One 2015) ; la carte retient le tonus inhibiteur trop faible, comme la FC 2025-26 | `ntr-fa-catabolisme-da` |
| 6 | la cocaïne « bloque la vésiculation de la dopamine », détruit les neurones dopaminergiques, et « à terme un cocaïnomane deviendra parkinsonien » (le cours le disait déjà en 2024-25 : « la cocaïne bloque les vésicules », ronéo 2024-25, p. 7) : elle bloque la recapture, et son effet sur les vésicules reste discuté ; une étude post mortem trouve moins de VMAT2 chez les usagers chroniques (Little et al., Am J Psychiatry 2003), mais une grande cohorte ne trouve pas plus de maladie de Parkinson chez eux, à la différence des usagers de méthamphétamine (Callaghan et al., Drug Alcohol Depend 2012) | `ntr-qc-addiction` |
| 7-8 | « 4 principales familles » de récepteurs sérotoninergiques (on en compte sept, IUPHAR ; quatre groupes seulement si on les range par couplage : Gi, Gq, canal, Gs) ; la kétansérine, la ritansérine et la clozapine, bloquant le 5-HT2A, « permettant ainsi un traitement antipsychotique » : seule la clozapine est antipsychotique, la kétansérine est un antihypertenseur, la ritansérine n'a jamais été commercialisée | `ntr-qc-serotonine` |
| 8 | « le LSD entraîne une décharge de sérotonine très importante » : le LSD est un agoniste partiel des récepteurs 5-HT2A, pas un libérateur de sérotonine (De Gregorio et al., Int J Mol Sci 2016) | `ntr-qc-agressivite` |
| 10 | le récepteur nicotinique « lié au système nerveux autonome (ex : digestion) » : il est celui des ganglions des deux systèmes, de la jonction neuromusculaire et du cerveau ; les effets digestifs de l'acétylcholine passent par les récepteurs muscariniques M3 (IUPHAR/BPS Guide to Pharmacology) | `ntr-qc-recepteurs-ach` (C) |

Sans carte ni ATTENTION, parce qu'aucune réponse n'en dépend : « éthiopathologie »
pour étiopathologie (p. 2, dit dans `ntr-qc-balance` E) ; « MOA » pour MAO
(p. 4) ; des souris, puis « 2 rats mâles », dans la même expérience (p. 8) ; le
cerveau « plus grand consommateur d'énergie de l'univers » (p. 3), image du
professeur.

## Les erreurs du Ronéosaure 2025-26

Le Ronéosaure n'est pas le ronéo de l'année : ses erreurs sont dites par un
**ATTENTION nu**, sans genre, et n'entrent pas dans
`contenu/ERRATA_RONEOS_2026-27.md`. Le ronéo 2026-27 n'en redit aucune, sauf celle
du tronc cérébral, qui a pris le genre de l'année (« le cours lui-même »).
Restent, là où une proposition les touche encore :

| Page | Le Ronéosaure dit | Carte |
|---|---|---|
| 4 | « en post synaptique, on capture la tyrosine » (prise de notes, errata de la promo) | `ntr-qc-catabolisme-da` C |
| 5 | l'halopéridol, « un agoniste pour le parkinsonien » (prise de notes, errata de la promo) | `ntr-qc-agonistes` C |
| 5 | « Antagoniste de D1/D2 : antiparkinson » (prise de notes, errata de la promo) | `ntr-qc-animal` D |
| 5 | « Selegiline (recapture de la dopamine) » (prise de notes ; Tan et al., J Parkinsons Dis 2022) | `ntr-qc-role-dopamine` C |
| 6-7 | le traitement sérotoninergique qui aurait rendu suicidaire (point douteux : le rimonabant) ; « la sérotonine rend agressif » | `ntr-qc-serotonine-clinique` |

Dites sans ATTENTION : « D1/D2 et D3/4/5 » (`ntr-qc-recepteurs-da`), « l'ACE »,
« l'ACC » (`ntr-qc-alzheimer`), les vésicules « à pH = 1-2 »
(`ntr-fa-catabolisme-da`), le sumatriptan qui agit « sur la vasodilatation » —
le ronéo 2026-27 dit juste « il module la vasodilatation et l'inflammation ».

## Les schémas et les figures

**Onze figures du ronéo 2026-27**, rendues en PNG depuis son PDF, déclarées dans
`IMAGES` avec leur page : la synapse (p. 2), les noyaux et les voies
dopaminergiques (p. 3), la neurotransmission dopaminergique (p. 4), et six
nouvelles — la sélectivité des récepteurs DA (p. 6), le schéma de synthèse sur la
dopamine et ses médicaments de 2026 (p. 7), la sérotonine (p. 7), les cibles des
antidépresseurs (p. 9), le noyau de Meynert et la synapse cholinergique avec la
xanoméline (p. 10), les déficits cholinergiques des démences (p. 11). Non reprises :
la page de garde et les deux diapositives « pas à connaître » (la migraine, p. 8 ;
les nouveaux antidépresseurs, p. 9).

**Onze figures de la FC 2025-26** restent déclarées ; trois portent encore des
cartes, parce que l'année ne les reprend pas : les six neurotransmetteurs et leur
part des neurones (p. 2), les étapes de la transmission (p. 3), les récepteurs
dopaminergiques et l'adénylate cyclase (p. 4). Les huit autres (synapse, noyaux,
voies, synthèse, neurotransmission dopaminergique, sérotonine, Meynert, synapse
cholinergique) ont leur pendant 2026-27, que les cartes citent désormais.

**Un schéma cliquable** (`schemas.py`), avec sa version légendée en correction :

| Fichier | Ce qu'on clique | Pourquoi ce dessin |
|---|---|---|
| `noyaux.svg` | le noyau de Meynert, le striatum, l'aire tegmentale ventrale, la substance noire, le locus cœruleus, les noyaux du raphé (6 zones) | la coupe sagittale de la p. 3 et celle de Meynert (p. 10), redessinées ; les questions nomment la fonction, pas le noyau. Tag `edn` : les noms sont « à titre informatif » cette année |

**Une planche à légender**, `ntr-pl-synapse` (`synapse.svg`, dessinée dans
`schemas.py`) : une synapse générique, neuf numéros, quatre intrus ; sa correction
dit sous chaque légende ce qu'une action sur la cible fait à la neurotransmission.
Ses notes citent désormais le ronéo 2026-27 (le calcium, p. 5 ; la réserpine,
p. 5).

**69 QCM sur 69 illustrés (100 %)**, 94 notes sur 107.

## Le lexique

Dix termes ; pages mesurées dans le texte du ronéo 2026-27 (`chercher_pages.py`),
puis dans la FC 2025-26 :

| Terme | Origine | Pages 2026-27 |
|---|---|---|
| Neurotransmetteur | grec neûron + latin transmittere | 1, 2, 3 |
| Synapse | grec súnapsis | 1, 2, 8, 10, 11 |
| Striatum | latin striatum (corpus) | 3, 5 |
| Mésolimbique | grec mésos + latin limbus | 3, 4, 6 |
| Antipsychotique | grec antí + psukhḗ | 6, 8 |
| Sérotonine | latin serum + grec tónos | 1, 2, 3, 7, 8, 9 |
| Locus cœruleus | latin locus caeruleus | 3 |
| Neuropsychotrope | grec neûron + psukhḗ + trópos | 1, 2 |
| **Dopaminergique** (nouveau) | dopamine + -ergique, du grec érgon | 1, 3, 5, 6, 11 |
| **Holocrânien** (nouveau) | grec hólos + kraníon | 9 |

Les deux termes nouveaux et la racine `holos (grec)` sont proposés à la table
commune (brouillon `etym/bmct_neurotransmission.json`) ; `ergon (grec)` et
`kranion (grec)` reprennent des clés existantes. « Dopaminergique » est rangé
« français », comme l'ergostérol : dopamine n'a pas d'étymon grec ou latin. Les
textes du lexique sont déjà écrits dans la forme que `appliquer_etymologies.py`
produirait. Aucun des deux n'existait dans un autre paquet ; « dopaminergique »
revient sept fois dans les énoncés et propositions des annales BMCT.

## Absent du cours 2026-27

**Aucune carte entière** (`ABSENTS_2026 = []`) : chaque carte garde sa notion
centrale dans le ronéo de l'année et cite sa page. Ce qui ne vient plus que de la
FC 2025-26 est dit dans la proposition ou l'explication qui le porte :

| Carte | Ce que seul le cours 2025-26 portait |
|---|---|
| `ntr-fa-moduler`, `ntr-qc-synapse` C-E | l'amont et l'aval |
| `ntr-fa-proportions` c4-c6, plusieurs annales | la part des neurones de l'acétylcholine, de la sérotonine, de la dopamine, de la noradrénaline |
| `ntr-fa-noyaux`, `ntr-qc-noyaux` C-D | les maladies de chaque noyau (sans lui, Alzheimer, Parkinson, troubles de l'attention et du sommeil, dépression) |
| `ntr-qc-voies` B, E | le tri des informations ; la schizophrénie à 1 %, l'addiction à 10-15 % |
| `ntr-qc-recepteurs-da` D-E, `ntr-rv-familles-d` | le D3 des addictions comportementales de 2003 ; l'adénylate cyclase |
| `ntr-qc-agonistes` B-E, `ntr-qr-clozapine` | l'halopéridol, la clozapine « fine », le bipolaire |
| `ntr-qc-animal` E | la schizophrénie neurodéveloppementale et génétique |
| `ntr-qc-cocaine` A, C, E, `ntr-qr-dat` | le DAT nommé, la dose et la prise explosive |
| `ntr-qc-serotonine` E, `ntr-qr-5ht3` | le 5-HT3 canal |
| `ntr-qc-serotonine-clinique` B, E | les IRS anxiolytiques ; la prise de poids |
| `ntr-qc-meynert` B-C | les étudiants canadiens, la scopolamine |

## Décisions prises en route

- **Une carte n'est confirmée que si sa notion centrale est dans le cours de
  l'année** ; ses propositions de 2025-26 le disent une à une. Aucune n'a perdu sa
  notion centrale : aucune n'est absente.
- **Les trous changés** : `ntr-fa-roles` c5 (« plaisir »), `ntr-fa-etapes` c2
  (« vésiculation »), `ntr-fa-alzheimer` c4 et c5 (« vomissements »,
  « curatif »), `ntr-fa-meynert` c5 (« holocrânien »). Les textes de `ntr-fa-voies`
  et `ntr-fa-catabolisme-da` changent autour de trous inchangés.
- **Les noms des noyaux** « pas à connaître » : la carte de zone prend le tag
  `edn` ; les cloze et QCM qui les demandent le disent, sans tag, parce que le
  noyau de Meynert reste au programme et que les annales les emploient.
- **Les figures** : celles de 2026-27 dans les cartes qui citent l'année ; celles
  de 2025-26 seulement pour ce que l'année ne reprend pas.
- **Le schéma de l'échelle** suit l'année : légende (ronéo 2026-27, p. 2-11), titres
  (synapse cholinergique p. 10, moduler une synapse p. 4-6), ligne « Dopamine »
  (« plaisir, motivation, récompense ») et la marche `s6` avec elle.
- **`EXAMENS` n'est pas déclaré** (décision de FC1) : le partiel du 4/11 se règle
  dans l'application.
- **Chaque session a sa carte**, même quand la question revient.

## À relire

**Aucune carte `a-relire`** : toutes les notes citent une page du ronéo 2026-27,
ou une source sûre pour les canaux sodiques. Reste à Vincent : `copier_les_cours.py`
avec le dossier des ronéos du 19/10, hors du bac à sable, pour que la fiche
`BMCT/NEUROTRANSMISSION.pdf` s'ouvre dans l'application.

## L'échelle : Simple → Moyen → Annale (C20, 16/10/2026)

L'échelle du pilote de l'immunité innée, étendue à la BMCT pour l'examen du 4/11 (Vincent, 16/10 : « on continue pour les chapitres que je vais avoir à l'examen »). Sous les annales, 24 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 4 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`) ; les QROC reçoivent le schéma nu.

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `neurotransmetteurs` | 12 | 1 | 8 |
| `modulation-synaptique` | 5 | 1 | 7 |
| `dopamine` | 3 | 1 | 1 |
| `serotonine` | 2 | 0 | 0 |
| `acetylcholine-centrale` | 2 | 1 | 3 |

**Le schéma** `ech-neurotransmission`, « La neurotransmission · qui la fait, comment la moduler », donne 48 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_NEUROTRANSMISSION`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Relues sur le ronéo 2026-27 (19/10/2026).** Chaque marche cite sa page de
l'année ; les clés ne changent pas (Simple : A × 7, B × 9, C × 8 ; Moyen : une à
trois vraies). Changent : la ligne « Dopamine » du schéma et l'option A de `s6`
(« plaisir, motivation, récompense », le tableau de la p. 6) ; l'option C de `m7`
(« vertiges » au lieu de la diarrhée, p. 11) ; les ATTENTION de `s5`, `s12` et `m2`
prennent le genre « cours » (le tronc cérébral) ; ceux de `s19`, `s21`, `s23` et
`m7`, qui disaient des erreurs du Ronéosaure que l'année ne redit pas, sont
retirés.

**Sans marche** :
- 2122s2-q3, 1920s2-q1, 1617s1-q1, 1617s2-q1 C, D ; 1516s1-q4, 1516s2-q4 E : canaux voltage-dépendants (le calcium est désormais dans le cours, p. 5, et dans `ntr-fa-synthese-liberation`). 1819s1-q1 A : cours évolutif (« pas curatif », p. 11). 2122s1-q2, 1920s1-q4, 1718s2-q2 A, B, C, E : multiplicité, boucles, latences ; leur D ou E (spécificité) est préparé par s20.
- 2122s1-q3 D, 1516s1-q4 B, 1516s2-q4 A : agonisme post-synaptique, qui trahirait l'antagonisme en Simple ; m6 D le porte.
- Lignes du schéma sans Simple : projections, tyrosine hydroxylase, dopa décarboxylase, MAO-COMT, recapture de l'acétylcholine, libération empêchée (m2, m4, m6, m7 en portent une part).

## Relecture sceptique (19/10/2026)

Le réalignement a été relu contre chaque page du ronéo 2026-27 et ses figures,
contre la FC 2025-26 et, cette fois, contre les ronéos 2023-24 et 2024-25 du même
cours. Aucun identifiant, aucun type, aucune clé ne change ; aucune note n'est
retirée. Corrigé :

- **Une référence fausse** : « le ronéo 2026-27 du système nerveux végétatif, p. 12 »
  ne parle pas de la choline. C'est la **figure de la p. 10** de ce ronéo qui ne
  ramène que la choline par un transporteur, l'acétate restant dans la fente (et
  son texte dit même l'acétylcholine « recapturée »). `ntr-rv-fin-action`,
  `ntr-qc-alzheimer` E et le tableau des erreurs citent désormais la figure.
- **« Trois ans de suite »** pour l'acétate réabsorbé : deux seulement (FC 2025-26,
  ronéo 2026-27) ; les ronéos 2023-24 et 2024-25 n'en parlent pas.
- **Des preuves de plus pour trois prises de notes** : le ronéo 2024-25 reprend la
  diapositive « Blocage D2 : effets moteurs extra-pyramidaux (nigro-strié) » (p. 8),
  celle du déficit en MAO-A « avec faible excrétion 5-HIAA » (p. 9), et dit le
  5-HT1D « stimulé » par le sumatriptan (p. 8).
- **Les agonistes sérotoninergiques sur le marché** : trois, pas deux (la
  vortioxétine porte « AMM UE » sur la diapositive de la p. 9).
- **La cocaïne et les vésicules** : le cours le disait déjà en 2024-25 (p. 7) ; le
  point reste douteux, et la carte le dit.
- **« 4 principales familles »** : le point douteux dit aussi qu'on range les sept
  familles en quatre groupes par leur couplage, ce que le professeur visait
  peut-être.
- **Le noyau de Meynert, « la source de l'acétylcholine de tout le cerveau »**
  (formule de la FC 2025-26) : la figure de la p. 10 en dessine d'autres (noyau
  septal médial, noyau pédonculopontin, interneurones du striatum) ; la marche
  `s5`, `ntr-qc-noyaux` A et la note de la zone disent « la principale source ».

## Régénérer

```powershell
..\..\..\app\.venv\Scripts\python.exe generer.py
```

## Questions pour Vincent

1. **Le squelette numérote à la 2024-25** (plan C14, 0.10) :
   `contenu/squelettes/roneosaure` déclare `chap-ue-bmct-fc8` sous le nom
   « Pharmacodynamie du Système Immunitaire ». Ce paquet le renomme
   « Pharmacodynamie de la neurotransmission » à l'import ; faut-il aligner le
   squelette sur la numérotation 2025-26 ?
2. **(19/10) Les noms des noyaux « pas à connaître »** : seule la carte de zone
   prend le tag `edn` ; `ntr-fa-noyaux`, `ntr-qc-noyaux` et trois marches les
   demandent encore, parce que les annales les emploient (Meynert surtout). Les
   marquer aussi `edn` ?
3. **(19/10) L'acétate « réabsorbé »** : le cours le dit deux années de suite
   (FC 2025-26, p. 7 ; ronéo 2026-27, p. 10 ; les ronéos 2023-24 et 2024-25 n'en
   parlent pas), sa diapositive le dessine ; la référence, et la figure du cours
   du système nerveux végétatif (p. 10), ne recaptent que la choline. Les cartes
   répondent comme le cours (`ATTENTION (cours)`). D'accord ?
4. **(19/10) Les diapositives « nouveaux médicaments (2026) »** (vert) : citées en
   explication et dans deux propositions seulement. Faut-il en faire des cartes à
   part entière (tavapadon, opicapone, safinamide, xanoméline, eskétamine) ?
5. **(19/10, relecture) Le gris « mécanisme à ne pas retenir »** de la synthèse de
   la dopamine (p. 4) : `ntr-fa-synthese-liberation` carte la « synthèse du
   schéma » de la p. 5, qui est dans la même partie (transporteurs d'acides aminés,
   calcium, réserpine). Elle reste sans tag, parce que ses étapes sont celles de la
   transmission (p. 4) et que le calcium sert aux annales. Faut-il la marquer `edn` ?
