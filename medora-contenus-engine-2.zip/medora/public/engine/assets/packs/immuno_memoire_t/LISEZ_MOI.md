# Contraction clonale et réponse T mémoire — paquet Immunologie

77 notes, 135 cartes. Chapitre `chap-ue-immunologie-fc9` de l'UE Immunologie.
Cours du **Pr Dubucquoi, le 14/10/2026** (11 h-12 h, semaine 6), « Contraction
clonale et réponse T mémoire » : **le ronéo Ronéo & Juliette 2026-27 (16 pages)
est la base du chapitre depuis le 19/10/2026**. Le Ronéosaure 2025-26 (FC n°9,
même professeur, 17/10/2025), sur lequel le chapitre était carté depuis le
02/10, n'est plus qu'un appoint. Annales du polycopié IMMUNO n°9 du Ronéosaure
2024-25 (4 questions, 4 sessions). Examen du 4 novembre 2026.

Chaque carte relue sur le ronéo de l'année porte sa page (`page=`) et cite
`src-fc-immuno-memoire-t-2627` : 72 notes sur 77, sans le badge « Cours
2025-26 ». Les 4 annales citent, en source secondaire, la page du ronéo où se
lit leur réponse. Une seule carte est « Absent du cours 2026-27 ».

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 26 | 26 |
| QRU | 13 | 13 |
| Texte à trous | 14 | 69 |
| QROC | 9 | 9 |
| Recto-verso | 7 | 7 |
| Schéma cliquable | 1 | 4 |
| Planche à légender | 1 | 1 |
| Lexique | 6 | 6 |

Dont **4 annales** (QRM), sur 4 sessions : 2018/2019 S1, 2018/2019 S2,
2020/2021 S1, 2021/2022 S1 ; et **15 marches de l'échelle** (12 Simple en QRU,
3 Moyen en QRM). Les 20 QCM du cours ont une justification par proposition,
comme les annales.

Six thèmes, dans l'ordre du cours, tous déjà dans `THEME_LABELS` :

| Clé | Libellé |
|---|---|
| `etapes-reponse` | Expansion, contraction et mémoire (celui d'`immuno_temporelle`, même libellé) |
| `contraction-clonale` | La contraction clonale |
| `origine-memoire` | Origine de la mémoire T |
| `types-memoire` | Les trois types de LT mémoire |
| `entretien-memoire` | Durée de vie et entretien de la mémoire |
| `memoire-vaccination` | Mémoire immunitaire et vaccination |

Le générateur ajoute `piege-roneo` aux sept cartes qui portent une erreur du
ronéo, et `absent-2026` à la carte absente.

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-immuno-memoire-t-2627` — Ronéo & Juliette, « Contraction clonale et réponse T mémoire » (16 p.), `IMMUNOLOGIE/CONTRACTION CLONALE ET RÉPONSE T MÉMOIRE.pdf` | **2026-27** | **la base** (`SRC["fiche"]`, `chapitre=`) : ce que le lecteur ouvre ; onze de ses figures illustrent les corrections |
| `src-fc-immuno-memoire-t` — Ronéosaure, « FC n°9 Contraction clonale et réponse T mémoire » (10 p.) | 2025-26 | appoint, cité « FC 2025-26, p. 6 » ; `SRC["cours"]`, la source de la carte absente ; n'a plus `chapitre=` |
| `src-annales-immuno-reponse-t` — Ronéosaure, « IMMUNO n°9 - Réponse adaptative T et mémoire » (9 p.) | 2024-25 | les 4 questions et leur table de corrections (p. 7-9) ; déclaration **copiée à l'identique** de celle d'`immuno_thymus` |
| cours 2024-25 du Pr Labalette, « FC n°9 - La régulation de la réponse T » (Ronéosaure 2024-25) | 2024-25 | appoint **cité dans le texte des cartes sans être déclaré** : seuil du TCR, costimulation, préprogrammation (p. 13), résidents (p. 14), entretien (p. 16-17) |
| FC n°1 2026-27 (« Organisation temporelle »), ronéos 2026-27 « TCR et lymphopoïèse T » et « Réponse immunitaire T », FC n°6 et n°8 2025-26 | — | citées dans le texte, à la page, sans être déclarées : ce sont les fiches d'autres chapitres |
| tableau des erreurs d'immunologie de la promo (dépôt du 19/10) ; erratas du Ronéosaure | — | **aucune entrée** sur ce cours ni sur ces quatre questions |

Vérifications hors du cours, citées dans la carte qui s'en sert : Macallan et
al., J Exp Med 2004 (renouvellement des LT CD4 chez l'humain : environ 48 jours
pour les centraux, 15 pour les effecteurs mémoire, un an pour les naïfs) ; Cui
et Kaech, Immunol Rev 2010 (5 à 10 % des effecteurs survivent à la
contraction) ; Park et al., Nat Immunol 2018 (les LT mémoire résidents
prolifèrent sur place) ; British Society for Immunology, « CD4 T cells »
(cytokines TH1, TH2, TH17) ; les cellules qui produisent l'IL-7 (stromales et
épithéliales, PMC2797310) et l'IL-15 (présentée par les monocytes et les cellules
dendritiques, PMC2808451, PMC2597127) ; l'étymologie (TLFi, Gaffiot, Bailly,
Wiktionnaire).

## Ce qui correspond à quoi

| FC n°9 2025-26 | Ronéo 2026-27 |
|---|---|
| Rappel de l'activation, p. 2-3 | p. 2-3 (pas de carte ici) |
| Chronologie, p. 3-4 | p. 3 (diapositive de la chronologie) |
| Avantage de l'immunité adaptative dans la vaccination, p. 4 | p. 3-4 (diapositive de l'amplitude) |
| Avantages et inconvénients de l'expansion clonale, p. 4-5 | p. 4-5 (diapositive de la balance, nouvelle dans le ronéo) |
| Fonctionnement de la contraction clonale, p. 5-6 | p. 5 (diapositive « comment ? », nouvelle dans le ronéo) |
| Origine de la mémoire, répertoire, résumé, p. 6-7 | p. 6-7 (diapositives de la population hétérogène et du répertoire) |
| Premier concept : îles Féroé, p. 7 | p. 8 (diapositive des îles Féroé, nouvelle dans le ronéo) |
| Fonctionnement, réponse secondaire, p. 8 | p. 9 (deux diapositives) |
| Les trois grands types, p. 8 | p. 10-11 (diapositive « A retenir ») |
| Localisation, p. 9 | p. 12-13 (diapositive « A retenir ») |
| Durée de vie, entretien, conclusion, p. 9-10 | p. 13-14 |
| — | objectifs, p. 7 et 15 |

## Le réalignement du 19/10/2026 : ce qui a changé

Toutes les notes ont été relues contre le ronéo 2026-27, ses figures d'abord
(dans un ronéo, l'image fait foi sur le texte). 72 citent sa page ; 27 ont été
réécrites, parce que le ronéo 2026-27 dit autrement ou ne dit plus :

- **La liste « Plus réactifs car » est à retenir.** Sur la diapositive de la
  réponse secondaire, elle portait « Ne pas retenir ! » en 2025-26 ; elle porte
  « Retenir ! » en 2026-27 (p. 9). Le tag `edn` quitte les marches
  `mem-ech-s1`, `-s2`, `-s3` ; la case du schéma de l'échelle s'appelle
  « Plus réactifs, car : » ; l'annale 2021/2022 S1 Q4 n'a plus à s'en excuser ;
  deux notes nouvelles la cartent (`mem-qc-plus-reactifs`,
  `mem-fa-plus-reactifs`).
- **Le frein des LT activés** s'impose « même si persistance antigénique ! »
  (diapositive p. 5), quand la FC 2025-26 faisait l'emporter l'activation si
  l'agent persiste vraiment (p. 6) ; il garantit qu'on
  n'agresse pas l'organe infecté ; les infections chroniques du cours sont le
  paludisme et le sida. `mem-qc-frein` et `mem-rv-frein` sont réécrites ;
  l'hépatite fulminante et les cancers ne sont plus dans le cours
  (`mem-qr-hepatite`, absente).
- **Les LT régulateurs** rappellent la tolérance « vis-à-vis de nos propres
  cellules » (p. 5, l'exemple de l'infarctus du myocarde), et non plus du
  microbiote ; « homéostasie » n'est plus dit (`mem-fa-treg`).
- **Les chiffres** : ×10 000 sur la diapositive (p. 4), « 10 000, 100 000x
  plus » dans le texte (p. 4) — le « 1 à 10 000 en 4 à 7 jours » de 2025-26
  n'est plus écrit ; 90 % éliminés et 10 % conservés (p. 6-7) ; « presque 10 %
  des cellules circulantes » a disparu (`mem-qc-repertoire` B réécrite).
- **Des durées nouvelles** : les effecteurs sont éliminés au bout d'environ
  15 jours (p. 6, 10) ; centraux 45 jours, effecteurs mémoire 15 (p. 13) ; la
  primo-réponse élimine l'agent en 14 à 21 jours (p. 9) ; la mémoire dure de
  plusieurs mois à des dizaines d'années (p. 9). Nouvelles notes `mem-fa-durees`
  et `mem-qr-elimination` (les 14 à 21 jours, relevés à la relecture du 19/10).
- **Les LT mémoire effecteurs** passent par « la rate, le poumon, l'intestin,
  ganglions lymphatiques, amygdales » (p. 12), plus par le cerveau : le
  bandeau du milieu du schéma cliquable a pris une rate à la place du cerveau.
- **Les centraux** : « hautes capacités de prolifération », le « kérosène »
  des cytokines non polarisées, la réactivation des cellules mémoire et naïves
  (p. 10, 13) ; la phrase rouge de 2025-26, « ne se transforment pas en
  effecteurs/tueurs », n'est plus écrite — la diapositive le montre encore
  (pas de « → effecteurs » pour eux, p. 10).
- **Nouveau et carté** : l'« état intermédiaire » des cellules mémoire entre
  naïves et effectrices (p. 7, `mem-qc-etat-intermediaire`) ; les cytokines par
  polarisation, demandées à l'examen (p. 11, `mem-qc-cytokines`,
  `mem-fa-cytokines`) ; ce qui entretient la mémoire, rappels vaccinaux et
  virus latents compris (p. 14, `mem-qc-entretien`) ; un vaccin « moins
  immunogène qu'une infection naturelle » (p. 9, `mem-qc-amplitude` D) ;
  l'immunité stérilisante et la réponse anamnestique, sur la diapositive des
  îles Féroé (p. 8).
- **Ce qui ne se dit plus** : le gris de 2025-26 sur des vaccinations en
  Chine ; « lorsqu'on force la machine » (remplacé par « chaque type va pouvoir
  donner un autre type », p. 11) ; la grippe et son pic à J2 (J2 est
  l'apparition des symptômes, p. 3) ; la cellule dendritique qui réexpose
  l'agent aux centraux.

## Ce que le cours a dicté

- **Ce qui appartient à un autre chapitre n'est pas carté** : le rappel de
  l'activation (p. 2-3 : cellule dendritique, synapse, CD28 et CD80 « à
  retenir », polarisation, l'exemple de la tuberculose) est à « La réponse
  immunitaire T ». CTLA-4, PD-1 et Treg y sont détaillés ; ce chapitre ne
  carte que leur place parmi les trois freins de la contraction.
- **Le gris de ce ronéo est la voix des rédacteurs** (il ne se définit pas
  lui-même) : il se carte. Il porte des consignes d'examen — « retenir ++ le
  carré rouge », différencier réponse primaire et secondaire pour les LB comme
  pour les LT (p. 9) ; « connaître au moins une ou deux cytokines par
  polarisation » (p. 11) ; « ne pas connaître les détails des mécanismes de
  génération » de la mémoire, sauf l'IL-7 et l'IL-15 (p. 6) — et l'annonce
  de l'examen : séance de questions le 30/10, QROC de deux mots au plus, sur
  tablette (p. 1).
- **Le rouge** : « dangereux ! », « processus de contrôle essentiels et
  nécessaires » (p. 5) ; la demi-vie courte des effecteurs, la durée de vie
  prolongée des précurseurs mémoire (p. 6) ; « contraction clonale
  nécessaire », « état intermédiaire » (p. 7) ; « les intérêts des cellules
  mémoires », rapide, intense, polarisée, diversifiée, efficace (p. 9) ;
  effecteurs qui CIRCULENT, résidents qui RÉSIDENT (p. 13) ; les cellules
  mémoire qui s'épuisent « au bout de 200 ans » (p. 14).
- **Les diapositives « A retenir »** : les types (p. 10) et leur localisation
  (p. 12). La première est la planche à légender ; la seconde a son schéma
  cliquable.
- **Le cours ne fixe pas les chiffres comme les autres** : ×10 000 et 90 % ici,
  environ 100 000 en une semaine et 95 % dans la FC n°1 2026-27. Chaque carte
  qui demande un chiffre le dit par ATTENTION : à l'examen de ce cours, ses
  chiffres.
- **Deux cours qui se contredisent sur la quantité de mémoire** : la
  diapositive de l'année dit que la pression antigénique « n'impacte pas la
  génération de la mémoire ! (pas plus !) » (p. 3), le cours 2024-25 en faisait
  dépendre la quantité (p. 14). Les cartes suivent le cours de l'année, par
  ATTENTION (`mem-qc-amplitude` B, `mem-rv-amplitude`).

## Ce que les annales ont dicté

| Savoir | Questions |
|---|---|
| Ce qui rend les LT mémoire plus réactifs (seuil, costimulation, préprogrammation), leur spécificité, leurs cytokines de survie | 2021/2022 S1 Q4 |
| Ce que le LT mémoire n'a pas (hypermutation, commutation), sa survie sans l'antigène, sa localisation | 2020/2021 S1 Q5 |
| La contraction (« environ 5 % » échappent), la localisation des centraux et des effecteurs, la durée de vie, l'IL-7 et l'IL-15 | 2018/2019 S1 Q5 |
| Les propriétés des trois types, la durée de vie, le CD25 qui n'est pas le leur | 2018/2019 S2 Q4 |

Les 19 autres questions d'IMMUNO n°9 sont dans le chapitre de leur sujet
(annales.py le détaille). Relues sur le ronéo 2026-27, les quatre clés tiennent :
la liste « plus réactifs », désormais à retenir, porte même les propositions
de 2021/2022 S1 Q4.

## Le schéma cliquable, la planche, les figures

| Fichier | Ce qu'on clique | Cartes |
|---|---|---|
| `lt-memoire-lieux-nu.svg` (`mem-zo-lieux`) | le circuit des centraux, la boucle des effecteurs, l'épithélium (résidents CD8), le chorion (résidents CD4) | 4 |

Redessiné d'après la diapositive « Où les trouve-t-on ? » (p. 12), en trois
bandeaux sans une légende : en haut un circuit fermé de sang et de lymphe qui
ne passe que par des ganglions et la rate ; au milieu une boucle de sang qui
relie **une rate**, des poumons, un intestin (le cerveau de 2025-26 a cédé la
place, le 19/10, aux organes que cite le ronéo de l'année) ; en bas la coupe
d'une muqueuse. Les deux rendus ont été relus.

**La planche** `mem-pl-types` : la diapositive « Quels types de (LT)
mémoire » (p. 10, « A retenir »), extraite du ronéo 2026-27 — la même que
celle de 2025-26 —, légendes effacées par `scripts/planche_depuis_image.py` :
sept numéros, quatre intrus. L'image numérotée a été refaite sur la figure de
l'année et relue.

**Les figures** : onze diapositives du ronéo 2026-27, toutes en correction —
chronologie et amplitude (p. 3), balance bénéfices/risques (p. 4), contraction
(p. 5), population hétérogène et répertoire (p. 6), îles Féroé (p. 8), réponse
secondaire et version vaccin (p. 9), types (p. 10), localisation (p. 12). Les
quatre figures de la FC 2025-26 qui ne servaient plus ont quitté `media/`.

**Illustrations** : 38 QCM sur 39 (97 %) portent une figure ou un schéma en
correction ; 65 notes sur 77. Seul `mem-qc-immunosenescence` n'en a pas : la
p. 14 n'a pas de figure.

## Les erreurs du ronéo 2026-27

Le tableau d'erreurs d'immunologie de la promo ne relève rien sur ce cours
(dépôt du 19/10). Trouvées en relisant : les trois premières sont prouvées par
la diapositive du ronéo lui-même et par le cours de 2025-26 du même professeur ;
les deux dernières restent des points douteux.

| Page | Ce que dit le ronéo | Ce qui est juste | Genre | Carte |
|---|---|---|---|---|
| 10 | Le « kérosène » des centraux : « les cytokines non polarisés de type IL 2, IL 7, IL 4 » | IL-2, IL-7, **IL-15** (« Cytokines non polarisées : IL-2/-7/-15 », diapositive p. 10) ; l'IL-4 est la cytokine TH2 (p. 11 ; p. 3) | prise de notes | `mem-qc-cytokines` A, `mem-fa-cytokines`, `mem-rv-centraux-effecteurs` |
| 7 | Après la contraction, « on dispose de 10 000, 100 000 cellules supplémentaires » | **10⁵ à 10⁶ cellules** (diapositive p. 6 ; 10 % de 10⁶ à 10⁷ ; FC 2025-26, p. 7) | prise de notes | `mem-qc-repertoire` B, `mem-fa-repertoire` |
| 7 | Le premier lymphocyte spécifique : « il a fallu 5 à 7 jours pour qu'il ait un effet » | **4 à 7 jours** (« 4 à 7 j », diapositive p. 9 ; FC 2025-26, p. 4) | prise de notes | `mem-qu-delai` C, `mem-qc-secondaire` A |
| 3 | Deux polarisations seulement : TH1 pour un pathogène intracellulaire, TH2 pour un extracellulaire | TH17 pour les bactéries extracellulaires et les champignons, TH2 pour les parasites (FC 2025-26, p. 3, même professeur ; ronéo 2026-27 « Réponse immunitaire T », p. 13 ; TH17 sur la diapositive p. 10) — simplification du cours ou raccourci de notes | douteux | `mem-qc-cytokines` E |
| 10 | Les centraux produisent le « kérosène » des LT, les cytokines non polarisées (« IL 2, IL 7, IL 4 ») : « ces cellules vont donc en produire » | La diapositive dit seulement « production cytokines ± polarisées » ; l'IL-7 vient des cellules stromales et épithéliales, l'IL-15 des monocytes et des cellules dendritiques, et les LT les consomment — le ronéo le dit p. 14 ; les centraux produisent surtout l'IL-2. Les cartes disent « peu polarisées, l'IL-2 en tête » | douteux | `mem-fa-cytokines`, `mem-rv-centraux-effecteurs` |

## Les erreurs du Ronéosaure 2025-26

Le ronéo 2026-27 ne les reprend pas, et les cartes ne les citent plus : « le
CD3 (Cellule Dendritique) » (p. 2 ; le ronéo 2026-27 dit juste « via le
complexe CD3 », p. 2), les résidents qui « réduisent » (p. 9 ; « résident »,
p. 12), « pneuma-virus » (p. 9 ; disparu). La FC 2025-26 disait aussi que les
signaux d'activation l'emportent sur le frein « seulement si » l'agent
persiste (p. 6), ce que la diapositive de l'année contredit (« même si
persistance antigénique ! ») : dit par un ATTENTION nu dans `mem-qc-frein` A.

## Les clés qui ne sont pas reprises telles quelles

Aucune : les quatre clés imprimées sont reprises (`officielle` par défaut).
Deux conflits sont déclarés dans `annales.py`, chacun signalé par ATTENTION
dans la justification en cause :

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2018/2019 S1 Q5 A (« Environ 5% des lymphocytes T activés échappent à la contraction clonale ») | vraie | **vraie, clé gardée** | le ronéo 2026-27 dit 90 % éliminés et 10 % conservés (p. 6-7) ; la FC n°1 2026-27, 95 % de morts ; la littérature, 5 à 10 % (Cui et Kaech 2010) : « environ 5 % » se tient |
| 2018/2019 S2 Q4 C (« les lymphocytes T mémoire résidents ont un faible potentiel prolifératif ») | vraie, seule vraie | **vraie, clé gardée, point douteux** | la diapositive les dit « rapidement prolifératives ++ », contre +++ pour les centraux (p. 10) ; le ronéo les dit aussi « les plus proches de la différenciation terminale » (p. 11), ce qui va dans le sens de la clé ; lu « moins prolifératifs que les centraux » |

Reprise avec une nuance dans la carte : **2021/2022 S1 Q4 C** (« un TCR de même
spécificité » : à lire « spécifiques du même antigène »).

## Absent du cours 2026-27

Une carte entière (`ABSENTS_2026`), que le générateur marque « Absent du cours
2026-27 » et range dans le thème `absent-2026` ; elle cite la FC n°9 2025-26
(p. 6), sans `chapitre=` :

| Carte | Notion | Pourquoi |
|---|---|---|
| `mem-qr-hepatite` | l'hépatite virale fulminante, où le patient meurt de sa réponse immunitaire | le ronéo 2026-27 garde le frein (p. 5) sans cet exemple ; l'explication de la carte garde aussi les autres exemples de 2025-26 (hépatite B ou C, cellules cancéreuses) |

Des propositions isolées tirées d'une autre année le disent dans leur propre
justification (le cours 2024-25 du Pr Labalette : seuil du TCR, résidents,
IL-7 pour les CD4 et IL-15 pour les CD8).

## Le lexique

Six termes, aux pages mesurées dans le ronéo 2026-27
(`scripts/chercher_pages.py`, en-têtes de page exclus) : expansion clonale
(p. 1, 3, 4, 6, 7, 9, 10), contraction clonale (1, 3, 5, 7, 14), tolérogénique
(5 : sur la diapositive, que le texte du PDF ne contient pas), vaccination (8,
9, 14 ; la p. 4 ne dit que « vaccin » et « vacciné »), immunosénescence (14), et **immunité stérilisante** (8, sur la
diapositive des îles Féroé), nouveau le 19/10/2026. Chacun dit son origine
grecque ou latine.

L'étymologie du terme nouveau et de sa racine `sterilis (latin)` est
**proposée** dans le brouillon `etym/immuno_memoire_t.json`, avec ses sources
(Wiktionnaire, Gaffiot, TLFi) ; la table `scripts/etymologies.json` n'est pas
modifiée par ce chapitre. La définition et la racine disent déjà, mot pour
mot, ce qu'`appliquer_etymologies.py` en écrira. « Réponse anamnestique » est
déjà accueillie par `immuno_temporelle` (`lex-anamnestique`) : pas reprise.

## À relire

Aucune carte `a-relire` : chaque carte de cours porte sa page dans le ronéo
2026-27 (la carte absente, la sienne dans la FC 2025-26), chaque annale sa clé
vérifiée sur la table de corrections (p. 7-8) et sa page de réponse dans le
ronéo.

## L'échelle : Simple → Moyen → Annale (C20, 16/10/2026)

Le pilote de l'immunité innée, étendu au reste de l'immunologie pour l'examen du 4/11 (choix de Vincent, 15/10). Sous les annales, 12 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 3 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`) ; les QROC reçoivent le schéma nu.

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `origine-memoire` | 3 | 1 | 1 |
| `types-memoire` | 5 | 1 | 2 |
| `entretien-memoire` | 4 | 1 | 1 |

**Le schéma** `ech-memoire-t`, « La mémoire T · contraction, trois types, entretien », donne 20 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_MEMOIRE_T`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu les dix chapitres ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Relue sur le ronéo 2026-27 (19/10/2026).** Les 15 marches citent les pages
de l'année. Le schéma cite « le ronéo 2026-27 (p. 3-14) » ; sa case de la
réactivité s'appelle « Plus réactifs, car : » (elle disait « ne pas
retenir ») et celle de la réponse secondaire « en 2 j au lieu de 4 à 7 j » (au
lieu de « dès J2 au lieu de J4 » : J4 est, sur la diapositive, le sommet de la
réponse secondaire). Aucune case n'a changé de place, aucun trou ni aucune
lettre n'a bougé. `mem-ech-s11` A dit « fonction ++ » (la diapositive) au lieu
de « fonction limitée » ; les clés et la forme (Simple réparties A/B/C, Moyen
d'une à trois vraies, « ↗ Prépare ») sont inchangées.

**Tag `edn`** : plus aucun. Il marquait `mem-ech-s1`, `-s2`, `-s3`, tirées de
la liste « Ne pas retenir ! » de 2025-26 ; la liste porte « Retenir ! » en
2026-27.

**Sans marche** :
- mem-an-1819s2-q4 E : le CD25 exprimé constitutivement, marque des LT régulateurs naturels, n'est pas dans ce cours ; il relève du chapitre de la réponse T. Faute de case propre, sa lettre est posée sur la case de l'entretien : la survie des LT mémoire tient à l'IL-7 et à l'IL-15, pas au récepteur de l'IL-2.

## Questions pour Vincent

1. **Les résidents prolifèrent-ils peu ?** (2018/2019 S2 Q4 C.) La clé imprimée
   est gardée avec un ATTENTION. Le ronéo 2026-27 les dit « rapidement
   prolifératives ++ », mais aussi « les plus proches de la différenciation
   terminale » : la clé se défend mieux qu'en 2025-26. On la garde officielle ?
2. **Le chiffre de la contraction** : les cartes de ce cours demandent 90 %
   éliminés, 10 % conservés (le ronéo de l'année le dit en toutes lettres) ;
   l'annale 2018/2019 S1 Q5 A garde « environ 5 % » vrai. Ça convient ?
3. **Le schéma des lieux** a remplacé le cerveau par la rate dans la boucle des
   effecteurs, comme le texte et la diapositive de l'année ; la rate y figure
   donc dans deux bandeaux, comme sur la diapositive. À regarder.
4. **« Immunité stérilisante »** entre au lexique (seul ce chapitre l'emploie) :
   l'étymologie proposée est à verser dans `etymologies.json`.
5. **Les centraux « produisent »-ils l'IL-7 ?** Le texte du ronéo le laisse
   entendre (p. 10), la diapositive non ; l'IL-7 et l'IL-15 ne sont pas des
   cytokines de LT. Les cartes disent « peu polarisées, l'IL-2 en tête », avec un
   ATTENTION (douteux). À confirmer à la séance de questions du 30/10.

## Régénérer

```powershell
cd contenu\chapitres\immuno_memoire_t
..\..\..\app\.venv\Scripts\python.exe generer.py
```

La planche se refait depuis `app/`, si ses rectangles changent :
`uv run --with pillow python ../.claude/skills/nouveau-chapitre/scripts/planche_depuis_image.py ../contenu/chapitres/immuno_memoire_t mem-pl-types --apercus <brouillon>`.
