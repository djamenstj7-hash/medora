# Les pathogènes viraux : virus respiratoires et des gastro-entérites — paquet Virologie

88 notes, 149 cartes. Chapitre `chap-ue-virologie-fc5` de l'UE Virologie (ordre 6).
Cours du **Pr Hober, le 22/10/2025** : la fin de la FC n°5 (« Pathogènes viraux I »,
p. 8-12) et la FC n°6 (« Les pathogènes viraux », 11 p.) du Ronéosaure 2025-26 ;
annales des polycopiés VIRO n°2_3, 4, 5 et 6 du Ronéosaure 2024-25, de la p. 12 de
la FC n°5 et du sujet de l'examen du 09/01/2025 (28 questions, 19 sessions). Examen de virologie le **5 janvier 2027**
(`exam-viro-jan-2027`, portée : l'UE).

**18/10/2026** : 2 questions du sujet de virologie 2025/2026 (examen du
08/01/2026, sans corrigé) — Q.9, Q.10 ; voir « Le sujet 2025/2026 ».

**Une fiche provisoire.** Aucun ronéo 2026-27 de virologie n'est paru (le cours
commence le 06/10/2026) : le chapitre est carté sur le Ronéosaure 2025-26 (décision
de Vincent du 02/10), et le ronéo de l'année corrigera les cartes à sa parution. Les
sources disent leur année dans leur auteur : chaque carte de cours porte le badge
« Cours 2025-26 ». Aucune carte ne dit « Absent du cours 2026-27 » ; les erreurs du
Ronéosaure sont dites par un ATTENTION sans genre, et n'entrent pas dans
`contenu/ERRATA_RONEOS_2026-27.md` (réservée aux ronéos 2026-27).

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 46 | 46 |
| QRU | 1 | 1 |
| Texte à trous | 13 | 65 |
| QROC | 9 | 9 |
| Recto-verso | 6 | 6 |
| Schéma cliquable | 2 | 11 |
| Planche à légender | 1 | 1 |
| Lexique | 10 | 10 |

Dont **30 annales** (QRM), sur 20 sessions, de 2015/2016 S1 à 2025/2026. Les 17 QCM
du cours ont, comme les annales, une justification par proposition. **43 QCM sur 47
sont illustrés** (91 %) ; les quatre autres (épidémiologie de la grippe,
coronavirus, virus non entéropathogènes, clinique des gastro-entérites) n'ont pas
de figure dans la fiche.

Six thèmes, tous nouveaux — libellés à ajouter à `THEME_LABELS`
(`app/src/med_engine/application/scopes.py`), sans chiffre :

| Clé | Libellé | Notes |
|---|---|---|
| `virus-respiratoires` | Virus respiratoires et syndromes | 19 |
| `grippe` | La grippe | 13 |
| `variations-antigeniques` | Glissements et cassures antigéniques | 4 |
| `coronavirus` | Les coronavirus | 4 |
| `gastro-enterites` | Virus des gastro-entérites | 32 |
| `gastro-mecanismes` | Physiopathologie des diarrhées virales | 3 |

`grippe`, `variations-antigeniques` et `gastro-enterites` servent aussi à
`viro_antiviraux`, `viro_virus_hote` et `viro_vaccins_vivants`, au même libellé
(plan C16 §2). L'introduction des pathogènes (infections aiguës, latentes,
persistantes, lentes) est rangée sous `virus-respiratoires` : c'est la première
partie du même cours.

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-viro-fc6` — « FC n°6 les pathogènes viraux » (11 p.), `VIROLOGIE/…`, `chapitre=chap-ue-virologie-fc5` | **2025-26** | la fiche du chapitre (`SRC["fiche"]`) : VRS, grippe, coronavirus (p. 2-5), gastro-entérites (p. 6-11) |
| `src-fc-viro-fc5` — « FC n°5 Marqueurs viraux 2 » (12 p.), `chapitre=chap-ue-virologie-fc4` | **2025-26** | ses p. 8-12 ouvrent ce cours (introduction, arbre respiratoire, VRS, grippe) ; cartes avec `fiche=` ; imprime 2024/2025 Q7 avec son Vrai/Faux (p. 12), que cite l'explication de la carte |
| `src-sujet-viro-2425` — « Sujet de virologie 2024/2025, session 1 » (examen du 09/01/2025, 16 p., 30 QCM) | 2024-25 | source de la session 2024/2025 (Q7, Q8) ; sujet sans corrigé ; déclaration identique dans tous les chapitres de virologie qui en prennent une question |
| `src-annales-virologie-6-pathogenes-viraux-ii` | 2024-25 | source par défaut des annales (11 questions) ; table p. 23-24 |
| `src-annales-virologie-5-pathogenes-viraux` | 2024-25 | 11 questions ; table p. 7 |
| `src-annales-virologie-4-marqueurs-viraux-application-au-diagnostic-virologique` | 2024-25 | 2 questions (2020/2021 S1 Q21, 2019/2020 S1 Q6) ; table p. 6-7 |
| `src-annales-virologie-2-3-multiplication-des-virus` | 2024-25 | 2 questions (2023/2024 S1 Q7, Q8) ; table p. 8 |
| cours 2024-25 (FC n°5 « Les pathogènes viraux », Ronéosaure 2024-25) | 2024-25 | non déclaré : cité dans le texte, pour les sérotypes des parainfluenza et la réinfection par le VRS |
| erratas du Ronéosaure : cours 2025-26 (`Erratas Virologie.docx`) et annales 2024-25 | — | trois entrées sur ce cours, reprises ; l'entrée d'annales sur la table de VIRO n°6, vérifiée |

**La FC n°5 est partagée** avec `viro_marqueurs` (ses p. 1-7) et `viro_multiplication`
(annale 2024/2025 Q1) : elle est déclarée rattachée à `chap-ue-virologie-fc4`, comme
le veut le plan C16 (§0.2, §16.3). Les déclarations des quatre polycopiés d'annales
suivent la forme commune fixée pour les chapitres écrits en parallèle (identifiant
`src-annales-<nom du fichier>`, cinq champs, rien d'autre).

**Un brouillon interrompu le 03/10** avait laissé `schemas.py` et treize figures dans
`media/`. Tout a été relu : dix PNG sont, à l'octet près, des images de la fiche
(FC n°5 p. 8, 9, 11 ; FC n°6 p. 3, 4, 9), deux en réunissent deux ou quatre
(`pv1-infections-evolution.png`, FC n°5 p. 8-9 ; `pv1-virus-ge-me.png`, FC n°6
p. 9-10), et leur légende le dit. Le génome viral de la FC n°5 p. 8, qu'aucune carte
n'employait, a été retiré. Dans `schemas.py`, la laryngite « parainfluenza 3 »
est devenue « parainfluenza » (voir les erreurs ci-dessous), et les zones de la
villosité ont été redessinées : le sommet, rectangle qui mordait sur le chorion, est
maintenant le fer à cheval de l'épithélium du dôme, et le chorion monte jusqu'à
l'arc intérieur. `pv1-grippe-recepteur.png` (FC n°6 p. 2, l'image même de la fiche)
a été ajoutée ; sa définition est celle du PDF (463 × 177 px), lisible agrandie.

**Relecture du 05/10** (toutes les cartes contre leur page, les 27 clés contre les
tables, les figures, les zones rendues) : la FC n°5 est déclarée exactement comme
dans `viro_multiplication` (avec `pages=12`, la forme que `viro_marqueurs` doit recopier) ; la zone « alvéoles » ne nomme plus le lieu
dans son libellé ; les racines `zo(o)-` et `bronch(o)-` suivent les propositions des
chapitres de parasitologie ; les deux points ouverts du plan (§14) sont dits sur leurs
cartes ; trois références vagues sont précisées ; la QROC du norovirus ne date plus
l'épidémie princeps des années 1970.

## Ce que le cours a dicté

- **Pas de gris « hors programme »** ni de rouge dans ces pages. La seule consigne :
  l'épidémie de 2017 est « à ne pas connaître en détails, mais notions à avoir en
  tête » (FC n°6 p. 4) — aucun chiffre de 2017 n'est carté.
- **Ce qui appartient à d'autres chapitres n'est pas carté** (plan C16) : les p. 1-7
  de la FC n°5 (marqueurs viraux), les annales 2024/2025 Q1 et la question SARS-CoV-2
  (Q30) de la p. 12 ; les vaccins (grippe, VRS, rotavirus) ne sont cités qu'en une
  proposition, renvoyée à « Vaccins viraux » ; le mécanisme de l'amantadine, à « La
  lutte contre les virus ».
- **Le vaccin grippal « 2019 »** du cours (H1N1pdm09, H3N2, lignées Victoria et
  Yamagata, FC n°6 p. 5) est carté tel quel, avec la mise à jour : vaccins trivalents,
  sans B/Yamagata, depuis la saison 2025-26 (`pv1-qc-grippe-epidemio`).
- **Le chiffre de 3 à 5 millions de décès** par gastro-entérite (FC n°6 p. 8) est
  dit comme celui du cours, avec l'estimation actuelle de l'OMS (environ 440 000
  décès par diarrhée chez l'enfant de moins de 5 ans) : `pv1-qc-ge-clinique`.

## Les erreurs du Ronéosaure 2025-26

Chacune est dite par un ATTENTION dans la carte qui porte la notion.

| Page | Ce que dit le ronéo | Ce qui est juste, et la source | Carte | Origine |
|---|---|---|---|---|
| FC n°5 p. 9 | « réplication continue (EHC chronique, VIH…) qui évolue lentement » | persistante à réplication continue : VHB, VHC chroniques ; le VIH est un virus lent (diapositive p. 9) | `pv1-fa-infections` | errata de la promo |
| FC n°5 p. 11 | syncytium : « un grand cytoplasme provoquant plusieurs bruits » | plusieurs **noyaux** | `pv1-qr-syncytium` | errata de la promo |
| FC n°6 p. 10 | « lapoviruses » | **lagovirus** | `pv1-qc-ge-virus` | errata de la promo |
| FC n°6 p. 3 | glissements « et cassures, qui sont des mutations ponctuelles » | la cassure est un **réassortiment** (même page, diapositive) | `pv1-qc-variations`, `pv1-an-2526-q9` C | relu |
| FC n°6 p. 5 | SARS-CoV-2 à « ARN monocaténaire segmenté positif » | génome **non segmenté** (NCBI NC_045512, 29 903 nt d'un tenant) | `pv1-qc-coronavirus` | relu |
| FC n°6 p. 5 | « Le Sars cov 2 s'est échappé de Chine (dès 2002) » | 2002-2003 : le **SARS-CoV** ; le SARS-CoV-2 date de fin 2019 | `pv1-qc-coronavirus`, `pv1-rv-sars-mers` | relu |
| FC n°6 p. 5 | genres « GAMMA et DELTA : chez les poissons par exemple » | surtout chez les **oiseaux** (delta aussi chez le porc) (Woo et al., J Virol 2012;86:3995 ; Sci Rep 2022;12:19412) | `pv1-qc-coronavirus` (explication) | relu |
| FC n°6 p. 6 | adénovirus digestifs « 40, 41 et 42 » | **40 et 41** (même fiche p. 10 ; espèce F ; le 42 est de l'espèce D ; Sci Rep 2022;12:11220) | `pv1-qc-ge-virus` | relu |
| FC n°6 p. 2 | « certains VRS peuvent être réactivés » | pas de latence : une **réinfection** (cours 2024-25 p. 10 ; immunité incomplète) | `pv1-qc-vrs` | relu |
| FC n°5 p. 11 | parainfluenza : « laryngite surtout sérotype 3 » | **trois sérotypes prédominants** (cours 2024-25 p. 9 ; 2019/2020 S1 Q23 D et S2 Q8 D) ; le croup est surtout dû aux types 1 et 2 (CDC) | `pv1-qc-syndromes`, `pv1-an-1920s1-q23` | relu |

Sans ATTENTION, parce qu'aucune réponse n'en dépend : « hPMV » pour hMPV (FC n°5
p. 10, dit dans `pv1-qr-hmpv`, qui donne aussi la famille actuelle, Pneumoviridae) ;
le VHA « excrété via le canal hépatique » (par la bile) ; une colite à CMV qui
provoquerait « des ulcérations de la muqueuse buccale » (FC n°6 p. 11), non cartée.

## Ce que les annales ont dicté

- **Les gastro-entérites, 18 questions** : la NSP4 du rotavirus dans 17 d'entre
  elles (une entérotoxine qui agit sur la cellule infectée **et** ses voisines), les
  entérocytes matures, « tous à ARN » (faux : l'adénovirus), les norovirus de
  l'adulte, l'astrovirus de l'enfant et du sujet âgé, l'immunochromatographie des
  selles (des antigènes, en quelques minutes ; ni acide nucléique, ni
  immunofluorescence, ni RT-PCR « en moins de 10 min »).
- **La grippe, 5 questions** : réservoir aviaire (ni cochon, ni inconnu), 8 segments
  d'ARN simple brin négatif (ni un segment, ni 11 segments double brin), noyau,
  acide sialique, H3N2 depuis 1968, recombinaisons possibles, diagnostic direct sur
  prélèvement respiratoire.
- **Les virus respiratoires, 5 questions** : pas de dissémination sanguine, VRS de
  la bronchiolite du nourrisson, parainfluenza des laryngites de l'enfant (trois
  sérotypes prédominants), rhinovirus des rhumes (plus de 100 sérotypes),
  adénovirus nus.

Sessions et polycopiés : la table du générateur (`SRC["sessions"]`) donne VIRO n°2_3
pour 2023/2024 S1, VIRO n°4 pour 2020/2021 S1 et 2019/2020 S1, VIRO n°5 pour six
autres sessions, le sujet de l'examen pour 2024/2025 (la FC n°5 jusqu'au 15/10/2026),
VIRO n°6 sinon. Quatre questions sont
imprimées dans un autre polycopié que celui de leur session, et leur explication le
dit : 2020/2021 S1 Q23 et 2019/2020 S1 Q23 (VIRO n°5), 2019/2020 S2 Q7 et 2018/2019
S2 « 21) » (VIRO n°6). Les doublons (même énoncé, même clé, dans deux ou trois
polycopiés) n'ont qu'une carte, qui nomme les autres impressions.

**Les étiquettes de VIRO n°6** (sessions 2019/2020 S1, 2020/2021 S1 et S2) sont en
cycle entre les énoncés et la table : retenues celles de la table, vérifiées une à
une (plan C16 §0.6), comme le dit l'errata des annales. L'énoncé « 2019/2020 S1
Q21 » de VIRO n°6 est 2020/2021 S1 Q21 (carte d'après VIRO n°4) ; celui imprimé deux
fois sous « 2020/2021 S1 Q6 » et « 2020/2021 S2 Q6 » est 2019/2020 S1 Q6, reposé tel
quel en 2020/2021 S2 Q6 : une carte, `pv1-an-1920s1-q6`.

## Le sujet 2025/2026 (18/10/2026)

Le sujet de virologie de l'examen du 08/01/2026 (cahier de 30 QCM,
`src-sujet-viro-2526`, sans corrigé), déposé le 18/10/2026, apporte 2
questions à ce chapitre (Q.9, Q.10) ; les autres questions vont aux chapitres
de leur cours. Aucune n'était déjà en cartes. Chaque clé est déduite du cours
2025-26, l'année de l'examen, proposition par proposition et page à l'appui
(`officielle=False`) ; les propositions déjà posées d'autres années ont servi
de contre-épreuve, et l'explication dit chaque reprise. Rédigées et
contre-vérifiées le 18/10/2026 : un rédacteur, un sceptique qui a refait
chaque clé sur le cours, un critique de complétude. Le profil des clés — A
souvent vraie, trois ou quatre vraies par question — est celui des sessions 1
officielles du Pr Hober (2021/2022 S1, 2023/2024 S1).

| Question | Clé imprimée | Retenue | Lecture |
|---|---|---|---|
| 2025/2026 Q.9 (`pv1-an-2526-q9`) | aucune (sujet sans corrigé) | **ADE** | La grippe est enveloppée, à ARN négatif segmenté, localisée à l'arbre respiratoire, et varie de deux façons, glissement et cassure. |
| 2025/2026 Q.10 (`pv1-an-2526-q10`) | aucune (sujet sans corrigé) | **BCD** | À chaque virus son terrain — rotavirus et enfant, norovirus et adulte, astrovirus 1 et sujet âgé —, à l'adénovirus son ADN, et au diagnostic les selles. |

Ce qui est signalé :

- Q.9 C : ATTENTION sur l'erreur du Ronéosaure déjà relevée (la cassure rangée
  parmi les « mutations ponctuelles », FC n°6, p. 3), carte ajoutée à sa ligne
  du tableau des erreurs.
- Q.10 A, sans point final, tel qu'imprimé ; la p. 6 cite les adénovirus 40, 41
  et 42, la p. 10 les types 40 et 41 : la justification dit « 40 et 41 surtout
  ».

## Les clés qui ne sont pas reprises telles quelles

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2023/2024 S1 Q8 (VIRO n°2_3 ; aussi n°5 et n°6) | BCDE | **BCE** | D « la NSP4 … fuite d'eau et d'ions par les cellules infectées **et pas les cellules voisines** » est faux : FC n°6 p. 9 ; 2023/2024 S2 Q8 D, 2021/2022 S1 et S2 Q16 C, 2015/2016 S2 Q22 C cotés vrais ; J Virol 2000;74:11663, Virol J 2011;8:551. `officielle=False`, `CONFLITS`, ATTENTION sur D |
| 2024/2025 Q7 (FC n°5 p. 12) | — (Vrai/Faux du ronéo : BDE) | BDE | pas de table de corrections ; clé déduite du Vrai/Faux, conforme au cours ; `officielle=False`. Énoncé vérifié sur le sujet du 09/01/2025 : identique |
| 2024/2025 Q8 (`pv1-an-2425-q8`) | aucune (sujet sans corrigé) | CD | clé déduite du cours : à ARN sauf l'adénovirus, nus sauf le coronavirus (FC n°6 p. 6) ; infection localisée (FC n°2 p. 8) ; norovirus de l'adulte (p. 11) ; NSP4 sur les cellules voisines (p. 9) ; antigènes dans les selles, pas dans le sang (p. 11). `officielle=False` |

Reprise mais nuancée : 2021/2022 S1 Q15 D, « le génome des virus de grippe A est à
ARN simple brin linéaire », cotée fausse — le professeur attend « segmenté » et
« négatif » ; la justification le dit, avec les deux sessions qui le montrent.

## Les schémas cliquables et la planche

| Fichier | On clique | Cartes |
|---|---|---|
| `arbre-respiratoire-nu.svg` (correction : `arbre-respiratoire.svg`) | fosses nasales, pharynx, larynx, trachée, bronche, bronchioles, alvéoles : l'étage de chaque syndrome | 7 |
| `villosite-nue.svg` (correction : `villosite.svg`) | sommet de la villosité (entérocytes matures), crypte, lumière, chorion | 4 |

L'arbre est redessiné d'après la diapositive anglaise de la FC n°5 p. 9, qui reste
en correction des QCM ; un seul poumon est plein. La villosité est redessinée
d'après la FC n°6 p. 7, dont les deux figures sont trop petites (154 × 104 px) pour
servir. Le dessin et les zones lisent les mêmes constantes.

**La planche** `pv1-pl-virus-ge` : les quatre clichés de microscopie électronique
de la FC n°6 p. 9-10 (rotavirus, calicivirus, astrovirus, adénovirus), noms effacés
et numérotés ; intrus : coronavirus, entérovirus, réovirus. L'image numérotée
(`pv1-virus-ge-me-numerotee.png`) sort de `planche_depuis_image.py`, rectangles dans
`donnees.py`.

## Le lexique

Dix termes, pages mesurées par `chercher_pages.py` dans les FC n°5 et n°6 :
rhinite, pharyngite, laryngite, bronchiolite (FC n°5 p. 9-11), hémagglutinine,
neuraminidase (FC n°6 p. 2-4), zoonose (p. 5), entérotoxine (p. 9), malabsorption
(p. 7, 9), atrophie villositaire (p. 7). La malabsorption est déjà un terme de
`biostat_pharmacovigilance` (`lex-malabsorption`) : ici `lex-malabsorption-viro`,
comme `lex-apoptose-bmcp`. « Syncytium », dans la FC n°5 p. 11 et la FC n°6 p. 2,
n'est pas pris : le plan ne le donne pas à ce chapitre (effet cytopathique,
`viro_multiplication`).

Chaque terme dit son origine. Huit racines sont nouvelles (`rhin(o)-`,
`pharyng(o)-`, `laryng(o)-`, `bronch(o)-`, `-ole (latin)`, `zo(o)-`, `-nose`,
`villus (latin)`) et les dix termes aussi : proposés dans
`scratchpad/etym/viro_pathogenes_1.json`, vérifiés sur le Wiktionnaire, l'Online
Etymology Dictionary et, pour l'acide neuraminique, la publication de Klenk (1941).
Trois de ces racines sont aussi proposées par des chapitres de parasitologie écrits en
même temps : `zo(o)-` (parasito_digestives_autochtones, paludisme, parasitisme),
`bronch(o)-` (parasito_aspergillose_pneumocystose) et `-nose`
(parasito_digestives_autochtones). Elles reprennent ici leur clé et leur texte, pour
que la même racine dise la même chose partout.
Les racines existantes sont reprises à la clé près (`-ite`, `hém(at)-`,
`ad- (latin)`, `gluten (latin)`, `neur(o)-`, `-ase`, `entér-`, `tox(i)-`,
`male (latin)`, `ab- (latin)`, `sorbere (latin)`, `a-/an-`, `-trophie`).

## Questions pour Vincent

1. **2023/2024 S1 Q8, clé BCE contre la table BCDE.** Le cours, quatre autres
   sessions et la littérature disent que la NSP4 agit aussi sur les cellules
   voisines ; la carte retient BCE et le signale. Si le corrigé de la faculté
   confirmait BCDE, garde-t-on BCE ?
2. **Parainfluenza : « surtout sérotype 3 » (FC n°5 p. 11).** Tenu pour une erreur
   du Ronéosaure (le cours 2024-25 et les annales disent « trois sérotypes
   prédominants ») ; à revoir sur le ronéo 2026-27.
3. **2021/2022 S1 Q15 D** (« ARN simple brin linéaire », cotée fausse) : clé reprise
   avec la lecture du professeur. D'accord ?
4. **Le diagnostic de grippe « par antigènes dans le sang » / « par anticorps dans
   les prélèvements respiratoires »** (2021/2022 S1 Q15 E, 2022/2023 S1 Q15 E) : la
   fiche ne le dit pas mot pour mot ; proposition du plan appliquée — clés reprises,
   justifiées par le diagnostic direct sur prélèvement respiratoire (FC n°6 p. 4,
   FC n°5 p. 9-10), et la justification de chaque item E dit que le cours ne le
   nomme pas.
5. **La FC n°5 est rattachée à `chap-ue-virologie-fc4`** (marqueurs), et ses p. 8-12
   sont citées ici : le lecteur l'ouvrira depuis « Marqueurs viraux ». Faut-il
   préférer un rattachement ici ?

## À relire

Aucune carte `a-relire` : chaque carte de cours cite sa page, chaque annale sa clé.
Le chapitre attend le ronéo 2026-27 (cours à partir du 06/10/2026), qui le
corrigera.


## L'échelle : Simple → Moyen → Annale (C20, 19/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 5 janvier. Sous les annales, 52 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 13 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`).

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `virus-respiratoires` | 8 | 2 | 5 |
| `grippe` | 18 | 4 | 6 |
| `gastro-enterites` | 26 | 7 | 19 |

**Le schéma** `ech-pathogenes`, « Les pathogènes viraux · l'arbre respiratoire, la grippe, les gastro-entérites », donne 96 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_PATHOGENES`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Sans marche** :
- 2019/2020 S1 Q23 D, 2019/2020 S2 Q8 D, 2020/2021 S1 Q23 C : la partie « 3 sérotypes prédominants » des parainfluenza n'a pas de carte. Le Ronéosaure 2025-26, qui fait foi, écrit « surtout sérotype 3 » (FC n°5, p. 11), contre le cours 2024-25 et les annales : la règle 11 l'exclut du schéma ; les cartes s6, s7 et m5 le disent par un ATTENTION. La laryngite et l'enfant, eux, ont leurs marches (s6, s7).
- 2023/2024 S1 Q7 C : la partie « sur des glycoprotéines ou glycolipides » n'a pas de carte à elle. L'acide sialique (s17) et le galactose (s18) en ont une ; la justification de s17 cite le support glycoprotéines/lipides (FC n°6, p. 3).

## Régénérer

```powershell
cd contenu\chapitres\viro_pathogenes_1
..\..\..\app\.venv\Scripts\python.exe generer.py
```

`generer.py` est la copie exacte du modèle du skill. La planche numérotée se refait
depuis `app/` avec `planche_depuis_image.py ../contenu/chapitres/viro_pathogenes_1
pv1-pl-virus-ge`.
