# Médecine nucléaire — paquet BMCP

55 notes, 98 cartes. Chapitre `chap-ue-bmcp-fc16` de l'UE BMCP, ordre 17. Cours
du **Pr Huglo, le 28/11/2025, de 11 h à 12 h**, dans le **Ronéosaure 2025-26**
(FC n°17, 10 pages, **p. 5-10 seulement**) ; les annales du polycopié BMCP 16
du Ronéosaure 2024-25 (3 sessions citées) et le **QROC d'imagerie du sujet de
2024/2025 S1** (examen du 09/01/2025, sans corrigé, déposé le 15/10/2026).
Examen : mardi 5 janvier 2027.

**Fiche provisoire** (C16, décision de Vincent du 02/10) : le cours 2026-27
n'est pas encore paru. Chaque carte de cours cite la FC 2025-26 à sa page et
porte le tag `cours-2025-26` (le badge « Cours 2025-26 », lu dans l'auteur de
la source) ; le ronéo 2026-27 corrigera les cartes quand il sortira.

**Reprise du 05/10** : le dossier contenait un brouillon interrompu le 03/10
(`schemas.py` et dix figures dans `media/`), sans `donnees.py`. Tout a été
relu : les dix figures sont bien celles des pages qu'elles citent et sont
gardées (réduites à 256 couleurs) ; `schemas.py` est gardé, un libellé de
zone corrigé (« à la meilleure résolution spatiale » valait aussi pour le
sténopéique, qui résout bien une petite zone : elle dit maintenant « à trous
parallèles qui sépare le mieux deux points voisins »). Le reste est écrit dans
cette reprise.

**Relecture du 05/10** (chaque carte contre la page qu'elle cite, les trois
clés contre la table et les erratas, les figures, le schéma rendu avec ses
zones) ; corrigé :

- le parcours des α : « quelques micromètres » (`mnu-fa-particules`,
  `mnu-qc-particules` A, `particules.svg`) devient « quelques dizaines de
  micromètres » — le ronéo dit seulement « µm », et une α parcourt 50 à
  100 µm dans les tissus (Poty et al., J Nucl Med 2018) ;
- `mnu-qc-collimateur-role` E recopiait mot pour mot l'item B de l'annale
  2022/2023 S2 (« Tous les collimateurs sont à trous parallèles ») : il devient
  « il n'en existe que deux types », que le ronéo dément (« pas que deux
  types », p. 9) ;
- `mnu-qr-radiopharmaceutique` acceptait « traceur radioactif » et
  « radiotraceur », que la question dit déjà : retirés ;
- `mnu-qc-principes` B dit l'exception des acquisitions dynamiques (FC n°18,
  p. 3) ; `mnu-qr-technetium` cite la fenêtre de la FC n°18 telle qu'écrite
  (« une fenêtre de 10 % ») ;
- la date d'Anger précisée (mise au point fin 1956-1957, publiée en 1958) ;
  les citations du Charonéo 2023-24 portent son vrai titre ; le compte des
  autres questions du BMCP 16 est de treize (onze QCM et deux QROC), pas onze.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 15 | 15 |
| QRU | 2 | 2 |
| Texte à trous | 11 | 52 |
| QROC | 8 | 8 |
| Recto-verso | 9 | 9 |
| Lexique | 8 | 8 |
| Schéma cliquable | 1 | 3 |
| Planche à légender | 1 | 1 |

Dont **7 annales** sur 4 sessions : 3 QCM du polycopié BMCP 16, et les
4 questions du QROC d'imagerie de 2024/2025 S1, en recto-verso.

Cinq thèmes, dans l'ordre du cours. Toutes les clés sont nouvelles ; leurs
libellés sont dans `THEME_LABELS`
(`app/src/med_engine/application/scopes.py`) depuis l'intégration du 05/10 :

| Clé | Libellé | Notes |
|---|---|---|
| `principes-mn` | Principes de la médecine nucléaire | 11 |
| `particules-emises` | Particules émises : α, β−, β+, γ | 6 |
| `radiotraceurs` | Traceurs, marqueurs et théranostique | 7 |
| `gamma-camera` | La gamma-caméra | 12 |
| `collimateurs` | Collimateurs : sensibilité et résolution | 11 |

`gamma-camera` est partagé avec `bmcp_tep` (FC n°18), au même libellé. Le plan
C16 proposait `particules` : la clé prise est `particules-emises`, plus
spécifique (« particules » servirait aussi aux particules virales) — voir les
questions pour Vincent.

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-bmcp-mnu-2526` — Ronéosaure, « FC n°17 - Médecine nucléaire » (10 p.) | 2025-26 | le cours ; `SRC["fiche"]`, ses figures ; fiche provisoire |
| `src-annales-bmcp-16-medecine-nucleaire` — « BMCP 16 - Médecine nucléaire » | 2024-25 | 5 sessions, 14 QCM et 2 QROC, table p. 7 ; 3 QCM ici |
| `src-sujets-bmcp-2425` — « Sujets de BMCP 2024/2025, session 1 » (examen du 09/01/2025, 30 p.) | 2024-25 | la session 2024/2025 S1 : le QROC d'imagerie (cahier de 8 p., p. 3-5), ses deux figures ; sujet sans corrigé ; déclarée à l'identique dans tous les chapitres de BMCP qui en tirent une question |

La source d'annales est déclarée avec exactement les champs convenus pour les
chapitres écrits en parallèle (id, kind, titre, chemin, auteur) : `bmcp_tep`,
`bmcp_bases_physiques` et `bmcp_echographie_irm`, qui tirent aussi des
questions du BMCP 16, doivent la reprendre à l'identique.

Lus en appoint, sans être déclarés : le Ronéosaure 2024-25 (FC n°16,
« médecine radioactive partie 1 », 7 p.) et le Charonéo 2023-24 (« Bases
physiques de l'imagerie médicale », 27/10/2023, p. 14-20, et sa suite du
28/11/2023), cités dans le texte de quelques cartes ; les erratas des cours 2025-26 et des annales, qui n'ont
aucune entrée pour ce cours. Le texte 2025-26 recopie presque mot pour mot
celui de 2024-25, qui reprenait celui de 2023-24 : trois textes, une seule
prise de notes — une erreur répétée trois fois n'y est pas pour autant
confirmée.

Les en-têtes des ronéos, des erratas et du polycopié portent des noms
d'étudiants : aucun n'est repris.

## Ce que le cours a dicté

- **La part de ce chapitre** (plan C16, § 0.1 et § 14) : les p. 5-10. Les
  p. 2-5 (fin de la scanographie) sont à `bmcp_bases_physiques`. Les
  acquisitions, la caméra CZT, la TEP et les radiopharmaceutiques sont à
  `bmcp_tep` (FC n°18) ; son « résumé du dernier cours » (p. 2), la
  composition de la gamma-caméra, se carte ici, par la planche tirée de la
  figure de la p. 10 de la FC n°17 — la même que la FC n°18 reprend.
- **Ni rouge ni gris** dans ce ronéo ; aucune consigne « à ne pas retenir ».
  Une seule mention « (Important) » : la description du radiotraceur (p. 7),
  qui a sa carte dans chaque forme (`mnu-fa-traceur`, `mnu-qc-traceur`,
  `mnu-rv-marqueur-traceur`).
- **Le référentiel de l'EDN** (p. 5-6) fait `mnu-fa-referentiel` ; la
  coïncidence de la TEP y est nommée, mais se carte à `bmcp_tep`.

## Ce que les annales ont dicté

| Savoir | Questions |
|---|---|
| La constitution de la gamma-caméra : cristal, photomultiplicateurs, collimateur | 2022/2023 S1 Q. 23 |
| Les collimateurs : interchangeables, adaptés à l'énergie, entre le patient et le cristal | 2022/2023 S2 Q. 23 |
| Qui irradie le patient : les rayons X, le traceur administré — pas la caméra | 2018/2019 S1 Q. 20 |
| Le QROC d'imagerie, un cas : les éléments A à E d'une gamma-caméra d'Anger (Q. 1) ; deux raisons d'adapter le collimateur (Q. 2) ; les types d'acquisition des images d'un examen — corps entier, TEMP-TDM (Q. 3) ; la fusion et les fenêtres du scanner (Q. 4) | 2024/2025 S1, QROC d'imagerie |

**Le QROC d'imagerie de 2024/2025 S1** : une patiente d'une trentaine
d'années, examinée sur une gamma-caméra d'Anger ; la figure 1 est le schéma
d'un livre (légendes anglaises sous des cadres blancs, lettres A à E posées
par le sujet), la figure 2 les images de l'examen (A et B : corps entier de
face et de dos ; C1 à C4 : une coupe du bassin en TEMP, en fusion, puis au
scanner dans deux fenêtres). Quatre questions, une carte chacune
(`mnu-anq-2425s1-qroc1` à `qroc4`), en recto-verso : les réponses sont des
listes. Les figures sont la question (`illustration_question`) ; elles ont été
extraites en rendant la page du sujet, et non l'image incorporée, qui porte
encore les légendes du livre. Les questions 3 et 4 touchent aussi la FC n°18
(les acquisitions, `bmcp_tep`) et les p. 2-5 de la FC n°17 (les fenêtres du
scanner, `bmcp_bases_physiques`) : elles restent ici, avec les figures du cas,
et citent ces pages dans leur explication.

Les treize autres questions du polycopié BMCP 16 (onze QCM et les deux QROC)
sont dans le chapitre de leur sujet (plan C16, § 12, § 10 et § 7) :
`bmcp_tep`, neuf (TEP, SUV, cas TEP-TDM, technétium, QROC 1 et 4) ;
`bmcp_bases_physiques`, trois (modalités, demande d'examen, enfant de 8 ans) ;
`bmcp_echographie_irm`, une (examen B).

## Les erreurs du ronéo 2025-26

Le Ronéosaure n'est pas le ronéo de l'année : chaque erreur est portée par un
**ATTENTION nu** dans la carte qui tient la notion, la sorte dite dans le
texte, et rien n'entre dans `contenu/ERRATA_RONEOS_2026-27.md`.

| Page | Le ronéo dit | Retenu | Sorte | Carte |
|---|---|---|---|---|
| 8 | les atomes du cristal reviennent à l'état fondamental « en émettant des rayons X de fluorescence qui seront dans la lumière visible ou ultraviolet » | des photons lumineux de scintillation : la diapositive de la p. 9 dit « photons UV », le NaI(Tl) émet dans le bleu (Hamamatsu, *Photomultiplier Tubes*) | prise de notes | `mnu-qc-cristal` C |
| 8 | le même support marqué à un émetteur β− « qui est le salarium » | le samarium 153 (EDTMP, un phosphonate), émetteur β− des douleurs de métastases osseuses (Cancer Manag Res 2013) ; le radium 223 est un émetteur α | prise de notes | `mnu-qc-theranostique` C |
| 9 | la position « par rapport au barycentre (axe X) » et par « la hauteur des pics (Y) » | le barycentre « selon l'axe X » et « selon l'axe Y » (diapositive de la p. 8) ; la somme donne Z | prise de notes | `mnu-fa-coordonnees`, `mnu-qc-coordonnee-z` B |
| 9 | « on passe de 7x7 donc 49, à 49x49 » | chaque dynode multiplie par le même facteur : 7, 49, 343… ; gain de 10⁶ à 10⁷ (Hamamatsu) | point douteux | `mnu-fa-photomultiplicateur` |
| 10 | « le photon gamma 321 c'est 300 keV » | incompréhensible ; la diapositive classe 300 keV en haute énergie (l'iode 131 émet surtout à 364 keV) ; aucune carte ne retient « 321 » | point douteux | `mnu-qc-energie` |
| 1, 8 | « Gamma Caméra (de type Anger, 1953) » | caméra à sténopé, cristal NaI(Tl) sur plaque photographique, en 1952 ; caméra à scintillation à photomultiplicateurs mise au point fin 1956-1957, publiée en janvier 1958 (Radiol Phys Technol 2013), datée en général de 1957 ; aucune carte ne demande la date | point douteux | `mnu-qc-cristal` (explication) |

Sans carte, parce qu'aucune n'en dépend : « location par détection en
coïncidence » (p. 6, pour localisation), « Β » pour β− (p. 6), le « 6 » égaré
en fin de ligne (p. 9).

## Les clés qui ne sont pas reprises telles quelles

**Aucune** clé imprimée n'est contestée. Les trois clés imprimées sont celles
du cours 2025-26 ; aucune n'est discutée par l'errata des annales ; aucun
conflit n'est déclaré (`CONFLITS = []`). Le QROC de 2024/2025 n'a **aucun
corrigé** : ses quatre réponses sont construites sur le cours,
`officielle=False`, et l'explication de chaque carte le dit.

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2024/2025 S1, QROC d'imagerie, Q. 1 | aucune (sujet sans corrigé) | A collimateur (A1 parallèle ; A2 divergent, A3 convergent, A4 sténopéique), B cristal NaI(Tl), C guide de lumière, D photomultiplicateurs, E électronique (positionnement, sommation, informatique) | la synthèse du cours, FC n°17 p. 10 (et p. 8-9) ; le livre de la figure le confirme sous ses cadres blancs |
| 2024/2025 S1, QROC d'imagerie, Q. 2 | aucune (sujet sans corrigé) | l'énergie des photons du radionucléide ; le compromis sensibilité-résolution selon l'organe (sténopéique pour les petits) | FC n°17 p. 9-10 |
| 2024/2025 S1, QROC d'imagerie, Q. 3 | aucune (sujet sans corrigé) | A, B : planaires corps entier par balayage, face antérieure et postérieure ; C : en coupes, TEMP couplée au scanner (TEMP-TDM) | FC n°18 p. 2-4 ; l'examen, ni nommé ni demandé, a l'aspect d'une scintigraphie osseuse (FC n°17 p. 8), dit comme une lecture d'image |
| 2024/2025 S1, QROC d'imagerie, Q. 4 | aucune (sujet sans corrigé) | C2 : fusion TEMP et scanner ; C3, C4 : la même coupe de scanner en fenêtre osseuse puis des parties molles | FC n°17 p. 4 (fenêtres, filtres), p. 6-7 (hybrides) ; FC n°21 p. 3-4 ; un filtre dur sur C3 n'est pas sûr, la carte le dit |

| Carte | Session | N° | Clé imprimée | Retenu | Ce que la question teste |
|---|---|---|---|---|---|
| `mnu-an-2223s1-q23` | 2022/2023 S1 | Q. 23 | ACDE | ACDE | le photomultiplicateur multiplie des électrons, pas le photon γ (B) |
| `mnu-an-2223s2-q23` | 2022/2023 S2 | Q. 23 | AC | AC | le collimateur : pas toujours parallèle (B), devant le cristal (D), il trie la direction, pas l'énergie (E) |
| `mnu-an-1819s1-q20` | 2018/2019 S1 | Q. 20 | ACE | ACE | la caméra et la couronne TEP détectent sans irradier (B, D) ; le traceur irradie (E) |

## Les schémas et les figures

**Dix figures de la FC 2025-26**, extraites en PNG (captures de diapositives,
256 couleurs) : la spécialité médicale (p. 7) ; la scintigraphie osseuse en
gamma-caméra et en TEP, la scintigraphie diagnostique et thérapeutique, la
TEP au FDG et au PSMA puis le PSMA-177Lu, la constitution de la gamma-caméra
(p. 8) ; le photomultiplicateur, le sténopéique, les collimateurs et le
compromis (p. 9) ; les collimateurs selon l'énergie et la synthèse de la
gamma-caméra (p. 10). Les scintigraphies et TEP sont des images de
médecine nucléaire, pas des photographies de patient.

**Un schéma cliquable** (`schemas.py`), avec sa version légendée en
correction :

| Fichier | Ce qu'on clique | Pourquoi ce dessin |
|---|---|---|
| `collimateurs.svg` | le collimateur le plus sensible (grands trous), celui à trous parallèles qui sépare le mieux deux points (petits trous), celui qui agrandit un petit organe (sténopéique) — 3 zones, une par panneau, 24 px entre deux zones | la diapositive de la p. 9 : même cristal, même épaisseur et même hauteur de septa, seule la taille des trous change ; sous chaque collimateur, deux points d'un organe et la tache que chacun laisse sur le cristal, calculée (largeur × (h + d) / h) : confondues derrière les grands trous, séparées derrière les petits, inversées et agrandies derrière le trou unique |

**Une planche à légender**, `mnu-pl-gamma-camera` : la synthèse de la p. 10
(« En résumé : principe global de fonctionnement d'une gamma-caméra de type
Anger »), sept légendes effacées par `planche_depuis_image.py` (collimateur,
cristal, guide de lumière, photomultiplicateurs, circuit électronique,
informatique — son cadre reste, vidé —, blindage) ; quatre intrus d'autres
appareils : anode tournante, grille anti-diffusante, amplificateur de
brillance (radiologie), couronne de détecteurs (TEP). Le patient n'a pas de
numéro : il n'est pas légendé sur la figure. Les rectangles sont dans
`donnees.py` ; l'aperçu de contrôle a été relu.

**Une figure redessinée** pour les corrections : `particules.svg` (p. 6), ce
que fait chaque particule dans le patient.

**15 QCM sur 17 illustrés (88 %)** — 12 sur 14 du cours, 3 sur 3 des
annales —, 42 notes sur 55 (les quatre QROC de 2024/2025 ont leur figure du
cours en correction).

**Trois figures ajoutées le 15/10/2026**, pour le QROC de 2024/2025 :
`mnu-an-2425-gamma-camera.png` (figure 1, p. 3 du cahier) et
`mnu-an-2425-examen.png` (figure 2, p. 4), rendues à 200 dpi depuis la page du
sujet et réduites à 256 couleurs, source `src-sujets-bmcp-2425` ; et
`bpi-filtres.png`, la diapositive de la FC n°17 p. 4 (la même coupe en
fenêtre abdominale et osseuse, filtre mou et dur), copie à l'identique de la
figure de `bmcp_bases_physiques` — même PDF, même page —, qui corrige la Q. 4. Sans figure : `mnu-qc-thyroide` (le ronéo n'a pas
de scintigraphie thyroïdienne) et `mnu-qc-hybrides` (les images « où est
Charlie » de la p. 7 sont des vignettes illisibles).

## Le lexique

Huit termes, ceux du plan C16 ; aucun n'existait (vérifié contre les `lex-*`
de tous les paquets). Pages mesurées dans la FC 2025-26 (`chercher_pages.py`),
la p. 1 (le plan du cours) exclue :

| Terme | Origine | Pages |
|---|---|---|
| Radiopharmaceutique | latin radius + grec pharmakeutikós | 6 |
| Scintigraphie | latin scintilla + grec gráphein | 7, 8 |
| Traceur | latin *tractiare (trahere), par tracer | 6, 7, 8 |
| Théranostique | grec therapeía + diagnōstikós | 7, 8 |
| Photomultiplicateur | grec phôs + latin multiplicator | 5, 8, 9 |
| Dynode | grec dúnamis + hodós | 8 |
| Collimateur | latin collimare (pour collineare) | 9, 10 |
| Sténopéique | grec stenós + opḗ | 9 |

Cinq racines sont enseignées par la FC de sémantique et la citent :
`radi- (latin)` et `photo-` (2/2, p. 12), `sténo-` (2/2, p. 6), `-thérapie`
(1/2, p. 5), `dia-` (2/2, p. 11). Huit racines nouvelles (`radi- (latin)`,
`photo-`, `scintill- (latin)`, `plicare (latin)`, `-ode`, `collimare (latin)`,
`-opé (grec)`, `trahere (latin)`) et les huit termes sont proposés à la table
commune, dans `scratchpad/etym/bmcp_medecine_nucleaire.json` (TLFi par l'API
du CNRTL, Bailly, Gaffiot, Wiktionnaire) ; les textes du lexique sont déjà
écrits dans la forme que `appliquer_etymologies.py` produirait (vérifié).
`pharmac(o)-`, `-graphie`, `-thérapie`, `dia-`, `-gnose`, `multi- (latin)`,
`-dynamie` et `sténo-` reprennent les clés existantes.

Unifié à l'intégration du 05/10 : la racine latine *radius*, proposée sous
plusieurs clés par les chapitres de la vague, n'a plus qu'une entrée dans
`etymologies.json`, `radi- (latin)`, la forme de la FC de sémantique. Celle-ci
l'enseigne p. 12 du PDF, avec `photo-` (vérifié dans le texte de la page) : les
deux citations de ce chapitre, qui disaient p. 11, sont corrigées.

## Décisions prises en route

- **`EXAMENS` n'est pas déclaré** (plan C16, § 0.2) : le 5 janvier se règle dans
  l'application.
- **La planche sur la figure de la FC n°17 (p. 10)**, et non sur celle de la
  FC n°18 (p. 2), qui appartient à `bmcp_tep` : même contenu, et la source
  reste celle du chapitre.
- **Les QCM de cours** sont faits sur le ronéo seul ; les distracteurs viennent
  du même champ (la place du guide de lumière, ce que multiplie le
  photomultiplicateur, ce que trie le collimateur), qui sont précisément les
  pièges des deux annales de la gamma-caméra.

## Questions pour Vincent

1. **La clé de thème `particules-emises`** au lieu du `particules` du plan C16 :
   le mot seul serait repris par une autre UE (les particules virales). Garder
   `particules-emises`, ou revenir au plan ?
2. **La date d'Anger** : le ronéo écrit « 1953 », la caméra à scintillation
   date de 1957. Aucune carte ne demande la date (le cours n'en fait pas un
   objet d'examen) ; faut-il une carte « 1957 », ou laisser l'histoire de
   côté ?

## À relire

**Aucune carte `a-relire`** : toutes les notes citent une page de la FC 2025-26
ou une source sûre. Les quatre QROC de 2024/2025, sans corrigé, ont leur
réponse sur des pages précises du cours ; l'examen de la figure 2 n'est pas
nommé par le sujet, et sa lecture (une scintigraphie osseuse) n'est pas ce que
les questions demandent. Reste à Vincent :

- quand le ronéo 2026-27 paraîtra, relire chaque carte sur lui et retirer le
  badge « Cours 2025-26 » ;
- `copier_les_cours.py` avec le dossier `…/examen janvier` du Ronéosaure
  2025-26, hors du bac à sable, pour que la fiche s'ouvre dans l'application.

## Intégration (05/10)

- Les libellés de thèmes sont dans `THEME_LABELS`
  (`app/src/med_engine/application/scopes.py`), bloc « BMCP FC n°6 à 22 ».
- Les étymologies proposées (racines et termes) sont versées dans
  `.claude/skills/nouveau-chapitre/scripts/etymologies.json` ;
  `appliquer_etymologies.py` n'a rien réécrit, les textes du lexique étant
  déjà à sa forme.
- `radi- (latin)` et `photo-` citent la FC de sémantique 2/2 p. 12, et non
  p. 11 (vérifié dans le texte du PDF) ; `scintill- (latin)` n'a qu'une
  entrée, commune avec `bmcp_tep`.

## L'échelle : Simple → Moyen → Annale (C20, 19/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 5 janvier (BMCP) ou du 6 janvier (SSH, papier). Sous les annales, 14 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 4 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`) ; les QROC reçoivent le schéma nu.

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `principes-mn` | 4 | 1 | 2 |
| `gamma-camera` | 5 | 2 | 3 |
| `collimateurs` | 5 | 1 | 2 |

**Le schéma** `ech-gamma-camera`, « La médecine nucléaire · du patient à l'image », donne 22 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_GAMMA_CAMERA`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Sans marche** :
- mnu-anq-2425s1-qroc3, les images planaires du corps entier par balayage et la TEMP : ces acquisitions sont décrites par la FC n°18, hors des sources de ce chapitre ; seule la notion d'appareil hybride, scanner et médecine nucléaire, a sa marche (mnu-ech-s4, FC n°17 p. 6-7).
- mnu-anq-2425s1-qroc1 : le blindage et l'informatique, que le verso ajoute à l'électronique (E), ne sont nommés que sur le schéma de synthèse de la p. 10, sans texte de cours ; l'électronique a ses deux marches (s9, s10).

## Régénérer

```powershell
..\..\..\app\.venv\Scripts\python.exe generer.py
```
