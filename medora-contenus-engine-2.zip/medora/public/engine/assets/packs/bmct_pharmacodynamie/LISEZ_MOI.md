# Pharmacodynamie générale — paquet BMCT

95 notes, 152 cartes. Chapitre `chap-ue-bmct-fc1` de l'UE BMCT (identifiant du
squelette), premier chapitre de l'UE. Cours du **Pr Bordet, le lundi 21/09/2026,
de 8 h à 11 h**, en trois ronéos 2026-27 ; le cours 2024-25 du même professeur
(Ronéosaure, FC n°1) ; les annales de huit sessions, dont les sujets 2023/2024
(QR1) et 2024/2025 déposés le 15/10/2026. Examen : partiel de novembre
(9/11/2026).

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 39 | 39 |
| Texte à trous | 13 | 62 |
| QROC | 15 | 15 |
| Recto-verso | 17 | 17 |
| Lexique | 9 | 9 |
| Schéma cliquable | 2 | 10 |

Dont **21 annales** sur 8 sessions : 10 QCM (2024/2025 S1, 2023/2024, 2021/2022 S2,
2019/2020 S1, 2019/2020 S2, 2018/2019 S1, 2017/2018 S1 ×4), les quatre
sous-questions de la question rédactionnelle 2016/2017 S1, en recto-verso, et les
douze questions de la QR1 2023/2024 du Pr Bordet en sept cartes (cinq
recto-verso, deux QROC) — toutes les rédactionnelles dans `ANNALES_QROC`.

**Les sujets déposés le 15/10/2026.** La QR1 de 2023/2024 (Pr Bordet, le
développement d'un médicament : cible, criblage, repositionnement, affinité,
sélectivité, pléiotropie, activité intrinsèque, essais, variabilité) manquait au
polycopié ; elle est cartée sur son **corrigé officiel** (`officielle=True`),
une carte par question, les questions enchaînées réunies (1-2, 5-8, 11-12) :
`pdg-an-2324-qr1-q1`, `-q3`, `-q4` (QROC), `-q5`, `-q9` (QROC), `-q10`, `-q11`.
Le corrigé suit mot pour mot le cours 2023-24 du Pr Bordet (Charonéo, cité dans
le texte, p. 2-9) ; les ronéos 2026-27 en confirment l'affinité, l'activité
intrinsèque, les trois principes et la variabilité. La session garde le libellé
« 2023/2024 » de la Q.9 et la source du polycopié ; l'explication de chaque carte
dit qu'elle vient du sujet. Le QCM 1 de 2024/2025 (`pdg-an-2425s1-q1`) reprend
2017/2018 S1 Q. 2, « sécurité » devenue « tolérance » : clé CDE déduite du cours.
Le PDF du sujet porte une correction surlignée en bleu, officieuse et d'origine
inconnue (le même surligneur reproduit 37 des 40 clés officielles de 2023-24) :
non déclarée, elle sert de seconde opinion, et donne la même clé, CDE.
Les clés du QCM 2023/2024 (la Q.9 ici, ACE) sont confirmées par la grille
officielle de la faculté (dépôt du 15/10/2026).

Neuf thèmes, dans l'ordre du cours : douleur, affinité (avec la sélectivité et la
pléiotropie), agonistes et antagonistes, puissance, pharmacocinétique,
variabilité, essais cliniques, addiction, balance bénéfice-risque. `douleur`
existe déjà (« Douleur ») ; les huit autres clés sont nouvelles et génériques,
pour les autres FC de BMCT, et leurs libellés restent à ajouter à `THEME_LABELS`
(`app/src/med_engine/application/scopes.py`) :

| Clé | Libellé |
|---|---|
| `affinite` | Affinité, sélectivité, pléiotropie |
| `agonistes` | Agonistes et antagonistes |
| `puissance` | Puissance et relation dose-effet |
| `pharmacocinetique` | Pharmacocinétique |
| `variabilite` | Variabilité de la réponse |
| `essai-clinique` | Essais cliniques |
| `addiction` | Addiction et récompense |
| `benefice-risque` | Balance bénéfice-risque |

## Les sources et leurs années

Méthode de Vincent (28/09) : le Ronéosaure (cours et annales) est la base, le
ronéo de l'année le corrige et l'emporte quand ils divergent ; ce que seul le
cours 2024-25 porte reste en cartes, marquées « Absent du cours 2026-27 ».

| Source | Année | Rôle |
|---|---|---|
| `src-fc-bmct-pd1` — Ronéo & Juliette, « Pharmacodynamie générale 1 » (6 p., la 6 vide) | **2026-27** | partie 1 : douleur, opium, récepteurs opioïdes, affinité, sélectivité, agonistes, antagonistes ; c'est `SRC["fiche"]` |
| `src-fc-bmct-pd2` — « Pharmacodynamie générale 2 » (8 p., la 8 vide) | **2026-27** | partie 2 : plaque chauffante, DL50/DA50/DE50, fentanyl, pharmacocinétique, CYP, phases ; ses **deux figures** (p. 2 et 6) |
| `src-fc-bmct-pd3` — « Pharmacodynamie générale 3 » (4 p.) | **2026-27** | partie 3 : essai de phase III, récompense, addiction, buprénorphine, nalméfène |
| `src-cours-bmct-pd-2425` — Ronéosaure, FC n°1 (17 p.) | 2024-25 | la base de Vincent ; fil rouge l'alcool ; source des 8 cartes absentes et de propositions isolées, dites comme telles |
| `src-annales-bmct-pd` — Ronéosaure, annales (5 p.) | 2024-25 | 7 sessions, table de corrections p. 5 ; reste la source de la session 2023/2024, QR1 comprise |
| `src-sujets-bmct-2425` — Sujets de BMCT 2024/2025, session 1 (20 p.) | 2024-25 | le QCM 1, sujet sans corrigé ; `SRC["sessions"]["2024/2025 S1"]` ; déclaré à l'identique par tous les chapitres de BMCT qui en cartent une question |

Chaque note relue porte sa page (`page`, et `fiche` pour les parties 2 et 3). Lus
en appoint, sans être déclarés : les erratas du Ronéosaure (cours : « distribution »
pour « absorption », p. 13 ; « GABA 1 » pour « GABA A », p. 4 — sans objet en
2026-27 ; annales : rien sur ce polycopié), les annales de pharmacocinétique et de
variabilité (la Q.9 de 2023/2024 y revient, même clé), le cours de
pharmacocinétique du Charonéo 2023-24 (son quizz tranche la Q.9 B), et le cours
de pharmacodynamie générale du Charonéo 2023-24 (Pr Bordet), sur lequel le
corrigé de la QR1 2023/2024 est écrit mot pour mot. Le tableau
des erreurs BMCT de la promo 2026-27, **vide** au 28/09/2026, porte au
**19/10/2026** une entrée sur ce cours : la DA50 et la DE50 (partie 2, p. 2).

Les en-têtes des ronéos portent des noms d'étudiants : aucun n'est repris.

## Ce que le cours a dicté

- **Le même squelette, un autre fil rouge.** 2024-25 partait d'un homme de 45 ans
  dépendant de l'alcool (système dopaminergique, GABA-A et benzodiazépines,
  recherche d'un antagoniste μ) ; 2026-27 part de la douleur et de la morphine.
  Nouveau en 2026-27 : voies de la douleur, opium et alcaloïdes, Ki, classement
  des antagonistes, plaque chauffante, DL50 et NOAEL, fentanyl et oxycodone,
  pharmacologie sociale, EPPH et stratagèmes, codéine et CYP2D6, phases I à III,
  buprénorphine, héroïne. Chiffre qui change : les métaboliseurs normaux du
  CYP2D6, « 90 % » en 2024-25, « 80 % » en 2026-27 (dit dans `pdg-qc-cyp2d6`).
- **Le rouge** des ronéos a chaque fois sa carte : la classification par
  l'activité intrinsèque (partie 1, p. 4 : `pdg-fa-activite-intrinseque`) ;
  « activité intrinsèque et affinité » pour juger de l'efficacité (p. 5 :
  `pdg-rv-affinite-activite`) ; sélection, double aveugle (partie 3, p. 2 :
  `pdg-qc-comparabilite`, `pdg-qr-randomisation`) ; dépendance (p. 3 :
  `pdg-qc-fentanyl-oxycodone`, `pdg-qc-dependance`) ; antagoniste fonctionnel
  (p. 4 : `pdg-qc-agoniste-partiel` B) ; et les titres du plan, qui font les
  thèmes.
- **Le gris.** Aucun des trois ronéos ne définit son gris : c'est la voix des
  rédacteurs, cartée comme le reste (décision de Vincent, 25/09) — les récepteurs
  couplés aux protéines G (partie 1, p. 3 : `pdg-fa-transduction`,
  `pdg-qc-recepteurs-opioides` A), la comparaison des Ki d'un récepteur à l'autre
  (p. 4 : `pdg-qc-affinite` D).
- **Pas de carte** sur la série télévisée citée pour le démarchage (« The
  Resident », partie 2, p. 3 : les séries consacrées à l'OxyContin sont
  « Dopesick » et « Painkiller », point douteux laissé hors cartes), ni sur la
  psychologie du patient qui réclame un médicament pour ne pas le prendre
  (partie 2, p. 7), dite dans `pdg-rv-objet-social`.

## Ce que les annales ont dicté

| Savoir | Questions |
|---|---|
| L'effet pléiotrope (trois fois la même question) | 2021/2022 S2 Q. 2, 2019/2020 S2 Q. 2, 2017/2018 S1 Q. 1, 2023/2024 QR1 q. 8 |
| La balance bénéfice-risque, les effets indésirables | 2018/2019 S1 Q. 16, 2017/2018 S1 Q. 18 |
| La variabilité, la personnalisation | 2019/2020 S1 Q. 2, 2017/2018 S1 Q. 3, 2016/2017 S1 Q2 d, 2023/2024 QR1 q. 11-12 |
| Les principes de l'essai clinique | 2024/2025 S1 Q1, 2017/2018 S1 Q. 2, 2016/2017 S1 Q2 b-c, 2023/2024 QR1 q. 10 |
| Le métabolisme | 2023/2024 Q.9 |
| La molécule pléiotrope, en rupture avec la sélectivité | 2016/2017 S1 Q2 a |
| Du projet au médicament : physiopathologie, approches, criblage, repositionnement, affinité, activité intrinsèque | 2023/2024 QR1 q. 1-9 |

La plupart de ces notions (pléiotropie, personnalisation, déclaration des effets
indésirables) ne sont ni dans les ronéos 2026-27 ni dans le cours 2024-25 : les
annales sont d'années où le cours était autre. Elles restent des annales ; chaque
justification dit d'où vient la réponse (page du cours quand il y en a une,
source sûre sinon). Les annales ne sont jamais listées « absentes ».

## Les erreurs du ronéo 2026-27

Chacune est portée par **ATTENTION** dans la carte qui tient la notion, avec son
genre juste après le mot (C11, 28/09), et elles rangent la carte dans « Pièges
des ronéos » (17 notes, dont le texte à trous des doses 50 depuis le 19/10). À l'examen, on répond d'abord comme le professeur.

| Page | Le ronéo dit | Genre | Retenu | Carte |
|---|---|---|---|---|
| 1, p. 2 | la morphine « extraite du pavot en 1903 » | prise de notes | Sertürner, vers 1804-1805 (AMU ; Mol Interv 2001) | `pdg-qc-opium` C |
| 1, p. 2 | l'opium « extrait de la graine de pavot » | prise de notes | le latex des capsules incisées (AMU) | `pdg-qc-opium` A |
| 1, p. 2 | « la substance P et la CGAP » | prise de notes | le **CGRP** (Collège des enseignants de neurologie) | `pdg-qc-influx` D |
| 1, p. 2 et 4 | cinq sous-types : μ, κ, δ, ε, σ | douteux | μ, δ, κ (+ NOP) ; σ n'est plus opioïde (IUPHAR) | `pdg-qc-recepteurs-opioides` D |
| 1, p. 4 | « Plus le Ki est faible, meilleure est la sélectivité » | prise de notes | Ki faible = affinité ; sélectivité = rapport des Ki | `pdg-qc-affinite` D |
| 1, p. 4 | « Les récepteurs à l'endorphine n'ont pas de réelle sélectivité » | douteux | ce sont les molécules qui ont des actions préférentielles | `pdg-qc-selectivite` C |
| 2, p. 3 | le fentanyl « 100 à 1000 fois plus puissant que la morphine » | **cours** | à l'examen, le chiffre du cours ; la référence : 50 à 100 fois (Sénat, StatPearls, EUDA) | `pdg-qc-fentanyl-oxycodone` A |
| 2, p. 3 | le récepteur « 𝝂 » | prise de notes | le récepteur μ | `pdg-qc-reversibilite` B |
| 2, p. 3 | un « arrêté » de 2011 pour « interdire » le démarchage | douteux | la loi Bertrand (29/12/2011) encadre ; les cadeaux interdits depuis 1993 | `pdg-qc-pharmacologie-sociale` C |
| 2, p. 3 | l'antagoniste « aura une activité endogène » | douteux | il empêche le ligand endogène d'agir (cours 2024-25, p. 8) | `pdg-qc-antagoniste-in-vivo` B |
| 2, p. 4 | « Les opiacés ont une mauvaise biodisponibilité orale (de 8 à 20-30 %) » | douteux | vrai de la morphine (≈ 30 %), pas de l'oxycodone (jusqu'à 87 %) | `pdg-qc-biodisponibilite` E |
| 2, p. 5 | la forme gastro-résistante prolongerait la présence d'un médicament | prise de notes | c'est la libération prolongée ; la gastro-résistance protège (EMA) | `pdg-qc-epph` E |
| 2, p. 5 | Vd des opiacés « 50 L/kg » | prise de notes | morphine 1 à 6 L/kg, fentanyl 3 à 10 L/kg | `pdg-qc-distribution` D |
| 2, p. 6 | ultrarapides « surtout […] scandinave[s] » | prise de notes | Europe du Nord 1-2 %, Méditerranée 7-12 %, Éthiopie 29 % (EMA 2013) | `pdg-qc-cyp2d6` C |
| 2, p. 7 | la codéine « globalement beaucoup transformée en morphine » | prise de notes | 5 à 10 % de la dose (CPIC 2014) | `pdg-qc-codeine` C |
| 2, p. 7 | le « métaboliseur rapide » la transforme massivement : « en tenir compte pour la posologie » | prise de notes | c'est l'ultrarapide, et la codéine lui est contre-indiquée (RCP 4.3) | `pdg-qc-codeine` E |
| 3, p. 3 | l'oxycodone « 100 à 1000 fois plus puissant[e] » | prise de notes | environ 2 fois la morphine (RCP) | `pdg-qc-fentanyl-oxycodone` B |
| 3, p. 4 | le baclofène parmi les antagonistes μ | prise de notes | agoniste GABA-B (RCP Baclocur ; cours 2024-25, p. 12) | `pdg-qc-alcool` D |
| 3, p. 4 | la naltrexone « antidote » du fentanyl | douteux | l'antidote est la naloxone ; la naltrexone maintient l'abstinence (ANSM) | `pdg-qc-traitement-addiction` E |
| 2, p. 2 | la DA50, dose à laquelle on observe « 50 % de l'effet » — **tableau de la promo, 19/10** | douteux | la moitié de l'effet MAXIMAL (intensité) ; la DE50 de la ronéo, la moitié des sujets qui présentent l'effet (fréquence), est juste ; un raccourci plus qu'une erreur, la figure du suivi thérapeutique 2026-27 dit aussi « 50 % de l'effet » et sa définition en rouge « de l'effet maximum » (p. 6) ; Katzung, chap. 2 | `pdg-fa-doses50` |

Sans ATTENTION, parce qu'aucune carte n'en dépend : Paracelse et le laudanum
(p. 3, formule classique ; la teinture safranée est celle de Sydenham), l'héroïne
qualifiée d'héroïque par « l'inventeur » (le nom est la marque de Bayer, 1898 ;
dit dans `pdg-qc-dependance` D), « papaver somnoforum » (Papaver somniferum), deux
« III » dans le plan de la partie 2 et son en-tête « semaine n°2 », le protoxyde
d'azote aux conséquences « cognitives » (l'ANSM décrit surtout des atteintes
neurologiques : `pdg-qr-protoxyde`).

## Les clés qui ne sont pas reprises telles quelles

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2023/2024 Q.9 | ACE | **ACE, officielle** ; ATTENTION sur B, déclaré dans `CONFLITS` | B, « Les métabolites d'un médicament sont le plus souvent inactifs », est donné faux par la clé, et par le quizz du cours de pharmacocinétique 2023-24 (« généralement inactifs : non ») : c'est la réponse du professeur qui pose la question. Mais le cours de pharmacodynamie 2024-25 fait du métabolite inactif « le but du métabolisme » (p. 14), et Pharmacomédicale écrit que les biotransformations donnent « d'une manière générale » des molécules moins actives. À l'examen : faux. |
| 2016/2017 S1 Question n°2 a-d | aucune | réponses déduites du cours, `officielle=False`, explication « Clé déduite du cours, absente de la table de corrections » | le polycopié ne donne aucun corrigé ; a et c portent `a-relire` |
| 2024/2025 S1 Q1 (`pdg-an-2425s1-q1`) | aucune (sujet sans corrigé) | **CDE**, `officielle=False` | comparaison, comparabilité, significativité : « trois principes à réaliser systématiquement » (ronéo 2026-27, partie 3, p. 2) ; la tolérance est l'objet de la phase I, l'efficacité ce que l'essai évalue (partie 2, p. 7) |

Les autres clés sont reprises telles quelles ; la QR1 2023/2024 suit son corrigé
officiel, que le cours ne contredit nulle part. Le corrigé appuie aussi la
sous-question a de 2016/2017 S1 (« effet pléiotrope ») : le Charonéo 2023-24
(p. 6) y écrit la rupture avec le modèle sélectif des années 1960-1970 — de quoi
retirer `a-relire` de `pdg-an-1617s1-q2a` à la prochaine relecture. 2017/2018 S1 Q. 3 (D et E faux :
l'analyse individu par individu, la perception du patient) repose sur la seule
clé imprimée, la notion n'étant dans aucun des cours disponibles.

Cas ouverts : la Q.9 B (reprise comme la clé), et le fentanyl « 100 à 1000 fois »,
reconnu comme juste pour l'examen.

## Absent du cours 2026-27

Huit cartes n'ont **pas de version 2026-27** et le disent en tête de leur
explication ; elles citent la FC n°1 2024-25 à sa page (`fiche` =
`src-cours-bmct-pd-2425`) :

| Carte | Ce que le ronéo 2026-27 ne dit plus | Page 2024-25 |
|---|---|---|
| `pdg-rv-prescrire` | prescrire, ne pas prescrire, déprescrire | p. 2 |
| `pdg-rv-alcool-etude` | les enquêtes lilloise et nationale sur l'alcool des étudiants | p. 2-3 |
| `pdg-qc-gaba-bzd` | le GABA-A, les benzodiazépines et la dépendance | p. 4 |
| `pdg-qc-bhe` | la barrière hémato-encéphalique, la résorption passive ou active | p. 13 |
| `pdg-fa-demi-vie` | les 5 demi-vies, diazépam et nordazépam | p. 14 |
| `pdg-rv-critere-jugement` | l'objectif qui fixe le nombre de sujets | p. 15 |
| `pdg-qr-loi-1988` | le consentement depuis la loi de 1988 | p. 17 |
| `pdg-qr-metrologie` | la métrologie, science des critères de jugement | p. 17 |

Propositions isolées de 2024-25, dites comme telles dans leur justification :
l'agoniste partiel modulateur, ses 90 % et ses 10 % (`pdg-qc-agoniste-partiel`
D-E), le Vd faible et la liaison à l'albumine, le risque d'effets indésirables
d'une large distribution (`pdg-qc-distribution` C, E), le μ sur l'interneurone
GABA (`pdg-qc-recompense` E, `pdg-zo-recompense`), le baclofène agoniste GABA-B
(`pdg-qc-alcool` E).

## Les schémas et les figures

**Deux figures du ronéo 2026-27**, extraites en PNG (partie 2) : la courbe de la
DL50 (p. 2, `dl50-courbe.png`) et les deux courbes de distribution du CYP2D6 et du
CYP3A4, réunies côte à côte (p. 6, `cyp-distributions.png`). Les autres pages
n'ont que des bandeaux.

**Deux schémas cliquables** (`schemas.py`), chacun avec sa version légendée en
correction :

| Fichier | Ce qu'on clique | Pourquoi ce dessin |
|---|---|---|
| `voies-douleur.svg` | périphérie, corne postérieure, substance blanche de la moelle, tronc cérébral, thalamus, cortex (6 zones) | le trajet de la partie 1 (p. 2) ; la moelle en coupe, côté dorsal tourné vers la peau ; une seule corne postérieure pleine, l'autre estompée ; cortex et substance blanche en anneaux (`geometry.annulus`) |
| `circuit-recompense.svg` | les récepteurs μ, κ, D3, GABA-A (4 zones) | partie 3 (p. 3) et figure 1 du cours 2024-25 (p. 5) ; neurones et régions nommés, récepteurs non : les situer est la question |

**Cinq figures redessinées** pour les corrections : `activite-intrinseque.svg`,
`antagonismes.svg`, `da50-de50.svg`, `voies-administration.svg`,
`essai-parallele-croise.svg`. **23 QCM sur 39 illustrés (59 %)**, 39 notes sur 95
(le QCM 2024/2025 et trois cartes de la QR1 2023/2024 reprennent l'essai
parallèle et croisé, l'activité intrinsèque et les distributions du CYP).
Les QCM sans figure (opium, affinité, sélectivité, distribution, BHE, phases,
fentanyl, pharmacologie sociale, dépendance, et sept annales) n'ont rien à montrer
que le texte ne dise.

## Le lexique

Neuf termes, les concepts du cours et des annales, chacun avec son **origine
grecque ou latine** ; pages mesurées dans le texte des trois ronéos 2026-27 (les
en-têtes, qui répètent « Pharmacodynamie générale », ne comptent pas) :

| Terme | Origine | Pages (partie, page) |
|---|---|---|
| Pharmacodynamie | grec phármakon + dúnamis | 1 p. 1 ; 2 p. 1, 3 ; 3 p. 1 |
| Pharmacocinétique | grec phármakon + kinētikós | 2 p. 1, 4, 7 |
| Agoniste | grec agōnistḗs, par le latin | 1 p. 4-5 ; 3 p. 4 |
| Antagoniste | grec antagōnistḗs, par le latin | 1 p. 4-5 ; 2 p. 3 ; 3 p. 4 |
| Biodisponibilité | grec bíos + latin disponibilis | 2 p. 1, 4 |
| Endorphine | grec éndon + Morpheús | 1 p. 2-4 ; 3 p. 3-4 |
| Opioïde | grec ópion + eîdos | 1 p. 4 ; 2 p. 1, 3, 4 ; 3 p. 1, 4 |
| Placebo | latin placebo, « je plairai » | 2 p. 3 ; 3 p. 2-3 |
| Pléiotrope | grec pleíōn + trópos | aucune : le mot n'est que dans les annales (trois questions) |

Quatre racines sont enseignées par la FC de sémantique et la citent : `kinési-`
(1/2, p. 2), `endo-` (1/2, p. 2), `bi(o)-` (1/2, p. 7), `-trope` (2/2, p. 4). Les
autres (pharmac(o)-, -dynamie, agôn, disponibilis, Morpheus, opium, -oïde,
placere, pléio-) sont « hors FC ». Les étymologies nouvelles sont proposées à la
table commune (`etymologies.json`), que Claude fusionne ; les textes du lexique
sont déjà écrits dans la forme que `appliquer_etymologies.py` produirait.

## Décisions prises en route

- **`EXAMENS` n'est pas déclaré.** L'import réécrit la portée d'une session
  d'examen (`save_exam_session`) : déclarer ici `exam-nov-2026` avec ce seul
  chapitre retirerait de la portée ceux qui y sont déjà (la sémiologie
  cardiovasculaire la déclare). Le partiel du 9/11 se règle dans l'application.
- **Deux inexactitudes du cours 2024-25**, redressées dans l'explication sans
  ATTENTION (ce n'est pas le ronéo de l'année) : μ et κ ne différeraient « que de
  quelques acides aminés » (p. 7) — les trois récepteurs opioïdes partagent environ
  60 % de leur séquence (Kieffer et Evans, Neuropharmacology 2009 ;
  `pdg-qc-selectivite`) ; « 97,5 % » éliminés après 5 demi-vies (p. 14) — le calcul
  donne 96,9 % (`pdg-fa-demi-vie`).
- La Q.9 de 2023/2024 est aussi dans les polycopiés de pharmacocinétique et de
  variabilité : un futur chapitre qui la reprendrait doit réutiliser
  `pdg-an-2324-q9` ou la laisser ici, pour ne pas la compter deux fois.

## À relire

**2 cartes `a-relire`** : `pdg-an-1617s1-q2a` (la qualité recherchée — effet
pléiotrope, profil d'affinités, rupture avec la sélectivité des années 1960-1980 —
n'est écrite dans aucun cours disponible) et `pdg-an-1617s1-q2c` (les critères
intermédiaires, biologiques et d'imagerie, sont une déduction). Toutes les autres
notes citent une page du ronéo 2026-27 ou du cours 2024-25 (la QR1 2023/2024,
aussi le Charonéo 2023-24). Pour la première, la rupture avec la sélectivité est
désormais écrite (Charonéo 2023-24, p. 6) et le corrigé officiel de la QR1
2023/2024 nomme l'effet pléiotrope : le tag peut tomber à la relecture. Aucune
carte nouvelle n'est `a-relire`. Reste à Vincent :

- les huit cartes « Absent du cours 2026-27 » : les garder ?
- le fentanyl « 100 à 1000 fois » : reconnu juste pour l'examen, référence 50 à
  100 ; si une diapositive du Pr Bordet dit autre chose, la carte change de genre.
- le tableau des erreurs BMCT 2026-27 ne relève, sur ce cours, que la DA50 et la
  DE50 (19/10) : y signaler les erreurs prouvées ci-dessus ?

## L'échelle : Simple → Moyen → Annale (C20, 16/10/2026)

L'échelle du pilote de l'immunité innée, étendue à la BMCT pour l'examen du 4/11 (Vincent, 16/10 : « on continue pour les chapitres que je vais avoir à l'examen »). Sous les annales, 30 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 6 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`) ; les QROC reçoivent le schéma nu.

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `affinite` | 9 | 1 | 8 |
| `agonistes` | 1 | 1 | 1 |
| `pharmacocinetique` | 4 | 1 | 1 |
| `variabilite` | 7 | 1 | 4 |
| `essai-clinique` | 5 | 1 | 5 |
| `benefice-risque` | 4 | 1 | 2 |

**Le schéma** `ech-pharmacodynamie`, « Pharmacodynamie générale · de la molécule au patient », donne 47 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_PHARMACODYNAMIE`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Deux désaccords entre chapitres, dits dans les cartes** : le génotype du CYP2D6 (pdg-ech-s14 C, m4 B) et le CYP3A4 (pdg-ech-s15 A, m3 B) ne s'écrivent pas pareil ici et dans la variabilité ; un ATTENTION le dit.

**Sans marche** :
- pdg-an-1920s1-q2 A (la comorbidité) : ni la ronéo 2026-27 ni le cours 2024-25 n'en parlent ; la lettre est posée sur « Chaque patient ».
- pdg-an-1819s1-q16 B, C, D, E (l'effet indésirable non grave, ses conditions de survenue, la déclaration de tout effet indésirable, l'information du patient sur les risques) : pharmacovigilance, absente des deux cours (la justification de D cite l'ANSM) ; « ne pas prescrire, et savoir l'expliquer au patient » (cours 2024-25, p. 2) frôle E sans le dire. Lettres posées sur la balance (B, C, D) et sur « Chaque patient » (E).
- pdg-an-1718s1-q3 B (le nombre de sujets à traiter) : absent des deux cours, et à ne pas confondre avec le nombre de sujets nécessaires que fixe l'objectif (cours 2024-25, p. 15) ; lettre posée sur le critère de jugement.
- pdg-an-2324-q9 E, en partie : pdg-ech-s15 prépare l'effet des inductions médicamenteuses sur le métabolisme (ronéo 2026-27, partie 2, p. 6) ; « de composés endogènes » n'est que dans le cours de pharmacocinétique du Charonéo 2023-24, non déclaré.
- pdg-an-2324-q9 D, en partie : pdg-ech-s16 prépare l'état physiologique (l'âge, cours 2024-25, p. 2) ; l'état pathologique n'est écrit dans aucun des deux cours.
- pdg-an-2122s2-q2 D, pdg-an-1920s2-q2 C, pdg-an-1718s1-q1 E (l'AMM) : pas de carte Simple, aucune case ne pouvant le dire sans trahir un trou ; seulement la proposition B de pdg-ech-m1 (les Ki comparés d'un récepteur à l'autre dès la sélection, partie 1, p. 4, passage gris). Lettres posées sur « Avant la phase III ».
- QROC pdg-an-2324-qr1-q1 (la physiopathologie, les trois approches) et pdg-an-2324-qr1-q4 (le repositionnement) : Charonéo 2023-24 seul, non déclaré ; ni marche ni schéma.
- QROC pdg-an-1617s1-q2b, en partie : le choix d'un essai parallèle plutôt que croisé (plasticité cérébrale, partie 3, p. 2) n'a pas de marche, faute de place sur le schéma ; pdg-qc-comparaison le travaille déjà.

## Régénérer

```powershell
..\..\..\app\.venv\Scripts\python.exe generer.py
```
