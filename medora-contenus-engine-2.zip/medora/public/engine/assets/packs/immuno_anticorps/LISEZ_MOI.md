# Mode d'action des anticorps — paquet Immunologie

71 notes, 119 cartes. Chapitre `chap-ue-immunologie-fc10` de l'UE Immunologie.
Cours du **Dr A. Collet, le 20/10/2025**, « Modes d'action des anticorps »
(FC n°10 du Ronéosaure 2025-26, 15 pages) ; annales des polycopiés IMMUNO n°10
et n°8 du Ronéosaure 2024-25 (13 questions, 9 sessions). Examen de novembre
(4 novembre 2026).

**Une fiche provisoire.** Le ronéo 2026-27 de ce cours n'est pas paru au
02/10/2026 : le chapitre est carté sur le Ronéosaure 2025-26 (tâche C14,
décision de Vincent du 02/10), et le ronéo de l'année corrigera les cartes à
sa parution. La source porte son année dans son auteur (« Ronéosaure
2025-26 ») : chaque carte de cours prend le tag `cours-2025-26`, et l'écran
montre « Cours 2025-26 ». Aucune carte ne dit « Absent du cours 2026-27 », et
les erreurs du Ronéosaure sont dites par un ATTENTION sans genre (précédent
d'`immuno_cmh`) : la liste des erreurs de la promo,
`contenu/ERRATA_RONEOS_2026-27.md`, ne concerne que les ronéos 2026-27.

## Le ronéo 2026-27 de l'activation des LB (relu le 19/10/2026)

Le ronéo 2026-27 du cours du Pr Dubucquoi du 09/10/2026, « Ontogenèse des lymphocytes B
et mise en place d'une réponse immunitaire anticorps dépendante » (12 p., déposé le
19/10), est la fiche d'`immuno_activation_b`. Il a été relu pour ce chapitre, parce que
ses pages 10-11 en recoupent deux parties :

| Pages 2026-27 | Ce qu'il dit | Cartes de ce chapitre |
|---|---|---|
| 10-11 | les fonctions des classes, « à connaître » : IgM pentamériques à dix sites, premières produites, peu affines, polyréactives, voie classique ; IgG après commutation, favorisées par le LTfh, nombreuses interactions par les FcγR (macrophages, polynucléaires, NK), complément ; IgA des muqueuses, résistantes aux protéases bactériennes ; le tableau des classes, le même qu'en FC n°6 2025-26 | `anc-qc-igm`, `anc-qc-igg-iga` : confirmées, dit dans leur explication |
| 10 | la toxoplasmose chez la femme enceinte : IgM, infection récente ; IgM et IgG, contrôle 4 semaines plus tard ; taux d'IgG stable, infection ancienne, qui augmente, pathogène présent | `anc-qc-toxoplasmose` : confirmée, dit dans son explication |

**La base ne change pas.** Le cours des modes d'action des anticorps (Dr Collet, FC n°10,
20/10/2025) n'a pas encore de ronéo 2026-27 : le chapitre reste carté sur la FC n°10
2025-26, ses cartes gardent le badge « Cours 2025-26 », et aucune ne cite ce ronéo à sa
page — il n'est pas déclaré ici. Rien n'y contredit une clé. Son erreur sur les IgA,
qui signeraient une toxoplasmose « ancienne » (p. 10), est portée avec son genre par
`alb-qc-serologie`, au chapitre de l'activation, où la notion se joue ; l'explication
d'`anc-qc-toxoplasmose` la signale sans ATTENTION.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 27 | 27 |
| QRU | 1 | 1 |
| Texte à trous | 11 | 54 |
| QROC | 8 | 8 |
| Recto-verso | 13 | 13 |
| Schéma cliquable | 1 | 6 |
| Planche à légender | 1 | 1 |
| Lexique | 9 | 9 |

Dont **13 annales** : 8 QCM (QRM) et 5 QROC (recto-verso), sur 9 sessions, de
2015/2016 S2 à 2023/2024 S1. Les 20 QCM du cours ont une justification par
proposition, comme les annales.

Six thèmes, dans l'ordre du cours :

| Clé | Libellé |
|---|---|
| `modes-action-ac` | Modes d'action des anticorps |
| `fonctions-isotypes` | Fonctions des classes d'anticorps |
| `ac-en-pratique` | Anticorps en pratique : thérapeutique et sérologie |
| `rate` | La rate (celui d'`immuno_organes`, même libellé) |
| `antigenes-reconnus` | Antigènes thymo-dépendants et thymo-indépendants |
| `affinite-avidite` | Affinité, avidité ; réponses poly- et monoclonales |

Les cinq nouveaux libellés sont à ajouter à `THEME_LABELS`
(`app/src/med_engine/application/scopes.py`), bloc « immunologie » ; le test
`test_tout_theme_du_paquet_a_son_libelle` échoue pour ce chapitre tant qu'ils
n'y sont pas. La clé `affinite` (« Affinité, sélectivité, pléiotropie », BMCT)
n'est pas réemployée.

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-immuno-anticorps` — Ronéosaure, « FC n°10 mode d_actions des anticorps » (15 p.), `IMMUNOLOGIE/…` | **2025-26** | **la base** : chaque note du cours porte sa page ; c'est ce que le lecteur ouvre (`chapitre=`) |
| `src-annales-immuno-n10-modification-de-structure-de-bcr` — Ronéosaure, « IMMUNO n°10- Modification de structure de BCR » (10 p.) | 2024-25 | 11 questions et leur table de corrections (p. 7-10) |
| `src-annales-immuno-activation-b` — Ronéosaure, « IMMUNO n°8- Activation et différenciation des cellules B par l'antigène » (13 p.) | 2024-25 | la session 2017/2018 S2 (Q8, QROC 5) ; déclaration recopiée à l'identique d'`immuno_activation_b` |
| `src-cours-immuno-anticorps-2425` — Ronéosaure, FC n°10 (AC), Pr Dubucquoi (19 p.) | 2024-25 | appoint, cité dans le texte des cartes : demi-vies des IgM et des IgG (p. 10), IgA et protéases (p. 6), vaccins conjugués (p. 12-13), rate (p. 13-16), complexes immuns et épitopes linéaires (p. 16-17), affinité (p. 18) |
| FC n°4, n°6, n°7 2025-26 | 2025-26 | citées dans le texte, à la page, sans être déclarées : ce sont les fiches d'autres chapitres |
| errata de l'UE (`Erratas Immuno.docx`) | 2025-26 | quatre entrées sur la FC n°10, aucune reportée dans le PDF : toutes portées (ci-dessous) |

La déclaration d'IMMUNO n°10 suit la forme commune demandée pour les chapitres
écrits en parallèle (identifiant tiré du nom du fichier, cinq champs) : un
autre chapitre qui la cite doit la recopier à l'identique.

Vérifications hors du cours, citées dans la carte qui s'en sert : Vidarsson
et al., *IgG subclasses and allotypes*, Front Immunol 2014 (isotypes et
complément) ; OpenStax Microbiology 20.2 (réseaux de complexes immuns) ;
O'Connell et al., *Understanding and interpreting serum protein
electrophoresis*, Am Fam Physician 2005, et WikiLectures (principe de
l'électrophorèse, tampon à pH 8,6) ; code de la santé publique, art.
R. 2122-2, et La Revue du praticien (sérologie de toxoplasmose obligatoire au
premier examen prénatal) ; l'étymologie (TLFi, Gaffiot, Bailly,
Wiktionnaire).

## Ce que le cours a dicté

- **Deux parties « pas à savoir »** : les rôles de la rate pour les LB (II.B,
  p. 11) et l'asplénie (II.C, p. 11-12). Leurs textes à trous
  (`anc-fa-rate-roles`, `anc-fa-asplenie`) portent le tag `edn`. L'annale
  2021/2022 S1 QROC 1, qui demande les cinq rôles de la rate, reste, sans
  `edn`, et le dit. La structure de la rate (pulpes, splénectomie, bactéries
  encapsulées) est au chapitre `immuno_organes` : seule la zone marginale est
  cartée ici.
- **Le rouge** a sa carte : opsonisation, phagocytose, cytotoxicité (p. 5-6),
  les « adjuvants de mécanismes non spécifiques » (`anc-qc-adjuvants` A),
  la faible spécificité et la poly-réactivité des IgM (`anc-qc-igm`), la
  distribution des IgA dans les muqueuses (`anc-qc-igg-iga`), le recyclage
  par le FcRn et la transcytose des IgA (`anc-fa-fcrn`, `anc-fa-pigr`,
  `anc-qc-fcrn`), l'antigène, l'épitope, l'affinité et l'avidité
  (`anc-qc-polyclonal`, `anc-qr-epitope`, `anc-fa-affinite`,
  `anc-qc-affinite-avidite`). Pas de gris.
- **Les questions de révision de la professeure** (tableau p. 10) ont leurs
  cartes : à quoi servent le Fab et le Fc (`anc-rv-fab-fc`), quatre fonctions
  des anticorps (QROC d'annales), les récepteurs qui amplifient ou freinent
  (`anc-rv-itam-itim`), la seule Ig qui passe le placenta (`anc-qu-placenta`).
- **Ce qui appartient à d'autres chapitres n'est pas carté** (plan C14) : la
  structure de l'Ig, Fab et Fc, et les valences (FC n°4 : `anc-qc-fab-fc` et
  `anc-rv-fab-fc` ne demandent que par quel fragment passe chaque mode
  d'action ; le nombre de paratopes, rappelé dans l'avidité, n'est pas un
  trou), le BCR bivalent et le TCR monovalent (FC n°5), la courbe des réponses primaire et secondaire (FC n°6 ; la
  diapositive p. 8 n'illustre ici que les isotypes et la toxoplasmose), la
  cascade du complément, la phagocytose et les NK (FC n°7 : ici, CDC, ADCC et
  FcγR vus depuis l'anticorps), le CD20 comme marqueur des LB (FC n°4 : ici,
  les mécanismes du rituximab).
- **La diapositive du nirsevimab (p. 4) n'est pas reprise** : elle montre une
  boîte commerciale. Les deux cartes du VRS sont illustrées par la
  neutralisation du SARS-CoV-2, le même mécanisme (p. 3).

## Les erreurs du Ronéosaure 2025-26

Chacune est dite par **ATTENTION**, sans genre, dans la carte qui porte la
notion.

| Page | Ce que dit le Ronéosaure | Ce qui est juste | Carte | Origine |
|---|---|---|---|---|
| 2 | « Les lymphocytes B de la zone marginale = voie du centre germinatif » | les LB folliculaires empruntent la voie extra-folliculaire ou celle du centre germinatif ; les MZB, dans la rate, s'activent sans LTFH | `anc-qc-zone-marginale` D | errata de l'UE (« p. 2 ») |
| 8 | les IgA de la réponse secondaire interagissent avec des « récepteurs FcγR » | FcαR (CD89) | `anc-qc-igg-iga` E | errata de l'UE (« p. 6 ») |
| 9 | « Non : ce sont des IgM, c'est une infection ancienne » | des IgG | `anc-qc-toxoplasmose` D, `anc-rv-toxoplasmose` | errata de l'UE (« p. 7 ») |
| 8 | la sérologie de toxoplasmose « obligatoire avant la grossesse » | recommandée avant ; obligatoire au premier examen prénatal (1er trimestre), puis chaque mois chez la femme non immunisée (code de la santé publique, art. R. 2122-2 ; certificat prénuptial supprimé en 2008) | `anc-fa-toxoplasmose` (explication ; la formule n'est pas un trou) | relecture |
| 12 | « pas de collaboration avec le LT polynucléaire » | le LTFH | `anc-qc-antigenes` E | errata de l'UE (« p. 10 ») |
| 14 | l'électrophorèse sépare les protéines « en fonction de la taille », les petites migrant le plus, « à droite du schéma » | selon la charge électrique nette, et aussi la taille et la forme (O'Connell et al., Am Fam Physician 2005), au pH alcalin du tampon (8,6) ; l'albumine, qui migre le plus loin vers l'anode, est à gauche de la diapositive ; l'α2-macroglobuline, énorme, migre plus loin que les IgG | `anc-qc-electrophorese` A, zone de l'albumine | relecture |
| 13 | une réponse polyclonale vient de « clones cellulaires (lymphocytes) différents avec des TCR différents » | des LB, avec des BCR différents (la ligne précédente le dit) | `anc-qc-polyclonal` C | relecture |
| 14 | l'avidité, « somme des affinités entre un épitope et un paratope » | la somme des affinités de tous les couples épitope-paratope engagés ; le résumé p. 15 dit juste | `anc-fa-affinite`, `anc-qc-affinite-avidite` | relecture |
| 2-3 | « Fragment “Antibody” = “Fab” », diapositive comprise | Fab : fragment antigen-binding (déjà signalé par `immuno_ontogenese_b`) | `anc-qc-fab-fc` A | relecture |

**Point douteux**, dit dans `anc-qc-zone-marginale` : la pulpe rouge et la zone
marginale filtreraient « le sang issu du tube digestif » (p. 10-11), comme le
disait le cours 2024-25 (p. 13). La rate reçoit le sang de l'artère splénique
et son sang veineux rejoint la veine porte ; ce sont les antigènes
intestinaux passés dans la circulation qu'elle filtre (`immuno_organes` le
dit ainsi). Aucune carte ne cote la formule.

Sans ATTENTION, parce qu'aucune réponse n'en dépend : « D. Mode d'action 2 »
pour le 4e mode dans le plan (p. 1) ; les Ig « endocytés par phagocytose »
(p. 9 : la diapositive dit pinocytose, dit dans `anc-qc-fcrn`) ; « préparés
par la cellule du CMH » (p. 12) ; « tIssus » (p. 11).

**Deux FC 2025-26 qui ne disent pas la même chose** : les isotypes qui activent
le complément — « IgM et IgG3 » ici (p. 7, texte ; le tableau de la même
diapositive cote aussi IgG1 ++ et IgG2 +), « IgM et IgG1, IgG2, IgG3 » dans
la FC n°7 (p. 6). Les cartes ne cotent que ce que les deux disent : les IgM et
l'IgG3 en tête (`anc-qc-isotypes` E, `anc-qc-cdc` D), l'IgG4 nulle
(`anc-fa-isotypes`), et le disent. La référence : IgG3 > IgG1 > IgG2, IgG4
nulle.

## Ce que les annales ont dicté

| Savoir | Questions |
|---|---|
| Les modes d'action et les partenaires des anticorps | 2023/2024 S1 QROC4, 2020/2021 S2 QROC4, 2016/2017 S1 QROC2, 2017/2018 S2 QROC 5 |
| Les fonctions des IgG | 2022/2023 S1 Q6, 2021/2022 S1 Q7 |
| L'interaction antigène-anticorps, l'affinité, l'avidité | 2018/2019 S1 Q9, 2015/2016 S2 Q1 |
| La réponse polyclonale | 2020/2021 S2 Q5 |
| Ce que reconnaît le LB, son BCR | 2017/2018 S2 Q8, 2016/2017 S1 Q2 |
| La rate et ses MZB | 2018/2019 S2 Q9, 2021/2022 S1 QROC 1 |

Les autres questions d'IMMUNO n°10 sont dans le chapitre de leur sujet
(docstring d'`annales.py`) : structure des Ig et ontogenèse B dans
`immuno_ontogenese_b`, aide cognate et centre germinatif dans
`immuno_activation_b`, bactéries extracellulaires dans `immuno_infectieux`,
lymphopoïèse B déjà dans `immuno_temporelle`.

| Poly | Session | N° | Clé imprimée | Sujet | Carte |
|---|---|---|---|---|---|
| n°10 (= n°4, n°7) | 2022/2023 S1 | Q6 | ABCD | fonctions des IgG | `anc-an-2223s1-q6` |
| n°10 (= n°4, n°8) | 2021/2022 S1 | Q7 | BD | IgG | `anc-an-2122s1-q7` |
| n°10 | 2023/2024 S1 | QROC4 | corrigé imprimé | effecteurs des Ac contre bactérie et toxine | `anc-an-2324s1-qroc4` |
| n°10 | 2021/2022 S1 | QROC 1 | corrigé imprimé | 3 des 5 fonctions de la rate | `anc-an-2122s1-qroc1` |
| n°10 | 2020/2021 S2 | Q5 | E | réponse polyclonale | `anc-an-2021s2-q5` |
| n°10 (= n°8) | 2020/2021 S2 | QROC4 | corrigé imprimé | Ac et pathogènes | `anc-an-2021s2-qroc4` |
| n°10 (= n°8) | 2018/2019 S1 | Q9 | BD | interaction Ag-Ac | `anc-an-1819s1-q9` |
| n°10 | 2018/2019 S2 | Q9 | CDE | LB de la zone marginale | `anc-an-1819s2-q9` |
| n°10 (= n°8) | 2016/2017 S1 | Q2 | ABCD | les LB | `anc-an-1617s1-q2` |
| n°10 | 2016/2017 S1 | QROC2 | corrigé imprimé | grandes fonctions des Ac, partenaires des IgG | `anc-an-1617s1-qroc2` |
| n°10 | 2015/2016 S2 | Q1 | BCE | interaction Ag-Ac | `anc-an-1516s2-q1` |
| n°8 | 2017/2018 S2 | Q8 | ABE | BCR et épitopes | `anc-an-1718s2-q8` |
| n°8 / n°7 | 2017/2018 S2 | QROC 5 | aucun (« pas de correction » / « voir cours ») | IgG et effecteurs de l'innée | `anc-an-1718s2-qroc5` |

**Le corrigé officiel des QROC 2023/2024 (dépôt du 15/10/2026)** : le verso de
`anc-an-2324s1-qroc4` (les mécanismes effecteurs des anticorps contre une
bactérie ou une toxine) a été comparé au corrigé officiel de la faculté. Il en
porte chaque élément — neutralisation directe, opsonophagocytose par les FcγR,
activation des NK et ADCC, activation du complément (CDC) — : rien à compléter ;
la carte était déjà `officielle`. Aucune question du sujet 2024/2025 ne relève
de ce chapitre.

## Le schéma cliquable et la planche

| Fichier | Ce qu'on clique | Cartes |
|---|---|---|
| `electrophorese-nue.svg` (`anc-zo-electrophorese`) | l'albumine, les α1, α2, β-globulines, le dôme polyclonal des γ, le pic monoclonal | 6 |

Les deux tracés de la diapositive p. 14, redessinés sans légende : en haut un
sérum normal, en bas celui d'une hémopathie. Le tracé du bas est estompé sauf
dans la zone γ : une zone se pose là où un seul tracé passe, et l'albumine du
bas ne fait perdre aucun point. La version légendée, `electrophorese.svg`,
tirée des mêmes constantes, est en correction ; elle dessine le vrai sens de
migration, vers l'anode, que la flèche de la diapositive met à l'envers.

**La planche** `anc-pl-fcrn-pigr` : la diapositive « Transport et recyclage des
immunoglobulines » (p. 9), légendes effacées par
`scripts/planche_depuis_image.py` — quatorze numéros (IgG, IgA ou IgM,
fixation au FcRn, pinocytose, endosome tardif, lysosome, transcytose ou
recyclage, cellule endothéliale, pIgR, IgA dimérique, plasmocyte à IgA,
cellule épithéliale, lumière intestinale, IgA sécrétoire), cinq intrus (FcγR,
phagolysosome, macrophage, IgE, cellule dendritique folliculaire). Les titres,
les en-têtes des trois vignettes et les pieds de la diapositive sont effacés
avec le numéro voisin : ils nommaient le FcRn, le pIgR, les IgG et les IgA.
L'image numérotée et l'aperçu de contrôle ont été relus ; les restes du titre
gauche, du lysosome, du pied gauche et du pied droit ont été repris, et la
légende de la cellule épithéliale remesurée.

**Illustrations** : 28 QCM sur 28 (100 %) portent une diapositive de la fiche
ou l'électrophorèse légendée en correction ; 61 notes sur 71. Dix-huit
diapositives de la fiche sont extraites en PNG (1 100 px de large au plus, 256
couleurs).

## Les clés qui ne sont pas reprises telles quelles

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2017/2018 S2 QROC 5 (IgG et effecteurs de l'innée) | aucune : IMMUNO n°8 « pas de correction », IMMUNO n°7 « voir cours » | clé déduite de la FC n°10 2025-26 (p. 4-6, 10) | non marquée officielle |

Les huit QCM gardent leur clé imprimée : aucune ne contredit le cours, et
`CONFLITS` est vide. Reprises avec une nuance dans la carte : **2015/2016 S2
Q1 C** (les IgA circulantes « jusqu'à quatre paratopes » : vrai pour le
dimère, alors que l'IgA du sang est surtout monomérique) ; **2020/2021 S2 Q5
E** (la réponse polyclonale « facilite la formation d'immuns complexes » :
vrai, mais le cours 2025-26 ne le dit pas ; justifié par la littérature) ;
**2018/2019 S1 Q9 C** (la commutation change l'avidité par la valence, pas
l'affinité du paratope) ; **2021/2022 S1 QROC 1** (les fonctions de la rate,
« pas à savoir » cette année).

Cas ouvert : aucun.

## Le lexique

Neuf termes, aux pages mesurées dans la fiche 2025-26
(`scripts/chercher_pages.py`, mot entier, et une normalisation NFKD pour
« affinité », que le PDF écrit avec la ligature « ffi ») : épitope (p. 12-15),
affinité (1, 7-9, 11, 13-15), avidité (1, 9, 14, 15), neutralisation (1-3, 7,
10 ; la p. 6 n'écrit que « neutraliser »), monoclonal (1, 7, 13, 14, avec
« monoclonale » et « monoclonaux »), polyclonal (1, 13, 14, sous la forme
« polyclonale »), électrophorèse (13, 14), transcytose (9), asplénie (11, où
le ronéo écrit « asplénisme »). Chacun dit
son origine grecque ou latine.

Les étymologies nouvelles — quatre racines (`affinis (latin)`,
`avidus (latin)`, `électr(o)-`, `-phorèse`) et les neuf termes — sont
**proposées** dans `scratchpad/etym/immuno_anticorps.json`, avec leurs
sources ; la table `etymologies.json` n'est pas modifiée par ce chapitre. Les
définitions et les racines disent déjà, mot pour mot, ce
qu'`appliquer_etymologies.py` en écrira. Les racines réemployées gardent la
clé de la table : `épi-`, `-tope`, `mono-`, `poly-`, `clon- (grec)`,
`neutr(o)-`, `trans- (latin)`, `cyt(o)- / -cyte`, `-ose`, `a-/an-`,
`splén(o)-`.

## Questions pour Vincent

1. **Les isotypes qui activent le complément.** La Dr Collet (FC n°10, p. 7)
   dit « IgM et IgG3 », le Pr Lefèvre (FC n°7, p. 6) « IgM et IgG1, IgG2,
   IgG3 ». Proposition appliquée : les cartes ne cotent que ce que les deux
   disent (IgM et IgG3 en tête, IgG4 nulle) et signalent l'écart ; à
   l'examen, une proposition « l'IgG1 active le complément » serait vraie
   pour la FC n°7 et le tableau de la FC n°10. À trancher à la parution du
   ronéo 2026-27, ou sur le quizz de la professeure s'il y en a un.
2. **Le squelette du Ronéosaure** nomme `chap-ue-immunologie-fc10`
   « Ontogénèse des lymphocytes B » (programme 2024-25) ; ce chapitre réemploie
   l'identifiant pour « Mode d'action des anticorps », comme le veut le plan
   C14. L'import renommera le chapitre vide chez les collègues : mettre le
   squelette à jour ?
3. **Les parties « pas à savoir »** (rôles de la rate, asplénie) : cartées avec
   le tag `edn`, l'annale 2021/2022 S1 QROC 1 gardée sans `edn` (proposition
   du plan). Faut-il aussi la ranger en `edn`, puisque le cours de l'année ne
   l'enseigne plus ?

4. **Les cartes que le ronéo 2026-27 de l'activation confirme** (`anc-qc-igm`,
   `anc-qc-igg-iga`, `anc-qc-toxoplasmose`) gardent leur page de la FC n°10 2025-26 et
   le badge « Cours 2025-26 », en attendant le ronéo des modes d'action. Préfères-tu
   qu'elles citent dès maintenant le ronéo du 09/10 (p. 10-11), qui les porte en partie ?

## Sans illustration

Sans objet : tous les QCM sont illustrés.

## À relire

Aucune carte `a-relire` : chaque carte de cours porte sa page dans la fiche
2025-26, chaque annale sa clé imprimée ou déduite et dite. À la parution du
ronéo 2026-27 de ce cours, relire toutes les cartes contre lui : pages,
isotypes du complément, chiffres (nirsevimab 5 mois, toxoplasmose 30 %, 4
semaines, asplénie, sérologie obligatoire), et les neuf erreurs ci-dessus.

## L'échelle : Simple → Moyen → Annale (C20, 16/10/2026)

Le pilote de l'immunité innée, étendu au reste de l'immunologie pour l'examen du 4/11 (choix de Vincent, 15/10). Sous les annales, 25 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 6 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`) ; les QROC reçoivent le schéma nu.

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `modes-action-ac` | 5 | 1 | 4 |
| `fonctions-isotypes` | 5 | 1 | 2 |
| `rate` | 3 | 1 | 2 |
| `antigenes-reconnus` | 5 | 1 | 2 |
| `affinite-avidite` | 7 | 2 | 3 |

**Le schéma** `ech-anticorps`, « Les anticorps · modes d'action, classes, cibles », donne 40 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_ANTICORPS`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu les dix chapitres ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Tag `edn`** (passage « pas à retenir ») : `anc-ech-s25`.

**Sans marche** :
- anc-an-2122s1-q7 B : les IgG majoritaires parmi les immunoglobulines du plasma — un fait de la FC n°4 2025-26 (p. 9), chapitre de l'ontogenèse B ; la FC n°10 ne le porte pas. Lettre posée sur la case IgG.
- anc-an-2021s2-q5 E : les complexes immuns d'une réponse polyclonale — ni la FC n°10 2025-26 ni le cours 2024-25 ne le disent (la justification de l'annale cite OpenStax) : rien à bâtir sans inventer. Lettre posée sur la case polyclonale.
- anc-an-1617s1-q2 A : BAFF et APRIL, facteurs de survie des LB sortis de la moelle — la FC n°10 2025-26 ne les nomme que sur la diapositive de rappel (p. 2), sans dire leur rôle : le fait est enseigné dans l'ontogenèse B (FC n°6 2025-26, p. 4 ; cours 2024-25, p. 2). Lettre posée sur la case des rôles de la rate (maturation des LB sortis de la moelle).

## Régénérer

```powershell
cd contenu\chapitres\immuno_anticorps
..\..\..\app\.venv\Scripts\python.exe generer.py
```

La planche se refait depuis `app/`, si ses rectangles changent :
`uv run --with pillow python ../.claude/skills/nouveau-chapitre/scripts/planche_depuis_image.py ../contenu/chapitres/immuno_anticorps anc-pl-fcrn-pigr --apercus <brouillon> --taille 16`.
