# Anomalies chromosomiques — paquet Génétique

115 notes, 176 cartes. Chapitre `chap-ue-genetique-fc4` de l'UE Génétique,
quatrième de l'UE. Cours du **Dr P. Plante-Bordeneuve, le 24/11/2025, de
8 h à 9 h 30**, dans le **Ronéosaure 2025-26** (FC n°4, 18 pages) ; les
annales de trois polycopiés du Ronéosaure 2024-25 (54 questions, 10 épreuves).
Examen : mercredi 16 décembre 2026.

**Fiche provisoire** (C15, décision de Vincent du 02/10) : le cours de l'année
2026-27 n'est pas encore paru. Chaque carte de cours cite la FC 2025-26 à sa
page, et porte le badge « Cours 2025-26 » (tag `cours-2025-26`, tiré de
l'auteur de la source) ; le ronéo 2026-27 la corrigera quand il sortira.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 73 | 73 |
| Texte à trous | 13 | 67 |
| QROC | 10 | 10 |
| Recto-verso | 7 | 7 |
| Schéma cliquable | 1 | 8 |
| Planche à légender | 1 | 1 |
| Lexique | 10 | 10 |

Dont **54 annales** : 52 QCM du polycopié n°4, la question 12 de 2016/2017 S1
du polycopié n°2 et la question 27 de 2019/2020 S1 du polycopié n°5 (plan C15,
0.9). 19 QCM de cours, tous avec une figure ; **73 QCM sur 73 illustrés**,
99 notes sur 115.

Huit thèmes, dans l'ordre du cours ; toutes les clés sont nouvelles et leurs
libellés restent à ajouter à `THEME_LABELS`
(`app/src/med_engine/application/scopes.py`) — c'est le seul test rouge :

| Clé | Libellé | Notes (dont annales) |
|---|---|---|
| `anomalies-nombre` | Anomalies de nombre : aneuploïdies et polyploïdies | 24 (12) |
| `meiose-segregation` | Méiose, non-disjonction et disomie uniparentale | 14 (7) |
| `mosaiques` | Mosaïques et chimères | 10 (5) |
| `trisomies` | Trisomies viables : Down, Patau, Edwards | 14 (9) |
| `turner-dysgonosomies` | Dysgonosomies et syndrome de Turner | 6 (1) |
| `anomalies-structure` | Translocations, inversions, insertions | 24 (14) |
| `desequilibres` | Remaniements déséquilibrés et région critique | 4 (1) |
| `conseil-recurrence` | Risque de récurrence et conseil génétique chromosomique | 9 (5) |

Le plan proposait « Trisomies 21, 13 et 18 » : un libellé ne porte pas de
chiffre (test `test_le_chapitre_se_decoupe_en_themes_lisibles`), d'où
« Trisomies viables : Down, Patau, Edwards ».

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-genet-chr-2526` — Ronéosaure, « FC n°4- Anomalies chromosomiques » (18 p.) | 2025-26 | le cours ; `SRC["fiche"]`, ses 15 figures |
| `src-annales-4-anomalies-chromosomique-de-nombre-de-structure-mosaiques` | 2024-25 | 52 questions, 9 épreuves ; table p. 17 |
| `src-annales-2-methodes-d-etudes-en-cytogenetique-conventionnelle-et-moleculaire` | 2024-25 | 2016/2017 S1 Q12 et son caryotype |
| `src-annales-5-maladies-genetiques-de-transmission-mendelienne` | 2024-25 | 2019/2020 S1 Q27 |

Les trois polycopiés sont déclarés exactement comme dans les chapitres qui les
déclaraient déjà, champ pour champ : le n°2 comme `genet_cytogenetique`, son
propriétaire, et `genet_tests` ; les n°4 et 5 comme `genet_mendelien` et
`genet_tests`. Lus en appoint, sans être
déclarés : les cours 2024-25 (Ronéosaure) et 2023-24 (Charonéo) du même
chapitre, pour comprendre une annale ; l'errata des cours 2025-26, celui des
annales 2024-25 (aucune entrée pour ce polycopié) ; le PNDS Trisomie 21 (HAS,
2020) pour les annales de clinique. Aucun nom d'étudiant n'est repris des
en-têtes, des erratas ni des polycopiés.

## Ce que le cours a dicté

- **Le cours se dit lui-même facile** : « pas beaucoup de questions sur ce
  cours ou du moins des questions très simples » (p. 2).
- **Le gris** est la voix des rédacteurs (décision du 25/09) : ses QCM sont
  cartés. Deux consignes y sont suivies : « les chiffres ne sont pas à
  connaître par cœur » (fréquences des ISG, p. 2) — aucun trou ne les demande,
  ils restent en ordre de grandeur ; « pas de questions sur le détail des
  cliniques », mais savoir quel syndrome donne quelle clinique (p. 12) — d'où
  le tableau comparatif des quatre syndromes. « Pas de cas d'inversion comme
  ci-dessus donné en examen » (p. 16) : aucune carte ne le pose.
- **Le rouge** a ses cartes : mosaïque contre chimère (p. 7 :
  `gch-qc-chimere`, `gch-rv-mosaique-chimere`, `gch-qr-chimere`), le « seul »
  facteur de risque de la trisomie 21 (p. 9 : `gch-qr-age-maternel`), les
  fréquences des remaniements et les déséquilibrés (p. 13 :
  `gch-qc-structure-generalites`), les acrocentriques et le trivalent
  (p. 14 : `gch-fa-acrocentriques`, `gch-qr-trivalent`), les inversions
  (p. 15), la région minimale critique (p. 17 : `gch-qr-region-critique`).
- **Aucune photographie d'enfant** (p. 8, 10, 11) : le tableau des trisomies
  21, 13, 18 et de la monosomie X est redessiné (`syndromes.svg`).

## Ce que les annales ont dicté

| Savoir | Questions |
|---|---|
| Aneuploïdie ou polyploïdie, viables ou non | 2023/2024 Q9, 2022/2023 Q6, 2021/2022 S1 Q9, S2 Q20, 2019/2020 S1 Q9 |
| Nombre ou structure ? | 2021/2022 S1 Q12, S2 Q23 |
| Triploïdie, tétraploïdie | 2020/2021 S1 Q18, S2 Q21, 2019/2020 S2 Q9, 2018/2019 Q24 (caryotype) |
| Trisomie 16, fréquences des FCS | 2020/2021 S1 Q19, S2 Q21-22 |
| Mosaïques (« toujours atténué », sang, sauvetage) | 2023/2024 Q11, 2022/2023 Q8, 2021/2022 S1 Q11, S2 Q22, 2018/2019 Q20 |
| Non-disjonction, disomie uniparentale | 2020/2021 S1 Q16, 2019/2020 S1 Q10, Q27 (poly 5), 2018/2019 Q8, Q9 |
| Translocations réciproques et robertsoniennes | 2023/2024 Q10, 2022/2023 Q7, 2021/2022 S1 Q10, S2 Q21, 2019/2020 S1 Q11, Q14, 2016/2017 Q12 (caryotype) |
| Inversions, insertions, ségrégation, X;autosome | 2020/2021 S1 Q20-21, S2 Q23-24, 2019/2020 S2 Q8, 2018/2019 Q19 |
| Formes et risque de la trisomie 21 | 2020/2021 S1 Q22, Q24, S2 Q25, Q27, 2019/2020 S2 Q7, Q10, 2018/2019 Q21 |
| Clinique de la trisomie 21 | 2020/2021 S1 Q23, S2 Q26, 2019/2020 S1 Q15, S2 Q11-13, 2018/2019 Q22 |
| Turner, dysgonosomies | 2019/2020 S1 Q12 |
| Délétions, mécanismes des remaniements | 2020/2021 S2 Q28, 2019/2020 S1 Q13, 2018/2019 Q23 |

Les questions répétées d'une session à l'autre ont chacune leur carte, et
l'explication renvoie aux autres. **Trois questions du polycopié n°4 sont dans
`genet_mendelien`** (plan C15) : 2019/2020 S2 Q14 et Q15 (mutations de novo,
mosaïcisme génique) et la « 2018/2019 » Q7 (mot pour mot la 2018/2019 S1 Q7
du polycopié n°5).

**Les en-têtes et l'impression** : le bloc « 2018/2019 » du polycopié n°4 est
imprimé « session 2 », mais la table dit « Session 1 » (et sa Q7 est la S1 Q7
du n°5) : les huit questions sont cartées sous 2018/2019 S1. En 2018/2019 Q24,
les propositions D et E sont imprimées collées : l'énoncé est redonné en cinq
propositions, mot pour mot. La vignette de 2016/2017 S1 Q12 manque dans les
deux polycopiés (les Q13-14 du même couple sont dans `genet_tests`).

**La session « 2019/2020 S1 (poly 5) »** : le générateur modèle choisit la
source d'une annale par sa session ; or le polycopié n°4 a lui aussi une
session 2019/2020 S1. La question 27 du n°5 porte donc la session « 2019/2020
S1 (poly 5) », qui la fait citer son vrai polycopié — la convention que
`genet_mendelien` a prise pour ses deux questions du n°4 (« 2019/2020 S2
(poly 4) »). Son tag de session est `2019-2020-s1-(poly-5)`.

## Les erreurs du Ronéosaure 2025-26

Le Ronéosaure n'est pas la ronéo de l'année : chaque erreur est portée par un
**ATTENTION nu** dans la carte qui tient la notion, la sorte dite dans le
texte, et rien n'entre dans `contenu/ERRATA_RONEOS_2026-27.md`.

| Page | Le ronéo dit | Retenu | Sorte | Carte |
|---|---|---|---|---|
| 12 | QCM E : « une dysgonosomie en mosaïque peut être due à un accident post mitotique » | post-zygotique, comme le même QCM du cours 2024-25 (p. 20) | prise de notes | `gch-qc-dysgonosomies` E |
| 14 | robertsoniennes : la 14/21, « c'est d'ailleurs celle-ci qui est la plus fréquente » | dans la population, la der(13;14) (63 % : Poot et Hochstenbach, Mol Syndromol 2021) ; la der(14;21) est la plus fréquente des trisomies 21 par translocation (PNDS T21, HAS 2020, p. 16) | point douteux | `gch-qc-translocations` E |
| 16 | les inversions « représentent 4 % des couples en situation d'infertilité » ; « dans ces 15 à 20 %, c'est pour des causes chromosomiques » | 4 % des couples infertiles ont un remaniement, toutes sortes confondues (cours 2023-24, p. 14 ; 2024-25, p. 18) | prise de notes | `gch-qc-infertilite` C |
| 18 | QCM A : « au risque de la mosaïque terminale donc de 1 % » | mosaïque germinale (p. 7, 9) | prise de notes | `gch-qc-recurrence` C |

Sans ATTENTION, parce qu'aucune réponse n'en dépend : « longue disjonction »
pour non-disjonction (QCM 3, p. 7), « Klynefelter » (p. 17),
« Bonnevie-Ulrich » pour Bonnevie-Ullrich (p. 11, dit dans `gch-qr-bonnevie`),
« ils varient non pas 2 à 2 mais 3 à 3 » pour s'apparient (p. 14). L'entrée de
l'errata 2025-26 (« équilibrées », p. 18) est déjà corrigée dans la version
lue.

## Les clés qui ne sont pas reprises telles quelles

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2020/2021 S1 Q19 | E | AE | la trisomie 16 est la plus fréquente des trisomies homogènes des FCS du 1er trimestre : cours 2025-26 p. 4 (graphique), 2024-25 et 2023-24 p. 5 ; la session 2 cote fausse « la trisomie 21 est la plus fréquente » (Q22 D) |
| 2020/2021 S1 Q20 | AE | ABE | toute ségrégation adjacente déséquilibre les régions transloquées ; la session 2 cote vraie la même idée (Q23 C) ; Gardner et Amor |
| 2019/2020 S2 Q10 | AD | ABD | la non-disjonction maternelle de méiose I est à l'origine de la majorité des trisomies 21 libres (Hassold et Hunt, Nat Rev Genet 2001) ; la table de 2020/2021 S1 Q22 A cote vraie la même idée |

Chacune porte `officielle=False`, un `ATTENTION` dans la justification en
cause et une entrée de `CONFLITS`. **Deux points douteux** gardent la clé
imprimée, avec `ATTENTION`, `CONFLITS` et `a-relire` :

| Question | Clé | Le point | À l'examen |
|---|---|---|---|
| 2022/2023 S1 Q7 B | ADE | « les translocations réciproques concernent les acrocentriques », cotée fausse avec son contraire C, alors que le cours dit qu'elles *peuvent* les concerner (QCM D, p. 18) : la table la lit comme une définition | faux, comme la table |
| 2019/2020 S2 Q10 D | ABD | le sur-risque de trisomie 18 après une trisomie 21, coté vrai ; le cours 2025-26 dit « pas spécialement de sur-risque » (p. 8) ; Warburton et al. (Am J Hum Genet 2004) trouvent un risque accru de trisomie d'un autre chromosome | vrai, comme la table (question ci-dessous) |

## Hors du cours 2025-26

**Cinq questions entières** portent sur des notions que la FC n°4 2025-26
n'enseigne pas (le cours de 2019-2021 était plus détaillé), et qu'aucune autre
FC 2025-26 ne couvre. Elles sont cartées ici (proposition du plan C15, 0.10),
clé reprise, justifiées sur une source sûre, avec le tag `a-relire` ; le ronéo
2026-27 dira si elles reviennent :

| Question | Clé | Sujet | Source |
|---|---|---|---|
| 2019/2020 S1 Q13 | BCDE | mécanismes des remaniements : recombinaison homologue, NHEJ et cicatrices, NAHR, V(D)J | Gu, Zhang et Lupski, PathoGenetics 2008 |
| 2018/2019 S1 Q23 | BDE | défaut d'alignement de la recombinaison homologue (NAHR) | idem |
| 2019/2020 S2 Q8 | BCE | modes de ségrégation d'une translocation réciproque donnant 46 chromosomes | Gardner et Amor ; cours 2024-25 p. 16 |
| 2018/2019 S1 Q19 | C | mode de ségrégation donnant 47 chromosomes (3:1) | idem |
| 2018/2019 S1 Q8 | ADE | mécanismes de la disomie uniparentale (complémentation gamétique, duplication de monosomie, correction de trisomie) | Engel, Eur J Hum Genet 2006 ; la correction de trisomie est p. 6-7 |

Des propositions isolées, dans des questions par ailleurs couvertes, disent
« hors du cours 2025-26 » et leur source dans leur justification : la 3:1 de
la t(11;22) et son risque (« 25 % », faux : quelques pour cent ; OMIM #609029,
Genes 2023), la translocation X;autosome chez une fille ou un garçon (cours
2023-24, p. 12-13), le canal atrio-ventriculaire, l'atrésie duodénale, la
macroglossie, la fertilité des femmes, l'inclusion scolaire, l'arthrose (PNDS
Trisomie 21, HAS 2020, et cours 2023-24), le syndrome des gènes contigus
(Schmickel, J Pediatr 1986), la perte d'hétérozygotie de l'isodisomie (Engel,
Eur J Hum Genet 2006).

## Les schémas et les figures

**Quinze figures de la FC 2025-26**, extraites en PNG (256 couleurs) : diandrie
et digynie (p. 3), les trisomies des FCS du 1er trimestre (p. 4), la
non-disjonction en méiose I et II (p. 6), la non-disjonction mitotique et le
sauvetage (p. 6), le moment de survenue (p. 7), mosaïque et chimère (p. 7),
les trisomies 21 robertsoniennes (p. 9), les translocations réciproques
(p. 13), les robertsoniennes et les acrocentriques (p. 14), l'insertion et ses
déséquilibres, les insertions intra- et interchromosomiques (p. 15), les
inversions (p. 16, le tableau repris du Ronéosaure 2024-25), les remaniements
des couples infertiles, délétions et duplication, la région minimale critique
(p. 17). **Deux figures d'annales**, qui sont la question
(`illustration_question`) : le caryotype 69,XXX de 2018/2019 Q24 (polycopié
n°4, p. 16) et le caryotype t(4;12) de 2016/2017 S1 Q12 (polycopié n°2, p. 16).

| Fichier | Ce qu'on fait | Pourquoi ce dessin |
|---|---|---|
| `remaniements-nus.svg` (zone, 8 cartes) | cliquer, parmi huit panneaux sans légende, la translocation réciproque, la robertsonienne, l'insertion, les inversions péri- et paracentrique, les délétions interstitielle et terminale, la duplication | les annales demandent sans cesse « nombre ou structure ? », « combien de cassures ? » ; chaque panneau montre le ou les chromosomes normaux et le résultat, segments a-e comme l'exemple du cours (p. 16) ; la version légendée `remaniements.svg` va dans la correction |
| `gch-non-disjonction-numerotee.png` (planche, 11 numéros) | légender les deux figures de la p. 6 : méiose I et II, non-disjonction, gamètes disomique, nullisomique, normal, hétéro- et isodisomie | une capture de diapositive : rectangles mesurés sur un agrandissement quadrillé, aperçu de contrôle relu ; cinq intrus (endomitose, trivalent, chimère, mosaïque, correction de trisomie) |
| `syndromes.svg` (illustration) | — | le tableau des quatre syndromes, sans photographie, pour toutes les questions de clinique |

Le plan proposait aussi une planche de la p. 3 (diandrie, digynie) : ses deux
images font 308 × 250 et 194 × 246 pixels, et leurs seules légendes sont
« Gametes », « Zygote », « 23 », « 46 », « 69 » ; la diandrie et la digynie
sont tenues par un texte à trous, un QROC, un recto-verso et un QCM, illustrés
par le tableau de la p. 3.

## Le lexique

Dix termes, ceux du plan C15 (0.7) ; aucun n'existait (vérifié contre les
`lex-*` de tous les paquets). Pages mesurées dans le texte de la FC 2025-26
(`chercher_pages.py`), la p. 1 écartée quand le mot n'est que dans le plan :

| Terme | Origine | Pages |
|---|---|---|
| Aneuploïdie | grec ἀν- + εὖ + -πλόος + εἶδος | 3, 4, 5, 7, 9, 12 |
| Polyploïdie | grec πολύς + -πλόος + εἶδος | 3, 5 |
| Triploïdie | grec τρι- + -πλόος + εἶδος | 2, 3, 4, 5 |
| Mosaïque | latin médiéval musaicum, par l'italien mosaico | 2-7, 9-13, 18 |
| Chimère | grec χίμαιρα, par le latin chimaera | 7 |
| Isodisomie | grec ἴσος + δίς + σῶμα | 6 |
| Dysgonosomie | grec δυσ- + γονή + σῶμα | 4, 5, 12 |
| Acrocentrique | grec ἄκρος + κέντρον | 14, 18 |
| Translocation robertsonienne | latin trans + locatio ; W. R. B. Robertson, 1916 | 9, 14, 18 |
| Chromatide | grec χρῶμα, χρώματος, par l'anglais chromatid | 4, 5, 6 |

Sept racines citent la FC de sémantique 2026-27, qui les enseigne : `a-/an-`
(1/2, p. 3), `gon(o)-` (1/2, p. 6), `acro- (grec)` (2/2, p. 4), `iso-` (2/2,
p. 5), `eu-` et `dys-` (2/2, p. 6), `-chrome / chromat-` (2/2, p. 7) et
`trans- (latin)` (2/2, p. 11). Les racines nouvelles (`-ploïdie`, `gon(o)-`,
`-chrome / chromat-` — même forme et même sens que `genet_cytogenetique` —,
`musaicum (latin médiéval)`, `chimaera (latin)`, `locatio (latin)`) et les dix
termes sont proposés à la table commune dans
`scratchpad/etym/genet_chromosomes.json` ; les textes du lexique sont déjà
écrits dans la forme que `appliquer_etymologies.py` produirait. `a-/an-`,
`eu-`, `poly-`, `tri-`, `iso-`, `di-`, `dys-`, `-some`, `acro- (grec)`,
`centrum (latin)`, `trans- (latin)` reprennent les clés existantes.

## Décisions prises en route

- **Le nom du chapitre** est « Anomalies chromosomiques », comme l'a demandé
  la tâche C15 ; l'identifiant est celui du squelette
  (`chap-ue-genetique-fc4`, qui y porte « Anomalies chromosomiques de nombre
  et de structure »).
- **« Une chromatide de chaque chromosome homologue »** (p. 6), que le plan
  C15 rangeait parmi les erreurs de prise de notes : relue sur la figure de la
  même page, la phrase est juste — après une non-disjonction en méiose I, la
  méiose II laisse dans le gamète une chromatide de chacun des deux homologues.
  Pas d'ATTENTION ; la carte `gch-qc-non-disjonction` B le dit en clair.
- **2021/2022 S1 Q12 B** (« un syndrome de Turner » n'est pas une anomalie de
  structure, clé reprise) : la justification dit que 30 % des Turner ont une
  anomalie de structure de l'X, et que la table vise la forme classique.
- **2019/2020 S2 Q13 D** (« les formes en mosaïque ont un meilleur
  développement intellectuel en général », vrai) : clé reprise ; la
  justification ajoute que le PNDS le dit « pas clairement déterminé ».
- **`EXAMENS` n'est pas déclaré** (convention C14) : l'examen du 16/12 se
  règle dans l'application.

## Questions pour Vincent

1. **Les cinq questions entières hors du cours 2025-26** (mécanismes des
   remaniements, modes de ségrégation, mécanismes de la disomie uniparentale)
   sont cartées ici avec `a-relire` (proposition du plan C15). Les garder, ou
   les mettre de côté tant que le ronéo 2026-27 ne les traite pas ?
2. **2019/2020 S2 Q10 D** : après une trisomie 21, faut-il répondre « sur-risque
   de trisomie 18 » comme la table de 2019/2020, ou « pas de sur-risque, seul
   l'âge maternel » comme le cours 2025-26 ? La carte suit la table et le
   signale.
3. **2022/2023 S1 Q7 B** : la carte suit la table (« faux ») contre la lecture
   littérale du cours ; à confirmer quand le ronéo 2026-27 paraîtra.
4. **La robertsonienne « la plus fréquente »** (p. 14, point douteux) : la
   carte `gch-qc-translocations` E retient la der(13;14) dans la population et
   la der(14;21) parmi les trisomies 21 par translocation, contre la phrase du
   Ronéosaure qui donne la 14/21. Le ronéo 2026-27 dira ce que la professeure
   enseigne.

## À relire

**Sept cartes `a-relire`** : les cinq questions hors du cours 2025-26
(`gch-an-1920s1-q13`, `gch-an-1819s1-q23`, `gch-an-1920s2-q8`,
`gch-an-1819s1-q19`, `gch-an-1819s1-q8`) et les deux points douteux
(`gch-an-2223s1-q7`, `gch-an-1920s2-q10`). Le tag se retire quand le ronéo
2026-27 tranchera. Reste aussi à Vincent :

- quand le ronéo 2026-27 paraîtra, relire chaque carte sur lui ;
- `copier_les_cours.py` avec le dossier `…/S1 25-26/examen décembre` du
  Ronéosaure 2025-26, hors du bac à sable, pour que la fiche s'ouvre dans
  l'application ;
- les libellés des huit thèmes dans `THEME_LABELS`, les étymologies dans la
  table commune.


## L'échelle : Simple → Moyen → Annale (C20, 18/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 16 décembre. Sous les annales, 74 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 14 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`).

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `anomalies-nombre` | 18 | 2 | 12 |
| `meiose-segregation` | 7 | 1 | 7 |
| `mosaiques` | 7 | 1 | 5 |
| `trisomies` | 10 | 3 | 9 |
| `turner-dysgonosomies` | 3 | 1 | 1 |
| `anomalies-structure` | 19 | 3 | 14 |
| `desequilibres` | 3 | 1 | 1 |
| `conseil-recurrence` | 7 | 2 | 5 |

**Les schémas** sont au nombre de 2 : `ech-anomalies-nombre`, « Les anomalies de nombre · du gamète à la naissance » (45 Simple, 8 Moyen, 34 annales ; 88 fichiers), et `ech2-structure`, « Les remaniements de structure · du porteur à l'enfant » (29 Simple, 6 Moyen, 20 annales ; 56 fichiers). Une carte ou une annale va au schéma de son mécanisme. Ils sont décrits dans `schemas.py` (`ECH_ANOMALIES_NOMBRE`, `ECH2_STRUCTURE`, avec leurs `TROUS_*` et `LETTRES_*`, un `FICHIERS.update` chacun) et dessinés par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Sans marche** :
- gch-an-2122s2-q23 B, C : la translocation réciproque t(11;22) et la duplication 8p24 sont des anomalies de structure, qu'enseignent les marches des remaniements de structure (schéma ech2-structure) ; ce schéma n'a aucun fait de nombre à leur opposer (lettres posées sur la case « Anomalies de nombre »).
- gch-an-2021s1-q16 B : la perte d'hétérozygotie de l'isodisomie n'est pas dans la FC n°4 2025-26 (la justification cite Engel, Eur J Hum Genet 2006).
- gch-an-2021s1-q22 A et gch-an-1920s1-q10 B : la part des non-disjonctions maternelles de méiose I dans la trisomie 21 libre n'est pas dans la FC 2025-26 (Hassold et Hunt, Nat Rev Genet 2001).
- gch-an-2021s1-q23 A, B, E et gch-an-1920s2-q11 C, E : canal atrio-ventriculaire, atrésie duodénale, fertilité et contraception des femmes porteuses viennent du PNDS Trisomie 21 (HAS 2020) ; la FC ne dit que « cardiaques (~40 %) » et « digestives » (p. 8), que gch-ech-m8 reprend.
- gch-an-2021s2-q25 E : la seule phrase du cours sur la fréquence des robertsoniennes est le point douteux du Ronéosaure (la 14/21 « la plus fréquente », p. 14, ATTENTION de gch-qc-translocations E) ; la réponse s'appuie sur le PNDS : pas de marche sur un point douteux.
- gch-an-1920s1-q15 E, gch-an-1920s2-q13 A et E : macroglossie, scolarisation, arthrose précoce viennent du PNDS et du cours 2023-24, hors de la FC 2025-26.
- gch-an-1920s2-q13 D : « meilleur développement des formes en mosaïque » est vrai pour la table (PNDS), alors que le cours dit la sévérité d'une mosaïque difficile à prédire (p. 7) : pas de marche sur cette notion ; gch-ech-s22, qui en est voisine, le signale par un ATTENTION (proposition A).
- gch-an-1920s2-q8 B, C, D, E et gch-an-1819s1-q19 A, B, D, E : les modes de ségrégation (alterne, adjacent 1 et 2, 3:1, 4:0) ne sont pas dans la FC n°4 2025-26 (Gardner et Amor ; annales a-relire) ; gch-ech-s2 ne prépare que le compte des chromosomes (un gamète disomique donne 47), pour 1819s1-q19 C et 1920s2-q8 A ; toutes les lettres sont posées sur la case « Méiose ratée ».
- gch-an-1819s1-q8 A, B, C, D et gch-an-1819s1-q9 D : les mécanismes de la disomie uniparentale autres que la correction de trisomie (complémentation gamétique, duplication de monosomie, rôle d'une translocation) sont hors de la FC 2025-26 (Engel 2006) ; seule la correction de trisomie a sa marche (gch-ech-s7).
- gch-an-1819s1-q20 C : la notation d'un caryotype en mosaïque, le nombre de cellules entre crochets, n'est pas dans la FC n°4 2025-26 ; le calcul (5 cellules sur 25, 20 %) reste dans la justification de l'annale.
- gch-an-2324s1-q10 C, gch-an-2122s1-q10 C, gch-an-2021s1-q20 E, gch-an-2021s2-q23 E : la translocation X;autosome (« que les autosomes », l'X normal inactivé chez la fille, rien à inactiver chez le garçon) n'est que dans le cours 2023-24 (p. 12-13) ; hors du cours 2025-26, aucune case ne la porte et les lettres se posent sur la case de la réciproque.
- gch-an-2324s1-q10 E, gch-an-2223s1-q7 E, gch-an-2122s1-q10 E : « équilibrée ou déséquilibrée » se lit partout sur le schéma (cases « Robertsonienne déséquilibrée », « Chez un enfant ») : une case vide s'y lirait ; la Moyen gch-ech2-m1 (D) les prépare.
- gch-an-2021s1-q20 A et B, gch-an-2021s2-q23 C, gch-an-2021s2-q24 D, gch-an-1920s1-q14 C : les modes de ségrégation d'une réciproque (alterne, adjacente, 3:1 de la t(11;22) et son risque) sont hors du cours 2025-26, qui ne les nomme pas (Gardner et Amor ; cours 2024-25, p. 16). 2020/2021 S1 Q20 B est en plus une clé changée (CONFLITS, officielle=False) : aucune marche ne la reprend, son ATTENTION reste dans sa justification ; les lettres se posent sur « Chez un enfant » ou « Porteur équilibré ».
- gch-an-2021s2-q28 D : le syndrome des gènes contigus, hors du cours 2025-26 (Schmickel, J Pediatr 1986).
- gch-an-1920s1-q13 B, C, D, E et gch-an-1819s1-q23 B, D, E : les mécanismes des remaniements (recombinaison homologue et non allélique, NHEJ et ses cicatrices, V(D)J) sont hors du cours 2025-26 (Gu, Zhang et Lupski, PathoGenetics 2008) : ni marche ni lettre ; 2019/2020 S1 Q13 n'est préparée que par sa lettre A (points de cassure non récurrents, gch-ech2-s23), 2018/2019 S1 Q23 par sa lettre C (gch-ech2-s4) ; 2018/2019 S1 Q23 A (la réciproque entre non-homologues) reste posée sur la case de la réciproque, sans marche.
- gch-an-1920s2-q10 B : la non-disjonction maternelle de méiose I, hors du cours 2025-26 et clé changée (CONFLITS) ; la méiose n'est pas sur ce schéma (thème meiose-segregation, schéma ech-anomalies-nombre) ; la lettre se pose sur « T21 libre et homogène ».
- gch-an-1617s1-q12 A : ce qu'on explique au couple avant de prescrire un caryotype relève du chapitre « Tests génétiques » (FC n°1) ; la lettre se pose sur « Porteur équilibré ».

## Régénérer

```powershell
..\..\..\app\.venv\Scripts\python.exe generer.py
```
