import { HttpError } from "./http.ts";
import { classifyProviderError } from "./ai-errors.ts";

export async function structuredAI<T>(system: string, input: unknown, name: string, schema: unknown): Promise<{ output: T; model: string; usage: unknown }> {
  const key = Deno.env.get("OPENAI_API_KEY");
  const model = Deno.env.get("OPENAI_MODEL") || "gpt-4o-mini";
  if (!key) throw new HttpError(503, "AI_CONFIGURATION", "La clé IA n’est pas configurée sur le serveur.");
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 45_000);
  try {
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      signal: controller.signal,
      headers: { "Authorization": `Bearer ${key}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model, store: false, max_completion_tokens: 6000,
        messages: [{ role: "system", content: system }, { role: "user", content: JSON.stringify(input) }],
        response_format: { type: "json_schema", json_schema: { name, strict: true, schema } },
      }),
    });
    if (!response.ok) {
      const payload = await response.json().catch(() => null) as { error?: { code?: unknown } } | null;
      const providerCode = typeof payload?.error?.code === "string" ? payload.error.code : undefined;
      const failure = classifyProviderError(response.status, providerCode);
      // Log only safe categories, never provider messages, API keys or course content.
      console.error(JSON.stringify({ event: "ai_provider_error", provider_status: response.status, code: failure.code }));
      throw new HttpError(failure.status, failure.code, failure.message);
    }
    const data = await response.json();
    const choice = data.choices?.[0];
    if (choice?.finish_reason !== "stop" || !choice.message?.content || choice.message.refusal) {
      throw new HttpError(502, "AI_INCOMPLETE", "La réponse IA est incomplète. Réessayez avec un extrait plus court.");
    }
    let output: T;
    try { output = JSON.parse(choice.message.content) as T; }
    catch { throw new HttpError(502, "AI_FORMAT", "La réponse IA n’a pas le format attendu."); }
    return { output, model: data.model || model, usage: data.usage ?? null };
  } catch (error) {
    if (error instanceof HttpError) throw error;
    if (controller.signal.aborted) throw new HttpError(504, "AI_TIMEOUT", "L’IA n’a pas répondu à temps. Réessayez avec un extrait plus court.");
    throw new HttpError(502, "AI_NETWORK", "La connexion au fournisseur IA a échoué.");
  } finally { clearTimeout(timer); }
}
