import { createClient, type SupabaseClient } from "npm:@supabase/supabase-js@2.57.4";
import { z } from "npm:zod@3.25.76";

export class HttpError extends Error {
  constructor(public status: number, public code: string, message: string) { super(message); }
}
export type Session = { db: SupabaseClient; userId: string };

export async function authenticate(request: Request): Promise<Session> {
  const token = request.headers.get("Authorization")?.match(/^Bearer ([^\s]+)$/i)?.[1];
  if (!token) throw new HttpError(401, "AUTH_REQUIRED", "Connectez-vous pour continuer.");
  const url = Deno.env.get("SUPABASE_URL");
  const key = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!url || !key) throw new HttpError(503, "CONFIGURATION", "Le serveur n’est pas configuré.");
  const db = createClient(url, key, { auth: { persistSession: false, autoRefreshToken: false } });
  const { data, error } = await db.auth.getUser(token);
  if (error || !data.user) throw new HttpError(401, "AUTH_REQUIRED", "Votre session a expiré. Reconnectez-vous.");
  return { db, userId: data.user.id };
}

export async function parseBody<T>(request: Request, schema: z.ZodType<T>): Promise<T> {
  if (!request.headers.get("content-type")?.toLowerCase().startsWith("application/json")) {
    throw new HttpError(415, "CONTENT_TYPE", "Le contenu doit être au format JSON.");
  }
  // Streaming limit: Content-Length is optional and cannot be trusted.
  const reader = request.body?.getReader();
  if (!reader) throw new HttpError(400, "EMPTY_BODY", "La requête est vide.");
  const chunks: Uint8Array[] = [];
  let total = 0;
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    total += value.byteLength;
    if (total > 220_000) {
      await reader.cancel();
      throw new HttpError(413, "BODY_TOO_LARGE", "Le document dépasse la limite autorisée.");
    }
    chunks.push(value);
  }
  const bytes = new Uint8Array(total);
  let offset = 0;
  for (const chunk of chunks) { bytes.set(chunk, offset); offset += chunk.byteLength; }
  let body: unknown;
  try { body = JSON.parse(new TextDecoder().decode(bytes)); }
  catch { throw new HttpError(400, "INVALID_JSON", "Le contenu JSON est invalide."); }
  const parsed = schema.safeParse(body);
  if (!parsed.success) throw new HttpError(400, "INVALID_INPUT", "Les champs transmis sont invalides ou dépassent les limites.");
  return parsed.data;
}

export function databaseError(error: { code?: string; message?: string }): never {
  if (error.code === "42501") throw new HttpError(403, "FORBIDDEN", "Cette ressource n’est pas accessible.");
  if (error.code === "40001") throw new HttpError(409, "CONFLICT", "Une autre révision a modifié cette carte. Rechargez son état avant de continuer.");
  if (error.code === "55P03") throw new HttpError(409, "IN_PROGRESS", "La génération de ce document est déjà en cours.");
  if (error.message?.includes("AI_RATE_LIMIT")) throw new HttpError(429, "RATE_LIMIT", "Limite de 6 appels IA par minute atteinte. Réessayez dans une minute.");
  if (error.message?.includes("AI_DAILY_LIMIT")) throw new HttpError(429, "DAILY_LIMIT", "Quota de 40 appels IA par jour atteint. Réessayez demain (UTC).");
  if (error.code === "22023") throw new HttpError(400, "INVALID_DATE", "La date de révision est hors de la fenêtre autorisée.");
  throw new HttpError(500, "DATABASE_ERROR", "L’enregistrement a échoué. Réessayez ultérieurement.");
}

export async function reserveAI(db: SupabaseClient, userId: string, task: string, documentId?: string) {
  const { data, error } = await db.rpc("reserve_ai_run", { p_user_id: userId, p_task: task, p_document_id: documentId ?? null });
  if (error) databaseError(error);
  return data as { cached: boolean; count?: number; run_id?: string };
}
export async function failAI(db: SupabaseClient, userId: string, runId: string, code: string) {
  // A lost response must never roll back a completed transaction.
  await db.rpc("fail_ai_run", { p_user_id: userId, p_run_id: runId, p_error_code: code });
}

export function serve(handler: (request: Request) => Promise<unknown>) {
  Deno.serve(async (request) => {
    const origin = request.headers.get("Origin");
    const allowed = (Deno.env.get("ALLOWED_ORIGINS") ?? "").split(",").map((s) => s.trim()).filter(Boolean);
    const headers = new Headers({ "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store", "Vary": "Origin", "X-Content-Type-Options": "nosniff" });
    const reply = (body: unknown, status: number) => new Response(JSON.stringify(body), { status, headers });
    if (!allowed.length || allowed.includes("*")) return reply({ error: "Origines serveur non configurées.", code: "CONFIGURATION" }, 503);
    if (origin && !allowed.includes(origin)) return reply({ error: "Origine non autorisée.", code: "ORIGIN_FORBIDDEN" }, 403);
    if (origin) headers.set("Access-Control-Allow-Origin", origin);
    headers.set("Access-Control-Allow-Headers", "authorization, apikey, content-type, x-client-info");
    headers.set("Access-Control-Allow-Methods", "POST, OPTIONS");
    headers.set("Access-Control-Max-Age", "86400");
    if (request.method === "OPTIONS") return new Response(null, { status: 204, headers });
    if (request.method !== "POST") return reply({ error: "Méthode non autorisée.", code: "METHOD_NOT_ALLOWED" }, 405);
    try { return reply(await handler(request), 200); }
    catch (error) {
      const known = error instanceof HttpError;
      const status = known ? error.status : 500;
      if (status >= 500) console.error(JSON.stringify({ event: "function_error", code: known ? error.code : "INTERNAL_ERROR" }));
      if (status === 429) headers.set("Retry-After", "60");
      return reply({ error: known ? error.message : "Une erreur interne est survenue.", code: known ? error.code : "INTERNAL_ERROR" }, status);
    }
  });
}
