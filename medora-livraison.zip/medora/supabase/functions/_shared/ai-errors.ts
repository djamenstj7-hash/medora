export interface AIProviderError {
  status: number;
  code: string;
  message: string;
}

/**
 * Convert provider failures into a fixed, safe set of public errors.
 * Provider messages can contain request details and must never be forwarded.
 * A provider authentication failure is a server configuration problem, not an
 * expired Medora session, so it must not become a public HTTP 401.
 */
export function classifyProviderError(status: number, code?: string): AIProviderError {
  if (status === 401) {
    return {
      status: 503,
      code: "AI_KEY_INVALID",
      message: "La clé OpenAI du serveur est invalide ou révoquée. Remplacez OPENAI_API_KEY dans les secrets Supabase.",
    };
  }
  if (status === 403) {
    return {
      status: 503,
      code: "AI_PERMISSIONS",
      message: "La clé OpenAI du serveur n’a pas les autorisations nécessaires. Vérifiez ses droits et l’accès au modèle configuré.",
    };
  }
  if (status === 404) {
    return {
      status: 503,
      code: "AI_MODEL",
      message: "Le modèle OpenAI configuré est introuvable ou inaccessible. Vérifiez OPENAI_MODEL dans les secrets Supabase.",
    };
  }
  if (status === 429) {
    if (code === "insufficient_quota" || code === "billing_hard_limit_reached") {
      return {
        status: 503,
        code: "AI_QUOTA",
        message: "L’API OpenAI n’a plus de quota disponible. Vérifiez ses crédits et son plafond de facturation sur platform.openai.com. L’abonnement ChatGPT ne couvre pas l’API.",
      };
    }
    if (code === "rate_limit_exceeded") {
      return {
        status: 429,
        code: "AI_RATE_LIMIT",
        message: "La limite temporaire de requêtes OpenAI est atteinte. Patientez quelques instants avant de réessayer.",
      };
    }
    return {
      status: 429,
      code: "AI_LIMIT",
      message: "OpenAI a limité cette requête. Vérifiez les limites et la facturation de l’API, puis réessayez.",
    };
  }
  if (status === 408 || status === 504) {
    return {
      status: 504,
      code: "AI_TIMEOUT",
      message: "L’IA n’a pas répondu à temps. Réessayez avec un extrait plus court.",
    };
  }
  if (status === 400 || status === 422) {
    return {
      status: 502,
      code: "AI_REQUEST",
      message: "OpenAI a refusé les paramètres de génération. Vérifiez le modèle configuré et sa compatibilité avec les réponses structurées.",
    };
  }
  if (status >= 500 && status <= 599) {
    return {
      status: 502,
      code: "AI_PROVIDER",
      message: "Le service OpenAI rencontre une erreur temporaire. Réessayez plus tard.",
    };
  }
  return {
    status: 502,
    code: "AI_PROVIDER",
    message: "La requête a été refusée par OpenAI. Vérifiez la configuration de l’API ou consultez les journaux techniques du serveur.",
  };
}
