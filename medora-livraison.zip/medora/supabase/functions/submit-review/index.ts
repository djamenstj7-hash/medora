import { fsrs, generatorParameters, type Card, type Grade } from "npm:ts-fsrs@5.2.3";
import { z } from "npm:zod@3.25.76";
import { authenticate, databaseError, HttpError, parseBody, serve } from "../_shared/http.ts";

const schema = z.object({
  card_id: z.string().uuid(), rating: z.union([z.literal(1), z.literal(2), z.literal(3), z.literal(4)]),
  client_event_id: z.string().uuid(), reviewed_at: z.string().datetime({ offset: true }),
  expected_version: z.number().int().nonnegative(),
}).strict();
// Same pinned engine and retention as the browser's offline preview.
const scheduler = fsrs(generatorParameters({ request_retention: 0.9, maximum_interval: 36500, enable_fuzz: false }));

serve(async (request) => {
  const { db, userId } = await authenticate(request);
  const input = await parseBody(request, schema);
  const reviewedAt = new Date(input.reviewed_at);
  const { data: previous, error: previousError } = await db.from("review_logs").select("card_id,rating,reviewed_at,after_schedule,schedule_version").eq("user_id", userId).eq("client_event_id", input.client_event_id).maybeSingle();
  if (previousError) databaseError(previousError);
  // Return the originally committed result even when a later review advanced the card.
  if (previous) {
    if (previous.card_id !== input.card_id || previous.rating !== input.rating || new Date(previous.reviewed_at).getTime() !== reviewedAt.getTime()) {
      throw new HttpError(409, "EVENT_CONFLICT", "Cet identifiant correspond déjà à une autre révision.");
    }
    return { schedule: previous.after_schedule, version: previous.schedule_version, duplicate: true };
  }
  const { data: card, error: cardError } = await db.from("cards").select("id,status").eq("id", input.card_id).eq("user_id", userId).maybeSingle();
  if (cardError) databaseError(cardError);
  if (!card || card.status !== "active") throw new HttpError(403, "FORBIDDEN", "Cette carte n’est pas active ou ne vous appartient pas.");
  const { data: row, error } = await db.from("card_schedules").select("schedule,version").eq("card_id", input.card_id).eq("user_id", userId).maybeSingle();
  if (error) databaseError(error);
  if (!row) throw new HttpError(404, "NOT_FOUND", "La planification de cette carte est introuvable.");
  if (row.version !== input.expected_version) throw new HttpError(409, "CONFLICT", "La carte a été modifiée sur un autre appareil. Rechargez son état.");
  const serialized = row.schedule as Record<string, unknown>;
  const lastReview = serialized.last_review ? new Date(serialized.last_review as string) : undefined;
  if (reviewedAt.getTime() > Date.now() + 5 * 60_000 || reviewedAt.getTime() < Date.now() - 30 * 86400_000) {
    throw new HttpError(400, "INVALID_DATE", "Une révision doit dater de moins de 30 jours et ne peut pas être dans le futur.");
  }
  if (lastReview && reviewedAt < lastReview) throw new HttpError(409, "OUT_OF_ORDER", "Cette révision précède une révision déjà synchronisée. Rechargez la carte et réévaluez-la.");
  const current = { ...serialized, due: new Date(serialized.due as string), ...(lastReview ? { last_review: lastReview } : {}) } as Card;
  const next = scheduler.next(current, reviewedAt, input.rating as Grade).card;
  const { data, error: commitError } = await db.rpc("commit_review", { p_user_id: userId, p_card_id: input.card_id, p_expected_version: input.expected_version, p_client_event_id: input.client_event_id, p_rating: input.rating, p_reviewed_at: reviewedAt.toISOString(), p_after: next });
  if (commitError) databaseError(commitError);
  return data;
});
