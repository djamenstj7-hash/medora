-- Run in a disposable/local Supabase database as postgres, after migrations:
-- psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f supabase/tests/security.sql
-- All fixtures and state changes are rolled back. No external provider is called.
begin;

insert into auth.users(id, email) values
 ('11111111-1111-4111-8111-111111111111', 'security-a@example.invalid'),
 ('22222222-2222-4222-8222-222222222222', 'security-b@example.invalid');
insert into public.decks(id,user_id,title,subject) values
 ('aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa','11111111-1111-4111-8111-111111111111','A','Cardiologie'),
 ('bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb','22222222-2222-4222-8222-222222222222','B','Neurologie');
insert into public.cards(id,user_id,deck_id,kind,prompt,answer) values
 ('cccccccc-cccc-4ccc-8ccc-cccccccccccc','11111111-1111-4111-8111-111111111111','aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa','flashcard','Question A','Réponse A'),
 ('dddddddd-dddd-4ddd-8ddd-dddddddddddd','22222222-2222-4222-8222-222222222222','bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb','flashcard','Question B','Réponse B');
insert into public.card_schedules(card_id,user_id,schedule,due)
 select id,user_id,jsonb_build_object('due',now(),'stability',0,'difficulty',0,'elapsed_days',0,'scheduled_days',0,'reps',0,'lapses',0,'learning_steps',0,'state',0),now() from public.cards where id in ('cccccccc-cccc-4ccc-8ccc-cccccccccccc','dddddddd-dddd-4ddd-8ddd-dddddddddddd');

do $$ begin
  assert not has_function_privilege('authenticated','public.commit_review(uuid,uuid,integer,uuid,integer,timestamptz,jsonb)','execute'), 'Clients must not mutate FSRS through service RPC';
  assert not has_function_privilege('anon','public.reserve_ai_run(uuid,text,uuid)','execute'), 'Anonymous quota RPC must be denied';
  assert not has_table_privilege('authenticated','public.ai_runs','select'), 'AI run internals must remain private';
end $$;

set local role authenticated;
select set_config('request.jwt.claims','{"sub":"11111111-1111-4111-8111-111111111111","role":"authenticated"}',true);
do $$ declare changed integer; begin
  assert (select count(*) from public.decks) = 1, 'RLS must hide other decks';
  assert (select count(*) from public.cards) = 1, 'RLS must hide other cards';
  assert (select count(*) from public.card_schedules) = 1, 'RLS must hide other schedules';
  begin
    insert into public.decks(user_id,title,subject) values ('22222222-2222-4222-8222-222222222222','Forbidden','Test');
    raise exception 'Owner spoofing unexpectedly succeeded';
  exception when insufficient_privilege then null; end;
  begin
    insert into public.documents(user_id,deck_id,name,storage_path) values ('11111111-1111-4111-8111-111111111111','bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb','cross-user.txt',null);
    raise exception 'Cross-user deck reference unexpectedly succeeded';
  exception when foreign_key_violation then null; end;
  begin
    update public.card_schedules set version = 99;
    raise exception 'Direct FSRS modification unexpectedly succeeded';
  exception when insufficient_privilege then null; end;
  begin
    perform public.activate_deck('bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb');
    raise exception 'Cross-user activation unexpectedly succeeded';
  exception when insufficient_privilege then null; end;
  changed := public.activate_deck('aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa');
  assert changed = 1, 'Owner must be able to activate their cards';
  insert into public.documents(id,user_id,deck_id,name,storage_path) values ('eeeeeeee-eeee-4eee-8eee-eeeeeeeeeeee','11111111-1111-4111-8111-111111111111','aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa','Pasted text',null);
end $$;
reset role;

do $$ declare after_state jsonb; result jsonb; event_id uuid := 'ffffffff-ffff-4fff-8fff-ffffffffffff'; begin
  after_state := jsonb_build_object('due',now()+interval '1 day','last_review',now(),'stability',2.3,'difficulty',3,'elapsed_days',0,'scheduled_days',1,'reps',1,'lapses',0,'learning_steps',0,'state',2);
  result := public.commit_review('11111111-1111-4111-8111-111111111111','cccccccc-cccc-4ccc-8ccc-cccccccccccc',0,event_id,3,now(),after_state);
  assert (result->>'version')::integer = 1, 'A review must advance the version';
  result := public.commit_review('11111111-1111-4111-8111-111111111111','cccccccc-cccc-4ccc-8ccc-cccccccccccc',0,event_id,3,now(),after_state);
  assert (result->>'duplicate')::boolean, 'Same event must be idempotent';
  assert (select count(*) from public.review_logs where user_id='11111111-1111-4111-8111-111111111111') = 1, 'Replay must not create another log';
  begin
    perform public.commit_review('11111111-1111-4111-8111-111111111111','cccccccc-cccc-4ccc-8ccc-cccccccccccc',0,gen_random_uuid(),3,now(),after_state);
    raise exception 'Stale version unexpectedly succeeded';
  exception when serialization_failure then null; end;
  begin
    perform public.commit_review('22222222-2222-4222-8222-222222222222','cccccccc-cccc-4ccc-8ccc-cccccccccccc',1,gen_random_uuid(),3,now(),after_state);
    raise exception 'Cross-user review unexpectedly succeeded';
  exception when insufficient_privilege then null; end;
end $$;

do $$ declare reservation jsonb; initial jsonb; count_cards integer; begin
  reservation := public.reserve_ai_run('11111111-1111-4111-8111-111111111111','generate-quiz','eeeeeeee-eeee-4eee-8eee-eeeeeeeeeeee');
  begin
    perform public.reserve_ai_run('11111111-1111-4111-8111-111111111111','generate-quiz','eeeeeeee-eeee-4eee-8eee-eeeeeeeeeeee');
    raise exception 'Concurrent generation unexpectedly succeeded';
  exception when lock_not_available then null; end;
  initial := jsonb_build_object('due',now(),'stability',0,'difficulty',0,'elapsed_days',0,'scheduled_days',0,'reps',0,'lapses',0,'learning_steps',0,'state',0);
  count_cards := public.finish_generation('11111111-1111-4111-8111-111111111111',(reservation->>'run_id')::uuid,
    jsonb_build_array(jsonb_build_object('kind','flashcard','prompt','Question source','answer','Réponse source','explanation','Explication','options','[]'::jsonb,'correct_option_id',null,'source_excerpt','Extrait vérifié du cours source.','schedule',initial)),'test-model',null);
  assert count_cards = 1, 'Generation must atomically save cards and schedule';
  reservation := public.reserve_ai_run('11111111-1111-4111-8111-111111111111','generate-quiz','eeeeeeee-eeee-4eee-8eee-eeeeeeeeeeee');
  assert (reservation->>'cached')::boolean and (reservation->>'count')::integer=1, 'Successful generation retry must return existing cards';
end $$;

do $$ declare n integer; begin
  for n in 1..6 loop perform public.reserve_ai_run('22222222-2222-4222-8222-222222222222','evaluate-feynman',null); end loop;
  begin
    perform public.reserve_ai_run('22222222-2222-4222-8222-222222222222','evaluate-feynman',null);
    raise exception 'Minute quota unexpectedly exceeded';
  exception when raise_exception then
    if sqlerrm <> 'AI_RATE_LIMIT' then raise; end if;
  end;
  assert (select requests from public.ai_daily_usage where user_id='22222222-2222-4222-8222-222222222222') = 6, 'Rejected reservation must not increment usage';
end $$;

rollback;
