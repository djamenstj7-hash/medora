-- Execute after migrations 001, 002 and 003 on a disposable Supabase/PostgreSQL database.
-- Assertions use two independent accounts and roll back every fixture.
begin;
insert into auth.users(id,email) values
 ('66666666-6666-4666-8666-666666666666','engine-a@example.invalid'),
 ('77777777-7777-4777-8777-777777777777','engine-b@example.invalid');
do $$ begin
  assert not has_table_privilege('anon','public.engine_imports','select'), 'Anonymous source-deck links must be private';
  assert not has_table_privilege('authenticated','public.engine_imports','insert'), 'Users cannot forge another import link';
  assert not has_table_privilege('authenticated','public.cards','update'), 'Source pointers and card contents remain server-controlled';
  assert not has_function_privilege('anon','public.install_engine_deck(text,text,text,text,jsonb)','execute'), 'Anonymous MED_ENGINE installation must be denied';
end $$;
set local role authenticated;
select set_config('request.jwt.claims','{"sub":"66666666-6666-4666-8666-666666666666","role":"authenticated"}',true);
do $$ declare result jsonb; repeated jsonb; target uuid; original_card uuid; before_schedule jsonb; before_version integer; current_decks integer; begin
  result := public.install_engine_deck('pack-a','Paquet A','Sémiologie','#007AFF','[
    {"id":"engine:pack-a:n1:cloze1","noteId":"n1","prompt":"Premier rappel ?","answer":"Réponse 1","schedule":{"reps":999,"due":"2099-01-01"},"user_id":"77777777-7777-4777-8777-777777777777"},
    {"id":"engine:pack-a:n1:cloze2","noteId":"n1","prompt":"Second rappel ?","answer":"Réponse 2"}
  ]');
  target := (result->>'deckId')::uuid;
  assert (select count(*) from public.cards where deck_id=target and status='draft') = 2, 'All distinct variants must start in draft';
  assert (select count(*) from public.cards where deck_id=target and user_id=auth.uid()) = 2, 'The owner is taken from the session, never card input';
  assert (select count(*) from public.card_schedules where card_id in(select id from public.cards where deck_id=target) and (schedule->>'reps')::integer = 0 and version=0) = 2, 'Client schedules must be ignored';
  assert (select count(distinct content->>'cardId') from public.cards where deck_id=target) = 2, 'Cloze variants retain distinct public source pointers';
  assert (select bool_and(content->>'origin'='engine' and content->>'packId'='pack-a' and content->>'noteId'='n1') from public.cards where deck_id=target), 'Pointers preserve the source note and pack';
  select id into original_card from public.cards where deck_id=target limit 1;
  select schedule,version into before_schedule,before_version from public.card_schedules where card_id=original_card;
  perform public.activate_deck(target);
  repeated := public.install_engine_deck('pack-a','Changed','Changed','#112233','[{"id":"changed","noteId":"changed","prompt":"Different","answer":"Different"}]');
  assert result->>'deckId' = repeated->>'deckId', 'Repeated installation reuses the original owner deck';
  assert (select count(*) from public.cards where deck_id=target) = 2, 'Repeated installation does not duplicate cards';
  assert (select bool_and(status='active') from public.cards where deck_id=target), 'Repeated installation preserves activation';
  assert (select schedule=before_schedule and version=before_version from public.card_schedules where card_id=original_card), 'Repeated installation never resets FSRS';
  select count(*) into current_decks from public.decks;
  begin
    perform public.install_engine_deck('invalid-pack','Invalid','Sémiologie','#007AFF','[{"id":"duplicate","noteId":"n","prompt":"A","answer":"A"},{"id":"duplicate","noteId":"n","prompt":"B","answer":"B"}]');
    raise exception 'Duplicate variants unexpectedly accepted';
  exception when invalid_parameter_value then null; end;
  assert (select count(*) from public.decks)=current_decks, 'Invalid content cannot leave an empty deck';
end $$;
select set_config('request.jwt.claims','{"sub":"77777777-7777-4777-8777-777777777777","role":"authenticated"}',true);
do $$ declare result jsonb; begin
  assert (select count(*) from public.engine_imports) = 0, 'RLS hides the first owner import links';
  assert (select count(*) from public.cards where content is not null) = 0, 'RLS hides the first owner source pointers';
  result := public.install_engine_deck('pack-a','Paquet B','Sémiologie','#007AFF','[{"id":"engine:pack-a:n1:cloze1","noteId":"n1","prompt":"B","answer":"B"}]');
  assert (select count(*) from public.engine_imports)=1, 'The same pack installs independently for another owner';
  delete from public.decks where id=(result->>'deckId')::uuid;
  assert (select count(*) from public.engine_imports)=0, 'Deleting an owned deck clears only its import link';
end $$;
reset role;
do $$ begin
  assert (select count(*) from public.engine_imports)=1, 'Another owner deletion cannot remove the original import';
  begin
    update public.cards set content='{"origin":"engine","packId":"x","cardId":"x","noteId":"x","schedule":{"reps":999}}' where content is not null;
    raise exception 'Unexpected source metadata field accepted';
  exception when check_violation then null; end;
  begin
    update public.cards set content='{"origin":"engine","packId":null,"cardId":"x","noteId":"x"}' where content is not null;
    raise exception 'Null source pointer accepted';
  exception when check_violation then null; end;
  assert (select count(*) from public.cards where content->>'packId'='pack-a')=2, 'Constraint failures preserve every existing pointer';
end $$;
rollback;
