-- Execute against a disposable/local Supabase database after migrations 001 and 002.
-- psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f supabase/tests/study-security.sql
-- This test rolls back every fixture. It never contacts an AI provider.
begin;
insert into auth.users(id,email) values
 ('33333333-3333-4333-8333-333333333333','study-a@example.invalid'),
 ('44444444-4444-4444-8444-444444444444','study-b@example.invalid');
do $$ begin
  assert not has_table_privilege('anon','public.study_events','select'), 'Anonymous study data access must be denied';
  assert not has_table_privilege('authenticated','public.study_events','update'), 'Immutable event history must not be overwritable';
  assert not has_table_privilege('authenticated','public.study_events','delete'), 'Immutable history must not be deletable by stale devices';
  assert not has_function_privilege('anon','public.install_curriculum_deck(text,text,text,text,jsonb)','execute'), 'Anonymous FSRS installation must be denied';
end $$;
set local role authenticated;
select set_config('request.jwt.claims','{"sub":"33333333-3333-4333-8333-333333333333","role":"authenticated"}',true);
insert into public.study_events(id,kind,payload,happened_at) values
 ('55555555-5555-4555-8555-555555555555','note','{"clock":1,"data":{"lessonId":"course","text":"A"}}',now());
do $$ declare result jsonb; repeated jsonb; deck uuid; begin
  begin
    insert into public.study_events(id,user_id,kind,payload,happened_at) values(gen_random_uuid(),'44444444-4444-4444-8444-444444444444','note','{"clock":1,"data":{}}',now());
    raise exception 'Cross-owner insertion unexpectedly succeeded';
  exception when insufficient_privilege then null; end;
  result := public.install_curriculum_deck('course','Cours','Cardiologie','#007AFF','[{"prompt":"Rappel ?","answer":"Réponse","schedule":{"reps":999,"due":"2099-01-01"}}]');
  deck := (result->>'deckId')::uuid;
  assert (select count(*) from public.cards where deck_id=deck and status='draft') = 1, 'Bundled cards must be draft until validation';
  assert (select (schedule->>'reps')::integer from public.card_schedules where card_id in(select id from public.cards where deck_id=deck)) = 0, 'Clients cannot choose review counts';
  perform public.activate_deck(deck);
  repeated := public.install_curriculum_deck('course','Changed','Cardiologie','#007AFF','[{"prompt":"Different","answer":"Different"}]');
  assert result->>'deckId' = repeated->>'deckId', 'Repeated installation must reuse the same owner deck';
  assert (select count(*) from public.cards where deck_id=deck) = 1, 'Repeated installation must not duplicate cards';
  assert (select status from public.cards where deck_id=deck limit 1) = 'active', 'Repeated installation must preserve activation';
end $$;

select set_config('request.jwt.claims','{"sub":"44444444-4444-4444-8444-444444444444","role":"authenticated"}',true);
do $$ declare result jsonb; begin
  assert (select count(*) from public.study_events) = 0, 'RLS must hide another owner progress';
  assert (select count(*) from public.curriculum_imports) = 0, 'RLS must hide another owner curriculum decks';
  -- A user may intentionally restore a backup exported by another account; event IDs are owner-scoped.
  insert into public.study_events(id,kind,payload,happened_at) values('55555555-5555-4555-8555-555555555555','note','{"clock":1,"data":{"lessonId":"course","text":"B"}}',now());
  assert (select count(*) from public.study_events) = 1, 'The same UUID must be importable by a different owner';
  result := public.install_curriculum_deck('course','Autre cours','Neurologie','#007AFF','[{"prompt":"B ?","answer":"B"}]');
  assert (select count(*) from public.curriculum_imports) = 1, 'Each owner has an independent curriculum deck';
end $$;
reset role;
do $$ begin
  assert (select count(*) from public.study_events where id='55555555-5555-4555-8555-555555555555') = 2, 'Both owner-scoped events must survive';
end $$;
rollback;
