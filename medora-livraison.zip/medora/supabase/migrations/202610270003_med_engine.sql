-- Additive MED_ENGINE bridge. Existing content, FSRS schedules and review logs are untouched.
alter table public.cards add column content jsonb;
alter table public.cards add constraint cards_engine_content_check check (
  content is null or (
    jsonb_typeof(content) = 'object' and octet_length(content::text) <= 4096 and
    content ?& array['origin', 'packId', 'cardId', 'noteId'] and
    content - array['origin', 'packId', 'cardId', 'noteId'] = '{}'::jsonb and
    content->>'origin' = 'engine' and
    jsonb_typeof(content->'packId') = 'string' and char_length(content->>'packId') between 1 and 200 and
    jsonb_typeof(content->'cardId') = 'string' and char_length(content->>'cardId') between 1 and 1000 and
    jsonb_typeof(content->'noteId') = 'string' and char_length(content->>'noteId') between 1 and 500
  )
);

create table public.engine_imports (
  user_id uuid not null references auth.users(id) on delete cascade,
  pack_id text not null check (char_length(pack_id) between 1 and 200),
  deck_id uuid not null,
  created_at timestamptz not null default now(),
  primary key(user_id, pack_id),
  foreign key (deck_id, user_id) references public.decks(id, user_id) on delete cascade
);
alter table public.engine_imports enable row level security;
create policy engine_imports_read on public.engine_imports for select to authenticated using (user_id = (select auth.uid()));
revoke all on public.engine_imports from public, anon, authenticated;
grant select on public.engine_imports to authenticated;
grant all on public.engine_imports to service_role;

-- The caller supplies content and public pointers, never an owner or a schedule.
create function public.install_engine_deck(p_pack_id text, p_title text, p_subject text, p_color text, p_cards jsonb) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare
  owner_id uuid := auth.uid();
  target_deck uuid;
  item jsonb;
  target_card uuid;
  count_cards integer := 0;
  fresh_due timestamptz := now();
  initial_schedule jsonb;
begin
  if owner_id is null then raise exception using errcode = '42501', message = 'Authentication required'; end if;
  if p_pack_id is null or char_length(p_pack_id) not between 1 and 200 or
     p_title is null or char_length(btrim(p_title)) not between 1 and 120 or
     p_subject is null or char_length(btrim(p_subject)) not between 1 and 80 or
     p_color is null or p_color !~ '^#[0-9A-Fa-f]{6}$' then
    raise exception using errcode = '22023', message = 'Invalid MED_ENGINE metadata';
  end if;
  perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended(owner_id::text || ':engine:' || p_pack_id, 0));
  select deck_id into target_deck from public.engine_imports where user_id = owner_id and pack_id = p_pack_id;
  if found then
    select count(*) into count_cards from public.cards where deck_id = target_deck and user_id = owner_id;
    return jsonb_build_object('deckId', target_deck, 'count', count_cards, 'existing', true);
  end if;
  if p_cards is null or jsonb_typeof(p_cards) <> 'array' then raise exception using errcode = '22023', message = 'Cards must be an array'; end if;
  if jsonb_array_length(p_cards) not between 1 and 5000 or octet_length(p_cards::text) > 25000000 then raise exception using errcode = '22023', message = 'Invalid MED_ENGINE card count or size'; end if;
  -- Every record is checked before the first write; exceptions roll back the entire import.
  for item in select value from jsonb_array_elements(p_cards) loop
    if jsonb_typeof(item) <> 'object' or
       jsonb_typeof(item->'id') is distinct from 'string' or char_length(item->>'id') not between 1 and 1000 or
       jsonb_typeof(item->'noteId') is distinct from 'string' or char_length(item->>'noteId') not between 1 and 500 or
       jsonb_typeof(item->'prompt') is distinct from 'string' or char_length(btrim(item->>'prompt')) not between 1 and 5000 or
       jsonb_typeof(item->'answer') is distinct from 'string' or char_length(btrim(item->>'answer')) not between 1 and 8000 or
       (item ? 'explanation' and (jsonb_typeof(item->'explanation') is distinct from 'string' or char_length(item->>'explanation') > 10000)) then
      raise exception using errcode = '22023', message = 'Invalid MED_ENGINE flashcard content';
    end if;
  end loop;
  if (select count(*) <> count(distinct value->>'id') from jsonb_array_elements(p_cards)) then
    raise exception using errcode = '22023', message = 'Duplicate MED_ENGINE source card';
  end if;
  insert into public.decks(user_id, title, subject, color) values(owner_id, btrim(p_title), btrim(p_subject), p_color) returning id into target_deck;
  initial_schedule := jsonb_build_object(
    'due', fresh_due, 'stability', 0, 'difficulty', 0, 'elapsed_days', 0,
    'scheduled_days', 0, 'reps', 0, 'lapses', 0, 'state', 0, 'learning_steps', 0
  );
  for item in select value from jsonb_array_elements(p_cards) loop
    insert into public.cards(user_id, deck_id, kind, prompt, answer, explanation, status, content)
      values(owner_id, target_deck, 'flashcard', btrim(item->>'prompt'), btrim(item->>'answer'), coalesce(item->>'explanation', ''), 'draft',
        jsonb_build_object('origin', 'engine', 'packId', p_pack_id, 'cardId', item->>'id', 'noteId', item->>'noteId')) returning id into target_card;
    insert into public.card_schedules(card_id, user_id, schedule, due) values(target_card, owner_id, initial_schedule, fresh_due);
    count_cards := count_cards + 1;
  end loop;
  insert into public.engine_imports(user_id, pack_id, deck_id) values(owner_id, p_pack_id, target_deck);
  return jsonb_build_object('deckId', target_deck, 'count', count_cards, 'existing', false);
end;
$$;
revoke all on function public.install_engine_deck(text, text, text, text, jsonb) from public, anon;
grant execute on function public.install_engine_deck(text, text, text, text, jsonb) to authenticated;
