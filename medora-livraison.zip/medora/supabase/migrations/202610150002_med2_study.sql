-- Additive MED2 integration. Existing decks, FSRS schedules and review logs are unchanged.
create table public.study_events (
  id uuid not null,
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  kind text not null check (kind in ('read', 'bookmark', 'note', 'last-read', 'attempt', 'session', 'exam', 'settings', 'lesson-review', 'writing', 'active-session', 'legacy', 'catalogue', 'reset-progress', 'mission-add', 'mission-remove')),
  payload jsonb not null check (jsonb_typeof(payload) = 'object' and octet_length(payload::text) <= 5242880),
  happened_at timestamptz not null,
  created_at timestamptz not null default now(),
  primary key (user_id, id),
  check (payload ? 'clock' and payload ? 'data' and jsonb_typeof(payload->'clock') = 'number' and jsonb_typeof(payload->'data') = 'object')
);
create index study_events_owner_idx on public.study_events(user_id, id);
alter table public.study_events enable row level security;
create policy study_events_read on public.study_events for select to authenticated using (user_id = (select auth.uid()));
create policy study_events_insert on public.study_events for insert to authenticated with check (user_id = (select auth.uid()));
revoke all on public.study_events from public, anon, authenticated;
grant select, insert on public.study_events to authenticated;
grant all on public.study_events to service_role;
-- No UPDATE or DELETE grant: history cannot be replaced by a stale device snapshot.

create table public.curriculum_imports (
  user_id uuid not null references auth.users(id) on delete cascade,
  lesson_id text not null check (char_length(lesson_id) between 1 and 200),
  deck_id uuid not null,
  created_at timestamptz not null default now(),
  primary key(user_id, lesson_id),
  foreign key (deck_id, user_id) references public.decks(id, user_id) on delete cascade
);
alter table public.curriculum_imports enable row level security;
create policy curriculum_imports_read on public.curriculum_imports for select to authenticated using (user_id = (select auth.uid()));
revoke all on public.curriculum_imports from public, anon, authenticated;
grant select on public.curriculum_imports to authenticated;
grant all on public.curriculum_imports to service_role;

-- Owner-only, idempotent bridge from bundled recall cards to the existing FSRS library.
-- The client supplies content, never a schedule, a review count, an owner or a due date.
create function public.install_curriculum_deck(p_lesson_id text, p_title text, p_subject text, p_color text, p_cards jsonb) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare
  owner_id uuid := auth.uid();
  target_deck uuid;
  item jsonb;
  target_card uuid;
  count_cards integer := 0;
  fresh_due timestamptz := now();
  initial_schedule jsonb;
begin
  if owner_id is null then raise exception using errcode = '42501', message = 'Authentication required'; end if;
  if p_lesson_id is null or char_length(p_lesson_id) not between 1 and 200 or
     p_title is null or char_length(btrim(p_title)) not between 1 and 120 or
     p_subject is null or char_length(btrim(p_subject)) not between 1 and 80 or
     p_color is null or p_color !~ '^#[0-9A-Fa-f]{6}$' then
    raise exception using errcode = '22023', message = 'Invalid deck metadata';
  end if;
  perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended(owner_id::text || ':' || p_lesson_id, 0));
  select deck_id into target_deck from public.curriculum_imports where user_id = owner_id and lesson_id = p_lesson_id;
  if found then
    select count(*) into count_cards from public.cards where deck_id = target_deck and user_id = owner_id;
    return jsonb_build_object('deckId', target_deck, 'count', count_cards, 'existing', true);
  end if;
  if p_cards is null or jsonb_typeof(p_cards) <> 'array' then raise exception using errcode = '22023', message = 'Cards must be an array'; end if;
  if jsonb_array_length(p_cards) not between 1 and 200 or octet_length(p_cards::text) > 3000000 then raise exception using errcode = '22023', message = 'Invalid card count or size'; end if;
  -- Validate all content before creating anything. SQL exceptions roll back the entire call.
  for item in select value from jsonb_array_elements(p_cards) loop
    if jsonb_typeof(item) <> 'object' or jsonb_typeof(item->'prompt') is distinct from 'string' or
       jsonb_typeof(item->'answer') is distinct from 'string' or
       char_length(item->>'prompt') not between 1 and 5000 or char_length(item->>'answer') not between 1 and 8000 or
       (item ? 'explanation' and (jsonb_typeof(item->'explanation') is distinct from 'string' or char_length(item->>'explanation') > 10000)) then
      raise exception using errcode = '22023', message = 'Invalid flashcard content';
    end if;
  end loop;
  insert into public.decks(user_id, title, subject, color) values(owner_id, btrim(p_title), btrim(p_subject), p_color) returning id into target_deck;
  initial_schedule := jsonb_build_object(
    'due', fresh_due, 'stability', 0, 'difficulty', 0, 'elapsed_days', 0,
    'scheduled_days', 0, 'reps', 0, 'lapses', 0, 'state', 0, 'learning_steps', 0
  );
  for item in select value from jsonb_array_elements(p_cards) loop
    insert into public.cards(user_id, deck_id, kind, prompt, answer, explanation, status)
      values(owner_id, target_deck, 'flashcard', item->>'prompt', item->>'answer', coalesce(item->>'explanation', ''), 'draft') returning id into target_card;
    insert into public.card_schedules(card_id, user_id, schedule, due) values(target_card, owner_id, initial_schedule, fresh_due);
    count_cards := count_cards + 1;
  end loop;
  insert into public.curriculum_imports(user_id, lesson_id, deck_id) values(owner_id, p_lesson_id, target_deck);
  return jsonb_build_object('deckId', target_deck, 'count', count_cards, 'existing', false);
end;
$$;
revoke all on function public.install_curriculum_deck(text, text, text, text, jsonb) from public, anon;
grant execute on function public.install_curriculum_deck(text, text, text, text, jsonb) to authenticated;
