-- Medora: private-by-default study data and atomic server operations.
create extension if not exists pgcrypto with schema extensions;

create table public.decks (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade default auth.uid(),
  title text not null check (char_length(title) between 1 and 120),
  subject text not null check (char_length(subject) between 1 and 80),
  color text not null default '#007AFF' check (color ~ '^#[0-9A-Fa-f]{6}$'),
  created_at timestamptz not null default now(),
  unique(id, user_id)
);

create table public.documents (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade default auth.uid(),
  deck_id uuid not null,
  storage_path text,
  name text not null check (char_length(name) between 1 and 255),
  status text not null default 'uploaded' check (status in ('uploaded', 'generating', 'needs_review', 'completed', 'failed')),
  created_at timestamptz not null default now(),
  unique(id, user_id),
  foreign key (deck_id, user_id) references public.decks(id, user_id) on delete cascade,
  check (storage_path is null or split_part(storage_path, '/', 1) = user_id::text)
);

create table public.cards (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  deck_id uuid not null,
  document_id uuid,
  kind text not null check (kind in ('flashcard', 'qcm', 'case')),
  prompt text not null check (char_length(prompt) between 1 and 5000),
  answer text not null check (char_length(answer) between 1 and 8000),
  explanation text not null default '' check (char_length(explanation) <= 10000),
  options jsonb not null default '[]'::jsonb check (jsonb_typeof(options) = 'array'),
  correct_option_id text,
  source_excerpt text check (char_length(source_excerpt) <= 1600),
  status text not null default 'draft' check (status in ('draft', 'active')),
  created_at timestamptz not null default now(),
  unique(id, user_id),
  foreign key (deck_id, user_id) references public.decks(id, user_id) on delete cascade,
  foreign key (document_id, user_id) references public.documents(id, user_id) on delete cascade
);

create table public.card_schedules (
  card_id uuid primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  schedule jsonb not null check (jsonb_typeof(schedule) = 'object'),
  due timestamptz not null,
  version integer not null default 0 check (version >= 0),
  foreign key (card_id, user_id) references public.cards(id, user_id) on delete cascade
);

create table public.review_logs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  card_id uuid not null,
  client_event_id uuid not null,
  rating integer not null check (rating between 1 and 4),
  reviewed_at timestamptz not null,
  received_at timestamptz not null default now(),
  before_schedule jsonb not null,
  after_schedule jsonb not null,
  schedule_version integer not null,
  scheduler_version text not null default 'ts-fsrs@5.2.3',
  unique(user_id, client_event_id),
  foreign key (card_id, user_id) references public.cards(id, user_id) on delete cascade
);

create table public.feynman_attempts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  concept text not null,
  response_text text not null,
  assessment jsonb not null check (jsonb_typeof(assessment) = 'object'),
  created_at timestamptz not null default now()
);

-- Internal tables: never exposed through grants to anon/authenticated.
create table public.ai_daily_usage (
  user_id uuid not null references auth.users(id) on delete cascade,
  usage_date date not null,
  requests integer not null default 0,
  primary key (user_id, usage_date)
);
create table public.ai_runs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  document_id uuid references public.documents(id) on delete cascade,
  task text not null check (task in ('generate-quiz', 'evaluate-feynman')),
  status text not null default 'pending' check (status in ('pending', 'completed', 'failed')),
  model text,
  usage jsonb,
  error_code text,
  created_at timestamptz not null default now(),
  completed_at timestamptz
);

create index decks_user_idx on public.decks(user_id, created_at desc);
create index documents_deck_idx on public.documents(user_id, deck_id);
create index cards_deck_idx on public.cards(user_id, deck_id, status);
create index cards_document_idx on public.cards(document_id);
create index schedules_due_idx on public.card_schedules(user_id, due);
create index reviews_user_date_idx on public.review_logs(user_id, reviewed_at desc);
create index feynman_user_date_idx on public.feynman_attempts(user_id, created_at desc);
create index ai_runs_user_date_idx on public.ai_runs(user_id, created_at desc);

alter table public.decks enable row level security;
alter table public.documents enable row level security;
alter table public.cards enable row level security;
alter table public.card_schedules enable row level security;
alter table public.review_logs enable row level security;
alter table public.feynman_attempts enable row level security;
alter table public.ai_daily_usage enable row level security;
alter table public.ai_runs enable row level security;

create policy decks_read on public.decks for select to authenticated using (user_id = (select auth.uid()));
create policy decks_insert on public.decks for insert to authenticated with check (user_id = (select auth.uid()));
create policy decks_update on public.decks for update to authenticated using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));
create policy decks_delete on public.decks for delete to authenticated using (user_id = (select auth.uid()));
create policy documents_read on public.documents for select to authenticated using (user_id = (select auth.uid()));
create policy documents_insert on public.documents for insert to authenticated with check (user_id = (select auth.uid()) and status = 'uploaded');
create policy cards_read on public.cards for select to authenticated using (user_id = (select auth.uid()));
create policy schedules_read on public.card_schedules for select to authenticated using (user_id = (select auth.uid()));
create policy reviews_read on public.review_logs for select to authenticated using (user_id = (select auth.uid()));
create policy feynman_read on public.feynman_attempts for select to authenticated using (user_id = (select auth.uid()));

revoke all on public.decks, public.documents, public.cards, public.card_schedules, public.review_logs, public.feynman_attempts, public.ai_daily_usage, public.ai_runs from anon, authenticated;
grant select, insert, update, delete on public.decks to authenticated;
grant select, insert on public.documents to authenticated;
grant select on public.cards, public.card_schedules, public.review_logs, public.feynman_attempts to authenticated;
grant all on public.decks, public.documents, public.cards, public.card_schedules, public.review_logs, public.feynman_attempts, public.ai_daily_usage, public.ai_runs to service_role;

create function public.activate_deck(p_deck_id uuid) returns integer
language plpgsql security definer set search_path = '' as $$
declare changed integer;
begin
  if auth.uid() is null or not exists (select 1 from public.decks where id = p_deck_id and user_id = auth.uid()) then
    raise exception using errcode = '42501', message = 'Deck inaccessible';
  end if;
  update public.cards set status = 'active' where deck_id = p_deck_id and user_id = auth.uid() and status = 'draft';
  get diagnostics changed = row_count;
  update public.documents set status = 'completed' where deck_id = p_deck_id and user_id = auth.uid() and status = 'needs_review';
  return changed;
end;
$$;
revoke all on function public.activate_deck(uuid) from public, anon;
grant execute on function public.activate_deck(uuid) to authenticated;

-- Locks per user make the per-minute and per-day limits atomic (including parallel calls).
-- Failed provider calls consume a reservation too, preventing retry abuse.
create function public.reserve_ai_run(p_user_id uuid, p_task text, p_document_id uuid default null) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare run_id uuid; count_cards integer; document_status text; used integer;
begin
  if p_task not in ('generate-quiz', 'evaluate-feynman') then raise exception 'Unknown task'; end if;
  perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended(p_user_id::text, 0));
  if p_task = 'generate-quiz' then
    select status into document_status from public.documents where id = p_document_id and user_id = p_user_id for update;
    if not found then raise exception using errcode = '42501', message = 'Document inaccessible'; end if;
    select count(*) into count_cards from public.cards where document_id = p_document_id and user_id = p_user_id;
    if count_cards > 0 then return jsonb_build_object('cached', true, 'count', count_cards); end if;
    if document_status = 'generating' and exists (
      select 1 from public.ai_runs where document_id = p_document_id and status = 'pending' and created_at > now() - interval '3 minutes'
    ) then raise exception using errcode = '55P03', message = 'Generation already running'; end if;
    update public.ai_runs set status = 'failed', error_code = 'expired', completed_at = now()
      where document_id = p_document_id and status = 'pending';
  end if;
  if (select count(*) from public.ai_runs where user_id = p_user_id and created_at > now() - interval '1 minute') >= 6 then
    raise exception using errcode = 'P0001', message = 'AI_RATE_LIMIT';
  end if;
  insert into public.ai_daily_usage(user_id, usage_date, requests) values (p_user_id, (now() at time zone 'UTC')::date, 1)
  on conflict (user_id, usage_date) do update set requests = public.ai_daily_usage.requests + 1
  where public.ai_daily_usage.requests < 40 returning requests into used;
  if used is null then raise exception using errcode = 'P0001', message = 'AI_DAILY_LIMIT'; end if;
  insert into public.ai_runs(user_id, document_id, task) values (p_user_id, p_document_id, p_task) returning id into run_id;
  if p_task = 'generate-quiz' then update public.documents set status = 'generating' where id = p_document_id; end if;
  return jsonb_build_object('cached', false, 'run_id', run_id);
end;
$$;

create function public.finish_generation(p_user_id uuid, p_run_id uuid, p_cards jsonb, p_model text, p_usage jsonb default null) returns integer
language plpgsql security definer set search_path = '' as $$
declare run public.ai_runs%rowtype; doc public.documents%rowtype; item jsonb; new_card uuid; generated integer := 0;
begin
  perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended(p_user_id::text, 0));
  select * into run from public.ai_runs where id = p_run_id and user_id = p_user_id and task = 'generate-quiz' for update;
  if not found or run.status <> 'pending' then raise exception using errcode = '40001', message = 'Generation expired'; end if;
  select * into doc from public.documents where id = run.document_id and user_id = p_user_id for update;
  if not found then raise exception using errcode = '42501', message = 'Document inaccessible'; end if;
  if jsonb_typeof(p_cards) <> 'array' or jsonb_array_length(p_cards) not between 1 and 12 then raise exception 'Invalid cards'; end if;
  for item in select value from jsonb_array_elements(p_cards) loop
    insert into public.cards(user_id, deck_id, document_id, kind, prompt, answer, explanation, options, correct_option_id, source_excerpt)
    values (p_user_id, doc.deck_id, doc.id, item->>'kind', item->>'prompt', item->>'answer', item->>'explanation', item->'options', item->>'correct_option_id', item->>'source_excerpt') returning id into new_card;
    insert into public.card_schedules(card_id, user_id, schedule, due)
    values (new_card, p_user_id, item->'schedule', (item->'schedule'->>'due')::timestamptz);
    generated := generated + 1;
  end loop;
  update public.documents set status = 'needs_review' where id = doc.id;
  update public.ai_runs set status = 'completed', model = p_model, usage = p_usage, completed_at = now() where id = run.id;
  return generated;
end;
$$;

create function public.finish_feynman(p_user_id uuid, p_run_id uuid, p_concept text, p_response text, p_assessment jsonb, p_model text, p_usage jsonb default null) returns uuid
language plpgsql security definer set search_path = '' as $$
declare attempt_id uuid;
begin
  perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended(p_user_id::text, 0));
  perform 1 from public.ai_runs where id = p_run_id and user_id = p_user_id and task = 'evaluate-feynman' and status = 'pending' for update;
  if not found then raise exception using errcode = '40001', message = 'Evaluation expired'; end if;
  insert into public.feynman_attempts(user_id, concept, response_text, assessment) values (p_user_id, p_concept, p_response, p_assessment) returning id into attempt_id;
  update public.ai_runs set status = 'completed', model = p_model, usage = p_usage, completed_at = now() where id = p_run_id;
  return attempt_id;
end;
$$;

create function public.fail_ai_run(p_user_id uuid, p_run_id uuid, p_error_code text) returns void
language plpgsql security definer set search_path = '' as $$
declare doc_id uuid;
begin
  perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended(p_user_id::text, 0));
  update public.ai_runs set status = 'failed', error_code = left(p_error_code, 80), completed_at = now()
    where id = p_run_id and user_id = p_user_id and status = 'pending' returning document_id into doc_id;
  if doc_id is not null then update public.documents set status = 'failed' where id = doc_id and user_id = p_user_id and status = 'generating'; end if;
end;
$$;

create function public.commit_review(p_user_id uuid, p_card_id uuid, p_expected_version integer, p_client_event_id uuid, p_rating integer, p_reviewed_at timestamptz, p_after jsonb) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare current_row public.card_schedules%rowtype; previous_event public.review_logs%rowtype;
begin
  -- User-wide event lock makes replay safe even when two requests arrive together.
  perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended(p_user_id::text || p_client_event_id::text, 0));
  select * into previous_event from public.review_logs where user_id = p_user_id and client_event_id = p_client_event_id;
  if found then
    if previous_event.card_id <> p_card_id or previous_event.rating <> p_rating or previous_event.reviewed_at <> p_reviewed_at then
      raise exception using errcode = '40001', message = 'Event identity conflict';
    end if;
    return jsonb_build_object('schedule', previous_event.after_schedule, 'version', previous_event.schedule_version, 'duplicate', true);
  end if;
  select * into current_row from public.card_schedules where card_id = p_card_id and user_id = p_user_id for update;
  if not found or not exists (select 1 from public.cards where id = p_card_id and user_id = p_user_id and status = 'active') then
    raise exception using errcode = '42501', message = 'Card inaccessible';
  end if;
  if current_row.version <> p_expected_version then raise exception using errcode = '40001', message = 'Schedule conflict'; end if;
  if p_reviewed_at > now() + interval '5 minutes' or p_reviewed_at < now() - interval '30 days' then raise exception using errcode = '22023', message = 'Review timestamp outside accepted window'; end if;
  if current_row.schedule->>'last_review' is not null and p_reviewed_at < (current_row.schedule->>'last_review')::timestamptz then
    raise exception using errcode = '40001', message = 'Review out of order';
  end if;
  insert into public.review_logs(user_id, card_id, client_event_id, rating, reviewed_at, before_schedule, after_schedule, schedule_version)
    values (p_user_id, p_card_id, p_client_event_id, p_rating, p_reviewed_at, current_row.schedule, p_after, current_row.version + 1);
  update public.card_schedules set schedule = p_after, due = (p_after->>'due')::timestamptz, version = version + 1 where card_id = p_card_id;
  return jsonb_build_object('schedule', p_after, 'version', current_row.version + 1, 'duplicate', false);
end;
$$;

revoke all on function public.reserve_ai_run(uuid, text, uuid) from public, anon, authenticated;
revoke all on function public.finish_generation(uuid, uuid, jsonb, text, jsonb) from public, anon, authenticated;
revoke all on function public.finish_feynman(uuid, uuid, text, text, jsonb, text, jsonb) from public, anon, authenticated;
revoke all on function public.fail_ai_run(uuid, uuid, text) from public, anon, authenticated;
revoke all on function public.commit_review(uuid, uuid, integer, uuid, integer, timestamptz, jsonb) from public, anon, authenticated;
grant execute on function public.reserve_ai_run(uuid, text, uuid) to service_role;
grant execute on function public.finish_generation(uuid, uuid, jsonb, text, jsonb) to service_role;
grant execute on function public.finish_feynman(uuid, uuid, text, text, jsonb, text, jsonb) to service_role;
grant execute on function public.fail_ai_run(uuid, uuid, text) to service_role;
grant execute on function public.commit_review(uuid, uuid, integer, uuid, integer, timestamptz, jsonb) to service_role;

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('courses', 'courses', false, 15728640, array['application/pdf', 'text/plain', 'text/markdown'])
on conflict (id) do update set public = false, file_size_limit = excluded.file_size_limit, allowed_mime_types = excluded.allowed_mime_types;
create policy courses_read on storage.objects for select to authenticated
  using (bucket_id = 'courses' and (storage.foldername(name))[1] = (select auth.uid())::text);
create policy courses_insert on storage.objects for insert to authenticated
  with check (bucket_id = 'courses' and (storage.foldername(name))[1] = (select auth.uid())::text);
create policy courses_delete on storage.objects for delete to authenticated
  using (bucket_id = 'courses' and (storage.foldername(name))[1] = (select auth.uid())::text);
