import { useEffect, useId, useState } from 'react';
import { Check, CheckCheck, ExternalLink, RotateCcw } from 'lucide-react';
import type { Question } from '../lib/curriculum';
import { safeExternalUrl } from '../lib/curriculum';
import { gradeChoices, matchQrocKeywords } from '../lib/study';
import '../course-reader.css';

export interface StudyAnswer { correct: boolean; selected: number[]; responseText?: string }
export interface StudyQuestionProps {
  question: Question;
  mode?: 'practice' | 'exam';
  onAnswered?: (result: StudyAnswer) => void;
  reveal?: boolean;
  disabled?: boolean;
  initialAnswer?: { selected: number[]; responseText?: string; correct?: boolean };
  initialResponse?: string;
  onSaveDraft?: (response: string) => Promise<void>;
}

/** Only the simple **bold** convention is supported. Course content never becomes HTML. */
export function InlineText({ text }: { text: string }) {
  return <>{String(text).split(/(\*\*[^*]+\*\*)/g).map((part, index) => part.startsWith('**') && part.endsWith('**') ? <strong key={index}>{part.slice(2, -2)}</strong> : part)}</>;
}

export default function StudyQuestion({ question, mode = 'practice', onAnswered, reveal = false, disabled = false, initialAnswer, initialResponse, onSaveDraft }: StudyQuestionProps) {
  const uid = useId();
  const [selected, setSelected] = useState<number[]>(initialAnswer?.selected || []);
  const [response, setResponse] = useState(initialAnswer?.responseText ?? initialResponse ?? '');
  const [submitted, setSubmitted] = useState(Boolean(initialAnswer));
  const [selfGrade, setSelfGrade] = useState<boolean | undefined>(initialAnswer?.correct);
  const [showModel, setShowModel] = useState(Boolean(initialAnswer) && mode !== 'exam');
  const [draftBusy, setDraftBusy] = useState(false);
  const [draftMessage, setDraftMessage] = useState('');
  useEffect(() => {
    setSelected(initialAnswer?.selected || []);
    setResponse(initialAnswer?.responseText ?? initialResponse ?? '');
    setSubmitted(Boolean(initialAnswer));
    setSelfGrade(initialAnswer?.correct);
    setShowModel(Boolean(initialAnswer) && mode !== 'exam');
    // A question's persisted answer is supplied at mount. Parent keys each session/question.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [question.id]);
  const choiceQuestion = question.options.length > 0;
  // The source sometimes labels a single correct choice QRM; use its actual answer set.
  const multiple = question.correct.length > 1;
  const shown = reveal || (mode === 'practice' && (choiceQuestion ? submitted : showModel));
  const isCorrect = choiceQuestion ? gradeChoices(selected, question.correct) : selfGrade;
  const locked = submitted || disabled || reveal;
  const sourceUrl = safeExternalUrl(question.source?.url);
  const annaleUrl = safeExternalUrl(typeof question.annaleUrl === 'string' ? question.annaleUrl : undefined);
  const pages = question.pages || question.source?.pages || question.source?.page;
  const lexical = !choiceQuestion && shown && question.expected?.length ? matchQrocKeywords(response, question.expected) : undefined;
  function choose(index: number) {
    if (locked) return;
    setSelected((current) => multiple ? current.includes(index) ? current.filter((value) => value !== index) : [...current, index] : [index]);
  }
  function submitChoice() {
    if (!selected.length || locked) return;
    setSubmitted(true);
    onAnswered?.({ correct: gradeChoices(selected, question.correct), selected: [...selected] });
  }
  function gradeResponse(correct: boolean) {
    if (submitted || disabled) return;
    setSelfGrade(correct);
    setSubmitted(true);
    onAnswered?.({ correct, selected: [], responseText: response.trim() });
  }
  async function saveDraft() {
    if (!onSaveDraft) return;
    setDraftBusy(true); setDraftMessage('');
    try { await onSaveDraft(response); setDraftMessage('Brouillon enregistré.'); }
    catch (error) { setDraftMessage(error instanceof Error ? error.message : 'Le brouillon n’a pas pu être enregistré.'); }
    finally { setDraftBusy(false); }
  }
  return <article className="study-question" aria-labelledby={`${uid}-prompt`}>
    <div className="sq-meta"><span className="sq-format">{choiceQuestion ? multiple ? 'QRM' : 'QRU' : question.format === 'QR' ? 'Rédaction' : 'QROC'}</span>{question.origin && <span className="sq-origin">{question.origin.replaceAll('_', ' ')}</span>}{typeof question.prob === 'number' && question.prob > 0 && <span className="sq-origin" title="Indice historique fourni dans l’archive, sans valeur prédictive garantie">Indice d’annales d’origine : {question.prob}/3</span>}</div>
    <h3 id={`${uid}-prompt`}><InlineText text={question.prompt} /></h3>
    {choiceQuestion ? <>
      <p className="sq-hint">{multiple ? 'Sélectionnez toutes les propositions exactes, puis validez.' : 'Sélectionnez une proposition, puis validez.'}</p>
      <fieldset className="sq-options" disabled={locked}><legend className="cr-sr-only">Votre réponse</legend>{question.options.map((option, index) => {
        const picked = selected.includes(index);
        const correct = question.correct.includes(index);
        return <label key={`${question.id}-${index}`} className={`sq-option ${picked ? 'is-selected' : ''} ${shown && correct ? 'is-correct' : shown && picked && !correct ? 'is-incorrect' : ''}`}>
          <input type={multiple ? 'checkbox' : 'radio'} name={`${uid}-answer`} checked={picked} onChange={() => choose(index)} />
          <span className="sq-letter" aria-hidden="true">{String.fromCharCode(65 + index)}</span><span><InlineText text={option} /></span>{shown && correct && <Check size={17} aria-label="Proposition exacte" />}
        </label>;
      })}</fieldset>
      {!submitted && !reveal && <button className="cr-primary" onClick={submitChoice} disabled={!selected.length || disabled}>Valider ma réponse <Check size={17} /></button>}
      {submitted && !shown && <p className="sq-saved" role="status"><CheckCheck size={17} />Réponse enregistrée. Correction à la fin de l’épreuve.</p>}
    </> : <>
      <label className="sq-input-label" htmlFor={`${uid}-response`}>Votre explication, avec vos mots</label>
      <textarea id={`${uid}-response`} value={response} disabled={submitted || disabled || reveal} onChange={(event) => setResponse(event.target.value)} rows={6} placeholder="Expliquez votre raisonnement avant de consulter le corrigé…" maxLength={20000} />
      {onSaveDraft && !submitted && !disabled && !reveal && <><button className="cr-secondary sq-save-draft" disabled={draftBusy} onClick={() => void saveDraft()}>{draftBusy ? 'Enregistrement…' : 'Enregistrer le brouillon'}</button>{draftMessage && <p className="sq-hint" role="status">{draftMessage}</p>}</>}
      {!shown && !submitted && <button className="cr-primary" disabled={!response.trim() || disabled} onClick={() => setShowModel(true)}>Comparer au corrigé <Check size={17} /></button>}
      {mode === 'exam' && !shown && !submitted && <p className="sq-hint">Exercice rédactionnel : l’autoévaluation exige la consultation du corrigé. Il ne donne pas lieu à une note médicale automatique.</p>}
    </>}
    {(shown || (!choiceQuestion && showModel)) && <div className={`sq-feedback ${choiceQuestion ? isCorrect ? 'good' : 'again' : ''}`} role="status">
      <strong>{choiceQuestion ? isCorrect ? 'Réponse exacte' : 'À revoir' : 'Corrigé de référence'}</strong>
      {choiceQuestion && <p>Réponse{question.correct.length > 1 ? 's' : ''} attendue{question.correct.length > 1 ? 's' : ''} : <b>{question.correct.map((index) => String.fromCharCode(65 + index)).join(', ')}</b>. {multiple && 'L’ensemble des réponses doit correspondre exactement.'}</p>}
      {!choiceQuestion && question.model && <p><InlineText text={question.model} /></p>}
      {!choiceQuestion && Boolean(question.criteria?.length) && <><h4>Critères à vérifier</h4><ul>{question.criteria?.map((criterion, index) => <li key={index}><InlineText text={criterion} /></li>)}</ul></>}
      {!choiceQuestion && question.min && <p>La consigne d’origine attend au moins {question.min} repère(s). Vérifiez leur sens et leur contexte dans votre réponse.</p>}
      {question.explanation && <p><InlineText text={question.explanation} /></p>}
      {lexical && <details className="sq-lexical"><summary>Repérage de mots-clés — aide locale, sans IA</summary><p>Ce repérage lexical ne juge pas la justesse médicale, le raisonnement ni toutes les négations. Comparez votre réponse au corrigé.</p>{lexical.matched.length > 0 && <p><b>Termes repérés :</b> {lexical.matched.join(' ; ')}</p>}{lexical.missing.length > 0 && <p><b>À vérifier :</b> {lexical.missing.join(' ; ')}</p>}{lexical.negated.length > 0 && <p><b>Négation détectée :</b> {lexical.negated.join(' ; ')}</p>}{lexical.warning && <p>{lexical.warning}</p>}</details>}
      {!choiceQuestion && !submitted && !disabled && <div className="sq-self-assessment"><p>Après comparaison, comment évaluez-vous votre réponse ?</p><div><button className="cr-secondary" onClick={() => gradeResponse(false)}><RotateCcw size={16} />À retravailler</button><button className="cr-primary" onClick={() => gradeResponse(true)}><Check size={16} />Éléments retrouvés</button></div></div>}
      {!choiceQuestion && submitted && <p className="sq-hint">Autoévaluation enregistrée : {selfGrade ? 'éléments retrouvés' : 'à retravailler'}.</p>}
      {(pages || question.source?.label || sourceUrl || annaleUrl) && <div className="sq-source">{pages && <span>Source : PDF p. {String(pages)}</span>}{question.source?.label && <span>{question.source.label}</span>}{typeof question.annaleReference === 'string' && <span>{question.annaleReference}</span>}{sourceUrl && <a href={sourceUrl} target="_blank" rel="noopener noreferrer">Ouvrir la source <ExternalLink size={13} /></a>}{annaleUrl && annaleUrl !== sourceUrl && <a href={annaleUrl} target="_blank" rel="noopener noreferrer">Ouvrir le sujet d’annales cité <ExternalLink size={13} /></a>}</div>}
    </div>}
  </article>;
}
