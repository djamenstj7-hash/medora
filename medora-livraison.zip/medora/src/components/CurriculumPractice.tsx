import { useEffect, useRef, useState } from 'react';
import { BookOpen, CheckCircle2, ChevronLeft, ChevronRight, Clock3, Pause, Play, RotateCcw, X } from 'lucide-react';
import { loadTraining, type CurriculumManifest } from '../lib/curriculum';
import { study, type StudyState } from '../lib/study';
import { latestQuestionAttempts } from '../lib/study-plan';
import { elapsedMilliseconds, isTrainingSession, pausedSession, restoreTrainingItems, sampleTraining, type TrainingItem, type TrainingSession } from '../lib/training-session';
import StudyQuestion, { type StudyAnswer } from './StudyQuestion';
import '../curriculum-tools.css';

interface Props { manifest: CurriculumManifest; onOpenLesson: (id: string) => void }
const clock = (seconds: number) => `${Math.floor(seconds / 60).toString().padStart(2, '0')}:${Math.floor(seconds % 60).toString().padStart(2, '0')}`;

export default function CurriculumPractice({ manifest, onOpenLesson }: Props) {
  const [state, setState] = useState<StudyState>();
  const [subjectId, setSubjectId] = useState('all');
  const [bank, setBank] = useState<'qi' | 'cases' | 'mixed'>('mixed');
  const [format, setFormat] = useState<'all' | 'QRU' | 'QRM'>('all');
  const [mode, setMode] = useState<'practice' | 'exam'>('practice');
  const [count, setCount] = useState(10);
  const [weakOnly, setWeakOnly] = useState(false);
  const [duration, setDuration] = useState(20);
  const [session, setSession] = useState<TrainingSession | null>(null);
  const [items, setItems] = useState<TrainingItem[]>([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [tick, setTick] = useState(Date.now());
  const [confirmEnd, setConfirmEnd] = useState(false);
  const [reviewWrong, setReviewWrong] = useState(false);
  const sessionRef = useRef(session);
  const ownerRef = useRef<string | undefined>(undefined);
  sessionRef.current = session;
  useEffect(() => {
    let live = true;
    const load = () => { study.ownerScope().then(async (owner) => { const value = await study.load(); if (live) { ownerRef.current ??= owner; setState(value); } }).catch((reason: Error) => { if (live) setError(reason.message); }); };
    load(); const unsubscribe = study.subscribe(load);
    return () => { live = false; unsubscribe(); };
  }, []);
  useEffect(() => {
    if (!session || session.finishedAt) return;
    // Store a paused snapshot: reopening never counts hours spent outside the exercise.
    study.saveActiveSession(pausedSession(session) as unknown as Record<string, unknown>, ownerRef.current).catch((reason: Error) => setError(reason.message));
  }, [session]);
  useEffect(() => {
    const handleVisibility = () => {
      if (document.visibilityState === 'hidden') setSession((current) => current && !current.finishedAt ? pausedSession(current) : current);
    };
    document.addEventListener('visibilitychange', handleVisibility);
    return () => {
      document.removeEventListener('visibilitychange', handleVisibility);
      const current = sessionRef.current;
      if (current && !current.finishedAt && ownerRef.current) void study.saveActiveSession(pausedSession(current) as unknown as Record<string, unknown>, ownerRef.current).catch(() => undefined);
    };
  }, []);
  useEffect(() => {
    if (!session || session.runningSince === null || session.finishedAt) return;
    const timer = window.setInterval(() => setTick(Date.now()), 1000);
    return () => window.clearInterval(timer);
  }, [session?.runningSince, session?.finishedAt]);

  const elapsed = session ? Math.floor(elapsedMilliseconds(session, tick) / 1000) : 0;
  const remaining = session?.limitSeconds ? Math.max(0, session.limitSeconds - elapsed) : null;
  useEffect(() => {
    if (remaining !== 0 || !session || session.finishedAt || session.runningSince === null) return;
    setSession((current) => current ? pausedSession(current) : current); setConfirmEnd(true);
  }, [remaining, session]);

  const saved = state?.activeSession;
  const resumable = isTrainingSession(saved) ? saved : null;
  const weakIds = new Set(state ? [...latestQuestionAttempts(state).values()].filter((attempt) => !attempt.correct).map((attempt) => attempt.questionId) : []);
  const allowedSubjects = manifest.subjects.filter((subject) => manifest.trainingSubjectIds.includes(subject.id));
  const currentItem = session ? items[session.index] : undefined;
  const currentAnswer = session && currentItem ? session.answers[currentItem.question.id] : undefined;
  const attempts = session ? Object.values(session.answers) : [];
  const correctCount = attempts.filter((answer) => answer.correct).length;
  const resultGroups = new Map<string, { title: string; lessonId?: string; answered: number; correct: number; total: number }>();
  if (session?.finishedAt) for (const item of items) {
    const lesson = manifest.lessons.find((candidate) => candidate.id === item.question.lessonId);
    const chapter = item.question.chapterIndex;
    const key = `${item.question.lessonId || item.question.subjectId}-${chapter ?? 'course'}`;
    const entry = resultGroups.get(key) || { title: `${lesson?.title || manifest.subjects.find((subject) => subject.id === item.question.subjectId)?.name || 'Questions'}${chapter !== undefined && lesson?.chapterTitles[chapter] ? ` · ${lesson.chapterTitles[chapter]}` : ''}`, lessonId: item.question.lessonId, answered: 0, correct: 0, total: 0 };
    entry.total++;
    if (session.answers[item.question.id]) { entry.answered++; if (session.answers[item.question.id].correct) entry.correct++; }
    resultGroups.set(key, entry);
  }
  const selectedSubject = manifest.subjects.find((subject) => subject.id === subjectId);
  const subjectMode = selectedSubject ? manifest.modalities.subjectModes[subjectId] || manifest.modalities.subjectModes[selectedSubject.name] : undefined;
  useEffect(() => {
    const match = subjectMode?.duration?.match(/^(\d+)h(\d{1,2})$/);
    if (match) setDuration(Number(match[1]) * 60 + Number(match[2]));
  }, [subjectMode?.duration]);
  async function start() {
    if (saved?.application === 'engine' && !window.confirm('Une séance MED_ENGINE est sauvegardée. La remplacer par cette séance MED2 ?')) return;
    setBusy(true); setError('');
    try {
      const ids = subjectId === 'all' ? manifest.trainingSubjectIds : [subjectId];
      const banks = await Promise.all(ids.map(loadTraining));
      const dc = subjectMode?.components.find((component) => (Array.isArray(component.type) ? component.type : [component.type]).includes('DC'));
      const qi = subjectMode?.components.find((component) => (Array.isArray(component.type) ? component.type : [component.type]).includes('QI'));
      const caseFraction = mode === 'exam' && bank === 'mixed' && dc?.percent !== null && dc?.percent !== undefined && qi?.percent !== null && qi?.percent !== undefined ? dc.percent / (dc.percent + qi.percent) : undefined;
      const chosen = sampleTraining(banks, { bank, format, count, weakIds: weakOnly ? weakIds : undefined, caseFraction });
      if (!chosen.length) throw new Error(weakOnly ? 'Aucune question compatible avec une erreur enregistrée. Fais d’abord une séance, ou désactive ce filtre.' : 'Aucun lot compatible. Un dossier clinique doit tenir entièrement dans la séance : essaie 20 ou 40 questions, ou change de filtre.');
      const next: TrainingSession = { kind: 'medora-curriculum-training', id: crypto.randomUUID(), mode, bank, subjectIds: ids, questionIds: chosen.map((item) => item.question.id), answers: {}, index: 0, startedAt: new Date().toISOString(), elapsedMs: 0, runningSince: Date.now(), questionStartedMs: 0, limitSeconds: mode === 'exam' ? duration * 60 : null };
      setItems(chosen); setSession(next); setTick(Date.now()); setReviewWrong(false); setConfirmEnd(false);
    } catch (reason) { setError(reason instanceof Error ? reason.message : 'Impossible de démarrer la séance.'); } finally { setBusy(false); }
  }
  async function resume() {
    if (!resumable) return;
    setBusy(true); setError('');
    try {
      const banks = await Promise.all(resumable.subjectIds.map(loadTraining));
      const restored = restoreTrainingItems(banks, resumable.questionIds);
      if (restored.length !== resumable.questionIds.length) throw new Error('Le contenu de cette séance a changé. Tu peux supprimer la sauvegarde et démarrer une nouvelle séance.');
      setItems(restored); setSession({ ...resumable, index: Math.min(restored.length - 1, Math.max(0, resumable.index)), runningSince: null }); setTick(Date.now());
    } catch (reason) { setError(reason instanceof Error ? reason.message : 'Reprise impossible.'); } finally { setBusy(false); }
  }
  function answered(answer: StudyAnswer) {
    if (!session || !currentItem || session.finishedAt || session.runningSince === null || remaining === 0) return;
    const nowElapsed = elapsedMilliseconds(session);
    setSession({ ...session, answers: { ...session.answers, [currentItem.question.id]: { ...answer, attemptId: crypto.randomUUID(), durationSeconds: Math.min(86400, Math.max(0, Math.round((nowElapsed - session.questionStartedMs) / 1000))) } } });
  }
  function navigate(index: number) {
    if (!session) return;
    setSession({ ...session, index, questionStartedMs: elapsedMilliseconds(session) }); setTick(Date.now());
  }
  async function finish() {
    if (!session) return;
    setBusy(true); setError('');
    const completed = { ...pausedSession(session), finishedAt: new Date().toISOString() };
    try {
      for (const item of items) {
        const answer = completed.answers[item.question.id];
        if (!answer) continue;
        await study.recordAttempt({ id: answer.attemptId, questionId: typeof item.question.canonicalId === 'string' ? item.question.canonicalId : item.question.id, subjectId: item.question.subjectId, lessonId: item.question.lessonId, chapterIndex: item.question.chapterIndex, mode: completed.mode, correct: answer.correct, selected: answer.selected, durationSeconds: answer.durationSeconds });
      }
      await study.recordSession({ id: completed.id, subjectId: completed.subjectIds.length === 1 ? completed.subjectIds[0] : undefined, mode: completed.mode, startedAt: completed.startedAt, finishedAt: completed.finishedAt, questionCount: attempts.length, correctCount, durationSeconds: Math.round(completed.elapsedMs / 1000) });
      await study.saveActiveSession(null, ownerRef.current);
      setSession(completed); setConfirmEnd(false);
    } catch (reason) { setSession(pausedSession(session)); setError(reason instanceof Error ? reason.message : 'L’enregistrement a échoué. La séance est conservée : réessaie.'); } finally { setBusy(false); }
  }
  function leaveSaved() { setSession(null); setItems([]); setConfirmEnd(false); setReviewWrong(false); }

  return <section className="curriculum-practice" aria-label="Entraînement MED2">
    {error && <div className="error-banner" role="alert">{error}</div>}
    {!session ? <>
      <div className="curriculum-tool-intro"><span className="eyebrow">RAPPEL ACTIF</span><h2>S’entraîner, puis comprendre.</h2><p>Questions isolées ou dossiers cliniques, sans appel IA. Les anciennes questions retirées restent consultables dans les cours, et sont exclues de ces séances.</p></div>
      {resumable && <div className="curriculum-resume"><div><strong>Séance sauvegardée</strong><p>{Object.keys(resumable.answers).length}/{resumable.questionIds.length} réponses · {clock(Math.floor(resumable.elapsedMs / 1000))} de travail</p></div><button className="secondary" onClick={resume} disabled={busy}><Play size={16}/>Reprendre</button><button className="text-button danger" onClick={() => { void study.saveActiveSession(null, ownerRef.current).catch((reason: Error) => setError(reason.message)); }} disabled={busy}>Supprimer la sauvegarde</button></div>}
      <div className="panel curriculum-training-form">
        <div className="curriculum-tool-fields"><label>Matière<select value={subjectId} onChange={(event) => setSubjectId(event.target.value)}><option value="all">Toutes les matières · mélange</option>{allowedSubjects.map((subject) => <option value={subject.id} key={subject.id}>{subject.name}</option>)}</select></label><label>Banque<select value={bank} onChange={(event) => setBank(event.target.value as typeof bank)}><option value="mixed">Questions + dossiers cliniques</option><option value="qi">Questions isolées</option><option value="cases">Dossiers cliniques liés</option></select></label></div>
        <fieldset className="curriculum-option-group"><legend>Type de séance</legend><div className="segmented-control"><button type="button" aria-pressed={mode === 'practice'} className={mode === 'practice' ? 'selected' : ''} onClick={() => setMode('practice')}>Entraînement</button><button type="button" aria-pressed={mode === 'exam'} className={mode === 'exam' ? 'selected' : ''} onClick={() => setMode('exam')}>Simulation chronométrée</button></div><p>{mode === 'practice' ? 'La correction apparaît après chaque réponse validée.' : 'Les corrections apparaissent uniquement après la fin de la séance. Tu peux modifier une réponse avant de terminer.'}</p></fieldset>
        <div className="curriculum-tool-fields"><label>Format<select value={format} onChange={(event) => setFormat(event.target.value as typeof format)}><option value="all">QRU + QRM</option><option value="QRU">QRU · une réponse</option><option value="QRM">QRM · plusieurs réponses</option></select></label><label>Volume maximal<select value={count} onChange={(event) => setCount(Number(event.target.value))}>{[10, 20, 40].map((value) => <option key={value} value={value}>Jusqu’à {value} questions</option>)}</select></label></div>
        {mode === 'exam' && <label className="curriculum-duration">Durée de travail<select value={duration} onChange={(event) => setDuration(Number(event.target.value))}>{[...new Set([10, 20, 30, 45, 50, 60, 90, 120, duration])].sort((a, b) => a - b).map((value) => <option value={value} key={value}>{value} minutes</option>)}</select></label>}
        <label className="curriculum-checkbox"><input type="checkbox" checked={weakOnly} onChange={(event) => setWeakOnly(event.target.checked)}/><span>Reprendre mes erreurs enregistrées <small>{weakIds.size} question(s) dont la dernière réponse était incorrecte</small></span></label>
        <p className="curriculum-tool-note">Les dossiers restent groupés, dans leur ordre clinique. Un filtre QRU ou QRM conserve seulement les dossiers entièrement compatibles. Le nombre obtenu peut être inférieur au maximum. QROC et réponses rédactionnelles sont disponibles dans les cours.</p>
        {mode === 'exam' && <div className="curriculum-simulation-notice"><strong>Simulation d’entraînement</strong><p>Le score compte les réponses entièrement exactes, sans points partiels. Il ne reproduit pas une notation officielle. Le chronomètre se met en pause lorsque l’application passe à l’arrière-plan.</p>{subjectMode && <p>Modalités du document source : {subjectMode.name}{subjectMode.duration ? ` · ${subjectMode.duration}` : ''}. {subjectMode.components.map((component) => component.label).join(' · ')}. Cette banque peut ne pas couvrir tous ces formats.</p>}</div>}
        <button className="primary full" onClick={start} disabled={busy || !state || !!resumable}><Play size={17}/>{busy ? 'Préparation…' : resumable ? 'Reprends ou supprime la séance sauvegardée' : 'Commencer la séance'}</button>
      </div>
    </> : session.finishedAt ? <>
      <div className="curriculum-session-result"><CheckCircle2 size={36}/><h2>Séance terminée.</h2><p><strong>{correctCount}/{attempts.length}</strong> réponses exactes parmi les questions répondues.</p><p>{attempts.length ? `${(correctCount / attempts.length * 20).toLocaleString('fr-FR', { maximumFractionDigits: 1 })}/20 sur les réponses données` : 'Aucun score : aucune réponse donnée'} · indicateur formatif sans notation officielle</p><p>{items.length - attempts.length} sans réponse · {clock(Math.round(session.elapsedMs / 1000))} de travail</p><p>Une lecture ou une bonne réponse ne suffit pas à démontrer une maîtrise durable.</p><button className="primary" onClick={() => setReviewWrong(!reviewWrong)}>{reviewWrong ? 'Masquer les corrections' : 'Revoir les erreurs et omissions'}</button><button className="secondary" onClick={leaveSaved}><RotateCcw size={16}/>Nouvelle séance</button></div>
      <div className="panel curriculum-result-breakdown"><h3>Bilan par cours ou chapitre</h3><p className="curriculum-tool-note">Le chapitre est affiché lorsqu’il est renseigné dans la source.</p><ul>{[...resultGroups.entries()].map(([key, group]) => <li key={key}><div><strong>{group.title}</strong><p>{group.correct}/{group.answered} réponse(s) exacte(s) · {group.total - group.answered} sans réponse</p></div>{group.lessonId && <button className="text-button" onClick={() => onOpenLesson(group.lessonId!)}><BookOpen size={16}/>Relire</button>}</li>)}</ul></div>
      {reviewWrong && <div className="curriculum-wrong-list">{items.filter((item) => !session.answers[item.question.id]?.correct).map((item) => <article key={item.question.id}>{item.vignette && <div className="curriculum-case-context"><strong>{item.caseTitle}</strong><p>{item.vignette}</p></div>}<StudyQuestion key={`${session.id}-review-${item.question.id}`} question={item.question} mode="exam" initialAnswer={session.answers[item.question.id] || { selected: [] }} reveal disabled/>{item.question.lessonId && <button className="text-button" onClick={() => onOpenLesson(item.question.lessonId!)}><BookOpen size={16}/>Relire le cours associé</button>}</article>)}</div>}
    </> : currentItem && <>
      <header className="curriculum-session-header"><div><span className="eyebrow">{session.mode === 'exam' ? 'SIMULATION' : 'ENTRAÎNEMENT'}</span><h2>Question {session.index + 1} / {items.length}</h2></div><div className="curriculum-timer" role="timer" aria-label={remaining === null ? 'Temps de travail' : 'Temps restant'}><Clock3 size={16}/>{clock(remaining ?? elapsed)}</div></header>
      <progress className="curriculum-session-progress" value={attempts.length} max={items.length} aria-label="Questions répondues"/>
      {session.mode === 'exam' && <p className="curriculum-tool-note">Composition réelle : {items.filter((item) => !item.caseId).length} question(s) isolée(s), {items.filter((item) => !!item.caseId).length} question(s) en dossier. Les proportions du document source sont approchées lorsque les dossiers entiers le permettent.</p>}
      <div className="curriculum-session-toolbar"><button className="secondary" onClick={() => { setTick(Date.now()); setSession(session.runningSince === null ? { ...session, runningSince: Date.now() } : pausedSession(session)); }} disabled={remaining === 0}>{session.runningSince === null ? <Play size={16}/> : <Pause size={16}/>} {session.runningSince === null ? 'Reprendre' : 'Pause'}</button><button className="text-button" disabled={busy} onClick={async () => { setBusy(true); try { await study.saveActiveSession(pausedSession(session) as unknown as Record<string, unknown>, ownerRef.current); leaveSaved(); } catch (reason) { setError(reason instanceof Error ? reason.message : 'Sauvegarde impossible.'); } finally { setBusy(false); } }}>Sauvegarder et quitter</button></div>
      {session.runningSince === null && <div className="info-banner" role="status">{remaining === 0 ? 'Temps écoulé. Termine la séance pour voir les corrections.' : 'Séance en pause. Appuie sur Reprendre pour continuer.'}</div>}
      {currentItem.vignette && <aside className="curriculum-case-context"><span className="eyebrow">DOSSIER CLINIQUE</span><h3>{currentItem.caseTitle}</h3><p>{currentItem.vignette}</p></aside>}
      <StudyQuestion key={`${session.id}-${currentItem.question.id}-${currentAnswer ? 'answered' : 'open'}`} question={currentItem.question} mode={session.mode} initialAnswer={currentAnswer} onAnswered={answered} disabled={session.runningSince === null || remaining === 0}/>
      {session.mode === 'exam' && currentAnswer && remaining !== 0 && <button className="text-button" disabled={session.runningSince === null} onClick={() => { const answers = { ...session.answers }; delete answers[currentItem.question.id]; setSession({ ...session, answers, questionStartedMs: elapsedMilliseconds(session) }); }}>Modifier ma réponse</button>}
      {session.mode === 'practice' && currentAnswer && currentItem.question.lessonId && <button className="text-button" onClick={() => onOpenLesson(currentItem.question.lessonId!)}><BookOpen size={16}/>Relire le cours associé</button>}
      <nav className="curriculum-question-navigation" aria-label="Navigation dans la séance"><button className="secondary" disabled={session.index === 0} onClick={() => navigate(session.index - 1)}><ChevronLeft size={16}/>Précédente</button>{session.index < items.length - 1 ? <button className="primary" onClick={() => navigate(session.index + 1)}>Suivante<ChevronRight size={16}/></button> : <button className="primary" onClick={() => { setSession(pausedSession(session)); setConfirmEnd(true); }}>Terminer</button>}</nav>
      <button className="text-button danger" onClick={() => { setSession(pausedSession(session)); setConfirmEnd(true); }}>Terminer maintenant</button>
      {confirmEnd && <div className="curriculum-finish-confirm" role="region" aria-label="Confirmer la fin de séance"><strong>{remaining === 0 ? 'Le temps est écoulé.' : 'Terminer cette séance ?'}</strong><p>{attempts.length} réponse(s) enregistrable(s), {items.length - attempts.length} question(s) sans réponse. Les omissions ne sont pas comptées comme des erreurs de connaissance.</p><div><button className="primary" disabled={busy} onClick={finish}>{busy ? 'Enregistrement…' : 'Terminer et corriger'}</button>{remaining !== 0 && <button className="secondary" onClick={() => setConfirmEnd(false)}><X size={15}/>Continuer plus tard</button>}</div></div>}
    </>}
  </section>;
}
