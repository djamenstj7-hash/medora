import { useEffect, useState } from 'react';
import { LoaderCircle } from 'lucide-react';
import { engineCards, loadEnginePack } from '../lib/engine';
import type { EngineCard, EnginePack } from '../lib/engine';
import type { StudyCard } from '../lib/types';
import EngineQuestion from './EngineQuestion';

/** The rich source stays public and immutable; the private card stores only its pointer. */
export default function EngineScheduledCard({ card, revealed, onRevealed }: { card: StudyCard; revealed: boolean; onRevealed: () => void }) {
  const [source, setSource] = useState<{ pack: EnginePack; question: EngineCard }>();
  const [error, setError] = useState('');
  useEffect(() => {
    let active = true; setSource(undefined); setError('');
    const pointer = card.content;
    if (!pointer) return;
    void loadEnginePack(pointer.packId).then(pack => {
      const question = engineCards(pack).find(item => item.id === pointer.cardId);
      if (!question) throw new Error('La carte source ne figure plus dans ce paquet.');
      if (active) setSource({ pack, question });
    }).catch(reason => { if (active) setError(reason instanceof Error ? reason.message : 'Le chapitre source ne peut pas être chargé.'); });
    return () => { active = false; };
  }, [card.id, card.content?.packId, card.content?.cardId]);
  if (source) return <EngineQuestion key={card.id} pack={source.pack} card={source.question} reveal={revealed} disabled={revealed} onAnswered={() => onRevealed()} />;
  if (!error) return <div className="loading-state" role="status"><LoaderCircle className="spin" size={22} /><p>Ouverture de l’exercice source…</p></div>;
  return <div className="question-card engine-source-fallback"><p className="info-banner">L’exercice illustré n’est pas disponible. La copie textuelle de la carte reste utilisable.</p><h1>{card.prompt}</h1>{revealed ? <div className="revealed-answer"><h2>{card.answer}</h2><p>{card.explanation}</p></div> : <button className="primary" onClick={onRevealed}>Voir la correction</button>}</div>;
}
