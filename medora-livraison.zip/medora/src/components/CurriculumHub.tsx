import { lazy, Suspense, useCallback, useEffect, useMemo, useState } from 'react';
import { ArrowRight, BookOpen, Bookmark, CalendarDays, Check, ChevronRight, FileText, GraduationCap, LoaderCircle, Search } from 'lucide-react';
import { loadCurriculum, safeExternalUrl } from '../lib/curriculum';
import type { CurriculumManifest } from '../lib/curriculum';
import { study } from '../lib/study';
import type { StudyState } from '../lib/study';
import '../curriculum-hub.css';

const Practice = lazy(() => import('./CurriculumPractice'));
const Progress = lazy(() => import('./CurriculumProgress'));
export type LibrarySection = 'decks' | 'courses' | 'practice' | 'progress' | 'engine';
export const librarySections: { id: LibrarySection; label: string }[] = [
  { id: 'decks', label: 'Mes decks' }, { id: 'courses', label: 'Cours MED2' },
  { id: 'practice', label: 'Entraînement' }, { id: 'progress', label: 'Suivi & planning' }, { id: 'engine', label: 'MED_ENGINE' },
];
function Busy() { return <div className="loading-state curriculum-loading"><LoaderCircle className="spin" size={24} /><p>Ouverture du programme…</p></div>; }

export default function CurriculumHub({ section, onOpenLesson }: { section: Exclude<LibrarySection, 'decks' | 'engine'>; onOpenLesson: (id: string) => void }) {
  const [manifest, setManifest] = useState<CurriculumManifest>();
  const [state, setState] = useState<StudyState>();
  const [error, setError] = useState('');
  const load = useCallback(async () => {
    setError('');
    try { const [content, progress] = await Promise.all([loadCurriculum(), study.load()]); setManifest(content); setState(progress); }
    catch (err) { setError(err instanceof Error ? err.message : 'Le programme ne peut pas être ouvert.'); }
  }, []);
  useEffect(() => { void load(); }, [load, section]);
  useEffect(() => { let active = true; const unsubscribe = study.subscribe(() => { void study.load().then(value => { if (active) setState(value); }).catch(() => undefined); }); return () => { active = false; unsubscribe(); }; }, []);
  if (error) return <div className="error-banner" role="alert"><span>{error}</span><button className="text-button" onClick={() => void load()}>Réessayer</button></div>;
  if (!manifest || !state) return <Busy />;
  return <Suspense fallback={<Busy />}>{section === 'courses' ? <CourseCatalogue manifest={manifest} state={state} onOpenLesson={onOpenLesson} /> : section === 'practice' ? <Practice manifest={manifest} onOpenLesson={onOpenLesson} /> : <Progress manifest={manifest} onOpenLesson={onOpenLesson} />}</Suspense>;
}

function CourseCatalogue({ manifest, state, onOpenLesson }: { manifest: CurriculumManifest; state: StudyState; onOpenLesson: (id: string) => void }) {
  const [query, setQuery] = useState(''); const [subjectId, setSubjectId] = useState('all');
  const [filter, setFilter] = useState<'all' | 'started' | 'bookmarks' | 'unread'>('all');
  const [resources, setResources] = useState(false);
  const normalize = (text: string) => text.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
  const needle = normalize(query.trim());
  const lessons = useMemo(() => manifest.lessons.filter(lesson => {
    if (subjectId !== 'all' && lesson.subject !== subjectId) return false;
    const read = (state.read[lesson.id] || []).length;
    if (filter === 'started' && !read) return false;
    if (filter === 'unread' && read) return false;
    if (filter === 'bookmarks' && !state.bookmarks.includes(lesson.id)) return false;
    return !needle || normalize(`${lesson.title} ${lesson.courseName} ${lesson.teacher} ${lesson.searchText} ${lesson.chapterTitles.join(' ')}`).includes(needle);
  }), [manifest, state, subjectId, filter, needle]);
  const last = state.lastRead && manifest.lessons.find(lesson => lesson.id === state.lastRead?.lessonId);
  const subjects = [...manifest.subjects, ...(state.customCatalogue?.subjects || []).filter(subject => !manifest.subjects.some(existing => existing.id === subject.id)).map(subject => ({ ...subject, color: subject.color || '#5e8150', lessonCount: 0, trainingCount: 0, caseCount: 0 }))];
  const resourceMap = new Map(manifest.resources.map(resource => [resource.id, resource]));
  for (const resource of state.customCatalogue?.resources || []) resourceMap.set(resource.id, { ...resourceMap.get(resource.id), ...resource, status: resource.status || 'reference_personnelle', lessonAvailable: manifest.lessons.some(lesson => lesson.id === resource.id) });
  const entries = [...resourceMap.values()].filter(resource => (subjectId === 'all' || resource.subject === subjectId) && (!needle || normalize(resource.title).includes(needle)));
  const mode = manifest.modalities.subjectModes[subjectId];
  return <section className="curriculum-catalogue fade-in">
    <div className="page-heading"><div><div className="eyebrow">VOTRE PROGRAMME, DANS MEDORA</div><h1>Les cours MED2<span className="green-dot">.</span></h1><p>{manifest.audit.lessonCount} cours · {manifest.lessons.reduce((sum, lesson) => sum + lesson.sectionCount, 0)} chapitres · {manifest.audit.subjectCount} matières</p></div><span className="soft-badge"><GraduationCap size={15} />Semestre 1</span></div>
    {last && !query && <button className="curriculum-resume" onClick={() => onOpenLesson(last.id)}><BookOpen size={22} /><span><small>REPRENDRE MA LECTURE</small><strong>{last.title}</strong><span>Chapitre {(state.lastRead?.chapterIndex || 0) + 1} sur {last.sectionCount}</span></span><ArrowRight size={19} /></button>}
    <label className="search-input"><Search size={19} /><input aria-label="Rechercher dans les cours MED2" value={query} onChange={event => setQuery(event.target.value)} placeholder="Cours, chapitre, notion ou enseignant…" /></label>
    <div className="curriculum-catalogue-controls"><label className="field"><span>Matière</span><select value={subjectId} onChange={event => setSubjectId(event.target.value)}><option value="all">Toutes les matières</option>{subjects.map(subject => <option key={subject.id} value={subject.id}>{subject.name} ({subject.lessonCount} cours)</option>)}</select></label><label className="field"><span>Votre progression</span><select value={filter} onChange={event => setFilter(event.target.value as typeof filter)}><option value="all">Tous les cours</option><option value="started">Déjà commencés</option><option value="unread">À découvrir</option><option value="bookmarks">Favoris</option></select></label></div>
    {mode && <section className="panel curriculum-exam-mode"><div className="section-heading"><h2>Modalités · {mode.name}</h2><span className="soft-badge">Document source</span></div><div className="curriculum-exam-mode-values"><span><strong>{mode.duration || 'À préciser'}</strong>Durée</span><span><strong>{mode.ects}</strong>ECTS</span><span><strong>{mode.coefficient}</strong>Coefficient</span><span><strong>{mode.points}</strong>Points</span></div><ul>{mode.components.map((component, index) => <li key={index}><strong>{component.label}</strong><span>{component.percent !== null ? `${component.percent} %` : 'Répartition non précisée'} · {component.context}</span></li>)}</ul><p>Modalités reprises du tableau fourni dans l’ancien projet. Vérifie les consignes actuelles de ta faculté.</p></section>}
    <div className="section-heading"><h2>{lessons.length} cours disponibles</h2><button className="text-button" onClick={() => setResources(value => !value)}><FileText size={15} />{resources ? 'Masquer les ressources' : 'Sources & annales'}</button></div>
    <div className="library-grid curriculum-course-grid">{lessons.map(lesson => {
      const subject = manifest.subjects.find(item => item.id === lesson.subject); const read = new Set(state.read[lesson.id] || []).size;
      return <button className="library-card curriculum-course-card" key={lesson.id} onClick={() => onOpenLesson(lesson.id)}><span className="subject-icon" style={{ color: subject?.color || '#155f48', background: `${subject?.color || '#155f48'}16` }}><BookOpen size={23} /></span>{state.bookmarks.includes(lesson.id) && <Bookmark className="curriculum-bookmark" size={16} fill="currentColor" />}<span className="library-subject">{subject?.name || lesson.subject}</span><h2>{lesson.title}</h2><p>{lesson.sectionCount} chapitres · {lesson.activeQuestionCount} QCM<br />{lesson.cardCount} cartes{lesson.qrocCount ? ` · ${lesson.qrocCount} QROC` : ''}</p><div className="curriculum-read-progress" role="progressbar" aria-label={`Chapitres lus : ${lesson.title}`} aria-valuemin={0} aria-valuemax={lesson.sectionCount} aria-valuenow={Math.min(read, lesson.sectionCount)}><span style={{ width: `${lesson.sectionCount ? Math.min(read / lesson.sectionCount, 1) * 100 : 0}%` }} /></div><div className="library-card-footer"><span className="up-to-date">{read ? `${read}/${lesson.sectionCount} chapitres lus` : 'À découvrir'}</span>{read >= lesson.sectionCount ? <Check size={18} /> : <ArrowRight size={18} />}</div></button>;
    })}</div>
    {!lessons.length && <div className="empty-state"><BookOpen size={29} /><h3>Aucun cours dans cette sélection</h3><p>Essaie un autre mot ou consulte les ressources recensées pour cette matière.</p><button className="secondary" onClick={() => { setQuery(''); setSubjectId('all'); setFilter('all'); }}>Afficher tous les cours</button></div>}
    {resources && <section className="panel curriculum-resources"><h2>Ressources & annales</h2><p>{resourceMap.size} supports recensés dans le programme et votre catalogue. Un support recensé sans cours rédigé n’est pas présenté comme un cours disponible. Les liens Drive peuvent nécessiter ton accès étudiant.</p><div className="curriculum-resource-list">{entries.map(resource => {
      const lesson = manifest.lessons.find(item => item.id === resource.id); const url = safeExternalUrl(resource.url || resource.source?.url);
      return <div key={resource.id} className="curriculum-resource"><FileText size={17} /><div><strong>{resource.title}</strong><small>{resource.kind === 'annale' ? 'Annales' : 'Support de cours'} · {resource.lessonAvailable ? 'Cours rédigé disponible' : 'Support recensé, contenu non fourni'}</small></div>{lesson ? <button className="text-button" onClick={() => onOpenLesson(lesson.id)}>Ouvrir <ChevronRight size={15} /></button> : url ? <a href={url} target="_blank" rel="noopener noreferrer">Source</a> : <span className="small-muted">Lien non fourni</span>}</div>;
    })}</div></section>}
    <div className="science-note"><CalendarDays size={18} /><p>Programme et dates issus de tes fichiers 2026–2027. Consulte <strong>Suivi & planning</strong> pour vérifier les échéances, les adapter et préparer tes sessions. Les cours et leurs corrections restent à confronter à tes référentiels.</p></div>
  </section>;
}

export function CurriculumTeaser({ onOpen }: { onOpen: (section: LibrarySection) => void }) {
  return <section className="curriculum-dashboard-card"><span className="subject-icon"><GraduationCap size={24} /></span><div><span className="eyebrow">VOTRE PROGRAMME MED2</span><h2>Les cours, les exercices et votre plan.</h2><p>Retrouvez votre semestre sans quitter Medora.</p><div className="curriculum-teaser-actions"><button className="text-button" onClick={() => onOpen('courses')}>Ouvrir mes cours <ArrowRight size={15} /></button><button className="text-button" onClick={() => onOpen('practice')}>M’entraîner</button><button className="text-button" onClick={() => onOpen('progress')}>Mon planning</button></div></div></section>;
}
