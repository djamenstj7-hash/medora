import { useEffect, useMemo, useState } from 'react';
import { ArrowUpRight, BookOpen, CalendarDays, Clock3, Target } from 'lucide-react';
import type { CurriculumManifest } from '../lib/curriculum';
import { study, type StudyState } from '../lib/study';
import { buildStudyPlan, dayInTimezone, examCalendar, latestQuestionAttempts } from '../lib/study-plan';
import '../curriculum-tools.css';

interface Props { manifest: CurriculumManifest; onOpenLesson: (id: string) => void }
const dateLabel = (date: string) => new Intl.DateTimeFormat('fr-FR', { dateStyle: 'long', timeZone: 'UTC' }).format(new Date(`${date}T12:00:00Z`));

export default function CurriculumProgress({ manifest, onOpenLesson }: Props) {
  const [state, setState] = useState<StudyState>();
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [dailyMinutes, setDailyMinutes] = useState(90);
  const [backgroundMinutes, setBackgroundMinutes] = useState(15);
  const [missionLesson, setMissionLesson] = useState(manifest.lessons[0]?.id ?? '');
  const [missionType, setMissionType] = useState<'read' | 'practice' | 'recall'>('read');
  const [examSubject, setExamSubject] = useState(manifest.subjects[0]?.id ?? '');
  const [examDate, setExamDate] = useState('');
  const [notice, setNotice] = useState('');
  useEffect(() => {
    let live = true;
    const load = () => { study.load().then((value) => { if (live) setState(value); }).catch((reason: Error) => { if (live) setError(reason.message); }); };
    load(); const unsubscribe = study.subscribe(load);
    return () => { live = false; unsubscribe(); };
  }, []);
  useEffect(() => { if (state) { setDailyMinutes(state.settings.dailyMinutes); setBackgroundMinutes(state.settings.backgroundMinutes); } }, [state?.settings.dailyMinutes, state?.settings.backgroundMinutes]);
  useEffect(() => { setExamDate(state?.exams[examSubject] ?? ''); }, [examSubject, state?.exams[examSubject]]);
  const today = dayInTimezone(new Date(), manifest.timezone);
  const lessons = manifest.lessons;
  const latest = useMemo(() => state ? latestQuestionAttempts(state) : new Map<string, StudyState['attempts'][number]>(), [state]);
  const calendar = state ? examCalendar(manifest, state) : [];
  const future = calendar.filter((exam) => !exam.archived);
  const past = calendar.filter((exam) => exam.archived);
  const plan = state ? buildStudyPlan(lessons, manifest.subjects.map((subject) => ({ ...subject, coefficient: manifest.modalities.subjectModes[subject.id]?.coefficient })), state) : [];
  const nearest = future[0];
  const tomorrowDate = new Date(`${today}T12:00:00Z`); tomorrowDate.setUTCDate(tomorrowDate.getUTCDate() + 1);
  const examPhase = nearest?.date === today ? 'Jour J : rappels courts et vérification des points essentiels.' : nearest?.date === tomorrowDate.toISOString().slice(0, 10) ? 'Veille d’examen : consolidation et rappel, sans nouvelle lecture longue.' : '';
  const qcmAttempts = state?.attempts.filter((attempt) => ['practice', 'exam'].includes(attempt.mode)) ?? [];
  const readCount = state ? lessons.reduce((sum, lesson) => sum + new Set((state.read[lesson.id] ?? []).filter((index) => index >= 0 && index < lesson.sectionCount)).size, 0) : 0;
  const sectionCount = lessons.reduce((sum, lesson) => sum + lesson.sectionCount, 0);
  const weakLessons = lessons.map((lesson) => {
    const attempts = [...latest.values()].filter((attempt) => attempt.lessonId === lesson.id && !attempt.correct);
    return { lesson, count: attempts.length };
  }).filter((item) => item.count > 0).sort((a, b) => b.count - a.count);
  const activity = Array.from({ length: 14 }, (_, index) => {
    const date = new Date(); date.setUTCDate(date.getUTCDate() - (13 - index));
    const key = dayInTimezone(date, manifest.timezone);
    const attempts = state?.attempts.filter((attempt) => dayInTimezone(new Date(attempt.createdAt), manifest.timezone) === key).length ?? 0;
    const sessions = state?.sessions.filter((session) => dayInTimezone(new Date(session.finishedAt), manifest.timezone) === key) ?? [];
    return { key, attempts, minutes: Math.round(sessions.reduce((sum, session) => sum + session.durationSeconds, 0) / 60) };
  });
  async function mutate(action: () => Promise<StudyState>, message: string) {
    setBusy(true); setError(''); setNotice('');
    try { const value = await action(); setState(value); setNotice(message); } catch (reason) { setError(reason instanceof Error ? reason.message : 'Enregistrement impossible.'); } finally { setBusy(false); }
  }
  return <section className="curriculum-progress" aria-label="Progression et planification MED2">
    <div className="curriculum-tool-intro"><span className="eyebrow">UN CAP, CHAQUE JOUR</span><h2>Ta progression réelle.</h2><p>Lecture, réponses aux questions et autoévaluation restent des indicateurs distincts. Les révisions FSRS de tes decks Medora continuent dans l’onglet Aujourd’hui.</p></div>
    {error && <div className="error-banner" role="alert">{error}</div>}{notice && <div className="info-banner" role="status">{notice}</div>}
    {!state ? <p role="status">Chargement de ta progression…</p> : <>
      {examPhase && <div className="info-banner">{examPhase}</div>}
      <div className="curriculum-progress-stats"><article><BookOpen size={19}/><strong>{readCount}<small>/{sectionCount}</small></strong><span>Chapitres marqués lus</span></article><article><Target size={19}/><strong>{qcmAttempts.length ? `${Math.round(qcmAttempts.filter((attempt) => attempt.correct).length / qcmAttempts.length * 100)} %` : '—'}</strong><span>{qcmAttempts.length} réponse(s) QCM</span></article><article><Clock3 size={19}/><strong>{Math.round(state.sessions.reduce((sum, session) => sum + session.durationSeconds, 0) / 60)}<small> min</small></strong><span>Séances chronométrées</span></article></div>
      <section className="panel curriculum-activity"><h3>Les 14 derniers jours</h3><p>Réponses réellement enregistrées · fuseau {manifest.timezone}. Les cases vides correspondent à zéro réponse.</p><div className="curriculum-activity-days">{activity.map((day) => <div key={day.key} className={`curriculum-activity-day ${day.attempts ? 'has-activity' : ''}`}><span>{new Date(`${day.key}T12:00:00Z`).getUTCDate()}</span><strong title={`${day.attempts} réponse(s), ${day.minutes} minute(s) chronométrée(s)`}>{day.attempts}</strong><small>{day.minutes}m</small><span className="sr-only">{dateLabel(day.key)} : {day.attempts} réponses, {day.minutes} minutes chronométrées</span></div>)}</div><p>Les durées ne comprennent que les séances chronométrées ; la lecture seule n’est pas convertie en temps estimé.</p></section>

      <section className="panel curriculum-plan"><div className="section-heading"><h3>Ton plan du jour</h3><span className="curriculum-badge">{plan.reduce((sum, task) => sum + task.minutes, 0)} min proposées</span></div><form className="curriculum-plan-settings" onSubmit={(event) => { event.preventDefault(); void mutate(() => study.updateSettings({ dailyMinutes, backgroundMinutes }), 'Tes budgets quotidiens ont été enregistrés.'); }}><label>Budget total · minutes<input type="number" min={10} max={480} step={5} value={dailyMinutes} onChange={(event) => setDailyMinutes(Number(event.target.value))} required/></label><label>Dont matières suivantes · minutes<input type="number" min={0} max={60} step={5} value={backgroundMinutes} onChange={(event) => setBackgroundMinutes(Number(event.target.value))} required/></label><button className="secondary" disabled={busy || !Number.isFinite(dailyMinutes) || dailyMinutes < 10 || dailyMinutes > 480 || backgroundMinutes < 0 || backgroundMinutes > 60}>Enregistrer</button></form><p className="curriculum-tool-note">Tour 1 : comprendre et lire. Tour 2 : consolider avec les questions. Tour 3 : s’évaluer sans regarder. Le prochain examen est prioritaire ; une part du budget entretient les matières suivantes, avec alternance quotidienne. Le plan s’adapte à tes actions ; ouvrir un cours ne le marque pas comme lu. Les durées sont des budgets, pas une promesse de couverture de tout le programme.</p>
        {plan.length ? <ol className="curriculum-task-list">{plan.map((task) => <li key={task.id}><div><span className="eyebrow">{task.type === 'read' ? 'TOUR 1 · COMPRENDRE' : task.type === 'practice' ? 'TOUR 2 · CONSOLIDER' : 'TOUR 3 · S’ÉVALUER'} · {task.minutes} MIN</span><strong>{task.title}</strong><p>{task.reason}</p></div><button aria-label={`Ouvrir ${task.title}`} className="secondary" onClick={() => onOpenLesson(task.lessonId)}><ArrowUpRight size={18}/><span>Ouvrir</span></button></li>)}</ol> : <p>Aucun cours disponible pour construire un plan.</p>}
      </section>

      <section className="panel curriculum-missions"><h3>Mes missions supplémentaires</h3><p className="curriculum-tool-note">Ajoute un cours à ton programme personnel. Ces missions s’ajoutent au budget automatique ; leur activité s’appuie sur tes lectures, réponses et autoévaluations.</p><form className="curriculum-exam-form" onSubmit={(event) => { event.preventDefault(); void mutate(() => study.addMission(missionLesson, missionType), 'Mission ajoutée à ton programme.'); }}><label>Cours<select value={missionLesson} onChange={(event) => setMissionLesson(event.target.value)}>{lessons.map((lesson) => <option key={lesson.id} value={lesson.id}>{lesson.title}</option>)}</select></label><label>Objectif<select value={missionType} onChange={(event) => setMissionType(event.target.value as typeof missionType)}><option value="read">Tour 1 · Comprendre et lire</option><option value="practice">Tour 2 · Consolider</option><option value="recall">Tour 3 · S’évaluer</option></select></label><button className="secondary" disabled={busy || !missionLesson}>Ajouter une mission</button></form>{state.missions.length ? <ul className="curriculum-task-list">{state.missions.map((mission) => { const lesson = lessons.find((item) => item.id === mission.lessonId); if (!lesson) return null; const recentAttempts = state.attempts.filter((attempt) => attempt.lessonId === mission.lessonId && attempt.createdAt >= mission.createdAt).length; const reviews = (state.lessonReviews[mission.lessonId] ?? []).filter((review) => review.createdAt >= mission.createdAt).length; const read = new Set(state.read[mission.lessonId] ?? []).size; return <li key={mission.id}><div><span className="eyebrow">{mission.type === 'read' ? 'COMPRENDRE' : mission.type === 'practice' ? 'CONSOLIDER' : 'S’ÉVALUER'}</span><strong>{lesson.title}</strong><p>{mission.type === 'read' ? `${read}/${lesson.sectionCount} chapitres actuellement lus` : mission.type === 'practice' ? `${recentAttempts} réponse(s) depuis l’ajout` : `${reviews} autoévaluation(s) depuis l’ajout`}</p><button className="text-button" disabled={busy} onClick={() => { void mutate(() => study.removeMission(mission.id), 'Mission retirée du programme. Tes données de progression sont conservées.'); }}>Retirer la mission</button></div><button className="secondary" aria-label={`Ouvrir ${lesson.title}`} onClick={() => onOpenLesson(lesson.id)}><ArrowUpRight size={17}/></button></li>; })}</ul> : <p className="curriculum-empty">Aucune mission personnelle pour le moment.</p>}</section>

      <section className="curriculum-subject-progress"><div className="section-heading"><h3>Par matière</h3></div><div className="curriculum-subject-progress-list">{manifest.subjects.map((subject) => {
        const own = lessons.filter((lesson) => lesson.subjectId === subject.id);
        const total = own.reduce((sum, lesson) => sum + lesson.sectionCount, 0);
        const read = own.reduce((sum, lesson) => sum + new Set((state.read[lesson.id] ?? []).filter((index) => index >= 0 && index < lesson.sectionCount)).size, 0);
        const attempted = qcmAttempts.filter((attempt) => attempt.subjectId === subject.id);
        const unique = new Set(attempted.map((attempt) => attempt.questionId)).size;
        const reviewed = own.filter((lesson) => { const history = state.lessonReviews[lesson.id] ?? []; return history[history.length - 1]?.level === 'mastered'; }).length;
        return <article key={subject.id}><h4><span style={{ background: subject.color }}/>{subject.name}</h4><progress value={read} max={Math.max(1, total)} aria-label={`${subject.name} : ${read} chapitres lus sur ${total}`}/><p>{read}/{total} chapitres lus · {unique} questions distinctes tentées</p><p>{attempted.length ? `${Math.round(attempted.filter((attempt) => attempt.correct).length / attempted.length * 100)} % exactes sur ${attempted.length} réponses QCM` : 'Aucune réponse QCM enregistrée'}</p><small>{reviewed}/{own.length} cours autoévalués « maîtrisés » · cette appréciation reste déclarative.</small></article>;
      })}</div></section>

      <section className="panel curriculum-weak"><h3>À retravailler</h3><p>Questions dont ta dernière réponse enregistrée était incorrecte. Les autoévaluations rédactionnelles restent déclaratives.</p>{weakLessons.length ? <ul>{weakLessons.slice(0, 12).map(({ lesson, count }) => <li key={lesson.id}><button onClick={() => onOpenLesson(lesson.id)}><span>{lesson.title}<small>{count} erreur(s) encore à reprendre</small></span><ArrowUpRight size={17}/></button></li>)}</ul> : <div className="curriculum-empty">{state.attempts.length ? 'Aucune erreur récente rattachée à un cours.' : 'Les chapitres à retravailler apparaîtront après tes premières réponses.'}</div>}</section>

      <section className="panel curriculum-exam-calendar"><div className="section-heading"><h3><CalendarDays size={17}/> Calendrier des examens</h3></div><div className="curriculum-simulation-notice"><p>{manifest.examNotice}</p><p>Horaires du document source, fuseau <strong>{manifest.timezone}</strong>. Les dates passées sont conservées comme archives. Vérifie toujours les convocations de ta faculté.</p></div>
        {future.length ? <ul className="curriculum-exam-list">{future.map((exam) => <li key={exam.id}><span className="curriculum-badge">{exam.overridden ? 'DATE PERSONNELLE' : 'DOCUMENT SOURCE'}</span><strong>{exam.title}</strong><span>{dateLabel(exam.date)}</span><small>{exam.start ? `${exam.start}${exam.end ? ` – ${exam.end}` : ''} · ${exam.timezone}` : 'Horaire non renseigné'}</small></li>)}</ul> : <p className="curriculum-empty">Aucun examen futur renseigné. Ajoute tes prochaines dates ci-dessous.</p>}
        <form className="curriculum-exam-form" onSubmit={(event) => { event.preventDefault(); if (examDate < today) { setError('Choisis une date actuelle ou future pour ton prochain examen.'); return; } void mutate(() => study.setExamDate(examSubject, examDate), 'Ta date personnelle a été enregistrée. L’horaire officiel n’est pas reconduit automatiquement.'); }}><label>Matière<select value={examSubject} onChange={(event) => setExamSubject(event.target.value)}>{manifest.subjects.map((subject) => <option key={subject.id} value={subject.id}>{subject.name}</option>)}</select></label><label>Prochaine date personnelle<input type="date" min={today} value={examDate} onChange={(event) => setExamDate(event.target.value)} required/></label><button className="primary" disabled={busy || !examSubject || !examDate}>Enregistrer la date</button>{state.exams[examSubject] && <button type="button" className="text-button" disabled={busy} onClick={() => { void mutate(() => study.setExamDate(examSubject, null), 'La date du document source a été restaurée.'); }}>Restaurer la date source</button>}</form>
        {!!past.length && <details className="curriculum-exam-archive"><summary>Dates passées du calendrier ({past.length})</summary><ul className="curriculum-exam-list">{past.map((exam) => <li key={exam.id}><span className="curriculum-badge">ARCHIVE · {exam.overridden ? 'DATE PERSONNELLE' : 'DOCUMENT SOURCE'}</span><strong>{exam.title}</strong><span>{dateLabel(exam.date)}{exam.start ? ` · ${exam.start}${exam.end ? ` – ${exam.end}` : ''}` : ''}</span><small>{exam.timezone}</small></li>)}</ul></details>}
      </section>
    </>}
  </section>;
}
