import { useEffect, useRef, useState } from 'react';
import type { CSSProperties, ReactNode } from 'react';
import { ArrowLeft, ArrowRight, Bookmark, BookOpen, Check, CheckCheck, ChevronLeft, ChevronRight, ExternalLink, FileText, ImageOff, Layers3, List, LoaderCircle, Maximize2, Settings2, StickyNote, X } from 'lucide-react';
import { activeQuestions, assetUrl, loadCurriculum, loadLesson, safeExternalUrl } from '../lib/curriculum';
import type { CourseLesson, LessonFigure, LessonParagraphBlock, Question, SourceReference } from '../lib/curriculum';
import { study } from '../lib/study';
import StudyQuestion, { InlineText } from './StudyQuestion';
import type { StudyAnswer } from './StudyQuestion';
import '../course-reader.css';

type ReaderState = Awaited<ReturnType<typeof study.load>>;
type ReaderTab = 'course' | 'summary' | 'qcm' | 'qroc' | 'writing' | 'cards' | 'assessment' | 'sources';
interface Props {
  lessonId: string;
  onClose: () => void;
  onInstallDeck: (lesson: CourseLesson) => Promise<void>;
  onFeynman?: (concept: string, context: string) => void;
  onNavigateLesson?: (id: string) => void;
}

const tabLabels: [ReaderTab, string][] = [['course', 'Cours'], ['summary', 'Synthèse'], ['qcm', 'QCM'], ['qroc', 'QROC'], ['writing', 'Rédaction'], ['cards', 'Cartes'], ['assessment', 'Évaluation'], ['sources', 'Sources']];

function essenceChapter(lesson: CourseLesson, heading: string, pages: string, index: number) {
  const normalize = (value: string) => value.normalize('NFD').replace(/\p{M}/gu, '').toLocaleLowerCase('fr').replace(/^\d+[.)]?\s*/, '').trim();
  const exact = lesson.sections.findIndex((section) => normalize(section.heading) === normalize(heading));
  if (exact >= 0) return exact;
  const samePages = lesson.sections.map((section, position) => section.pages === pages ? position : -1).filter((position) => position >= 0);
  if (samePages.length === 1) return samePages[0];
  // The source retains chapter order when its headings have been rephrased.
  return lesson.essenceSections.length === lesson.sections.length ? index : 0;
}

function ReaderParagraph({ paragraph }: { paragraph: string | LessonParagraphBlock }) {
  if (typeof paragraph !== 'string') return <aside className="cr-remember"><h4>{paragraph.title || (paragraph.type === 'retenir' ? 'À retenir' : 'Repère du cours')}</h4><ul>{(paragraph.items || []).map((text, index) => <li key={index}><InlineText text={text} /></li>)}</ul></aside>;
  const kind = /^(attention|ne confonds|ne pas confondre|voici le piège|piège|à l['’]examen|en examen|dans un qr[mu]|erreur fréquente|méfie-toi)/i.test(paragraph) ? 'trap' : /^(imagine|imaginons|prenons|par exemple|l['’]exemple|exemple|cas \d|visualise|pense à|c['’]est comme)/i.test(paragraph) ? 'example' : /^(pourquoi|comment|cela explique|le mécanisme|mécanisme)/i.test(paragraph) ? 'mechanism' : '';
  if (!kind) return <p><InlineText text={paragraph} /></p>;
  return <aside className={`cr-callout cr-callout-${kind}`}><h4>{kind === 'trap' ? 'Point de vigilance' : kind === 'example' ? 'Exemple' : 'Mécanisme'}</h4><p><InlineText text={paragraph} /></p></aside>;
}

function CourseFigure({ figure, onOpen }: { figure: LessonFigure; onOpen: (figure: LessonFigure) => void }) {
  const [failed, setFailed] = useState(false);
  const [fallbackFailed, setFallbackFailed] = useState(false);
  const fallback = (figure.missing || failed) && figure.fallbackSrc;
  const sourcePath = fallback || figure.src;
  const source = assetUrl(sourcePath);
  if ((!fallback && (figure.missing || failed)) || !source || fallbackFailed) return <figure className="cr-missing-figure"><ImageOff size={25} aria-hidden="true" /><figcaption><strong>Illustration absente de l’archive d’origine</strong><p>{figure.caption || figure.alt || 'Consultez le document source pour retrouver cette figure.'}</p><small>Aucune image de remplacement n’a été inventée.</small></figcaption></figure>;
  return <figure className="cr-figure"><button onClick={() => onOpen({ ...figure, src: sourcePath })} aria-label={`Agrandir : ${figure.alt || figure.caption || 'illustration du cours'}`}><img src={source} alt={figure.alt || figure.caption || 'Illustration du cours'} loading="lazy" onError={() => fallback ? setFallbackFailed(true) : setFailed(true)} /><span className="cr-expand"><Maximize2 size={16} />Agrandir</span></button>{(figure.caption || fallback) && <figcaption>{fallback && <small>Schéma simplifié d’origine — illustration principale indisponible.</small>}<InlineText text={figure.caption || ''} /></figcaption>}</figure>;
}

function FigureDialog({ figure, onClose }: { figure: LessonFigure; onClose: () => void }) {
  const dialog = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const previous = document.activeElement as HTMLElement | null;
    dialog.current?.focus();
    return () => previous?.focus();
  }, []);
  return <div className="cr-figure-backdrop" onClick={(event) => { if (event.target === event.currentTarget) onClose(); }}><div className="cr-figure-dialog" ref={dialog} tabIndex={-1} role="dialog" aria-modal="true" aria-label={figure.caption || 'Illustration agrandie'} onKeyDown={(event) => { if (event.key === 'Escape') { event.preventDefault(); event.stopPropagation(); onClose(); } if (event.key === 'Tab') { event.preventDefault(); dialog.current?.querySelector('button')?.focus(); } }}><button className="cr-icon" onClick={onClose} aria-label="Fermer l’illustration"><X size={23} /></button><div className="cr-figure-viewport"><img src={assetUrl(figure.src)} alt={figure.alt || figure.caption || 'Illustration agrandie'} /></div>{figure.caption && <p>{figure.caption}</p>}<small>Écartez les doigts pour zoomer selon les possibilités de votre navigateur.</small></div></div>;
}

function SourceLink({ source }: { source: SourceReference }) {
  const url = safeExternalUrl(source.url);
  return <div className="cr-source-row"><FileText size={19} /><div><strong>{source.label || source.title || 'Document source'}</strong>{source.pages && <small>{source.pages} page(s)</small>}{url ? <a href={url} target="_blank" rel="noopener noreferrer">Ouvrir le document <ExternalLink size={14} /></a> : <small>Lien non disponible dans l’archive.</small>}</div></div>;
}

function EmptyContent({ children }: { children: ReactNode }) { return <div className="cr-empty"><BookOpen size={29} /><p>{children}</p></div>; }

function CourseAssessment({ lesson, onAttempt, onRecorded }: { lesson: CourseLesson; onAttempt: (question: Question, answer: StudyAnswer, mode: 'practice' | 'exam' | 'qroc' | 'writing') => void; onRecorded: (promise: Promise<ReaderState>) => void }) {
  const all = activeQuestions(lesson.questions);
  const [count, setCount] = useState(Math.min(20, all.length));
  const [questions, setQuestions] = useState<Question[]>([]);
  const [index, setIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, StudyAnswer>>({});
  const [done, setDone] = useState(false);
  const [startedAt, setStartedAt] = useState('');
  const [run, setRun] = useState(0);
  const [showCorrections, setShowCorrections] = useState(false);
  const answered = Object.keys(answers).length;
  function start() {
    // Shuffle once per attempt; the question list stays stable throughout the assessment.
    const shuffled = [...all];
    for (let i = shuffled.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]]; }
    setQuestions(shuffled.slice(0, count)); setAnswers({}); setIndex(0); setDone(false); setShowCorrections(false); setStartedAt(new Date().toISOString()); setRun((value) => value + 1);
  }
  function finish() {
    if (answered !== questions.length) return;
    const finishedAt = new Date().toISOString();
    onRecorded(study.recordSession({ lessonId: lesson.id, subjectId: lesson.subject, mode: 'exam', startedAt, finishedAt, questionCount: questions.length, correctCount: Object.values(answers).filter((answer) => answer.correct).length, durationSeconds: Math.round((Date.parse(finishedAt) - Date.parse(startedAt)) / 1000) }));
    setDone(true);
  }
  if (!all.length) return <EmptyContent>Ce cours ne contient pas de QCM actifs pour une évaluation.</EmptyContent>;
  if (!questions.length) return <div className="cr-assessment-start cr-card"><span className="cr-kicker">PRENDRE DU RECUL</span><h2>Le cours est-il compris ?</h2><p>Un ensemble mélangé de QCM du cours. Les corrections apparaissent à la fin ; aucune question n’est comptée comme répondue avant validation.</p><label htmlFor={`assessment-count-${lesson.id}`}>Nombre de questions</label><select id={`assessment-count-${lesson.id}`} value={count} onChange={(event) => setCount(Number(event.target.value))}>{Array.from(new Set([Math.min(10, all.length), Math.min(20, all.length), all.length])).sort((a, b) => a - b).map((size) => <option key={size} value={size}>{size === all.length ? `Toutes (${size})` : size}</option>)}</select><p className="cr-muted">Cette évaluation formative n’est pas une note officielle d’examen.</p><button className="cr-primary" onClick={start}>Commencer <ArrowRight size={17} /></button></div>;
  if (done) {
    const correct = Object.values(answers).filter((answer) => answer.correct).length;
    return <section className="cr-assessment-result"><div className="cr-card"><CheckCheck size={32} /><h2>{correct} / {questions.length} réponses exactes</h2><p>{questions.length - correct} question(s) à retravailler. Le résultat porte uniquement sur cette session.</p><div className="cr-actions"><button className="cr-primary" onClick={() => setShowCorrections((value) => !value)}>{showCorrections ? 'Masquer' : 'Voir'} les corrections</button><button className="cr-secondary" onClick={() => { setQuestions([]); setAnswers({}); }}>Nouvelle évaluation</button></div></div>{showCorrections && questions.map((question) => <StudyQuestion key={`${run}-result-${question.id}`} question={question} initialAnswer={answers[question.id]} reveal disabled />)}</section>;
  }
  const current = questions[index];
  return <section><div className="cr-exam-progress"><strong>Question {index + 1} / {questions.length}</strong><span>{answered} validée(s)</span></div><progress value={answered} max={questions.length} aria-label="Questions validées" /><StudyQuestion key={`${run}-${current.id}`} question={current} mode="exam" initialAnswer={answers[current.id]} onAnswered={(answer) => { setAnswers((previous) => ({ ...previous, [current.id]: answer })); onAttempt(current, answer, 'exam'); }} /><div className="cr-pagination"><button className="cr-secondary" onClick={() => setIndex((value) => value - 1)} disabled={index === 0}><ChevronLeft size={17} />Précédente</button>{index < questions.length - 1 ? <button className="cr-primary" onClick={() => setIndex((value) => value + 1)}>Suivante <ChevronRight size={17} /></button> : <button className="cr-primary" disabled={answered !== questions.length} onClick={finish}>Terminer <CheckCheck size={17} /></button>}</div>{answered !== questions.length && index === questions.length - 1 && <p className="cr-muted">Validez les {questions.length - answered} réponse(s) restante(s) pour terminer.</p>}</section>;
}

function CourseFlashcards({ lesson, onInstall, onAttempt, onRecorded }: { lesson: CourseLesson; onInstall: () => void; onAttempt: (question: Question, answer: StudyAnswer, mode: 'practice' | 'exam' | 'qroc' | 'writing' | 'flashcard') => void; onRecorded: (promise: Promise<ReaderState>) => void }) {
  const [index, setIndex] = useState(0);
  const [revealed, setRevealed] = useState(false);
  const [confidence, setConfidence] = useState<Record<string, boolean>>({});
  const [startedAt] = useState(() => new Date().toISOString());
  const card = lesson.flashcards[index];
  const completed = Object.keys(confidence).length;
  function move(next: number) { setIndex(Math.max(0, Math.min(lesson.flashcards.length - 1, next))); setRevealed(false); }
  function rate(correct: boolean) {
    if (!revealed || confidence[card.id] !== undefined) return;
    const next = { ...confidence, [card.id]: correct }; setConfidence(next);
    onAttempt({ id: card.id, subjectId: lesson.subject, lessonId: lesson.id, chapterIndex: card.chapterIndex, prompt: card.q, options: [], correct: [], format: 'QROC', explanation: card.a }, { correct, selected: [] }, 'flashcard');
    if (Object.keys(next).length === lesson.flashcards.length) { const finishedAt = new Date().toISOString(); onRecorded(study.recordSession({ lessonId: lesson.id, subjectId: lesson.subject, mode: 'flashcard', startedAt, finishedAt, questionCount: lesson.flashcards.length, correctCount: Object.values(next).filter(Boolean).length, durationSeconds: Math.round((Date.parse(finishedAt) - Date.parse(startedAt)) / 1000) })); }
  }
  if (!card) return <EmptyContent>Ce cours ne contient pas de flashcards.</EmptyContent>;
  return <section className="cr-flashcards" onKeyDown={(event) => { const target = event.target as HTMLElement; if (target.closest('button,input,textarea,select,a')) return; if (event.key === 'ArrowRight') { event.preventDefault(); move(index + 1); } if (event.key === 'ArrowLeft') { event.preventDefault(); move(index - 1); } if (event.key === ' ') { event.preventDefault(); setRevealed(true); } }} tabIndex={0} aria-label="Flashcards du cours, flèches pour naviguer, espace pour révéler"><div className="cr-exam-progress"><strong>Carte {index + 1} / {lesson.flashcards.length}</strong><span>{completed} autoévaluée(s)</span></div><div className="cr-flashcard cr-card"><span className="cr-kicker">RAPPELEZ AVANT DE RETOURNER</span><h2><InlineText text={card.q} /></h2>{revealed ? <div className="cr-flashcard-answer" role="status"><span className="cr-kicker">RÉPONSE</span><p><InlineText text={card.a} /></p></div> : <p className="cr-muted">Formulez la réponse mentalement ou à voix haute.</p>}<small>PDF p. {card.pages}</small></div>{!revealed ? <button className="cr-primary cr-full" onClick={() => setRevealed(true)}>Afficher la réponse <ArrowRight size={17} /></button> : confidence[card.id] !== undefined ? <p className="cr-saved"><CheckCheck size={17} />Autoévaluation : {confidence[card.id] ? 'retrouvée' : 'à revoir'}</p> : <div className="cr-actions"><button className="cr-secondary" onClick={() => rate(false)}>À revoir</button><button className="cr-primary" onClick={() => rate(true)}>Je savais <Check size={17} /></button></div>}<div className="cr-pagination"><button className="cr-secondary" disabled={index === 0} onClick={() => move(index - 1)}><ChevronLeft size={17} />Précédente</button><button className="cr-secondary" disabled={index === lesson.flashcards.length - 1} onClick={() => move(index + 1)}>Suivante <ChevronRight size={17} /></button></div><div className="cr-scheduler-bridge cr-card"><Layers3 size={23} /><h3>Les revoir au bon moment</h3><p>Ajoutez ces cartes à vos decks Medora pour utiliser le planificateur FSRS. Cette lecture rapide ne change pas les échéances de vos cartes.</p><button className="cr-primary" onClick={onInstall}>Ajouter à mes decks FSRS <ArrowRight size={17} /></button></div></section>;
}

export default function CourseReader({ lessonId, onClose, onInstallDeck, onFeynman, onNavigateLesson }: Props) {
  const [lesson, setLesson] = useState<CourseLesson | null>(null);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState('');
  const [actionError, setActionError] = useState('');
  const [attempt, setAttempt] = useState(0);
  const [state, setState] = useState<ReaderState | null>(null);
  const [chapter, setChapter] = useState(0);
  const [tab, setTab] = useState<ReaderTab>('course');
  const [tocOpen, setTocOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [notesOpen, setNotesOpen] = useState(false);
  const [note, setNote] = useState('');
  const [savedNote, setSavedNote] = useState('');
  const [noteBusy, setNoteBusy] = useState(false);
  const [noteSaved, setNoteSaved] = useState(false);
  const [deckBusy, setDeckBusy] = useState(false);
  const [deckSaved, setDeckSaved] = useState(false);
  const [figure, setFigure] = useState<LessonFigure | null>(null);
  const [practiceChapter, setPracticeChapter] = useState<number | null>(null);
  const [neighbors, setNeighbors] = useState<{ previous?: { id: string; title: string }; next?: { id: string; title: string } }>({});
  const content = useRef<HTMLDivElement>(null);
  useEffect(() => {
    let active = true; setLoading(true); setLoadError(''); setActionError(''); setDeckSaved(false); setLesson(null); setTab('course'); setChapter(0); setFigure(null); setNoteSaved(false); setPracticeChapter(null);
    Promise.all([loadLesson(lessonId), Promise.resolve(study.load())]).then(([loaded, saved]) => {
      if (!active) return; setLesson(loaded); setState(saved); setNote(saved.notes[lessonId] || ''); setSavedNote(saved.notes[lessonId] || '');
      const resume = saved.lastRead?.lessonId === lessonId ? saved.lastRead.chapterIndex : 0;
      const initialChapter = Math.max(0, Math.min(loaded.sections.length - 1, resume)); setChapter(initialChapter); setLoading(false); void study.setLastRead(lessonId, initialChapter).then((latest) => { if (active) setState(latest); }).catch((error: unknown) => { if (active) setActionError(error instanceof Error ? error.message : 'La position de lecture n’a pas pu être enregistrée.'); });
    }).catch((error: unknown) => { if (active) { setLoadError(error instanceof Error ? error.message : 'Le cours n’a pas pu être chargé.'); setLoading(false); } });
    loadCurriculum().then((manifest) => {
      if (!active) return;
      const current = manifest.lessons.find((item) => item.id === lessonId); const sameSubject = manifest.lessons.filter((item) => item.subject === current?.subject); const position = sameSubject.findIndex((item) => item.id === lessonId);
      setNeighbors({ previous: position > 0 ? sameSubject[position - 1] : undefined, next: position >= 0 ? sameSubject[position + 1] : undefined });
    }).catch(() => { if (active) setNeighbors({}); });
    return () => { active = false; };
  }, [lessonId, attempt]);
  function persist(promise: Promise<ReaderState>) {
    setActionError(''); void promise.then(setState).catch((error: unknown) => setActionError(error instanceof Error ? error.message : 'L’enregistrement a échoué. Réessayez.'));
  }
  function changeChapter(index: number) {
    if (!lesson) return;
    const next = Math.max(0, Math.min(lesson.sections.length - 1, index)); setChapter(next); setTocOpen(false); setTab('course'); persist(study.setLastRead(lesson.id, next)); content.current?.scrollTo({ top: 0, behavior: 'auto' });
  }
  function changeTab(next: ReaderTab) { setTab(next); setTocOpen(false); content.current?.scrollTo({ top: 0, behavior: 'auto' }); }
  function close() { if (note !== savedNote && !window.confirm('Votre note contient des modifications non enregistrées. Fermer sans les enregistrer ?')) return; onClose(); }
  async function saveNote() {
    setNoteBusy(true); setActionError(''); setNoteSaved(false);
    try { const saved = await study.setNote(lessonId, note); setState(saved); setSavedNote(note); setNoteSaved(true); } catch (error) { setActionError(error instanceof Error ? error.message : 'La note n’a pas pu être enregistrée.'); } finally { setNoteBusy(false); }
  }
  async function installDeck() {
    if (!lesson || deckBusy) return; setDeckBusy(true); setActionError('');
    try { await onInstallDeck(lesson); setDeckSaved(true); } catch (error) { setActionError(error instanceof Error ? error.message : 'Le deck n’a pas pu être ajouté.'); } finally { setDeckBusy(false); }
  }
  function recordAnswer(question: Question, answer: StudyAnswer, mode: 'practice' | 'exam' | 'qroc' | 'writing' | 'flashcard') {
    if (!lesson) return;
    persist(study.recordAttempt({ questionId: question.canonicalId || question.id, lessonId: lesson.id, subjectId: lesson.subject, chapterIndex: question.chapterIndex, mode, correct: answer.correct, selected: answer.selected, responseText: answer.responseText }));
  }
  const settings = state?.settings;
  const readerStyle = { '--cr-font-size': `${settings?.fontSize || 18}px`, '--cr-line-height': settings?.lineHeight || 1.75 } as CSSProperties;
  const read = [...new Set(state?.read[lessonId] || [])].filter((index) => index >= 0 && index < (lesson?.sections.length || 0));
  const section = lesson?.sections[chapter];
  const bookmarked = state?.bookmarks.includes(lessonId) || false;
  const activeQcm = lesson ? activeQuestions(lesson.questions) : [];
  const chapterPractice = lesson && practiceChapter !== null ? lesson.chapterPractice[practiceChapter] : undefined;
  const practiceQuestions = lesson && practiceChapter !== null ? activeQuestions(lesson.questions.filter((question, index) => chapterPractice?.qcm.includes(index) || question.chapterIndex === practiceChapter)) : activeQcm;
  const practiceCards = lesson && practiceChapter !== null ? lesson.flashcards.filter((card, index) => chapterPractice?.cards.includes(index) || card.chapterIndex === practiceChapter) : lesson?.flashcards || [];
  const filteredTabs = tabLabels.filter(([key]) => !(key === 'qroc' && !lesson?.qroc.length) && !(key === 'writing' && !lesson?.writing.length));
  return <div className={`course-reader cr-theme-${settings?.readerTheme || 'light'} cr-font-${settings?.readerFont || 'system'}`} style={readerStyle}>
    <header className="cr-toolbar"><button className="cr-icon" aria-label="Fermer le cours" onClick={close}><ArrowLeft size={22} /></button><div className="cr-toolbar-title"><strong>{lesson?.title || 'Votre cours'}</strong><span>{lesson ? `${read.length} / ${lesson.sections.length} chapitres lus` : 'Chargement…'}</span></div><button className={`cr-icon ${bookmarked ? 'is-active' : ''}`} onClick={() => persist(study.setBookmark(lessonId, !bookmarked))} disabled={!state} aria-label={bookmarked ? 'Retirer des favoris' : 'Ajouter aux favoris'} aria-pressed={bookmarked}><Bookmark size={21} fill={bookmarked ? 'currentColor' : 'none'} /></button><button className="cr-icon" aria-label="Réglages de lecture" aria-expanded={settingsOpen} onClick={() => setSettingsOpen((value) => !value)}><Settings2 size={21} /></button></header>
    <div className="cr-reading-progress" role="progressbar" aria-label="Chapitres lus" aria-valuemin={0} aria-valuemax={lesson?.sections.length || 1} aria-valuenow={read.length}><div style={{ width: `${lesson?.sections.length ? read.length / lesson.sections.length * 100 : 0}%` }} /></div>
    {lesson && <nav className="cr-tabs" aria-label="Parcours du cours">{filteredTabs.map(([key, label]) => <button key={key} className={tab === key ? 'is-active' : ''} onClick={() => changeTab(key)} aria-current={tab === key ? 'page' : undefined}>{label}{key === 'qcm' ? <small>{activeQcm.length}</small> : key === 'cards' ? <small>{lesson.flashcards.length}</small> : null}</button>)}</nav>}
    <div className="cr-content" ref={content}>
      {loading ? <div className="cr-loading" role="status"><LoaderCircle size={28} className="spin" /><p>Ouverture du cours…</p></div> : loadError ? <div className="cr-empty" role="alert"><p>{loadError}</p><button className="cr-primary" onClick={() => setAttempt((value) => value + 1)}>Réessayer</button></div> : lesson && <>
        {settingsOpen && <section className="cr-settings cr-card" aria-label="Réglages de lecture"><div className="cr-panel-heading"><h2>À votre rythme</h2><button className="cr-icon" aria-label="Fermer les réglages" onClick={() => setSettingsOpen(false)}><X size={19} /></button></div><label htmlFor={`font-${lesson.id}`}>Taille du texte : {settings?.fontSize || 18} px</label><input id={`font-${lesson.id}`} type="range" min="15" max="26" step="1" value={settings?.fontSize || 18} onChange={(event) => persist(study.updateSettings({ fontSize: Number(event.target.value) }))} /><div className="cr-settings-group"><span>Police</span><div>{([['system', 'Système'], ['atkinson', 'Atkinson'], ['serif', 'Serif']] as const).map(([value, label]) => <button key={value} aria-pressed={(settings?.readerFont || 'system') === value} onClick={() => persist(study.updateSettings({ readerFont: value }))}>{label}</button>)}</div></div><div className="cr-settings-group"><span>Interligne</span><div>{([1.55, 1.75, 1.95] as const).map((value, index) => <button key={value} aria-pressed={(settings?.lineHeight || 1.75) === value} onClick={() => persist(study.updateSettings({ lineHeight: value }))}>{['Compact', 'Normal', 'Aéré'][index]}</button>)}</div></div><div className="cr-settings-group"><span>Thème du lecteur</span><div>{([['light', 'Clair'], ['sepia', 'Sépia'], ['dark', 'Sombre']] as const).map(([value, label]) => <button key={value} aria-pressed={(settings?.readerTheme || 'light') === value} onClick={() => persist(study.updateSettings({ readerTheme: value }))}>{label}</button>)}</div></div></section>}
        {actionError && <div className="cr-error" role="alert">{actionError}<button className="cr-icon" onClick={() => setActionError('')} aria-label="Masquer le message"><X size={17} /></button></div>}
        {deckSaved && <div className="cr-saved" role="status"><CheckCheck size={18} />Deck ajouté à votre bibliothèque Medora. Relisez les cartes avant de les activer.</div>}
        {deckBusy && <div className="cr-saved" role="status"><LoaderCircle size={18} className="spin" />Ajout des cartes à vos decks…</div>}
        {tab === 'course' && <>
          <div className="cr-course-heading"><span className="cr-kicker">{lesson.teacher || 'VOTRE COURS MÉDICAL'}</span><h1>{lesson.title}</h1><p>{lesson.courseName}{lesson.date && ` · ${new Date(`${lesson.date}T12:00:00`).toLocaleDateString('fr-FR')}`}</p></div>
          <button className="cr-toc-toggle cr-secondary" aria-expanded={tocOpen} onClick={() => setTocOpen((value) => !value)}><List size={18} /><span>Sommaire · chapitre {chapter + 1}/{lesson.sections.length}</span><ChevronRight size={17} /></button>
          {tocOpen && <nav className="cr-toc cr-card" aria-label="Chapitres du cours">{lesson.sections.map((item, index) => <button key={index} aria-current={chapter === index ? 'location' : undefined} className={chapter === index ? 'is-current' : ''} onClick={() => changeChapter(index)}><span>{String(index + 1).padStart(2, '0')}</span><strong>{item.heading}</strong>{read.includes(index) && <Check size={16} aria-label="Lu" />}</button>)}</nav>}
          {chapter === 0 && lesson.hook && <div className="cr-hook"><BookOpen size={22} /><p><InlineText text={lesson.hook} /></p></div>}
          {section && <article className="cr-chapter"><div className="cr-chapter-meta"><span>CHAPITRE {chapter + 1}</span><span>PDF p. {section.pages}</span></div><h2>{section.heading}</h2><div className="cr-prose">{section.paragraphs.map((paragraph, index) => <ReaderParagraph key={index} paragraph={paragraph} />)}{section.figures?.map((item, index) => <CourseFigure key={`${chapter}-${index}`} figure={item} onOpen={setFigure} />)}{section.memory && <aside className="cr-memory"><span className="cr-kicker">LE FIL À GARDER</span><p><InlineText text={section.memory} /></p></aside>}</div><div className="cr-chapter-actions"><button className={read.includes(chapter) ? 'cr-secondary' : 'cr-primary'} onClick={() => persist(study.markRead(lesson.id, chapter, !read.includes(chapter)))}><CheckCheck size={18} />{read.includes(chapter) ? 'Chapitre lu · annuler' : 'Marquer ce chapitre comme lu'}</button>{onFeynman && <button className="cr-secondary" onClick={() => { if (note === savedNote || window.confirm('Ouvrir Feynman sans enregistrer votre note ?')) onFeynman(section.heading, section.paragraphs.map((paragraph) => typeof paragraph === 'string' ? paragraph : `${paragraph.title || ''}\n${(paragraph.items || []).join('\n')}`).join('\n\n')); }}>Expliquer avec Feynman <ArrowRight size={16} /></button>}</div></article>}
          <div className="cr-pagination"><button className="cr-secondary" onClick={() => changeChapter(chapter - 1)} disabled={chapter === 0}><ChevronLeft size={17} />Précédent</button><button className="cr-primary" onClick={() => changeChapter(chapter + 1)} disabled={chapter === lesson.sections.length - 1}>Suivant <ChevronRight size={17} /></button></div>
          {activeQcm.length > 0 && <button className="cr-secondary cr-full" onClick={() => { setPracticeChapter(chapter); changeTab('qcm'); }}>Vérifier ma compréhension de ce chapitre <ArrowRight size={17} /></button>}
          {chapter === lesson.sections.length - 1 && <div className="cr-card cr-lesson-review"><h2>Où en êtes-vous dans ce cours ?</h2><p>Une appréciation personnelle pour votre progression. Les échéances de vos cartes restent calculées par FSRS.</p><div className="cr-actions">{([['again', 'À reprendre'], ['partial', 'En cours'], ['mastered', 'Compris']] as const).map(([level, label]) => <button className="cr-secondary" key={level} onClick={() => persist(study.recordLessonReview(lesson.id, level))}>{label}</button>)}</div>{Boolean(state?.lessonReviews[lesson.id]?.length) && <p className="cr-muted">Dernier bilan : {({ again: 'à reprendre', partial: 'en cours', mastered: 'compris' })[state!.lessonReviews[lesson.id].at(-1)!.level]}.</p>}</div>}
        </>}
        {tab === 'summary' && <section className="cr-summary"><div className="cr-section-heading"><span className="cr-kicker">LA VUE D’ENSEMBLE</span><h1>Retenir le fil.</h1><p>Les repères du cours et le sens de chaque chapitre.</p></div>{lesson.summary.map((item, index) => <article className="cr-card" key={index}><span className="cr-kicker">PDF p. {item.pages}</span><h2>{item.name}</h2><p><InlineText text={item.detail} /></p></article>)}{lesson.flow && <div className="cr-card"><h2>Le raisonnement en séquence</h2><ol>{lesson.flow.map((step, index) => <li key={index}><InlineText text={step} /></li>)}</ol></div>}{lesson.essenceSections.length > 0 && <h2 className="cr-group-heading">Le sens de chaque chapitre</h2>}{lesson.essenceSections.map((item, index) => <article className="cr-card cr-essence" key={index}><span className="cr-kicker">CHAPITRE {index + 1} · PDF p. {item.pages}</span><h2>{item.heading}</h2><h3>Pourquoi ce chapitre ?</h3><p><InlineText text={item.goal} /></p><h3>Le raisonnement</h3><p><InlineText text={item.logic} /></p><h3>Le réflexe à garder</h3><p><InlineText text={item.heuristic} /></p>{item.examAnchor && <><h3>À savoir expliquer</h3><p><InlineText text={item.examAnchor} /></p></>}<button className="cr-secondary" onClick={() => changeChapter(essenceChapter(lesson, item.heading, item.pages, index))}>Lire ce chapitre <ArrowRight size={16} /></button></article>)}</section>}
        {(tab === 'qcm' || tab === 'qroc' || tab === 'writing') && <section className="cr-question-list"><div className="cr-section-heading"><span className="cr-kicker">RAPPEL ACTIF</span><h1>{tab === 'qcm' ? 'Retrouver, puis vérifier.' : tab === 'writing' ? 'Construire son raisonnement.' : 'Répondre avec ses mots.'}</h1><p>{tab === 'qcm' ? 'Les réponses multiples sont corrigées sur l’ensemble exact des choix.' : 'Comparez votre réponse au modèle et autoévaluez-vous. Le repérage lexical ne constitue pas une correction médicale par IA.'}</p></div>{tab === 'qcm' && <div className="cr-practice-filter"><label htmlFor="cr-qcm-chapter">Périmètre de l’entraînement</label><select id="cr-qcm-chapter" value={practiceChapter ?? 'all'} onChange={(event) => setPracticeChapter(event.target.value === 'all' ? null : Number(event.target.value))}><option value="all">Tout le cours ({activeQcm.length} QCM)</option>{lesson.sections.map((section, index) => <option key={index} value={index}>Chapitre {index + 1} · {section.heading}</option>)}</select></div>}{(tab === 'qcm' ? practiceQuestions : tab === 'writing' ? activeQuestions(lesson.writing) : activeQuestions(lesson.qroc)).map((question) => <StudyQuestion key={`${tab}-${question.id}`} question={question} initialResponse={state?.writingDrafts[question.id]} onSaveDraft={tab !== 'qcm' ? async (response) => { const saved = await study.saveWritingDraft(question.id, response); setState(saved); } : undefined} onAnswered={(answer) => recordAnswer(question, answer, tab === 'qcm' ? 'practice' : tab === 'writing' ? 'writing' : 'qroc')} />)}{tab === 'qcm' && !practiceQuestions.length && <EmptyContent>Aucun QCM actif dans ce cours.</EmptyContent>}</section>}
        {tab === 'cards' && <><div className="cr-practice-filter"><label htmlFor="cr-cards-chapter">Cartes à parcourir</label><select id="cr-cards-chapter" value={practiceChapter ?? 'all'} onChange={(event) => setPracticeChapter(event.target.value === 'all' ? null : Number(event.target.value))}><option value="all">Tout le cours ({lesson.flashcards.length} cartes)</option>{lesson.sections.map((section, index) => <option key={index} value={index}>Chapitre {index + 1} · {section.heading}</option>)}</select></div><CourseFlashcards key={`${lesson.id}-${practiceChapter}`} lesson={{ ...lesson, flashcards: practiceCards }} onInstall={() => void installDeck()} onAttempt={recordAnswer} onRecorded={persist} /></>}
        {tab === 'assessment' && <CourseAssessment lesson={lesson} onAttempt={recordAnswer} onRecorded={persist} />}
        {tab === 'sources' && <section className="cr-sources"><div className="cr-section-heading"><span className="cr-kicker">RETOURNER AU DOCUMENT</span><h1>Sources & précisions.</h1><p>Les liens externes s’ouvrent uniquement à votre demande. Un document Drive privé peut demander votre connexion et une autorisation.</p></div><SourceLink source={lesson.source} />{lesson.relatedSources?.map((source, index) => <SourceLink key={index} source={source} />)}{lesson.editorialNote && <div className="cr-card"><h2>Note éditoriale d’origine</h2><p><InlineText text={lesson.editorialNote} /></p></div>}{lesson.flags.length > 0 && <div className="cr-card"><h2>Corrections et points à vérifier</h2>{lesson.flags.map((flag, index) => <div className="cr-source-flag" key={index}><h3>{flag.title}</h3><p><InlineText text={flag.detail} /></p></div>)}</div>}<p className="cr-muted">Contenu pédagogique repris de votre archive MED2. Les formulations d’origine et corrections éditoriales ne constituent pas une validation médicale indépendante.</p></section>}
        <section className="cr-notes"><button className="cr-notes-toggle" onClick={() => setNotesOpen((value) => !value)} aria-expanded={notesOpen}><StickyNote size={19} /><strong>Mes notes personnelles</strong>{note !== savedNote && <span>Non enregistrées</span>}<ChevronRight size={17} /></button>{notesOpen && <div className="cr-notes-editor"><label htmlFor={`note-${lesson.id}`}>Compléments, questions et liens à faire</label><textarea id={`note-${lesson.id}`} rows={6} maxLength={40000} value={note} onChange={(event) => { setNote(event.target.value); setNoteSaved(false); }} placeholder="Vos notes pour ce cours…" /><p className="cr-muted">Vos modifications sont conservées après avoir appuyé sur Enregistrer.</p><button className="cr-primary" disabled={noteBusy || note === savedNote} onClick={() => void saveNote()}>{noteBusy ? <LoaderCircle className="spin" size={17} /> : <Check size={17} />}Enregistrer ma note</button>{noteSaved && <p className="cr-saved" role="status"><CheckCheck size={17} />Note enregistrée.</p>}</div>}</section>
        {onNavigateLesson && (neighbors.previous || neighbors.next) && <nav className="cr-adjacent" aria-label="Autres cours de cette matière">{neighbors.previous && <button onClick={() => { if (note === savedNote || window.confirm('Changer de cours sans enregistrer votre note ?')) onNavigateLesson(neighbors.previous!.id); }}><ChevronLeft size={17} /><span><small>Cours précédent</small>{neighbors.previous.title}</span></button>}{neighbors.next && <button onClick={() => { if (note === savedNote || window.confirm('Changer de cours sans enregistrer votre note ?')) onNavigateLesson(neighbors.next!.id); }}><span><small>Cours suivant</small>{neighbors.next.title}</span><ChevronRight size={17} /></button>}</nav>}
      </>}
    </div>
    {figure && <FigureDialog figure={figure} onClose={() => setFigure(null)} />}
  </div>;
}
