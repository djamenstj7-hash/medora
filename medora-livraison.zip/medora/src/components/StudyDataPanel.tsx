import { useEffect, useRef, useState } from 'react';
import { Download, FolderInput, LoaderCircle, ShieldCheck, Upload } from 'lucide-react';
import { study } from '../lib/study';
import type { StudyState } from '../lib/study';
import { curriculumCacheStatus, downloadCurriculum, protectLocalStorage } from '../lib/curriculum-offline';
import type { OfflineProgress } from '../lib/curriculum-offline';
import { isConfigured } from '../lib/supabase';
import { engineCacheStatus, downloadEngine } from '../lib/engine-offline';

function saveJSON(value: unknown) {
  const blob = new Blob([JSON.stringify(value, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob); const link = document.createElement('a');
  link.href = url; link.download = `medora-sauvegarde-${new Date().toISOString().slice(0, 10)}.json`;
  document.body.append(link); link.click(); link.remove(); window.setTimeout(() => URL.revokeObjectURL(url), 60_000);
}

export default function StudyDataPanel({ onChanged }: { onChanged: () => Promise<void> }) {
  const [message, setMessage] = useState(''); const [error, setError] = useState(false);
  const [busy, setBusy] = useState(false); const [selected, setSelected] = useState<{ name: string; value: unknown }>();
  const [offline, setOffline] = useState<OfflineProgress>(); const [files, setFiles] = useState(0);
  const [engineFiles, setEngineFiles] = useState(0);
  const [syncStatus, setSyncStatus] = useState<StudyState['syncStatus']>();
  const controller = useRef<AbortController | undefined>(undefined); const input = useRef<HTMLInputElement>(null); const catalogueInput = useRef<HTMLInputElement>(null);
  const updateStatus = () => { void curriculumCacheStatus().then(status => setFiles(status.files)); void engineCacheStatus().then(status => setEngineFiles(status.files)); };
  useEffect(() => { updateStatus(); return () => controller.current?.abort(); }, []);
  useEffect(() => { let active = true; const load = () => { void study.load().then(value => { if (active) setSyncStatus(value.syncStatus); }).catch(() => undefined); }; load(); const unsubscribe = study.subscribe(load); return () => { active = false; unsubscribe(); }; }, []);
  const failure = (reason: unknown) => { setError(true); setMessage(reason instanceof Error ? reason.message : 'Cette opération n’a pas pu aboutir.'); };
  const exportData = async () => { setBusy(true); setError(false); try { saveJSON(await study.exportBackup()); setMessage('Sauvegarde préparée. Conserve le fichier JSON dans Fichiers.'); } catch (reason) { failure(reason); } finally { setBusy(false); } };
  const selectFile = async (file?: File) => {
    if (!file) return; setError(false); setMessage('');
    try { if (file.size > 20_000_000) throw new Error('La sauvegarde dépasse 20 Mo.'); const value: unknown = JSON.parse(await file.text()); setSelected({ name: file.name, value }); }
    catch (reason) { failure(reason); }
    if (input.current) input.current.value = '';
  };
  const restore = async () => {
    if (!selected) return; setBusy(true); setError(false);
    try { await study.importBackup(selected.value); setSelected(undefined); await onChanged(); setMessage('Progression fusionnée. Les données déjà présentes et les planifications FSRS du serveur sont conservées.'); }
    catch (reason) { failure(reason); } finally { setBusy(false); }
  };
  const download = async (programme: 'med2' | 'engine' = 'med2') => {
    setBusy(true); setError(false); setMessage(''); const abort = new AbortController(); controller.current = abort;
    try { const result = await (programme === 'engine' ? downloadEngine : downloadCurriculum)(setOffline, abort.signal); setMessage(result.failed.length ? `${result.completed}/${result.total} fichiers disponibles. ${result.failed.length} téléchargement(s) à reprendre en relançant cette action.` : `${result.completed} fichiers du programme sont disponibles hors connexion sur cet appareil.`); }
    catch (reason) { failure(reason); }
    finally { setBusy(false); setOffline(undefined); updateStatus(); controller.current = undefined; }
  };
  const importCatalogue = async (file?: File) => {
    if (!file) return; setBusy(true); setError(false);
    try { if (file.size > 5_000_000) throw new Error('Le catalogue dépasse 5 Mo.'); await study.importCatalogue(JSON.parse(await file.text())); await onChanged(); setMessage('Catalogue fusionné. Les cours intégrés restent disponibles ; les nouvelles références apparaissent dans Sources & annales.'); }
    catch (reason) { failure(reason); }
    finally { setBusy(false); if (catalogueInput.current) catalogueInput.current.value = ''; }
  };
  const resetProgress = async () => {
    if (!window.confirm('Effacer uniquement le suivi MED2 : lectures, réponses, évaluations et sessions ? Vos notes, favoris, réglages, cours importés et révisions FSRS seront conservés.')) return;
    setBusy(true); setError(false);
    try { await study.resetProgress(); await onChanged(); setMessage('Suivi MED2 réinitialisé. Vos notes et vos révisions FSRS sont conservées.'); }
    catch (reason) { failure(reason); } finally { setBusy(false); }
  };
  return <>
    <section className="settings-section study-backup-section"><h3>Sauvegardes & progression</h3><p>Exporte ta progression MED2 et MED_ENGINE, tes notes et une copie de tes decks Medora. L’import fusionne les données ; les échéances FSRS du serveur restent la référence.</p><p role="status">{!isConfigured ? 'Progression pédagogique conservée sur cet appareil : mode démo.' : syncStatus === 'synced' ? 'Progression pédagogique synchronisée avec ton compte.' : syncStatus === 'pending' ? 'Progression pédagogique conservée sur cet appareil ; envoi en attente. Garde une sauvegarde avant de changer d’appareil.' : syncStatus === 'unavailable' ? 'Synchronisation MED2 indisponible. Vérifie la connexion et l’installation de la mise à jour Supabase.' : 'Vérification de la synchronisation MED2…'}</p><div className="study-backup-actions"><button className="secondary full" onClick={() => void exportData()} disabled={busy}><Download size={17} />Exporter ma sauvegarde</button><button className="secondary full" onClick={() => input.current?.click()} disabled={busy}><Upload size={17} />Importer une sauvegarde JSON</button></div><input type="file" accept=".json,application/json" aria-label="Choisir une sauvegarde Medora ou MED2" ref={input} hidden onChange={event => void selectFile(event.target.files?.[0])} />
      {selected && <div className="backup-confirm"><p><strong>{selected.name}</strong><br />Importer cette progression dans le compte actuellement ouvert ? Les réponses, lectures et notes seront fusionnées. {isConfigured ? 'La copie des decks et révisions contenue dans une sauvegarde est conservée comme archive ; elle ne remplace pas les données de ton compte Supabase.' : 'La copie de bibliothèque est conservée comme archive ; cette importation restaure la progression pédagogique.'}</p><button className="secondary full" disabled={busy} onClick={() => void restore()}><FolderInput size={17} />Confirmer la fusion</button><button className="text-button" disabled={busy} onClick={() => setSelected(undefined)}>Annuler</button></div>}
      <details><summary>Récupérer mes résultats de l’ancien site</summary><p className="backup-note">Dans l’ancienne application MED2, ouvre Suivi ou Réglages → Mes données → Exporter. Enregistre le JSON dans Fichiers, puis importe-le ici. Medora ne peut pas lire directement le stockage d’un autre site. Les anciens intervalles de rappel sont conservés dans la sauvegarde, sans remplacer FSRS.</p></details>
      <details><summary>Catalogue personnel & suivi</summary><p className="backup-note">Un ancien catalogue JSON peut enrichir les références et les matières. Les 69 cours intégrés et vos decks personnels restent disponibles.</p><button className="secondary full" disabled={busy} onClick={() => catalogueInput.current?.click()}><FolderInput size={17} />Importer un catalogue JSON</button><input type="file" accept=".json,application/json" ref={catalogueInput} hidden aria-label="Choisir un catalogue de cours" onChange={event => void importCatalogue(event.target.files?.[0])} /><button className="text-button danger" disabled={busy} onClick={() => void resetProgress()}>Réinitialiser uniquement le suivi MED2</button></details>
    </section>
    <section className="settings-section study-backup-section"><h3>Mon programme hors connexion</h3><p>Les cours ouverts se conservent progressivement. Prépare MED2 ou MED_ENGINE avant un déplacement et garde l’application ouverte jusqu’à la fin du téléchargement.</p><p>{files} fichiers MED2 et {engineFiles} fichiers MED_ENGINE conservés sur cet appareil. Les données personnelles restent dans un stockage séparé.</p>
      {offline && <><div className="curriculum-offline-progress" role="progressbar" aria-label="Téléchargement du programme" aria-valuenow={offline.completed} aria-valuemin={0} aria-valuemax={offline.total}><span style={{ width: `${offline.total ? offline.completed / offline.total * 100 : 0}%` }} /></div><p>{offline.completed}/{offline.total} fichiers · {offline.failed} à reprendre</p></>}
      <div className="offline-download-actions"><button className="secondary full" disabled={busy || !navigator.onLine} onClick={() => void download()}>{offline ? <LoaderCircle className="spin" size={17} /> : <Download size={17} />}Télécharger le programme</button><button className="secondary full" disabled={busy || !navigator.onLine} onClick={() => void download('engine')}><Download size={17} />Télécharger MED_ENGINE</button>{offline && <button className="text-button" onClick={() => controller.current?.abort()}>Interrompre le téléchargement</button>}<button className="text-button" disabled={busy} onClick={async () => { setError(false); try { const granted = await protectLocalStorage(); setMessage(granted ? 'Le navigateur a accordé une conservation persistante. Garde aussi une sauvegarde JSON.' : 'Safari garde la gestion de l’espace. Une sauvegarde JSON reste nécessaire pour conserver tes données.'); } catch (reason) { failure(reason); } }}><ShieldCheck size={16} />Demander la protection du stockage</button></div>
    </section>
    {message && <p role="status" className={'study-backup-status ' + (error ? 'error' : '')}>{message}</p>}
  </>;
}
