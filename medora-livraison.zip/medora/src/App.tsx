import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import type { FormEvent, ReactNode } from 'react';
import type { Session } from '@supabase/supabase-js';
import { useRegisterSW } from 'virtual:pwa-register/react';
import { ArrowDownToLine, ArrowRight, BookOpen, Brain, Check, CheckCheck, ChevronRight, CircleHelp, CloudOff, FileText, GraduationCap, HeartPulse, Layers3, LoaderCircle, LogOut, Plus, RefreshCw, Search, Settings2, ShieldCheck, Sparkles, Stethoscope, Target, Trash2, Upload, WifiOff, X } from 'lucide-react';
import { repository } from './lib/repository';
import { getReviewQueue } from './lib/interleaving';
import { isConfigured, supabase } from './lib/supabase';
import type { Deck, FeynmanAssessment, GenerationKind, LibraryData, RatingValue, StudyCard } from './lib/types';

type Tab = 'today' | 'library' | 'import' | 'feynman';
const empty: LibraryData = { decks: [], cards: [], reviews: [] };
const tabs: { id: Tab; label: string; icon: typeof BookOpen }[] = [
  { id: 'today', label: "Aujourd’hui", icon: Layers3 }, { id: 'library', label: 'Bibliothèque', icon: BookOpen },
  { id: 'import', label: 'Importer', icon: Plus }, { id: 'feynman', label: 'Feynman', icon: Brain },
];
const subjects = ['Cardiologie', 'Neurologie', 'Pharmacologie', 'Pneumologie', 'Sémiologie', 'Autre'];
const errorText = (error: unknown) => error instanceof Error ? error.message : 'Une erreur est survenue. Réessayez.';
const dayKey = (value: string | Date) => new Date(value).toLocaleDateString('fr-CA');
const formatDate = (value: string) => new Date(value).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' });
const kindLabel = (kind: string) => kind === 'qcm' ? 'QCM' : kind === 'case' ? 'Cas clinique' : 'Rappel actif';
function IconFor({ subject, size = 22 }: { subject: string; size?: number }) {
  const Icon = subject === 'Cardiologie' ? HeartPulse : subject === 'Neurologie' ? Brain : subject === 'Pharmacologie' ? ShieldCheck : Stethoscope;
  return <Icon size={size} strokeWidth={1.7} />;
}

export default function App() {
  const [tab, setTab] = useState<Tab>(() => {
    const value = window.location.hash.slice(1);
    return tabs.some((item) => item.id === value) ? value as Tab : 'today';
  });
  const [data, setData] = useState<LibraryData>(empty);
  const [loading, setLoading] = useState(true);
  const [session, setSession] = useState<Session | null>(null);
  const [authReady, setAuthReady] = useState(!isConfigured);
  const [settings, setSettings] = useState(false);
  const [detail, setDetail] = useState<Deck | null>(null);
  const [review, setReview] = useState<StudyCard[] | null>(null);
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');
  const [pending, setPending] = useState(0);
  const [conflicts, setConflicts] = useState(0);
  const [online, setOnline] = useState(navigator.onLine);
  const [syncing, setSyncing] = useState(false);
  const currentUser = useRef<string | null>(null);
  const { needRefresh: [needRefresh], updateServiceWorker } = useRegisterSW();
  const ready = !isConfigured || Boolean(session);
  const notify = useCallback((message: string) => { setNotice(message); }, []);
  const refresh = useCallback(async () => {
    if (isConfigured && !session) { setData(empty); setLoading(false); return; }
    const userAtStart = session?.user.id || null;
    const stillCurrent = () => !isConfigured || currentUser.current === userAtStart;
    setLoading(true);
    try { const next = await repository.load(); const events = await repository.getPendingReviews(); if (stillCurrent()) { setData(next); setPending(events.length); setConflicts(events.filter(e => e.conflict).length); setError(''); } }
    catch (err) { if (stillCurrent()) setError(errorText(err)); }
    finally { if (stillCurrent()) setLoading(false); }
  }, [session]);

  useEffect(() => {
    if (!supabase) return;
    void supabase.auth.getSession().then(({ data: result, error: err }) => {
      if (err) setError(err.message);
      currentUser.current = result.session?.user.id || null; setSession(result.session); setAuthReady(true);
    });
    const { data: listener } = supabase.auth.onAuthStateChange((_event, value) => {
      const nextUser = value?.user.id || null;
      if (currentUser.current !== nextUser) { setData(empty); setReview(null); setDetail(null); setPending(0); setConflicts(0); }
      currentUser.current = nextUser; setSession(value); setAuthReady(true);
    });
    return () => listener.subscription.unsubscribe();
  }, []);
  useEffect(() => { if (authReady) void refresh(); }, [authReady, refresh]);
  useEffect(() => { if (!notice) return; const id = window.setTimeout(() => setNotice(''), 5000); return () => clearTimeout(id); }, [notice]);
  useEffect(() => {
    const change = () => setOnline(navigator.onLine);
    const hash = () => { const id = location.hash.slice(1); if (tabs.some(t => t.id === id)) setTab(id as Tab); };
    window.addEventListener('online', change); window.addEventListener('offline', change); window.addEventListener('hashchange', hash);
    return () => { window.removeEventListener('online', change); window.removeEventListener('offline', change); window.removeEventListener('hashchange', hash); };
  }, []);
  const sync = useCallback(async () => {
    if (syncing || !ready) return;
    setSyncing(true);
    try {
      const result = await repository.syncPending(); setConflicts(result.conflicts);
      await refresh();
      if (result.conflicts) notify(`${result.conflicts} révision(s) en conflit : ouvrez les réglages pour les résoudre.`);
      else if (result.sent) notify(`${result.sent} révision(s) synchronisée(s).`);
    } catch (err) { setError(errorText(err)); }
    finally { setSyncing(false); }
  }, [ready, refresh, notify, syncing]);
  useEffect(() => {
    if (online && authReady && ready) void sync();
    // Synchronize on connectivity/auth transitions, never in a render loop.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [online, authReady, session?.user.id]);
  useEffect(() => {
    const foreground = () => { if (document.visibilityState === 'visible' && navigator.onLine && ready) void sync(); };
    document.addEventListener('visibilitychange', foreground);
    return () => document.removeEventListener('visibilitychange', foreground);
  }, [sync, ready]);

  const queue = useMemo(() => getReviewQueue(data.cards, data.decks, new Date(), 20), [data]);
  const navigate = (id: Tab) => { setTab(id); location.hash = id; window.scrollTo({ top: 0 }); };
  const startReview = (deckId?: string) => {
    const cards = getReviewQueue(data.cards.filter(c => !deckId || c.deck_id === deckId), data.decks, new Date(), 20);
    if (!cards.length) return notify('Vous êtes à jour. Revenez à la prochaine échéance.');
    setDetail(null); setReview(cards);
  };

  return <div className="app-shell">
    <aside className="sidebar" inert={review !== null || settings || detail !== null ? true : undefined}><Brand /><div className="sidebar-caption">VOTRE ESPACE D’APPRENTISSAGE</div><nav>{tabs.map(({ id, label, icon: Icon }) => <button key={id} className={tab === id ? 'side-link active' : 'side-link'} onClick={() => navigate(id)}><Icon size={20} />{label}{id === 'today' && queue.length > 0 && <span className="side-count">{queue.length}</span>}</button>)}</nav><div className="sidebar-bottom"><div className="quiet-card"><ShieldCheck size={20} /><strong>Un peu chaque jour.</strong><p>Des connaissances qui restent, au-delà de l’examen.</p></div><button className="side-link" onClick={() => setSettings(true)}><Settings2 size={20} />Réglages & compte</button></div></aside>
    <div className="page-wrap" inert={review !== null || settings || detail !== null ? true : undefined}>
      <header className="topbar"><div className="mobile-brand"><Brand /></div><div className="desktop-breadcrumb">Mon espace <ChevronRight size={13} /><span>{tabs.find(t => t.id === tab)?.label}</span></div><div className="topbar-actions"><span className={'status-dot ' + (!online ? 'offline' : '')} /><span className="connection-label">{!online ? 'Hors connexion' : isConfigured ? 'Espace personnel' : 'Démo locale'}</span><button className="avatar" aria-label="Ouvrir les réglages" onClick={() => setSettings(true)}>{session?.user.email?.slice(0, 2).toUpperCase() || 'M'}</button></div></header>
      <main className="main-content">
        {!isConfigured && <div className="demo-line"><span className="tiny-pill">DÉMO</span> Explorez Medora. Vos données restent sur cet appareil.<button onClick={() => setSettings(true)} aria-label="En savoir plus sur la démo"><CircleHelp size={16} /></button></div>}
        {!online && <div className="info-banner"><WifiOff size={17} />Les cartes déjà chargées restent accessibles. {pending > 0 && `${pending} révision(s) en attente.`}</div>}
        {error && <div className="error-banner" role="alert"><span>{error}</span><button onClick={() => void refresh()} aria-label="Réessayer"><RefreshCw size={17} /></button></div>}
        {needRefresh && <div className="info-banner"><ArrowDownToLine size={18} />Une nouvelle version est prête.<button className="text-button" onClick={() => void updateServiceWorker(true)}>Mettre à jour</button></div>}
        {!authReady || loading ? <div className="loading-state"><LoaderCircle className="spin" size={26} /><p>Votre espace se prépare…</p></div> : !ready ? <Welcome onLogin={() => setSettings(true)} /> : <>
          {tab === 'today' && <Dashboard data={data} queue={queue} onReview={startReview} onNavigate={navigate} onDeck={setDetail} />}
          {tab === 'library' && <Library data={data} onDeck={setDetail} onImport={() => navigate('import')} />}
          {tab === 'import' && <ImportCourse onDone={async (id) => { await refresh(); navigate('library'); setDetail((await repository.load()).decks.find(d => d.id === id) || null); notify('Votre deck est prêt à être relu.'); }} />}
          {tab === 'feynman' && <Feynman />}
        </>}
        <footer className="page-footer"><span>APPRENDRE POUR SOIGNER.</span><span>Rappel actif · FSRS · Entrelacement</span></footer>
      </main>
    </div>
    <nav className="bottom-nav" aria-label="Navigation principale" inert={review !== null || settings || detail !== null ? true : undefined}>{tabs.map(({ id, label, icon: Icon }) => <button key={id} onClick={() => navigate(id)} className={tab === id ? 'active' : ''} aria-current={tab === id ? 'page' : undefined}><Icon size={22} strokeWidth={tab === id ? 2.2 : 1.7} /><span>{label}</span></button>)}</nav>
    {notice && <div className="toast" role="status"><CheckCheck size={18} />{notice}<button aria-label="Fermer" onClick={() => setNotice('')}><X size={16} /></button></div>}
    {settings && <Settings session={session} pending={pending} conflicts={conflicts} onClose={() => setSettings(false)} onSync={sync} syncing={syncing} notify={notify} onRefresh={refresh} />}
    {detail && <DeckDetail deck={detail} cards={data.cards.filter(c => c.deck_id === detail.id)} onClose={() => setDetail(null)} onReview={() => startReview(detail.id)} onChanged={refresh} notify={notify} />}
    {review && <ReviewSession cards={review} decks={data.decks} onClose={() => { setReview(null); void refresh(); }} onChanged={refresh} />}
  </div>;
}

function Brand() { return <div className="brand"><span className="brand-symbol">m<span /></span><span>medora<span className="brand-dot">.</span></span></div>; }
function Welcome({ onLogin }: { onLogin: () => void }) { return <section className="welcome"><div className="welcome-symbol"><GraduationCap size={42} /></div><span className="eyebrow">VOTRE MÉMOIRE, EN MIEUX</span><h1>Apprendre aujourd’hui.<br />S’en souvenir demain.</h1><p>Retrouvez vos cours, entraînez votre raisonnement clinique et révisez au bon moment.</p><button className="primary" onClick={onLogin}>Ouvrir mon espace <ArrowRight size={18} /></button><div className="welcome-foot"><ShieldCheck size={16} />Vos cours restent dans votre espace personnel.</div></section>; }

function Dashboard({ data, queue, onReview, onNavigate, onDeck }: { data: LibraryData; queue: StudyCard[]; onReview: () => void; onNavigate: (t: Tab) => void; onDeck: (d: Deck) => void }) {
  const today = dayKey(new Date());
  const reviewed = data.reviews.filter(r => dayKey(r.reviewed_at) === today).length;
  const active = data.cards.filter(c => c.status === 'active');
  const due = active.filter(c => new Date(c.schedule.due) <= new Date()).length;
  const reviewedDays = new Set(data.reviews.map(r => dayKey(r.reviewed_at)));
  let streak = 0; const probe = new Date();
  if (!reviewedDays.has(dayKey(probe))) probe.setDate(probe.getDate() - 1);
  while (reviewedDays.has(dayKey(probe))) { streak++; probe.setDate(probe.getDate() - 1); }
  const weekStart = new Date(); weekStart.setDate(weekStart.getDate() - ((weekStart.getDay() + 6) % 7));
  return <div className="fade-in"><div className="page-heading"><div><div className="eyebrow">UN PAS DE PLUS, CHAQUE JOUR</div><h1>Bonjour, futur médecin<span className="green-dot">.</span></h1><p>De petites révisions. De grandes connexions.</p></div><span className="date-chip">{new Date().toLocaleDateString('fr-FR', { day: 'numeric', month: 'long' })}</span></div>
    <section className="study-hero"><div className="hero-copy"><div className="hero-tag"><span /> VOTRE SESSION DU JOUR</div><h2>{queue.length ? 'Ancrez ce que vous savez.' : active.length ? 'Votre mémoire prend le relais.' : 'Votre prochain déclic commence ici.'}</h2><p>{queue.length ? `${due} carte${due > 1 ? 's' : ''} à revoir, au moment où cela compte.` : active.length ? 'Vous êtes à jour. Vos cartes reviendront au bon moment.' : 'Importez un premier cours pour créer votre bibliothèque.'}</p><button className="hero-button" onClick={() => queue.length ? onReview() : onNavigate(active.length ? 'library' : 'import')}>{queue.length ? 'Commencer ma session' : active.length ? 'Explorer mes decks' : 'Importer mon premier cours'}<ArrowRight size={18} /></button><div className="hero-meta"><Layers3 size={13} />{queue.length ? `Jusqu’à ${queue.length} cartes · matières entrelacées` : 'Rappel actif · Répétition espacée'}</div></div><div className="hero-art" aria-hidden="true"><div className="orbit orbit-one" /><div className="orbit orbit-two" /><div className="floating-card back"><HeartPulse size={27} /><div /><div /></div><div className="floating-card front"><Brain size={31} /><div /><div /><span><Check size={13} /> Bien mémorisé</span></div><span className="art-star one">✦</span><span className="art-star two">✧</span></div></section>
    <div className="stat-grid"><Stat icon={<Layers3 size={19} />} value={String(due)} label="Cartes à revoir" note="Au bon moment" /><Stat icon={<CheckCheck size={19} />} value={String(reviewed)} label="Révisées aujourd’hui" note="Chaque rappel compte" /><Stat icon={<Target size={19} />} value={`${streak}`} label={streak > 1 ? 'Jours de régularité' : 'Jour de régularité'} note="Construisez votre habitude" /></div>
    <div className="dashboard-grid"><section className="deck-section"><div className="section-heading"><h2>Vos matières</h2><button className="text-button" onClick={() => onNavigate('library')}>Tout voir <ArrowRight size={15} /></button></div><div className="deck-list">{data.decks.slice(0, 4).map(deck => <DeckRow key={deck.id} deck={deck} cards={data.cards.filter(c => c.deck_id === deck.id)} onClick={() => onDeck(deck)} />)}{!data.decks.length && <EmptyState title="Une bibliothèque à votre image" text="Ajoutez vos cours et transformez-les en occasions de vous tester." action="Importer un cours" onAction={() => onNavigate('import')} />}</div><button className="add-course" onClick={() => onNavigate('import')}><Plus size={18} /><span>Ajouter un cours</span><span>PDF ou texte</span></button></section>
    <aside className="dashboard-aside"><section className="week-card"><div className="section-heading"><h3>Votre rythme</h3><span className="small-muted">Cette semaine</span></div><div className="week-days">{Array.from({ length: 7 }, (_, i) => { const day = new Date(weekStart); day.setDate(day.getDate() + i); const isToday = dayKey(day) === today; const done = reviewedDays.has(dayKey(day)); return <div key={i} className={isToday ? 'week-day today' : 'week-day'}><span>{['L', 'M', 'M', 'J', 'V', 'S', 'D'][i]}</span><div className={done ? 'day-circle done' : 'day-circle'}>{done ? <Check size={14} /> : day.getDate()}</div><i /></div>; })}</div><p>La régularité fait la différence.<br /><strong>Même cinq minutes suffisent pour commencer.</strong></p></section><button className="feynman-teaser" onClick={() => onNavigate('feynman')}><div className="teaser-icon"><Sparkles size={21} /></div><span className="eyebrow">LE DÉCLIC FEYNMAN</span><h3>Si vous pouvez l’expliquer,<br />vous le comprenez.</h3><p>Testez un concept avec vos mots.</p><span className="text-button">Essayer le mode Feynman <ArrowRight size={15} /></span></button></aside></div>
    <div className="science-note"><Brain size={19} /><p><strong>Votre mémoire a son propre rythme.</strong> FSRS adapte les intervalles à vos réponses. L’entrelacement vous aide à distinguer les concepts proches.</p></div>
  </div>;
}
function Stat({ icon, value, label, note }: { icon: ReactNode; value: string; label: string; note: string }) { return <div className="stat-card"><div className="stat-top"><span>{icon}</span><strong>{value}</strong></div><h3>{label}</h3><p>{note}</p></div>; }
function DeckRow({ deck, cards, onClick }: { deck: Deck; cards: StudyCard[]; onClick: () => void }) {
  const active = cards.filter(c => c.status === 'active'); const due = active.filter(c => new Date(c.schedule.due) <= new Date()).length; const draft = cards.length - active.length;
  return <button className="deck-row" onClick={onClick}><span className="subject-icon" style={{ background: `${deck.color}16`, color: deck.color }}><IconFor subject={deck.subject} /></span><span className="deck-info"><strong>{deck.title}</strong><span>{deck.subject} <i>·</i> {cards.length} cartes{draft > 0 ? ` · ${draft} à valider` : ''}</span></span><span className={due ? 'due-pill' : 'up-to-date'}>{due ? `${due} à revoir` : draft ? 'Brouillon' : 'À jour'}</span><ChevronRight className="row-chevron" size={17} /></button>;
}
function EmptyState({ title, text, action, onAction }: { title: string; text: string; action?: string; onAction?: () => void }) { return <div className="empty-state"><BookOpen size={30} /><h3>{title}</h3><p>{text}</p>{action && <button className="secondary" onClick={onAction}>{action}</button>}</div>; }

function Library({ data, onDeck, onImport }: { data: LibraryData; onDeck: (deck: Deck) => void; onImport: () => void }) {
  const [query, setQuery] = useState(''); const [filter, setFilter] = useState('Toutes');
  const available = ['Toutes', ...new Set(data.decks.map(d => d.subject))];
  const decks = data.decks.filter(d => (filter === 'Toutes' || d.subject === filter) && `${d.title} ${d.subject}`.toLowerCase().includes(query.toLowerCase()));
  return <div className="fade-in"><div className="page-heading"><div><div className="eyebrow">VOS CONNAISSANCES, ORGANISÉES</div><h1>La bibliothèque<span className="green-dot">.</span></h1><p>{data.decks.length} decks pour construire votre raisonnement.</p></div><button className="primary compact" onClick={onImport}><Plus size={17} />Ajouter un cours</button></div><label className="search-input"><Search size={19} /><input aria-label="Rechercher dans la bibliothèque" placeholder="Rechercher une matière, un cours…" value={query} onChange={e => setQuery(e.target.value)} /></label><div className="filter-chips">{available.map(s => <button key={s} onClick={() => setFilter(s)} className={filter === s ? 'selected' : ''}>{s}</button>)}</div><div className="library-grid">{decks.map(deck => { const cards = data.cards.filter(c => c.deck_id === deck.id); const due = cards.filter(c => c.status === 'active' && new Date(c.schedule.due) <= new Date()).length; return <button key={deck.id} className="library-card" onClick={() => onDeck(deck)}><span className="subject-icon" style={{ color: deck.color, background: `${deck.color}16` }}><IconFor subject={deck.subject} size={25} /></span><span className="library-subject">{deck.subject}</span><h2>{deck.title}</h2><p>{cards.length} cartes <span>·</span> {cards.filter(c => c.kind === 'case').length} cas cliniques</p><div className="library-card-footer"><span className={due ? 'due-pill' : 'up-to-date'}>{due ? `${due} à revoir` : cards.some(c => c.status === 'draft') ? 'À valider' : 'À jour'}</span><ArrowRight size={18} /></div></button>; })}</div>{!decks.length && <EmptyState title={query ? 'Aucun cours trouvé' : 'Votre premier cours vous attend'} text={query ? 'Essayez un autre terme ou une autre matière.' : 'Importez un cours pour créer vos premières cartes.'} action={!query ? 'Importer un cours' : undefined} onAction={onImport} />}</div>;
}

function ImportCourse({ onDone }: { onDone: (id: string) => Promise<void> }) {
  const [title, setTitle] = useState(''); const [subject, setSubject] = useState(subjects[0]); const [text, setText] = useState(''); const [file, setFile] = useState<File>(); const [kind, setKind] = useState<GenerationKind>('mixed'); const [count, setCount] = useState(6); const [busy, setBusy] = useState(false); const [extracting, setExtracting] = useState(false); const [error, setError] = useState(''); const fileRef = useRef<HTMLInputElement>(null);
  const selectFile = async (selected?: File) => { if (!selected) return; setExtracting(true); setError(''); try { const { extractCourseFile } = await import('./lib/pdf'); const result = await extractCourseFile(selected); setText(result); setFile(selected); if (!title) setTitle(selected.name.replace(/\.[^.]+$/, '')); } catch (err) { setError(errorText(err)); } finally { setExtracting(false); } };
  const submit = async (event: FormEvent) => { event.preventDefault(); setBusy(true); setError(''); try { const result = await repository.importCourse({ title: title.trim(), subject, color: ({ Cardiologie: '#b36259', Neurologie: '#8073ad', Pharmacologie: '#bd8b38' } as Record<string, string>)[subject] || '#428576', text, file, kind, count }); await onDone(result.deckId); } catch (err) { setError(errorText(err)); } finally { setBusy(false); } };
  return <div className="fade-in"><div className="page-heading"><div><div className="eyebrow">DU COURS À LA COMPRÉHENSION</div><h1>Donnez vie à vos notes<span className="green-dot">.</span></h1><p>Un cours, plusieurs façons de vous tester.</p></div></div><div className="form-layout"><form className="panel import-form" onSubmit={submit}><div className="form-section-title"><span className="step-number">1</span><h2>Votre support de cours</h2></div><input ref={fileRef} type="file" accept=".pdf,.txt,.md,text/plain,application/pdf" hidden onChange={e => void selectFile(e.target.files?.[0])} /><button type="button" className="upload-zone" disabled={extracting || busy} onClick={() => fileRef.current?.click()}>{extracting ? <LoaderCircle className="spin" size={28} /> : <Upload size={28} />}<strong>{extracting ? 'Lecture du document…' : file ? file.name : 'Choisir un document'}</strong><span>PDF textuel, TXT ou Markdown · 10 Mo maximum</span></button><div className="or-divider"><span>ou collez vos notes</span></div><label className="field"><span>Contenu du cours</span><textarea rows={8} required minLength={100} maxLength={40000} value={text} onChange={e => { setText(e.target.value); setFile(undefined); }} placeholder="Collez un extrait de cours suffisamment détaillé : définition, signes cliniques, mécanismes, prise en charge…" /><small>{text.length.toLocaleString('fr-FR')} / 40 000 caractères · 100 minimum</small></label><div className="form-section-title"><span className="step-number">2</span><h2>Organisez votre deck</h2></div><label className="field"><span>Titre du cours</span><input required maxLength={120} placeholder="Ex. Insuffisance cardiaque : diagnostic" value={title} onChange={e => setTitle(e.target.value)} /></label><div className="field-pair"><label className="field"><span>Matière</span><select value={subject} onChange={e => setSubject(e.target.value)}>{subjects.map(s => <option key={s}>{s}</option>)}</select></label><label className="field"><span>Nombre de cartes</span><select value={count} onChange={e => setCount(Number(e.target.value))}>{[4, 6, 8, 10].map(n => <option key={n} value={n}>{n} cartes</option>)}</select></label></div><label className="field"><span>Type d’entraînement</span><select value={kind} onChange={e => setKind(e.target.value as GenerationKind)}><option value="mixed">Mélange : rappel, QCM et cas cliniques</option><option value="flashcard">Rappel actif</option><option value="qcm">QCM à réponse unique</option><option value="case">Mini-cas cliniques</option></select></label>{error && <div className="error-banner" role="alert">{error}</div>}<button className="primary full" disabled={busy || extracting || text.trim().length < 100 || !title.trim()}>{busy ? <LoaderCircle className="spin" size={18} /> : <Sparkles size={18} />}{busy ? 'Création du deck en cours…' : isConfigured ? 'Générer mon deck' : 'Créer un deck de démonstration'}</button><p className="form-footnote">Les cartes seront créées en brouillon pour votre relecture.</p></form><aside className="form-aside"><div className="aside-illustration"><FileText size={35} /><ArrowRight size={20} /><Layers3 size={35} /></div><h3>Ne relisez pas seulement.<br />Retrouvez l’information.</h3><p>Répondre avant de voir la correction vous aide à identifier ce que vous savez vraiment.</p><ol className="benefit-list"><li><Check size={16} />Questions ancrées dans votre cours</li><li><Check size={16} />Extraits sources conservés</li><li><Check size={16} />Planification FSRS après activation</li></ol><div className="subtle-note"><CircleHelp size={17} /><p>{isConfigured ? 'Vérifiez les corrections, les unités et les posologies avant activation. Un PDF scanné doit être converti en texte par OCR au préalable.' : 'En démo, les cartes sont des exercices illustratifs extraits du texte, sans appel IA. Connectez Supabase pour générer de vrais QCM et cas cliniques.'}</p></div></aside></div></div>;
}

function Feynman() {
  const [concept, setConcept] = useState(''); const [explanation, setExplanation] = useState(''); const [context, setContext] = useState(''); const [result, setResult] = useState<FeynmanAssessment | null>(null); const [busy, setBusy] = useState(false); const [error, setError] = useState('');
  const submit = async (e: FormEvent) => { e.preventDefault(); setBusy(true); setError(''); setResult(null); try { setResult(await repository.evaluateFeynman({ concept, explanation, context: context || undefined })); } catch (err) { setError(errorText(err)); } finally { setBusy(false); } };
  return <div className="fade-in"><div className="page-heading"><div><div className="eyebrow">COMPRENDRE, AVEC VOS MOTS</div><h1>Le mode Feynman<span className="green-dot">.</span></h1><p>Expliquez simplement. Repérez ce qui reste flou.</p></div><span className="soft-badge"><Sparkles size={14} />{isConfigured ? 'Coach IA' : 'Exemple de retour'}</span></div><div className="feynman-intro"><Brain size={25} /><p>Imaginez que vous expliquez ce concept à un camarade. Décrivez les mécanismes et les liens, sans vous cacher derrière le vocabulaire.</p></div><form className="panel feynman-form" onSubmit={submit}><label className="field"><span>Quel concept souhaitez-vous expliquer ?</span><input maxLength={200} required value={concept} onChange={e => setConcept(e.target.value)} placeholder="Ex. Pourquoi les bêtabloquants dans l’insuffisance cardiaque ?" /></label><label className="field"><span>Votre explication</span><textarea required minLength={50} maxLength={10000} rows={8} value={explanation} onChange={e => setExplanation(e.target.value)} placeholder="Sans regarder vos notes, expliquez ce que vous avez compris…" /><small>{explanation.length} / 10 000 caractères · 50 minimum</small></label><details className="context-details"><summary>Ajouter un extrait de référence <span>Conseillé</span></summary><label className="field"><span className="sr-only">Extrait du cours</span><textarea maxLength={12000} rows={4} value={context} onChange={e => setContext(e.target.value)} placeholder="L’extrait du cours sur lequel fonder la correction…" /></label></details>{error && <div className="error-banner" role="alert">{error}</div>}<div className="form-action-row"><span><ShieldCheck size={15} />{isConfigured ? 'Correction pédagogique à vérifier' : 'Retour illustratif, sans analyse IA'}</span><button className="primary" disabled={busy || explanation.trim().length < 50 || !concept.trim()}>{busy ? <LoaderCircle className="spin" size={17} /> : <Sparkles size={17} />}{busy ? 'Analyse en cours…' : 'Éclairer ma compréhension'}</button></div></form>{result && <section className="assessment fade-in" aria-live="polite"><div className="section-heading"><h2>{isConfigured ? 'Votre retour pédagogique' : 'Exemple de retour pédagogique'}</h2><span className="soft-badge">{isConfigured ? 'À relire avec le cours' : 'Démonstration'}</span></div><div className="assessment-grid"><AssessmentBlock title="Les points solides" items={result.strengths} tone="good" /><AssessmentBlock title="À approfondir" items={result.missing} tone="amber" /><AssessmentBlock title="Les confusions à lever" items={result.misconceptions} tone="rose" /></div><div className="panel correction"><h3>Une explication pour avancer</h3><p>{result.correction}</p></div><div className="panel correction"><h3>Pour aller plus loin</h3><ul>{result.follow_up.map((q, i) => <li key={i}>{q}</li>)}</ul></div></section>}</div>;
}
function AssessmentBlock({ title, items, tone }: { title: string; items: string[]; tone: string }) { return <div className={`assessment-block ${tone}`}><h3>{title}</h3>{items.length ? <ul>{items.map((item, i) => <li key={i}>{item}</li>)}</ul> : <p>Aucun élément signalé dans ce retour.</p>}</div>; }

function Sheet({ title, children, onClose, wide = false }: { title: string; children: ReactNode; onClose: () => void; wide?: boolean }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const before = document.activeElement as HTMLElement | null;
    const oldOverflow = document.body.style.overflow; document.body.style.overflow = 'hidden';
    ref.current?.focus();
    const keys = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      if (e.key === 'Tab') {
        const nodes = ref.current?.querySelectorAll<HTMLElement>('button:not([disabled]),input:not([disabled]),select,textarea,a[href],summary,[tabindex="0"]');
        if (!nodes?.length) return;
        const first = nodes[0], last = nodes[nodes.length - 1];
        if (e.shiftKey && (document.activeElement === first || document.activeElement === ref.current)) { e.preventDefault(); last.focus(); }
        else if (!e.shiftKey && (document.activeElement === last || document.activeElement === ref.current)) { e.preventDefault(); first.focus(); }
      }
    };
    document.addEventListener('keydown', keys);
    return () => { document.body.style.overflow = oldOverflow; document.removeEventListener('keydown', keys); before?.focus(); };
  }, []);
  return <div className="sheet-backdrop" onClick={e => { if (e.target === e.currentTarget) onClose(); }}><div ref={ref} className={'sheet ' + (wide ? 'wide' : '')} role="dialog" aria-modal="true" aria-label={title} tabIndex={-1}><div className="sheet-handle" /><div className="sheet-header"><h2>{title}</h2><button className="icon-button" aria-label="Fermer" onClick={onClose}><X size={21} /></button></div><div className="sheet-content">{children}</div></div></div>;
}

function Settings({ session, pending, conflicts, onClose, onSync, syncing, notify, onRefresh }: { session: Session | null; pending: number; conflicts: number; onClose: () => void; onSync: () => Promise<void>; syncing: boolean; notify: (message: string) => void; onRefresh: () => Promise<void> }) {
  const [signup, setSignup] = useState(false); const [email, setEmail] = useState(''); const [password, setPassword] = useState(''); const [busy, setBusy] = useState(false); const [error, setError] = useState(''); const [message, setMessage] = useState('');
  const auth = async (e: FormEvent) => { e.preventDefault(); if (!supabase) return; setBusy(true); setError(''); try { const { error: err } = signup ? await supabase.auth.signUp({ email, password, options: { emailRedirectTo: new URL(import.meta.env.BASE_URL, location.origin).href } }) : await supabase.auth.signInWithPassword({ email, password }); if (err) throw err; if (signup) setMessage('Compte créé. Si la confirmation est activée, ouvrez le lien reçu par e-mail, puis connectez-vous.'); else { notify('Votre espace est ouvert.'); onClose(); } } catch (err) { setError(errorText(err)); } finally { setBusy(false); } };
  const logout = async () => { setBusy(true); try { if (pending > 0 && !window.confirm(`${pending} révision(s) ne sont pas synchronisées. Elles seront supprimées de cet appareil à la déconnexion. Continuer ?`)) return; await repository.clearCache(); const { error: err } = await supabase!.auth.signOut(); if (err) throw err; onClose(); } catch (err) { setError(errorText(err)); } finally { setBusy(false); } };
  return <Sheet title="Votre espace" onClose={onClose}><div className="settings-brand"><Brand /><span className="soft-badge">Version 1.0</span></div>{!isConfigured ? <div className="settings-section"><h3>Vous explorez la démo</h3><p>Vos cartes et révisions sont enregistrées uniquement dans ce navigateur. Les actions IA sont illustratives.</p><p>Pour utiliser votre espace personnel et l’IA, suivez le guide INSTALLATION du projet et configurez Supabase.</p></div> : session ? <div className="settings-section"><h3>Compte connecté</h3><p className="account-email">{session.user.email}</p><button className="secondary full" disabled={busy} onClick={() => void logout()}><LogOut size={17} />Se déconnecter</button></div> : <form onSubmit={auth} className="auth-form"><div className="segmented-control"><button type="button" className={!signup ? 'selected' : ''} onClick={() => setSignup(false)}>Connexion</button><button type="button" className={signup ? 'selected' : ''} onClick={() => setSignup(true)}>Créer un compte</button></div><label className="field"><span>Adresse e-mail</span><input required type="email" autoComplete="email" value={email} onChange={e => setEmail(e.target.value)} /></label><label className="field"><span>Mot de passe</span><input required type="password" minLength={8} autoComplete={signup ? 'new-password' : 'current-password'} value={password} onChange={e => setPassword(e.target.value)} /></label><button className="primary full" disabled={busy}>{busy && <LoaderCircle className="spin" size={17} />}{signup ? 'Créer mon compte' : 'Me connecter'}</button>{message && <div className="info-banner">{message}</div>}</form>}{error && <div className="error-banner" role="alert">{error}</div>}<div className="settings-section"><h3>Synchronisation</h3><p>{pending ? `${pending} révision(s) en attente d’envoi.` : 'Toutes les révisions enregistrées sont à jour.'}</p>{conflicts > 0 && <p className="error-text">{conflicts} conflit(s) : ces révisions sont devenues incompatibles avec le serveur (modification, suppression ou expiration). La planification du serveur est conservée.</p>}<button className="secondary full" disabled={syncing || !navigator.onLine || (isConfigured && !session)} onClick={() => void onSync()}><RefreshCw size={16} className={syncing ? 'spin' : ''} />Synchroniser maintenant</button>{conflicts > 0 && <button className="text-button danger" onClick={async () => { if (!window.confirm('Supprimer uniquement les événements en conflit et conserver les révisions du serveur ?')) return; try { await repository.discardConflicts(); await onRefresh(); notify('Conflits écartés. Les données du serveur sont conservées.'); onClose(); } catch (err) { setError(errorText(err)); } }}>Écarter les événements en conflit</button>}</div><div className="settings-section"><h3>Installer sur iPhone</h3><p>Dans Safari, ouvrez le menu Partager, puis « Sur l’écran d’accueil ». Lancez ensuite Medora depuis son icône.</p><div className="subtle-note"><CloudOff size={18} /><p>Les cartes chargées restent disponibles hors connexion. L’IA demande une connexion. La synchronisation reprend à l’ouverture de l’app.</p></div></div><p className="legal-note">Outil d’apprentissage. Les contenus médicaux et les retours IA sont à vérifier avec vos cours et vos référentiels.</p></Sheet>;
}

function DeckDetail({ deck, cards, onClose, onReview, onChanged, notify }: { deck: Deck; cards: StudyCard[]; onClose: () => void; onReview: () => void; onChanged: () => Promise<void>; notify: (m: string) => void }) {
  const [busy, setBusy] = useState(false); const [error, setError] = useState(''); const draft = cards.filter(c => c.status === 'draft').length;
  const activate = async () => { setBusy(true); try { await repository.activateDeck(deck.id); await onChanged(); notify('Cartes activées. Votre première révision vous attend.'); } catch (err) { setError(errorText(err)); } finally { setBusy(false); } };
  const remove = async () => { if (!window.confirm('Supprimer ce deck et ses cartes ? Cette action est définitive.')) return; setBusy(true); try { await repository.deleteDeck(deck.id); await onChanged(); onClose(); } catch (err) { setError(errorText(err)); } finally { setBusy(false); } };
  return <Sheet title={deck.title} wide onClose={onClose}><div className="deck-detail-meta"><span className="soft-badge">{deck.subject}</span><span>{cards.length} cartes</span></div>{draft > 0 && <div className="draft-callout"><ShieldCheck size={23} /><div><strong>{draft} cartes à relire</strong><p>Vérifiez chaque réponse et sa source avant d’activer ce deck.</p></div></div>}{error && <div className="error-banner" role="alert">{error}</div>}<div className="preview-cards">{cards.map((card, i) => <details key={card.id} className="preview-card"><summary><span className="preview-number">{String(i + 1).padStart(2, '0')}</span><span><small>{kindLabel(card.kind)}{card.status === 'draft' ? ' · Brouillon' : ''}</small><strong>{card.prompt}</strong></span><ChevronRight size={17} /></summary><div className="preview-answer">{card.options.length > 0 && <ul>{card.options.map(option => <li key={option.id}>{option.text}{option.id === card.correct_option_id && ' ✓'}</li>)}</ul>}<strong>Réponse</strong><p>{card.answer}</p><p>{card.explanation}</p>{card.source_excerpt && <blockquote>{card.source_excerpt}</blockquote>}<span className="small-muted">Prochaine révision : {formatDate(card.schedule.due)}</span></div></details>)}</div>{!cards.length && <EmptyState title="Aucune carte pour le moment" text="La génération n’a pas abouti. Vous pouvez supprimer ce deck vide puis réimporter le cours." />}<div className="sheet-footer-actions">{draft > 0 ? <button className="primary full" disabled={busy} onClick={() => void activate()}>{busy ? <LoaderCircle className="spin" size={18} /> : <CheckCheck size={18} />}J’ai relu les cartes, activer le deck</button> : <button className="primary full" disabled={!cards.length || busy} onClick={onReview}>Réviser ce deck <ArrowRight size={18} /></button>}<button className="text-button danger" disabled={busy} onClick={() => void remove()}><Trash2 size={15} />Supprimer le deck</button></div></Sheet>;
}

function ReviewSession({ cards, decks, onClose, onChanged }: { cards: StudyCard[]; decks: Deck[]; onClose: () => void; onChanged: () => Promise<void> }) {
  const [index, setIndex] = useState(0); const [revealed, setRevealed] = useState(false); const [selected, setSelected] = useState<string>(); const [busy, setBusy] = useState(false); const [error, setError] = useState('');
  const dialogRef = useRef<HTMLDivElement>(null);
  const card = cards[index]; const deck = decks.find(d => d.id === card?.deck_id); const completed = index >= cards.length;
  useEffect(() => {
    const before = document.activeElement as HTMLElement | null;
    const prev = document.body.style.overflow; document.body.style.overflow = 'hidden'; dialogRef.current?.focus();
    const keys = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      if (e.key !== 'Tab') return;
      const nodes = dialogRef.current?.querySelectorAll<HTMLElement>('button:not([disabled]),summary');
      if (!nodes?.length) return;
      const first = nodes[0], last = nodes[nodes.length - 1];
      if (e.shiftKey && (document.activeElement === first || document.activeElement === dialogRef.current)) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && (document.activeElement === last || document.activeElement === dialogRef.current)) { e.preventDefault(); first.focus(); }
    };
    document.addEventListener('keydown', keys);
    return () => { document.body.style.overflow = prev; document.removeEventListener('keydown', keys); before?.focus(); };
  }, []);
  const rate = async (rating: RatingValue) => { if (!card || busy) return; setBusy(true); setError(''); try { await repository.rateCard(card, rating); setIndex(i => i + 1); setRevealed(false); setSelected(undefined); } catch (err) { setError(errorText(err)); } finally { setBusy(false); } };
  return <div ref={dialogRef} tabIndex={-1} className="review-screen" role="dialog" aria-modal="true" aria-label="Session de révision"><header className="review-header"><button className="icon-button" onClick={onClose} aria-label="Quitter la session"><X size={22} /></button><span>{completed ? 'Session terminée' : `Carte ${index + 1} sur ${cards.length}`}</span><span className="review-mode"><Layers3 size={16} />FSRS</span></header><div className="review-progress"><div style={{ width: `${index / cards.length * 100}%` }} /></div><div className="review-body">{completed ? <div className="session-complete"><div className="complete-icon"><CheckCheck size={43} /></div><div className="eyebrow">CHAQUE RAPPEL CONSTRUIT LA SUITE</div><h1>Un peu plus ancré.</h1><p>{cards.length} cartes révisées. Vos prochaines échéances sont calculées à partir de vos réponses.</p>{!navigator.onLine && <div className="info-banner"><WifiOff size={16} />Vos réponses attendent la reconnexion.</div>}<button className="primary" onClick={() => { void onChanged(); onClose(); }}>Revenir à mon espace <ArrowRight size={17} /></button></div> : <><div className="review-subject"><span style={{ color: deck?.color }}><IconFor subject={deck?.subject || ''} size={18} />{deck?.subject}</span><span>{kindLabel(card.kind)}</span></div><div className="question-card"><span className="eyebrow">PRENEZ LE TEMPS DE RETROUVER</span><h1>{card.prompt}</h1>{card.options.length > 0 && <div className="answer-options">{card.options.map((option, i) => <button key={option.id} disabled={revealed} className={'answer-option ' + (selected === option.id ? 'selected ' : '') + (revealed && option.id === card.correct_option_id ? 'correct' : revealed && selected === option.id ? 'incorrect' : '')} onClick={() => setSelected(option.id)}><span>{String.fromCharCode(65 + i)}</span>{option.text}{revealed && option.id === card.correct_option_id && <Check size={18} />}</button>)}</div>}{!revealed && <p className="recall-hint">{card.options.length ? 'Choisissez une réponse avant de consulter la correction.' : 'Formulez votre réponse à voix haute ou mentalement avant de retourner la carte.'}</p>}{revealed && <div className="revealed-answer fade-in"><span className="answer-label"><CheckCheck size={16} />LA CORRECTION</span><h2>{card.answer}</h2><p>{card.explanation}</p>{card.source_excerpt && <details><summary>Voir l’extrait du cours</summary><blockquote>{card.source_excerpt}</blockquote></details>}</div>}</div>{error && <div className="error-banner" role="alert">{error}</div>}</>}</div>{!completed && <div className="review-controls">{!revealed ? <button className="primary full" disabled={card.options.length > 0 && !selected} onClick={() => setRevealed(true)}>Voir la correction <ArrowRight size={17} /></button> : <><p>À quel point avez-vous retrouvé la réponse ?</p><div className="rating-buttons">{([{ n: 1, label: 'À revoir', sub: 'Oublié' }, { n: 2, label: 'Difficile', sub: 'Avec effort' }, { n: 3, label: 'Bien', sub: 'Retrouvé' }, { n: 4, label: 'Facile', sub: 'Immédiat' }] as const).map(r => <button key={r.n} className={'rating rating-' + r.n} disabled={busy} onClick={() => void rate(r.n)}><strong>{r.label}</strong><span>{r.sub}</span></button>)}</div>{busy && <span className="small-muted">Enregistrement…</span>}</>}</div>}</div>;
}
