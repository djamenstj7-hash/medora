import * as pdfjs from 'pdfjs-dist';
import workerUrl from 'pdfjs-dist/build/pdf.worker.min.mjs?url';

pdfjs.GlobalWorkerOptions.workerSrc = workerUrl;
export const MAX_FILE_BYTES = 10 * 1024 * 1024;
export const MAX_COURSE_CHARS = 40_000;

export async function extractCourseFile(file: File): Promise<string> {
  if (file.size > MAX_FILE_BYTES) throw new Error('Le fichier dépasse 10 Mo. Découpez le cours en plusieurs parties.');
  let text: string;
  if (file.type === 'application/pdf' || /\.pdf$/i.test(file.name)) {
    const task = pdfjs.getDocument({ data: new Uint8Array(await file.arrayBuffer()), isEvalSupported: false });
    const document = await task.promise;
    try {
      if (document.numPages > 100) throw new Error('Ce PDF dépasse 100 pages. Importez un chapitre à la fois.');
      const pages: string[] = [];
      let length = 0;
      for (let pageNumber = 1; pageNumber <= document.numPages; pageNumber++) {
        const page = await document.getPage(pageNumber);
        const content = await page.getTextContent();
        const pageText = content.items.map((item) => 'str' in item ? item.str + ('hasEOL' in item && item.hasEOL ? '\n' : ' ') : '').join('').trim();
        pages.push(`[Page ${pageNumber}]\n${pageText}`);
        length += pageText.length;
        if (length > MAX_COURSE_CHARS) throw new Error('Le texte dépasse 40 000 caractères. Importez un chapitre plus court.');
        page.cleanup();
      }
      const actualText = pages.map((page) => page.replace(/^\[Page \d+\]\n/, '')).join('').trim();
      if (actualText.length < 40) throw new Error('Ce PDF semble être scanné ou sans texte exploitable. Effectuez un OCR, puis importez le texte obtenu.');
      text = pages.join('\n\n');
    } finally {
      await document.destroy();
    }
  } else if (file.type.startsWith('text/') || /\.(txt|md)$/i.test(file.name)) {
    text = await file.text();
  } else {
    throw new Error('Choisissez un fichier PDF textuel, TXT ou Markdown.');
  }
  if (text.length > MAX_COURSE_CHARS) throw new Error('Le texte dépasse 40 000 caractères. Importez un chapitre plus court.');
  if (text.trim().length < 40) throw new Error('Le cours doit contenir au moins 40 caractères de texte exploitable.');
  return text.trim();
}
