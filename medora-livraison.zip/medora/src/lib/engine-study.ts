import type { EngineCard, EnginePackSummary } from './engine-types';
import type { StudyAttempt } from './study-types';

export type EnginePracticeMode = 'bachotage' | 'annales' | 'exam';
export type EngineConfidence = 'sure' | 'hesitant' | 'guess';
export interface EngineUngradedAnswer {
  correct: false; graded: false; selected?: number[]; responseText?: string; confidence?: EngineConfidence;
  point?: { x: number; y: number }; selfAssessed?: boolean;
}
/** A mental answer can legitimately have no text. Only known, bounded fields are restored. */
export function readEngineDraftAnswer(serialized: string | undefined): EngineUngradedAnswer | undefined {
  if (!serialized || serialized.length > 40000) return undefined;
  try {
    const draft: unknown = JSON.parse(serialized);
    if (!object(draft) || draft.application !== 'engine' || !object(draft.answer) || draft.answer.graded !== false) return undefined;
    const answer = draft.answer;
    if (answer.responseText !== undefined && (typeof answer.responseText !== 'string' || answer.responseText.length > 40000)) return undefined;
    if (answer.selected !== undefined && (!Array.isArray(answer.selected) || answer.selected.length > 100 || !answer.selected.every(value => Number.isInteger(value) && value >= 0 && value <= 999))) return undefined;
    if (answer.confidence !== undefined && !['sure', 'hesitant', 'guess'].includes(String(answer.confidence))) return undefined;
    if (answer.selfAssessed !== undefined && typeof answer.selfAssessed !== 'boolean') return undefined;
    let point: { x: number; y: number } | undefined;
    if (answer.point !== undefined) {
      if (!object(answer.point) || typeof answer.point.x !== 'number' || typeof answer.point.y !== 'number' || !Number.isFinite(answer.point.x) || !Number.isFinite(answer.point.y) || answer.point.x < 0 || answer.point.y < 0 || answer.point.x > 1000000 || answer.point.y > 1000000) return undefined;
      point = { x: answer.point.x, y: answer.point.y };
    }
    return { correct: false, graded: false, ...(answer.responseText !== undefined ? { responseText: answer.responseText as string } : {}), ...(answer.selected !== undefined ? { selected: [...answer.selected as number[]] } : {}), ...(answer.confidence !== undefined ? { confidence: answer.confidence as EngineConfidence } : {}), ...(point ? { point } : {}), ...(answer.selfAssessed !== undefined ? { selfAssessed: answer.selfAssessed as boolean } : {}) };
  } catch { return undefined; }
}
export interface EngineFilters { query?: string; subjectId?: string; type?: string; level?: string; tag?: string; weakIds?: Set<string> }
export interface EnginePracticeSession {
  application: 'engine'; schemaVersion: 1; id: string; packId: string; mode: EnginePracticeMode;
  cardIds: string[]; answers: Record<string, string>; index: number; startedAt: string;
  elapsedMs: number; runningSince: number | null; questionStartedMs: number; limitSeconds: number | null;
  finishedAt?: string;
}
export type EngineAttempt = StudyAttempt & { confidence?: EngineConfidence; engineMode?: EnginePracticeMode; application?: 'engine'; point?: { x: number; y: number }; selfAssessed?: boolean };
export const engineLessonKey = (id: string) => `engine:pack:${id}`;
export const engineSubjectKey = (id: string) => `engine:subject:${id}`;
export const normalizeEngineText = (value: string) => value.normalize('NFD').replace(/\p{M}/gu, '').toLocaleLowerCase('fr').replace(/\s+/g, ' ').trim();
export const engineTypeNames: Record<string, string> = { qrm: 'QRM', qru: 'QRU', basic: 'Recto-verso', cloze: 'Texte à trous', qroc: 'QROC', zone: 'Repérage', legend: 'Légendes', lexique: 'Lexique' };
export function filterEnginePacks(packs: EnginePackSummary[], filters: EngineFilters) {
  const needle = normalizeEngineText(filters.query || '');
  return packs.filter(pack => (!filters.subjectId || filters.subjectId === 'all' || pack.subjectIds.includes(filters.subjectId))
    && (!needle || normalizeEngineText(`${pack.title} ${pack.searchText}`).includes(needle))
    && (!filters.type || filters.type === 'all' || (pack.types[filters.type] || 0) > 0)
    && (!filters.level || filters.level === 'all' || (filters.level === 'annales' ? pack.annaleCount > 0 : filters.level === 'a-relire' ? pack.unverifiedCount > 0 : pack.tags.includes(filters.level)))
    && (!filters.tag || filters.tag === 'all' || pack.tags.includes(filters.tag)));
}
export function filterEngineCards(cards: EngineCard[], filters: EngineFilters, mode?: EnginePracticeMode) {
  const needle = normalizeEngineText(filters.query || '');
  return cards.filter(card => (mode !== 'annales' || card.annale)
    && (!filters.type || filters.type === 'all' || card.type === filters.type)
    && (!filters.level || filters.level === 'all' || (filters.level === 'annales' ? card.annale : card.tags.includes(filters.level)))
    && (!filters.tag || filters.tag === 'all' || card.tags.includes(filters.tag))
    && (!needle || normalizeEngineText(`${card.prompt} ${card.tags.join(' ')}`).includes(needle))
    && (!filters.weakIds || filters.weakIds.has(card.id)));
}
export function shuffleEngineCards<T>(items: T[], random: () => number = Math.random): T[] {
  const copy = [...items];
  for (let index = copy.length - 1; index > 0; index--) { const at = Math.min(index, Math.max(0, Math.floor(random() * (index + 1)))); [copy[index], copy[at]] = [copy[at], copy[index]]; }
  return copy;
}
export function engineElapsed(session: EnginePracticeSession, now = Date.now()) {
  return Math.max(0, session.elapsedMs + (session.runningSince === null ? 0 : Math.max(0, now - session.runningSince)));
}
export function pauseEngineSession(session: EnginePracticeSession, now = Date.now()): EnginePracticeSession { return { ...session, elapsedMs: engineElapsed(session, now), runningSince: null }; }
export function createEngineSession(packId: string, cards: EngineCard[], mode: EnginePracticeMode, count: number, minutes: number, now = Date.now()): EnginePracticeSession {
  if (!cards.length) throw new Error('Aucune carte ne correspond à cette sélection.');
  const selected = shuffleEngineCards(cards).slice(0, count > 0 ? count : cards.length);
  if (selected.length > 10000) throw new Error('Cette séance dépasse 10 000 cartes. Sélectionne un chapitre ou un thème.');
  const session: EnginePracticeSession = { application: 'engine', schemaVersion: 1, id: crypto.randomUUID(), packId, mode, cardIds: selected.map(card => card.id), answers: {}, index: 0, startedAt: new Date(now).toISOString(), elapsedMs: 0, runningSince: now, questionStartedMs: 0, limitSeconds: mode === 'exam' ? Math.max(1, Math.min(180, minutes)) * 60 : null };
  if (JSON.stringify(session).length > 200000) throw new Error('Cette sélection est trop grande pour une sauvegarde de séance. Choisis un lot de cartes.');
  return session;
}
const object = (value: unknown): value is Record<string, unknown> => value !== null && typeof value === 'object' && !Array.isArray(value);
export function isEngineSession(value: unknown): value is EnginePracticeSession {
  if (!object(value) || value.application !== 'engine' || value.schemaVersion !== 1 || typeof value.id !== 'string' || typeof value.packId !== 'string' || !['bachotage', 'annales', 'exam'].includes(String(value.mode))) return false;
  if (!Array.isArray(value.cardIds) || value.cardIds.length < 1 || value.cardIds.length > 10000 || !value.cardIds.every(id => typeof id === 'string' && id.startsWith('engine:') && id.length <= 200) || new Set(value.cardIds).size !== value.cardIds.length || !object(value.answers)) return false;
  const cardIds = value.cardIds;
  if (Object.entries(value.answers).some(([key, id]) => !cardIds.includes(key) || typeof id !== 'string' || id.length > 200)) return false;
  return Number.isInteger(value.index) && Number(value.index) >= 0 && Number(value.index) < value.cardIds.length && typeof value.startedAt === 'string' && Number.isFinite(Date.parse(value.startedAt))
    && typeof value.elapsedMs === 'number' && Number.isFinite(value.elapsedMs) && value.elapsedMs >= 0
    && (value.runningSince === null || typeof value.runningSince === 'number' && Number.isFinite(value.runningSince))
    && typeof value.questionStartedMs === 'number' && Number.isFinite(value.questionStartedMs) && value.questionStartedMs >= 0
    && (value.limitSeconds === null || typeof value.limitSeconds === 'number' && Number.isFinite(value.limitSeconds) && value.limitSeconds >= 1)
    && (value.finishedAt === undefined || typeof value.finishedAt === 'string' && Number.isFinite(Date.parse(value.finishedAt)));
}
export function restoreEngineCards(cards: EngineCard[], session: EnginePracticeSession): EngineCard[] {
  const lookup = new Map(cards.map(card => [card.id, card]));
  const restored = session.cardIds.map(id => lookup.get(id));
  if (restored.some(card => !card)) throw new Error('Des cartes de cette séance ont changé. Garde tes résultats et démarre une nouvelle séance.');
  return restored as EngineCard[];
}
export function engineAttempts(attempts: StudyAttempt[]): EngineAttempt[] { return attempts.filter(attempt => attempt.questionId.startsWith('engine:')) as EngineAttempt[]; }
export function latestEngineAttempts(attempts: StudyAttempt[]): Map<string, EngineAttempt> {
  const latest = new Map<string, EngineAttempt>();
  for (const attempt of engineAttempts(attempts)) { const old = latest.get(attempt.questionId); if (!old || Date.parse(attempt.createdAt) > Date.parse(old.createdAt) || Date.parse(attempt.createdAt) === Date.parse(old.createdAt) && attempt.id > old.id) latest.set(attempt.questionId, attempt); }
  return latest;
}
export function nextEngineExam(date: string | undefined, today: string) { return date && /^\d{4}-\d{2}-\d{2}$/.test(date) && Number.isFinite(Date.parse(`${date}T12:00:00Z`)) && new Date(`${date}T12:00:00Z`).toISOString().slice(0, 10) === date && date >= today ? date : null; }
