import type { Deck, StudyCard } from './types';

function urgency(card: StudyCard, now: number) {
  const overdue = now - new Date(card.schedule.due).getTime();
  return overdue >= 7 * 86_400_000 ? 0 : overdue >= 86_400_000 ? 1 : 2;
}

/** Preserve urgency bands, then alternate subjects within each band. */
export function getReviewQueue(cards: StudyCard[], decks: Deck[], now = new Date(), limit = 20): StudyCard[] {
  const timestamp = now.getTime();
  const subjects = new Map(decks.map((deck) => [deck.id, deck.subject]));
  const due = cards
    .filter((card) => card.status === 'active' && new Date(card.schedule.due).getTime() <= timestamp)
    .sort((a, b) => new Date(a.schedule.due).getTime() - new Date(b.schedule.due).getTime());
  const result: StudyCard[] = [];
  let previousSubject = '';
  for (const band of [0, 1, 2]) {
    const remaining = due.filter((card) => urgency(card, timestamp) === band);
    while (remaining.length && result.length < limit) {
      const different = remaining.findIndex((card) => (subjects.get(card.deck_id) ?? card.deck_id) !== previousSubject);
      const [next] = remaining.splice(different === -1 ? 0 : different, 1);
      previousSubject = subjects.get(next.deck_id) ?? next.deck_id;
      result.push(next);
    }
  }
  return result;
}
