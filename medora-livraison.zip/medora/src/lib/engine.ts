import type { EngineCard, EngineChapter, EngineIllustration, EngineManifest, EngineNote, EnginePack, EnginePackSummary, EngineSourceCard, EngineVariant, EngineZone } from './engine-types';
export type * from './engine-types';

const requests = new Map<string, Promise<unknown>>();
const normalizedCards = new WeakMap<EnginePack, EngineCard[]>();
const safeId = /^[a-z0-9][a-z0-9_-]{0,119}$/i;
const text = (value: unknown): string => typeof value === 'string' ? value : value === undefined || value === null ? '' : String(value);
const strings = (value: unknown): string[] => Array.isArray(value) ? value.map(text) : [];
const list = <T>(value: unknown): T[] => Array.isArray(value) ? value as T[] : [];

/** The caller must render HTML diagrams in its own restrictive sandbox. */
export function engineAssetUrl(path: string): string {
  const cleaned = path.replace(/^\.\//, '').replace(/^engine\//, '');
  if (!cleaned || cleaned.includes(':') || cleaned.startsWith('/') || /[\\?#\u0000-\u001f]/.test(cleaned) || cleaned.split('/').some(part => part === '..' || part === '.')) return '';
  if (!/\.(?:json|md|txt|toml|png|webp|jpe?g|svg|html)$/i.test(cleaned)) return '';
  return `${import.meta.env.BASE_URL}engine/${cleaned.split('/').map(encodeURIComponent).join('/')}`;
}
async function readJson<T>(path: string): Promise<T> {
  const url = engineAssetUrl(path);
  if (!url) throw new Error('Le chemin du contenu MED_ENGINE est invalide.');
  if (!requests.has(path)) requests.set(path, fetch(url).then(async response => {
    if (!response.ok) throw new Error('Ce chapitre n’a pas pu être chargé. Vérifie ta connexion ou télécharge le programme pour le hors connexion.');
    return response.json() as Promise<T>;
  }).catch(error => { requests.delete(path); throw error; }));
  return requests.get(path) as Promise<T>;
}
export function loadEngineManifest(): Promise<EngineManifest> { return readJson('manifest.json'); }
export async function loadEnginePack(id: string): Promise<EnginePack> {
  if (!safeId.test(id)) throw new Error('L’identifiant de chapitre MED_ENGINE est invalide.');
  const manifest = await loadEngineManifest();
  const summary = manifest.packs.find(pack => pack.id === id);
  if (!summary) throw new Error('Ce chapitre ne figure pas dans le programme.');
  return toEnginePack(id, await readJson<Record<string, unknown>>(summary.sourcePath), summary);
}

export function clozeIndices(value: string): number[] {
  return [...new Set([...value.matchAll(/\{\{c(\d+)::([\s\S]*?)\}\}/g)].map(match => Number(match[1])))].sort((a, b) => a - b);
}
export function clozeText(value: string, index?: number, reveal = false): string {
  return value.replace(/\{\{c(\d+)::([\s\S]*?)\}\}/g, (_all, number: string, inner: string) => {
    const [answer, hint] = inner.split('::');
    return reveal || Number(number) !== index ? answer : hint ? `[${hint}]` : '[…]';
  });
}
export function engineAnnale(note: EngineNote): boolean {
  return note.tags.some(tag => /annal/i.test(tag)) || note.origine === 'annale' || typeof note.source?.session_examen === 'string';
}
function variantId(packId: string, noteId: string, key: string) { return `engine:${packId}:${noteId}:${key}`; }
/** One deletion group, requested image region or numbered label produces one independent recall variant. */
export function engineVariants(packId: string, notes: EngineNote[], cards: EngineSourceCard[]): EngineVariant[] {
  const sourceCards = new Map<string, EngineSourceCard[]>();
  for (const card of cards) sourceCards.set(card.note_id, [...(sourceCards.get(card.note_id) || []), card]);
  const variants: EngineVariant[] = [];
  for (const note of notes) {
    const field = note.champs;
    const common = { noteId: note.id };
    const originalCards = sourceCards.get(note.id) || [];
    let keys: Omit<EngineVariant, 'id' | 'noteId' | 'sourceCardId'>[] = [];
    if (note.type === 'cloze') keys = clozeIndices(text(field.texte)).map(clozeIndex => ({ key: `c${clozeIndex}`, clozeIndex }));
    else if (note.type === 'zone') {
      const zones = list<EngineZone>(field.zones);
      const requested = strings(field.demandees);
      keys = zones.filter(zone => !requested.length || requested.includes(zone.cle)).map(zone => ({ key: `zone-${zone.cle}`, zoneKey: zone.cle }));
    } else if (note.type === 'legend') {
      keys = list<{ numero: number }>(field.numeros).map(item => ({ key: `legend-${item.numero}`, legendNumber: item.numero }));
    }
    if (!keys.length) keys = [{ key: 'main' }];
    for (const variant of keys) {
      const exactSource = originalCards.find(card => card.id === `${note.id}#${variant.key}`) || originalCards.find(card => card.id === note.id) || originalCards[0];
      variants.push({ ...common, ...variant, sourceCardId: exactSource?.id, id: variantId(packId, note.id, variant.key) });
    }
  }
  return variants;
}
export function toEnginePack(id: string, raw: Record<string, unknown>, summary?: EnginePackSummary): EnginePack {
  if (!safeId.test(id) || raw.format !== 'hippocampe.paquet' || raw.format_version !== 1 || !Array.isArray(raw.notes) || !Array.isArray(raw.chapters)) throw new Error('Ce paquet MED_ENGINE est invalide ou utilise un format non pris en charge.');
  const notes = raw.notes as EngineNote[];
  const chapters = raw.chapters as EngineChapter[];
  const cards = list<EngineSourceCard>(raw.cards);
  return { ...raw, id, title: summary?.title || chapters.map(chapter => chapter.nom).join(' · ') || id, readmePath: summary?.readmePath, sourcePath: summary?.sourcePath || `packs/${id}.json`, availableMedia: summary?.availableMedia, subjects: list(raw.subjects), chapters, source_documents: list(raw.source_documents), media: list(raw.media), notes, cards, variants: engineVariants(id, notes, cards) } as EnginePack;
}
function choiceIndices(value: unknown, length: number): number[] {
  const input = Array.isArray(value) ? value : typeof value === 'string' ? value.split(/[\s,;]+/) : [];
  return [...new Set(input.map(item => typeof item === 'number' ? item : /^[A-Z]$/i.test(text(item)) ? text(item).toUpperCase().charCodeAt(0) - 65 : -1).filter(index => index >= 0 && index < length))].sort((a, b) => a - b);
}
/** Stable per-card order avoids matching numbered diagram labels by their option position. */
function legendOptions(values: string[], seed: string): string[] {
  const result = [...new Set(values)];
  let state = 2166136261;
  for (const char of seed) state = Math.imul(state ^ char.charCodeAt(0), 16777619) >>> 0;
  for (let index = result.length - 1; index > 0; index--) {
    state = (Math.imul(state, 1664525) + 1013904223) >>> 0;
    const other = state % (index + 1);
    [result[index], result[other]] = [result[other], result[index]];
  }
  return result;
}
export function engineCards(pack: EnginePack): EngineCard[] {
  if (normalizedCards.has(pack)) return normalizedCards.get(pack)!;
  const notes = new Map(pack.notes.map(note => [note.id, note]));
  const cards = pack.variants.flatMap(variant => {
    const note = notes.get(variant.noteId);
    if (!note) return [];
    const fields = note.champs, tags = strings(note.tags);
    const chapter = pack.chapters.find(item => item.id === note.chapter_id);
    const illustration = (filename: unknown, caption: unknown, width?: unknown, height?: unknown): EngineIllustration | undefined => {
      if (!text(filename)) return undefined;
      const clean = text(filename).replace(/^media\//, '');
      if (clean.includes('/') || clean.includes('\\') || clean === '..') return undefined;
      return { path: `assets/packs/${pack.id}/media/${clean}`, available: pack.availableMedia ? pack.availableMedia.includes(clean) : undefined, caption: text(caption), width: typeof width === 'number' ? width : undefined, height: typeof height === 'number' ? height : undefined };
    };
    const options = strings(fields.propositions || fields.options);
    const correct = choiceIndices(fields.vraies ?? fields.correct, options.length);
    let prompt = text(fields.enonce || fields.question || fields.recto || fields.terme || fields.titre), answer = text(fields.verso || fields.reponse || fields.definition), explanation = text(fields.explication);
    let zone: EngineZone | undefined;
    let questionIllustration = illustration(fields.illustration_question, fields.legende_illustration_question);
    if (note.type === 'qrm' || note.type === 'qru') answer = correct.map(index => `${String.fromCharCode(65 + index)}. ${options[index]}`).join('\n');
    if (note.type === 'qroc' && !answer) answer = strings(fields.exactes).join(' ; ');
    if (note.type === 'cloze') { prompt = clozeText(text(fields.texte), variant.clozeIndex); answer = clozeText(text(fields.texte), variant.clozeIndex, true); }
    if (note.type === 'zone') {
      zone = list<EngineZone>(fields.zones).find(item => item.cle === variant.zoneKey);
      prompt = (prompt || 'Sur le schéma, où se situe {label} ?').replaceAll('{label}', text(zone?.libelle || zone?.court || zone?.cle));
      answer = text(zone?.court || zone?.libelle || zone?.cle);
      explanation = [zone?.note, explanation].filter(Boolean).join('\n\n');
      questionIllustration = illustration(fields.image, fields.legende_image, fields.largeur, fields.hauteur);
    }
    if (note.type === 'legend') {
      const labels = list<{ numero: number; legende: string; note?: string }>(fields.numeros);
      const target = labels.find(item => item.numero === variant.legendNumber);
      prompt = `${prompt || 'Retrouve la légende du schéma.'}\nNuméro ${variant.legendNumber}`;
      answer = text(target?.legende);
      explanation = [target?.note, explanation].filter(Boolean).join('\n\n');
      options.splice(0, options.length, ...legendOptions([...labels.map(item => item.legende), ...strings(fields.intrus)], variant.id));
      correct.splice(0, correct.length, ...(target ? [options.indexOf(target.legende)] : []));
      questionIllustration = illustration(fields.planche, fields.legende_image, fields.largeur, fields.hauteur);
    }
    return [{ id: variant.id, noteId: note.id, packId: pack.id, chapterId: note.chapter_id, subjectId: chapter?.subject_id || pack.subjects[0]?.id || '', type: note.type, prompt, answer, explanation, options, correct, required: choiceIndices(fields.indispensables, options.length), forbidden: choiceIndices(fields.inacceptables, options.length), justifications: strings(fields.justifications), tags, annale: engineAnnale(note), official: note.cle_officielle === true, source: note.source || {}, secondarySource: note.source_secondaire, fields, note, illustration: illustration(fields.illustration, fields.legende_illustration), questionIllustration, schemaIllustration: illustration(fields.schema, fields.legende_schema), zone, clozeIndex: variant.clozeIndex, legendNumber: variant.legendNumber } satisfies EngineCard];
  });
  normalizedCards.set(pack, cards);
  return cards;
}
