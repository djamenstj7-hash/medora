import type { Card } from 'ts-fsrs';

export type RatingValue = 1 | 2 | 3 | 4;
export type CardKind = 'flashcard' | 'qcm' | 'case';
export type GenerationKind = CardKind | 'mixed';
export type SerializedSchedule = Omit<Card, 'due' | 'last_review'> & {
  due: string;
  last_review?: string;
};

export interface Deck {
  id: string;
  title: string;
  subject: string;
  color: string;
  created_at: string;
  user_id?: string;
}

export interface StudyCard {
  id: string;
  deck_id: string;
  kind: CardKind;
  prompt: string;
  answer: string;
  explanation: string;
  options: { id: string; text: string }[];
  correct_option_id: string | null;
  source_excerpt?: string;
  status: 'draft' | 'active';
  schedule: SerializedSchedule;
  version: number;
  created_at?: string;
}

export interface ReviewLog {
  id: string;
  card_id: string;
  client_event_id: string;
  rating: RatingValue;
  reviewed_at: string;
  previous_schedule?: SerializedSchedule;
  next_schedule?: SerializedSchedule;
}

export interface PendingReview {
  card_id: string;
  rating: RatingValue;
  client_event_id: string;
  reviewed_at: string;
  expected_version: number;
  conflict?: boolean;
}

export interface LibraryData {
  decks: Deck[];
  cards: StudyCard[];
  reviews: ReviewLog[];
}

export interface FeynmanAssessment {
  strengths: string[];
  missing: string[];
  misconceptions: string[];
  correction: string;
  follow_up: string[];
}

export interface ImportCourseInput {
  title: string;
  subject: string;
  color: string;
  text: string;
  file?: File;
  kind: GenerationKind;
  count: number;
}
