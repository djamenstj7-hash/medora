import { createDemoLibrary } from './demo';
import { newSchedule, scheduleReview } from './fsrs';
import { enqueueReview, persistence, type CachedLibrary } from './persistence';
import { getSession, isConfigured, supabase } from './supabase';
import type { Deck, FeynmanAssessment, ImportCourseInput, LibraryData, PendingReview, RatingValue, ReviewLog, SerializedSchedule, StudyCard } from './types';

const EMPTY: CachedLibrary = { decks: [], cards: [], reviews: [], pending: [] };
type RemoteSchedule = { schedule: SerializedSchedule; version: number };
type RemoteCard = Omit<StudyCard, 'schedule' | 'version'> & { card_schedules: RemoteSchedule | RemoteSchedule[] | null };
type RemoteReview = Omit<ReviewLog, 'previous_schedule' | 'next_schedule'> & { before_schedule: SerializedSchedule; after_schedule: SerializedSchedule };
let lastScope: string | undefined;
let operations: Promise<unknown> = Promise.resolve();

function exclusive<T>(action: () => Promise<T>): Promise<T> {
  const result = operations.then(action, action);
  operations = result.then(() => undefined, () => undefined);
  return result;
}

class ApiError extends Error {
  constructor(message: string, public status?: number, public network = false) { super(message); }
}

function isNetworkError(error: unknown) {
  return error instanceof ApiError && error.network || error instanceof Error && /Failed to fetch|NetworkError|Load failed|fetch failed|Network request failed/i.test(error.message);
}

function canRetryReview(error: unknown) {
  // A timeout or upstream failure can happen after the transaction committed.
  // Keep the event ID so the server can return its original result on retry.
  if (isNetworkError(error)) return true;
  if (!(error instanceof ApiError) || error.status === undefined) return true;
  return [408, 425, 429].includes(error.status) || error.status >= 500;
}

async function scope() {
  if (!isConfigured) return (lastScope = 'demo');
  const session = await getSession();
  if (!session) throw new Error('Connectez-vous pour retrouver vos cours.');
  return (lastScope = session.user.id);
}

async function cacheFor(key: string) {
  const cached = await persistence.read(key);
  if (cached) return cached;
  const fresh = key === 'demo' ? createDemoLibrary() : structuredClone(EMPTY);
  await persistence.write(key, fresh);
  return fresh;
}

async function invoke<T>(name: string, body: Record<string, unknown>): Promise<T> {
  if (!supabase) throw new Error('Configurez Supabase pour utiliser cette fonction.');
  const { data, error } = await supabase.functions.invoke<T>(name, { body });
  if (!error) return data as T;
  const response = 'context' in error && error.context instanceof Response ? error.context : undefined;
  let message = error.message;
  if (response) {
    try {
      const payload = await response.clone().json() as { error?: string; message?: string };
      message = payload.error || payload.message || message;
    } catch { /* A non-JSON gateway error keeps its original message. */ }
  }
  throw new ApiError(message, response?.status, error.name === 'FunctionsFetchError');
}

async function remoteSnapshot(): Promise<LibraryData> {
  if (!supabase) throw new Error('Supabase non configuré.');
  async function allRows<T>(table: 'decks' | 'cards' | 'review_logs', selection: string, limit = Infinity, sortColumn = 'id', ascending = true) {
    const rows: T[] = [];
    const pageSize = 500;
    let total: number | null = null;
    while (true) {
      let query = supabase!.from(table).select(selection, { count: 'exact' }).order(sortColumn, { ascending });
      if (sortColumn !== 'id') query = query.order('id', { ascending: true });
      const requested = Math.min(pageSize, limit - rows.length);
      const result = await query.range(rows.length, rows.length + requested - 1);
      if (result.error) throw new ApiError(result.error.message, result.status, /fetch|network|load failed/i.test(result.error.message));
      const page = result.data || [];
      rows.push(...page as unknown as T[]);
      total = result.count ?? total;
      if (rows.length >= limit || total !== null && rows.length >= total || total === null && page.length < requested) break;
      if (!page.length) throw new Error('La bibliothèque a changé pendant le chargement. Rechargez la page.');
    }
    return rows;
  }
  const results = await Promise.all([
    allRows<Deck>('decks', '*'),
    allRows<RemoteCard>('cards', '*,card_schedules(schedule,due,version)'),
    allRows<RemoteReview>('review_logs', '*', 1000, 'reviewed_at', false),
  ]);
  const cards: StudyCard[] = results[1].map((row) => {
    const schedules = row.card_schedules;
    const state = Array.isArray(schedules) ? schedules[0] : schedules;
    return {
      ...row,
      options: row.options || [],
      correct_option_id: row.correct_option_id || null,
      schedule: state?.schedule || newSchedule(),
      version: state?.version ?? 0,
    };
  });
  const reviews: ReviewLog[] = results[2].map((row) => ({
    ...row,
    previous_schedule: row.before_schedule,
    next_schedule: row.after_schedule,
  }));
  const decks = results[0].sort((a, b) => b.created_at.localeCompare(a.created_at));
  return { decks, cards, reviews };
}

function overlayPending(data: LibraryData, pending: PendingReview[]): LibraryData {
  const cards = data.cards.map((card) => ({ ...card }));
  const reviews = [...data.reviews];
  for (const event of pending) {
    if (event.conflict) continue;
    const card = cards.find((item) => item.id === event.card_id);
    if (!card || card.version !== event.expected_version) continue;
    const before = card.schedule;
    card.schedule = scheduleReview(before, event.rating, new Date(event.reviewed_at));
    card.version += 1;
    if (!reviews.some((review) => review.client_event_id === event.client_event_id)) {
      reviews.unshift({ id: event.client_event_id, ...event, previous_schedule: before, next_schedule: card.schedule });
    }
  }
  return { ...data, cards, reviews };
}

async function load(): Promise<LibraryData & { offline?: boolean }> {
  return exclusive(async () => {
    const key = await scope();
    const cached = await cacheFor(key);
    if (key === 'demo') return cached;
    try {
      const remote = overlayPending(await remoteSnapshot(), cached.pending);
      await persistence.write(key, { ...remote, pending: cached.pending });
      return remote;
    } catch (error) {
      if (isNetworkError(error) && cached.cards.length) return { ...cached, offline: true };
      throw error;
    }
  });
}

async function createDeck(input: Pick<Deck, 'title' | 'subject' | 'color'>): Promise<Deck> {
  if (!input.title.trim() || !input.subject.trim()) throw new Error('Indiquez un titre de deck et une matière.');
  return exclusive(async () => {
    const key = await scope();
    const deck: Deck = { id: crypto.randomUUID(), ...input, created_at: new Date().toISOString() };
    if (key !== 'demo') {
      const { error } = await supabase!.from('decks').insert({ ...deck, user_id: key });
      if (error) throw error;
    }
    const data = await cacheFor(key);
    data.decks.unshift(deck);
    await persistence.write(key, data);
    return deck;
  });
}

async function activateDeck(id: string) {
  return exclusive(async () => {
    const key = await scope();
    if (key !== 'demo') {
      const { error } = await supabase!.rpc('activate_deck', { p_deck_id: id });
      if (error) throw error;
    }
    const data = await cacheFor(key);
    data.cards.forEach((card) => { if (card.deck_id === id) card.status = 'active'; });
    await persistence.write(key, data);
  });
}

async function deleteDeck(id: string) {
  return exclusive(async () => {
    const key = await scope();
    if (key !== 'demo') {
      const { data: documents, error: documentsError } = await supabase!.from('documents').select('storage_path').eq('deck_id', id);
      if (documentsError) throw documentsError;
      const paths = (documents || []).map((document) => document.storage_path).filter((path): path is string => Boolean(path));
      if (paths.length) {
        const { error: filesError } = await supabase!.storage.from('courses').remove(paths);
        if (filesError) throw filesError;
      }
      const { error } = await supabase!.from('decks').delete().eq('id', id);
      if (error) throw error;
    }
    const data = await cacheFor(key);
    const ids = new Set(data.cards.filter((card) => card.deck_id === id).map((card) => card.id));
    data.decks = data.decks.filter((deck) => deck.id !== id);
    data.cards = data.cards.filter((card) => card.deck_id !== id);
    data.pending = data.pending.filter((review) => !ids.has(review.card_id));
    data.reviews = data.reviews.filter((review) => !ids.has(review.card_id));
    await persistence.write(key, data);
  });
}

async function importCourse(input: ImportCourseInput): Promise<{ deckId: string; count: number }> {
  if (input.text.trim().length < 40 || input.text.length > 40_000) throw new Error('Le cours doit contenir entre 40 et 40 000 caractères.');
  if (!Number.isInteger(input.count) || input.count < 1 || input.count > 12) throw new Error('Choisissez entre 1 et 12 cartes.');
  const key = await scope();
  const deck = await createDeck({ title: input.title.trim(), subject: input.subject.trim(), color: input.color });
  if (key === 'demo') {
    return exclusive(async () => {
      // Demo mode extracts recall prompts; no model is called and no medical facts are invented.
      const extracts = input.text.split(/(?<=[.!?])\s+|\n\s*\n/).map((part) => part.trim()).filter((part) => part.length >= 20).slice(0, input.count);
      if (!extracts.length) extracts.push(input.text.trim());
      const data = await cacheFor(key);
      const cards: StudyCard[] = extracts.map((excerpt, index) => ({
        id: crypto.randomUUID(), deck_id: deck.id, kind: 'flashcard',
        prompt: `Restituez de mémoire l’idée principale de l’extrait ${index + 1} de « ${input.title} ».`,
        answer: excerpt, explanation: 'Démonstration sans IA : cet extrait est repris directement du cours. Relisez et reformulez la question avant activation.',
        source_excerpt: excerpt, options: [], correct_option_id: null, status: 'draft', schedule: newSchedule(), version: 0,
      }));
      data.cards.push(...cards);
      await persistence.write(key, data);
      return { deckId: deck.id, count: cards.length };
    });
  }
  const documentId = crypto.randomUUID();
  let storagePath: string | null = null;
  try {
    if (input.file) {
      if (input.file.size > 10 * 1024 * 1024) throw new Error('Le fichier dépasse 10 Mo.');
      const safeName = input.file.name.replace(/[^a-zA-Z0-9._-]/g, '_');
      storagePath = `${key}/${documentId}/${safeName}`;
      const contentType = /\.pdf$/i.test(input.file.name) ? 'application/pdf' : /\.md$/i.test(input.file.name) ? 'text/markdown' : 'text/plain';
      const { error } = await supabase!.storage.from('courses').upload(storagePath, input.file, { upsert: false, contentType });
      if (error) throw error;
    }
    const { error } = await supabase!.from('documents').insert({
      id: documentId, user_id: key, deck_id: deck.id, storage_path: storagePath,
      name: input.file?.name || input.title, status: 'uploaded',
    });
    if (error) throw error;
    const result = await invoke<{ count: number }>('generate-quiz', {
      deck_id: deck.id, document_id: documentId, text: input.text.trim(), kind: input.kind, count: input.count,
    });
    return { deckId: deck.id, count: result.count };
  } catch (error) {
    // Keep the draft deck for inspection; never claim generation succeeded after a failed request.
    throw new Error(`La génération a échoué. Le deck « ${deck.title} » reste en brouillon. ${error instanceof Error ? error.message : String(error)}`);
  }
}

async function sendReview(event: PendingReview) {
  return invoke<{ schedule: SerializedSchedule; version: number; duplicate?: boolean }>('submit-review', {
    card_id: event.card_id, rating: event.rating, client_event_id: event.client_event_id,
    reviewed_at: event.reviewed_at, expected_version: event.expected_version,
  });
}

async function rateCard(card: StudyCard, rating: RatingValue): Promise<{ schedule: SerializedSchedule; version: number; queued?: boolean }> {
  return exclusive(async () => {
    const key = await scope();
    const data = await cacheFor(key);
    const current = data.cards.find((item) => item.id === card.id);
    if (!current || current.status !== 'active') throw new Error('Cette carte n’est plus disponible à la révision.');
    if (current.version !== card.version) throw new Error('Cette carte a changé. Rechargez votre session de révision.');
    const event: PendingReview = { card_id: card.id, rating, client_event_id: crypto.randomUUID(), reviewed_at: new Date().toISOString(), expected_version: card.version };
    const before = current.schedule;
    const hasPendingForCard = data.pending.some((item) => item.card_id === card.id);
    if (data.pending.some((item) => item.card_id === card.id && item.conflict)) throw new Error('Un conflit existe pour cette carte. Rechargez son état depuis les réglages de synchronisation.');
    const optimistic = { schedule: scheduleReview(before, rating, new Date(event.reviewed_at)), version: current.version + 1 };
    current.schedule = optimistic.schedule;
    current.version = optimistic.version;
    data.reviews.unshift({ id: event.client_event_id, ...event, previous_schedule: before, next_schedule: optimistic.schedule });
    if (key !== 'demo') data.pending = enqueueReview(data.pending, event);
    // Persist the event, schedule and history atomically before any network request.
    // A tab closing after commit can retry the same ID and continue the local version chain.
    await persistence.write(key, data);
    if (key === 'demo') return optimistic;
    if (!navigator.onLine || hasPendingForCard) return { ...optimistic, queued: true };
    let result: { schedule: SerializedSchedule; version: number };
    try { result = await sendReview(event); }
    catch (error) {
      if (canRetryReview(error)) return { ...optimistic, queued: true };
      // A definitive rejection is surfaced to the student; the action is not counted.
      data.pending = data.pending.filter((item) => item.client_event_id !== event.client_event_id);
      data.reviews = data.reviews.filter((item) => item.client_event_id !== event.client_event_id);
      current.schedule = before;
      current.version = event.expected_version;
      await persistence.write(key, data);
      throw error;
    }
    data.pending = data.pending.filter((item) => item.client_event_id !== event.client_event_id);
    current.schedule = result.schedule;
    current.version = result.version;
    data.reviews.find((review) => review.client_event_id === event.client_event_id)!.next_schedule = result.schedule;
    await persistence.write(key, data);
    return result;
  });
}

async function syncPending(): Promise<{ sent: number; conflicts: number }> {
  return exclusive(async () => {
    const key = await scope();
    if (key === 'demo') return { sent: 0, conflicts: 0 };
    const data = await cacheFor(key);
    let sent = 0;
    for (const event of [...data.pending]) {
      if (event.conflict) continue;
      try {
        const result = await sendReview(event);
        data.pending = data.pending.filter((item) => item.client_event_id !== event.client_event_id);
        const current = data.cards.find((card) => card.id === event.card_id);
        // Do not replace a later optimistic schedule until all events on that card have synced.
        if (current && result.version >= current.version && !data.pending.some((item) => item.card_id === event.card_id)) {
          current.schedule = result.schedule;
          current.version = result.version;
        }
        sent++;
        await persistence.write(key, data);
      } catch (error) {
        if (error instanceof ApiError && error.status && [400, 403, 404, 409].includes(error.status)) {
          // The whole dependent chain needs human review; it must not be replayed against a new version.
          data.pending.forEach((item) => { if (item.card_id === event.card_id) item.conflict = true; });
          await persistence.write(key, data);
          continue;
        }
        if (isNetworkError(error)) break;
        throw error;
      }
    }
    return { sent, conflicts: data.pending.filter((item) => item.conflict).length };
  });
}

/** Explicit user action: discard conflicted local events, preserving server history. */
async function discardConflicts() {
  return exclusive(async () => {
    const key = await scope();
    const data = await cacheFor(key);
    const remote = await remoteSnapshot();
    const pending = data.pending.filter((event) => !event.conflict);
    await persistence.write(key, { ...overlayPending(remote, pending), pending });
  });
}

async function evaluateFeynman(input: { concept: string; explanation: string; context?: string }): Promise<FeynmanAssessment> {
  if (input.explanation.trim().length < 40) throw new Error('Développez votre explication en au moins 40 caractères.');
  if (!isConfigured) return {
    strengths: ['Votre explication est enregistrée dans cette démonstration ; sa justesse n’a pas été évaluée.'],
    missing: ['Vérifiez les définitions, les mécanismes et un exemple clinique dans votre cours.'],
    misconceptions: ['Aucune erreur n’est détectée automatiquement sans connexion à l’IA.'],
    correction: 'Démonstration sans IA. Pour vous auto-évaluer : définissez le concept avec des mots simples, expliquez le mécanisme, donnez un exemple et vérifiez chaque affirmation dans une référence de cours. Connectez Supabase et le fournisseur IA pour obtenir une analyse individualisée.',
    follow_up: [`Comment expliqueriez-vous « ${input.concept} » à un autre étudiant ?`, 'Quelle situation clinique permettrait de distinguer ce concept d’une notion proche ?'],
  };
  await scope();
  return invoke<FeynmanAssessment>('evaluate-feynman', input);
}

export async function clearUserCache(userId?: string) {
  return exclusive(async () => {
    const key = userId || lastScope;
    if (key) await persistence.clear(key);
    lastScope = undefined;
  });
}

export const repository = {
  load, createDeck, activateDeck, deleteDeck, importCourse, rateCard, syncPending, discardConflicts, evaluateFeynman,
  async getPendingCount() { return (await cacheFor(await scope())).pending.length; },
  async getPendingReviews() { return (await cacheFor(await scope())).pending; },
  clearCache: clearUserCache,
  async resetDemo() {
    if (isConfigured) throw new Error('La réinitialisation concerne uniquement le mode démonstration.');
    await persistence.write('demo', createDemoLibrary());
  },
};
