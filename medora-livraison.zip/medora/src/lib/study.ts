import { createStore, del, get, set } from 'idb-keyval';
import { persistence } from './persistence';
import { getSession, isConfigured, supabase } from './supabase';
import { loadCurriculum, loadLesson } from './curriculum';
import type { Question } from './curriculum';
import type { StudyAttempt, StudyEnvelope, StudyEvent, StudyEventKind, StudySession, StudySettings, StudyState, LessonLevel, ImportedCatalogue } from './study-types';
export type * from './study-types';

const db = createStore('medora-curriculum-v2', 'study');
const listeners = new Set<() => void>();
const defaultSettings: StudySettings = { dailyMinutes: 90, backgroundMinutes: 15, fontSize: 18, lineHeight: 1.75, readerTheme: 'light', readerFont: 'serif' };
const modes = ['practice', 'exam', 'qroc', 'writing', 'flashcard'];
const eventKinds: StudyEventKind[] = ['read', 'bookmark', 'note', 'last-read', 'attempt', 'session', 'exam', 'settings', 'lesson-review', 'writing', 'active-session', 'legacy', 'catalogue', 'reset-progress', 'mission-add', 'mission-remove'];
let operations: Promise<unknown> = Promise.resolve();
let lastScope: string | undefined;
const lastSync = new Map<string, number>();
const inFlightSync = new Map<string, Promise<StudyState>>();
let syncTimer: ReturnType<typeof setTimeout> | undefined;
const cacheKey = (scope: string) => `study:${scope}`;
const emit = () => { for (const listener of listeners) listener(); };
const uuid = () => crypto.randomUUID();
const record = (value: unknown): value is Record<string, unknown> => value !== null && typeof value === 'object' && !Array.isArray(value);
const text = (value: unknown, max = 200): value is string => typeof value === 'string' && value.length > 0 && value.length <= max;
const identifier = (value: unknown): value is string => text(value) && !['__proto__', 'prototype', 'constructor'].includes(value);
const integer = (value: unknown, min = 0, max = 100000): value is number => typeof value === 'number' && Number.isInteger(value) && value >= min && value <= max;
const finite = (value: unknown, min: number, max: number): value is number => typeof value === 'number' && Number.isFinite(value) && value >= min && value <= max;
const timestamp = (value: unknown): value is string => typeof value === 'string' && value.length <= 40 && Number.isFinite(Date.parse(value));
const has = (object: Record<string, unknown>, key: string) => Object.prototype.hasOwnProperty.call(object, key);
const freshEnvelope = (): StudyEnvelope => ({ schemaVersion: 2, events: [], pending: [], syncStatus: 'local' });

function exclusive<T>(action: () => Promise<T>): Promise<T> {
  const result = operations.then(action, action);
  operations = result.then(() => undefined, () => undefined);
  return result;
}

async function scope() {
  if (!isConfigured) return (lastScope = 'demo');
  const session = await getSession();
  if (!session) throw new Error('Connectez-vous pour retrouver votre progression.');
  return (lastScope = session.user.id);
}

async function readEnvelope(key: string): Promise<StudyEnvelope> {
  return await get<StudyEnvelope>(cacheKey(key), db) || freshEnvelope();
}

/** Reject unsafe keys at every depth. Backups are data and are never merged with object prototypes. */
export function sanitizeBackup(value: unknown, depth = 0): unknown {
  if (depth > 24) throw new Error('Sauvegarde trop imbriquée.');
  if (value === null || typeof value === 'boolean') return value;
  if (typeof value === 'number') { if (!Number.isFinite(value)) throw new Error('Nombre invalide dans la sauvegarde.'); return value; }
  if (typeof value === 'string') { if (value.length > 1_000_000) throw new Error('Texte trop volumineux dans la sauvegarde.'); return value; }
  if (Array.isArray(value)) { if (value.length > 100000) throw new Error('Sauvegarde trop volumineuse.'); return value.map((item) => sanitizeBackup(item, depth + 1)); }
  if (!record(value)) throw new Error('Format de sauvegarde invalide.');
  const entries = Object.entries(value);
  if (entries.length > 100000) throw new Error('Sauvegarde trop volumineuse.');
  return Object.fromEntries(entries.filter(([key]) => !['__proto__', 'prototype', 'constructor'].includes(key)).map(([key, item]) => [key, sanitizeBackup(item, depth + 1)]));
}

export function isCalendarDate(value: unknown): value is string {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const date = new Date(`${value}T12:00:00Z`);
  return Number.isFinite(date.getTime()) && date.toISOString().slice(0, 10) === value;
}

function settingsPatch(input: Record<string, unknown>): Partial<StudySettings> {
  const output: Partial<StudySettings> = {};
  if (finite(input.dailyMinutes, 10, 720)) output.dailyMinutes = Math.round(input.dailyMinutes);
  if (finite(input.backgroundMinutes, 0, 60)) output.backgroundMinutes = Math.round(input.backgroundMinutes);
  if (finite(input.fontSize, 14, 30)) output.fontSize = input.fontSize;
  if (finite(input.lineHeight, 1.3, 2.4)) output.lineHeight = input.lineHeight;
  if (['light', 'sepia', 'dark'].includes(String(input.readerTheme))) output.readerTheme = input.readerTheme as StudySettings['readerTheme'];
  if (['serif', 'sans', 'system', 'atkinson'].includes(String(input.readerFont))) output.readerFont = input.readerFont as StudySettings['readerFont'];
  return output;
}

function validatedCatalogue(input: unknown): ImportedCatalogue {
  if (!record(input) || input.schemaVersion !== 1 || !Array.isArray(input.subjects) || !Array.isArray(input.resources) || input.subjects.length > 100 || input.resources.length > 5000) throw new Error('Catalogue invalide : utilisez le manifeste MED2 avec subjects et resources.');
  const subjects: ImportedCatalogue['subjects'] = []; const resources: ImportedCatalogue['resources'] = [];
  const ids = new Set<string>(); const subjectIds = new Set<string>();
  for (const value of input.subjects) {
    if (!record(value) || !identifier(value.id) || !text(value.name, 200) || subjectIds.has(value.id)) throw new Error('Matière incomplète ou dupliquée dans le catalogue.');
    subjectIds.add(value.id);
    subjects.push({ id: value.id, name: value.name, ...(typeof value.color === 'string' && /^#[0-9a-f]{6}$/i.test(value.color) ? { color: value.color } : {}) });
  }
  for (const value of input.resources) {
    if (!record(value) || !identifier(value.id) || !identifier(value.subject) || !text(value.title, 500) || !text(value.kind, 40) || ids.has(value.id) || !subjectIds.has(value.subject)) throw new Error('Document incomplet, dupliqué ou matière inconnue dans le catalogue.');
    ids.add(value.id);
    let url: string | undefined;
    if (value.url !== undefined && value.url !== '') {
      try { const parsed = new URL(String(value.url)); if (parsed.protocol !== 'https:' || parsed.username || parsed.password) throw new Error(); url = parsed.href; } catch { throw new Error('Les documents importés doivent utiliser une adresse HTTPS valide.'); }
    }
    resources.push({ id: value.id, subject: value.subject, title: value.title, kind: value.kind, ...(text(value.status, 80) ? { status: value.status } : {}), ...(url ? { url } : {}) });
  }
  return { schemaVersion: 1, subjects, resources };
}

function validAttempt(value: unknown): value is StudyAttempt {
  return record(value) && identifier(value.id) && identifier(value.questionId) && identifier(value.subjectId)
    && (value.lessonId === undefined || identifier(value.lessonId)) && modes.includes(String(value.mode))
    && typeof value.correct === 'boolean' && timestamp(value.createdAt)
    && (value.chapterIndex === undefined || integer(value.chapterIndex, 0, 10000))
    && (value.selected === undefined || Array.isArray(value.selected) && value.selected.length <= 100 && value.selected.every((x) => integer(x, 0, 999)))
    && (value.responseText === undefined || typeof value.responseText === 'string' && value.responseText.length <= 40000)
    && (value.score === undefined || finite(value.score, 0, 1))
    && (value.durationSeconds === undefined || finite(value.durationSeconds, 0, 86400));
}

function validSession(value: unknown): value is StudySession {
  return record(value) && identifier(value.id) && modes.includes(String(value.mode))
    && (value.subjectId === undefined || identifier(value.subjectId)) && (value.lessonId === undefined || identifier(value.lessonId))
    && timestamp(value.startedAt) && timestamp(value.finishedAt) && Date.parse(value.finishedAt) >= Date.parse(value.startedAt)
    && integer(value.questionCount, 0, 10000) && integer(value.correctCount, 0, value.questionCount)
    && finite(value.durationSeconds, 0, 86400 * 7);
}

export function emptyStudyState(): StudyState {
  return { schemaVersion: 2, read: {}, bookmarks: [], notes: {}, attempts: [], sessions: [], missions: [], exams: {}, settings: { ...defaultSettings }, lessonReviews: {}, writingDrafts: {}, version: 0, syncStatus: 'local' };
}

/** A union of immutable events avoids whole-state replacement when two devices reconnect. */
export function mergeStudyEvents(...groups: StudyEvent[][]): StudyEvent[] {
  const events = new Map<string, StudyEvent>();
  for (const group of groups) for (const event of group) {
    if (validEvent(event) && !events.has(event.id)) events.set(event.id, event);
  }
  return [...events.values()].sort((a, b) => a.clock - b.clock || a.createdAt.localeCompare(b.createdAt) || a.id.localeCompare(b.id));
}

function validEvent(value: unknown): value is StudyEvent {
  return record(value) && typeof value.id === 'string' && /^[0-9a-f]{8}-[0-9a-f-]{27}$/i.test(value.id)
    && eventKinds.includes(value.kind as StudyEventKind) && integer(value.clock, 1, Number.MAX_SAFE_INTEGER)
    && timestamp(value.createdAt) && record(value.data);
}

export function replayStudyEvents(events: StudyEvent[], status: StudyState['syncStatus'] = 'local'): StudyState {
  const state = emptyStudyState();
  const attempts = new Set<string>(); const sessions = new Set<string>(); const reviews = new Set<string>();
  const apply = (event: StudyEvent) => {
    const data = event.data;
    const id = identifier(data.lessonId) ? data.lessonId : undefined;
    switch (event.kind) {
      case 'read':
        if (id && integer(data.chapterIndex, 0, 10000) && typeof data.read === 'boolean') {
          const values = new Set(state.read[id] || []);
          if (data.read) values.add(data.chapterIndex); else values.delete(data.chapterIndex);
          state.read[id] = [...values].sort((a, b) => a - b);
        }
        break;
      case 'bookmark':
        if (id && typeof data.enabled === 'boolean') state.bookmarks = data.enabled ? [...new Set([...state.bookmarks, id])] : state.bookmarks.filter((x) => x !== id);
        break;
      case 'note': if (id && typeof data.text === 'string' && data.text.length <= 40000) state.notes[id] = data.text; break;
      case 'last-read': if (id && integer(data.chapterIndex, 0, 10000)) state.lastRead = { lessonId: id, chapterIndex: data.chapterIndex }; break;
      case 'attempt':
        if (validAttempt(data.attempt) && !attempts.has(data.attempt.id)) { state.attempts.push(data.attempt); attempts.add(data.attempt.id); }
        break;
      case 'session':
        if (validSession(data.session) && !sessions.has(data.session.id)) { state.sessions.push(data.session); sessions.add(data.session.id); }
        break;
      case 'exam':
        if (identifier(data.subjectId)) { if (isCalendarDate(data.date)) state.exams[data.subjectId] = data.date; else if (data.date === null) delete state.exams[data.subjectId]; }
        break;
      case 'settings': state.settings = { ...state.settings, ...settingsPatch(data) }; break;
      case 'lesson-review':
        if (id && identifier(data.id) && ['mastered', 'partial', 'again'].includes(String(data.level)) && timestamp(data.createdAt) && !reviews.has(data.id)) {
          (state.lessonReviews[id] ||= []).push({ id: data.id, level: data.level as LessonLevel, createdAt: data.createdAt }); reviews.add(data.id);
        }
        break;
      case 'writing': if (identifier(data.id) && typeof data.text === 'string' && data.text.length <= 40000) state.writingDrafts[data.id] = data.text; break;
      case 'active-session':
        if (data.session === null) delete state.activeSession;
        else if (record(data.session) && JSON.stringify(data.session).length <= 256000) state.activeSession = data.session;
        break;
      case 'legacy': if (record(data.state)) state.importedLegacy = data.state; break;
      case 'catalogue':
        try {
          const catalogue = validatedCatalogue(data.catalogue);
          const old = state.customCatalogue || { schemaVersion: 1 as const, subjects: [], resources: [] };
          state.customCatalogue = { schemaVersion: 1, subjects: [...new Map([...old.subjects, ...catalogue.subjects].map((item) => [item.id, item])).values()], resources: [...new Map([...old.resources, ...catalogue.resources].map((item) => [item.id, item])).values()] };
        } catch { /* Invalid remote/imported metadata never changes the built-in curriculum. */ }
        break;
      case 'reset-progress':
        state.read = {}; state.attempts = []; state.sessions = []; state.lessonReviews = {};
        state.missions = [];
        delete state.activeSession; delete state.lastRead;
        attempts.clear(); sessions.clear(); reviews.clear();
        break;
      case 'mission-add':
        if (id && identifier(data.id) && ['read', 'practice', 'recall'].includes(String(data.type)) && timestamp(data.createdAt) && !state.missions.some((item) => item.id === data.id)) state.missions.push({ id: data.id, lessonId: id, type: data.type as 'read' | 'practice' | 'recall', createdAt: data.createdAt });
        break;
      case 'mission-remove': if (identifier(data.id)) state.missions = state.missions.filter((item) => item.id !== data.id); break;
    }
  };
  const merged = mergeStudyEvents(events);
  for (const event of merged) apply(event);
  state.attempts.sort((a, b) => a.createdAt.localeCompare(b.createdAt) || a.id.localeCompare(b.id));
  state.sessions.sort((a, b) => a.finishedAt.localeCompare(b.finishedAt) || a.id.localeCompare(b.id));
  state.version = merged.length;
  state.syncStatus = status;
  return state;
}

function stateOf(envelope: StudyEnvelope) { return replayStudyEvents(envelope.events, envelope.syncStatus); }

async function append(kind: StudyEventKind, data: Record<string, unknown>, expectedScope?: string): Promise<StudyState> {
  return exclusive(async () => {
    let key: string;
    try { key = await scope(); } catch (error) { if (expectedScope !== undefined) return emptyStudyState(); throw error; }
    const envelope = await readEnvelope(key);
    if (expectedScope !== undefined && key !== expectedScope) return stateOf(envelope);
    const safe = sanitizeBackup(JSON.parse(JSON.stringify(data))) as Record<string, unknown>;
    const clock = envelope.events.reduce((max, event) => Math.max(max, event.clock), 0) + 1;
    const event: StudyEvent = { id: uuid(), kind, data: safe, clock, createdAt: new Date().toISOString() };
    envelope.events.push(event);
    if (key !== 'demo') envelope.pending.push(event.id);
    envelope.syncStatus = key === 'demo' ? 'local' : 'pending';
    await set(cacheKey(key), envelope, db);
    emit();
    if (key !== 'demo' && typeof navigator !== 'undefined' && navigator.onLine) {
      clearTimeout(syncTimer);
      syncTimer = setTimeout(() => { void sync().catch(() => undefined); }, 1500);
    }
    return stateOf(envelope);
  });
}

function validateId(id: string) { if (!identifier(id)) throw new Error('Identifiant de cours invalide.'); }

/** No partial official marks: a QRM succeeds only if the chosen set exactly equals the expected set. */
export function gradeChoices(selected: number[], correct: number[]): boolean {
  if (!selected.length || !correct.length || !selected.every((x) => integer(x, 0, 999)) || !correct.every((x) => integer(x, 0, 999))) return false;
  const chosen = [...new Set(selected)].sort((a, b) => a - b);
  const expected = [...new Set(correct)].sort((a, b) => a - b);
  return chosen.length === expected.length && chosen.every((value, index) => value === expected[index]);
}

const normalized = (value: string) => value.normalize('NFD').replace(/\p{M}/gu, '').toLocaleLowerCase('fr').replace(/[^\p{L}\p{N}]+/gu, ' ').trim();
/** Lexical help only. In particular, no fuzzy matching between hypo/hyper, I/II, drugs or doses. */
export function matchQrocKeywords(response: string, groups: string[][]) {
  const source = normalized(response).split(/\s+/).filter(Boolean);
  const matched: string[] = []; const missing: string[] = []; const negated: string[] = [];
  for (const group of groups) {
    const label = group[0] || '';
    let found = false; let negative = false;
    for (const alias of group) {
      const tokens = normalized(alias).split(/\s+/).filter(Boolean);
      if (!tokens.length) continue;
      for (let offset = 0; offset <= source.length - tokens.length; offset++) {
        if (!tokens.every((token, index) => source[offset + index] === token)) continue;
        const before = source.slice(Math.max(0, offset - 4), offset);
        const around = source.slice(Math.max(0, offset - 4), offset + tokens.length + 3);
        const after = source.slice(offset + tokens.length, offset + tokens.length + 3);
        if (before.some((token) => ['sans', 'pas', 'aucun', 'aucune', 'absence', 'non', 'jamais', 'ni'].includes(token)) || before.includes('ne') && around.includes('pas') || after.some((token) => ['absent', 'absente', 'absents', 'absentes', 'exclu', 'exclue', 'negatif', 'negative'].includes(token))) negative = true;
        else found = true;
      }
    }
    if (negative) { negated.push(label); missing.push(label); } else if (found) matched.push(label); else missing.push(label);
  }
  return { matched, missing, negated, warning: 'Repérage de mots-clés uniquement : ni le sens clinique, ni les doses, ni la justesse du raisonnement ne sont évalués. Comparez au corrigé puis autoévaluez-vous.' };
}

async function sync(): Promise<StudyState> {
  const key = await scope();
  if (key === 'demo') return stateOf(await readEnvelope(key));
  const running = inFlightSync.get(key); if (running) return running;
  const task = exclusive(async () => {
    const envelope = await readEnvelope(key);
    try {
      if (!supabase) throw new Error('Supabase non configuré.');
      const pendingIds = new Set(envelope.pending);
      const pending = envelope.events.filter((event) => pendingIds.has(event.id));
      for (let offset = 0; offset < pending.length; offset += 100) {
        const batch = pending.slice(offset, offset + 100);
        const result = await supabase.from('study_events').upsert(batch.map((event) => ({ id: event.id, user_id: key, kind: event.kind, payload: { clock: event.clock, data: event.data }, happened_at: event.createdAt })), { onConflict: 'user_id,id', ignoreDuplicates: true });
        if (result.error) throw result.error;
        const sent = new Set(batch.map((event) => event.id));
        envelope.pending = envelope.pending.filter((id) => !sent.has(id));
        await set(cacheKey(key), envelope, db);
      }
      const remote: StudyEvent[] = [];
      let offset = 0; let total: number | null = null;
      // Count-aware pagination also works when the project caps API pages below 500 rows.
      while (true) {
        const result = await supabase.from('study_events').select('id,kind,payload,happened_at', { count: 'exact' }).eq('user_id', key).order('id', { ascending: true }).range(offset, offset + 499);
        if (result.error) throw result.error;
        total = result.count ?? total;
        const rows = result.data || [];
        for (const row of rows) if (record(row.payload)) remote.push({ id: row.id, kind: row.kind as StudyEventKind, clock: row.payload.clock as number, data: row.payload.data as Record<string, unknown>, createdAt: row.happened_at });
        offset += rows.length;
        if (total !== null ? offset >= total : rows.length < 500) break;
        if (!rows.length) throw new Error('La progression a changé pendant la synchronisation. Réessayez.');
      }
      envelope.events = mergeStudyEvents(envelope.events, remote);
      envelope.syncStatus = envelope.pending.length ? 'pending' : 'synced';
      lastSync.set(key, Date.now());
    } catch {
      // Keep every local event. A missing migration is visible as unavailable rather than blocking courses.
      envelope.syncStatus = envelope.pending.length ? 'pending' : 'unavailable';
    }
    await set(cacheKey(key), envelope, db);
    emit();
    return stateOf(envelope);
  });
  inFlightSync.set(key, task);
  try { return await task; } finally { inFlightSync.delete(key); }
}

function stateImportEvents(state: Record<string, unknown>, event: (kind: StudyEventKind, data: Record<string, unknown>) => void) {
  if (record(state.read)) for (const [lessonId, chapters] of Object.entries(state.read)) if (identifier(lessonId) && Array.isArray(chapters)) for (const chapterIndex of chapters) if (integer(chapterIndex, 0, 10000)) event('read', { lessonId, chapterIndex, read: true });
  if (Array.isArray(state.bookmarks)) for (const lessonId of state.bookmarks) if (identifier(lessonId)) event('bookmark', { lessonId, enabled: true });
  if (record(state.notes)) for (const [lessonId, value] of Object.entries(state.notes)) if (identifier(lessonId) && typeof value === 'string' && value.length <= 40000) event('note', { lessonId, text: value });
  if (record(state.lastRead) && identifier(state.lastRead.lessonId) && integer(state.lastRead.chapterIndex, 0, 10000)) event('last-read', state.lastRead);
  if (Array.isArray(state.attempts)) for (const attempt of state.attempts) if (validAttempt(attempt)) event('attempt', { attempt });
  if (Array.isArray(state.sessions)) for (const session of state.sessions) if (validSession(session)) event('session', { session });
  if (Array.isArray(state.missions)) for (const mission of state.missions) if (record(mission) && identifier(mission.id) && identifier(mission.lessonId) && timestamp(mission.createdAt) && ['read', 'practice', 'recall'].includes(String(mission.type))) event('mission-add', mission);
  if (record(state.exams)) for (const [subjectId, date] of Object.entries(state.exams)) if (identifier(subjectId) && isCalendarDate(date)) event('exam', { subjectId, date });
  if (record(state.settings)) event('settings', settingsPatch(state.settings));
  if (record(state.lessonReviews)) for (const [lessonId, reviews] of Object.entries(state.lessonReviews)) if (identifier(lessonId) && Array.isArray(reviews)) for (const review of reviews) if (record(review) && identifier(review.id) && timestamp(review.createdAt) && ['mastered', 'partial', 'again'].includes(String(review.level))) event('lesson-review', { lessonId, ...review });
  if (record(state.writingDrafts)) for (const [id, value] of Object.entries(state.writingDrafts)) if (identifier(id) && typeof value === 'string' && value.length <= 40000) event('writing', { id, text: value });
  if (record(state.activeSession)) event('active-session', { session: state.activeSession });
  if (record(state.importedLegacy)) event('legacy', { state: state.importedLegacy });
  if (record(state.customCatalogue)) event('catalogue', { catalogue: validatedCatalogue(state.customCatalogue) });
}

interface LegacyContext { subjects: Map<string, string>; questions: Map<string, Question>; qroc: Map<string, Question>; writing: Map<string, Question>; cards: Map<string, { id: string; chapterIndex?: number }> }
async function legacyContext(state: Record<string, unknown>): Promise<LegacyContext> {
  const context: LegacyContext = { subjects: new Map(), questions: new Map(), qroc: new Map(), writing: new Map(), cards: new Map() };
  try {
    const manifest = await loadCurriculum();
    for (const lesson of manifest.lessons) context.subjects.set(lesson.id, lesson.subjectId);
    const ids = new Set<string>();
    for (const field of ['quizAttemptHistory', 'quizAnswers', 'flashcards']) if (record(state[field])) for (const key of Object.keys(state[field])) ids.add(key.split('#')[0]);
    const qrocIds = record(state.qroc) ? Object.keys(state.qroc) : [];
    const writingIds = record(state.sshWritingDrafts) ? Object.keys(state.sshWritingDrafts) : [];
    for (const lesson of manifest.lessons) if ([...qrocIds, ...writingIds].some((id) => id.startsWith(lesson.id.slice(-8)))) ids.add(lesson.id);
    const loaded = await Promise.allSettled([...ids].filter((id) => context.subjects.has(id)).map((id) => loadLesson(id)));
    for (const result of loaded) if (result.status === 'fulfilled') {
      const lesson = result.value;
      lesson.questions.forEach((question, index) => context.questions.set(`${lesson.id}#${index}`, question));
      lesson.qroc.forEach((question) => { context.qroc.set(String(question.originalId || question.id), question); });
      lesson.writing.forEach((question) => { context.writing.set(String(question.originalId || question.id), question); });
      lesson.flashcards.forEach((card, index) => context.cards.set(`${lesson.id}#${index}`, card));
    }
  } catch { /* The full raw evidence is retained even when static content cannot be loaded offline. */ }
  return context;
}

function legacyImportEvents(state: Record<string, unknown>, event: (kind: StudyEventKind, data: Record<string, unknown>) => void, context: LegacyContext) {
  event('legacy', { state });
  const plan = record(state.plan) ? state.plan : {};
  if (record(plan.settings) && finite(plan.settings.daily, 10, 720)) event('settings', { dailyMinutes: plan.settings.daily });
  if (record(state.sshWritingDrafts)) for (const [id, value] of Object.entries(state.sshWritingDrafts)) if (identifier(id) && typeof value === 'string' && value.length <= 40000) event('writing', { id: context.writing.get(id)?.id || id, text: value });
  // Legacy history contains actual user self-assessments. Never invent attempts from a mere counter.
  if (Array.isArray(state.history)) for (const [index, item] of state.history.entries()) if (record(item) && identifier(item.id) && isCalendarDate(item.date) && ['good', 'partial', 'forgot'].includes(String(item.score))) event('lesson-review', { lessonId: item.id, id: `legacy-review-${item.id}-${item.date}-${index}`, level: item.score === 'good' ? 'mastered' : item.score === 'partial' ? 'partial' : 'again', createdAt: `${item.date}T12:00:00.000Z` });
  if (record(plan.done)) for (const [lessonId, values] of Object.entries(plan.done)) if (identifier(lessonId) && Array.isArray(values)) for (const [index, value] of values.entries()) if (record(value) && isCalendarDate(value.date) && ['maitrise', 'moyen'].includes(String(value.level))) {
    // A history assessment for this lesson/date already covers the same completed tour.
    if (Array.isArray(state.history) && state.history.some((item) => record(item) && item.id === lessonId && item.date === value.date)) continue;
    event('lesson-review', { lessonId, id: `legacy-tour-${lessonId}-${value.date}-${index}`, level: value.level === 'maitrise' ? 'mastered' : 'partial', createdAt: `${value.date}T12:00:00.000Z` });
  }
  const trainingHistory: Record<string, unknown> = record(state.trainingAttemptHistory) ? { ...state.trainingAttemptHistory } : {};
  if (record(state.trainingAnswers)) for (const [id, value] of Object.entries(state.trainingAnswers)) if (!has(trainingHistory, id)) trainingHistory[id] = [value];
  for (const [originalId, values] of Object.entries(trainingHistory)) if (identifier(originalId) && Array.isArray(values)) for (const [index, value] of values.entries()) if (record(value) && typeof value.correct === 'boolean' && isCalendarDate(value.date)) {
    const questionId = originalId.startsWith('training:') ? originalId : `training:${originalId}`;
    const attempt = { id: `legacy-training-${originalId}-${value.date}-${index}`, questionId, subjectId: originalId.replace(/^training:/, '').split('-')[0] || 'legacy', mode: 'practice', correct: value.correct, ...(Array.isArray(value.selected) ? { selected: value.selected } : {}), createdAt: `${value.date}T12:00:00.000Z`, imported: true };
    if (validAttempt(attempt)) event('attempt', { attempt });
  }
  if (record(state.quizAttemptHistory)) for (const [key, values] of Object.entries(state.quizAttemptHistory)) if (Array.isArray(values)) {
    const [lessonId, rawIndex] = key.split('#'); const index = Number(rawIndex);
    if (!identifier(lessonId) || !integer(index, 0, 10000)) continue;
    const question = context.questions.get(key);
    for (const [position, value] of values.entries()) if (record(value) && typeof value.correct === 'boolean' && isCalendarDate(value.at)) {
      const attempt = { id: `legacy-quiz-${key}-${value.at}-${position}`, questionId: question?.canonicalId || question?.id || `lesson:${lessonId}:qcm:${index}`, lessonId, subjectId: context.subjects.get(lessonId) || 'legacy', chapterIndex: question?.chapterIndex, mode: 'practice', correct: value.correct, selected: Array.isArray(value.choices) ? value.choices : integer(value.choice, 0, 999) ? [value.choice] : [], createdAt: `${value.at}T12:00:00.000Z`, imported: true };
      if (validAttempt(attempt)) event('attempt', { attempt: JSON.parse(JSON.stringify(attempt)) });
    }
  }
  if (record(state.flashcards)) for (const [key, value] of Object.entries(state.flashcards)) if (record(value) && ['good', 'again'].includes(String(value.result)) && isCalendarDate(value.at)) {
    const [lessonId, rawIndex] = key.split('#'); const index = Number(rawIndex); if (!identifier(lessonId) || !integer(index, 0, 10000)) continue;
    const card = context.cards.get(key);
    const attempt = { id: `legacy-card-${key}-${value.at}`, questionId: card?.id || `lesson:${lessonId}:card:${index}`, lessonId, subjectId: context.subjects.get(lessonId) || 'legacy', mode: 'flashcard', correct: value.result === 'good', createdAt: `${value.at}T12:00:00.000Z`, imported: true };
    if (validAttempt(attempt)) event('attempt', { attempt });
  }
  // Old QROC matching was permissive (negation/fuzzy matching): preserve answers as drafts, never import its automatic "ok" as clinical success.
  if (record(state.qroc)) for (const [id, value] of Object.entries(state.qroc)) if (record(value) && typeof value.a === 'string' && value.a.length <= 40000 && identifier(id)) event('writing', { id: context.qroc.get(id)?.id || id, text: value.a });
  if (record(state.sshWritingResults)) for (const [id, value] of Object.entries(state.sshWritingResults)) if (record(value) && ['good', 'again'].includes(String(value.result)) && isCalendarDate(value.date) && identifier(id)) {
    const question = context.writing.get(id);
    if (!question) continue;
    event('attempt', { attempt: { id: `legacy-writing-${id}-${value.date}`, questionId: question.id, lessonId: question.lessonId, subjectId: question.subjectId, mode: 'writing', correct: value.result === 'good', createdAt: `${value.date}T12:00:00.000Z`, imported: true } });
  }
  if (record(state.courseExamHistory)) for (const [lessonId, values] of Object.entries(state.courseExamHistory)) if (identifier(lessonId) && Array.isArray(values)) for (const [index, value] of values.entries()) if (record(value) && isCalendarDate(value.date) && integer(value.total, 1, 10000) && integer(value.score, 0, value.total)) event('session', { session: { id: `legacy-exam-${lessonId}-${value.date}-${index}`, lessonId, subjectId: context.subjects.get(lessonId) || 'legacy', mode: 'exam', startedAt: `${value.date}T12:00:00.000Z`, finishedAt: `${value.date}T12:00:00.000Z`, questionCount: value.total, correctCount: value.score, durationSeconds: 0, imported: true } });
}

export const study = {
  ownerScope() { return scope(); },
  async load(): Promise<StudyState> {
    const key = await scope();
    const envelope = await exclusive(() => readEnvelope(key));
    if (key !== 'demo' && typeof navigator !== 'undefined' && navigator.onLine && Date.now() - (lastSync.get(key) || 0) > 60000) { lastSync.set(key, Date.now()); void sync().catch(() => undefined); }
    return stateOf(envelope);
  },
  subscribe(listener: () => void) { listeners.add(listener); return () => { listeners.delete(listener); }; },
  markRead(lessonId: string, chapterIndex: number, read = true) { validateId(lessonId); if (!integer(chapterIndex, 0, 10000)) throw new Error('Chapitre invalide.'); return append('read', { lessonId, chapterIndex, read }); },
  setBookmark(lessonId: string, enabled: boolean) { validateId(lessonId); return append('bookmark', { lessonId, enabled }); },
  setNote(lessonId: string, value: string) { validateId(lessonId); if (value.length > 40000) throw new Error('La note dépasse 40 000 caractères.'); return append('note', { lessonId, text: value }); },
  setLastRead(lessonId: string, chapterIndex: number) { validateId(lessonId); if (!integer(chapterIndex, 0, 10000)) throw new Error('Chapitre invalide.'); return append('last-read', { lessonId, chapterIndex }); },
  recordAttempt(input: Omit<StudyAttempt, 'id' | 'createdAt'> & { id?: string }) { const attempt = { ...input, id: input.id || uuid(), createdAt: new Date().toISOString() }; if (!validAttempt(attempt)) throw new Error('Réponse invalide.'); return append('attempt', { attempt }); },
  recordSession(input: Omit<StudySession, 'id'> & { id?: string }) { const session = { ...input, id: input.id || uuid() }; if (!validSession(session)) throw new Error('Session invalide.'); return append('session', { session }); },
  setExamDate(subjectId: string, date: string | null) { validateId(subjectId); if (date !== null && !isCalendarDate(date)) throw new Error('Date d’examen invalide.'); return append('exam', { subjectId, date }); },
  updateSettings(input: Partial<StudySettings>) { const patch = settingsPatch(input); if (Object.keys(patch).length !== Object.keys(input).length) throw new Error('Réglages de lecture invalides.'); return append('settings', patch); },
  saveWritingDraft(id: string, value: string) { validateId(id); if (value.length > 40000) throw new Error('La réponse dépasse 40 000 caractères.'); return append('writing', { id, text: value }); },
  recordLessonReview(lessonId: string, level: LessonLevel) { validateId(lessonId); if (!['mastered', 'partial', 'again'].includes(level)) throw new Error('Autoévaluation invalide.'); return append('lesson-review', { lessonId, level, id: uuid(), createdAt: new Date().toISOString() }); },
  saveActiveSession(session: Record<string, unknown> | null, expectedScope?: string) { if (session && JSON.stringify(session).length > 256000) throw new Error('Session trop volumineuse.'); return append('active-session', { session }, expectedScope); },
  importCatalogue(input: unknown) { return append('catalogue', { catalogue: validatedCatalogue(sanitizeBackup(input)) }); },
  resetProgress() { return append('reset-progress', {}); },
  addMission(lessonId: string, type: 'read' | 'practice' | 'recall') { validateId(lessonId); if (!['read', 'practice', 'recall'].includes(type)) throw new Error('Type de mission invalide.'); return append('mission-add', { lessonId, type, id: uuid(), createdAt: new Date().toISOString() }); },
  removeMission(id: string) { validateId(id); return append('mission-remove', { id }); },
  sync,
  async exportBackup() {
    return exclusive(async () => {
      const key = await scope(); const envelope = await readEnvelope(key);
      return { app: 'medora', schemaVersion: 2, exportedAt: new Date().toISOString(), scope: key === 'demo' ? 'demo' : 'account', state: stateOf(envelope), events: envelope.events, library: await persistence.read(key) || envelope.archivedLibrary || null };
    });
  },
  async importBackup(input: unknown, mode: 'merge' = 'merge'): Promise<StudyState> {
    if (mode !== 'merge') throw new Error('Seule la fusion préservant vos données est proposée.');
    const serialized = JSON.stringify(input);
    if (!serialized || serialized.length > 20_000_000) throw new Error('Sauvegarde invalide ou supérieure à 20 Mo.');
    const safe = sanitizeBackup(input);
    if (!record(safe)) throw new Error('Sauvegarde invalide.');
    const isCurrent = safe.app === 'medora' && safe.schemaVersion === 2 && record(safe.state);
    const legacyState = safe.app === 'med2-s1' && record(safe.state) ? safe.state : record(safe['med2.semestre1.etat.v1']) ? safe['med2.semestre1.etat.v1'] : undefined;
    if (!isCurrent && !legacyState) throw new Error('Choisissez une sauvegarde Medora ou MED2 S1 (.json).');
    const context = legacyState ? await legacyContext(legacyState) : undefined;
    return exclusive(async () => {
      const key = await scope(); const envelope = await readEnvelope(key);
      const existingState = stateOf(envelope);
      let clock = envelope.events.reduce((max, event) => Math.max(max, event.clock), 0);
      const imported: StudyEvent[] = [];
      const add = (kind: StudyEventKind, data: Record<string, unknown>) => { imported.push({ id: uuid(), kind, data, clock: ++clock, createdAt: new Date().toISOString() }); };
      if (isCurrent && Array.isArray(safe.events) && safe.events.length) {
        for (const event of safe.events) if (validEvent(event)) imported.push(event);
        clock = imported.reduce((max, event) => Math.max(max, event.clock), clock);
        // Reset events from a backup must never clear progress belonging to the receiving account.
        stateImportEvents(existingState as unknown as Record<string, unknown>, add);
        // An explicit restore after a reset reapplies the saved state, while immutable histories keep IDs.
        stateImportEvents(safe.state as Record<string, unknown>, add);
      } else if (isCurrent) stateImportEvents(safe.state as Record<string, unknown>, add);
      else legacyImportEvents(legacyState as Record<string, unknown>, add, context!);
      const before = new Set(envelope.events.map((event) => event.id));
      envelope.events = mergeStudyEvents(envelope.events, imported);
      if (key !== 'demo') envelope.pending = [...new Set([...envelope.pending, ...envelope.events.filter((event) => !before.has(event.id)).map((event) => event.id)])];
      if (has(safe, 'library') && safe.library !== null) envelope.archivedLibrary = safe.library;
      envelope.syncStatus = key === 'demo' ? 'local' : 'pending';
      await set(cacheKey(key), envelope, db);
      emit(); return stateOf(envelope);
    });
  },
  async clearCache(userId?: string) {
    clearTimeout(syncTimer);
    return exclusive(async () => { const key = userId || lastScope; if (key) { await del(cacheKey(key), db); lastSync.delete(key); } lastScope = undefined; emit(); });
  },
};
