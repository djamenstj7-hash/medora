/** Static MED2 source content. Loaded on demand; never executes imported HTML. */
export interface SourceReference { label?: string; title?: string; url?: string; pages?: string | number; page?: string | number; [key: string]: unknown }
export interface CurriculumSubject { id: string; name: string; date?: string; group?: string; cmCount?: number; annaleCount?: number; contentStatus?: string; color: string; lessonCount: number; trainingCount: number; caseCount: number }
export interface LessonSummary { id: string; subject: string; subjectId: string; title: string; courseName: string; date?: string; teacher: string; sectionCount: number; questionCount: number; activeQuestionCount: number; cardCount: number; qrocCount: number; writingCount: number; chapterTitles: string[]; searchText: string }
export interface CurriculumResource { id: string; subject: string; title: string; kind: string; status: string; url?: string; lessonAvailable: boolean; source?: SourceReference }
export interface ExamDefinition { id: string; date: string; start: string | null; end: string | null; subject: string; title: string }
export interface ExamMode { name: string; duration: string | null; ects: number; coefficient: number; points: number; components: { label: string; percent: number | null; type: string | string[]; context: string; responseFormats?: string[] }[] }
export interface CurriculumModalities { schemaVersion: number; revision: string; source: SourceReference; totalPoints: number; definitions: Record<string, string>; note: string; subjectModes: Record<string, ExamMode> }
export interface CurriculumAudit { lessonCount: number; subjectCount: number; resourceCount: number; flashcardCount: number; lessonQuestionCount: number; activeLessonQuestionCount: number; qrocCount: number; writingCount: number; trainingQuestionCount: number; caseCount: number; caseQuestionCount: number; retiredQuestionCount: number; copiedAssetCount: number; activeTrainingQuestionCount: number; diagramCount: number; missingAssets: string[]; invalidQuestions: { id: string; reason: string }[]; notice: string }
export interface CurriculumManifest { schemaVersion: number; revision: string; scope: string; subjects: CurriculumSubject[]; lessons: LessonSummary[]; resources: CurriculumResource[]; exams: ExamDefinition[]; timezone: string; examNotice: string; modalities: CurriculumModalities; audit: CurriculumAudit; trainingSubjectIds: string[]; assetPaths: string[]; visuals: Record<string, LessonFigure>; sourceNotice: string; trainingDisclaimer: string }
export interface Question { id: string; canonicalId?: string; subjectId: string; lessonId?: string; chapterIndex?: number; prompt: string; options: string[]; correct: number[]; explanation: string; format: 'QRU' | 'QRM' | 'QROC' | 'QR'; expected?: string[][]; model?: string; criteria?: string[]; min?: number; source?: SourceReference; retired?: boolean; origin?: string; prob?: number; topic?: string; pages?: string; answer?: string | number | number[]; [key: string]: unknown }
export interface LessonFlashcard { id: string; q: string; a: string; pages: string; topic?: string; chapterIndex?: number; origin?: string; annaleUrl?: string }
export interface LessonFigure { src: string; caption?: string; alt?: string; missing?: boolean; fallbackSrc?: string; visualId?: string; w?: number; h?: number }
export interface LessonParagraphBlock { type: string; title?: string; items?: string[] }
export interface LessonSection { heading: string; pages: string; paragraphs: (string | LessonParagraphBlock)[]; memory: string; figures?: LessonFigure[]; visual?: string }
export interface EssenceSection { heading: string; pages: string; goal: string; logic: string; heuristic: string; examAnchor: string }
export interface CourseLesson { id: string; subject: string; title: string; courseName: string; date?: string; teacher: string; source: SourceReference; editorialNote: string; hook: string; summary: { name: string; detail: string; pages: string }[]; sections: LessonSection[]; flashcards: LessonFlashcard[]; questions: Question[]; qroc: Question[]; writing: Question[]; chapterPractice: { qcm: number[]; cards: number[] }[]; essenceSections: EssenceSection[]; flags: { title: string; detail: string }[]; flow?: string[]; relatedSources?: SourceReference[] }
export interface TrainingCase { id: string; title: string; vignette: string; questions: Question[]; retired?: boolean; source?: SourceReference; lessonId?: string; prob?: number }
export interface TrainingBank { subjectId: string; questions: Question[]; cases: TrainingCase[]; source?: SourceReference; notice?: string; lessonId?: string }

const cache = new Map<string, Promise<unknown>>();
const safeId = /^[a-z0-9][a-z0-9-]{0,119}$/i;
const base = () => import.meta.env.BASE_URL;
async function readJson<T>(path: string): Promise<T> {
  if (!cache.has(path)) {
    const request = fetch(`${base()}curriculum/${path}`).then(async (response) => {
      if (!response.ok) throw new Error('Le contenu n’a pas pu être chargé. Vérifie ta connexion puis réessaie.');
      return response.json() as Promise<T>;
    }).catch((error) => { cache.delete(path); throw error; });
    cache.set(path, request);
  }
  return cache.get(path) as Promise<T>;
}
export function loadCurriculum(): Promise<CurriculumManifest> { return readJson('manifest.json'); }
export function loadLesson(id: string): Promise<CourseLesson> {
  if (!safeId.test(id)) return Promise.reject(new Error('Identifiant de cours invalide.'));
  return readJson(`lessons/${id}.json`);
}
export function loadTraining(subjectId: string): Promise<TrainingBank> {
  if (!safeId.test(subjectId)) return Promise.reject(new Error('Identifiant de matière invalide.'));
  return readJson(`training/${subjectId}.json`);
}
/** Empty string means unsupported/missing-safe path; callers render a placeholder. */
export function assetUrl(path: string): string {
  const cleaned = path.replace(/^\.\//, '').replace(/^curriculum\/assets\//, '');
  if (!cleaned.startsWith('Assets/') || cleaned.includes('..') || /[\\?#\u0000-\u001f]/.test(cleaned)) return '';
  if (!/\.(?:webp|png|jpe?g|svg|woff2|txt)$/i.test(cleaned)) return '';
  return `${base()}curriculum/assets/${cleaned.split('/').map(encodeURIComponent).join('/')}`;
}
export function safeExternalUrl(value?: string): string | undefined {
  if (!value) return undefined;
  try { const parsed = new URL(value); return parsed.protocol === 'https:' && !parsed.username && !parsed.password ? parsed.href : undefined; } catch { return undefined; }
}
export function activeQuestions(questions: Question[]): Question[] { return questions.filter((question) => !question.retired); }
