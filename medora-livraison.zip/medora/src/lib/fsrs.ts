import { createEmptyCard, fsrs, type Card, type Grade } from 'ts-fsrs';
import type { RatingValue, SerializedSchedule } from './types';

// Keep these defaults in step with supabase/functions/submit-review.
const scheduler = fsrs({ request_retention: 0.9, enable_fuzz: false, enable_short_term: true });

export function serializeSchedule(card: Card): SerializedSchedule {
  return {
    ...card,
    due: new Date(card.due).toISOString(),
    last_review: card.last_review ? new Date(card.last_review).toISOString() : undefined,
  };
}

export function deserializeSchedule(card: SerializedSchedule): Card {
  return {
    ...card,
    due: new Date(card.due),
    last_review: card.last_review ? new Date(card.last_review) : undefined,
  };
}

export function newSchedule(now = new Date()): SerializedSchedule {
  return serializeSchedule(createEmptyCard(now));
}

export function scheduleReview(card: SerializedSchedule, rating: RatingValue, now = new Date()) {
  const result = scheduler.repeat(deserializeSchedule(card), now)[rating as Grade];
  return serializeSchedule(result.card);
}

export function ratingPreview(card: SerializedSchedule, now = new Date()) {
  return ([1, 2, 3, 4] as const).map((rating) => ({ rating, schedule: scheduleReview(card, rating, now) }));
}
