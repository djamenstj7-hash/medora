import type { CurriculumManifest, CurriculumSubject, LessonSummary } from './curriculum';
import type { StudyState } from './study';

export interface StudyTask { id: string; type: 'read' | 'practice' | 'recall'; lessonId: string; chapterIndex?: number; subjectId: string; title: string; minutes: number; reason: string }
export interface PlannedExam { id: string; subjectId: string; title: string; date: string; start: string | null; end: string | null; overridden: boolean; archived: boolean; timezone: string }

/** Read-only MED2 statistics view. All events remain in the shared account history. */
export function med2StudyState(state: StudyState): StudyState {
  return { ...state,
    attempts: state.attempts.filter(attempt => !attempt.questionId.startsWith('engine:')),
    sessions: state.sessions.filter(session => !session.lessonId?.startsWith('engine:') && !session.subjectId?.startsWith('engine:')),
  };
}

export function dayInTimezone(date: Date, timezone = 'Europe/Paris'): string {
  const parts = new Intl.DateTimeFormat('en', { timeZone: timezone, year: 'numeric', month: '2-digit', day: '2-digit' }).formatToParts(date);
  return ['year', 'month', 'day'].map((key) => parts.find((part) => part.type === key)?.value).join('-');
}

/** Uses source-local calendar dates, so an exam never jumps a day with the iPhone timezone. */
export function examCalendar(manifest: CurriculumManifest, state: StudyState, now = new Date()): PlannedExam[] {
  const today = dayInTimezone(now, manifest.timezone);
  const known = new Set<string>();
  const result: PlannedExam[] = manifest.exams.map((exam) => {
    const subject = manifest.subjects.find((item) => item.id === exam.subject || item.name === exam.subject);
    const subjectId = subject?.id ?? exam.subject;
    known.add(subjectId);
    const override = state.exams[subjectId];
    const date = override || exam.date;
    // A changed date does not imply that the old official time still applies.
    return { id: exam.id, subjectId, title: exam.title, date, start: override ? null : exam.start, end: override ? null : exam.end, overridden: !!override, archived: date < today, timezone: manifest.timezone };
  });
  for (const subject of manifest.subjects) {
    if (known.has(subject.id) || !state.exams[subject.id]) continue;
    const date = state.exams[subject.id];
    result.push({ id: `personal-${subject.id}`, subjectId: subject.id, title: subject.name, date, start: null, end: null, overridden: true, archived: date < today, timezone: manifest.timezone });
  }
  return result.sort((a, b) => a.date.localeCompare(b.date) || (a.start ?? '').localeCompare(b.start ?? ''));
}
export function upcomingExams(manifest: CurriculumManifest, state: StudyState, now = new Date()): PlannedExam[] { return examCalendar(manifest, state, now).filter((exam) => !exam.archived); }

/** Bounded, evidence-based daily work: rotate subjects, first unread chapters, then weak recall. */
export function buildStudyPlan(lessons: LessonSummary[], subjects: (CurriculumSubject & { coefficient?: number })[], state: StudyState, now = new Date()): StudyTask[] {
  state = med2StudyState(state);
  const budget = Math.max(10, Math.min(480, Math.round(state.settings.dailyMinutes || 90)));
  const today = dayInTimezone(now);
  const tomorrow = new Date(`${today}T12:00:00Z`); tomorrow.setUTCDate(tomorrow.getUTCDate() + 1);
  const tomorrowKey = tomorrow.toISOString().slice(0, 10);
  const latest = new Map<string, StudyState['attempts'][number]>();
  for (const attempt of state.attempts) {
    const previous = latest.get(attempt.questionId);
    if (!previous || attempt.createdAt > previous.createdAt) latest.set(attempt.questionId, attempt);
  }
  const buckets = subjects.map((subject) => {
    const own = lessons.filter((lesson) => lesson.subjectId === subject.id);
    const weak = [...latest.values()].filter((attempt) => attempt.subjectId === subject.id && !attempt.correct && attempt.lessonId);
    const unread = own.filter((lesson) => (state.read[lesson.id] || []).filter((index) => index < lesson.sectionCount).length < lesson.sectionCount);
    const exam = state.exams[subject.id] || subject.date;
    const upcoming = !!exam && exam >= today;
    const lastDay = exam === today || exam === tomorrowKey;
    const queues: StudyTask[] = [];
    for (const lesson of own.filter((lesson) => weak.some((attempt) => attempt.lessonId === lesson.id))) queues.push({ id: `practice-${lesson.id}`, type: 'practice', lessonId: lesson.id, subjectId: subject.id, title: lesson.title, minutes: 10, reason: 'Dernière réponse incorrecte : rappel ciblé et correction.' });
    for (const lesson of own.filter((item) => !unread.includes(item) && !state.attempts.some((attempt) => attempt.lessonId === item.id))) queues.push({ id: `consolidate-${lesson.id}`, type: 'practice', lessonId: lesson.id, subjectId: subject.id, title: lesson.title, minutes: 10, reason: 'Cours lu : consolider avec un premier rappel actif.' });
    for (const lesson of unread) {
      const chapterIndex = Array.from({ length: lesson.sectionCount }, (_, index) => index).find((index) => !(state.read[lesson.id] || []).includes(index));
      if (chapterIndex !== undefined) queues.push({ id: `read-${lesson.id}-${chapterIndex}`, type: lastDay ? 'recall' : 'read', lessonId: lesson.id, subjectId: subject.id, chapterIndex, title: `${lesson.title} · ${lesson.chapterTitles[chapterIndex] || `chapitre ${chapterIndex + 1}`}`, minutes: lastDay ? 10 : 15, reason: lastDay ? `${exam === today ? 'Jour J' : 'Veille d’examen'} : rappel court puis vérification ; chapitre encore non marqué comme lu.` : 'Prochain chapitre non marqué comme lu.' });
    }
    if (!queues.length && own.length) {
      const lesson = own.find((item) => !state.attempts.some((attempt) => attempt.lessonId === item.id && dayInTimezone(new Date(attempt.createdAt)) === today)) ?? own[0];
      queues.push({ id: `recall-${lesson.id}`, type: 'recall', lessonId: lesson.id, subjectId: subject.id, title: lesson.title, minutes: 10, reason: 'Tour de rappel : expliquer sans regarder, puis vérifier.' });
    }
    const coefficient = Number.isFinite(subject.coefficient) ? Math.max(0, Math.min(10, subject.coefficient!)) : 1;
    return { id: subject.id, queues, priority: weak.length * 2 + (upcoming ? 3 : 0) + coefficient, exam: upcoming ? exam! : null };
  }).filter((bucket) => bucket.queues.length).sort((a, b) => b.priority - a.priority || a.id.localeCompare(b.id));
  const result: StudyTask[] = [];
  function allocate(group: typeof buckets, available: number) {
    let remaining = available;
    // One task per subject each round; avoids dedicating a whole session to a single matter.
    while (remaining >= 5 && group.some((bucket) => bucket.queues.length)) {
      for (const bucket of group) {
        if (remaining < 5) break;
        const task = bucket.queues.shift();
        if (!task) continue;
        const minutes = Math.min(task.minutes, remaining);
        result.push({ ...task, minutes });
        remaining -= minutes;
      }
    }
    return remaining;
  }
  const nearestDate = buckets.map((bucket) => bucket.exam).filter((date): date is string => !!date).sort()[0];
  const foreground = nearestDate ? buckets.filter((bucket) => bucket.exam === nearestDate) : buckets;
  const background = nearestDate ? buckets.filter((bucket) => bucket.exam !== nearestDate) : [];
  const reserve = background.length ? Math.min(Math.max(0, state.settings.backgroundMinutes || 0), Math.floor(budget / 2)) : 0;
  // Rotate later subjects across calendar days instead of always choosing the first one.
  if (background.length) { const shift = Math.floor(Date.parse(`${today}T12:00:00Z`) / 86400000) % background.length; background.push(...background.splice(0, shift)); }
  const unusedMain = allocate(foreground, budget - reserve);
  const unusedBackground = allocate(background, reserve + unusedMain);
  if (unusedBackground >= 5) allocate(foreground, unusedBackground);
  return result;
}

export function latestQuestionAttempts(state: StudyState) {
  const result = new Map<string, StudyState['attempts'][number]>();
  for (const attempt of state.attempts) if (!attempt.questionId.startsWith('engine:') && (!result.has(attempt.questionId) || result.get(attempt.questionId)!.createdAt < attempt.createdAt)) result.set(attempt.questionId, attempt);
  return result;
}
