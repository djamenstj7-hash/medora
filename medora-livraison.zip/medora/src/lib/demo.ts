import { newSchedule } from './fsrs';
import type { CachedLibrary } from './persistence';
import type { StudyCard } from './types';

/** Built-in examples are labelled as demonstration content in the interface. */
export function createDemoLibrary(): CachedLibrary {
  const now = new Date();
  const created_at = now.toISOString();
  const decks = [
    { id: 'demo-cardio', title: 'Cardiologie clinique', subject: 'Cardiologie', color: '#e77869', created_at },
    { id: 'demo-neuro', title: 'Les bases de la sémiologie', subject: 'Neurologie', color: '#8e87c4', created_at },
    { id: 'demo-pharma', title: 'Pharmacologie essentielle', subject: 'Pharmacologie', color: '#5c9c8b', created_at },
  ];
  const examples: Array<Pick<StudyCard, 'deck_id' | 'kind' | 'prompt' | 'answer' | 'explanation'> & Partial<StudyCard>> = [
    { deck_id: 'demo-cardio', kind: 'qcm', prompt: 'Une douleur thoracique constrictive irradiant vers le bras gauche évoque en priorité…', options: [{ id: 'a', text: 'Un syndrome coronarien aigu' }, { id: 'b', text: 'Une douleur pariétale isolée' }, { id: 'c', text: 'Un reflux certain sans bilan' }, { id: 'd', text: 'Une cause exclusivement anxieuse' }], correct_option_id: 'a', answer: 'Un syndrome coronarien aigu doit être recherché en priorité.', explanation: 'Cette description est évocatrice, mais ne suffit pas au diagnostic. L’évaluation repose notamment sur le contexte clinique, l’ECG et la troponine. Une douleur thoracique aiguë nécessite une évaluation médicale urgente.' },
    { deck_id: 'demo-cardio', kind: 'flashcard', prompt: 'Pourquoi une insuffisance cardiaque gauche peut-elle provoquer une dyspnée ?', answer: 'L’élévation des pressions de remplissage gauches se transmet à la circulation pulmonaire et favorise la congestion.', explanation: 'La congestion interstitielle puis alvéolaire altère les échanges gazeux. L’orthopnée peut accompagner cette augmentation des pressions pulmonaires.' },
    { deck_id: 'demo-cardio', kind: 'case', prompt: 'Un patient présente une dyspnée aggravée en décubitus et des crépitants bilatéraux. Quel mécanisme relie ces deux signes ?', answer: 'Une congestion pulmonaire liée à une augmentation des pressions de remplissage gauches.', explanation: 'Le décubitus favorise le retour veineux et peut majorer la congestion. Ces signes orientent, mais ne prouvent pas à eux seuls une insuffisance cardiaque.' },
    { deck_id: 'demo-cardio', kind: 'flashcard', prompt: 'Quelle distinction fait-on entre précharge et postcharge ?', answer: 'La précharge reflète l’étirement myocardique en fin de diastole ; la postcharge correspond aux contraintes s’opposant à l’éjection ventriculaire.', explanation: 'La pression artérielle contribue à la postcharge du ventricule gauche. Ces notions décrivent des mécanismes et ne sont pas des mesures interchangeables.' },
    { deck_id: 'demo-neuro', kind: 'flashcard', prompt: 'Quels signes orientent vers un syndrome pyramidal constitué ?', answer: 'Déficit moteur, hyperréflexie ostéotendineuse, spasticité et signe de Babinski.', explanation: 'L’expression dépend de la localisation et du délai d’évolution. Une lésion aiguë peut initialement donner une hypotonie.' },
    { deck_id: 'demo-neuro', kind: 'case', prompt: 'Une faiblesse brutale d’un hémicorps s’accompagne d’un trouble du langage. Quelle priorité clinique retenir ?', answer: 'Évoquer un accident vasculaire cérébral et déclencher une évaluation urgente.', explanation: 'L’heure de début des symptômes, la glycémie et l’imagerie cérébrale font partie de l’évaluation. La latéralisation précise nécessite l’examen clinique.' },
    { deck_id: 'demo-neuro', kind: 'qcm', prompt: 'Quelle description correspond le mieux à une aphasie ?', options: [{ id: 'a', text: 'Un trouble acquis du langage' }, { id: 'b', text: 'Une faiblesse des muscles articulatoires uniquement' }, { id: 'c', text: 'Une perte auditive systématique' }], correct_option_id: 'a', answer: 'Un trouble acquis du langage.', explanation: 'L’aphasie peut toucher l’expression et/ou la compréhension du langage. Elle se distingue de la dysarthrie, qui concerne la réalisation motrice de la parole.' },
    { deck_id: 'demo-neuro', kind: 'flashcard', prompt: 'Quel principe guide la localisation d’une lésion neurologique ?', answer: 'Relier l’ensemble des signes cliniques aux voies et structures anatomiques pouvant les expliquer.', explanation: 'Le raisonnement topographique précède l’hypothèse étiologique. Un signe isolé doit être interprété dans le contexte de l’examen.' },
    { deck_id: 'demo-pharma', kind: 'flashcard', prompt: 'Quel est le mécanisme d’action des inhibiteurs de l’enzyme de conversion ?', answer: 'Ils diminuent la formation d’angiotensine II et réduisent la dégradation de la bradykinine.', explanation: 'La baisse d’angiotensine II contribue à la vasodilatation et à la diminution de la sécrétion d’aldostérone. La bradykinine peut contribuer à la toux.' },
    { deck_id: 'demo-pharma', kind: 'qcm', prompt: 'Quel paramètre fait partie de la surveillance habituelle d’un traitement par IEC ?', options: [{ id: 'a', text: 'Kaliémie et fonction rénale' }, { id: 'b', text: 'Acuité visuelle uniquement' }, { id: 'c', text: 'Calcémie exclusivement' }], correct_option_id: 'a', answer: 'La kaliémie et la fonction rénale.', explanation: 'Les IEC peuvent favoriser une hyperkaliémie et modifier la fonction rénale. La surveillance dépend du patient, du contexte et des recommandations.' },
    { deck_id: 'demo-pharma', kind: 'flashcard', prompt: 'Quelle différence existe entre effet indésirable et contre-indication ?', answer: 'Un effet indésirable est un effet nocif possible du médicament ; une contre-indication désigne une situation où son utilisation est proscrite selon les conditions définies.', explanation: 'Le risque d’un effet indésirable n’implique pas systématiquement une contre-indication. La décision dépend du rapport bénéfice-risque et des recommandations.' },
    { deck_id: 'demo-pharma', kind: 'case', prompt: 'Un étudiant confond la demi-vie d’élimination avec la durée d’effet. Comment corriger cette idée ?', answer: 'La demi-vie décrit la décroissance de la concentration ; la durée d’effet dépend aussi de la pharmacodynamie et peut être différente.', explanation: 'Les métabolites actifs, la liaison à la cible et les réponses biologiques contribuent à cette différence. L’équivalence entre ces deux durées n’est pas générale.' },
  ];
  const cards: StudyCard[] = examples.map((example, index) => ({
    id: `demo-card-${index + 1}`,
    options: [],
    correct_option_id: null,
    status: 'active',
    source_excerpt: 'Exemple pédagogique intégré au mode démonstration. À vérifier avec vos références de cours.',
    schedule: newSchedule(index >= 9 ? new Date(now.getTime() + 86_400_000) : now),
    version: 0,
    created_at,
    ...example,
  }));
  return { decks, cards, reviews: [], pending: [] };
}
