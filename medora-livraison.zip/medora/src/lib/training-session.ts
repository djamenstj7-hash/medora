import type { Question, TrainingBank } from './curriculum';
export interface TrainingItem { question: Question; caseId?: string; caseTitle?: string; vignette?: string }
export interface SavedTrainingAnswer { selected: number[]; correct: boolean; responseText?: string; attemptId: string; durationSeconds: number }
export interface TrainingSession {
  kind: 'medora-curriculum-training'; id: string; mode: 'practice' | 'exam'; bank: 'qi' | 'cases' | 'mixed'; subjectIds: string[];
  questionIds: string[]; answers: Record<string, SavedTrainingAnswer>; index: number; startedAt: string;
  elapsedMs: number; runningSince: number | null; questionStartedMs: number; limitSeconds: number | null; finishedAt?: string;
}
/** Fisher-Yates: each position has an equal chance, unlike sort(() => random()-.5). */
export function shuffled<T>(input: T[], random: () => number = Math.random): T[] {
  const copy = [...input];
  for (let i = copy.length - 1; i > 0; i--) { const j = Math.floor(random() * (i + 1)); [copy[i], copy[j]] = [copy[j], copy[i]]; }
  return copy;
}
export function sampleTraining(banks: TrainingBank[], options: { bank: 'qi' | 'cases' | 'mixed'; format: 'all' | 'QRU' | 'QRM'; count: number; weakIds?: Set<string>; caseFraction?: number }, random: () => number = Math.random): TrainingItem[] {
  const compatible = (question: Question) => !question.retired && ['QRU', 'QRM'].includes(question.format) && question.options.length > 1 && question.correct.length > 0 && (options.format === 'all' || question.format === options.format);
  const groups: TrainingItem[][] = [];
  for (const bank of banks) {
    if (options.bank !== 'cases') for (const question of bank.questions.filter(compatible)) groups.push([{ question }]);
    if (options.bank !== 'qi') for (const clinicalCase of bank.cases.filter((item) => !item.retired)) {
      const active = clinicalCase.questions.filter((question) => !question.retired);
      // A format filter must not remove an earlier question that a later clinical step relies on.
      if (active.some((question) => !compatible(question))) continue;
      const items = active.map((question) => ({ question, caseId: clinicalCase.id, caseTitle: clinicalCase.title, vignette: clinicalCase.vignette }));
      if (items.length) groups.push(items);
    }
  }
  let candidates = shuffled(groups, random);
  if (options.weakIds) candidates = candidates.filter((items) => items.some((item) => options.weakIds!.has(typeof item.question.canonicalId === 'string' ? item.question.canonicalId : item.question.id)));
  if (options.bank === 'mixed' && options.caseFraction !== undefined && !options.weakIds) {
    const caseBudget = Math.round(options.count * Math.max(0, Math.min(1, options.caseFraction)));
    const cases = candidates.filter((group) => !!group[0].caseId);
    const singles = candidates.filter((group) => !group[0].caseId);
    const grouped: TrainingItem[][] = [];
    let used = 0;
    for (const clinicalCase of cases) if (used + clinicalCase.length <= caseBudget) { grouped.push(clinicalCase); used += clinicalCase.length; }
    for (const single of singles) if (used < options.count) { grouped.push(single); used++; }
    // Entire clinical dossiers may leave fewer items than the requested ceiling.
    candidates = shuffled(grouped, random);
  }
  const chosen: TrainingItem[] = [];
  const seen = new Set<string>();
  for (const group of candidates) {
    // Never split a clinical case or scramble its linked questions.
    const fresh = group.filter((item) => !seen.has(item.question.id));
    if (!fresh.length || fresh.length > options.count - chosen.length) continue;
    chosen.push(...fresh);
    fresh.forEach((item) => seen.add(item.question.id));
    if (chosen.length === options.count) break;
  }
  return chosen;
}
export function restoreTrainingItems(banks: TrainingBank[], ids: string[]): TrainingItem[] {
  const lookup = new Map<string, TrainingItem>();
  for (const bank of banks) {
    for (const question of bank.questions) lookup.set(question.id, { question });
    for (const clinicalCase of bank.cases) for (const question of clinicalCase.questions) lookup.set(question.id, { question, caseId: clinicalCase.id, caseTitle: clinicalCase.title, vignette: clinicalCase.vignette });
  }
  return ids.map((id) => lookup.get(id)).filter((item): item is TrainingItem => !!item);
}
export function elapsedMilliseconds(session: Pick<TrainingSession, 'elapsedMs' | 'runningSince'>, now = Date.now()): number {
  return Math.max(0, session.elapsedMs + (session.runningSince === null ? 0 : Math.max(0, now - session.runningSince)));
}
export function pausedSession(session: TrainingSession, now = Date.now()): TrainingSession { return { ...session, elapsedMs: elapsedMilliseconds(session, now), runningSince: null }; }
export function isTrainingSession(value: unknown): value is TrainingSession {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return false;
  const item = value as Partial<TrainingSession>;
  const finite = (number: unknown, max: number) => typeof number === 'number' && Number.isFinite(number) && number >= 0 && number <= max;
  const identifier = (id: unknown): id is string => typeof id === 'string' && id.length > 0 && id.length <= 200 && !['__proto__', 'prototype', 'constructor'].includes(id);
  if (!(item.kind === 'medora-curriculum-training' && identifier(item.id) && ['practice', 'exam'].includes(String(item.mode)) && ['qi', 'cases', 'mixed'].includes(String(item.bank))
    && Array.isArray(item.questionIds) && item.questionIds.length > 0 && item.questionIds.length <= 100 && item.questionIds.every(identifier) && new Set(item.questionIds).size === item.questionIds.length
    && Array.isArray(item.subjectIds) && item.subjectIds.length > 0 && item.subjectIds.length <= 30 && item.subjectIds.every((id) => typeof id === 'string' && /^[a-z0-9][a-z0-9-]{0,119}$/i.test(id))
    && item.answers && typeof item.answers === 'object' && !Array.isArray(item.answers)
    && Number.isInteger(item.index) && finite(item.index, item.questionIds.length - 1)
    && finite(item.elapsedMs, 7 * 86400 * 1000) && finite(item.questionStartedMs, 7 * 86400 * 1000)
    && (item.runningSince === null || finite(item.runningSince, Number.MAX_SAFE_INTEGER))
    && (item.limitSeconds === null || typeof item.limitSeconds === 'number' && item.limitSeconds > 0 && item.limitSeconds <= 86400)
    && typeof item.startedAt === 'string' && Number.isFinite(Date.parse(item.startedAt))
    && (item.finishedAt === undefined || typeof item.finishedAt === 'string' && Number.isFinite(Date.parse(item.finishedAt))))) return false;
  return Object.entries(item.answers).every(([questionId, answer]) => item.questionIds!.includes(questionId) && answer && typeof answer === 'object' && typeof answer.correct === 'boolean'
    && Array.isArray(answer.selected) && answer.selected.length <= 100 && answer.selected.every((number) => Number.isInteger(number) && number >= 0 && number <= 999)
    && identifier(answer.attemptId) && finite(answer.durationSeconds, 86400) && (answer.responseText === undefined || typeof answer.responseText === 'string' && answer.responseText.length <= 40000));
}
