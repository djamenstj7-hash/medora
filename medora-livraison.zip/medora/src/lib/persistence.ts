import { createStore, del, get, set } from 'idb-keyval';
import type { LibraryData, PendingReview } from './types';

export interface CachedLibrary extends LibraryData { pending: PendingReview[] }
const db = createStore('medora-private-v1', 'library');
const key = (scope: string) => `library:${scope}`;

export const persistence = {
  read(scope: string) { return get<CachedLibrary>(key(scope), db); },
  write(scope: string, value: CachedLibrary) { return set(key(scope), value, db); },
  clear(scope: string) { return del(key(scope), db); },
};

/** A retransmitted event never enters the local queue twice. */
export function enqueueReview(pending: PendingReview[], event: PendingReview): PendingReview[] {
  return pending.some((item) => item.client_event_id === event.client_event_id) ? pending : [...pending, event];
}
