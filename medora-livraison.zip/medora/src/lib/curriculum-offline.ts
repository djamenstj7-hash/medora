import { assetUrl, loadCurriculum } from './curriculum';

// Shared with the static-only runtime routes in vite.config.ts.
export const CURRICULUM_CACHE = 'medora-curriculum-v2';
export interface OfflineProgress { completed: number; total: number; failed: number; phase: string }
export interface OfflineResult { completed: number; total: number; failed: string[] }

export async function curriculumCacheStatus() {
  if (!('caches' in window)) return { supported: false, files: 0 };
  return { supported: true, files: (await (await caches.open(CURRICULUM_CACHE)).keys()).length };
}

/** Only the bundled, public curriculum is cached; no session, personal data or AI response. */
export async function downloadCurriculum(onProgress: (progress: OfflineProgress) => void, signal?: AbortSignal): Promise<OfflineResult> {
  if (!('caches' in window)) throw new Error('Le téléchargement hors connexion nécessite Safari en HTTPS.');
  const manifest = await loadCurriculum();
  const base = new URL(import.meta.env.BASE_URL, location.origin);
  const urls = [
    new URL('curriculum/manifest.json', base).href,
    ...manifest.lessons.map(lesson => new URL(`curriculum/lessons/${encodeURIComponent(lesson.id)}.json`, base).href),
    ...manifest.trainingSubjectIds.map(id => new URL(`curriculum/training/${encodeURIComponent(id)}.json`, base).href),
    ...(manifest.assetPaths || []).filter(path => !path.endsWith('.txt')).map(path => new URL(assetUrl(path), location.origin).href),
  ];
  const unique = [...new Set(urls)].filter(url => new URL(url).origin === location.origin);
  const cache = await caches.open(CURRICULUM_CACHE);
  const failed: string[] = []; let completed = 0;
  onProgress({ completed, total: unique.length, failed: 0, phase: 'Téléchargement des cours et illustrations' });
  // Sequential requests keep memory and network usage bounded on iPhone.
  for (const url of unique) {
    if (signal?.aborted) throw new DOMException('Téléchargement interrompu. Les fichiers déjà enregistrés restent disponibles.', 'AbortError');
    try {
      if (!await cache.match(url)) {
        const response = await fetch(url, { signal });
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        await cache.put(url, response.clone());
      }
      completed++;
    } catch (error) {
      if (signal?.aborted) throw error;
      failed.push(new URL(url).pathname);
    }
    onProgress({ completed, total: unique.length, failed: failed.length, phase: 'Téléchargement des cours et illustrations' });
  }
  return { completed, total: unique.length, failed };
}

export async function protectLocalStorage(): Promise<boolean> {
  return navigator.storage?.persist ? navigator.storage.persist() : false;
}
