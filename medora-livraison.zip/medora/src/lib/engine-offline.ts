import { engineAssetUrl, loadEngineManifest } from './engine';
import type { OfflineProgress, OfflineResult } from './curriculum-offline';

export const ENGINE_CACHE = 'medora-engine-v3';
export async function engineCacheStatus() {
  return { files: 'caches' in window ? (await (await caches.open(ENGINE_CACHE)).keys()).length : 0 };
}

/** Cache only the public files enumerated by the bundled programme. */
export async function downloadEngine(onProgress: (value: OfflineProgress) => void, signal?: AbortSignal): Promise<OfflineResult> {
  if (!('caches' in window)) throw new Error('Le téléchargement hors connexion nécessite Safari en HTTPS.');
  const manifest = await loadEngineManifest();
  const urls = [...new Set(['manifest.json', ...manifest.files].map(path => engineAssetUrl(path)).filter(Boolean).map(path => new URL(path, location.origin).href))].filter(url => new URL(url).origin === location.origin);
  const cache = await caches.open(ENGINE_CACHE), failed: string[] = [];
  let completed = 0;
  const progress = () => onProgress({ completed, total: urls.length, failed: failed.length, phase: 'Téléchargement de MED_ENGINE' });
  progress();
  for (const url of urls) {
    if (signal?.aborted) throw new DOMException('Téléchargement interrompu. Les fichiers déjà enregistrés restent disponibles.', 'AbortError');
    try {
      if (!await cache.match(url)) {
        const response = await fetch(url, { signal });
        if (!response.ok) throw new Error('HTTP ' + response.status);
        await cache.put(url, response.clone());
      }
      completed++;
    } catch (error) { if (signal?.aborted) throw error; failed.push(new URL(url).pathname); }
    progress();
  }
  return { completed, total: urls.length, failed };
}
