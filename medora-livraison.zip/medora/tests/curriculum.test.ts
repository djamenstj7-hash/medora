import { readFileSync, existsSync } from 'node:fs';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { activeQuestions, assetUrl, loadCurriculum, loadLesson, loadTraining, safeExternalUrl } from '../src/lib/curriculum';
import type { CourseLesson, CurriculumManifest, Question, TrainingBank } from '../src/lib/curriculum';

const root = new URL('../public/curriculum/', import.meta.url);
const json = <T>(path: string): T => JSON.parse(readFileSync(new URL(path, root), 'utf8')) as T;
const manifest = json<CurriculumManifest>('manifest.json');
const lessons = manifest.lessons.map((summary) => json<CourseLesson>(`lessons/${summary.id}.json`));
const banks = manifest.trainingSubjectIds.map((subject) => json<TrainingBank>(`training/${subject}.json`));
const lessonQuestions = lessons.flatMap((lesson) => lesson.questions);
const qroc = lessons.flatMap((lesson) => lesson.qroc);
const writing = lessons.flatMap((lesson) => lesson.writing);
const trainingQuestions = banks.flatMap((bank) => bank.questions);
const caseQuestions = banks.flatMap((bank) => bank.cases.flatMap((item) => item.questions));
const questions = [...lessonQuestions, ...qroc, ...writing, ...trainingQuestions, ...caseQuestions];

afterEach(() => { vi.unstubAllGlobals(); });

describe('MED2 content preservation', () => {
  it('keeps all original lessons, banks, written exercises and catalogue references', () => {
    expect(manifest.subjects).toHaveLength(14);
    expect(lessons).toHaveLength(69);
    expect(manifest.resources).toHaveLength(115);
    expect(manifest.exams).toHaveLength(14);
    expect(manifest.timezone).toBe('Europe/Paris');
    expect(lessons.reduce((sum, lesson) => sum + lesson.sections.length, 0)).toBe(484);
    expect(lessons.reduce((sum, lesson) => sum + lesson.flashcards.length, 0)).toBe(1764);
    expect(lessonQuestions).toHaveLength(3964);
    expect(activeQuestions(lessonQuestions)).toHaveLength(2307);
    expect(qroc).toHaveLength(897);
    expect(writing).toHaveLength(51);
    expect(banks).toHaveLength(8);
    expect(trainingQuestions).toHaveLength(1629);
    expect(banks.reduce((sum, bank) => sum + bank.cases.length, 0)).toBe(105);
    expect(caseQuestions).toHaveLength(367);
    expect(manifest.audit.invalidQuestions).toEqual([]);
    expect(manifest.resources.filter((resource) => resource.lessonAvailable)).toHaveLength(69);
    // The source only contains 480 essence sections for 484 narrative chapters.
    expect(lessons.reduce((sum, lesson) => sum + lesson.essenceSections.length, 0)).toBe(480);
  });

  it('has unique stable question identifiers and structurally valid corrections', () => {
    expect(new Set(questions.map((question) => question.id)).size).toBe(questions.length);
    const invalid: string[] = [];
    for (const question of questions) {
      if (!question.prompt || !manifest.subjects.some((subject) => subject.id === question.subjectId)) invalid.push(question.id);
      if (question.format === 'QRU' || question.format === 'QRM') {
        if (!question.correct.length || question.correct.some((index) => !Number.isInteger(index) || index < 0 || index >= question.options.length)) invalid.push(question.id);
        if (question.format === 'QRU' && question.correct.length !== 1) invalid.push(question.id);
      }
    }
    expect(invalid).toEqual([]);
  });

  it('preserves retired items but excludes them from selectable practice', () => {
    const retired = questions.filter((question) => question.retired);
    expect(retired.length).toBe(manifest.audit.retiredQuestionCount);
    expect(retired.length).toBeGreaterThan(0);
    expect(activeQuestions(questions).some((question) => question.retired)).toBe(false);
    for (const bank of banks) {
      for (const item of bank.cases.filter((entry) => entry.retired)) {
        expect(item.questions.every((question) => question.retired)).toBe(true);
      }
    }
  });

  it('retains chapter associations and canonical bank identifiers without fabricated lessons', () => {
    const ids = new Set(lessons.map((lesson) => lesson.id));
    const canonical = new Set([...trainingQuestions, ...caseQuestions].map((question) => question.canonicalId));
    let linked = 0;
    for (const lesson of lessons) {
      lesson.chapterPractice.forEach((chapter) => {
        expect(chapter.qcm.every((index) => index >= 0 && index < lesson.questions.length)).toBe(true);
        expect(chapter.cards.every((index) => index >= 0 && index < lesson.flashcards.length)).toBe(true);
      });
      for (const question of lesson.questions) {
        if (question.bankId) {
          linked += 1;
          expect(canonical.has(question.canonicalId)).toBe(true);
        }
      }
    }
    expect(linked).toBe(1272);
    expect(questions.filter((question) => question.lessonId && !ids.has(question.lessonId)).map((question) => question.id)).toEqual([]);
  });

  it('keeps available figures and explicitly reports missing source assets', () => {
    const missing = new Set(manifest.audit.missingAssets);
    const invalid: string[] = [];
    for (const lesson of lessons) for (const section of lesson.sections) for (const figure of section.figures ?? []) {
      const available = existsSync(new URL(`assets/${figure.src}`, root));
      if (!available && (!figure.missing || !missing.has(figure.src))) invalid.push(figure.src);
      if (figure.missing && available) invalid.push(figure.src);
      if (figure.fallbackSrc && !existsSync(new URL(`assets/${figure.fallbackSrc}`, root))) invalid.push(figure.fallbackSrc);
    }
    expect(invalid).toEqual([]);
    expect(Object.keys(manifest.visuals)).toHaveLength(26);
    expect(manifest.audit.diagramCount).toBe(15);
  });
});

describe('static curriculum security and loading', () => {
  it('permits only local curriculum assets and HTTPS source URLs', () => {
    expect(assetUrl('Assets/photos/IMM-12.webp')).toContain('curriculum/assets/Assets/photos/IMM-12.webp');
    expect(assetUrl('Assets/diagrams/rbc.svg')).toContain('curriculum/assets/Assets/diagrams/rbc.svg');
    for (const bad of ['https://evil.test/x.svg', '../Assets/x.webp', 'Assets/../index.html', 'Assets\\x.webp', 'Assets/x.svg?x=1', 'Assets/test.html', 'Assets/x.svg#id']) expect(assetUrl(bad)).toBe('');
    expect(safeExternalUrl('https://drive.google.com/file/d/example/view')).toBe('https://drive.google.com/file/d/example/view');
    for (const bad of ['javascript:alert(1)', 'data:text/html,a', 'http://example.test', 'https://user:secret@example.test/', '//example.test']) expect(safeExternalUrl(bad)).toBeUndefined();
  });

  it('loads metadata separately and caches concurrent requests', async () => {
    const request = vi.fn().mockResolvedValue({ ok: true, json: async () => manifest });
    vi.stubGlobal('fetch', request);
    const [first, second] = await Promise.all([loadCurriculum(), loadCurriculum()]);
    expect(first).toEqual(manifest);
    expect(second).toEqual(first);
    expect(request).toHaveBeenCalledTimes(1);
    expect(request.mock.calls[0][0]).toMatch(/curriculum\/manifest.json$/);
  });

  it('retries failed lesson loads and rejects traversal before making network requests', async () => {
    const request = vi.fn().mockResolvedValueOnce({ ok: false }).mockResolvedValueOnce({ ok: true, json: async () => lessons[0] });
    vi.stubGlobal('fetch', request);
    await expect(loadLesson(lessons[0].id)).rejects.toThrow('contenu');
    await expect(loadLesson(lessons[0].id)).resolves.toEqual(lessons[0]);
    await expect(loadLesson('../secrets')).rejects.toThrow('Identifiant');
    await expect(loadTraining('sang/../../secrets')).rejects.toThrow('Identifiant');
    expect(request).toHaveBeenCalledTimes(2);
  });
});
