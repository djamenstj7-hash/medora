import { describe, expect, it } from 'vitest';
import { classifyProviderError } from '../supabase/functions/_shared/ai-errors';

describe('safe OpenAI error classification', () => {
  it.each([
    [401, 'AI_KEY_INVALID', 'OPENAI_API_KEY'],
    [403, 'AI_PERMISSIONS', 'autorisations'],
    [404, 'AI_MODEL', 'OPENAI_MODEL'],
  ])('identifies provider HTTP %i without expiring the Medora session', (status, expectedCode, actionableText) => {
    const error = classifyProviderError(status as number);
    expect(error.status).toBe(503);
    expect(error.code).toBe(expectedCode);
    expect(error.message).toContain(actionableText);
  });

  it.each(['insufficient_quota', 'billing_hard_limit_reached'])('explains API billing for %s instead of recommending a blind retry', (code) => {
    const error = classifyProviderError(429, code);
    expect(error).toMatchObject({ status: 503, code: 'AI_QUOTA' });
    expect(error.message).toContain('crédits');
    expect(error.message).toContain('plafond de facturation');
    expect(error.message).toContain('ChatGPT ne couvre pas l’API');
    expect(error.message).not.toContain('temporaire');
  });

  it('distinguishes temporary rate limits from billing quota exhaustion', () => {
    const error = classifyProviderError(429, 'rate_limit_exceeded');
    expect(error).toMatchObject({ status: 429, code: 'AI_RATE_LIMIT' });
    expect(error.message).toContain('temporaire');
    expect(error.message).not.toContain('ChatGPT');
  });

  it.each([undefined, 'new_provider_code', 'insufficient_quota-with-private-details'])('does not guess the cause of an unrecognized HTTP 429 code (%s)', (code) => {
    const error = classifyProviderError(429, code);
    expect(error).toMatchObject({ status: 429, code: 'AI_LIMIT' });
    expect(error.message).not.toContain('temporaire');
    expect(error.message).not.toContain('épuisé');
  });

  it.each([408, 504])('keeps HTTP %i timeouts separate from provider outages', (status) => {
    expect(classifyProviderError(status)).toMatchObject({ status: 504, code: 'AI_TIMEOUT' });
  });

  it.each([400, 422])('makes HTTP %i incompatible generation parameters actionable', (status) => {
    const error = classifyProviderError(status, 'unsupported_parameter');
    expect(error).toMatchObject({ status: 502, code: 'AI_REQUEST' });
    expect(error.message).toContain('modèle configuré');
    expect(error.message).toContain('réponses structurées');
  });

  it.each([500, 502, 503, 599])('reports HTTP %i as a provider outage', (status) => {
    expect(classifyProviderError(status)).toMatchObject({ status: 502, code: 'AI_PROVIDER' });
  });

  it('requires a matching status before attributing an error to billing', () => {
    expect(classifyProviderError(500, 'insufficient_quota').code).toBe('AI_PROVIDER');
    expect(classifyProviderError(400, 'insufficient_quota').code).toBe('AI_REQUEST');
  });

  it.each([0, 200, 418, 499, 600, Number.NaN])('handles unexpected status %s without leaking arbitrary provider text', (status) => {
    const privateText = 'sk-private-key; student clinical notes';
    const error = classifyProviderError(status, privateText);
    expect(error).toMatchObject({ status: 502, code: 'AI_PROVIDER' });
    expect(JSON.stringify(error)).not.toContain(privateText);
    expect(error.message).not.toContain('temporaire');
  });
});
