"""Offline checks for the iPhone archive installer, without GitHub/Supabase."""

from __future__ import annotations

import hashlib
import importlib.util
import json
from pathlib import Path
import stat
import tempfile
import unittest
import zipfile


SCRIPT = Path(__file__).parents[1] / "docs" / "iphone" / "extract-engine-parts.py"
SPEC = importlib.util.spec_from_file_location("delivery_parts", SCRIPT)
assert SPEC is not None and SPEC.loader is not None
INSTALLER = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(INSTALLER)


class DeliveryPartsTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.source = self.root / "source"
        (self.source / "medora").mkdir(parents=True)
        self.archives = self.root / "archives"
        self.archives.mkdir()
        self.parts = []

    def bundle(self, name, entries):
        target = self.archives / name
        with zipfile.ZipFile(target, "w") as archive:
            for path, content in entries:
                archive.writestr(path, content)
        record = {"file": name, "sha256": hashlib.sha256(target.read_bytes()).hexdigest()}
        self.parts.append(record)
        return target

    def install(self):
        (self.source / "medora" / "delivery-files.json").write_text(json.dumps({"parts": self.parts}))
        return INSTALLER.extract_parts(self.source, self.archives)

    def test_merges_all_verified_parts_without_changing_existing_source(self):
        core = self.source / "medora" / "package.json"
        core.write_text("existing application")
        self.bundle("medora-contenus-engine-1.zip", [("medora/public/engine/a.svg", "illustration A")])
        self.bundle("medora-contenus-engine-2.zip", [("medora/public/engine/b.png", b"illustration B")])
        self.assertEqual(self.install(), 2)
        self.assertEqual(core.read_text(), "existing application")
        self.assertEqual((self.source / "medora/public/engine/b.png").read_bytes(), b"illustration B")

    def test_missing_later_part_stops_before_any_content_is_written(self):
        self.bundle("medora-contenus-engine-1.zip", [("medora/a.txt", "A")])
        self.parts.append({"file": "medora-contenus-engine-2.zip", "sha256": "0" * 64})
        with self.assertRaisesRegex(ValueError, "Partie manquante"):
            self.install()
        self.assertFalse((self.source / "medora/a.txt").exists())

    def test_mismatched_version_or_corrupted_part_is_not_extracted(self):
        target = self.bundle("medora-contenus-engine-1.zip", [("medora/a.txt", "A")])
        target.write_bytes(target.read_bytes() + b"unexpected replacement")
        with self.assertRaisesRegex(ValueError, "ne correspond pas"):
            self.install()
        self.assertFalse((self.source / "medora/a.txt").exists())

    def test_archive_paths_and_symlinks_cannot_leave_the_project(self):
        bad_paths = ["medora/../../outside.txt", "/medora/outside.txt", "other/outside.txt", "medora\\outside.txt"]
        symlink = zipfile.ZipInfo("medora/link")
        symlink.create_system = 3
        symlink.external_attr = (stat.S_IFLNK | 0o777) << 16
        for entry in bad_paths + [symlink]:
            with self.subTest(entry=entry):
                self.parts = []
                self.bundle("medora-contenus-engine-1.zip", [(entry, "../../outside.txt")])
                with self.assertRaisesRegex(ValueError, "Chemin"):
                    self.install()
        self.assertFalse((self.root / "outside.txt").exists())

    def test_parts_cannot_overwrite_the_main_application_or_each_other(self):
        core = self.source / "medora" / "package.json"
        core.write_text("original")
        self.bundle("medora-contenus-engine-1.zip", [("medora/new.txt", "new"), ("medora/package.json", "bad")])
        with self.assertRaisesRegex(ValueError, "remplacer"):
            self.install()
        self.assertEqual(core.read_text(), "original")
        self.assertFalse((self.source / "medora/new.txt").exists())
        self.parts = []
        self.bundle("medora-contenus-engine-1.zip", [("medora/new.txt", "first")])
        self.bundle("medora-contenus-engine-2.zip", [("medora/new.txt", "second")])
        with self.assertRaisesRegex(ValueError, "remplacer"):
            self.install()
        self.assertFalse((self.source / "medora/new.txt").exists())
        self.parts = []
        self.bundle("medora-contenus-engine-1.zip", [("medora/parent", "file"), ("medora/parent/child.txt", "child")])
        with self.assertRaisesRegex(ValueError, "fichier comme dossier"):
            self.install()
        self.assertFalse((self.source / "medora/parent").exists())

    def test_manifest_cannot_select_arbitrary_files_from_checkout(self):
        self.parts = [{"file": "../unrelated.zip", "sha256": "0" * 64}]
        with self.assertRaisesRegex(ValueError, "Nom de partie"):
            self.install()


if __name__ == "__main__":
    unittest.main()
