import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';

vi.mock('../supabase/functions/_shared/http.ts', () => ({
  HttpError: class HttpError extends Error {
    constructor(public status: number, public code: string, message: string) {
      super(message);
    }
  },
}));

import { structuredAI } from '../supabase/functions/_shared/ai';

const privateKey = 'sk-private-test-key';
const privateCourse = 'Confidential course text for this test';

describe('OpenAI provider error integration', () => {
  beforeEach(() => {
    vi.stubGlobal('Deno', {
      env: { get: (name: string) => name === 'OPENAI_API_KEY' ? privateKey : undefined },
    });
    vi.spyOn(console, 'error').mockImplementation(() => undefined);
  });

  afterEach(() => {
    vi.unstubAllGlobals();
    vi.restoreAllMocks();
  });

  it('returns an actionable billing error and logs safe categories only', async () => {
    vi.stubGlobal('fetch', vi.fn().mockResolvedValue(new Response(JSON.stringify({
      error: {
        code: 'insufficient_quota',
        message: `Rejected ${privateKey}: ${privateCourse}`,
      },
    }), { status: 429, headers: { 'Content-Type': 'application/json' } })));

    const failure = await structuredAI('Generate study cards', { text: privateCourse }, 'cards', {})
      .catch((error: unknown) => error);

    expect(failure).toMatchObject({ status: 503, code: 'AI_QUOTA' });
    expect((failure as Error).message).toContain('crédits');
    expect((failure as Error).message).toContain('ChatGPT ne couvre pas l’API');
    expect(console.error).toHaveBeenCalledWith(JSON.stringify({
      event: 'ai_provider_error', provider_status: 429, code: 'AI_QUOTA',
    }));
    const publicOutput = JSON.stringify({ failure, logs: vi.mocked(console.error).mock.calls });
    expect(publicOutput).not.toContain(privateKey);
    expect(publicOutput).not.toContain(privateCourse);
    expect((failure as Error).message).not.toContain(privateKey);
    expect((failure as Error).message).not.toContain(privateCourse);
  });

  it('turns provider authentication failures into server configuration errors', async () => {
    vi.stubGlobal('fetch', vi.fn().mockResolvedValue(new Response(JSON.stringify({
      error: { code: 'invalid_api_key', message: `Invalid ${privateKey}` },
    }), { status: 401, headers: { 'Content-Type': 'application/json' } })));

    await expect(structuredAI('Generate study cards', { text: privateCourse }, 'cards', {}))
      .rejects.toMatchObject({ status: 503, code: 'AI_KEY_INVALID' });
    expect(JSON.stringify(vi.mocked(console.error).mock.calls)).not.toContain(privateKey);
  });
});
