import { beforeEach, afterEach, describe, expect, it, vi } from 'vitest';
import type { StudyEnvelope, StudyEvent } from '../src/lib/study-types';

const fixture = vi.hoisted(() => ({
  userId: 'user-a' as string | null,
  configured: false,
  cache: new Map<string, unknown>(),
  remote: [] as Record<string, unknown>[],
  sent: [] as Record<string, unknown>[],
  failed: false,
}));
vi.mock('idb-keyval', () => ({
  createStore: (name: string) => name,
  get: vi.fn(async (key: string, db: string) => structuredClone(fixture.cache.get(`${db}:${key}`))),
  set: vi.fn(async (key: string, value: unknown, db: string) => { fixture.cache.set(`${db}:${key}`, structuredClone(value)); }),
  del: vi.fn(async (key: string, db: string) => { fixture.cache.delete(`${db}:${key}`); }),
}));
vi.mock('../src/lib/supabase', () => ({
  get isConfigured() { return fixture.configured; },
  getSession: async () => fixture.userId ? { user: { id: fixture.userId } } : null,
  supabase: {
    from() {
      const query = {
        async upsert(rows: Record<string, unknown>[]) {
          if (fixture.failed) return { error: { message: 'Network unavailable' } };
          fixture.sent.push(...rows);
          for (const row of rows) if (!fixture.remote.some((item) => item.id === row.id && item.user_id === row.user_id)) fixture.remote.push(row);
          return { error: null };
        },
        select() { return query; }, eq() { return query; }, order() { return query; },
        async range(from: number, to: number) {
          if (fixture.failed) return { error: { message: 'Network unavailable' }, data: null };
          const rows = fixture.remote.filter((item) => item.user_id === fixture.userId);
          return { data: rows.slice(from, Math.min(to + 1, from + 2)), error: null, count: rows.length };
        },
      };
      return query;
    },
  },
}));

beforeEach(() => {
  vi.resetModules();
  vi.useFakeTimers();
  vi.setSystemTime(new Date('2026-10-15T10:00:00Z'));
  vi.stubGlobal('navigator', { onLine: false });
  fixture.cache.clear(); fixture.remote = []; fixture.sent = []; fixture.failed = false; fixture.configured = false; fixture.userId = 'user-a';
});
afterEach(() => { vi.useRealTimers(); vi.unstubAllGlobals(); });
function event(index: number, kind: StudyEvent['kind'], data: Record<string, unknown>, clock = index): StudyEvent {
  return { id: `00000000-0000-4000-8000-${String(index).padStart(12, '0')}`, kind, data, clock, createdAt: '2026-10-15T10:00:00.000Z' };
}

describe('QRU/QRM grading and QROC lexical assistance', () => {
  it('uses exact sets without partial credit or extra answers', async () => {
    const { gradeChoices } = await import('../src/lib/study');
    expect(gradeChoices([2, 0], [0, 2])).toBe(true);
    expect(gradeChoices([0], [0, 2])).toBe(false);
    expect(gradeChoices([0, 1, 2], [0, 2])).toBe(false);
    expect(gradeChoices([], [])).toBe(false);
    expect(gradeChoices([-1], [-1])).toBe(false);
  });
  it('does not confuse negation, similar drug names, numbers or Roman classes', async () => {
    const { matchQrocKeywords } = await import('../src/lib/study');
    expect(matchQrocKeywords('Pas de fièvre', [['fièvre']]).matched).toEqual([]);
    expect(matchQrocKeywords('Fièvre absente', [['fièvre']]).negated).toEqual(['fièvre']);
    expect(matchQrocKeywords('Une fièvre mesurée', [['fièvre']]).matched).toEqual(['fièvre']);
    expect(matchQrocKeywords('zêta classe VIII 5g hypotension', [['bêta'], ['classe VII'], ['5'], ['hypertension']]).matched).toEqual([]);
    const found = matchQrocKeywords('CRP élevée', [['protéine C réactive', 'CRP']]);
    expect(found.matched).toEqual(['protéine C réactive']);
    expect(found.warning).toMatch(/ni le sens clinique/);
    expect(found).not.toHaveProperty('correct');
  });
});

describe('immutable study event merge', () => {
  it('merges two devices without deleting independent progress or duplicate attempts', async () => {
    const { mergeStudyEvents, replayStudyEvents } = await import('../src/lib/study');
    const first = event(1, 'read', { lessonId: 'course-a', chapterIndex: 0, read: true });
    const second = event(2, 'note', { lessonId: 'course-b', text: 'Mon raisonnement' }, 1);
    const third = event(3, 'bookmark', { lessonId: 'course-a', enabled: true }, 2);
    const merged = mergeStudyEvents([first, third], [second, first]);
    expect(merged).toHaveLength(3);
    const state = replayStudyEvents(merged);
    expect(state.read['course-a']).toEqual([0]);
    expect(state.notes['course-b']).toBe('Mon raisonnement');
    expect(state.bookmarks).toEqual(['course-a']);
    expect(replayStudyEvents([...merged].reverse())).toEqual(state);
  });
  it('supports unmarking and records only real lesson self-assessments', async () => {
    const { replayStudyEvents } = await import('../src/lib/study');
    const events = [event(1, 'read', { lessonId: 'course-a', chapterIndex: 0, read: true }), event(2, 'read', { lessonId: 'course-a', chapterIndex: 0, read: false })];
    expect(replayStudyEvents(events).read['course-a']).toEqual([]);
    expect(replayStudyEvents(events).lessonReviews).toEqual({});
  });
});

describe('durable study state and safe backups', () => {
  it('persists notes, active timed sessions, reader settings and attempts across reloads', async () => {
    const { study } = await import('../src/lib/study');
    await study.setNote('course', 'À retenir');
    await study.markRead('course', 2);
    await study.setBookmark('course', true);
    await study.updateSettings({ fontSize: 22, readerTheme: 'sepia' });
    await study.saveActiveSession({ id: 'session', elapsedMs: 7000, selected: { q1: [0, 2] } });
    const answer = { id: 'answer-1', questionId: 'q1', subjectId: 'cardio', mode: 'exam' as const, correct: true };
    await study.recordAttempt(answer);
    await study.recordAttempt(answer);
    vi.resetModules();
    const { study: restarted } = await import('../src/lib/study');
    const state = await restarted.load();
    expect(state.notes.course).toBe('À retenir'); expect(state.read.course).toEqual([2]); expect(state.bookmarks).toEqual(['course']);
    expect(state.activeSession?.elapsedMs).toBe(7000);
    expect(state.settings.readerTheme).toBe('sepia'); expect(state.settings.fontSize).toBe(22);
    expect(state.attempts).toHaveLength(1);
  });
  it('rejects invalid dates/settings and neutralizes prototype pollution', async () => {
    const { study, sanitizeBackup, isCalendarDate } = await import('../src/lib/study');
    expect(isCalendarDate('2026-02-30')).toBe(false);
    expect(isCalendarDate('2028-02-29')).toBe(true);
    expect(() => study.setExamDate('cardio', '2026-02-30')).toThrow();
    expect(() => study.updateSettings({ fontSize: Number.NaN })).toThrow();
    const safe = sanitizeBackup(JSON.parse('{"__proto__":{"polluted":true},"notes":{"constructor":"bad","a":"good"}}'));
    expect(safe).toEqual({ notes: { a: 'good' } });
    expect(({} as Record<string, unknown>).polluted).toBeUndefined();
  });
  it('imports legacy evidence without pretending counters are FSRS reviews', async () => {
    const { study } = await import('../src/lib/study');
    const legacy = { app: 'med2-s1', version: 1, state: { memory: { course: { count: 50, nextDue: '2026-11-01' } }, history: [{ id: 'course', date: '2026-10-01', score: 'partial' }], plan: { settings: { daily: 120 }, done: { course: [{ tour: 1, date: '2026-10-01', level: 'moyen' }] } }, sshWritingDrafts: { writing1: 'Ma réponse' } } };
    const state = await study.importBackup(legacy);
    expect(state.lessonReviews.course).toHaveLength(1);
    expect(state.lessonReviews.course[0].level).toBe('partial');
    expect(state.settings.dailyMinutes).toBe(120); expect(state.writingDrafts.writing1).toBe('Ma réponse');
    expect(state.attempts).toEqual([]);
    expect(state.importedLegacy?.memory).toEqual(legacy.state.memory);
    const backup = await study.exportBackup();
    expect(backup.state.importedLegacy).toEqual(legacy.state);
    await study.importBackup(backup);
    expect((await study.load()).lessonReviews.course).toHaveLength(1);
  });
  it('keeps account data isolated and clears only the signed-out account', async () => {
    fixture.configured = true;
    const { study } = await import('../src/lib/study');
    await study.setNote('course', 'Compte A');
    fixture.userId = 'user-b'; expect((await study.load()).notes).toEqual({});
    await study.setNote('course', 'Compte B');
    await study.clearCache('user-a');
    expect((await study.load()).notes.course).toBe('Compte B');
    fixture.userId = 'user-a'; expect((await study.load()).notes).toEqual({});
    fixture.userId = null; await expect(study.load()).rejects.toThrow('Connectez-vous');
  });
  it('does not save an unmounted exam into a different account or after logout', async () => {
    fixture.configured = true;
    const { study } = await import('../src/lib/study');
    const owner = await study.ownerScope();
    fixture.userId = 'user-b';
    await study.saveActiveSession({ id: 'old-account-exam' }, owner);
    expect((await study.load()).activeSession).toBeUndefined();
    fixture.userId = null;
    await expect(study.saveActiveSession({ id: 'old-account-exam' }, owner)).resolves.toMatchObject({ attempts: [] });
  });
  it('can import the same event IDs into another account and sync each owner independently', async () => {
    fixture.configured = true;
    const { study } = await import('../src/lib/study');
    await study.setNote('course', 'Mon carnet exporté');
    const backup = await study.exportBackup();
    await study.sync();
    const originalId = backup.events[0].id;
    fixture.userId = 'user-b';
    await study.importBackup(backup);
    await study.sync();
    expect(fixture.remote.filter((row) => row.id === originalId).map((row) => row.user_id).sort()).toEqual(['user-a', 'user-b']);
    await study.clearCache('user-b');
    const restored = await study.sync();
    expect(restored.notes.course).toBe('Mon carnet exporté');
  });
  it('resets progress while preserving personal content and supports explicit backup recovery', async () => {
    const { study } = await import('../src/lib/study');
    await study.markRead('course', 0); await study.setNote('course', 'À conserver'); await study.setBookmark('course', true);
    await study.recordLessonReview('course', 'partial'); await study.addMission('course', 'recall');
    const backup = await study.exportBackup();
    const reset = await study.resetProgress();
    expect(reset.read).toEqual({}); expect(reset.lessonReviews).toEqual({}); expect(reset.missions).toEqual([]);
    expect(reset.notes.course).toBe('À conserver'); expect(reset.bookmarks).toEqual(['course']);
    const recovered = await study.importBackup(backup);
    expect(recovered.read.course).toEqual([0]); expect(recovered.lessonReviews.course).toHaveLength(1); expect(recovered.missions).toHaveLength(1);
  });
  it('does not let a reset contained in an imported backup wipe receiving-account progress', async () => {
    const { study } = await import('../src/lib/study');
    await study.markRead('old', 0); await study.resetProgress(); await study.markRead('imported', 1);
    const backup = await study.exportBackup();
    await study.clearCache('demo');
    await study.markRead('local', 2);
    const merged = await study.importBackup(backup);
    expect(merged.read.local).toEqual([2]); expect(merged.read.imported).toEqual([1]); expect(merged.read.old).toBeUndefined();
  });
  it('imports catalogue metadata additively and rejects executable URLs', async () => {
    const { study } = await import('../src/lib/study');
    const catalogue = { schemaVersion: 1, subjects: [{ id: 'cardio', name: 'Cardiologie' }], resources: [{ id: 'r1', subject: 'cardio', title: 'Cours ajouté', kind: 'CM', url: 'https://example.org/cours.pdf' }] };
    await study.importCatalogue(catalogue);
    const state = await study.importCatalogue({ ...catalogue, resources: [{ ...catalogue.resources[0], id: 'r2' }] });
    expect(state.customCatalogue?.resources).toHaveLength(2);
    expect(() => study.importCatalogue({ ...catalogue, resources: [{ ...catalogue.resources[0], url: 'javascript:alert(1)' }] })).toThrow(/HTTPS/);
    expect(() => study.importCatalogue({ ...catalogue, resources: [...catalogue.resources, ...catalogue.resources] })).toThrow(/dupliqué/);
  });
  it('preserves old QROC responses without importing the old fuzzy match as a correct answer', async () => {
    const { study } = await import('../src/lib/study');
    const state = await study.importBackup({ app: 'med2-s1', state: { qroc: { qroc1: { a: 'pas de fièvre', ok: true, date: '2026-10-01' } }, flashcards: { 'course#0': { result: 'again', at: '2026-10-01' } } } });
    expect(state.writingDrafts.qroc1).toBe('pas de fièvre');
    expect(state.attempts).toHaveLength(1);
    expect(state.attempts[0].mode).toBe('flashcard'); expect(state.attempts[0].correct).toBe(false);
  });
  it('preserves an outbox on network failure and paginates a capped API without lost remote events', async () => {
    fixture.configured = true;
    const { study } = await import('../src/lib/study');
    await study.setNote('local', 'Hors connexion');
    fixture.failed = true;
    expect((await study.sync()).syncStatus).toBe('pending');
    const pending = fixture.cache.get('medora-curriculum-v2:study:user-a') as StudyEnvelope;
    expect(pending.pending).toHaveLength(1);
    fixture.failed = false;
    fixture.remote = Array.from({ length: 5 }, (_, index) => { const e = event(50 + index, 'bookmark', { lessonId: `course-${index}`, enabled: true }); return { id: e.id, user_id: 'user-a', kind: e.kind, payload: { clock: e.clock, data: e.data }, happened_at: e.createdAt }; });
    const synced = await study.sync();
    expect(synced.notes.local).toBe('Hors connexion');
    expect(synced.bookmarks).toHaveLength(5);
    expect(synced.syncStatus).toBe('synced');
    expect(fixture.sent).toHaveLength(1);
    expect((fixture.cache.get('medora-curriculum-v2:study:user-a') as StudyEnvelope).pending).toEqual([]);
  });
});

describe('owner-scoped MED_ENGINE writes', () => {
  it('drops delayed notes, responses and exam settings after the account changes', async () => {
    fixture.configured = true;
    const { study } = await import('../src/lib/study');
    const owner = await study.ownerScope();
    await study.setNote('engine:pack:p', 'Note privée du compte A', owner);
    fixture.userId = 'user-b';
    await study.setNote('engine:pack:p', 'Ancienne saisie retardée', owner);
    await study.setBookmark('engine:pack:p', true, owner);
    await study.setExamDate('engine:subject:a', '2027-01-10', owner);
    await study.saveWritingDraft('engine:exam-answer:draft', 'Ancienne réponse privée', owner);
    await study.recordAttempt({ questionId: 'engine:p:q:main', subjectId: 'engine:subject:a', lessonId: 'engine:pack:p', mode: 'practice', correct: true }, owner);
    await study.recordSession({ lessonId: 'engine:pack:p', mode: 'practice', startedAt: '2026-10-15T09:00:00Z', finishedAt: '2026-10-15T09:01:00Z', questionCount: 1, correctCount: 1, durationSeconds: 60 }, owner);
    expect(await study.load()).toMatchObject({ notes: {}, bookmarks: [], exams: {}, writingDrafts: {}, attempts: [], sessions: [] });
    fixture.userId = 'user-a';
    expect((await study.load()).notes['engine:pack:p']).toBe('Note privée du compte A');
  });
});
