import { describe, expect, it } from 'vitest';
import { replayStudyEvents } from '../src/lib/study';
import type { StudyEvent } from '../src/lib/study-types';
describe('existing MED2 reset stays scoped after importing MED_ENGINE', () => {
  it('keeps engine answers, sessions and saved work while removing MED2 activity', () => {
    let clock = 0;
    const date = '2026-10-27T16:00:00.000Z';
    const event = (kind: StudyEvent['kind'], data: Record<string, unknown>): StudyEvent => ({ id: crypto.randomUUID(), kind, clock: ++clock, createdAt: date, data });
    const attempt = (questionId: string) => ({ id: crypto.randomUUID(), questionId, lessonId: questionId.startsWith('engine:') ? 'engine:pack:p' : 'med2', subjectId: 'subject', mode: 'practice', correct: true, createdAt: date });
    const saved = { application: 'engine', packId: 'p', cardIds: ['engine:p:q:main'] };
    const state = replayStudyEvents([
      event('attempt', { attempt: attempt('engine:p:q:main') }), event('attempt', { attempt: attempt('med2:q') }),
      event('session', { session: { id: crypto.randomUUID(), lessonId: 'engine:pack:p', mode: 'practice', startedAt: date, finishedAt: date, questionCount: 1, correctCount: 1, durationSeconds: 0 } }),
      event('active-session', { session: saved }), event('note', { lessonId: 'engine:pack:p', text: 'Note à conserver' }), event('reset-progress', {}),
    ]);
    expect(state.attempts.map(item => item.questionId)).toEqual(['engine:p:q:main']);
    expect(state.sessions).toHaveLength(1);
    expect(state.activeSession).toEqual(saved);
    expect(state.notes['engine:pack:p']).toBe('Note à conserver');
  });
});
