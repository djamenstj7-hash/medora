import { beforeEach, describe, expect, it, vi } from 'vitest';
import { newSchedule } from '../src/lib/fsrs';
import type { CachedLibrary } from '../src/lib/persistence';

const fixture = vi.hoisted(() => ({ cache: new Map<string, CachedLibrary>(), configured: false, userId: 'user-a' as string | null, rpc: vi.fn() }));
vi.mock('../src/lib/persistence', async (importOriginal) => {
  const original = await importOriginal<typeof import('../src/lib/persistence')>();
  return { ...original, persistence: {
    read: async (scope: string) => structuredClone(fixture.cache.get(scope)),
    write: async (scope: string, value: CachedLibrary) => { fixture.cache.set(scope, structuredClone(value)); },
    clear: async (scope: string) => { fixture.cache.delete(scope); },
  } };
});
vi.mock('../src/lib/supabase', () => ({ get isConfigured() { return fixture.configured; }, getSession: async () => fixture.userId ? { user: { id: fixture.userId } } : null, supabase: { rpc: fixture.rpc } }));
const input = { packId: 'semio-abord', title: 'Paquet de sémiologie', subject: 'Sémiologie', color: '#007AFF', cards: [
  { id: 'engine:semio:cloze:1', noteId: 'source-note', prompt: 'Premier rappel ?', answer: 'Première réponse', explanation: 'Explication du cours.' },
  { id: 'engine:semio:cloze:2', noteId: 'source-note', prompt: 'Second rappel ?', answer: 'Seconde réponse' },
] };
beforeEach(() => {
  vi.resetModules(); fixture.cache.clear();
  fixture.configured = false; fixture.userId = 'user-a'; fixture.rpc.mockReset();
  fixture.cache.set('demo', {
    decks: [{ id: 'old-deck', title: 'Mon deck existant', subject: 'Neuro', color: '#007AFF', created_at: '2026-10-15T10:00:00.000Z' }],
    cards: [{ id: 'old-card', deck_id: 'old-deck', kind: 'flashcard', prompt: 'Ancienne question', answer: 'Ancienne réponse', explanation: '', options: [], correct_option_id: null, status: 'active', schedule: newSchedule(new Date('2026-10-15T10:00:00.000Z')), version: 7 }],
    reviews: [{ id: 'old-review', card_id: 'old-card', client_event_id: 'old-event', rating: 3, reviewed_at: '2026-10-15T10:00:00.000Z' }], pending: [],
  });
});

describe('MED_ENGINE to FSRS bridge', () => {
  it('preserves existing history and distinct cloze variants while adding drafts with source pointers', async () => {
    const original = structuredClone(fixture.cache.get('demo')!);
    const { repository } = await import('../src/lib/repository');
    const result = await repository.installEngineDeck(input);
    const cached = fixture.cache.get('demo')!;
    expect(result.count).toBe(2);
    expect(cached.decks).toHaveLength(2);
    expect(cached.cards.find(card => card.id === 'old-card')).toEqual(original.cards[0]);
    expect(cached.reviews).toEqual(original.reviews);
    const cards = cached.cards.filter(card => card.deck_id === result.deckId);
    expect(cards.map(card => card.content?.cardId)).toEqual(input.cards.map(card => card.id));
    expect(cards.every(card => card.status === 'draft' && card.version === 0 && card.schedule.reps === 0)).toBe(true);
    expect(cards[0].content).toEqual({ origin: 'engine', packId: input.packId, cardId: input.cards[0].id, noteId: 'source-note' });
  });
  it('reuses an installed pack after activation and review without duplicating or resetting schedules', async () => {
    const { repository } = await import('../src/lib/repository');
    const first = await repository.installEngineDeck(input);
    await repository.activateDeck(first.deckId);
    const card = fixture.cache.get('demo')!.cards.find(card => card.deck_id === first.deckId)!;
    await repository.rateCard(card, 3);
    const after = structuredClone(fixture.cache.get('demo')!);
    expect(await repository.installEngineDeck(input)).toEqual(first);
    expect(fixture.cache.get('demo')).toEqual(after);
  });
  it('rejects duplicate variants before creating a deck', async () => {
    const { repository } = await import('../src/lib/repository');
    await expect(repository.installEngineDeck({ ...input, cards: [input.cards[0], input.cards[0]] })).rejects.toThrow(/dupliqué/);
    expect(fixture.cache.get('demo')!.decks).toHaveLength(1);
  });
  it('does not collide with an existing MED2 course of the same identifier', async () => {
    const { repository } = await import('../src/lib/repository');
    const med2 = await repository.installCourseDeck({ lessonId: input.packId, title: 'Ancien cours', subject: input.subject, color: input.color, cards: [{ prompt: 'Ancien rappel ?', answer: 'Ancienne réponse' }] });
    const engine = await repository.installEngineDeck(input);
    expect(engine.deckId).not.toBe(med2.deckId);
    expect(fixture.cache.get('demo')!.decks).toHaveLength(3);
  });
  it('rejects a changed account before loading a new snapshot into the original owner cache', async () => {
    fixture.configured = true;
    fixture.rpc.mockImplementationOnce(async () => {
      fixture.userId = 'user-b';
      return { data: { deckId: 'remote-a', count: 2 }, error: null };
    });
    const { repository } = await import('../src/lib/repository');
    await expect(repository.installEngineDeck(input)).rejects.toThrow(/compte a changé/);
    expect(fixture.cache.has('user-a')).toBe(false);
    expect(fixture.cache.has('user-b')).toBe(false);
  });
  it('requires an authenticated account before calling the installation RPC', async () => {
    fixture.configured = true; fixture.userId = null;
    const { repository } = await import('../src/lib/repository');
    await expect(repository.installEngineDeck(input)).rejects.toThrow(/Connectez-vous/);
    expect(fixture.rpc).not.toHaveBeenCalled();
  });
});
