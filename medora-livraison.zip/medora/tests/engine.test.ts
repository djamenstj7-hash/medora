import { describe, expect, it } from 'vitest';
import { deserializeSchedule, newSchedule, scheduleReview, serializeSchedule } from '../src/lib/fsrs';
import { getReviewQueue } from '../src/lib/interleaving';
import { enqueueReview } from '../src/lib/persistence';
import type { Deck, PendingReview, StudyCard } from '../src/lib/types';

const now = new Date('2026-10-15T12:00:00.000Z');
function card(id: string, deckId: string, due: Date = now): StudyCard {
  return { id, deck_id: deckId, kind: 'flashcard', prompt: 'Question', answer: 'Réponse', explanation: 'Explication', options: [], correct_option_id: null, status: 'active', version: 0, schedule: newSchedule(due) };
}
const decks: Deck[] = [
  { id: 'cardio', title: 'Cardio', subject: 'Cardiologie', color: '#fff', created_at: now.toISOString() },
  { id: 'neuro', title: 'Neuro', subject: 'Neurologie', color: '#fff', created_at: now.toISOString() },
];

describe('FSRS persistence and scheduling', () => {
  it('round-trips dates through JSON and gives Easy a later due date than Again', () => {
    const initial = newSchedule(now);
    const stored = JSON.parse(JSON.stringify(initial));
    expect(serializeSchedule(deserializeSchedule(stored))).toEqual(initial);
    const again = scheduleReview(stored, 1, now);
    const easy = scheduleReview(stored, 4, now);
    expect(new Date(easy.due).getTime()).toBeGreaterThan(new Date(again.due).getTime());
    expect(again.reps).toBe(1);
    expect(easy.reps).toBe(1);
    expect(initial.reps).toBe(0);
    expect(again.last_review).toBe(now.toISOString());
  });

  it('uses the previous memory state for successive reviews', () => {
    const first = scheduleReview(newSchedule(now), 4, now);
    const due = new Date(first.due);
    const second = scheduleReview(first, 3, due);
    expect(second.reps).toBe(2);
    expect(second.stability).toBeGreaterThan(0);
    expect(new Date(second.due).getTime()).toBeGreaterThan(due.getTime());
  });
});

describe('interleaving', () => {
  it('alternates subjects while retaining markedly overdue cards ahead of recent cards', () => {
    const old = new Date(now.getTime() - 8 * 86_400_000);
    const cards = [card('c1', 'cardio'), card('c2', 'cardio'), card('c3', 'cardio'), card('n1', 'neuro'), card('overdue', 'cardio', old)];
    const queue = getReviewQueue(cards, decks, now);
    expect(queue.map((item) => item.id)).toEqual(['overdue', 'n1', 'c1', 'c2', 'c3']);
  });

  it('excludes drafts and future cards, respects the limit, and does not modify input', () => {
    const future = card('future', 'cardio', new Date(now.getTime() + 1000));
    const draft = { ...card('draft', 'neuro'), status: 'draft' as const };
    const cards = [future, draft, card('due1', 'cardio'), card('due2', 'neuro')];
    const before = cards.map((item) => item.id);
    expect(getReviewQueue(cards, decks, now, 1).map((item) => item.id)).toEqual(['due1']);
    expect(cards.map((item) => item.id)).toEqual(before);
  });
});

describe('offline idempotency', () => {
  it('retains a single event for retransmissions without collapsing distinct reviews', () => {
    const event: PendingReview = { card_id: 'card', rating: 3, client_event_id: 'event-1', reviewed_at: now.toISOString(), expected_version: 0 };
    const initial = enqueueReview([], event);
    expect(enqueueReview(initial, { ...event })).toBe(initial);
    expect(enqueueReview(initial, { ...event, client_event_id: 'event-2', expected_version: 1 })).toHaveLength(2);
  });
});
