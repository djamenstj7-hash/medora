import { describe, expect, it } from 'vitest';
import type { CurriculumManifest, CurriculumSubject, LessonSummary, Question, TrainingBank } from '../src/lib/curriculum';
import type { StudyState } from '../src/lib/study-types';
import { buildStudyPlan, dayInTimezone, examCalendar, upcomingExams } from '../src/lib/study-plan';
import { elapsedMilliseconds, isTrainingSession, pausedSession, sampleTraining, shuffled, type TrainingSession } from '../src/lib/training-session';

const state = (): StudyState => ({ schemaVersion: 2, read: {}, bookmarks: [], notes: {}, attempts: [], sessions: [], missions: [], exams: {}, lessonReviews: {}, writingDrafts: {}, version: 0, settings: { dailyMinutes: 30, backgroundMinutes: 10, fontSize: 18, lineHeight: 1.75, readerTheme: 'light', readerFont: 'serif' } });
const subjects: CurriculumSubject[] = ['a', 'b'].map((id) => ({ id, name: id, color: '#000', lessonCount: 1, trainingCount: 1, caseCount: 0 }));
const lessons: LessonSummary[] = subjects.map((subject) => ({ id: `${subject.id}-lesson`, subject: subject.name, subjectId: subject.id, title: subject.name, courseName: subject.name, teacher: '', sectionCount: 2, chapterTitles: ['Introduction', 'Suite'], questionCount: 1, activeQuestionCount: 1, cardCount: 0, qrocCount: 0, writingCount: 0, searchText: '' }));
const question = (id: string): Question => ({ id, subjectId: 'a', prompt: id, options: ['vrai', 'faux'], correct: [0], explanation: '', format: 'QRU' });

describe('study plan evidence and calendar', () => {
  it('does not invent mistakes or mastery, stays within budget, and interleaves subjects', () => {
    const fresh = state();
    const result = buildStudyPlan(lessons, subjects, fresh, new Date('2026-10-15T12:00:00Z'));
    expect(result.map((task) => task.subjectId)).toEqual(['a', 'b']);
    expect(result.every((task) => task.type === 'read')).toBe(true);
    expect(result.reduce((sum, task) => sum + task.minutes, 0)).toBeLessThanOrEqual(30);
    expect(fresh.attempts).toHaveLength(0);
  });
  it('uses the latest attempt and only the next unread chapter', () => {
    const data = state(); data.settings.dailyMinutes = 60; data.read['a-lesson'] = [0];
    data.attempts = [{ id: '1', questionId: 'q', subjectId: 'a', lessonId: 'a-lesson', mode: 'practice', correct: false, createdAt: '2026-10-14T00:00:00Z' }, { id: '2', questionId: 'q', subjectId: 'a', lessonId: 'a-lesson', mode: 'practice', correct: true, createdAt: '2026-10-15T00:00:00Z' }];
    const result = buildStudyPlan(lessons, subjects, data);
    expect(result.find((task) => task.lessonId === 'a-lesson')?.chapterIndex).toBe(1);
    expect(result.some((task) => task.type === 'practice')).toBe(false);
  });
  it('keeps old exam dates archived and does not apply old times to a personal date', () => {
    const manifest = { subjects, exams: [{ id: 'exam', subject: 'a', title: 'A', date: '2025-11-01', start: '09:00', end: '10:00' }], timezone: 'Europe/Paris' } as CurriculumManifest;
    const now = new Date('2026-10-15T12:00:00Z');
    expect(upcomingExams(manifest, state(), now)).toEqual([]);
    expect(examCalendar(manifest, state(), now)[0].archived).toBe(true);
    const data = state(); data.exams.a = '2026-12-01';
    expect(upcomingExams(manifest, data, now)[0]).toMatchObject({ date: '2026-12-01', start: null, end: null, overridden: true });
  });
  it('uses the source timezone near midnight and daylight saving boundaries', () => {
    expect(dayInTimezone(new Date('2026-10-15T22:30:00Z'), 'Europe/Paris')).toBe('2026-10-16');
    expect(dayInTimezone(new Date('2026-12-15T22:30:00Z'), 'Europe/Paris')).toBe('2026-12-15');
  });
  it('reserves part of the total budget for later exams without adding extra time', () => {
    const data = state(); data.settings.backgroundMinutes = 10;
    const dated = subjects.map((subject, index) => ({ ...subject, date: index ? '2027-01-05' : '2026-11-04' }));
    const result = buildStudyPlan(lessons, dated, data, new Date('2026-10-15T12:00:00Z'));
    // Unused foreground minutes may also be offered to a later subject.
    expect(result.filter((task) => task.subjectId === 'b').reduce((sum, task) => sum + task.minutes, 0)).toBeGreaterThanOrEqual(10);
    expect(result.reduce((sum, task) => sum + task.minutes, 0)).toBeLessThanOrEqual(30);
  });
  it('uses short recall tasks on the eve of an exam and respects coefficient priority', () => {
    const data = state(); data.settings.dailyMinutes = 15; data.settings.backgroundMinutes = 0;
    const dated = subjects.map((subject, index) => ({ ...subject, coefficient: index ? 3 : 1, date: '2026-11-04' }));
    const result = buildStudyPlan(lessons, dated, data, new Date('2026-11-03T12:00:00Z'));
    expect(result[0].subjectId).toBe('b');
    expect(result.every((task) => task.type === 'recall')).toBe(true);
    expect(result.every((task) => task.reason.includes('Veille'))).toBe(true);
    expect(data.read).toEqual({});
  });
});

describe('training selection and durable timer', () => {
  const bank: TrainingBank = { subjectId: 'a', questions: [question('qi-1'), { ...question('retired'), retired: true }], cases: [{ id: 'case', title: 'Dossier', vignette: 'Contexte nécessaire', questions: [question('case-1'), question('case-2'), question('case-3')] }] };
  it('retains case context and order, excludes retired questions and never truncates a case', () => {
    const result = sampleTraining([bank], { bank: 'cases', format: 'all', count: 10 }, () => 0.5);
    expect(result.map((item) => item.question.id)).toEqual(['case-1', 'case-2', 'case-3']);
    expect(result.every((item) => item.vignette === 'Contexte nécessaire')).toBe(true);
    expect(sampleTraining([bank], { bank: 'cases', format: 'all', count: 2 })).toEqual([]);
    expect(sampleTraining([bank], { bank: 'qi', format: 'all', count: 10 }).map((item) => item.question.id)).toEqual(['qi-1']);
  });
  it('requires real weak evidence rather than labelling unseen questions incorrect', () => {
    expect(sampleTraining([bank], { bank: 'mixed', format: 'all', count: 10, weakIds: new Set() })).toEqual([]);
    expect(sampleTraining([bank], { bank: 'mixed', format: 'all', count: 10, weakIds: new Set(['qi-1']) }).map((item) => item.question.id)).toEqual(['qi-1']);
  });
  it('does not drop the first step of a mixed-format clinical case when filtering', () => {
    const mixed = { ...bank, cases: [{ ...bank.cases[0], questions: [question('first'), { ...question('later'), format: 'QRM' as const, correct: [0, 1] }] }] };
    expect(sampleTraining([mixed], { bank: 'cases', format: 'QRM', count: 10 })).toEqual([]);
    expect(sampleTraining([mixed], { bank: 'cases', format: 'all', count: 10 }).map((item) => item.question.id)).toEqual(['first', 'later']);
  });
  it('approximates exam proportions using complete linked cases and canonical weak identities', () => {
    const richer = { ...bank, questions: Array.from({ length: 20 }, (_, index) => question(`qi-${index}`)) };
    const result = sampleTraining([richer], { bank: 'mixed', format: 'all', count: 10, caseFraction: 0.5 }, () => 0.5);
    expect(result).toHaveLength(10);
    expect(result.filter((item) => item.caseId)).toHaveLength(3);
    expect(result.filter((item) => item.caseId).map((item) => item.question.id)).toEqual(['case-1', 'case-2', 'case-3']);
    const alias = { ...bank, questions: [{ ...question('alias'), canonicalId: 'original' }], cases: [] };
    expect(sampleTraining([alias], { bank: 'qi', format: 'all', count: 10, weakIds: new Set(['original']) })[0].question.id).toBe('alias');
  });
  it('shuffles without modifying the original and can reach every order with Fisher-Yates', () => {
    const source = [1, 2, 3];
    const orders = new Set<string>();
    for (const first of [0, 0.34, 0.67]) for (const second of [0, 0.51]) { const values = [first, second]; orders.add(shuffled(source, () => values.shift()!).join('')); }
    expect(orders.size).toBe(6); expect(source).toEqual([1, 2, 3]);
  });
  it('counts work once, freezes on pause and continues from the saved accumulated time', () => {
    const input = { elapsedMs: 4000, runningSince: 1000 } as TrainingSession;
    expect(elapsedMilliseconds(input, 6000)).toBe(9000);
    const paused = pausedSession(input, 6000);
    expect(elapsedMilliseconds(paused, 100000)).toBe(9000);
    expect(elapsedMilliseconds({ ...paused, runningSince: 100000 }, 102000)).toBe(11000);
    expect(elapsedMilliseconds({ elapsedMs: 1000, runningSince: 5000 }, 4000)).toBe(1000);
  });
  it('rejects malformed or out-of-range saved sessions before mounting a question', () => {
    const valid: TrainingSession = { kind: 'medora-curriculum-training', id: 'test', subjectIds: ['a'], questionIds: ['q'], index: 0, answers: { q: { selected: [0], correct: true, attemptId: 'answer', durationSeconds: 5 } }, bank: 'qi', mode: 'practice', elapsedMs: 5000, runningSince: null, questionStartedMs: 0, limitSeconds: null, startedAt: '2026-10-15T12:00:00Z' };
    expect(isTrainingSession(valid)).toBe(true);
    expect(isTrainingSession({ ...valid, index: 1 })).toBe(false);
    expect(isTrainingSession({ ...valid, elapsedMs: Infinity })).toBe(false);
    expect(isTrainingSession({ ...valid, answers: { q: { ...valid.answers.q, selected: 'malformed' } } })).toBe(false);
  });
});
