import { beforeEach, describe, expect, it, vi } from 'vitest';
import { newSchedule } from '../src/lib/fsrs';
import type { CachedLibrary } from '../src/lib/persistence';

const fixture = vi.hoisted(() => ({ cache: new Map<string, CachedLibrary>() }));
vi.mock('../src/lib/persistence', async (importOriginal) => {
  const original = await importOriginal<typeof import('../src/lib/persistence')>();
  return { ...original, persistence: {
    read: async (scope: string) => structuredClone(fixture.cache.get(scope)),
    write: async (scope: string, value: CachedLibrary) => { fixture.cache.set(scope, structuredClone(value)); },
    clear: async (scope: string) => { fixture.cache.delete(scope); },
  } };
});
vi.mock('../src/lib/supabase', () => ({ isConfigured: false, getSession: async () => null, supabase: null }));
const input = { lessonId: 'course-a', title: 'Cours de cardiologie', subject: 'Cardiologie', color: '#007AFF', cards: [{ prompt: 'Expliquez le mécanisme.', answer: 'Réponse issue du cours.', explanation: 'Source : cours MED2.' }] };

beforeEach(() => {
  vi.resetModules(); fixture.cache.clear();
  fixture.cache.set('demo', {
    decks: [{ id: 'old-deck', title: 'Mon deck existant', subject: 'Neuro', color: '#007AFF', created_at: '2026-10-15T10:00:00.000Z' }],
    cards: [{ id: 'old-card', deck_id: 'old-deck', kind: 'flashcard', prompt: 'Ancienne question', answer: 'Ancienne réponse', explanation: '', options: [], correct_option_id: null, status: 'active', schedule: newSchedule(new Date('2026-10-15T10:00:00.000Z')), version: 7 }],
    reviews: [{ id: 'old-review', card_id: 'old-card', client_event_id: 'old-event', rating: 3, reviewed_at: '2026-10-15T10:00:00.000Z' }], pending: [],
  });
});

describe('curriculum to FSRS bridge', () => {
  it('adds a draft deck without altering existing cards or their history', async () => {
    const original = structuredClone(fixture.cache.get('demo')!);
    const { repository } = await import('../src/lib/repository');
    const result = await repository.installCourseDeck(input);
    const cached = fixture.cache.get('demo')!;
    expect(result.count).toBe(1);
    expect(cached.decks).toHaveLength(2);
    expect(cached.cards.find((card) => card.id === 'old-card')).toEqual(original.cards[0]);
    expect(cached.reviews).toEqual(original.reviews);
    const added = cached.cards.find((card) => card.deck_id === result.deckId)!;
    expect(added.status).toBe('draft'); expect(added.schedule.reps).toBe(0); expect(added.version).toBe(0);
  });
  it('reuses the installed deck and preserves its activation and reviewed schedule', async () => {
    const { repository } = await import('../src/lib/repository');
    const first = await repository.installCourseDeck(input);
    await repository.activateDeck(first.deckId);
    const card = fixture.cache.get('demo')!.cards.find((item) => item.deck_id === first.deckId)!;
    await repository.rateCard(card, 3);
    const afterReview = structuredClone(fixture.cache.get('demo')!);
    const repeated = await repository.installCourseDeck(input);
    expect(repeated).toEqual(first);
    expect(fixture.cache.get('demo')).toEqual(afterReview);
  });
  it('rejects malformed content before creating a deck', async () => {
    const { repository } = await import('../src/lib/repository');
    await expect(repository.installCourseDeck({ ...input, cards: [{ prompt: '', answer: 'Réponse' }] })).rejects.toThrow(/limites/);
    expect(fixture.cache.get('demo')!.decks).toHaveLength(1);
  });
});
