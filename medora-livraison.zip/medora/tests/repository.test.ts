import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { newSchedule, scheduleReview } from '../src/lib/fsrs';
import type { CachedLibrary } from '../src/lib/persistence';
import type { Deck, StudyCard } from '../src/lib/types';

const mock = vi.hoisted(() => ({
  userId: 'user-a' as string | null,
  cache: new Map<string, CachedLibrary>(),
  writes: [] as { scope: string; data: CachedLibrary }[],
  invoke: vi.fn(),
  ranges: [] as { table: string; from: number; to: number }[],
  rows: {} as Record<string, Record<string, unknown>[]>,
  networkFailure: false,
  maxRows: 1000,
}));

vi.mock('../src/lib/persistence', async (importOriginal) => {
  const original = await importOriginal<typeof import('../src/lib/persistence')>();
  return {
    ...original,
    persistence: {
      read: vi.fn(async (scope: string) => structuredClone(mock.cache.get(scope))),
      write: vi.fn(async (scope: string, data: CachedLibrary) => {
        mock.cache.set(scope, structuredClone(data));
        mock.writes.push({ scope, data: structuredClone(data) });
      }),
      clear: vi.fn(async (scope: string) => { mock.cache.delete(scope); }),
    },
  };
});

vi.mock('../src/lib/supabase', () => ({
  isConfigured: true,
  getSession: vi.fn(async () => mock.userId ? { user: { id: mock.userId } } : null),
  supabase: {
    functions: { invoke: mock.invoke },
    from(table: string) {
      const query = {
        select() { return query; },
        order() { return query; },
        async range(from: number, to: number) {
          mock.ranges.push({ table, from, to });
          if (mock.networkFailure) return { data: null, error: { message: 'Failed to fetch' }, status: 0, count: null };
          const rows = mock.rows[table] || [];
          return { data: structuredClone(rows.slice(from, Math.min(to + 1, from + mock.maxRows))), count: rows.length, error: null, status: 200 };
        },
      };
      return query;
    },
  },
}));

const now = new Date('2026-10-15T12:00:00.000Z');
function card(id = 'card-a'): StudyCard {
  return { id, deck_id: 'deck-a', kind: 'flashcard', prompt: 'Question', answer: 'Réponse', explanation: 'Explication', options: [], correct_option_id: null, status: 'active', version: 0, schedule: newSchedule(now) };
}
const deck: Deck = { id: 'deck-a', title: 'Cardio', subject: 'Cardiologie', color: '#fff', created_at: now.toISOString() };
function seed(userId = 'user-a', studyCard = card()) {
  mock.cache.set(userId, { decks: [deck], cards: [studyCard], reviews: [], pending: [] });
  return studyCard;
}
function httpError(status: number) {
  return { data: null, error: { name: 'FunctionsHttpError', message: 'Edge Function error', context: new Response(JSON.stringify({ error: `HTTP ${status}` }), { status, headers: { 'Content-Type': 'application/json' } }) } };
}
function stored(userId = 'user-a') { return mock.cache.get(userId)!; }

beforeEach(() => {
  vi.resetModules();
  vi.useFakeTimers();
  vi.setSystemTime(now);
  vi.stubGlobal('navigator', { onLine: true });
  mock.userId = 'user-a';
  mock.cache.clear();
  mock.writes = [];
  mock.ranges = [];
  mock.rows = {};
  mock.maxRows = 1000;
  mock.networkFailure = false;
  mock.invoke.mockReset();
});
afterEach(() => { vi.useRealTimers(); vi.unstubAllGlobals(); });

describe('durable review outbox', () => {
  it('retries the same persisted event after a committed review loses its response', async () => {
    const initial = seed();
    const committed = scheduleReview(initial.schedule, 3, now);
    mock.invoke.mockImplementationOnce(async (_name, { body }) => {
      expect(stored().pending[0].client_event_id).toBe(body.client_event_id);
      expect(stored().cards[0].version).toBe(1);
      expect(stored().reviews).toHaveLength(1);
      // The transaction committed, but the gateway lost the successful response.
      return httpError(502);
    }).mockResolvedValueOnce({ data: { schedule: committed, version: 1, duplicate: true }, error: null });
    const { repository } = await import('../src/lib/repository');

    const optimistic = await repository.rateCard(initial, 3);
    expect(optimistic.queued).toBe(true);
    expect(stored().pending).toHaveLength(1);
    expect(stored().reviews).toHaveLength(1);
    const originalEvent = structuredClone(stored().pending[0]);

    // Restarting the module models a new app launch using only persisted state.
    vi.resetModules();
    const { repository: restarted } = await import('../src/lib/repository');
    expect(await restarted.syncPending()).toEqual({ sent: 1, conflicts: 0 });
    const retry = mock.invoke.mock.calls[1][1].body;
    expect(retry).toEqual(originalEvent);
    expect(stored().pending).toHaveLength(0);
    expect(stored().cards[0].version).toBe(1);
    expect(stored().cards[0].schedule).toEqual(committed);
    expect(stored().reviews).toHaveLength(1);
  });

  it.each([408, 425, 429, 500, 502, 503])('keeps an optimistic event after a retryable HTTP %i', async (status) => {
    const initial = seed();
    mock.invoke.mockResolvedValueOnce(httpError(status));
    const { repository } = await import('../src/lib/repository');
    expect((await repository.rateCard(initial, 3)).queued).toBe(true);
    expect(stored().pending).toHaveLength(1);
    expect(stored().cards[0].version).toBe(1);
    expect(stored().reviews).toHaveLength(1);
  });

  it('surfaces a definitive authorization rejection without inventing a completed review', async () => {
    const initial = seed();
    mock.invoke.mockResolvedValueOnce(httpError(401));
    const { repository } = await import('../src/lib/repository');
    await expect(repository.rateCard(initial, 3)).rejects.toThrow('HTTP 401');
    expect(stored().pending).toHaveLength(0);
    expect(stored().reviews).toHaveLength(0);
    expect(stored().cards[0].version).toBe(0);
  });

  it('does not overwrite a newer server state with an older idempotent result', async () => {
    const initial = seed();
    const oldResult = scheduleReview(initial.schedule, 3, now);
    mock.invoke.mockResolvedValueOnce(httpError(502));
    const { repository } = await import('../src/lib/repository');
    await repository.rateCard(initial, 3);
    const latest = scheduleReview(oldResult, 4, new Date(oldResult.due));
    mock.rows = { decks: [{ ...deck }], cards: [{ ...initial, card_schedules: { schedule: latest, version: 8 } }], review_logs: [] };
    expect((await repository.load()).cards[0].version).toBe(8);
    mock.invoke.mockResolvedValueOnce({ data: { schedule: oldResult, version: 1, duplicate: true }, error: null });
    expect(await repository.syncPending()).toEqual({ sent: 1, conflicts: 0 });
    expect(stored().pending).toHaveLength(0);
    expect(stored().cards[0].version).toBe(8);
    expect(stored().cards[0].schedule).toEqual(latest);
  });

  it('stops a stale dependent chain and requires explicit recovery before replacing local events', async () => {
    const initial = seed();
    vi.stubGlobal('navigator', { onLine: false });
    const { repository } = await import('../src/lib/repository');
    await repository.rateCard(initial, 1);
    await repository.rateCard(structuredClone(stored().cards[0]), 3);
    expect(stored().pending).toHaveLength(2);
    expect(stored().pending.map((event) => event.expected_version)).toEqual([0, 1]);
    vi.stubGlobal('navigator', { onLine: true });
    mock.invoke.mockResolvedValueOnce(httpError(409));

    expect(await repository.syncPending()).toEqual({ sent: 0, conflicts: 2 });
    expect(mock.invoke).toHaveBeenCalledTimes(1);
    expect(stored().pending.every((event) => event.conflict)).toBe(true);
    expect(stored().cards[0].version).toBe(2);
    expect(await repository.syncPending()).toEqual({ sent: 0, conflicts: 2 });
    expect(mock.invoke).toHaveBeenCalledTimes(1);

    const authoritative = { ...initial, version: 8, schedule: scheduleReview(initial.schedule, 4, now) };
    mock.rows = { decks: [{ ...deck }], cards: [{ ...authoritative, card_schedules: { schedule: authoritative.schedule, version: 8 } }], review_logs: [] };
    const loaded = await repository.load();
    expect(loaded.cards[0].version).toBe(8);
    expect(stored().pending).toHaveLength(2);
    await repository.discardConflicts();
    expect(stored().pending).toHaveLength(0);
    expect(stored().cards[0].schedule).toEqual(authoritative.schedule);
    expect(stored().cards[0].version).toBe(8);
  });
});

describe('cache isolation and complete libraries', () => {
  it('uses only the authenticated account cache offline, never demo or another account', async () => {
    seed('user-a', card('private-a'));
    mock.networkFailure = true;
    const { repository, clearUserCache } = await import('../src/lib/repository');
    const a = await repository.load();
    expect(a.offline).toBe(true);
    expect(a.cards.map((item) => item.id)).toEqual(['private-a']);

    mock.userId = 'user-b';
    await expect(repository.load()).rejects.toThrow('Failed to fetch');
    seed('user-b', card('private-b'));
    expect((await repository.load()).cards.map((item) => item.id)).toEqual(['private-b']);
    await clearUserCache('user-a');
    expect(mock.cache.has('user-a')).toBe(false);
    expect(mock.cache.has('user-b')).toBe(true);
    mock.userId = null;
    await expect(repository.load()).rejects.toThrow('Connectez-vous');
  });

  it('paginates all cards and decks even below a 500-row API cap, with the last 1000 logs bounded', async () => {
    mock.maxRows = 200;
    const sourceCard = card();
    mock.rows = {
      decks: Array.from({ length: 1003 }, (_, index) => ({ ...deck, id: `deck-${index}` })),
      cards: Array.from({ length: 1207 }, (_, index) => ({ ...sourceCard, id: `card-${index}`, card_schedules: index % 2 ? [{ schedule: sourceCard.schedule, version: 0 }] : { schedule: sourceCard.schedule, version: 0 } })),
      review_logs: Array.from({ length: 1500 }, (_, index) => ({ id: `log-${index}`, card_id: 'card-a', client_event_id: `event-${index}`, rating: 3, reviewed_at: now.toISOString(), before_schedule: sourceCard.schedule, after_schedule: sourceCard.schedule })),
    };
    const { repository } = await import('../src/lib/repository');
    const result = await repository.load();
    expect(result.decks).toHaveLength(1003);
    expect(result.cards).toHaveLength(1207);
    expect(new Set(result.cards.map((item) => item.id)).size).toBe(1207);
    expect(result.cards[1206].schedule).toEqual(sourceCard.schedule);
    expect(result.reviews).toHaveLength(1000);
    expect(mock.ranges.filter((range) => range.table === 'cards').map((range) => range.from)).toEqual([0, 200, 400, 600, 800, 1000, 1200]);
    expect(mock.ranges.filter((range) => range.table === 'review_logs').at(-1)?.to).toBe(999);
  });
});
