import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';
import { VitePWA } from 'vite-plugin-pwa';

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '');
  const base = env.VITE_BASE_PATH || '/';
  return {
    base,
    plugins: [react(), tailwindcss(), VitePWA({
      registerType: 'prompt',
      includeAssets: ['icons/*.png', 'icons/*.svg', 'curriculum/manifest.json'],
      manifest: {
        id: base, name: 'Medora — Apprendre pour soigner', short_name: 'Medora',
        description: 'Révisions médicales par rappel actif et répétition espacée FSRS.',
        lang: 'fr', start_url: base, scope: base, display: 'standalone',
        orientation: 'portrait-primary', theme_color: '#f5f6f8', background_color: '#f5f6f8',
        icons: [
          { src: 'icons/icon-192.png', sizes: '192x192', type: 'image/png', purpose: 'any' },
          { src: 'icons/icon-512.png', sizes: '512x512', type: 'image/png', purpose: 'any' },
          { src: 'icons/maskable-512.png', sizes: '512x512', type: 'image/png', purpose: 'maskable' },
        ],
      },
      workbox: {
        globPatterns: ['**/*.{js,css,html,png,svg,ico,woff2}'],
        maximumFileSizeToCacheInBytes: 3 * 1024 * 1024,
        navigateFallback: 'index.html',
        cleanupOutdatedCaches: true,
        // No runtime API caching: authenticated data lives in a user-scoped IndexedDB store.
        runtimeCaching: [
          {
            urlPattern: ({ url, sameOrigin }) => sameOrigin && /\/curriculum\/(?:lessons|training)\/[^/]+\.json$/.test(url.pathname),
            handler: 'NetworkFirst',
            options: { cacheName: 'medora-curriculum-v2', networkTimeoutSeconds: 3, cacheableResponse: { statuses: [200] } },
          },
          {
            urlPattern: ({ url, sameOrigin }) => sameOrigin && /\/curriculum\/assets\//.test(url.pathname),
            handler: 'CacheFirst',
            options: { cacheName: 'medora-curriculum-v2', cacheableResponse: { statuses: [200] } },
          },
        ],
      },
    })],
    build: { chunkSizeWarningLimit: 900 },
  };
});
