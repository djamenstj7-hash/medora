# Medora

Une PWA de révision médicale en français, conçue pour l’iPhone : répétition espacée FSRS, rappel actif, cours transformés en cas cliniques et QCM, et explications évaluées en mode Feynman.

**Le frontend est entièrement statique et se déploie sur GitHub Pages.** Supabase héberge l’authentification, la base privée, les documents et les Edge Functions qui appellent OpenAI. Aucune clé IA ne va dans le navigateur.

## Version 3 : MED_ENGINE sur iPhone

Cette version conserve les 69 cours et tous les outils Medora, et ajoute **Bibliothèque → MED_ENGINE** : 141 chapitres de 13 UE, 15 592 notes et 25 753 cartes de rappel indépendantes (textes à trous, zones et légendes sont déclinés par cible). Les 15 605 enregistrements de cartes d’origine sont conservés dans les paquets JSON exportables.

Les huit formats sont QRM, QRU, recto-verso, texte à trous, QROC, repérage sur image, planche à légender et lexique. Les corrections par proposition, sources, clés officielles ou déduites, étymologies et avertissements restent visibles. Les 2 752 variantes d’annales et 82 variantes signalées comme non vérifiées gardent leur provenance.

Les séances **Bachoter**, **Annales** et **Simulation** ont une reprise sauvegardée et un chronomètre qui se met en pause quand l’application passe en arrière-plan. Elles n’altèrent pas les échéances FSRS. L’ajout à FSRS crée un nouveau deck en brouillon, isolé par compte et idempotent ; les cartes visuelles impossibles à évaluer faute d’image restent consultables dans le chapitre. Les notes, favoris et activités utilisent le suivi privé existant. Quinze schémas HTML, avec leurs explications, s’ouvrent dans un cadre isolé du compte.

**Limite des fichiers fournis :** les 752 fichiers ont été repris sans modifier leurs octets, dont 438 images PNG/SVG. Les paquets référencent aussi 8 699 figures absentes du Drive, réparties dans 135 chapitres ; 19 695 variantes citent au moins une de ces figures. Ces absences sont signalées et les images ne sont pas inventées. Les exercices qui dépendent d’une image absente ne sont pas notés comme une réussite ou un échec.

[Installer la version 3 depuis un iPhone](docs/MISE-A-JOUR-IPHONE-V3.md) · [Traçabilité et limites d’import](docs/IMPORT-MED-ENGINE.md). La livraison comprend un ZIP principal et des ZIP de contenu complémentaires, chacun adapté à l’envoi par navigateur GitHub. Le workflow iPhone vérifie leurs empreintes avant de les assembler. Un accès à l’IA n’est pas nécessaire pour les contenus préécrits ; la génération et Feynman conservent leur fournisseur configuré.

## Version 2 : le programme MED2 dans Medora

Cette version ajoute le contenu de l’ancien site MED2 et ses outils de travail, en conservant les quatre onglets principaux et les fonctions Medora existantes : decks personnels, ingestion texte/PDF, génération IA, mode Feynman, révisions FSRS et synchronisation des révisions hors connexion.

Les nouveaux espaces se trouvent dans **Bibliothèque → Cours MED2 / Entraînement / Suivi & planning** :

- **69 cours et 484 chapitres**, avec synthèses, illustrations, notes, favoris, réglages de lecture et reprise de position ; le catalogue recense 14 matières et 115 ressources, dont certaines sont des références sans cours rédigé fourni.
- **2 307 QCM de cours actifs, 897 QROC, 51 exercices de rédaction et 1 764 flashcards**, avec corrigés et évaluations de cours. Les questions retirées sont conservées dans les données source mais écartées de l’entraînement.
- **1 314 questions isolées et 91 dossiers cliniques actifs** pour des sessions chronométrées ou libres, la reprise d’une session, une correction en fin d’épreuve et le travail des erreurs. Certaines questions de cours proviennent de la même banque ; ces chiffres ne doivent pas être additionnés pour compter des questions uniques.
- Un **planning entrelaçant les matières**, adapté au temps disponible et aux dates d’examen modifiables, avec suivi des réponses, lectures et autoévaluations.
- L’**ajout des cartes d’un cours à un nouveau deck FSRS**, en brouillon à valider, ainsi qu’un accès au mode Feynman depuis le lecteur.
- Un export et un import de progression, la reprise d’une ancienne sauvegarde MED2, et le téléchargement du programme intégré pour le hors connexion.

Les QROC proposent un repérage lexical et une autoévaluation, pas une notation clinique automatique. Les supports et corrections sont ceux du programme fourni ; ils restent à confronter aux référentiels. Le planning affiche les dates du programme 2026–2027, à vérifier dans les réglages d’examen.

**Medora déjà installée ?** Suivez [la mise à jour sur iPhone](docs/MISE-A-JOUR-IPHONE-V2.md). Elle utilise le même dépôt, le même projet Supabase et le workflow existant. La case de mise à jour Supabase doit rester cochée pour appliquer la nouvelle migration. La progression personnelle n’est pas incluse dans le ZIP source.

### Correctif 2.0.1

Les erreurs OpenAI indiquent désormais si le problème concerne la clé, les droits, le modèle, la facturation API ou une limite temporaire. Les erreurs de connexion Supabase sont expliquées en français. Voir [le diagnostic IA](docs/DEPANNAGE-IA.md). Ce correctif nécessite le redéploiement des Edge Functions avec le workflow iPhone, case Supabase cochée.

## Installation uniquement sur iPhone

Suivez [le guide iPhone](docs/INSTALLATION-IPHONE.md) : le ZIP reste dans le dépôt et GitHub Actions installe Supabase puis publie le site. Aucun ordinateur ni terminal local n’est nécessaire.

## Démarrage local

Prérequis : Node.js 22 et npm.

```bash
npm ci
npm run dev
```

Sans configuration Supabase, l’application démarre en démonstration avec des cartes et des données locales. Pour utiliser votre compte et vos cours, suivez [l’installation complète](docs/INSTALLATION.md), dans l’ordre.

```bash
npm test
npm run build
npm run preview
```

Le service worker est produit lors du build. Utilisez `npm run preview` pour tester la PWA construite ; le serveur de développement ne reproduit pas son cache de production.

## Dossiers à envoyer sur GitHub

Placez le **contenu de ce dossier à la racine du dépôt**, avec les fichiers cachés :

```text
medora/
├── .github/workflows/deploy.yml   # Vérification puis publication Pages
├── .env.example                  # Modèle de configuration publique
├── docs/                         # Installation, architecture et contrats backend
├── public/                       # Icônes iOS et fichiers statiques
│   └── curriculum/               # Cours MED2, banques d’exercices et illustrations
├── src/                          # Application React et moteur de révision
├── supabase/
│   ├── functions/                # Appels IA et révisions protégés
│   ├── migrations/               # Schéma PostgreSQL et politiques RLS
│   └── tests/                    # Vérification de l’isolation des données
├── index.html                    # Balises iOS
├── package.json
├── package-lock.json
└── vite.config.ts                # Manifest, service worker et chemin Pages
```

N’envoyez pas `node_modules/`, `dist/` ou `.env`. Le dossier `.github` doit être présent pour que le déploiement fonctionne.

Ce transfert de dossiers concerne la méthode de développement classique. Pour la méthode iPhone, gardez **`medora-livraison.zip` entier à la racine du dépôt** : le workflow d’installation extrait son dossier `medora/`. Les [instructions iPhone](docs/INSTALLATION-IPHONE.md) donnent les étapes adaptées.

## Parcours de livraison

1. Exécuter la démonstration localement.
2. Créer le dépôt GitHub et le projet Supabase.
3. Appliquer la migration et déployer les Edge Functions.
4. Configurer les URL d’authentification et les variables publiques GitHub.
5. Activer GitHub Pages avec la source **GitHub Actions**, puis pousser sur `main`.
6. Vérifier le parcours connecté et ajouter le site à l’écran d’accueil de l’iPhone.

Les commandes et les valeurs à remplacer sont dans [INSTALLATION.md](docs/INSTALLATION.md). Les choix techniques sont décrits dans [ARCHITECTURE.md](docs/ARCHITECTURE.md).

La nouvelle progression MED2 utilise des événements privés synchronisés avec Supabase. L’installation de cartes de cours est idempotente et ne modifie pas les decks précédents. Les tables ajoutées, l’import de sauvegarde et les limites de restauration sont décrits dans [MIGRATION-MED2.md](docs/MIGRATION-MED2.md).

## Périmètre

Les révisions déjà chargées peuvent être effectuées hors connexion ; l’ingestion et les évaluations IA nécessitent une connexion. Le texte et les PDF contenant du texte sont pris en charge. Les PDF scannés nécessitent un OCR externe, qui n’est pas fourni.

Le téléchargement du programme dans les réglages prépare aussi les cours MED2 et illustrations pour le hors connexion. Il ne télécharge pas les PDF ou les liens externes du catalogue. La synchronisation s’effectue quand l’application est ouverte et connectée ; gardez également une sauvegarde JSON des données locales.

Les contenus médicaux de démonstration sont illustratifs. Les cartes générées sont proposées à la validation de l’étudiant ; elles ne constituent pas une référence clinique. Le code est fourni sans secrets : le branchement et la vérification d’un véritable projet Supabase/OpenAI sont à effectuer avec vos comptes.

## Aperçus et vérifications

[Aperçu iPhone](docs/v3-iphone-dashboard.png) · [Lecteur de cours](docs/v2-iphone-reader.png) · [Planning](docs/v2-iphone-planning.png) · [Vérifications effectuées](docs/VERIFICATION.md)

Licence : [MIT](LICENSE).
