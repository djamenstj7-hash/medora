# Medora

Une PWA de révision médicale en français, conçue pour l’iPhone : répétition espacée FSRS, rappel actif, cours transformés en cas cliniques et QCM, et explications évaluées en mode Feynman.

**Le frontend est entièrement statique et se déploie sur GitHub Pages.** Supabase héberge l’authentification, la base privée, les documents et les Edge Functions qui appellent OpenAI. Aucune clé IA ne va dans le navigateur.

## Installation uniquement sur iPhone

Suivez [le guide iPhone](docs/INSTALLATION-IPHONE.md) : le ZIP reste dans le dépôt et GitHub Actions installe Supabase puis publie le site. Aucun ordinateur ni terminal local n’est nécessaire.

## Démarrage local

Prérequis : Node.js 22 et npm.

```bash
npm ci
npm run dev
```

Sans configuration Supabase, l’application démarre en démonstration avec des cartes et des données locales. Pour utiliser votre compte et vos cours, suivez [l’installation complète](docs/INSTALLATION.md), dans l’ordre.

```bash
npm test
npm run build
npm run preview
```

Le service worker est produit lors du build. Utilisez `npm run preview` pour tester la PWA construite ; le serveur de développement ne reproduit pas son cache de production.

## Dossiers à envoyer sur GitHub

Placez le **contenu de ce dossier à la racine du dépôt**, avec les fichiers cachés :

```text
medora/
├── .github/workflows/deploy.yml   # Vérification puis publication Pages
├── .env.example                  # Modèle de configuration publique
├── docs/                         # Installation, architecture et contrats backend
├── public/                       # Icônes iOS et fichiers statiques
├── src/                          # Application React et moteur de révision
├── supabase/
│   ├── functions/                # Appels IA et révisions protégés
│   ├── migrations/               # Schéma PostgreSQL et politiques RLS
│   └── tests/                    # Vérification de l’isolation des données
├── index.html                    # Balises iOS
├── package.json
├── package-lock.json
└── vite.config.ts                # Manifest, service worker et chemin Pages
```

N’envoyez pas `node_modules/`, `dist/` ou `.env`. Le dossier `.github` doit être présent pour que le déploiement fonctionne.

## Parcours de livraison

1. Exécuter la démonstration localement.
2. Créer le dépôt GitHub et le projet Supabase.
3. Appliquer la migration et déployer les Edge Functions.
4. Configurer les URL d’authentification et les variables publiques GitHub.
5. Activer GitHub Pages avec la source **GitHub Actions**, puis pousser sur `main`.
6. Vérifier le parcours connecté et ajouter le site à l’écran d’accueil de l’iPhone.

Les commandes et les valeurs à remplacer sont dans [INSTALLATION.md](docs/INSTALLATION.md). Les choix techniques sont décrits dans [ARCHITECTURE.md](docs/ARCHITECTURE.md).

## Périmètre

Les révisions déjà chargées peuvent être effectuées hors connexion ; l’ingestion et les évaluations IA nécessitent une connexion. Le texte et les PDF contenant du texte sont pris en charge. Les PDF scannés nécessitent un OCR externe, qui n’est pas fourni.

Les contenus médicaux de démonstration sont illustratifs. Les cartes générées sont proposées à la validation de l’étudiant ; elles ne constituent pas une référence clinique. Le code est fourni sans secrets : le branchement et la vérification d’un véritable projet Supabase/OpenAI sont à effectuer avec vos comptes.

## Aperçus et vérifications

[Aperçu iPhone](docs/apercu-iphone.png) · [Aperçu grand écran](docs/apercu-desktop.png) · [Vérifications effectuées](docs/VERIFICATION.md)

Licence : [MIT](LICENSE).
