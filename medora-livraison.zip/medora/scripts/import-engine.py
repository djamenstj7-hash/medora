#!/usr/bin/env python3
"""Import the user-provided MED_ENGINE content tree without executing its code.
The original package JSON bytes are served unchanged. Browser views derive independent
cloze/zone/legend cards; their counts are computed here with the same rules.
Usage: python scripts/import-engine.py /workspace/med-engine-source
"""
from __future__ import annotations
from pathlib import Path
import argparse
import collections
import hashlib
import json
import re
import shutil
import tomllib
import unicodedata

ROOT = Path(__file__).resolve().parents[1]
KINDS = {'qrm', 'qru', 'basic', 'cloze', 'qroc', 'zone', 'lexique', 'legend'}
NOTICE = ('Contenu repris de MED_ENGINE, sans nouvelle validation médicale. Les avertissements, '
          'clés déduites, sources et mentions non vérifiées restent visibles. Les sources externes '
          'qui ne figurent pas dans les fichiers fournis restent des références.')


def dump(path: Path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, separators=(',', ':')) + '\n', encoding='utf-8')


def fold(value):
    return ''.join(c for c in unicodedata.normalize('NFKD', str(value).lower()) if not unicodedata.combining(c))


def annale(note):
    return any('annal' in str(tag).lower() for tag in note.get('tags', [])) or note.get('origine') == 'annale' or isinstance(note.get('source', {}).get('session_examen'), str)


def variant_count(note):
    fields = note.get('champs', {})
    kind = note.get('type')
    if kind == 'cloze':
        return max(1, len({int(index) for index in re.findall(r'\{\{c(\d+)::[\s\S]*?\}\}', str(fields.get('texte', '')))}))
    if kind == 'zone':
        wanted = fields.get('demandees', [])
        return max(1, sum(1 for zone in fields.get('zones', []) if not wanted or zone.get('cle') in wanted))
    if kind == 'legend':
        return max(1, len(fields.get('numeros', [])))
    return 1


def valid_member(path):
    return path and not Path(path).is_absolute() and not any(x in ('.', '..') for x in Path(path).parts) and '\\' not in path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', type=Path)
    parser.add_argument('--expected-files', type=int)
    args = parser.parse_args()
    source = args.source.resolve()
    assert source.is_dir(), 'The MED_ENGINE source tree is not available.'
    supplied = sorted(p for p in source.rglob('*') if p.is_file())
    if args.expected_files is not None:
        assert len(supplied) == args.expected_files, f'Incomplete source tree: {len(supplied)} files, expected {args.expected_files}.'
    for item in supplied:
        assert not item.is_symlink(), f'Symlink in source tree: {item}'
    packages = sorted((source / 'contenu/chapitres').glob('*/paquet.json'))
    assert packages, 'No chapter packages found.'
    out = ROOT / 'public/engine'
    if out.exists():
        shutil.rmtree(out)
    out.mkdir(parents=True)
    subjects, summaries, diagrams, scaffolds, resources = {}, [], [], [], {}
    note_ids, card_ids = collections.defaultdict(set), collections.defaultdict(set)
    missing, invalid, unsafe_svg, missing_sources, hashes = [], [], [], [], {}
    types, totals = collections.Counter(), collections.Counter()
    chapters = set()
    all_kinds = set()

    def copy(item, target):
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(item, target)
        raw = item.read_bytes()
        hashes[str(item.relative_to(source))] = hashlib.sha256(raw).hexdigest()
        if item.suffix.lower() == '.svg' and re.search(rb'<script|<foreignObject|\son[a-z]+\s*=|<!ENTITY|javascript:', raw, re.I):
            unsafe_svg.append(str(item.relative_to(source)))

    for package in packages:
        pack_id = package.parent.name
        assert re.fullmatch(r'[a-zA-Z0-9][a-zA-Z0-9_-]{0,119}', pack_id), f'Unsafe package ID {pack_id}'
        raw = json.loads(package.read_text(encoding='utf-8-sig'))
        assert raw.get('format') == 'hippocampe.paquet' and raw.get('format_version') == 1, f'Unsupported format in {pack_id}'
        notes = raw.get('notes', [])
        source_cards = raw.get('cards', [])
        local_note_ids = set()
        source_doc_ids = {item.get('id') for item in raw.get('source_documents', [])}
        for subject in raw.get('subjects', []):
            subjects.setdefault(subject['id'], subject)
        for chapter in raw.get('chapters', []):
            chapters.add(chapter['id'])
        copy(package, out / 'packs' / f'{pack_id}.json')
        readme = package.parent / 'LISEZ_MOI.md'
        readme_path = None
        if readme.exists():
            readme_path = f'assets/packs/{pack_id}/LISEZ_MOI.md'
            copy(readme, out / readme_path)
        media_root = package.parent / 'media'
        available_media = []
        if media_root.exists():
            for image in sorted(media_root.rglob('*')):
                if not image.is_file():
                    continue
                relative = image.relative_to(media_root).as_posix()
                available_media.append(relative)
                assert valid_member(relative), f'Unsafe media path in {pack_id}: {relative}'
                assert image.suffix.lower() in ('.png', '.svg', '.webp', '.jpg', '.jpeg', '.md', '.html', '.txt'), f'Unsupported media: {image}'
                copy(image, out / f'assets/packs/{pack_id}/media' / relative)
        pack_types = collections.Counter(note.get('type') for note in notes)
        tags = set()
        pack_variants = pack_annales = pack_unverified = 0
        for note in notes:
            note_id, kind = note.get('id'), note.get('type')
            if not isinstance(note_id, str) or not note_id or note_id in local_note_ids:
                invalid.append({'pack': pack_id, 'id': str(note_id), 'reason': 'Missing or duplicate note ID inside one package.'})
            local_note_ids.add(note_id)
            note_ids[str(note_id)].add(pack_id)
            all_kinds.add(kind)
            tags.update(str(tag) for tag in note.get('tags', []))
            count = variant_count(note)
            pack_variants += count
            if annale(note):
                pack_annales += count
            if 'a-relire' in note.get('tags', []):
                pack_unverified += count
            fields = note.get('champs', {})
            if kind not in KINDS:
                invalid.append({'pack': pack_id, 'id': note_id, 'reason': f'Unsupported note type {kind}'})
            if kind in ('qrm', 'qru'):
                options = fields.get('propositions', fields.get('options', []))
                answer = fields.get('vraies', fields.get('correct', []))
                answers = answer if isinstance(answer, list) else re.split(r'[\s,;]+', str(answer))
                for letter in answers:
                    if not isinstance(letter, str) or not re.fullmatch('[A-Z]', letter, re.I) or ord(letter.upper()) - 65 >= len(options):
                        invalid.append({'pack': pack_id, 'id': note_id, 'reason': f'Answer outside provided choices: {letter}'})
            for key in ('illustration', 'illustration_question', 'schema', 'image', 'planche'):
                filename = fields.get(key)
                if isinstance(filename, str) and filename:
                    member = filename.removeprefix('media/')
                    if not valid_member(member) or not (media_root / member).is_file():
                        missing.append({'pack': pack_id, 'file': filename})
            ref = note.get('source', {})
            if ref.get('source_id') and ref['source_id'] not in source_doc_ids:
                missing_sources.append({'pack': pack_id, 'noteId': note_id, 'sourceId': ref['source_id']})
        for card in source_cards:
            card_ids[str(card.get('id'))].add(pack_id)
            if card.get('note_id') not in local_note_ids:
                invalid.append({'pack': pack_id, 'id': str(card.get('id')), 'reason': 'Stored card references an absent note.'})
        subject_ids = list(dict.fromkeys(chapter.get('subject_id', '') for chapter in raw.get('chapters', [])))
        title = ' · '.join(chapter.get('nom', chapter['id']) for chapter in raw.get('chapters', [])) or pack_id
        summaries.append({
            'id': pack_id, 'title': title, 'subjectId': subject_ids[0] if subject_ids else '', 'subjectIds': subject_ids,
            'chapterIds': [chapter['id'] for chapter in raw.get('chapters', [])], 'noteCount': len(notes),
            'cardCount': pack_variants, 'sourceCardCount': len(source_cards), 'annaleCount': pack_annales,
            'unverifiedCount': pack_unverified, 'types': dict(pack_types), 'tags': sorted(tags),
            'searchText': fold(' '.join([title, pack_id] + [subject.get('nom', '') for subject in raw.get('subjects', [])] + sorted(tags))),
            'sourcePath': f'packs/{pack_id}.json', 'availableMedia': available_media, **({'readmePath': readme_path} if readme_path else {}),
        })
        types.update(pack_types)
        totals.update({'noteCount': len(notes), 'sourceCardCount': len(source_cards), 'cardCount': pack_variants, 'annaleCount': pack_annales, 'unverifiedCount': pack_unverified})
    for html in sorted((source / 'contenu/schemas_claude').glob('*/*.html')):
        relative = html.relative_to(source / 'contenu/schemas_claude')
        html_path = 'assets/diagrams/' + relative.as_posix()
        copy(html, out / html_path)
        markdown = html.with_suffix('.md')
        markdown_path = None
        if markdown.exists():
            markdown_path = 'assets/diagrams/' + markdown.relative_to(source / 'contenu/schemas_claude').as_posix()
            copy(markdown, out / markdown_path)
        diagrams.append({'id': relative.with_suffix('').as_posix().replace('/', ':'), 'title': html.stem.replace('-', ' ').capitalize(), 'subject': relative.parts[0], 'htmlPath': html_path, **({'markdownPath': markdown_path} if markdown_path else {})})
    for skeleton in sorted((source / 'contenu/squelettes').glob('*/paquet.json')):
        skeleton_id = skeleton.parent.name
        target_path = f'scaffolds/{skeleton_id}.json'
        copy(skeleton, out / target_path)
        skeleton_readme = skeleton.parent / 'LISEZ_MOI.md'
        if skeleton_readme.exists():
            copy(skeleton_readme, out / f'scaffolds/{skeleton_id}.md')
        scaffolds.append({'id': skeleton_id, 'path': target_path, 'data': json.loads(skeleton.read_text(encoding='utf-8-sig'))})
    for toml in sorted((source / 'med_engine/resources').glob('*.toml')):
        copy(toml, out / 'resources' / toml.name)
        resources[toml.stem] = tomllib.loads(toml.read_text(encoding='utf-8-sig'))
    missing = [dict(t) for t in sorted({tuple(sorted(item.items())) for item in missing})]
    audit = {'packCount': len(packages), **totals, 'subjectCount': len(subjects), 'chapterCount': len(chapters),
             'assetCount': sum(1 for p in (out / 'assets').rglob('*') if p.is_file()), 'types': dict(types),
             'missingAssets': missing, 'invalidNotes': invalid, 'unsafeSvg': unsafe_svg, 'missingSourceReferences': missing_sources,
             'duplicateNoteIds': [{'id': k, 'packs': sorted(v)} for k, v in sorted(note_ids.items()) if len(v) > 1],
             'duplicateCardIds': [{'id': k, 'packs': sorted(v)} for k, v in sorted(card_ids.items()) if len(v) > 1],
             'unknownTypes': sorted(all_kinds - KINDS), 'notice': NOTICE}
    dump(out / 'audit.json', audit)
    files = sorted([p.relative_to(out).as_posix() for p in out.rglob('*') if p.is_file()] + ['manifest.json'])
    revision = hashlib.sha256(json.dumps(hashes, sort_keys=True).encode()).hexdigest()[:20]
    manifest = {'schemaVersion': 1, 'revision': revision, 'sourceFolder': 'https://drive.google.com/drive/folders/19gMoAC7eJPwxv3xedxjjcgm0b8RNI12y',
                'subjects': sorted(subjects.values(), key=lambda subject: fold(subject['nom'])), 'packs': summaries,
                'diagrams': diagrams, 'files': files, 'scaffolds': scaffolds, 'resources': resources, 'audit': audit, 'notice': NOTICE}
    dump(out / 'manifest.json', manifest)
    dump(out / 'provenance.json', {'revision': revision, 'inputSha256': hashes})
    manifest['files'].append('provenance.json')
    manifest['files'].sort()
    dump(out / 'manifest.json', manifest)
    print(json.dumps({'revision': revision, **{k: audit[k] for k in ['packCount', 'chapterCount', 'subjectCount', 'noteCount', 'sourceCardCount', 'cardCount', 'annaleCount', 'assetCount']}, 'missingAssets': len(missing), 'invalidNotes': len(invalid), 'unsafeSvg': len(unsafe_svg)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
