#!/usr/bin/env python3
"""Deterministic lossless MED2 data conversion (stdlib only, no imported JS execution).
Usage: python3 scripts/import-med2.py /path/to/fichiers_a_envoyer
The original authoring assertions are preserved; no medical answers are inferred or revalidated.
"""
from pathlib import Path
import argparse
import collections
import copy
import hashlib
import json
import re
import shutil
import unicodedata

ROOT = Path(__file__).resolve().parents[1]
COLORS = ['#6371E8', '#DC6978', '#648E72', '#AC7BC8', '#5C9FB8', '#C68E51', '#8A7CBB', '#5A9E9A', '#BE7199', '#6F96AD', '#8B9E5A', '#9C8B66', '#8395B0', '#A886A5']

def dump(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, separators=(',', ':')) + '\n', encoding='utf-8')

def slug_text(value):
    return ''.join(c for c in unicodedata.normalize('NFKD', value.lower()) if not unicodedata.combining(c))

def embedded(html, name):
    match = re.search(r'<script\b[^>]*id="default-' + re.escape(name) + r'"[^>]*>([\s\S]*?)</script>', html)
    if not match:
        raise ValueError('Missing embedded dataset: ' + name)
    return json.loads(match.group(1))

def visual_mapping(html):
    match = re.search(r'const V10_VISUALS = (\{[\s\S]*?\n  \});', html)
    value = re.sub(r'(?m)(^\s*|[,{]\s*)([a-zA-Z][\w-]*)(\s*:)', r'\1"\2"\3', match.group(1))
    value = re.sub(r',\s*([}\]])', r'\1', value)
    return json.loads(value)

def extract_diagrams(html):
    result = {}
    for block in re.findall(r'function v0[89]Diagram\(name\) \{([\s\S]*?)\n  \}', html):
        for match in re.finditer(r'(?:"([\w-]+)"|([\w-]+)):\s*\n?\s*\'((?:\\.|[^\'\\])*)\'', block):
            name = match.group(1) or match.group(2)
            value = match.group(3).replace("\\'", "'").replace('\\/', '/').replace('\\\\', '\\')
            if not value.startswith('<svg'):
                continue
            if re.search(r'<script|<foreignObject|\son[a-z]+\s*=|javascript:|https?://(?!www.w3.org/2000/svg)', value, re.I):
                raise ValueError('Unsafe diagram: ' + name)
            result[name] = value
    return result

def main():
    args = argparse.ArgumentParser(description=__doc__)
    args.add_argument('source', type=Path)
    source = args.parse_args().source
    out = ROOT / 'public/curriculum'
    html = (source / 'index.html').read_text(encoding='utf-8')
    pedagogy = json.loads((source / 'data/pedagogie.json').read_text(encoding='utf-8'))
    training = json.loads((source / 'data/entrainements.json').read_text(encoding='utf-8'))
    catalogue = embedded(html, 'catalogue')
    exams = embedded(html, 'examens')
    modalities = embedded(html, 'modalites')
    visuals = visual_mapping(html)
    diagrams = extract_diagrams(html)
    assets = out / 'assets'
    assets.mkdir(parents=True, exist_ok=True)
    for asset in (source / 'Assets').rglob('*'):
        if asset.is_file() and not asset.is_symlink():
            suffix = asset.suffix.lower()
            if suffix not in ('.webp', '.png', '.jpg', '.jpeg', '.svg', '.woff2', '.txt'):
                raise ValueError('Unsupported asset: ' + str(asset))
            if suffix == '.svg' and re.search(r'<script|<foreignObject|\son[a-z]+\s*=|javascript:', asset.read_text(), re.I):
                raise ValueError('Unsafe SVG asset: ' + str(asset))
            target = assets / asset.relative_to(source)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(asset, target)
    for name, svg in diagrams.items():
        target = assets / 'Assets/diagrams' / (name + '.svg')
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(svg, encoding='utf-8')
    missing = set()
    invalid = []
    all_ids = set()
    question_counts = collections.Counter()
    lesson_summaries = []
    lessons = pedagogy['lessons']

    def mark_figure(figure):
        result = copy.deepcopy(figure)
        path = result.get('src', '')
        available = path.startswith('Assets/') and '..' not in Path(path).parts and (assets / path).is_file()
        if not available:
            missing.add(path)
            result['missing'] = True
        return result

    def question(raw, question_id, subject_id, lesson_id=None, chapter_index=None, parent_source=None, kind=None):
        q = copy.deepcopy(raw)
        q['id'] = question_id
        if raw.get('id'):
            q['originalId'] = raw['id']
        if question_id in all_ids:
            raise ValueError('Duplicate question ID: ' + question_id)
        all_ids.add(question_id)
        q['subjectId'] = subject_id
        effective_lesson = raw.get('lessonId', lesson_id)
        if effective_lesson:
            q['lessonId'] = effective_lesson
        if raw.get('sec') is not None:
            chapter_index = raw['sec']
        elif raw.get('chapter') is not None:
            chapter_index = raw['chapter']
        if chapter_index is not None:
            q['chapterIndex'] = chapter_index
        q['prompt'] = raw.get('q', raw.get('question', ''))
        q['options'] = raw.get('choices', raw.get('options', []))
        answer = raw.get('correct', raw.get('answer', [])) if not kind else []
        q['correct'] = answer if isinstance(answer, list) else [answer]
        q['format'] = kind or raw.get('format') or ('QRM' if len(q['correct']) > 1 else 'QRU')
        q['explanation'] = raw.get('why', raw.get('explanation', raw.get('model', raw.get('answer', '') if kind else '')))
        if kind == 'QROC' and 'keys' in raw:
            q['expected'] = raw['keys']
        reference = raw.get('source') or (lessons.get(effective_lesson, {}).get('source') if effective_lesson else None) or parent_source
        if reference:
            q['source'] = copy.deepcopy(reference)
            if not isinstance(q['source'], dict):
                q['source'] = {'label': str(q['source'])}
            pages = raw.get('pages', raw.get('page'))
            if pages is not None:
                q['source']['pages'] = pages
        if raw.get('sourceUrl'):
            q.setdefault('source', {})['url'] = raw['sourceUrl']
        # Same origin bank question shares a canonical identifier for deduplicated practice.
        q['canonicalId'] = 'training:' + raw['bankId'] if raw.get('bankId') else ('training:' + raw['id'] if question_id.startswith('training:') and raw.get('id') else question_id)
        if q['format'] in ('QRU', 'QRM'):
            if not q['prompt'] or not q['options'] or not q['correct'] or any(type(n) is not int or n < 0 or n >= len(q['options']) for n in q['correct']):
                invalid.append({'id': question_id, 'reason': 'Malformed choice answer in original source'})
            elif q['format'] == 'QRU' and len(q['correct']) != 1:
                invalid.append({'id': question_id, 'reason': 'QRU has multiple answers in original source'})
        question_counts['retired'] += bool(q.get('retired'))
        return q

    for lesson_id, original in lessons.items():
        lesson = copy.deepcopy(original)
        chapter_qcm = {}
        chapter_cards = {}
        for index, practice in enumerate(lesson['chapterPractice']):
            for number in practice['qcm']:
                chapter_qcm.setdefault(number, index)
            for number in practice['cards']:
                chapter_cards.setdefault(number, index)
        lesson['questions'] = [question(q, f'lesson:{lesson_id}:qcm:{i}', lesson['subject'], lesson_id, chapter_qcm.get(i), lesson['source']) for i, q in enumerate(lesson.pop('qcm'))]
        lesson['qroc'] = [question(q, f'lesson:{lesson_id}:qroc:{i}', lesson['subject'], lesson_id, parent_source=lesson['source'], kind='QROC') for i, q in enumerate(lesson.get('qroc', []))]
        lesson['writing'] = [question(q, f'lesson:{lesson_id}:writing:{i}', lesson['subject'], lesson_id, parent_source=lesson['source'], kind=q.get('format', 'QR')) for i, q in enumerate(lesson.get('writing', []))]
        for i, card in enumerate(lesson['flashcards']):
            card['id'] = f'lesson:{lesson_id}:card:{i}'
            if i in chapter_cards:
                card['chapterIndex'] = chapter_cards[i]
        for section in lesson['sections']:
            section['figures'] = [mark_figure(figure) for figure in section.get('figures', [])]
            visual = section.get('visual')
            if visual:
                if visual in visuals:
                    figure = mark_figure(visuals[visual])
                    figure['visualId'] = visual
                    if visual in diagrams:
                        figure['fallbackSrc'] = f'Assets/diagrams/{visual}.svg'
                    if not any(item['src'] == figure['src'] for item in section['figures']):
                        section['figures'].append(figure)
                elif visual in diagrams:
                    section['figures'].append({'src': f'Assets/diagrams/{visual}.svg', 'caption': 'Schéma pédagogique de l’ancienne version', 'visualId': visual})
                else:
                    missing.add('visual:' + visual)
        dump(out / 'lessons' / (lesson_id + '.json'), lesson)
        summary = {key: lesson[key] for key in ('id', 'subject', 'title', 'courseName', 'teacher')}
        if lesson.get('date'):
            summary['date'] = lesson['date']
        summary.update(subjectId=lesson['subject'], sectionCount=len(lesson['sections']), questionCount=len(lesson['questions']), activeQuestionCount=sum(not q.get('retired') for q in lesson['questions']), cardCount=len(lesson['flashcards']), qrocCount=len(lesson['qroc']), writingCount=len(lesson['writing']), chapterTitles=[s['heading'] for s in lesson['sections']])
        # Full narrative text remains lazy. Index titles/teacher/chapter and summary words only.
        summary['searchText'] = slug_text(' '.join([lesson['title'], lesson['courseName'], lesson['teacher']] + summary['chapterTitles'] + [s['name'] + ' ' + s['detail'] for s in lesson['summary']]))
        lesson_summaries.append(summary)

    subject_training = {}
    for subject_id, original in training['subjects'].items():
        bank = copy.deepcopy(original)
        bank['subjectId'] = subject_id
        bank['questions'] = [question(q, 'training:' + q.get('id', f'{subject_id}:qi:{i}'), subject_id, bank.get('lessonId'), parent_source=bank.get('source')) for i, q in enumerate(bank.pop('qi'))]
        for i, case in enumerate(bank['cases']):
            case_id = 'case:' + case.get('id', f'{subject_id}:{i}')
            case['originalId'] = case.get('id')
            case['id'] = case_id
            case['questions'] = [question(q, 'training:' + q.get('id', f'{case_id}:q:{j}'), subject_id, case.get('lessonId', bank.get('lessonId')), parent_source=case.get('source', bank.get('source'))) for j, q in enumerate(case['questions'])]
            if case.get('retired'):
                for q in case['questions']:
                    if not q.get('retired'):
                        question_counts['retired'] += 1
                    q['retired'] = True
        dump(out / 'training' / (subject_id + '.json'), bank)
        subject_training[subject_id] = bank

    subjects = []
    for i, original in enumerate(catalogue['subjects']):
        subject = copy.deepcopy(original)
        subject['color'] = COLORS[i % len(COLORS)]
        subject['lessonCount'] = sum(l['subject'] == subject['id'] for l in lesson_summaries)
        bank = subject_training.get(subject['id'], {})
        subject['trainingCount'] = sum(not q.get('retired') for q in bank.get('questions', []))
        subject['caseCount'] = sum(not c.get('retired') for c in bank.get('cases', []))
        subjects.append(subject)
    resources = []
    for original in catalogue['resources']:
        resource = copy.deepcopy(original)
        resource['lessonAvailable'] = resource['id'] in lessons
        if resource['lessonAvailable']:
            resource['source'] = lessons[resource['id']]['source']
            if resource['source'].get('url'):
                resource['url'] = resource['source']['url']
        resources.append(resource)
    audit = {
        'lessonCount': len(lessons), 'subjectCount': len(subjects), 'resourceCount': len(resources),
        'flashcardCount': sum(l['cardCount'] for l in lesson_summaries),
        'lessonQuestionCount': sum(l['questionCount'] for l in lesson_summaries),
        'activeLessonQuestionCount': sum(l['activeQuestionCount'] for l in lesson_summaries),
        'qrocCount': sum(l['qrocCount'] for l in lesson_summaries), 'writingCount': sum(l['writingCount'] for l in lesson_summaries),
        'trainingQuestionCount': sum(len(b['questions']) for b in subject_training.values()),
        'activeTrainingQuestionCount': sum(sum(not q.get('retired') for q in b['questions']) for b in subject_training.values()),
        'caseCount': sum(len(b['cases']) for b in subject_training.values()),
        'caseQuestionCount': sum(len(c['questions']) for b in subject_training.values() for c in b['cases']),
        'retiredQuestionCount': question_counts['retired'],
        'copiedAssetCount': sum(f.is_file() for f in assets.rglob('*')),
        'diagramCount': len(diagrams), 'missingAssets': sorted(missing), 'invalidQuestions': invalid,
        'notice': 'Contenu repris de MED2 v0.30, sans nouvelle validation médicale. Les questions retirées sont conservées pour traçabilité et exclues des séances. Les références sans fichier fourni restent des références ; aucun cours ou corrigé manquant n’a été inventé.',
        'inputHashes': {name: hashlib.sha256((source / name).read_bytes()).hexdigest() for name in ('index.html', 'data/pedagogie.json', 'data/entrainements.json')},
    }
    manifest = {'schemaVersion': 1, 'revision': 'medora-med2-v030-1', 'scope': catalogue['scope'], 'sourceNotice': catalogue.get('sourceNotice', ''), 'subjects': subjects, 'lessons': lesson_summaries, 'resources': resources, 'exams': exams['exams'], 'timezone': exams['timezone'], 'examNotice': exams['notice'], 'modalities': modalities, 'audit': audit, 'trainingSubjectIds': list(subject_training), 'assetPaths': sorted(str(f.relative_to(assets)) for f in assets.rglob('*') if f.is_file()), 'visuals': visuals, 'sourceRevisions': {'catalogue': catalogue['revision'], 'pedagogy': pedagogy['revision'], 'training': training['revision'], 'exams': exams['revision'], 'modalities': modalities['revision']}, 'trainingDisclaimer': training.get('disclaimer', '')}
    dump(out / 'manifest.json', manifest)
    dump(out / 'audit.json', audit)
    print(json.dumps(audit, ensure_ascii=False, indent=2))
    if invalid:
        raise SystemExit('Source structural errors need explicit review; no answer was inferred.')

if __name__ == '__main__':
    main()
