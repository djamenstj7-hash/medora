#!/usr/bin/env python3
"""Verify and merge the additional ZIPs named by an iPhone delivery manifest."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import sys
import zipfile


PART_NAME = re.compile(r"medora-contenus-engine-[1-9][0-9]*\.zip\Z")
SHA256 = re.compile(r"[0-9a-fA-F]{64}\Z")
MAX_PARTS = 20
MAX_ENTRIES = 20_000
MAX_UNCOMPRESSED = 300 * 1024 * 1024


def extract_parts(source_root: Path, archive_root: Path) -> int:
    """Check the complete delivery before writing any additional file."""
    source_root = source_root.resolve()
    archive_root = archive_root.resolve()
    manifest = source_root / "medora" / "delivery-files.json"
    data = json.loads(manifest.read_text(encoding="utf-8"))
    parts = data.get("parts") if isinstance(data, dict) else None
    if not isinstance(parts, list) or len(parts) > MAX_PARTS:
        raise ValueError("Le manifeste de livraison doit contenir une liste de parties valide.")

    archives: list[Path] = []
    names: set[str] = set()
    for part in parts:
        if not isinstance(part, dict):
            raise ValueError("Une partie du manifeste est invalide.")
        name, digest = part.get("file"), part.get("sha256")
        if not isinstance(name, str) or not PART_NAME.fullmatch(name) or name in names:
            raise ValueError("Nom de partie invalide ou présent plusieurs fois.")
        if not isinstance(digest, str) or not SHA256.fullmatch(digest):
            raise ValueError(f"Empreinte SHA-256 invalide pour {name}.")
        names.add(name)
        archive = archive_root / name
        if archive.is_symlink() or not archive.is_file():
            raise ValueError(f"Partie manquante : {name}. Envoie tous les ZIP de cette livraison à la racine du dépôt.")
        with archive.open("rb") as stream:
            actual = hashlib.file_digest(stream, "sha256").hexdigest()
        if actual != digest.lower():
            raise ValueError(f"Le fichier {name} ne correspond pas à cette livraison. Remplace-le par le ZIP fourni avec le projet.")
        archives.append(archive)

    targets: set[Path] = set()
    directories: set[Path] = set()
    entry_count = total_size = 0
    for archive in archives:
        with zipfile.ZipFile(archive) as bundle:
            for entry in bundle.infolist():
                entry_count += 1
                total_size += entry.file_size
                if entry_count > MAX_ENTRIES or total_size > MAX_UNCOMPRESSED:
                    raise ValueError("Les parties dépassent la taille maximale d’une livraison.")
                path = PurePosixPath(entry.filename)
                if (not path.parts or path.parts[0] != "medora" or
                        any(part in {"", ".", ".."} for part in path.parts) or
                        "\\" in entry.filename or ":" in entry.filename or
                        stat.S_ISLNK(entry.external_attr >> 16)):
                    raise ValueError(f"Chemin de fichier interdit dans {archive.name}.")
                target = (source_root / Path(*path.parts)).resolve()
                if not target.is_relative_to(source_root):
                    raise ValueError(f"Chemin hors du projet dans {archive.name}.")
                for parent in target.parents:
                    if parent == source_root.parent:
                        break
                    if parent in targets or (parent.exists() and not parent.is_dir()):
                        raise ValueError("Une partie utilise un fichier comme dossier.")
                    directories.add(parent)
                if entry.is_dir():
                    if target in targets or (target.exists() and not target.is_dir()):
                        raise ValueError("Une partie contient un dossier incompatible avec le projet.")
                    directories.add(target)
                    continue
                if target.exists() or target in targets or target in directories:
                    raise ValueError(f"Une partie tente de remplacer un fichier existant : {path}.")
                targets.add(target)
            # Check archive CRCs before any additional files are extracted.
            if bundle.testzip() is not None:
                raise ValueError(f"Le ZIP {archive.name} est endommagé.")

    for archive in archives:
        with zipfile.ZipFile(archive) as bundle:
            for entry in bundle.infolist():
                target = source_root / Path(*PurePosixPath(entry.filename).parts)
                if entry.is_dir():
                    target.mkdir(parents=True, exist_ok=True)
                else:
                    target.parent.mkdir(parents=True, exist_ok=True)
                    with bundle.open(entry) as source, target.open("xb") as destination:
                        shutil.copyfileobj(source, destination)
    return len(targets)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-root", type=Path, required=True)
    parser.add_argument("--archive-root", type=Path, required=True)
    args = parser.parse_args()
    try:
        count = extract_parts(args.source_root, args.archive_root)
    except (ValueError, OSError, zipfile.BadZipFile, RuntimeError) as error:
        print(f"Livraison Medora incomplète ou invalide : {error}", file=sys.stderr)
        return 1
    print(f"Livraison vérifiée : {count} fichiers complémentaires extraits.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
