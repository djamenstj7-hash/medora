# Installation, dans l’ordre

Le code est prêt à construire. Pour activer les comptes et l’IA, il faut votre projet Supabase, une clé OpenAI avec facturation active, un compte GitHub et Node.js 22. Les commandes se lancent à la racine du dossier extrait, là où se trouve `package.json`.

Dans les exemples, remplacez `OWNER`, `REPO` et `PROJECT_REF` par vos propres valeurs. `PROJECT_REF` est l’identifiant du projet Supabase, visible dans son URL et ses paramètres.

## 1. Vérifier l’application localement

```bash
npm ci
npm test
npm run dev
```

Ouvrez l’adresse affichée par Vite, généralement `http://localhost:5173`. Sans `.env`, l’application utilise la démonstration locale. Aucun appel payant n’est effectué dans ce mode.

Le serveur de développement sert uniquement à travailler localement. Pour vérifier la version construite :

```bash
npm run build
npm run preview
```

## 2. Créer un projet Supabase dédié

Créez un nouveau projet dans [Supabase](https://supabase.com/dashboard). Conservez son mot de passe de base de données dans votre gestionnaire de mots de passe. Attendez que le projet soit disponible.

Dans les paramètres API du projet, relevez :

- l’URL du projet, par exemple `https://PROJECT_REF.supabase.co` ;
- la **clé publiable**, commençant habituellement par `sb_publishable_` ; l’ancienne clé publique `anon` reste utilisable.

La clé `service_role` ou une clé `sb_secret_…` ne doit jamais être utilisée comme clé frontend.

## 3. Installer le schéma et les règles de sécurité

Le CLI peut être utilisé via npm, sans installation globale :

```bash
npx supabase login
npx supabase link --project-ref PROJECT_REF
npx supabase db push
```

La connexion CLI peut ouvrir votre navigateur. Le rattachement demande éventuellement le mot de passe de la base. La migration crée les tables, les index, les politiques RLS, les fonctions SQL et le bucket privé `courses` avec ses politiques d’accès.

Utilisez un projet dédié : ce schéma est conçu pour une première installation. Ne collez pas une clé privilégiée dans le code React et ne désactivez pas la RLS pour résoudre un problème d’accès.

## 4. Configurer et déployer les fonctions IA

Créez localement le fichier `supabase/.env.local` suivant :

```dotenv
OPENAI_API_KEY=VOTRE_CLE_OPENAI
OPENAI_MODEL=gpt-4o-mini
ALLOWED_ORIGINS=https://OWNER.github.io,http://localhost:5173
```

La valeur `ALLOWED_ORIGINS` contient des **origines**, séparées par des virgules : aucun chemin `/REPO/` et aucune barre oblique finale. Avec un domaine personnalisé, ajoutez par exemple `https://revision.exemple.fr`. Si vous testez via `npm run preview`, ajoutez aussi `http://localhost:4173`.

Le modèle peut être remplacé par un modèle OpenAI compatible avec les sorties structurées de Chat Completions. La facturation OpenAI est distincte d’un abonnement ChatGPT.

Chargez les secrets puis déployez :

```bash
npx supabase secrets set --env-file supabase/.env.local
npx supabase functions deploy generate-quiz --use-api
npx supabase functions deploy evaluate-feynman --use-api
npx supabase functions deploy submit-review --use-api
```

L’option `--use-api` utilise la construction distante des fonctions et évite d’installer Docker pour ce déploiement. `SUPABASE_URL` et `SUPABASE_SERVICE_ROLE_KEY` sont fournis par l’environnement Edge de Supabase ; ne les ajoutez pas au frontend. Les trois fonctions vérifient la session avec `auth.getUser(jwt)` côté serveur. Leur configuration `verify_jwt = false` désactive uniquement la vérification historique de la passerelle, pas l’authentification réalisée par le code.

Le fichier de secrets est ignoré par Git. Vérifiez néanmoins les fichiers sélectionnés avant votre premier commit.

## 5. Configurer l’authentification e-mail et mot de passe

Dans **Authentication → Sign In / Providers**, activez le fournisseur e-mail. L’application permet de créer un compte puis de se connecter avec son e-mail et son mot de passe.

Conservez la confirmation des e-mails et le modèle **Confirm signup** par défaut, qui utilise `{{ .ConfirmationURL }}`. Lors de la première inscription, ouvrez le lien reçu pour confirmer le compte. Le lien doit revenir vers l’URL de votre application.

Dans **Authentication → URL Configuration**, configurez :

| Paramètre | Valeur pour un dépôt standard |
|---|---|
| Site URL | `https://OWNER.github.io/REPO/` |
| Redirect URLs | `https://OWNER.github.io/REPO/` et `http://localhost:5173/` |

Pour un dépôt nommé `OWNER.github.io`, ou un domaine personnalisé, l’URL du site est à la racine, sans `/REPO/`. L’application transmet son URL de base comme destination de confirmation : elle doit figurer dans les URL autorisées. Ajoutez aussi `http://localhost:4173/` si vous vérifiez le site avec `npm run preview`.

Pour un usage au-delà des premiers essais, configurez un fournisseur SMTP dans Supabase. L’envoi e-mail intégré possède des restrictions et des limites de fréquence ; une absence d’e-mail ne signifie pas nécessairement que l’application est défaillante.

## 6. Brancher le frontend en local

Copiez `.env.example` vers `.env`, puis remplacez les valeurs :

```dotenv
VITE_SUPABASE_URL=https://PROJECT_REF.supabase.co
VITE_SUPABASE_PUBLISHABLE_KEY=VOTRE_CLE_PUBLIABLE
VITE_BASE_PATH=/
```

Redémarrez Vite après chaque modification d’environnement. Connectez-vous et testez la génération avec un court extrait de cours. Les données de démonstration restent distinctes du compte connecté.

Ces deux valeurs Supabase sont publiques par conception. La clé OpenAI et la clé privilégiée Supabase ne doivent figurer dans aucune variable `VITE_*`.

## 7. Préparer GitHub Pages

Créez un dépôt GitHub vide, par exemple `medora`, avec la branche principale `main`. GitHub Pages est disponible sur les dépôts publics ; pour un dépôt privé, vérifiez que votre offre GitHub le permet.

Dans **Settings → Pages**, choisissez la source **GitHub Actions**.

Dans **Settings → Secrets and variables → Actions → Variables**, créez ces deux **Repository variables** :

| Nom | Valeur |
|---|---|
| `VITE_SUPABASE_URL` | `https://PROJECT_REF.supabase.co` |
| `VITE_SUPABASE_PUBLISHABLE_KEY` | Votre clé publique Supabase |

Le workflow refuse de publier si l’une manque. Ne mettez pas les secrets OpenAI dans GitHub : ils restent dans Supabase.

## 8. Envoyer les dossiers et publier

Le contenu du dossier extrait doit être à la racine du dépôt. Il faut voir `package.json` directement, et non un sous-dossier supplémentaire `medora/package.json`.

Depuis ce dossier :

```bash
git init -b main
git add .
git status
git commit -m "Initialiser Medora"
git remote add origin https://github.com/OWNER/REPO.git
git push -u origin main
```

Si vous avez déjà cloné le dépôt, utilisez simplement `git add .`, puis `git commit` et `git push` ; ne relancez pas `git init` ni `git remote add`.

Le dossier caché `.github/workflows/` doit être inclus. L’envoi via Git évite de l’oublier. L’onglet **Actions** affiche l’installation des dépendances, les tests, la construction puis la publication. L’URL finale apparaît dans **Settings → Pages**.

Le chemin de base est calculé automatiquement par le workflow à partir de la configuration Pages : `/REPO/` pour un site de dépôt, `/` à la racine. Il sert aussi au manifest et au service worker. Si vous changez de domaine, mettez à jour Supabase Auth et `ALLOWED_ORIGINS`, puis relancez le workflow.

## 9. Vérifier sur iPhone

Ouvrez l’URL HTTPS dans Safari, puis **Partager → Sur l’écran d’accueil**. Lancez Medora depuis son icône. Les encoches, l’indicateur d’accueil, les zones tactiles et le clavier sont pris en compte.

Effectuez ces vérifications avec votre configuration :

1. Créer un compte, confirmer son e-mail et se connecter.
2. Importer un court texte et générer un deck.
3. Lire les cartes en brouillon, puis valider le deck pour les révisions.
4. Révéler une réponse, choisir une appréciation FSRS et vérifier le prochain passage.
5. Demander une correction Feynman et lire les erreurs signalées.
6. Charger des cartes, passer en mode avion, effectuer une révision puis rouvrir l’application avec une connexion.

L’ingestion et l’IA exigent une connexion. Le hors connexion concerne les cartes déjà chargées et leurs évaluations ; la synchronisation a lieu à l’ouverture ou au retour au premier plan. iOS peut supprimer le stockage local ; le serveur reste la référence après synchronisation. Une révision en conflit avec un autre appareil reste visible afin de pouvoir être résolue explicitement.

## Limites de cette version

- Extraction du texte dans le navigateur ; fichiers limités à 10 Mo et PDF à 100 pages. Aucun OCR intégré pour les documents scannés.
- Génération limitée à 40 000 caractères et à 12 cartes par demande. Découpez un cours long en parties cohérentes.
- Quotas IA par utilisateur : 6 demandes par minute et 40 par jour UTC, génération et Feynman cumulés. Un appel fournisseur échoué consomme sa réservation pour limiter les relances abusives.
- Le traitement IA est synchrone et borné ; il ne s’agit pas d’un service de traitement automatique de manuels entiers en arrière-plan.
- Aucune notification push ou planification de tâches iOS en arrière-plan.
- La qualité médicale des contenus générés exige une validation par l’étudiant et ses références de cours.

## Dépannage rapide

| Symptôme | Vérification |
|---|---|
| Le site affiche encore la démonstration | Variables publiques absentes lors du build ; corriger puis relancer Actions |
| Les fichiers JS ou icônes renvoient 404 | Vérifier la source Pages et le chemin de base ; conserver le workflow fourni |
| Le lien de confirmation ouvre la mauvaise adresse | Corriger Site URL et Redirect URLs, puis demander une nouvelle inscription/confirmation |
| La génération est refusée avec 401 | Se reconnecter ; vérifier que les fonctions ont bien été déployées |
| La génération est bloquée par CORS | Ajouter l’origine exacte dans `ALLOWED_ORIGINS`, sans chemin de dépôt |
| L’IA renvoie une erreur fournisseur | Vérifier le secret, le modèle et le crédit API OpenAI ; consulter les logs Edge sans y ajouter le contenu des cours |
| Un PDF ne contient aucun texte | Document probablement scanné : effectuer un OCR avant import |
| Une ancienne version reste affichée | Accepter la mise à jour proposée et relancer la PWA |

Pour les détails des requêtes et des fonctions SQL, consultez [BACKEND.md](BACKEND.md). Pour vérifier l’isolation de la base, utilisez le script fourni dans `supabase/tests/` sur un environnement de développement selon ses instructions.
