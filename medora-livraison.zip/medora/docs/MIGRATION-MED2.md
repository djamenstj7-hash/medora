# Mise à jour Medora avec le programme MED2

Cette version ajoute les cours, entraînements et outils de l’ancien site MED2 à Medora. L’interface Medora reste la base de l’application. Les decks existants, les imports texte/PDF, les appels IA, Feynman, les révisions FSRS et leurs événements hors connexion sont conservés.

## Installation depuis un iPhone

1. Dans le même dépôt GitHub, remplace uniquement `medora-livraison.zip` par l’archive de cette version, avec exactement ce nom. Conserve le workflow d’installation existant.
2. Vérifie que les variables publiques Supabase du dépôt sont toujours renseignées.
3. Si le jeton Supabase de déploiement a expiré, génère un nouveau jeton limité au projet `medora` et remplace le secret GitHub `SUPABASE_ACCESS_TOKEN`. Le secret `SUPABASE_DB_PASSWORD` reste le mot de passe de la base de données.
4. Lance **Actions → Installer Medora depuis un iPhone → Run workflow**, en laissant **Installer ou mettre à jour Supabase** coché.
5. La migration `202610150002_med2_study.sql` ajoute deux tables et une procédure. La migration initiale est conservée. Aucune table existante n’est réinitialisée.
6. Après le succès du déploiement, ouvre Medora en ligne et accepte la mise à jour. Vérifie tes anciens decks, ouvre un cours MED2, enregistre une note, puis une réponse d’entraînement.
7. Pour l’accès hors connexion à l’ensemble des cours, utilise le téléchargement du programme dans les réglages et garde l’application ouverte pendant le téléchargement.

Un simple changement de l’interface peut être publié sans réinstaller Supabase. Cette première mise à jour MED2 nécessite la nouvelle migration pour synchroniser la progression et ajouter les cartes du programme à FSRS.

## Ce qui est ajouté à Supabase

### `study_events`

Chaque lecture déclarée, réponse, session, favori, note, brouillon, autoévaluation, date d’examen personnalisée et réglage est un événement immuable. Les événements sont identifiés par la paire `(user_id, id)` : une sauvegarde peut être importée volontairement dans un autre compte sans collision d’identifiants.

Les utilisateurs authentifiés peuvent lire et insérer leurs propres événements. Ils ne peuvent ni lire ceux d’un autre utilisateur, ni modifier l’historique avec une ancienne copie du stockage local. Les événements hors connexion sont d’abord enregistrés dans IndexedDB, puis transmis avec leurs identifiants d’origine : une reconnexion ou une réponse réseau perdue ne crée pas de doublon.

Les événements des appareils sont fusionnés, puis rejoués dans un ordre déterministe. Les réponses et sessions sont réunies par identifiant. Les propriétés individuelles — note d’un cours, réglage, session en cours — utilisent la dernière modification connue dans cet ordre. Les versions précédentes restent présentes dans la sauvegarde d’événements ; les textes concurrents ne sont pas fusionnés automatiquement phrase par phrase.

La synchronisation ne dépend pas d’un service worker actif en arrière-plan. Sur iPhone, rouvre Medora avec Internet pour permettre la synchronisation. Sans connexion, le suivi fonctionne sur cet appareil. Si la migration n’est pas encore déployée, les cours restent consultables et la progression locale reste en attente.

### `curriculum_imports` et `install_curriculum_deck`

Le bouton d’ajout des cartes d’un cours au moteur FSRS crée un nouveau deck personnel. Il ne remplace aucun deck déjà présent. L’installation est atomique et idempotente : plusieurs appuis pour le même cours et le même utilisateur retrouvent le même deck.

Les cartes sont initialement **en brouillon**, avec un état FSRS neuf créé côté serveur. Il faut les relire puis activer le deck. Le navigateur ne peut fournir ni un nombre de révisions, ni une échéance, ni un propriétaire arbitraire à cette procédure. Un deck déjà activé conserve son état lors d’un nouvel appui.

La procédure accepte au maximum 200 cartes par cours. Si un deck du programme est supprimé explicitement, son lien d’installation est supprimé avec lui et un nouvel ajout reste possible.

## Importer une ancienne sauvegarde MED2

Depuis l’ancien site, utilise **Suivi ou Réglages → Exporter la sauvegarde**. Le fichier attendu est un JSON de la forme :

```json
{
  "app": "med2-s1",
  "version": 1,
  "state": {}
}
```

Dans Medora, importe ce fichier depuis les réglages. L’application ne tente pas d’accéder au `localStorage` d’un autre site : les origines GitHub Pages et les chemins historiques peuvent être différents.

L’import conserve l’état source complet comme archive exportable. Il récupère les autoévaluations de cours effectivement enregistrées, les réponses et historiques QCM présents, les autoévaluations des cartes, les brouillons de rédaction, les résumés d’examens et le temps quotidien configuré. Les identifiants des questions sont rapprochés du programme lorsque les cours correspondants sont disponibles. Si un cours ne peut pas être chargé, l’archive d’origine reste conservée.

Les anciennes QROC étaient notées par une comparaison de mots permissive. Leurs réponses sont reprises comme brouillons, mais leur ancien champ automatique `ok` n’est pas converti en réussite clinique. Les durées absentes des anciens résumés ne sont pas reconstituées ; elles restent non mesurées.

Un ancien compteur `memory.count` ou un ancien `nextDue` ne crée jamais de révision FSRS. Les données historiques restent consultables dans l’archive, sans inventer des répétitions ni changer les échéances des cartes actuelles.

## Sauvegarde actuelle et restauration

Une sauvegarde Medora contient :

- la progression pédagogique, les préférences, les notes, les favoris, les missions supplémentaires et la session en cours ;
- les événements de progression, y compris ceux qui attendent leur synchronisation ;
- une copie de la bibliothèque FSRS connue sur cet appareil, avec ses cartes, journaux et révisions en attente ;
- l’archive d’une ancienne progression MED2 si elle a été importée.

L’import fusionne la progression pédagogique. **La copie de bibliothèque FSRS est archivée, elle n’est pas écrite par-dessus la bibliothèque Supabase.** Les versions et échéances du serveur restent la référence ; rejouer aveuglément un ancien cache pourrait dupliquer des révisions ou écraser une planification plus récente.

Exporte une sauvegarde avant de changer de compte ou d’effacer les données Safari. La déconnexion efface le cache personnel du compte sur cet appareil, comme dans Medora initial. Les données déjà synchronisées restent dans Supabase ; les événements encore uniquement locaux doivent être synchronisés ou exportés avant la déconnexion.

La réinitialisation du **suivi MED2** remet à zéro lectures, activité, autoévaluations, missions et session en cours dans la vue courante. Elle conserve notes, favoris, brouillons, réglages, dates d’examen et la bibliothèque FSRS. C’est un événement de réinitialisation réversible par l’import d’une sauvegarde ; ce n’est pas un effacement physique des historiques du compte.

## Catalogue personnel

L’import de manifeste MED2 ajoute des matières et références personnelles au catalogue. Il ne remplace jamais les cours intégrés. Les liens doivent être HTTPS et les identifiants uniques. Un catalogue ne contient pas automatiquement le texte d’un PDF : il peut référencer un document externe sans le rendre disponible hors connexion.

## Correction et suivi

Les QRU et QRM utilisent une comparaison exacte des ensembles de réponses. Aucun barème partiel officiel n’est inventé. Les QROC fournissent un repérage lexical et un corrigé ; le sens clinique, les doses et les erreurs de raisonnement nécessitent une comparaison avec le cours et une autoévaluation. L’aide lexicale détecte certaines négations, sans prétendre analyser toutes les formulations médicales.

Le plan utilise les dates d’examen encore à venir, les retards de lecture et les réponses effectivement enregistrées. Les échéances historiques passées ne sont pas recyclées en faux examens futurs. Les tours se fondent sur les autoévaluations enregistrées ; ouvrir un cours ou cocher une mission ne signifie pas le maîtriser.

## Vérifications techniques

Les tests JavaScript se lancent avec `npm test`. Le contrôle TypeScript utilise `npm run check` et la compilation de production `npm run build`.

Le fichier `supabase/tests/study-security.sql` vérifie l’isolation des comptes, l’immuabilité des événements, les sauvegardes inter-comptes et l’installation idempotente des decks. Il doit être exécuté sur une base Supabase locale ou de test après les migrations ; il annule ses données de test avec `ROLLBACK` et n’appelle aucune IA.

Les tests SQL et les appels Supabase/OpenAI réels exigent un environnement connecté. Une compilation locale réussie ne prouve pas à elle seule que la migration a été appliquée dans ton projet.
