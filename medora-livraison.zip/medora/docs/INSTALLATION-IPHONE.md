# Installer Medora uniquement depuis un iPhone

Cette procédure remplace celle qui utilise un ordinateur. Safari et l’app Fichiers suffisent. Les commandes s’exécutent sur GitHub Actions. Aucun terminal, Node.js local, GitHub Desktop ou Codespaces n’est requis.

Si des boutons sont masqués dans GitHub ou Supabase, ouvrez le menu de page de Safari et choisissez « Version pour ordinateur ». Le nom du menu dépend de la version d’iOS.

## 1. Créer le dépôt GitHub

Sur https://github.com/new, créer un dépôt public nommé `medora`, avec un README pour initialiser `main`. Conserver le nom du compte GitHub : il remplace `PSEUDO` dans les exemples. L’adresse finale sera `https://PSEUDO.github.io/medora/`.

## 2. Déposer le ZIP, sans l’extraire

Télécharger `medora-livraison.zip` dans Fichiers → Téléchargements. Ne pas le décompresser pour cette méthode. Si iOS ou un deuxième téléchargement l’a renommé, le renommer exactement `medora-livraison.zip`.

Dans le dépôt GitHub, onglet Code → Add file → Upload files → choisir le ZIP dans Fichiers. Vérifier que le ZIP est à la racine, puis Commit changes sur `main`. Ne pas importer les fichiers un par un. Le workflow décompresse lui-même l’archive lors de chaque exécution.

## 3. Créer le projet Supabase

Sur https://supabase.com/dashboard, créer une organisation si nécessaire, puis un projet dédié `medora`, dans une région proche. Choisir et conserver le mot de passe de base de données. Attendre que le projet soit disponible.

Relever dans les paramètres du projet :

- Project Reference / Project ID, appelé `SUPABASE_PROJECT_REF` ci-dessous ;
- Project URL, par exemple `https://abcdefghijklmnopqrst.supabase.co` ;
- la clé publique publiable, généralement `sb_publishable_…` (la clé publique legacy `anon` est également compatible).

La référence du projet dans cet exemple est `abcdefghijklmnopqrst`. La clé `service_role` ou une clé `sb_secret_…` n’est pas la clé frontend.

## 4. Configurer les secrets IA et l’authentification dans Supabase

Créer une clé API OpenAI sur https://platform.openai.com avec facturation API active. Un abonnement ChatGPT ne fournit pas automatiquement du crédit API.

Dans le projet Supabase, Edge Functions → Secrets, ajouter :

| Nom | Valeur |
|---|---|
| `OPENAI_API_KEY` | Votre clé API OpenAI |
| `OPENAI_MODEL` | `gpt-4o-mini` |
| `ALLOWED_ORIGINS` | `https://PSEUDO.github.io` |

L’origine ne contient ni `/medora/` ni barre oblique finale. La clé OpenAI reste dans Supabase.

Dans Authentication → Sign In / Providers, activer Email et les inscriptions, avec confirmation d’e-mail. Dans Authentication → URL Configuration :

- Site URL : `https://PSEUDO.github.io/medora/` ;
- Redirect URLs : ajouter `https://PSEUDO.github.io/medora/`.

Conserver le modèle de confirmation utilisant `{{ .ConfirmationURL }}`. Le service e-mail intégré Supabase est limité, notamment concernant les destinataires ; configurer SMTP pour permettre les inscriptions d’autres utilisateurs.

## 5. Créer l’accès de déploiement Supabase

Dans les paramètres de votre compte Supabase (et non les clés API du projet), ouvrir Access Tokens et générer un jeton personnel nommé `medora-installation`, avec une expiration appropriée si proposée.

Ce jeton autorise le workflow à administrer les projets accessibles au compte ; le stocker uniquement comme secret GitHub. Il est distinct de la clé publiable et de la clé OpenAI. Ne pas le mettre dans un fichier du dépôt.

## 6. Configurer GitHub

Dans le dépôt → Settings → Secrets and variables → Actions, onglet Variables, créer trois Repository variables :

| Nom exact | Valeur |
|---|---|
| `SUPABASE_PROJECT_REF` | Référence du projet |
| `VITE_SUPABASE_URL` | URL du projet |
| `VITE_SUPABASE_PUBLISHABLE_KEY` | Clé publique publiable |

Dans l’onglet Secrets, créer deux Repository secrets :

| Nom exact | Valeur |
|---|---|
| `SUPABASE_ACCESS_TOKEN` | Jeton personnel créé à l’étape précédente |
| `SUPABASE_DB_PASSWORD` | Mot de passe de la base choisi à la création du projet |

Puis Settings → Pages → Build and deployment → Source : GitHub Actions.

## 7. Ajouter le workflow pour iPhone

Dans le dépôt → Code → Add file → Create new file, donner exactement ce chemin au nouveau fichier :

```text
.github/workflows/installation-iphone.yml
```

Copier tout le contenu du fichier `docs/iphone/installation-iphone.yml` livré avec le projet (également fourni séparément), le coller dans l’éditeur GitHub, puis Commit changes sur `main`.

Ne pas coller les trois délimiteurs de bloc Markdown autour du contenu. La première ligne doit être `name: Installer Medora depuis un iPhone`.

Le dépôt contient maintenant notamment le ZIP à la racine et le workflow dans `.github/workflows/`. Le ZIP reste le fichier source de cette méthode : ne pas le supprimer après installation.

## 8. Lancer l’installation

Ouvrir Actions → Installer Medora depuis un iPhone → Run workflow. Sélectionner la branche `main` et laisser coché « Installer ou mettre à jour Supabase » pour la première installation. Cliquer sur Run workflow et suivre le journal jusqu’au résultat vert.

Le workflow extrait le ZIP, installe la migration SQL, déploie les trois Edge Functions, installe les dépendances, exécute les tests, construit la PWA et publie GitHub Pages.

Le code du workflow et le paquet ont été vérifiés localement ; le déploiement dans votre compte reste à exécuter. S’il échoue, ouvrir l’étape rouge et relever le message précis. Les secrets GitHub sont masqués dans les journaux ; ne pas publier de capture contenant une clé saisie dans les paramètres.

## 9. Vérifier et installer sur l’écran d’accueil

Dans Supabase, vérifier Table Editor (`decks`, `cards`, etc.), Storage (bucket privé `courses`) et Edge Functions (`generate-quiz`, `evaluate-feynman`, `submit-review`).

Ouvrir `https://PSEUDO.github.io/medora/` dans Safari, créer un compte, confirmer l’e-mail et tester un petit import avant d’ajouter un cours long. Relire puis activer les cartes. Tester ensuite une révision et le mode Feynman.

Safari → Partager → Sur l’écran d’accueil → Ajouter.

## Après installation

- Pour une nouvelle archive : remplacer `medora-livraison.zip` dans le dépôt et relancer le workflow. Le nom et le dossier racine `medora/` de l’archive doivent être conservés.
- Pour republier uniquement le frontend : décocher l’installation Supabase lors de Run workflow.
- Après la première installation, vous pouvez révoquer le jeton personnel Supabase et supprimer les deux secrets de déploiement GitHub si vous ne souhaitez pas les conserver. L’application publiée et les Edge Functions continueront à fonctionner. Recréer ces accès pour une future mise à jour backend.
- L’offre GitHub/Supabase et la consommation OpenAI déterminent les coûts et quotas. Les fichiers publiés sur GitHub sont publics ; les cours importés vont dans le projet Supabase avec accès utilisateur, pas dans le dépôt.
