# Architecture livrée

Medora sépare un frontend statique d’un backend Supabase. GitHub Pages sert uniquement HTML, JavaScript, CSS, icônes et service worker. La base, l’authentification, les documents privés et l’IA restent chez Supabase.

```mermaid
flowchart TD
    A[PWA React / GitHub Pages] -->|E-mail et mot de passe| B[Supabase Auth]
    A -->|JWT + RLS| C[PostgreSQL]
    A -->|JWT + politiques Storage| D[Bucket privé courses]
    A -->|JWT utilisateur| E[Edge Functions]
    E -->|auth.getUser| B
    E -->|Clé serveur + contrôles propriétaire| C
    E -->|Secret côté serveur| F[OpenAI]
    A --> G[IndexedDB local et file de révisions]
```

## Frontend et iOS

React 19, TypeScript, Vite 7 et TailwindCSS 4 composent l’interface. `vite-plugin-pwa` génère `manifest.webmanifest` et le service worker à la construction. Le manifest n’est donc pas un fichier à maintenir séparément.

`index.html` contient `apple-mobile-web-app-capable`, `viewport-fit=cover`, les icônes Apple et la couleur de thème. Les styles appliquent les safe areas et les dimensions dynamiques du viewport. La navigation interne ne nécessite pas de routes serveur : elle fonctionne sous le chemin d’un dépôt GitHub Pages.

Le service worker met en cache le shell statique. Les réponses Supabase authentifiées ne sont pas mises en cache par Workbox. Les données de révision nécessaires hors connexion sont enregistrées séparément dans IndexedDB, dans un espace associé à l’utilisateur. Les sessions Supabase persistent sur l’appareil pour permettre la reconnexion.

## Modèle de données

| Table | Contenu et protection |
|---|---|
| `auth.users` | Comptes gérés par Supabase Auth |
| `decks` | Titre, matière, couleur et propriétaire |
| `documents` | Fichier privé, deck associé, état du traitement |
| `cards` | Question, réponse, explication, choix QCM, extrait source et état brouillon/actif |
| `card_schedules` | État FSRS sérialisé, échéance indexée et version de concurrence |
| `review_logs` | Évaluation, date, états avant/après et identifiant d’événement unique |
| `feynman_attempts` | Explication et retour pédagogique structuré |
| `ai_runs` | Traitement, modèle, état et consommation ; accès serveur uniquement |
| `ai_daily_usage` | Compteur de quota atomique ; accès serveur uniquement |

Toutes les tables publiques ont la RLS activée. Les références composites `(id, user_id)` empêchent de rattacher une carte ou un document au deck d’un autre utilisateur. Les tables de planification et de journalisation n’acceptent aucune écriture directe du navigateur.

La matière est portée directement par le deck. Cette première version ne crée pas de catalogue partagé, de profils sociaux, ni de table de paramètres FSRS personnalisés. L’état détaillé FSRS est stocké en JSONB pour suivre la structure réelle de la bibliothèque, avec `due` dans une colonne indexée.

## Sécurité des Edge Functions

Les fonctions `generate-quiz`, `evaluate-feynman` et `submit-review` :

1. Contrôlent l’origine et répondent aux requêtes CORS autorisées.
2. Extraient le JWT puis le font vérifier avec `auth.getUser(jwt)`.
3. Déduisent le propriétaire de cette session et valident les entrées.
4. Vérifient les droits sur les ressources concernées.
5. Effectuent les écritures sensibles à l’aide de procédures SQL restreintes au rôle serveur.

La clé publiable Supabase est incluse dans le bundle par conception. Les secrets OpenAI et la clé Supabase privilégiée restent côté Edge. La RLS protège les accès directs ; les fonctions utilisant un rôle privilégié effectuent leurs propres contrôles de propriétaire.

`verify_jwt = false` dans la configuration des fonctions est compatible avec l’usage des clés publiables récentes : la validation de session est réalisée explicitement dans chaque handler. CORS ne remplace jamais cette authentification.

## Révision : FSRS et entrelacement

Le frontend et la fonction de révision emploient la même version verrouillée, `ts-fsrs@5.2.3`, avec les mêmes paramètres : rétention cible de 0,90, apprentissage à court terme activé et variation aléatoire désactivée pour conserver des transitions reproductibles. La cible n’est pas une garantie individuelle de mémorisation. Le navigateur peut estimer le prochain passage immédiatement et travailler hors connexion ; le serveur recalcule la transition officielle.

Chaque évaluation possède un UUID et une version attendue. Elle est sauvegardée dans la file locale avant l’envoi, afin de pouvoir être reprise après une fermeture de l’application. La transaction serveur verrouille la planification, vérifie l’ordre chronologique, écrit le log puis met à jour l’échéance. Un envoi répété du même événement renvoie son résultat sans doubler la révision.

Un conflit de version ne doit pas être assimilé à une réussite. L’événement reste signalé et l’étudiant peut écarter explicitement les événements locaux incompatibles dans les réglages, puis reprendre sa révision depuis la version serveur. Le même parcours s’applique à une carte supprimée ou à une révision expirée. Les événements acceptés doivent dater de moins de 30 jours et ne peuvent pas être de plus de 5 minutes dans le futur. Une erreur d’authentification, de quota ou de serveur conserve la file pour un nouvel essai.

L’entrelacement intervient après sélection des cartes dues : il alterne les matières disponibles par groupes d’urgence, avec les cartes en retard d’au moins une semaine d’abord, puis celles en retard d’au moins un jour. Au sein de chaque groupe, l’ancienneté est conservée autant que l’alternance le permet. Il ne modifie pas les dates FSRS. Une session prend jusqu’à 20 cartes ; cette version n’expose pas de quota séparé pour les nouvelles cartes.

## Ingestion et rappel génératif

```text
Texte ou PDF textuel
    → extraction locale et contrôle du volume
    → fichier dans Storage privé + document en base
    → génération IA bornée et validation du schéma
    → cartes en brouillon avec extrait source
    → relecture et activation du deck
```

Le texte du cours est une donnée non fiable : le prompt interdit d’exécuter ses instructions et demande de s’appuyer sur son contenu pédagogique. Les sorties structurées sont vérifiées avant toute écriture ; elles ne déclenchent aucune opération privilégiée.

La génération est synchrone, limitée à 40 000 caractères et 12 cartes. Le navigateur accepte des fichiers de 10 Mo au plus et des PDF de 100 pages au plus. Le traitement peut échouer et être relancé ; une génération déjà achevée est réutilisée pour éviter de dupliquer les cartes d’un document. Les PDF scannés nécessitent un OCR externe. Cette implémentation n’ajoute pas une file de tâches pour traiter automatiquement de longs ouvrages.

## Mode Feynman

L’étudiant saisit un concept et son explication. L’IA renvoie les acquis, les omissions, les erreurs de compréhension, une correction et des questions de relance. Un contexte de cours peut appuyer l’évaluation. Ce retour est distinct des quatre appréciations de mémoire FSRS et ne change pas automatiquement la planification.

## Déploiement et vérification

GitHub Actions installe le lockfile, exécute les tests et construit `dist/`, puis publie un artefact GitHub Pages. Le chemin de base vient de `actions/configure-pages`, ce qui permet de conserver le même code pour un dépôt, un site utilisateur ou un domaine personnalisé.

Les secrets IA ne transitent pas par le workflow. Les variables frontend sont fixées au build : toute modification exige une nouvelle publication.

Les tests locaux portent sur le moteur et ses invariants. Le parcours Auth/Storage/Edge/OpenAI doit aussi être exécuté avec un véritable projet configuré ; sans vos identifiants, aucun déploiement distant ni appel IA de production ne peut être certifié.
