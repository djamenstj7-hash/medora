# Mettre à jour Medora depuis ton iPhone

Cette procédure concerne **ton application Medora déjà installée**. Elle ajoute le programme de ton ancien site MED2 dans Medora, en conservant ses quatre onglets, tes decks, FSRS, l’import de cours et Feynman.

Tu gardes le même dépôt GitHub, le même projet Supabase et la même adresse de l’application. **Ne crée pas un nouveau projet et ne supprime aucune table.**

## 1. Préserver ta progression avant la mise à jour

Ouvre ta Medora actuelle avec Internet et laisse les révisions en attente se synchroniser. La progression de ton compte est privée : elle ne se trouve ni dans le code de l’application ni dans le ZIP.

Si tu utilisais aussi l’ancien site MED2, ouvre ce site sur l’iPhone où tu l’utilisais, puis **Suivi ou Réglages → Mes données → Exporter**. Enregistre le fichier JSON dans l’app **Fichiers**. La mise à jour ne peut pas récupérer automatiquement les résultats stockés dans l’ancien site. Le ZIP MED2 envoyé contient les cours, pas ta progression personnelle.

Garde cette sauvegarde. Pendant la mise à jour, conserve les données Safari et ta session actuelle.

## 2. Télécharger et remplacer le ZIP sur GitHub

1. Télécharge la nouvelle archive dans **Fichiers → Téléchargements**. Pour cette méthode, garde le fichier ZIP entier : GitHub Actions se charge de l’extraire.
2. Vérifie son nom : **`medora-livraison.zip`**. Si l’iPhone a ajouté « 2 » ou « (1) », renomme le fichier avec le nom exact.
3. Dans Safari, ouvre ton dépôt : **https://github.com/djamenstj7-hash/medora**.
4. Dans l’onglet **Code**, vérifie que tu es sur la branche **main**.
5. Choisis **Add file → Upload files**, puis sélectionne le nouveau ZIP dans Fichiers. Sur écran étroit, cette commande peut se trouver dans le menu **…**. Le menu de page de Safari permet aussi d’activer la **version pour ordinateur**.
6. Le ZIP doit remplacer le fichier du même nom à la racine du dépôt. Écris par exemple « Mise à jour Medora avec les cours MED2 », puis touche **Commit changes**, directement sur **main**.

Garde le workflow `.github/workflows/installation-iphone.yml` déjà présent dans le dépôt. Tu n’as pas à envoyer séparément les dossiers de l’archive.

## 3. Lancer la mise à jour complète

1. Ouvre l’onglet **Actions** du dépôt. Sur iPhone, il peut être dans **More**.
2. Sélectionne **Installer Medora depuis un iPhone**.
3. Touche **Run workflow** et sélectionne **main**.
4. **Laisse cochée « Installer ou mettre à jour Supabase ».** Cette version ajoute la migration `202610150002_med2_study.sql`, nécessaire pour synchroniser le suivi MED2 et ajouter les cartes des cours à FSRS.
5. Touche le bouton vert **Run workflow** et attends la fin de l’exécution. Ouvre la nouvelle ligne pour suivre les étapes. La coche verte finale confirme le succès du workflow.

Le workflow utilise tes variables et secrets existants. La migration ajoute les tables du suivi et une procédure d’installation des decks ; elle conserve les tables, cartes et journaux FSRS déjà présents.

### Si le jeton Supabase a expiré

Ton premier jeton a pu être créé pour sept jours. Si l’étape Supabase échoue pour un jeton expiré ou invalide :

1. Dans les paramètres de **ton compte Supabase**, ouvre **Access Tokens** et crée un nouveau jeton pour le projet **medora**, avec les droits de déploiement nécessaires. Il s’agit du jeton personnel d’administration, distinct de la clé publique du projet et de la clé OpenAI.
2. Dans GitHub : **Settings → Secrets and variables → Actions → Secrets**.
3. Modifie **`SUPABASE_ACCESS_TOKEN`**, colle le nouveau jeton dans sa valeur et enregistre.
4. Relance le workflow avec la case Supabase cochée.

Si tu avais supprimé les secrets de déploiement après la première installation, recrée aussi **`SUPABASE_DB_PASSWORD`**, avec le mot de passe de la base du projet existant. La clé OpenAI reste dans **Supabase → Edge Functions → Secrets** ; elle n’a pas à être déplacée pour cette mise à jour.

Pour une autre erreur, ouvre l’étape rouge et relève son message. Un résultat rouge signifie que la mise à jour n’est pas terminée.

## 4. Ouvrir la nouvelle Medora

Après le résultat vert, ouvre **https://djamenstj7-hash.github.io/medora/** avec Internet. Si Medora propose une mise à jour, accepte-la. Si l’ancienne version s’affiche encore, ferme puis rouvre l’application ou actualise la page Safari.

Vérifie d’abord que tes anciens decks sont toujours dans **Bibliothèque → Mes decks**. Les quatre onglets principaux restent **Aujourd’hui**, **Bibliothèque**, **Importer** et **Feynman**.

Dans **Bibliothèque**, les nouveaux espaces sont :

| Espace | Ce que tu peux y faire |
|---|---|
| **Mes decks** | Retrouver tes decks et leurs révisions FSRS existantes. |
| **Cours MED2** | Lire les 69 cours, leurs synthèses et illustrations ; répondre aux QCM, QROC, rédactions et évaluations ; conserver des notes et favoris. |
| **Entraînement** | Composer une session de questions isolées ou dossiers cliniques, travailler les erreurs et reprendre une session. |
| **Suivi & planning** | Consulter l’activité, adapter les dates d’examen et le temps disponible, puis suivre un planning entrelaçant les matières. |

Les dates proviennent du programme 2026–2027 : vérifie qu’elles correspondent à tes examens. Le catalogue comprend aussi des références dont le cours rédigé n’était pas fourni ; elles sont signalées dans l’application.

Pour ajouter les flashcards d’un cours à FSRS, utilise le bouton prévu dans le lecteur. Un **nouveau deck en brouillon** est ajouté à tes decks personnels : relis ses réponses puis active-le. Tes autres decks restent présents et leurs échéances sont conservées.

## 5. Récupérer tes résultats de l’ancien MED2

Dans les **réglages Medora**, ouvre **Sauvegardes & ancienne progression MED2 → Importer une sauvegarde JSON**. Sélectionne le JSON exporté à l’étape 1, vérifie le nom du fichier puis touche **Confirmer la fusion**.

L’import fusionne les données reconnues et garde l’état source en archive. Les anciens intervalles de rappel MED2 ne remplacent pas les échéances FSRS. Les anciennes réponses QROC sont reprises comme brouillons, car leur ancienne notation automatique était trop permissive.

Après tes premières sessions, utilise **Exporter ma sauvegarde** pour conserver également une copie de ta progression Medora dans Fichiers. La copie FSRS contenue dans cet export est une archive ; l’import ne l’écrit pas par-dessus les échéances du serveur.

## 6. Télécharger les cours pour le hors connexion

Dans les réglages, utilise **Télécharger le programme** avec une connexion stable. Garde Medora ouverte jusqu’au message de fin. Cela télécharge les cours intégrés, exercices et illustrations dans le cache de cet appareil.

Les PDF et documents externes référencés par des liens ne sont pas téléchargés automatiquement. L’ingestion et les évaluations IA nécessitent toujours Internet. Rouvre Medora en ligne pour synchroniser ta progression ; une sauvegarde JSON reste utile car iOS peut libérer du stockage.

Les détails de migration et les règles de sauvegarde figurent dans [MIGRATION-MED2.md](MIGRATION-MED2.md). Les vérifications effectuées sont consignées dans [VERIFICATION.md](VERIFICATION.md).
