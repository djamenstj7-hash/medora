# Intégration des contenus MED_ENGINE

Cette intégration ajoute les paquets de l’application Windows MED_ENGINE à Medora. Elle conserve l’interface principale et les fonctionnalités Medora précédentes, notamment les 69 cours MED2, les decks personnels, les révisions FSRS, les imports de cours et les modules IA.

## Périmètre des sources

Le dossier Drive fourni contient un programme Windows et ses dépendances, ainsi que les données séparées sous `_internal/contenu/`. Le contenu structuré est repris depuis les paquets, les médias et leurs documents d’accompagnement. Aucun exécutable `.exe`, script `.bat` ou module Windows n’est nécessaire sur l’iPhone.

L’inventaire d’origine recense 141 dossiers de chapitres et 750 fichiers de contenu, dont 142 JSON, 155 Markdown, 15 HTML, 130 PNG et 308 SVG. Le JSON supplémentaire appartient au squelette pédagogique de remédiation. Les totaux des notes et des cartes sont calculés depuis les paquets ; les anciens titres de README peuvent annoncer des comptes antérieurs à leurs derniers ajouts.

Les deux fichiers TOML de ressources portent le total à **752 fichiers fournis**, conservés avec vérification des empreintes SHA-256. Le programme intégré comprend :

| Mesure | Total |
|---|---:|
| Paquets / chapitres | 141 |
| UE | 13 |
| Notes | 15 592 |
| Cartes enregistrées dans les paquets source | 15 605 |
| Variantes de travail dérivées des notes | 25 753 |
| Variantes d’annales, incluses dans le total précédent | 2 752 |
| Variantes marquées non vérifiées, incluses dans le total | 82 |
| Fichiers de support du programme | 607 |
| Images PNG/SVG fournies, incluses dans les supports | 438 |
| Schémas HTML et explications Markdown associées | 15 paires |

Le nombre de variantes ne doit pas être présenté comme le nombre d’anciennes cartes Windows : une note à plusieurs trous ou zones est décomposée pour permettre un rappel indépendant. Aucun nouveau fait médical n’est ajouté par cette décomposition.

### Figures citées mais absentes du Drive

Le contrôle des références a détecté **8 699 couples paquet/nom de figure absents**, répartis sur 135 paquets. Ce n’est pas le nombre d’images perdues pendant l’import : ces fichiers ne figuraient pas dans les dossiers reçus. Le dossier `semio_abord/media`, par exemple, était vide sur Drive alors que ses notes citent des figures.

**19 695 variantes** mentionnent au moins une de ces figures manquantes. Tous leurs textes, références et corrigés restent conservés. Le chargeur distingue les médias effectivement fournis des références absentes ; l’interface affiche une indication au lieu de provoquer une série de chargements 404 ou de fabriquer une image. Une question de repérage ne peut pas être travaillée normalement sans sa figure, même si son corrigé textuel reste disponible.

Les 438 images réellement présentes et les 15 schémas HTML sont intégrés. Des fichiers supplémentaires pourront compléter la bibliothèque lorsqu’ils seront fournis ; cette version ne prétend pas contenir les milliers de figures seulement citées. Le détail est conservé dans `public/engine/audit.json`, et les empreintes des sources dans `public/engine/provenance.json`.

Les références de cours, auteurs, pages, sessions d’annales et explications sont conservées. Les supports externes absents du dossier restent des références documentaires ; un chapitre sans cartes fournies n’est pas transformé en faux contenu rédigé.

## Formats pédagogiques

Les formats présents sont adaptés à l’écran tactile :

| Format source | Usage dans Medora |
|---|---|
| QRU / QRM | Choix unique ou multiple, validation explicite et justification de chaque proposition. |
| Recto-verso | Rappel avant révélation, puis autoévaluation. |
| Texte à trous | Travail de chaque groupe de suppression, avec contexte conservé. |
| QROC | Réponse écrite, comparaison au corrigé et autoévaluation explicite. |
| Lexique | Terme, définition, racines et références disponibles dans le paquet. |
| Zones sur image | Repérage sur le schéma en tenant compte de ses coordonnées d’origine. |
| Légendes | Éléments numérotés d’une planche et leurs corrections. |

Une note peut produire plusieurs variantes de travail, par exemple plusieurs trous ou zones. Les identifiants gardent la portée du paquet, de la note et de sa variante, pour ne pas mélanger les résultats de cartes différentes ou les anciens identifiants MED2.

Les propositions indispensables ou inacceptables, les justifications, les corrigés officiels, les clés déduites, les avertissements `ATTENTION` et les mentions « à relire » restent associés au contenu concerné. L’intégration technique ne constitue pas une nouvelle validation médicale des réponses.

La confiance déclarée avant correction — sûr, hésitant ou au hasard — reste distincte de la note FSRS et de la réussite d’une réponse. Une QROC ou une explication libre ne reçoit pas une validation clinique automatique fondée sur quelques mots reconnus.

## Entraînement et répétition espacée

**Bachoter** et **Annales** enregistrent les réponses d’entraînement. Ils ne modifient pas les échéances de révision. Une simulation diffère l’affichage des corrections jusqu’au bilan ; une séance sauvegardée peut être reprise.

L’ajout des cartes d’un paquet à FSRS passe par un nouveau deck personnel, en brouillon à relire. La procédure d’installation est propre à l’utilisateur et idempotente : répéter l’ajout retrouve le deck déjà installé, sans réinitialiser ses cartes activées ni leurs échéances. Les états FSRS initiaux sont créés côté serveur ; aucun ancien compteur de l’application Windows n’est inventé.

La migration `202610270003_med_engine.sql` ajoute les informations de liaison au contenu et une procédure d’installation. Elle ne remplace pas la migration initiale, les tables historiques ou le moteur de révision déjà utilisé par Medora.

## Sources, illustrations et schémas interactifs

Les médias sont servis comme ressources statiques sous le chemin GitHub Pages du projet, y compris lorsque l’application est publiée sous `/medora/`. Les chapitres sont chargés à la demande pour éviter de placer tous les paquets dans le JavaScript de démarrage.

Les HTML « Comprendre » sont des documents pédagogiques interactifs ou fixes, affichés dans un espace isolé. Ils doivent être affichés dans une iframe sandboxée, sans accès au stockage, à la session ou au DOM de Medora. Leur texte ne doit pas être injecté comme HTML privilégié dans l’application. Les explications Markdown restent accessibles à côté des interactifs.

Un schéma sert d’appui pédagogique ; le cours et les référentiels restent la référence, comme le précise la source. Les figures existantes sont conservées ; l’importateur ne fabrique pas une illustration médicale absente.

## Suivi, sauvegardes et limites

Les notes, favoris, réponses et séances ajoutés dans Medora appartiennent à son suivi privé. Ils utilisent les mécanismes de sauvegarde et de synchronisation de Medora. Les activités d’entraînement ne sont pas présentées comme des répétitions FSRS.

La commande de remise à zéro du suivi MED2 conserve la progression MED_ENGINE et la bibliothèque FSRS. Les sauvegardes globales regroupent les progressions des deux bibliothèques.

Les résultats personnels de l’ancienne application sont enregistrés dans le profil Windows, à l’extérieur du dossier distribué. Le Drive fourni ne permet donc pas de restaurer ces résultats. La présente livraison importe les contenus, sans prétendre avoir récupéré une base personnelle SQLite ou une ancienne planification.

Les dates historiques ou le squelette de remédiation ne sont pas recyclés en fausses échéances futures. Vérifier les dates d’examen et la portée des chapitres lorsqu’un planning est utilisé.

Les contenus fournis sont préécrits et consultables sans appel IA. Les fonctions IA existantes continuent d’utiliser les secrets Supabase configurés. Aucune clé ne doit être ajoutée au frontend, aux JSON statiques ou aux archives de livraison. Gemini n’est pas ajouté par cette intégration.

## Livraison en plusieurs ZIP depuis iPhone

Le navigateur GitHub limite la taille d’un fichier envoyé. Le projet principal et les contenus complémentaires sont donc distribués en fichiers distincts, chacun adapté à cette limite. Toutes les données `public/engine/` sont placées dans les parties complémentaires, y compris les JSON : celles-ci ne contiennent pas uniquement des images. Leur extraction conserve le même dossier racine `medora/`.

Le ZIP principal contient `delivery-files.json`, avec la liste exacte des parties et leurs empreintes SHA-256 :

```json
{
  "parts": [
    {
      "file": "medora-contenus-engine-1.zip",
      "sha256": "empreinte SHA-256 réelle fournie avec la livraison"
    }
  ]
}
```

Les valeurs effectives sont écrites lors de l’assemblage de la livraison, pas copiées depuis cet exemple. Le vérificateur `docs/iphone/extract-engine-parts.py` contrôle toutes les parties avant d’extraire un fichier : noms autorisés, SHA-256, intégrité ZIP, limite de volume, chemins internes, absence de lien symbolique et absence d’écrasement du projet principal ou d’un autre fichier de partie.

Une partie manquante ou issue d’une autre version interrompt le workflow avant le build et la publication. Le vérificateur ne télécharge aucune dépendance et n’utilise ni compte Google ni secret IA. Les parties sont lues depuis le dépôt GitHub de l’utilisateur.

Le modèle de workflow reste compatible avec un ancien ZIP ne contenant aucun manifeste de parties. Le workflow source classique `.github/workflows/deploy.yml` concerne un dépôt contenant déjà tous les dossiers extraits ; il n’est pas utilisé pour le dépôt iPhone qui conserve les ZIP.

## Vérifications

Les tests du vérificateur de livraison se lancent avec :

```bash
python -m unittest discover -s tests -p test_delivery_parts.py -v
```

Ils couvrent la fusion d’archives, une partie manquante, une empreinte incorrecte, les chemins interdits, les liens symboliques et les tentatives d’écrasement. Les tests de contenu, de FSRS, d’interface et de hors connexion sont consignés dans le rapport global de vérification. Les essais réels sur le projet Supabase et l’iPhone de l’utilisateur restent à distinguer des vérifications locales.

Pour l’installation manuelle, suivre [MISE-A-JOUR-IPHONE-V3.md](MISE-A-JOUR-IPHONE-V3.md).
