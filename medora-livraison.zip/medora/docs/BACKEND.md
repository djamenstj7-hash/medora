# Backend Supabase

Le frontend est statique. Les écritures sensibles sont effectuées par des Edge Functions authentifiées, avec une clé service Supabase uniquement côté serveur. Les cours sont des données pédagogiques privées ; aucune clé IA ne doit apparaître dans une variable `VITE_*`.

## Fichiers

- `supabase/migrations/202610150001_initial.sql` : tables, index, RLS, grants, bucket privé et procédures atomiques.
- `supabase/functions/_shared/` : vérification JWT par `auth.getUser`, CORS, limitation des entrées, client OpenAI.
- `supabase/functions/generate-quiz/` : génération et sauvegarde de cartes brouillon.
- `supabase/functions/evaluate-feynman/` : évaluation et sauvegarde d’une explication.
- `supabase/functions/submit-review/` : planification FSRS et journalisation.
- `supabase/tests/security.sql` : régressions SQL à exécuter sur une base de test après migration.

Suivre [INSTALLATION.md](INSTALLATION.md) ou le README racine pour la mise en place. Les trois fonctions utilisent `verify_jwt = false` dans `config.toml` pour prendre en charge les clés publiables récentes : **chaque handler vérifie lui-même le JWT utilisateur avec Supabase Auth**, avant toute opération. Ce paramètre ne rend pas les fonctions accessibles sans connexion.

## Secrets

Copier `supabase/.env.example` vers `supabase/.env.local`, puis configurer :

```env
OPENAI_API_KEY=sk-...
OPENAI_MODEL=gpt-4o-mini
ALLOWED_ORIGINS=http://localhost:5173,https://VOTRE-COMPTE.github.io
```

Les origines ne contiennent ni chemin de dépôt, ni slash final, ni joker. Supabase injecte `SUPABASE_URL` et `SUPABASE_SERVICE_ROLE_KEY` dans les fonctions hébergées. Ne pas les ajouter au frontend. Le modèle choisi doit accepter Chat Completions et les sorties structurées JSON Schema.

## Contrats HTTP

Tous les appels sont `POST` JSON avec `Authorization: Bearer <JWT utilisateur>`. Les réponses d’erreur sont `{ "error": "message", "code": "CODE" }`. Les codes 401, 403, 409, 429 et 5xx sont traités explicitement.

### generate-quiz

```json
{
  "deck_id": "UUID",
  "document_id": "UUID",
  "text": "Texte extrait du cours…",
  "kind": "mixed",
  "count": 6
}
```

`kind` : `mixed`, `flashcard`, `qcm` ou `case`. Texte : 100 à 40 000 caractères. Nombre : 1 à 12. Retour `{ "count": 6 }`, éventuellement `cached: true` si ce document a déjà été généré. Une génération réussie est idempotente par document : pour un autre contenu ou type de génération, créer un nouveau document.

La fonction vérifie explicitement l’appartenance du document au deck et à l’étudiant. Les sorties sont validées en TypeScript ; chaque citation source doit exister littéralement dans le texte, après normalisation Unicode et des espaces. Les QCM/cas possèdent quatre choix et une seule réponse attendue. La correction scientifique reste à vérifier par l’étudiant : une citation valide ne prouve pas que l’interprétation du modèle est correcte.

Les cartes sont enregistrées en `draft`, avec leur état FSRS initial. La procédure utilisateur `activate_deck(p_deck_id)` active uniquement les cartes du propriétaire et retourne le nombre de cartes activées.

### evaluate-feynman

```json
{
  "concept": "Insuffisance cardiaque",
  "explanation": "Explication de l’étudiant, au moins 30 caractères…",
  "context": "Extrait de cours optionnel"
}
```

Limites : concept 300 caractères ; explication 12 000 ; contexte 12 000. Retour et sauvegarde :

```json
{
  "strengths": [],
  "missing": [],
  "misconceptions": [],
  "correction": "Explication corrigée",
  "follow_up": []
}
```

Ce résultat ne modifie pas FSRS et ne constitue pas une évaluation clinique. Sans contexte de cours, le modèle doit signaler que les faits nécessitent une vérification.

### submit-review

```json
{
  "card_id": "UUID",
  "rating": 3,
  "client_event_id": "UUID stable pour cet événement",
  "reviewed_at": "2026-10-15T10:00:00.000Z",
  "expected_version": 0
}
```

`rating` : 1 Again, 2 Hard, 3 Good, 4 Easy. Retour `{ "schedule": {}, "version": 1, "duplicate": false }`. Le serveur recalcule avec `ts-fsrs@5.2.3`, rétention 0,9, intervalle maximal 36 500 jours, fuzz désactivé. Les dates du JSON de planification sont ISO UTC. Le navigateur utilise la même version pour l’aperçu hors ligne.

L’enregistrement du nouvel état et du journal est atomique. Le couple utilisateur/événement est unique ; retransmettre le même événement retourne son résultat original sans compter deux révisions. Réutiliser son UUID avec un autre contenu renvoie 409. Une version obsolète ou un événement antérieur à la dernière révision synchronisée renvoie 409 : l’interface conserve les événements en conflit et permet de les écarter explicitement pour conserver l’état serveur. Les événements hors ligne de plus de 30 jours ou datés de plus de cinq minutes dans le futur sont refusés.

## Données et droits

- `decks` : propriétaire, titre, matière, couleur ; lecture/création/édition/suppression par propriétaire via RLS.
- `documents` : propriétaire, deck, nom, chemin Storage nullable pour texte collé, état ; lecture/création par propriétaire. Pas d’édition directe de l’état.
- `cards` : contenu, choix, réponse, justification, citation source, document, statut ; lecture du propriétaire.
- `card_schedules` : JSON FSRS, échéance et version ; lecture du propriétaire, écriture serveur.
- `review_logs` : état avant/après, version, date, note, UUID d’événement ; lecture du propriétaire, écriture serveur.
- `feynman_attempts` : concept, explication et évaluation ; lecture du propriétaire, écriture serveur.
- `ai_runs` et `ai_daily_usage` : internes, sans grants frontend.

Les clés étrangères composites empêchent d’associer une carte ou un document au deck d’un autre étudiant. Les RPC privilégiées sont révoquées à `public`, `anon` et `authenticated`, et réservées à `service_role`. Les fonctions Security Definer utilisent un `search_path` vide et des références qualifiées. Les opérations IA utilisent un verrou par utilisateur pour ordonner réservations, finalisations et échecs.

Le bucket `courses` est privé, limite serveur 15 Mio, MIME PDF/texte/Markdown, chemin commençant par l’UUID utilisateur. L’interface applique une limite plus conservatrice de 10 Mio. L’interface supprime les fichiers référencés avant de supprimer le deck et ses données relationnelles. La cascade SQL seule ne supprime pas les objets Storage ; une interruption entre upload et enregistrement peut laisser un objet orphelin, à nettoyer si nécessaire.

## Quotas et limites opérationnelles

- Six appels IA par minute et quarante par jour UTC, réservés atomiquement dans PostgreSQL. Les erreurs du fournisseur consomment également une réservation.
- Traitement synchrone borné : un extrait de 40 000 caractères maximum par génération ; aucun pipeline asynchrone ou OCR n’est simulé.
- Les PDF textuels sont extraits dans le navigateur. Les PDF scannés nécessitent un OCR externe avant import.
- Un appel OpenAI est annulé après 45 secondes et limité à 6 000 tokens de sortie. Une génération incomplète est refusée sans sauvegarde partielle ; essayer moins de cartes ou un extrait plus court.
- Une réservation de génération abandonnée expire après trois minutes ; une relance peut ensuite démarrer.
- Les journaux serveur ne contiennent pas les cours, explications, JWT ou réponses complètes du fournisseur.
- Sur iOS, la synchronisation dépend du retour au premier plan et de la connectivité. La conservation IndexedDB n’est pas une sauvegarde durable.
- Adapter les durées de conservation, les quotas et les obligations de confidentialité à votre contexte. Éviter d’importer des dossiers patients identifiants : le texte sélectionné est envoyé au fournisseur IA.

## Validation

Effectué : revue indépendante de la RLS, des grants/RPC, des contrôles de propriétaire et de la concurrence ; vérification exécutée sous Node de l’API `ts-fsrs@5.2.3`, de `next()` et de la sérialisation des dates. Les tests frontend/build du dépôt couvrent l’intégration locale et la file hors ligne.

Non exécuté dans cet environnement : démarrage Supabase local, migration sur un vrai PostgreSQL/Supabase et invocation réelle d’OpenAI. Aucun compte ni secret déployé n’était fourni. Docker était inaccessible et aucun client PostgreSQL/Deno n’était installé.

Pour exécuter les régressions sur une base Supabase de test après les migrations :

```bash
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f supabase/tests/security.sql
```

Ce script crée deux utilisateurs de test, vérifie l’isolation et les droits, l’activation, l’idempotence/version des révisions, la génération atomique et les quotas ; toutes ses écritures sont annulées en fin de transaction. Utiliser une base de test. Effectuer ensuite un test connecté avec deux comptes distincts et une génération IA réelle avant ouverture au public.
