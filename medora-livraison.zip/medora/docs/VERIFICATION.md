# Vérification de Medora 3.0.0

Vérifications exécutées le 27 octobre 2026 sur la livraison MED_ENGINE. Les rapports détaillés sont joints dans ce dossier.

## Code et régressions

- `VITE_BASE_PATH=/medora/ npm run verify` : **118 tests JavaScript réussis**, contrôle TypeScript et compilation Vite/PWA réussis. Ces tests couvrent les fonctionnalités Medora existantes, les nouveaux formats, les imports idempotents, l’isolation des comptes et celle des compteurs MED2/MED_ENGINE.
- **6 tests Python** réussis pour l’assemblage des parties ZIP : empreintes, corruption, parties manquantes, chemins, liens symboliques et refus d’écrasement.
- Comparaison de **275 fichiers** avec la livraison 2.0.1 : contenu MED2, migrations initiales et tous les fichiers des Edge Functions inchangés. Aucun ancien deck ni historique FSRS n’est réinitialisé par la nouvelle migration.

## Contenus repris

**752 fichiers sources conservés à l’identique**, avec comparaison SHA-256 : 141 chapitres de 13 UE, 15 592 notes dans huit formats et 15 605 enregistrements de cartes source. Le lecteur dérive 25 753 variantes indépendantes de rappel, dont 2 752 variantes d’annales. La distinction note/carte/variante évite d’annoncer un faux nombre de questions uniques.

L’import ne signale aucune note invalide, aucun SVG actif dangereux ni référence bibliographique inconnue. Les identifiants entre programmes sont séparés ; les originaux JSON restent téléchargeables.

Le dossier fourni contient 438 images PNG/SVG et 15 schémas HTML avec leurs explications Markdown. **8 699 références d’illustrations sont absentes du Drive**, dans 135 paquets ; 19 695 variantes citent au moins une figure absente. Les emplacements manquants sont signalés sans tentative réseau 404. Les repérages et légendes impossibles à évaluer sans leur image ne produisent pas de réussite ou d’échec et ne sont pas ajoutés aux nouveaux decks FSRS. Leurs textes, réponses et références restent consultables. Aucune image médicale manquante n’a été inventée.

Voir `public/engine/audit.json`, `provenance.json` et [IMPORT-MED-ENGINE.md](IMPORT-MED-ENGINE.md).

## Parcours sur écran mobile

**15 scénarios navigateur réussis**, sans exception JavaScript, erreur console ni ressource HTTP en erreur :

- les quatre onglets d’origine, l’import d’un cours et son activation, FSRS, Feynman en démo et les 69 cours MED2 ;
- le catalogue MED_ENGINE, la recherche, les filtres, les favoris, les notes et l’export du paquet original ;
- QRM avec justifications, textes à trous, QROC et autoévaluation, zones tactiles, légendes et lexique ;
- annales, simulation chronométrée, pause, sauvegarde et reprise sans modifier FSRS ;
- schémas interactifs isolés, suivi, dates personnelles et ajout d’un nouveau deck FSRS en brouillon ;
- absence de débordement à 320, 390, 430 pixels et sur grand écran.

Les cinq vues analysées avec axe WCAG A/AA ne présentent aucune violation détectée : dashboard, catalogue, QRM, schéma et suivi. Ce contrôle ne remplace pas VoiceOver.

[Rapport navigateur](VERIFICATION-NAVIGATEUR-V3.json)

## PWA construite et hors connexion

**10 scénarios supplémentaires réussis** sur la version de production sous `/medora/` : manifest et métadonnées iOS, service worker, téléchargement intégral, rechargement hors connexion et révision FSRS.

Le contrôle de chaque entrée confirme **755 fichiers MED_ENGINE et 265 fichiers MED2 disponibles dans leurs caches**. Des chapitres jamais ouverts avant la coupure s’affichent ensuite sans réseau ; une illustration fournie et un schéma HTML interactif se chargent, les corrections fonctionnent, et les vues restent utilisables aux trois largeurs mobiles. Aucune API privée ou origine étrangère ne figure dans les caches publics.

[Rapport production et hors connexion](VERIFICATION-PWA-V3.json)

## Base de données

Les **trois migrations et 47 assertions SQL passent** dans PGlite/PostgreSQL embarqué. Les suites vérifient RLS, droits des comptes, immuabilité, idempotence et conservation des échéances. Toutes les données de test sont annulées avec `ROLLBACK`.

Auth et Storage utilisent des fixtures minimales ; la configuration de l’extension pgcrypto est omise uniquement dans la base de test, qui fournit déjà `gen_random_uuid()`. Les fichiers SQL de production restent inchangés pour cet essai. Cela ne vérifie ni le Supabase hébergé, ni ses passerelles HTTP, ni des requêtes réellement concurrentes.

[Rapport SQL](VERIFICATION-SQL-V3.json)

## Après installation

Le déploiement sur le dépôt et le projet Supabase de l’utilisateur reste à lancer avec le workflow iPhone mis à jour. Aucun secret personnel ni appel OpenAI réel n’a été utilisé ici. La migration 003 doit être appliquée avant l’ajout de decks MED_ENGINE sur un compte connecté.

Les tests mobiles utilisent Chromium ; une validation sur iPhone physique avec Safari/VoiceOver reste nécessaire. Les contenus médicaux importés n’ont pas fait l’objet d’une nouvelle validation clinique. La progression stockée dans le profil Windows de l’ancienne application n’était pas dans le dossier distribué.

Les captures `v3-iphone-engine-catalogue.png`, `v3-iphone-engine-qrm.png`, `v3-iphone-engine-zone.png` et `v3-offline-engine-reader.png` montrent la démo de cette version.
