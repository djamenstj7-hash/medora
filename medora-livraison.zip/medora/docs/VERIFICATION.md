# Vérification de Medora 2.0.1

Vérifications exécutées sur la livraison du 15 octobre 2026. Les rapports détaillés sont joints dans ce dossier.

## Code et données

- `npm run verify` : **82 tests réussis**, contrôle TypeScript et compilation Vite/PWA réussis. Les tests couvrent FSRS, entrelacement, persistance et conflits hors connexion, isolation des caches, fusion de progression, sauvegardes MED2, planification, dossiers cliniques et installation additive des decks.
- Construction supplémentaire avec `VITE_BASE_PATH=/medora/`, comme le déploiement GitHub Pages. Le chargement des cours et outils est séparé du démarrage de l’application.
- Le catalogue livré contient 69 cours, 484 chapitres, 14 matières et 115 références. Les exercices retirés restent archivés et sont exclus des séances ; les questions communes aux banques ont des identifiants canoniques.
- Les 136 illustrations absentes du ZIP de mise à jour initial ont été récupérées depuis l’ancien site du même propriétaire. **188 fichiers de support sont livrés, sans illustration référencée manquante ni question signalée invalide par l’importateur.** Voir `public/curriculum/audit.json` et [la provenance des illustrations](PROVENANCE-ILLUSTRATIONS.json).
- La migration initiale et les trois handlers Edge Functions Medora restent identiques à la première livraison. Le schéma MED2 est ajouté dans une nouvelle migration. En version 2.0.1, le client affiche une aide en français pour les erreurs de connexion ; le fichier partagé `ai.ts` distingue les erreurs OpenAI avec le classifieur testé `ai-errors.ts` (clé, permissions, modèle, quota, débit, délai et indisponibilité), sans divulguer de réponse brute du fournisseur.

## Parcours d’utilisation

**18 scénarios de navigateur réussis**, sans exception JavaScript, erreur console ni réponse HTTP en erreur :

- les quatre onglets d’origine, l’import de cours avec activation du brouillon, une révision FSRS hors connexion et Feynman en démonstration ;
- catalogue, recherche, lecteur, sommaire, zoom d’illustration, notes persistantes, favoris, QRM, QROC, rédaction hors SSH, cartes et évaluation avec correction différée ;
- passage du lecteur à Feynman avec son extrait, ajout d’un nouveau deck FSRS en brouillon en conservant les decks existants ;
- séance chronométrée sauvegardée puis reprise, bilan, planning, budget, mission et date d’examen personnalisée ;
- export puis fusion d’une sauvegarde et dispositions à 320, 390 et 1 440 pixels.

L’analyse axe WCAG A/AA ne signale aucune violation dans les sept vues contrôlées : dashboard, catalogue, lecteur, QCM, bilan, planning et réglages. Ce contrôle automatique ne remplace pas une validation VoiceOver.

[Rapport navigateur](VERIFICATION-NAVIGATEUR-V2.json)

## Production et hors connexion

**8 scénarios supplémentaires réussis** sur la version construite sous `/medora/` : métadonnées iOS, manifest, icônes, périmètre du service worker, téléchargement du programme et rechargement sans réseau.

Les **265 ressources publiques attendues** sont présentes dans le cache : manifest, 69 cours, 8 banques et supports utilisés par le téléchargement. Un cours et des banques jamais ouverts avant la coupure s’affichent hors connexion ; les illustrations se décodent et les corrections d’exercice fonctionnent. Les écrans contrôlés n’ont pas de débordement horizontal à 320, 390 et 430 pixels. Aucune donnée d’API privée n’est placée dans le cache public du programme.

[Rapport PWA et hors connexion](VERIFICATION-PWA-V2.json)

## Base de données

Les deux migrations et les deux suites SQL ont été exécutées avec succès dans **PGlite, un PostgreSQL embarqué isolé**. Les 27 assertions des scripts vérifient notamment les politiques RLS, les droits entre comptes, l’immuabilité des événements, la préservation des révisions et l’installation idempotente des cartes. Les données de test sont annulées par `ROLLBACK`.

Les schémas Auth et Storage sont des fixtures minimales ; seule l’instruction d’installation de l’extension pgcrypto est omise dans cette base de test, qui fournit déjà `gen_random_uuid()`. Les fichiers SQL de production n’ont pas été modifiés pour cet essai. Cela ne vérifie ni la passerelle API Supabase, ni des requêtes réellement concurrentes, ni le déploiement dans un projet hébergé.

[Rapport SQL](VERIFICATION-SQL-V2.json)

## À vérifier après ta mise à jour

Aucun identifiant Supabase/OpenAI personnel n’a été utilisé et le site existant n’a pas été publié depuis cet environnement. Le workflow doit appliquer la migration dans ton projet ; vérifie ensuite la connexion, la synchronisation entre appareils et les appels IA réels.

Les essais mobiles utilisent Chromium avec des dimensions de téléphone. Une validation sur iPhone physique avec Safari et VoiceOver reste nécessaire. Les cours repris n’ont pas fait l’objet d’une nouvelle validation médicale ; les références sans document fourni ne sont pas transformées en faux cours ou corrigés.

Les captures `v2-iphone-dashboard.png`, `v2-iphone-reader.png` et `v2-iphone-planning.png` montrent la nouvelle version en démonstration.
