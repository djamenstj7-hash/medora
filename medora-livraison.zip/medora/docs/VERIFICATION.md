# Vérification de la livraison

Les vérifications suivantes ont été exécutées sur le code livré :

- `npm test` : 17 tests passent (FSRS, entrelacement, pagination, persistance avant envoi, reprise idempotente, conflits et isolation des caches).
- `npm run build` : TypeScript et compilation Vite/PWA réussissent.
- Construction avec `VITE_BASE_PATH=/medora/` : manifest et ressources produits avec le chemin de dépôt GitHub Pages.
- Navigateur Chromium, viewport mobile 390 × 844 : dashboard, révision avec révélation puis évaluation, recherche de deck, import de texte, relecture, activation, Feynman et rechargement vérifiés sans erreur JavaScript.
- Analyse automatique axe WCAG A/AA du tableau de bord : aucune violation détectée lors de la vérification. Cela ne remplace pas une vérification VoiceOver complète.
- Version construite sous `/medora/` : service worker actif, rechargement hors connexion, révision hors connexion, extraction d’un PDF textuel et absence de débordement à 320, 375, 390 et 430 px vérifiés.
- Audit npm des dépendances de production : aucune vulnérabilité déclarée au moment de l’exécution.

Les captures `apercu-iphone.png` et `apercu-desktop.png` montrent la démo locale.

## Vérifications à effectuer avec vos comptes

Aucun projet Supabase ni secret OpenAI n’était fourni. Les fonctions sont livrées mais les appels à ces services réels et le déploiement GitHub Actions n’ont pas été exécutés. Le script `supabase/tests/security.sql` permet de vérifier les politiques de la base sur un projet de développement. Les éventuels contrôles PostgreSQL complémentaires sont décrits dans BACKEND.md.

Les essais de navigateur ont utilisé Chromium avec des dimensions mobiles ; une validation sur un iPhone physique avec Safari/VoiceOver reste à effectuer selon le guide INSTALLATION.
