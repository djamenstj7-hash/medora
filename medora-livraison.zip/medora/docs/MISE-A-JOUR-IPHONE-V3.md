# Ajouter MED_ENGINE à Medora depuis ton iPhone

Cette mise à jour ajoute les contenus de ton ancienne application MED_ENGINE à ta Medora actuelle. Tu conserves le même dépôt GitHub, le même projet Supabase et la même adresse : **https://djamenstj7-hash.github.io/medora/**.

Les 69 cours MED2, tes decks personnels, FSRS, l’import texte/PDF, Feynman et les outils déjà installés restent présents.

La nouvelle bibliothèque comprend **141 chapitres dans 13 UE**, avec **15 592 notes**. Leurs textes à trous et repérages donnent **25 753 variantes de travail**, dont 2 752 d’annales ; ce total est distinct des 15 605 cartes enregistrées dans les paquets Windows. Les 15 schémas HTML fournis et leurs explications sont repris.

**État des illustrations dans le dossier reçu :** les 752 fichiers fournis ont été conservés et vérifiés, dont 438 images PNG/SVG. En revanche, les paquets citent aussi 8 699 références de figures absentes de ce dossier, réparties sur 135 chapitres. Par exemple, le dossier `media` d’« Abord et examen clinique du malade » était vide sur Drive. Medora signale ces images comme non fournies ; elle ne les invente pas. Les textes et corrections restent présents, mais un repérage visuel nécessite sa figure pour être travaillé normalement.

Cette livraison comporte **trois ZIP** : `medora-livraison.zip`, `medora-contenus-engine-1.zip` et `medora-contenus-engine-2.zip`. Les deux parties sont nécessaires. Le fichier `installation-iphone-v3.txt` sert à mettre à jour le workflow, et ce guide explique l’ordre.

## 1. Préserver tes données

Ouvre Medora avec Internet et laisse la synchronisation se terminer. Dans les réglages, utilise **Exporter ma sauvegarde** et enregistre le JSON dans Fichiers. Garde ta session et les données Safari pendant la mise à jour.

Le dossier Windows MED_ENGINE contient les contenus distribués avec l’application. Il ne contient pas les révisions personnelles stockées dans le profil Windows. Cette livraison n’invente ni anciens résultats ni échéances FSRS.

## 2. Télécharger tous les fichiers de la livraison

Depuis les liens Drive fournis avec cette version, télécharge :

- **`medora-livraison.zip`** : l’archive principale ;
- **toutes les archives `medora-contenus-engine-…zip` fournies avec elle** : les parties complémentaires des contenus ;
- le fichier texte du nouveau workflow, **`installation-iphone-v3.txt`**.

Chaque ZIP reste sous la limite d’envoi d’un fichier dans le navigateur GitHub. Les parties contiennent l’ensemble des données MED_ENGINE de cette livraison, y compris les paquets JSON et les images fournies. Elles ne contiennent pas uniquement des illustrations.

Dans Fichiers, garde les noms exacts. Si l’iPhone a ajouté « 2 » ou « (1) », renomme le fichier. **Ne décompresse aucun ZIP** : GitHub Actions les rassemble.

## 3. Mettre à jour le workflow une seule fois

Le workflow déjà présent sait extraire un seul ZIP. Cette version lui ajoute la vérification et l’extraction des parties complémentaires.

1. Dans Safari, ouvre **https://github.com/djamenstj7-hash/medora** et la branche **main**.
2. Ouvre **`.github` → `workflows` → `installation-iphone.yml`**.
3. Choisis **Edit file** — le crayon, parfois dans le menu **…**.
4. Remplace tout le contenu de l’éditeur par le texte complet du fichier **`installation-iphone-v3.txt`** fourni. Ce fichier contient le workflow, sans balises Markdown à copier.
5. Touche **Commit changes**, directement sur **main**.

Si Safari masque une commande, active la **version pour ordinateur** dans son menu de page. Le fichier à modifier conserve exactement le chemin **`.github/workflows/installation-iphone.yml`** ; il ne faut pas créer un simple fichier texte à la racine.

Pour une installation classique avec les sources, le modèle identique se trouve dans `docs/iphone/installation-iphone.yml`. Le workflow utilise le vérificateur inclus dans l’archive principale ; aucun script n’est à installer sur l’iPhone.

## 4. Envoyer les ZIP sur GitHub

1. Reviens à la racine du dépôt, dans **Code → main**.
2. Choisis **Add file → Upload files**.
3. Envoie le nouveau **`medora-livraison.zip`** pour remplacer l’ancien, ainsi que toutes ses parties **`medora-contenus-engine-…zip`**.
4. Vérifie les noms, puis touche **Commit changes** sur **main**.

Si tu envoies les fichiers en plusieurs fois, termine tous les envois avant de lancer l’installation. Garde l’ancienne application ouverte seulement pour consulter ou synchroniser ; la nouvelle version sera publiée par le workflow.

## 5. Lancer la mise à jour

1. Ouvre **Actions → Installer Medora depuis un iPhone**. L’onglet Actions peut être dans **More**.
2. Touche **Run workflow** et choisis **main**.
3. **Laisse cochée « Installer ou mettre à jour Supabase ».** La migration `202610270003_med_engine.sql` ajoute la liaison des cartes MED_ENGINE avec les decks personnels. Elle conserve les données et les journaux de révision existants.
4. Lance le workflow et attends la coche verte finale.

Le workflow vérifie les empreintes de toutes les parties avant de les extraire. Si un ZIP manque, appartient à une autre version ou est endommagé, il s’arrête avant la compilation et la publication. Ouvre l’étape rouge : son message donne le nom du fichier à remplacer ou à ajouter. Relance ensuite le workflow.

Les variables et secrets habituels restent utilisés. Si le jeton personnel Supabase a expiré, remplace **`SUPABASE_ACCESS_TOKEN`** dans **GitHub → Settings → Secrets and variables → Actions → Secrets**, puis relance. Il s’agit du jeton de déploiement Supabase, pas de la clé OpenAI. Le mot de passe existant reste dans **`SUPABASE_DB_PASSWORD`**.

## 6. Ouvrir MED_ENGINE dans Medora

Après la coche verte, ouvre Medora avec Internet et accepte **Mettre à jour** si proposé. Si l’ancienne version s’affiche, ferme puis rouvre l’application ou actualise Safari.

Vérifie d’abord tes anciens decks et un des 69 cours MED2. Le nouveau contenu se trouve dans **Bibliothèque → MED_ENGINE** :

- **Chapitres** : recherche et filtres par UE, format, niveau et thème ;
- **Comprendre** : les schémas interactifs et leurs explications ;
- **Mon suivi** : l’activité enregistrée dans cette version.

Dans un chapitre :

- **Bachoter** permet un entraînement libre ; **Annales** sélectionne les questions d’examen ; ces séances ne déplacent pas les échéances FSRS.
- **Simulation** conserve les corrections jusqu’au bilan de la séance.
- **Ajouter à mes decks FSRS** crée ou retrouve un nouveau deck personnel en brouillon. Relis ses réponses et active-le pour l’intégrer aux révisions espacées.
- **Sources & guide** conserve les références et les précisions de l’ancien paquet ; **Télécharger le paquet source** permet de garder sa version JSON.

Les corrections officielles, déduites ou signalées « à relire » restent distinguées. Les 82 variantes marquées comme non vérifiées gardent leur mention. Les contenus préécrits sont utilisables sans crédits OpenAI. La génération de nouveaux contenus et Feynman restent reliés à l’API configurée ; cette livraison n’ajoute pas Gemini.

## 7. Préparer le hors connexion

Ouvre les **réglages → Mon programme hors connexion → Télécharger MED_ENGINE**. Garde l’application ouverte et connectée jusqu’à la fin du téléchargement. Le bouton **Télécharger le programme** prépare séparément les cours MED2. Les fichiers disponibles sur cet appareil peuvent ensuite être consultés sans réseau.

Le téléchargement prépare les fichiers effectivement fournis. Il ne recrée pas les figures absentes de la source et ne télécharge pas les PDF ou documents externes cités. Rouvre l’application en ligne pour synchroniser ton suivi et conserve une sauvegarde JSON.

Les détails techniques et les limites d’import sont décrits dans [IMPORT-MED-ENGINE.md](IMPORT-MED-ENGINE.md). Les vérifications réellement exécutées figurent dans [VERIFICATION.md](VERIFICATION.md).
