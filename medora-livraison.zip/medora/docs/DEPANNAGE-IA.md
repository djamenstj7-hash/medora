# Génération IA : identifier le blocage

## « Failed to send a request to the Edge Function »

Le navigateur n’obtient pas de réponse lisible de la fonction. Vérifier la connexion et le secret Supabase `ALLOWED_ORIGINS`. Pour le site actuel, sa valeur exacte est :

```text
https://djamenstj7-hash.github.io
```

Aucun `/` final ni chemin `/medora/`. Enregistrer dans **Supabase → medora → Edge Functions → Secrets**, puis actualiser Medora. Des vérifications publiques OPTIONS ont confirmé que la configuration avec un `/` final refusait l’origine réellement envoyée par Safari. Cette correction concerne aussi Feynman et les révisions.

## « Le fournisseur IA est indisponible » dans l’ancienne version

Ce message regroupe toutes les réponses OpenAI en erreur ; il ne prouve pas une panne. Il peut s’agir de facturation API, d’une clé refusée, d’un accès au modèle ou d’une limite de débit.

1. Ouvrir [Billing OpenAI](https://platform.openai.com/settings/organization/billing/overview), dans l’organisation et le projet auxquels appartient la clé. Vérifier le crédit disponible et les éventuelles limites de facturation. Un abonnement ChatGPT ne fournit pas de crédit API.
2. Dans **Supabase → Edge Functions → Secrets**, vérifier que `OPENAI_MODEL` vaut `gpt-4o-mini`, sauf si un autre modèle compatible a été volontairement choisi.
3. Vérifier dans OpenAI que la clé utilisée est active et autorise la génération de réponses. En cas de remplacement, la nouvelle clé va uniquement dans `OPENAI_API_KEY` dans les secrets Supabase.

Les 28 504 caractères et les six cartes de la capture sont dans les limites de l’application. L’erreur ne justifie pas à elle seule de raccourcir le PDF.

## Correctif 2.0.1

Le ZIP comprend des messages français distincts pour les erreurs de clé, droits, modèle, quota, débit, délai, paramètres et panne. Les journaux serveur enregistrent seulement le statut HTTP du fournisseur et une catégorie sûre : aucune clé, réponse brute ou note de cours n’est ajoutée à ces journaux.

Remplacer le ZIP dans le même dépôt puis lancer **Installer Medora depuis un iPhone**, avec **Installer ou mettre à jour Supabase** coché. Le correctif ne change pas les tables ni les decks existants et ne crée aucun crédit API. Les appels OpenAI réels nécessitent toujours un compte et une facturation API disponibles.

Après un échec, le deck existant reste en brouillon. Éviter les appuis répétés pendant le diagnostic : chaque nouvel import de l’ancienne version peut créer un autre brouillon.
