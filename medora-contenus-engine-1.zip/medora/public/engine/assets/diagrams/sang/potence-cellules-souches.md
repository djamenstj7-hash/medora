---
id: sang/potence-cellules-souches
titre: L'échelle de potence — totipotente, pluripotente, multipotente, unipotente (et où se place la CSH)
ue: Tissu sanguin
chapitre: Cellules souches et progéniteurs hématopoïétiques, I. Expérience de Till et McCulloch et II.A CSH (ronéo 2026-27, p. 4-5)
themes_app: []
cartes_en_plus: [sso-fa-potence, sso-rv-potence, sso-qc-potence, sso-fa-proprietes, sso-qc-proprietes, sso-an-qr-proprietes, sso-qc-progeniteurs, sso-an-2122s1-q3, sso-an-2425-q2, sso-ech-m3, csd-fa-toti-pluri, csd-fa-multi-uni, csd-rv-toti-pluri, csd-rv-multi-uni, csd-qc-potentialites, csd-qc-hierarchie, csd-zo-potentialites, csd-qc-cs-adultes, lex-totipotent, lex-pluripotent, lex-multipotent, lex-unipotent]
cartes_exclues: []
mots_cles: [potence, totipotente, pluripotente, multipotente, unipotente, cellule souche hématopoïétique, CSH, cellules souches embryonnaires, iPS, cellules souches adultes, précurseurs]
schema: potence-cellules-souches.html
majeur: true
date: 2026-10-20
---

## Explication

> Le cours de tissu sanguin (Pr Duployez, ronéo 2026-27, p. 4) ne cite que deux niveaux, pour les opposer : la CSH est multipotente, « à ne pas confondre avec totipotentes ». L'échelle complète vient du cours de BMCP sur les cellules souches (`bmcp_cellules_souches`) ; les annales de tissu sanguin s'en servent. `chapitre_app` liste donc les deux chapitres.

### L'échelle

La potence est l'éventail de cellules différentes qu'une cellule peut encore produire. Elle se restreint à chaque étape, et l'on ne remonte jamais.

- **Totipotente** : un individu entier, annexes comprises (placenta). Ex. l'ovocyte fécondé, jusqu'au stade 8 cellules.
- **Pluripotente** : les trois feuillets, tout l'organisme, mais pas le placenta. Ex. les cellules souches embryonnaires (masse cellulaire interne du blastocyste), les iPS.
- **Multipotente** : un seul tissu, mais plusieurs types de cellules. Ex. la CSH, qui donne toutes les cellules du sang ; les cellules souches mésenchymateuses (os, cartilage, tissu adipeux).
- **Unipotente** : un seul type de cellule, mais s'auto-renouvelle. Ex. la spermatogonie, la cellule souche de la peau (kératinocytes).
- Puis la **cellule mature**, qui ne se divise plus.

Les cellules souches adultes sont « uniquement multi et unipotentes » (BMCP, p. 3).

### Ce que dit le cours de tissu sanguin

« Cellules souches hématopoïétiques multipotentes = capables de donner plusieurs cellules sanguines (d'un même tissu). À ne pas confondre avec totipotentes → les CSH ne sont pas capables de donner n'importe quelle cellule de l'organisme ! » (p. 4). La multipotence est l'une des quatre propriétés des CSH à retenir : auto-renouvellement, multipotence, quiescence, migration (p. 9).

### Les pièges des annales

- « La CSH est pluripotente » : faux, elle est multipotente. Une ancienne grille de correction écrit parfois « pluripotence » : répondre multipotence.
- « Les précurseurs sont des cellules pluripotentes » : faux deux fois, ils ne sont même plus multipotents (engagés dans une lignée, sans auto-renouvellement).
- « Les cellules souches adultes sont totipotentes » : faux, elles sont multi- ou unipotentes.

## Cartes

### Q: Quelle différence entre une cellule totipotente et une cellule pluripotente ?
R: La totipotente forme un individu entier, annexes comprises (placenta) ; la pluripotente donne les trois feuillets et tout l'organisme, mais pas les annexes : elle ne peut pas former un individu à elle seule.

### Q: Pourquoi la cellule souche hématopoïétique est-elle dite multipotente, et non pluripotente ?
R: Elle donne plusieurs types de cellules, mais d'un seul tissu : toutes les cellules du sang, et rien d'autre. Une pluripotente donnerait tous les tissus de l'organisme.

### Q: Quel niveau de potence ont les cellules souches adultes ?
R: Uniquement multipotentes ou unipotentes (ex. CSH multipotente, spermatogonie unipotente) ; jamais toti- ou pluripotentes.

### Q: Les précurseurs hématopoïétiques sont-ils pluripotents ?
R: Non : ils ne sont même plus multipotents. Ils sont engagés dans une seule lignée et n'ont plus d'auto-renouvellement.
