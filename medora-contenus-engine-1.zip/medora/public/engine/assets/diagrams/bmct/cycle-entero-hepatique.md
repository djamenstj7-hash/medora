---
id: bmct/cycle-entero-hepatique
titre: Le cycle entéro-hépatique
ue: BMCT
chapitre: FC n°2 - Pharmacocinétique appliquée, I.A Élimination biliaire, cycle entéro-hépatique (partie 3, p. 2)
themes_app: []
cartes_en_plus: [pk-fa-cycle-entero-hepatique, pk-qc-entero-hepatique, pk-qc-quiz-elimination, pk-pl-entero-hepatique, pk-ech-s25, pk-ech-s29, pk-ech-m6, pk-an-2425s1-q10, pk-an-2223s1-q6, pk-an-2122s1-q11, pk-an-2021s2-q8, lex-entero-hepatique, lex-glucuronoconjugaison, pk-qr-glucuronidases, pk-ech-s28]
cartes_exclues: []
mots_cles: [cycle entéro-hépatique, élimination biliaire, glucuronoconjugaison, β-glucuronidases, flore intestinale, veine porte, demi-vie apparente, estroprogestatifs, antibiotiques]
schema: cycle-entero-hepatique.html
majeur: true
date: 2026-10-19
---

## Explication

> Cours : partie 3, p. 2 (ronéo 2026-27) et FC 2025-26, p. 18-19. Le second pic de concentration et le lien avec les sels biliaires et la bilirubine sont du complément. `cartes_app` liste toutes les cartes du chapitre qui demandent la notion, y compris `pk-ech-s25` (sécrétion tubulaire), où le cycle est un distracteur à ne pas confondre.

### Les étapes

1. **Dans le foie**, le médicament est glucuronoconjugué (réaction de phase II) : plus gros et plus hydrosoluble, il peut être excrété dans la bile.
2. **Dans l'intestin**, les β-glucuronidases des bactéries coupent le glucuronide : le médicament retrouve sa forme libre, active.
3. **La forme libre est réabsorbée** et revient au foie par la veine porte, puis dans la circulation générale. Il peut faire plusieurs tours ; seule la part non réabsorbée part dans les selles.

### Les conséquences

- **La demi-vie apparente s'allonge** : le médicament est périodiquement réintroduit dans la circulation (un second pic peut apparaître sur la courbe de concentration).
- **Les estroprogestatifs** sont les plus concernés : le cycle entretient leur effet malgré des microdoses, une prise par jour suffit. Autres exemples du cours : digitoxine, imipramine, acide valproïque, spironolactone.
- **Une flore très perturbée rompt le cycle** (antibiotique à large spectre, décontamination intestinale) : moins de réabsorption, moins d'effet. Le cours en tire le risque d'échec d'une contraception orale sous antibiotique (à répondre ainsi à l'examen, bien que l'importance réelle de cette interaction soit discutée).

### Ne pas confondre

- Cycle entéro-hépatique : voie biliaire, foie et intestin.
- Compétition à la sécrétion tubulaire : rein ; deux médicaments sécrétés par le même transporteur du tubule (méthotrexate et pénicilline) se gênent.
- Compétition sur l'albumine : sang, au moment de la distribution.

Le cycle est aussi de la physiologie : les sels biliaires (environ 95 % réabsorbés dans l'iléon) et en partie la bilirubine (via l'urobilinogène) font le même tour.

### Erreur du ronéo

Le ronéo fait fixer le médicament « sur les acides biliaires » (partie 3, p. 2) : c'est un conjugué glucuronide que le foie excrète dans la bile (déjà signalé `ATTENTION` dans `pk-qc-entero-hepatique`).

## Cartes

### Q: Pourquoi le médicament doit-il être déconjugué dans l'intestin pour être réabsorbé ?
R: Le glucuronoconjugué est gros et hydrosoluble : il ne traverse pas la paroi intestinale. Les β-glucuronidases bactériennes libèrent la forme active, qui, elle, est réabsorbée vers la veine porte.

### Q: Pourquoi un antibiotique à large spectre peut-il diminuer l'effet d'un médicament soumis au cycle entéro-hépatique ?
R: Il détruit la flore intestinale : la déconjugaison ne se fait plus, le médicament reste conjugué et part dans les selles au lieu d'être réabsorbé (exemple du cours : contraception orale).

### Q: Quel est l'effet du cycle entéro-hépatique sur la demi-vie apparente d'un médicament ?
R: Il la prolonge : le médicament est périodiquement réintroduit dans la circulation au lieu d'être éliminé.

### Q: Dans quel organe se joue la compétition entre méthotrexate et pénicilline, et dans lequel le cycle entéro-hépatique ?
R: La compétition se joue dans le rein (sécrétion tubulaire, même transporteur) ; le cycle entéro-hépatique passe par le foie, la bile et l'intestin.
