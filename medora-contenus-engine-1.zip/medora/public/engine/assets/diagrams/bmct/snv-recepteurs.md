---
id: bmct/snv-recepteurs
titre: Système nerveux végétatif — synthèse : neurones, synapses, médiateurs et récepteurs du sympathique et du parasympathique
ue: BMCT
chapitre: FC n°4 - Pharmacologie du système nerveux végétatif, II.C Relais ganglionnaire et récepteurs nicotiniques (p. 6-7)
themes_app: [bmct_snv/synapse-cholinergique, bmct_snv/organisation-snv]
cartes_en_plus: [snv-ech-s20, snv-qc-synapse-adrenergique, snv-fa-synthese-na, snv-qc-recepteurs-adrenergiques]
cartes_exclues: [snv-qr-claude-bernard, snv-qr-hypothalamus, snv-fa-niveaux, snv-qc-niveaux, snv-fa-fonctions, snv-ech-s1]
mots_cles: [choline, nicotine, muscarine, acétylcholinestérase, adrénergique, cholinergique, système nerveux végétatif, sympathique, parasympathique, relais ganglionnaire, récepteur nicotinique, récepteur muscarinique, récepteurs adrénergiques, acétylcholine, noradrénaline, médullosurrénale, curares]
schema: snv-recepteurs.html
majeur: true
date: 2026-10-20
---

## Explication

> Cours : relais ganglionnaire « organisé de la même façon dans les deux systèmes » (FC p. 11 ; ronéo p. 6-7), médullosurrénale (p. 7), curares (FC 2025-26, p. 22). Les sous-types de récepteurs nicotiniques, les ganglioplégiques et les glandes sudoripares sont du complément.

### Le schéma

Deux schémas construits pareil, l'un sous l'autre (sympathique, parasympathique) : deux neurones, deux synapses, et à chaque synapse le médiateur libéré et le récepteur qui le reçoit ; en bas, un encadré « Qui est quoi ». Repère visuel : l'acétylcholine (vert) est partout, sauf au bout du sympathique, où c'est la noradrénaline (orange).

### Comment le lire

Le système nerveux végétatif utilise toujours deux neurones à la suite : le premier part du système nerveux central (moelle ou tronc cérébral) et fait relais dans un ganglion avec le second, qui va à l'organe.

1. **Au ganglion, c'est toujours pareil** : le premier neurone libère de l'acétylcholine sur un récepteur nicotinique du second, dans le sympathique comme dans le parasympathique.
2. **À l'organe, les deux systèmes divergent** : le sympathique libère de la noradrénaline sur des récepteurs α et β (adrénergiques) ; le parasympathique libère de l'acétylcholine, cette fois sur des récepteurs muscariniques.

Le piège (réponse B de `snv-ech-s20`) : le parasympathique utilise l'acétylcholine deux fois, mais sur deux récepteurs différents, nicotinique au ganglion, muscarinique sur l'organe.

### La géographie

- Sympathique : ganglions près de la moelle, le long de la colonne ; premier neurone court, second long.
- Parasympathique : ganglions près de l'organe, voire dans sa paroi ; premier neurone long, second très court.

### Pour comparer : le somatique

Le motoneurone va directement de la moelle au muscle strié, sans ganglion, et agit lui aussi sur des récepteurs nicotiniques. Ce ne sont pas les mêmes sous-types qu'au ganglion, ce qui permet de cibler l'un sans l'autre : les curares bloquent ceux du muscle (paralysie de l'anesthésie), les ganglioplégiques ceux des ganglions.

### Choline, nicotine, muscarine : trois rôles différents

- **Choline** : matière première et déchet de l'acétylcholine. Le neurone fabrique l'acétylcholine à partir de choline et d'un groupement acétyle ; libérée, l'acétylcholine est coupée par l'acétylcholinestérase en choline et acétate, et la choline est recaptée pour en refaire. Elle n'agit sur aucun récepteur. « Cholinergique » = qui fonctionne avec l'acétylcholine.
- **Nicotine, muscarine** : molécules extérieures (tabac ; amanite tue-mouches). Chacune n'active qu'un des deux types de récepteurs à l'acétylcholine, qui portent donc leur nom : nicotinique (ganglions, muscle strié), muscarinique (tissus cibles du parasympathique). Le cours : « nicotiniques parce que nicotine = agoniste ».
- Dans le parasympathique, un seul médiateur, l'acétylcholine, aux deux étages ; seul le récepteur change.

### Deux exceptions du sympathique

- La médullosurrénale fonctionne comme un ganglion : elle reçoit l'acétylcholine sur des récepteurs nicotiniques et libère de l'adrénaline directement dans le sang.
- Les glandes sudoripares sont commandées par le sympathique, mais par de l'acétylcholine sur des récepteurs muscariniques.

## Cartes

### Q: Quel neuromédiateur et quel récepteur au relais ganglionnaire, dans le sympathique et dans le parasympathique ?
R: Les mêmes dans les deux systèmes : l'acétylcholine, sur un récepteur nicotinique du second neurone.

### Q: Sur quels récepteurs agissent les médiateurs libérés sur l'organe par le sympathique et par le parasympathique ?
R: Sympathique : noradrénaline sur des récepteurs adrénergiques α et β. Parasympathique : acétylcholine sur des récepteurs muscariniques.

### Q: Où sont situés les ganglions du sympathique et du parasympathique ?
R: Sympathique : près de la moelle, le long de la colonne (premier neurone court, second long). Parasympathique : près de l'organe ou dans sa paroi (premier neurone long, second très court).

### Q: En quoi la médullosurrénale ressemble-t-elle à un ganglion sympathique ?
R: Elle reçoit l'acétylcholine du premier neurone sur des récepteurs nicotiniques, comme un second neurone, et libère de l'adrénaline directement dans le sang.

### Q: Quel est le rôle de la choline dans la synapse cholinergique ?
R: Ce n'est pas un médiateur : c'est la matière première de l'acétylcholine et son produit de dégradation. L'acétylcholinestérase coupe l'acétylcholine en choline et acétate ; la choline est recaptée par le neurone pour en refaire.

### Q: Pourquoi parle-t-on de récepteurs « nicotiniques » et « muscariniques » ?
R: Ce sont les deux types de récepteurs à l'acétylcholine. Chacun est activé aussi par une molécule extérieure qui lui a donné son nom : la nicotine (tabac) pour le nicotinique, la muscarine (champignon) pour le muscarinique.
