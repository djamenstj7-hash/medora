---
id: bmct/phases-essais-dose
titre: Les phases du développement d'un médicament — ce que chaque phase mesure en fonction de la dose
ue: BMCT
chapitre: FC n°1 - Pharmacodynamie générale, IV. Phases du développement (p. 7)
themes_app: []
cartes_en_plus: [pdg-fa-phases, pdg-qc-phases, pdg-an-1617s1-q2c, pdg-qc-comparaison, pdg-ech-s22, pdg-ech-s23, pdg-ech-s24, pdg-rv-critere-jugement]
cartes_exclues: []
mots_cles: [développement du médicament, AMM, phase 4, groupe témoin, placebo, traitement de référence, phase 1, phase 2, phase 3, dose maximale tolérée, relation dose-réponse, posologie, fenêtre thérapeutique, effets indésirables, critère de jugement]
schema: phases-essais-dose.html
majeur: true
date: 2026-10-18
---

## Explication

> Le cours (p. 7) donne : phase I, toxicité globale et dose maximale tolérée, chez des volontaires sains ou des patients atteints de cancer ; phase II, efficacité et relation dose-réponse pour fixer la posologie ; phase III, efficacité à plus grande échelle. Les courbes du schéma sont schématiques.

### De quelles phases parle-t-on ?

Des phases du développement d'un médicament : la suite d'essais qu'une molécule doit franchir avant d'être autorisée à la vente, puis après. Préclinique (laboratoire, animal), puis trois phases chez l'homme (1, 2, 3), puis l'autorisation de mise sur le marché (AMM), puis la phase 4, le suivi du médicament commercialisé en vie réelle. C'est la frise en tête du schéma.

### Les courbes

Deux courbes en fonction de la dose : l'efficacité (proportion de sujets qui répondent) monte tôt ; la fréquence des effets indésirables monte plus tard. Entre la dose minimale efficace et la dose maximale tolérée, la zone explorée en phase 2 ; dans cette zone, la dose choisie en phase 2, puis testée seule en phase 3.

### Phase 1 : le plafond

Chez des volontaires sains (directement chez des patients en cancérologie, les molécules étant trop toxiques), on augmente la dose par paliers et l'on note la fréquence et la gravité des effets indésirables. On s'arrête quand ils deviennent inacceptables : c'est la dose maximale tolérée. La courbe tracée est donc dose / fréquence des effets indésirables, pas dose / efficacité : chez un sujet sain, il n'y a pas de maladie à améliorer.

### Phase 2 : la bonne dose

Les premiers patients, en petit nombre. On teste plusieurs doses sous la dose maximale tolérée pour tracer la relation dose-réponse (efficacité) et fixer la posologie. D'où des critères de jugement qui bougent vite et se mesurent chez peu de patients : biologiques, d'imagerie (annale 2016/2017, Q2 c), à côté des critères cliniques.

### Phase 3 : la preuve

La dose choisie en phase 2, et elle seule, chez beaucoup de patients. Elle ne compare plus des doses entre elles : elle compare un groupe traité (la molécule) à un groupe témoin. Le placebo n'est pas un groupe à part, c'est ce que reçoit le groupe témoin quand il n'existe aucun traitement ; s'il en existe un, le groupe témoin reçoit le traitement de référence, pour ne pas faire perdre de chances aux patients. Groupes comparables (randomisation, double aveugle), résultat significatif : elle démontre l'efficacité à grande échelle, ce qui permet l'AMM.

La comparaison à un groupe témoin existe aussi en phase 2 (annale 2016/2017, Q2 b), mais sur peu de patients, pour trouver la dose.

### À retenir

Les phases 1 et 2 font toutes deux varier la dose, mais pas pour la même mesure : tolérance en phase 1, efficacité en phase 2. La phase 1 donne le plafond, la phase 2 cherche la bonne dose sous ce plafond, la phase 3 la valide.

## Cartes

### Q: Quelle courbe trace-t-on en phase 1, et pourquoi pas une courbe d'efficacité ?
R: La fréquence des effets indésirables en fonction de la dose, jusqu'à la dose maximale tolérée. Pas d'efficacité : la phase 1 se fait chez des volontaires sains, qui n'ont pas de maladie à améliorer (sauf en cancérologie, où elle se fait chez des patients).

### Q: Que cherche la phase 2, et dans quelle gamme de doses ?
R: L'efficacité et la relation dose-réponse chez les premiers patients, pour fixer la posologie ; elle explore les doses entre la dose minimale efficace et la dose maximale tolérée fixée en phase 1.

### Q: En quoi la phase 3 diffère-t-elle des phases 1 et 2 vis-à-vis de la dose ?
R: Elle ne fait plus varier la dose : elle teste la dose retenue en phase 2, chez beaucoup de patients, par comparaison (placebo ou référence), pour démontrer l'efficacité à grande échelle.

### Q: En phase 3, que reçoit le groupe témoin ?
R: Un placebo s'il n'existe aucun traitement de la maladie ; le traitement de référence s'il en existe un, pour ne pas faire perdre de chances aux patients. Le groupe traité reçoit la molécule à la dose choisie en phase 2.

### Q: Dans quel ordre se succèdent les étapes du développement d'un médicament ?
R: Préclinique (laboratoire, animal), phase 1 (tolérance, dose maximale tolérée), phase 2 (efficacité, dose-réponse, posologie), phase 3 (preuve à grande échelle par comparaison), AMM, puis phase 4 (suivi en vie réelle).
