---
id: bmct/potentiel-action
titre: Potentiel d'action et canaux ioniques
ue: BMCT
chapitre: FC n°1 - Pharmacodynamie générale, I.A Introduction (p. 2)
themes_app: []
cartes_en_plus: [pdg-fa-moelle, pdg-qc-influx, pdg-qr-xylocaine]
cartes_exclues: []
mots_cles: [potentiel d'action, canaux sodiques voltage-dépendants, canaux potassiques, pompe Na/K-ATPase, période réfractaire, potentiel de repos, xylocaïne]
schema: potentiel-action.html
majeur: true
date: 2026-10-18
---

## Explication

> Le cours (p. 2) ne dit que l'essentiel : canaux Na⁺ puis K⁺, peu de canaux calciques dans le nerf, xylocaïne qui bloque les canaux Na⁺. Le reste (Nernst, inactivation, sélectivité, pompe) est du complément de compréhension, hors programme d'examen tant que le cours ne le reprend pas.

### Le préalable : des gradients et une membrane chargée

La pompe Na⁺/K⁺-ATPase consomme de l'ATP pour maintenir deux gradients : le Na⁺ est environ 10 fois plus concentré dehors (145 contre 15 mM), le K⁺ environ 30 fois plus concentré dedans (140 contre 5 mM). Chaque ion a donc un potentiel d'équilibre de Nernst : environ +60 mV pour le Na⁺, environ −90 mV pour le K⁺.

Dans la masse des liquides, tout est électriquement neutre (Na⁺ avec Cl⁻ dehors, K⁺ avec des anions protéiques dedans). La charge n'existe que sur une couche très fine contre la membrane. Au repos, la membrane laisse surtout fuir le K⁺ : il sort en suivant son gradient, mais ses anions partenaires, trop gros, restent dedans. L'intérieur se charge négativement jusqu'à ce que l'attraction électrique compense la poussée du gradient : c'est le potentiel de repos, vers −70 mV.

La membrane se comporte comme un condensateur (≈ 1 µF/cm²) : l'excès de charges en jeu correspond à environ un ion sur 100 000. Les concentrations ne bougent donc quasiment pas, ni au repos ni pendant un potentiel d'action.

### Le canal voltage-dépendant

Un canal ne pompe rien : c'est une porte qui laisse les ions descendre passivement leur gradient électrochimique. Un segment chargé de la protéine (S4) sert de capteur de tension : quand l'intérieur devient moins négatif, il se déplace et ouvre le pore.

### Les étapes

1. **Repos (−70 mV)** : canaux Na⁺ et K⁺ voltage-dépendants fermés.
2. **Seuil (−55 mV)** : un stimulus dépolarise, les premiers canaux Na⁺ s'ouvrent.
3. **Dépolarisation (jusqu'à +40 mV)** : le Na⁺ entre, ce qui ouvre d'autres canaux Na⁺ (rétroaction positive, d'où le « tout ou rien »). La membrane file vers l'équilibre du Na⁺.
4. **Inactivation** : environ 0,5 ms après l'ouverture, une boucle intracellulaire du canal Na⁺ vient boucher le pore. Ce n'est pas l'équilibre des charges qui ferme le canal : c'est un minuteur intrinsèque, déclenché par la même dépolarisation qui l'a ouvert. Au même moment, les canaux K⁺, plus lents, finissent de s'ouvrir.
5. **Repolarisation puis hyperpolarisation (jusqu'à −85 mV)** : le K⁺ sort et ramène l'intérieur vers l'équilibre du K⁺, un peu trop loin car les canaux K⁺ tardent à se refermer. Les canaux Na⁺ restent inactivés : c'est la période réfractaire, qui empêche l'influx de repartir en arrière.
6. **Retour au repos** : les canaux K⁺ se ferment, la porte d'inactivation se retire et le canal Na⁺ redevient activable.

### Pourquoi des cations et pas des anions ?

Il faut deux ions dont les potentiels d'équilibre sont loin du repos, de part et d'autre : le Na⁺ (+60 mV) pour monter, le K⁺ (−90 mV) pour redescendre. Le Cl⁻ a un potentiel d'équilibre d'environ −65 à −70 mV, quasiment égal au repos : ouvrir des canaux Cl⁻ verrouille la membrane près du repos. C'est le mécanisme de l'inhibition (récepteurs GABA-A et glycine, cibles des benzodiazépines). Les autres anions intracellulaires (protéines, phosphates) sont trop gros pour traverser.

La sélectivité est une affaire de coordination : dans le filtre du canal K⁺, des oxygènes carbonyle reproduisent la couche d'hydratation du K⁺, que le Na⁺, plus petit, ne peut pas occuper correctement.

### Le rôle de la pompe

La pompe ne participe pas au potentiel d'action lui-même : elle recharge la batterie. Le potentiel d'action est une décharge rapide et passive qui utilise les gradients. Pompe bloquée, un neurone peut encore tirer des milliers de potentiels d'action avant que les gradients s'épuisent. La pompe échange 3 Na⁺ sortants contre 2 K⁺ entrants : elle est électrogène et contribue de quelques mV au potentiel de repos, mais l'essentiel vient de la fuite de K⁺.

### Lien clinique : la xylocaïne

La xylocaïne (lidocaïne) est un anesthésique local qui bloque les canaux Na⁺ voltage-dépendants. Sans entrée de Na⁺, pas de potentiel d'action, donc pas de message douloureux. Les petites fibres de la douleur (C et Aδ) sont bloquées avant les grosses fibres tactiles et motrices. La lidocaïne est aussi un antiarythmique de classe IB.

## Cartes

### Q: Pourquoi le canal Na⁺ voltage-dépendant se ferme-t-il alors que la membrane est encore dépolarisée ?
R: Par inactivation intrinsèque : une porte d'inactivation (boucle intracellulaire) bouche le pore environ 0,5 ms après l'ouverture, déclenchée par la même dépolarisation. Elle ne se retire qu'après repolarisation, d'où la période réfractaire.

### Q: Pourquoi l'ouverture de canaux Cl⁻ ne déclenche-t-elle pas de potentiel d'action ?
R: Le potentiel d'équilibre du Cl⁻ (≈ −65 à −70 mV) est proche du potentiel de repos : ouvrir des canaux Cl⁻ maintient la membrane au repos. C'est un mécanisme d'inhibition (GABA-A, glycine).

### Q: Quel est le rôle de la pompe Na⁺/K⁺-ATPase dans le potentiel d'action ?
R: Aucun rôle direct. Elle entretient les gradients de Na⁺ et de K⁺ (3 Na⁺ sortants / 2 K⁺ entrants) ; le potentiel d'action est un flux passif qui utilise ces gradients.

### Q: Comment la xylocaïne produit-elle une anesthésie locale ?
R: Elle bloque les canaux Na⁺ voltage-dépendants : pas d'entrée de Na⁺, donc pas de potentiel d'action, donc pas de transmission du message douloureux. Les fibres fines de la douleur (C, Aδ) sont bloquées en premier.
