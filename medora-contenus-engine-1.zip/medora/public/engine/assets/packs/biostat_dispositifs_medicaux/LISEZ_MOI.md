# Évaluation des dispositifs médicaux — paquet Biomédecine quantitative

200 notes, 267 cartes. Chapitre `chap-ue-biomed-quanti-fc11` de l'UE
Biomédecine quantitative, deuxième de l'UE. Cours du **09/10/2026**, deux
heures : **Pr B. Décaudin** (9 h-10 h) et **Pr E. Gerard** (10 h-11 h).
Examen : partiel du mercredi 16 décembre 2026 (sur tablette, 1 h).

**La base est le cours 2026-27** (réalignement du 19/10/2026) : les deux
ronéos Ronéo & Juliette du 09/10/2026, déposées le 19/10, sont la fiche du
chapitre. Le Ronéosaure 2025-26 (FC n°2, parties 1 et 2, cours du 13/10/2025),
qui faisait la base depuis le 02/10, reste l'appoint : la source des trois
cartes absentes du cours 2026-27, et des figures les plus nettes. Les annales
sont celles de deux polycopiés du Ronéosaure 2024-25 (18 sessions), inchangées.

**Les deux heures de l'année ont été données** : elles suivent tout le plan
de la FC 2025-26, conclusion comprise. Rien n'est « en attente des CM
suivants » (voir plus bas).

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 110 | 110 |
| QRU | 45 | 45 |
| Texte à trous | 13 | 77 |
| QROC | 14 | 14 |
| Recto-verso | 6 | 6 |
| Lexique | 9 | 9 |
| Schéma cliquable | 1 | 4 |
| Planche à légender | 2 | 2 |
| **Total** | **200** | **267** |

Dont **72 annales** (QCM) sur 18 sessions, de 2015/2016 S1 à 2023/2024 S2 :
43 du polycopié « 10.Les fondamentaux des dispositifs médicaux » (A10), 29 du
polycopié « 11. Evaluation clinique des dispositifs médicaux » (A11). Dont
aussi **55 marches de l'échelle** (44 Simple, 11 Moyen). **154 QCM sur 155
illustrés**, 187 notes sur 200. **9 cartes portent un piège de la ronéo
2026-27** (thème « Pièges des ronéos »). **3 cartes absentes du cours
2026-27.** **Aucune carte `a-relire`.**

Huit thèmes, tous déjà libellés dans `THEME_LABELS` : aucune clé nouvelle.

| Clé | Libellé |
|---|---|
| `dm-definition` | Définition d'un dispositif médical |
| `dm-classification` | Classes de risque, invasif, implantable |
| `marquage-ce` | Marquage CE et acteurs de la mise sur le marché |
| `materiovigilance` | Matériovigilance et suivi post-commercialisation |
| `benefice-risque` | Balance bénéfice-risque |
| `dm-etudes` | Études cliniques des dispositifs médicaux |
| `randomisation` | Randomisation, placebo et aveugle |
| `non-inferiorite` | Supériorité et non-infériorité |

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-biomed-dm1-2627` — « Évaluation des dispositifs médicaux » (10 p.), chemin `BIOMEDECINE QUANTI/ÉVALUATION DES DISPOSITIFS MÉDICAUX 1.pdf` | **2026-27** | la partie 1, Pr Décaudin : `SRC["fiche"]`, `chapitre=` |
| `src-fc-biomed-dm2-2627` — « Évaluation clinique des dispositifs médicaux » (10 p.), chemin `BIOMEDECINE QUANTI/ÉVALUATION DES DISPOSITIFS MÉDICAUX 2.pdf` | **2026-27** | la partie 2, Pr Gerard : `fiche=FC2`, `chapitre=` |
| `src-fc-biomed-dm1-2526` — FC n°2 partie 1 (8 p.) | 2025-26 | appoint (`SRC["cours"]`, `SRC["medias"]`) ; plus de `chapitre=` |
| `src-fc-biomed-dm2-2526` — FC n°2 partie 2 (6 p.) | 2025-26 | appoint ; plus de `chapitre=` |
| `src-annales-10-…`, `src-annales-11-…` | 2024-25 | les annales, inchangées |

Les deux PDF 2026-27 sont nommés en NFC, comme sur le disque du dépôt du
19/10. Dans le texte d'une carte, « partie 1, p. N » et « partie 2, p. N »
renvoient aux ronéos 2026-27 ; « FC 2025-26, partie N, p. N », au Ronéosaure.

**124 notes citent une page des ronéos 2026-27** (`page=`, et `fiche=FC2` pour
la partie 2) — les 116 notes de cours et marches relues, et 8 termes du
lexique — et ne portent plus le badge « Cours 2025-26 ». Quatre citent encore
la FC 2025-26 : les trois cartes absentes et le terme « arthroplastie ».

| Pages 2026-27 | Ce qu'elles couvrent |
|---|---|
| partie 1, p. 2-3 | les attentes des patients, des industriels, des professionnels ; le bénéfice/risque du patient et de l'utilisateur ; la biocompatibilité des sondes et des prothèses |
| partie 1, p. 3-4 | le premier considérant du règlement 2017/745 ; « est-ce un DM ? » en quatre exemples |
| partie 1, p. 5-7 | la définition, la contraception, les exemples et leurs figures, la fonction assistée |
| partie 1, p. 7-9 | la biocompatibilité de la prothèse résorbable, le marquage CE (figure p. 8), les classes, les règles, l'invasif et l'implantable, les acteurs |
| partie 2, p. 2-4 | les réglementations, les classes et leurs exemples, les organismes notifiés et la CNEDiMTS, les trois contextes d'évaluation |
| partie 2, p. 4-6 | les types d'études, la pyramide des preuves (figure p. 6), les essais intéressants pour les DM |
| partie 2, p. 6-8 | le placebo, la fausse intervention, médicament et DM, pilote et pivot, la randomisation |
| partie 2, p. 8-10 | supériorité et non-infériorité, la télécardiologie, la conclusion, l'effet opérateur |

## Ce que le cours 2026-27 a changé

**19 notes réécrites**, parce que le cours de l'année dit autre chose ; leurs
identifiants, leurs types et leurs clés n'ont pas bougé (comparé au paquet
d'avant) :

- **Les attentes des intervenants** : les patients attendent la facilité
  d'utilisation et la sécurité ; la transparence des données passe aux
  professionnels ; l'accessibilité est rangée avec les industriels
  (`dm-fa-attentes`, `dm-qc-reglementation` D).
- **La biocompatibilité** : les risques infectieux, cancérigènes, mutagènes,
  la sonde vésicale en PVC ou en silicone (`dm-fa-biocompatibilite`).
- **Le niveau de risque** : le temps de contact, l'association à un
  médicament, le DM actif et son risque de panne ; plus de preuves pour une
  prothèse de hanche que pour une seringue (`dm-fa-risque`,
  `dm-qc-benefice-risque`, qui gardent leur clé ACDE). Les exemples de 2025-26
  — sonde naso-gastrique, système cérébral, abaisse-langue, suture de l'enfant
  — sont dits dans l'explication.
- **L'ANSM** « facilite l'innovation » et peut retirer un produit du marché ;
  la réception des déclarations de matériovigilance n'est plus dans la liste
  (`dm-fa-acteurs`, trou 7).
- **La pyramide des preuves** (figure p. 6) : l'avis d'experts et les cas
  rapportés sous les cas-témoins, les méta-analyses seules au sommet ; les
  études quasi-expérimentales n'y sont plus (`dm-fa-niveaux-preuve`,
  `dm-qc-types-etudes` C, réécrite pour rester vraie ; ATTENTION nu).
- **Le pacemaker plus petit, plus facile à poser, moins cher : supérieur**
  (partie 2, p. 8) — en 2025-26, « le meilleur exemple » de la
  non-infériorité. `dm-qc-pacemakers` est réécrite sur le pacemaker et la
  télécardiologie, clé ACE inchangée, avec un ATTENTION nu sur le désaccord des
  deux années.
- **La fausse intervention existe** : une étude a ouvert puis refermé des
  patients sous anesthésie, avec une « ambiguïté éthique » (partie 2, p. 7),
  et la simulation de l'intervention est un moyen de l'aveugle (p. 9) — en
  2025-26, le cours la disait impossible. `dm-qc-placebo` E est réécrite,
  `dm-fa-aveugle` aussi ; la marche `dm-ech2-s21` passe des « fausses
  interventions en ophtalmologie » à « simuler l'intervention », et son schéma
  avec elle ; `dm-ech2-m4` C passe de la désactivation à la prothèse d'aspect
  identique.
- **La perception biaisée** des études non randomisées
  (`dm-fa-neurostimulation`, trou 3) ; **le DM « sûr et efficace »**
  (`dm-rv-medicament-dm`, `dm-qc-evaluation-clinique`) ; **le DIU de 1973 sans
  son nom** (`dm-qc-evaluation-clinique` B) ; **le gel des PIP changé sans
  nouvelle évaluation** (`dm-qr-pip`) ; **l'ECR en double aveugle**, référence
  de l'étude pivot (`dm-rv-pilote-pivot`) ; **Δ = XN − XR** et l'hypothèse
  nulle (`dm-rv-superiorite-non-inferiorite`).

Ailleurs, les citations sont passées aux pages 2026-27 et les propositions
que la ronéo ne redit plus le disent dans leur justification (« FC 2025-26,
partie 1, p. 6 ») : l'expanseur cutané, la chirurgie assistée par
ordinateur, la majorité des DM non résorbable, l'utilisateur qui est aussi le
patient, les sondes d'intubation et naso-gastrique, le partage européen des
déclarations, la p-valeur, α et β, la désactivation des DM externes.

**14 notes nouvelles**, pour ce que le cours 2026-27 enseigne et qu'aucune
carte ne couvrait :

| Note | Ce qu'elle apprend | Page |
|---|---|---|
| `dm-qc-attentes` | les attentes de chaque intervenant, le progrès incrémental | partie 1, p. 2-3 |
| `dm-qc-fonction-assistee` | la liste des DM dont la fonction est assistée, l'héparine de rinçage, l'alginate ; le DIU au cuivre et aux hormones ; les études d'un pansement à l'antalgique | partie 1, p. 5 et 7 |
| `dm-qc-acces-marche` | la reconnaissance mutuelle, l'impasse thérapeutique (pays tiers, autorisation de l'ANSM), le SMR et l'ASMR jugés par la HAS — le SA et l'ASA de la CNEDiMTS pour un DM ; ajoutée à la relecture | partie 1, p. 2-3 |
| `dm-qc-materiaux` | la biocompatibilité : sondes en PVC ou en silicone, prothèse de hanche en céramique | partie 1, p. 2 |
| `dm-fa-considerant` | le premier considérant du règlement 2017/745 (en gris en 2025-26) | partie 1, p. 4 |
| `dm-fa-regles` | les quatre groupes de règles de classification | partie 1, p. 9 |
| `dm-qr-certificat-ce` | le certificat de l'organisme notifié, 5 ans | partie 1, p. 8 |
| `dm-qr-cnedimts` | la CNEDiMTS juge le remboursement | partie 2, p. 3 |
| `dm-qc-contextes-evaluation` | DM à hauts risques (< 10 %), ligne générique, suivi post-commercialisation | partie 2, p. 3-4 |
| `dm-qc-longitudinales` | prospective, rétrospective, registre, cas-témoins | partie 2, p. 5 |
| `dm-pl-pyramide-preuves` | **planche à légender** de la pyramide des preuves, 7 numéros, 3 intrus | partie 2, p. 6 |
| `dm-qr-pivot-reference` | l'ECR en double aveugle, référence de l'étude pivot | partie 2, p. 7 |
| `dm-qr-effet-operateur` | l'effet opérateur : compétences et compliance au protocole | partie 2, p. 10 |
| `lex-hysteroscopie` | terme du lexique (« voie hystéroscopique ») | partie 1, p. 6 |

**Les annales** n'ont pas bougé : énoncés, propositions et clés sont les
mêmes ; chaque clé a été relue contre le cours de l'année, aucune n'est
contredite, et leurs justifications citent désormais ses pages. Le cours
2026-27 appuie même plusieurs clés que le cours 2025-26 laissait en suspens :
le ciment aux antibiotiques, les stents enduits et le pansement avec
antalgique sont nommés parmi les DM dont la fonction est assistée (partie 1,
p. 7 — la liste du ciment à la gentamicine) ; le stimulateur cardiaque
implantable est cité (partie 1, p. 3) ; la simulation de l'intervention existe
(partie 2, p. 7 et 9) ; l'effet opérateur revient (partie 2, p. 10) ; le
double aveugle est la référence de l'étude pivot (partie 2, p. 7).

## Les erreurs des ronéos 2026-27

Aucun tableau d'erreurs de la promo pour la biomédecine quantitative au 19/10 :
toutes ont été trouvées à la relecture. Portées dans les cartes avec leur
genre, à verser dans `contenu/ERRATA_RONEOS_2026-27.md`.

| Ronéo, page | Ce que dit la ronéo | Ce qui est juste, et la preuve | Genre | Carte |
|---|---|---|---|---|
| partie 1, p. 3 | vendu en Europe ne veut pas dire remboursé « car l'obtention de la mise sur le marché est purement national » | c'est le remboursement qui est national ; la mise sur le marché, par le marquage CE, vaut pour toute l'Union — même ronéo, p. 2 et 8 ; FC 2025-26, partie 1, p. 2 ; règlement (UE) 2017/745 | prise de notes | `dm-qc-reglementation` (A) |
| partie 1, p. 9 | un DM est invasif de type chirurgical « si il est nécessairement posé par un chirurgien » | défini par sa voie : à travers la surface du corps, à l'aide ou dans le cadre d'un acte chirurgical, ou autrement que par un orifice (règlement 2017/745, annexe VIII, 2.2) ; phrase reprise du ronéo 2025-26, dont l'errata de la promo demandait déjà la définition de la diapositive | prise de notes | `dm-qc-invasif-implantable` (D), `dm-ech-s14` (B) |
| partie 1, p. 9 | l'implantable « est de type chirurgical s'il reste plus de 30 jours dans le corps » | les trente jours rangent parmi les implantables le DM introduit EN PARTIE et destiné à rester au moins trente jours (règlement 2017/745, art. 2, 5) ; même phrase dans le ronéo 2025-26 | prise de notes | `dm-rv-invasif-implantable` |
| partie 2, p. 3 | « les DM de classes IIb et III qui administrent ou éliminent un médicament implantable » | la diapositive de la partie 1 (p. 8, encadré vert) : « DMI classe 3 et classe 2b destiné à l'administration des médicaments » ; règlement 2017/745, art. 54 : les implantables de classe III et les actifs de classe IIb destinés à administrer ou retirer un médicament (ANSM, « Points marquants du règlement DM ») | prise de notes | `dm-qc-contextes-evaluation` (A) |
| partie 1, p. 3 | le stimulateur cardiaque implantable qui, dès qu'il détecte une arythmie, « déclenche un choc » | le choc est celui du défibrillateur automatique implantable ; le stimulateur supplée un cœur trop lent par des impulsions non ressenties (Vidal, « Stimulateurs et défibrillateurs cardiaques » ; Fédération française de cardiologie, brochure DAI) | douteux | `dm-qc-attentes` (C) |
| partie 2, p. 5 | l'étude cas-témoins, « Exemple Fumeur / non-Fumeur » | choisir des fumeurs et des non-fumeurs fait une cohorte exposés/non-exposés ; le cas-témoins part de la maladie et recherche l'exposition (Wikipédia, « Case–control study » ; Doll et Hill, BMJ 1950) | douteux | `dm-qc-longitudinales` (D) |
| partie 1, p. 3 | « le remboursement concerne le SMR (Service Médical Rendu) et l'ASMR » | les mots du médicament : pour un DM, la CNEDiMTS de la HAS juge le service attendu (SA) et son amélioration (ASA, de I à V) — HAS, « Principes d'évaluation de la CNEDiMTS », 2025 ; à l'examen, la phrase du cours | douteux | `dm-qc-acces-marche` (C), ajoutée à la relecture |
| partie 2, p. 2 et 10 | le règlement « à partir de 2020 », « application à partir de 2024 » ; puis « règlement européen 2017 mis en place en 2020 » | règlement (UE) 2017/745 du 5 avril 2017, appliqué le 26 mai 2021 (report d'un an par le règlement (UE) 2020/561) — Ordre national des pharmaciens, « Report de l'application du règlement sur les dispositifs médicaux » ; « 2024 » vient peut-être des périodes de transition | douteux | `dm-ech2-s6` (A) |

**Vus et laissés sans ATTENTION**, parce qu'aucune carte n'en dépend :

- « Si le rapport bénéfice/risque est favorable ou pas (AMM...) » (partie 1,
  p. 3) : un mot du médicament ; pour un DM, le marquage CE (« équivalent de
  l'AMM », p. 8) ;
- « stimulation de l'intervention » (partie 2, p. 9) : simulation ;
- « quasi non-expérimentable » pour les essais non contrôlés (partie 2,
  p. 5) : quasi-expérimentaux ;
- « l'étude Scharm : un groupe de 2 patients » (partie 2, p. 7), phrase
  tronquée, et « évaluation du service rendu à 4 » (p. 9) : inutilisables ;
- la CNEDiMTS qui ferait « en sorte que l'innovation efficace soit le moins
  cher possible » (partie 2, p. 3) : elle donne un avis sur le remboursement,
  le prix se négocie ailleurs ; la carte ne dit que son rôle dans le
  remboursement ;
- l'« accessibilité du traitement » rangée avec les industriels (partie 1,
  p. 3), quand le cours 2025-26 la donnait aux professionnels : dit dans
  l'explication de `dm-fa-attentes`, sans trancher.

## Les erreurs du Ronéosaure 2025-26, et ce qu'elles deviennent

Le Ronéosaure n'est pas la ronéo de l'année : ses erreurs restent dites sans
genre, et n'entrent pas dans la liste de la promo.

| Page 2025-26 | Ce qu'il disait | Aujourd'hui |
|---|---|---|
| partie 1, p. 8 | « de la classe I à III » | corrigé par la ronéo 2026-27 (« (I, IIa, IIb, III) », p. 9) ; ATTENTION nu gardé dans les annales et les marches des classes, CONFLITS gardés |
| partie 1, p. 8 | invasif et implantable abrégés, « posé par un chirurgien », « 30 jours » | redits en 2026-27 : devenus des erreurs de la ronéo de l'année (ci-dessus) |
| partie 2, p. 4 | la p-valeur, « probabilité que le hasard explique le résultat observé » | absente de 2026-27 ; ATTENTION nu sur `dm-qc-pilote-pivot` E, qui le dit |
| partie 2, p. 5 | « H0 : Δ − ΔL ≤ 0 » | absente de 2026-27 ; point douteux dit dans `dm-qc-superiorite` |

## Absent du cours 2026-27

Trois cartes entières (`ABSENTS_2026`), que les deux heures du 09/10 ont
traitées sans en reprendre le point. Elles gardent leur page de la FC 2025-26
(`fiche=` une source sans `chapitre=`) et la phrase « Absent du cours
2026-27 » en tête de leur explication.

| Carte | Le point | Source |
|---|---|---|
| `dm-qr-dalkon` | le nom du Dalkon Shield ; la ronéo 2026-27 dit « un dispositif intra-utérin » (partie 2, p. 2) | FC 2025-26, partie 2, p. 2 |
| `dm-ech2-s5` | le partage des déclarations de matériovigilance entre autorités compétentes européennes | FC 2025-26, partie 1, p. 7 |
| `dm-ech2-s20` | la désactivation de certains DM pour l'aveugle | FC 2025-26, partie 2, p. 6 |

Les propositions isolées que l'année ne redit plus restent dans leurs cartes,
et le disent (voir plus haut).

## En attente des CM suivants

Aucune carte : les deux cours du 09/10/2026 couvrent tout le plan de la FC
2025-26, conclusion comprise. La p-valeur, les risques α et β, le nombre de
sujets, la randomisation et l'aveugle en général sont cartés aux chapitres de
phase I-II et de phase III de l'UE, qui se réaligneront sur leurs propres
ronéos.

## Les clés qui ne sont pas reprises telles quelles

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| A10 2022/2023 S2 Q22 (ciment, hydrofibre, stent, ibuprofène, fentanyl) | AB | **ABCD**, `officielle=False` | les sept autres sessions de la même liste donnent ABCD ; le cours 2026-27 nomme le stent enduit et le pansement avec antalgique parmi les DM dont la fonction est assistée (partie 1, p. 7) — ATTENTION sur C et D |
| A10 2017/2018 S2 Q15 | AB | **ABE**, `officielle=False` | E, l'objectif de la matériovigilance, est corrigée vraie dans les cinq autres sessions qui la posent — ATTENTION sur E |
| A11 2023/2024 S1 Q9 (pilote, pivot) | E | **CE**, `officielle=False` | C est la phrase du cours : « les études pivots qui correspondent aux études comparatives » (partie 2, p. 7) — ATTENTION sur C |

Sept points sont discutés dans la carte (`ATTENTION`, `CONFLITS`), sans
changer la clé :

| Question | Clé | Le point | À l'examen |
|---|---|---|---|
| 2023/2024 S1 Q8 A ; 2022/2023 S1 Q26 A ; A11 2023/2024 S2 Q19 A | BE ; ABDE ; ABDE | quatre classes : la clé a raison, et la ronéo 2026-27 le dit ; le ronéo 2025-26 écrivait « de la classe I à III » | quatre classes |
| A11 2016/2017 S1 Q40 D ; 2016/2017 S2, 2015/2016 S1 et S2 Q40 C | ABDE ; ABCD ; ABCD ; ABCE | « le placebo d'un implantable peut être effectué par simulation de l'intervention » : le cours 2026-27 le confirme (partie 2, p. 7 et 9), le cours 2025-26 le disait impossible | vrai, comme la clé |

A11 2023/2024 S2 Q19 D (« l'ANSM est l'autorité compétente »), contestée dans
l'errata des annales 2024-25, reste vraie (partie 1, p. 9), sans conflit.

## Les schémas et les figures

**Une figure nouvelle de la ronéo 2026-27** : la pyramide des preuves
(`dm-pyramide-preuves.png`, partie 2, p. 6), en correction de
`dm-fa-niveaux-preuve` et de `dm-qc-types-etudes`, et en planche à légender. **Les figures de la FC 2025-26 restent** : les mêmes
diapositives que la ronéo 2026-27 (exemples de DM, logiciel, cœliochirurgie,
prothèse mammaire et Essure, « Obtention marquage CE »), mieux résolues dans
le PDF 2025-26 — leur légende cite les deux pages ; le tableau des classes,
les pacemakers, la supériorité et la non-infériorité n'ont pas d'équivalent
en 2026-27, et leur légende dit « FC 2025-26 ».

**Les schémas redessinés** (`schemas.py`) suivent le cours 2026-27 :
`etudes-cliniques.svg` dessine la pyramide de la p. 6 ; `parcours-dm.svg`
donne les phases 1 à 4 de la p. 7, l'ECR en double aveugle et la CNEDiMTS ;
`aveugle-dm.svg` montre le placebo « pas toujours évident », la simulation de
l'intervention et la réticence du médecin ; `invasif-implantable.svg`,
`neurostimulation.svg`, `dm-ou-medicament.svg`, `classes-risque.svg` citent
leurs pages 2026-27.

| Fichier | Ce qu'on clique | Pourquoi ce dessin |
|---|---|---|
| `classes-risque.svg` | la classe d'une compresse (I), d'une couronne dentaire (IIa), d'un préservatif (IIb), d'un stent (III) — 4 zones | les exemples de la partie 2, p. 2-3 ; quatre bandes qui pavent une échelle de risque croissant |

**Deux planches à légender** :

- `dm-pl-mise-sur-le-marche` : la diapositive « Obtention marquage CE »
  (partie 1, p. 8 ; image de la FC 2025-26, p. 7, plus nette), 7 numéros ;
  intrus : HAS, CNIL, CPP, EMA ;
- `dm-pl-pyramide-preuves` (nouvelle) : la pyramide de la partie 2, p. 6, ses
  sept étages effacés (`fond="degrade"`, l'étage du sommet d'une couleur
  unie) ; 7 numéros, légendes en français ; intrus : études transversales,
  études quasi-expérimentales, essais non contrôlés. L'image numérotée a été
  relue : aucun reste de lettre, aucun trait mordu.

Pour les refaire, depuis `app/` :
`uv run --with pillow python ../.claude/skills/nouveau-chapitre/scripts/planche_depuis_image.py ../contenu/chapitres/biostat_dispositifs_medicaux <identifiant> --apercus <brouillon>`.

**154 QCM sur 155 illustrés.** Sans figure : `dm-qc-securite` (le patient et
l'utilisateur), qu'aucune figure ne montre.

## L'échelle : Simple → Moyen → Annale

55 marches (44 Simple, 11 Moyen) sur deux schémas, `ech-dispositif-medical`
et `ech2-evaluation-clinique` (`schemas.py`, dessinés par `echelle.py`, copie
exacte du modèle). **Relues sur le cours 2026-27** : chaque marche cite ses
pages, et 53 portent `page=` dans les ronéos de l'année ; aucune clé n'a
bougé, les clés Simple restent réparties entre A, B et C, les Moyen gardent
une à trois vraies.

- `dm-ech2-s21` : « fausses interventions (ophtalmo) » → « simuler
  l'intervention », sur la carte et sur la case `aveugle` du schéma 2 ;
- `dm-ech2-m4` C : la désactivation → la prothèse d'aspect identique ;
- la case `controle` du schéma 2 dit « souvent un ancien dispositif » (partie
  2, p. 7) au lieu de « la génération précédente » ;
- les légendes des deux schémas citent la ronéo 2026-27, et la FC 2025-26
  pour les lignes que l'année ne redit pas (« désactiver certains DM »,
  « déclarations d'EI partagées », la matériovigilance reçue par l'ANSM) ; le
  schéma 2 passe à 506 px de haut pour loger sa légende sur deux lignes ;
- `dm-ech2-s5` et `dm-ech2-s20` sont absentes du cours 2026-27 (voir plus
  haut) ; `dm-ech-s14` porte l'ATTENTION (prise de notes) du « posé par un
  chirurgien », `dm-ech2-s6` l'ATTENTION (douteux) des dates du règlement.

**Sans marche**, comme avant : la notice d'instruction (cours 2023-24), les
gants chirurgicaux (cours 2024-25), le pansement de la liste d'exemples, la
lecture à l'aveugle par un tiers (FC n°6) — lettres posées sur la case la plus
proche. Le stimulateur cardiaque implantable (2020/2021 S1 Q23 D et S2 Q21 D)
est désormais nommé par le cours (partie 1, p. 3), et l'effet
« opérateur-dépendant » (Q40) aussi (partie 2, p. 10) : leurs lettres restent
sur « exemples » et « Essais préférentiels », sans marche nouvelle.

## Le lexique

Neuf termes ; pages mesurées dans le texte des quatre PDF
(`chercher_pages.py`, page de garde exclue), celles de 2026-27 en premier :

| Terme | Pages 2026-27 | Pages 2025-26 |
|---|---|---|
| Implantable | partie 1, p. 3, 9 ; partie 2, p. 3 | P1 8 ; P2 4, 6 |
| Invasif | partie 1, p. 9 | P1 7, 8 ; P2 5 |
| Biocompatibilité | partie 1, p. 2, 7, 8 | P1 6 |
| Matériovigilance | partie 2, p. 4, 7 | P1 7, 8 ; P2 2, 4 |
| Résorbable | partie 1, p. 5, 7 | P1 4, 6 |
| Endoprothèse | partie 1, p. 6, 7 | P1 5 |
| Cœliochirurgie | partie 1, p. 6 | P1 5 |
| **Hystéroscopie** (nouveau) | partie 1, p. 6 | P1 5 |
| Arthroplastie | — | P1 4 : la chirurgie assistée par ordinateur n'est plus dans la ronéo 2026-27 |

L'étymologie du terme nouveau (grec ὑστέρα + σκοπεῖν, vérifiée sur le
Wiktionnaire, le Bailly et le CNRTL) est proposée pour `etymologies.json` dans
`scratchpad/etym/biostat_dispositifs_medicaux.json`, et déjà écrite dans la
définition et les racines, dans la forme que `appliquer_etymologies.py`
produirait ; ses deux racines, `hystér(o)-` et `-scopie`, sont déjà dans la
table. Aucun terme n'est doublé dans la bibliothèque (vérifié sur tous les
`paquet.json`).

## Ce que le cours a dicté

- **Un chapitre pour deux cours** (plan C15) : les deux heures du 09/10 font
  une FC, un titre, un partiel, et les polycopiés d'annales mélangent déjà les
  deux. Les cartes de la partie 2 citent leur fiche (`fiche=FC2`).
- **Pas de gris** dans les ronéos 2026-27 : l'extrait du règlement, en gris
  « ne pas apprendre » en 2025-26, est donné en entier, ses mots clés en gras ;
  il a désormais sa carte (`dm-fa-considerant`).
- **Ce qui n'est pas carté ici** (plan C15) : la p-valeur, les risques α et β,
  le nombre de sujets, la randomisation et l'aveugle en général (chapitres de
  phase I-II et de phase III) ; les niveaux de preuve en général (chapitre de
  régression linéaire). Ce chapitre les carte **pour le dispositif médical**.

## Décisions prises en route

- **`EXAMENS` n'est pas déclaré** (décision de BMCT FC1) : le partiel du 16/12
  se règle dans l'application.
- **Les CONFLITS des classes et de la simulation sont gardés**, leur texte
  réécrit : le cours 2026-27 confirme les clés, mais le Ronéosaure 2025-26,
  que les collègues ont encore, dit autre chose.
- **Les figures 2025-26 restent** là où la ronéo 2026-27 reprend la même
  diapositive en moins net ; la planche de la mise sur le marché cite la page
  2026-27 (`page=8`) mais garde l'image 2025-26.
- **Une carte réécrite garde son identifiant, son type et sa clé** : quand le
  cours 2026-27 contredisait une proposition (le cas-témoins au plus bas de la
  hiérarchie, le pacemaker de la non-infériorité, la simulation impossible),
  la proposition a été réécrite pour rester vraie ou fausse comme avant.

## Questions pour Vincent

- **Les CONFLITS des classes de risque** (trois annales) : le cours 2026-27
  écrit les quatre classes ; faut-il retirer ces conflits, ou les garder pour
  qui révise sur le Ronéosaure 2025-26 ?
- **Le pacemaker** : supérieur (2026-27) ou exemple de non-infériorité
  (2025-26) ? La carte suit 2026-27 et dit le désaccord. Les deux se
  défendent (supérieur sur la taille, non inférieur sur l'efficacité) ; si le
  professeur pose la question, la ronéo de l'année fait foi.
- **Le chapitre du squelette `chap-ue-biomed-quanti-fc10`** (« Les
  fondamentaux des dispositifs médicaux ») reste vide : son cours et ses
  annales sont ici. Le masquer, le fusionner, ou le laisser ?
- **La source des annales d'un second polycopié** : le modèle ne connaît
  qu'une source par session ; une clé `source=` par question le réglerait.
- `copier_les_cours.py` avec le dossier du dépôt du 19/10, hors du bac à
  sable, pour que les deux ronéos 2026-27 s'ouvrent dans l'application.

## À relire

**Aucune carte `a-relire`** : chaque note cite une page des ronéos 2026-27, de
la FC 2025-26, une clé d'annale ou une source sûre nommée dans son texte.

## Régénérer

```powershell
..\..\..\app\.venv\Scripts\python.exe generer.py
```
