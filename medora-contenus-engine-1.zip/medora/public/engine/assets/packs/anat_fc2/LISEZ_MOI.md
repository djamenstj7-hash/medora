# Anatomie du membre inférieur (suite) — paquet Anatomie

73 notes, 153 cartes. Chapitre `chap-ue-anatomie-fc2` de l'UE Anatomie
(identifiant du squelette), pour l'examen de novembre. Cours du **Pr Demondion,
le 04/10/2024**, FC n°2 du Ronéosaure 2024-25 (13 pages). Aucune annale : les
sujets du membre inférieur sont des schémas à légender, cartés par les chapitres
Schémas n°1 et n°2.

## La méthode

**Le Ronéosaure 2024-25 est la base**, et la seule source de cartes : aucune
ronéo d'anatomie 2026-27 n'était parue le 29/09/2026. Quand elle paraîtra, elle
corrigera ce chapitre (et la FC déclarée ici comme fiche du chapitre, « fiche
provisoire en attendant le ronéo 2026-27 », sera remplacée). Il n'y a donc ni
« Absent du cours 2026-27 », ni `ATTENTION (genre)` : les erreurs du Ronéosaure
portent un `ATTENTION` nu.

Le cours 2023-24 (Charonéo, « Membre inférieur (suite) », 8 pages) sert
d'appui pour trancher un point, jamais de source de carte à lui seul.

## Le ronéo 2026-27 (relu le 19/10/2026)

Le seul ronéo 2026-27 du membre inférieur paru au 19/10, « TOPOGRAPHIE DU
MEMBRE INF 1 » (Ronéo & Juliette, CM du 06/10/2026, 11 h-12 h, **Pr
Herteleer**, 12 p.), traite la région glutéale, l'articulation de la hanche et
la région lombaire et inguino-pelvienne. Il réaligne le chapitre FC n°1
(`anat_fc1`) et ajoute cinq planches au chapitre Schémas n°1 (`anat_sch1`) ;
**il ne dit rien du genou, de la jambe, de la cheville ni du pied**.

## Absent du cours 2026-27

Aucune carte (`ABSENTS_2026` n'existe pas ici) : le cours de l'année n'a pas
encore traité ces régions.

## En attente des CM suivants

**Les 73 notes** gardent leur page de la FC n°2 2024-25 et le badge « Cours
2024-25 » ; elles se reliront à la parution des ronéos des CM du membre
inférieur qui suivront le 06/10 (« ce point sera revu au prochain cours », dit
le ronéo du 06/10 du tractus ilio-tibial, p. 9). Le libellé du chapitre
(`semaine`) reste « Ronéosaure 2024-25 » jusque-là.

**L'examen est un schéma** (bureau, errata du cours : « notre examen est
uniquement un schéma ») : orienter, nommer, compléter. Les QCM de ce chapitre
portent donc sur des positions, des relations, des trajets, des insertions et
des innervations, et chacun est illustré par le schéma du cours.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 28 | 28 |
| QRU | 2 | 2 |
| Texte à trous | 13 | 66 |
| QROC | 11 | 11 |
| Recto-verso | 7 | 7 |
| Schéma cliquable | 3 | 30 |
| Lexique | 9 | 9 |
| **Total** | **73** | **153** |

**30 QCM sur 30 illustrés** (100 %) : huit figures de la FC n°2, la planche
corrigée des territoires de Schémas n°2 (p. 9) et les versions légendées des
deux schémas redessinés. Aucune annale, aucun conflit. **2 cartes `a-relire`**
(voir plus bas).

Six thèmes, clés partagées avec les chapitres FC n°1, Schémas n°1 et n°2 (même
libellé dans les quatre) ; tous nouveaux, à ajouter à `THEME_LABELS`
(`app/src/med_engine/application/scopes.py`) — tant qu'ils n'y sont pas,
`test_tout_theme_du_paquet_a_son_libelle` échoue sur ce chapitre :

| Clé | Libellé | Notes |
|---|---|---|
| `vaisseaux-mi` | Artères et veines du membre inférieur | 9 |
| `nerfs-mi` | Nerfs du membre inférieur | 10 |
| `genou` | Le genou | 5 |
| `loges-jambe` | Loges et muscles de la jambe | 14 |
| `pied-cheville` | Pied et cheville | 22 |
| `territoires-mi` | Territoires sensitifs du membre inférieur | 4 |

(64 notes de cours ; les 9 termes du lexique n'ont pas de thème.)

## Les sources

| Source | Rôle |
|---|---|
| `src-ue-anatomie-fc2` — FC n°2, « Anatomie du membre inférieur (suite) », Ronéosaure 2024-25, 13 p. | la base ; fiche du chapitre (`chapitre=`), `Anatomie/FC n°2 - Anatomie du membre inférieur (suite).pdf` — c'est ce que le lecteur ouvre |
| `src-ue-anatomie-sch2` — Schémas n°2, Ronéosaure 2024-25, 9 p. | la planche corrigée des territoires sensitifs (p. 9), en illustration de trois QCM. Sa déclaration est **recopiée à l'identique** de celle du chapitre Schémas n°2, qui en est le propriétaire (`chapitre="chap-ue-anatomie-sch2"`, même titre, même note) : une déclaration différente, et le dernier paquet importé réécrirait celle de l'autre. Si le chapitre Schémas n°2 change la sienne, recopier ici |
| `src-ue-anatomie-fc1` — FC n°1 | citée par les pages du lexique seulement (déclarée par le chapitre FC n°1) |
| Cours 2023-24 (Charonéo) | appui cité dans les justifications (fibulaire profond et flexion dorsale du pied, « spring ligament », poulies du long fléchisseur de l'hallux, coupe du genou) |
| Errata du cours et des annales (Ronéosaure 2024-25) | trois entrées sur la FC n°2 : « nerf » tibial antérieur → **artère** (p. 7, déjà corrigé dans la figure) ; « nerf calcanéen latéral » → **nerf plantaire latéral** (le bureau le dit corrigé « dans la FC n°2 », mais la figure de la p. 13 l'écrit encore — vérifié ; seule la planche de Schémas n°2 p. 9 est corrigée, d'où elle en illustration) ; un numéro de diapositive qui masque un peu les nerfs d'un schéma (sans effet sur les cartes). Rien dans l'errata des annales. |

Les vérifications hors du cours sont citées dans la carte qui s'en sert :
StatPearls (tibial postérieur et ligament calcanéo-naviculaire plantaire, ordre
du tunnel tarsien, nerf fibulaire commun et steppage, artère fibulaire, nerf
fibulaire superficiel), IMAIOS (sillon du long fléchisseur de l'hallux),
Académie de médecine (angle de l'arche interne), AAFP 2001 (entorse), Kenhub.

## Ce que le cours a dicté

- **Le rouge de la ronéo n'est pas un « à savoir »** : c'est la convention
  typographique des noms d'artères (les nerfs sont en jaune sur les schémas).
  Aucun gris de rédacteur dans cette FC.
- **Le schéma « d'examen »** : de la vue antérieure de la jambe (p. 7), « le
  professeur Demondion a beaucoup insisté sur le fait que ce schéma pourrait tout
  à fait être celui présent durant les examens » (p. 6). Elle illustre onze
  cartes (nerfs fibulaires, artère dorsale du pied, extenseurs) ; la planche
  légendée elle-même est au chapitre Schémas n°2 (p. 5).
- **« Le prof insiste bien »** sur le nerf fibulaire commun qui contourne la
  fibula (p. 3) : trois QCM, un texte à trous, deux QROC.
- **« Attention »** de la ronéo : l'ordre derrière la malléole médiale (p. 2),
  le tendon du plantaire qui devient médial (p. 4), tunnel tarsien et sinus du
  tarse (p. 11) — chacun a sa carte, l'ordre rétro-malléolaire a son schéma
  cliquable.
- **Les territoires sensitifs** « doivent être connus pour l'examen des
  patients » (p. 13) ; la planche est « non susceptible de tomber selon le prof,
  mais importante à connaître » (Schémas n°2 p. 9). Ici, des QCM de
  raisonnement (un déficit du 1er espace, du bord latéral) ; la planche à
  légender est au chapitre Schémas n°2.

### Le partage avec les trois autres chapitres du membre inférieur

Rien n'est carté deux fois. Ici : la division de l'artère poplitée, les
géniculées, le nerf fibulaire commun après le genou, le nerf tibial à la
cheville, la terminaison et la palpation du tendon calcanéen, le trajet du
tendon du plantaire. Laissés à la FC n°1 : la poplitée jusqu'au hiatus, NiVeA,
le nerf ischiatique, la liste motrice du nerf tibial, la formation du triceps
sural, la patte d'oie (rappelés p. 3 et 5, non recartés). À la relecture, deux
propositions qui recartaient la FC n°1 ont été remplacées : « la fémorale
devient poplitée au hiatus » (`mi2-qc-geniculees`, A, désormais la place des
géniculées) et « le tendon calcanéen termine le triceps sural »
(`mi2-qc-tendon-calcaneen`, A, désormais le tendon hors du tunnel tarsien) ;
ces deux faits ne sont plus rappelés que dans l'explication. « De la profondeur
à la superficie : artère, veine, nerf tibial » (`mi2-qc-coupe-genou`, C) reste
ici : le plan le range dans la partie II.A de la FC n°2 (p. 5), même si NiVeA
est carté à la FC n°1 (p. 19). Laissés aux chapitres
de schémas : toutes les planches légendées de Schémas n°2, dont la coupe du
genou, la cheville latérale et les territoires.

### Ce qui n'est pas carté, et pourquoi

| Où | Ce que dit la ronéo | Pourquoi |
|---|---|---|
| p. 8 | la lésion du fibulaire commun mène à « une incapacité irréversible à marcher correctement » | excessif : une compression régresse souvent ; la phrase du professeur (« la gueule de bois va passer mais pas le pied qui tombe », p. 4) est citée comme telle |
| p. 9 | les veines, satellites des artères, « placées médialement à ces dernières » | vrai au trigone fémoral, pas une règle générale ; seul « deux veines par artère après le genou » est carté |
| p. 12 | les tendons fibulaires, derrière la malléole, « obliques en bas et en arrière » | ambigu (sous la malléole ils partent en avant sur le calcanéus) |
| p. 7 | « en plus de l'articulaire talo-naviculaire » | phrase incomplète |
| p. 8 | la liste des nerfs digitaux du fibulaire superficiel | contredit p. 3 pour le 5e orteil (voir les erreurs) ; seul « tout le dos du pied sauf le 1er espace et le bord latéral » est carté |

## Les schémas cliquables

| Fichier | Ce qu'on clique | Carte |
|---|---|---|
| `retro-malleolaire.svg` | malléole médiale ; tendons du tibial postérieur, du long fléchisseur des orteils, du long fléchisseur de l'hallux ; artère tibiale postérieure ; nerf tibial ; rétinaculum des fléchisseurs ; sustentaculum tali ; tubérosité de l'os naviculaire ; tendon calcanéen | `mi2-zo-retro-malleolaire` (10) |
| `loges-jambe.svg` | tibia, fibula, membrane interosseuse ; les onze muscles des quatre plans | `mi2-zo-loges-muscles` (14) |
| `loges-jambe.svg` | artères tibiales antérieure et postérieure, artère fibulaire ; nerfs fibulaires profond et superficiel, nerf tibial | `mi2-zo-loges-vn` (6) |

La région rétro-malléolaire est vue du côté médial d'une cheville droite,
repère « Haut / Avant » comme la dissection de la p. 12 ; les cinq éléments
sont cliquables sur leur portion droite, au-dessus du rétinaculum, là où chacun
est seul ; le rétinaculum l'est en arrière du dernier tendon, le sustentaculum
en avant du tendon qui le croise. La coupe de jambe est vue d'en bas, comme au
scanner et comme la coupe du genou de la p. 4 (repère « Avant / Droite ») : le
côté latéral de la jambe droite est à GAUCHE de l'image, et c'est le piège des
deux chefs du gastrocnémien. Chaque schéma a une version légendée
(`-legende.svg`), tracée par la même fonction, qui illustre la correction de
QCM. La ronéo n'a ni coupe de jambe ni vue schématique de la gouttière
rétro-malléolaire : ces deux dessins ne doublent aucune planche.

Pas de zone sur la cheville latérale, la coupe du genou ni les territoires : ce
sont des planches de Schémas n°2 (p. 8, 3 et 9).

## Les erreurs du Ronéosaure, et les clés

Aucune annale : pas de clé imprimée, pas de `CONFLITS`. Les erreurs de la FC
n°2 que ni l'errata ni la figure ne corrigent sont signalées là où elles se
jouent, par un `ATTENTION` nu (les genres sont réservés aux ronéos 2026-27) ;
chaque carte retient la bonne lecture. `contenu/ERRATA_RONEOS_2026-27.md` ne
liste que les ronéos 2026-27 : rien n'y est écrit.

| Page | Ce que dit la ronéo | Ce qui est juste, et la preuve | Carte |
|---|---|---|---|
| p. 4 (figure) | l'os coupé en arrière de la patella légendé « Tibia » | le **fémur** : surface patellaire (trochlée), fosse intercondylaire, chefs du gastrocnémien contre les condyles ; le texte de la même page dit « la surface patellaire du fémur » ; le cours 2023-24 légende « joues de la surface patellaire » | `mi2-qc-coupe-genou` (E), légende de `coupe-genou.png` |
| p. 3 | le nerf fibulaire profond, « pour la dorsiflexion de la jambe » | la flexion dorsale du **pied** (p. 8 ; cours 2023-24) | `mi2-qc-fibulaire-profond` (E) |
| p. 8 | les long et court fibulaires rangés parmi « les muscles de la loge antérieure » | loge **latérale**, nerf fibulaire superficiel (p. 3 et 8 plus bas ; cours 2023-24) | `mi2-qc-loges` (D) |
| p. 10 (deux fois) | le « ligament calcanéo-cuboïdien-plantaire », « gros cartilage qui soutient la tête du talus » | le ligament **calcanéo-naviculaire** plantaire, le « spring ligament » (cours 2023-24 p. 7 ; Gray's ; StatPearls) ; le calcanéo-cuboïdien plantaire est latéral | `mi2-qc-lcm-cheville` (E), `mi2-qr-spring` |
| p. 2 | la tibiale postérieure, derrière la malléole, « va alors donner l'artère fibulaire » | l'artère fibulaire naît haut, 2 à 3 cm sous le muscle poplité (Schémas n°2 p. 1 ; StatPearls) | `mi2-qc-division-poplitee` (explication) |
| p. 8 | un nerf digital du fibulaire superficiel « pour la partie latérale du 5e rayon » | la même ronéo p. 3 donne le bord latéral au nerf sural, comme la référence (StatPearls, Kenhub) ; on retient p. 3 | `mi2-qc-territoires-pied` (C) |

Trois formulations sont reprises à la bonne lecture, sans `ATTENTION` : le nerf
fibulaire commun qui « contourne la tête » (p. 3) — c'est le col, juste sous la
tête (p. 8) ; le long fléchisseur de l'hallux qui passe « derrière les
tubercules » du talus (p. 11) — entre eux, dans leur sillon (cours 2023-24) ; le
ligament collatéral latéral qui finit sur « le sommet de la fibula » (p. 4) —
le sommet de la tête. L'angle de Djian-Annonier est carté comme le cours
(120-125° ; au-dessus pied plat, au-dessous pied creux), et l'explication donne
les seuils de la référence (pied creux sous 115°, pied plat au-delà de 137°,
vérifiés au dictionnaire de l'Académie de médecine).

Trois précisions de la référence, sans `ATTENTION` parce que le cours n'est pas
faux, seulement plus court : le cours compte **quatre** artères géniculées, les
références en décrivent une cinquième, la géniculée moyenne
(`mi2-qc-geniculees`, B, le dit) ; l'os peroneum est **inconstant** (« on
décrit », p. 6 : la proposition le reprend mot pour mot) ; le sinus du tarse a
aussi une ouverture médiale, étroite (« plus large latéralement que
médialement », p. 12 : la proposition fausse porte sur l'orifice **le plus
large**).

## Le lexique

Neuf termes, aucun accueilli par un autre chapitre, pages mesurées dans le
texte de la FC n°2 (et de la FC n°1 quand elle les emploie) : **fibulaire**,
**rétinaculum**, **malléole**, **tarse**, **calcanéus**, **talus**, **hallux**,
**soléaire**, **patella**. En réserve : sustentaculum tali (p. 10-11). Les
termes de la cuisse, de la région glutéale et de la fosse poplitée (poplité,
sural, gastrocnémien…) sont au chapitre FC n°1. L'origine latine ou grecque de
chaque terme et de chaque racine est proposée dans le fichier d'étymologies du
chapitre (TLFi, Gaffiot, Bailly, Wiktionnaire), puis s'écrit par
`appliquer_etymologies.py` ; une racine existante est reprise telle quelle
(`re- (latin)`).

## À relire

**2 cartes `a-relire`** : `mi2-zo-loges-muscles` et `mi2-zo-loges-vn`, la coupe
de jambe. Chaque fait qu'elles enseignent est dans le cours (loge, insertion,
innervation, page citée), mais la place relative des muscles et des pédicules
dans la coupe (long fléchisseur des orteils en dedans, de l'hallux en dehors,
pédicule tibial postérieur sur le tibial postérieur, nerf tibial en arrière et
en dehors de l'artère — il la croise en arrière dans le haut de la jambe —,
artère fibulaire près de la fibula, cloison postérieure en arrière du court
fibulaire) n'est dessinée nulle part dans la ronéo : elle vient des références
(Gray's, Kamina).
Le tag se retire quand un dessin du professeur (ronéo 2026-27, ou coupe de jambe
d'un bloc de schémas) l'aura confirmée.

## Régénérer

```powershell
cd contenu\chapitres\anat_fc2
..\..\..\app\.venv\Scripts\python.exe generer.py
```

`generer.py` est la copie exacte de `scripts/generer_modele.py` du skill. Les
figures de `media/` ont été extraites des PDF du Ronéosaure (images embarquées
de la FC n°2, rendu de la p. 9 de Schémas n°2), réduites à 1100 px et 256
couleurs.
