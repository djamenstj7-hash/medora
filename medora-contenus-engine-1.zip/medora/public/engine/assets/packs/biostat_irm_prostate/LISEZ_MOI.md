# IRM du cancer de la prostate — paquet Biomédecine quantitative

65 notes, 132 cartes. Chapitre `chap-ue-biomed-quanti-fc7` de l'UE
Biomédecine quantitative, quatrième de l'UE. Cours du **Pr P. Puech, le
22/10/2025, de 9 h à 10 h**, dans le **Ronéosaure 2025-26** (FC n°4, 9 pages) ;
huit annales du polycopié « 6. Tests diagnostiques » du Ronéosaure 2024-25 (7
sessions). Examen : partiel du mercredi 16 décembre 2026.

**Fiche provisoire** (C15, décision de Vincent du 02/10) : le cours de l'année
2026-27 n'est pas encore paru. Chaque carte de cours cite la FC 2025-26 à sa
page et porte le badge « Cours 2025-26 » ; le ronéo 2026-27 corrigera les cartes
quand il sortira. `donnees.py` porte `ANNEE_COURS = "2025-26"`. Aucune carte ne
dit « Absent du cours 2026-27 », et les erreurs du Ronéosaure sont dites par un
ATTENTION sans genre : la liste des erreurs de la promo,
`contenu/ERRATA_RONEOS_2026-27.md`, ne concerne que les ronéos 2026-27.

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 30 | 30 |
| Texte à trous | 10 | 74 |
| QROC | 10 | 10 |
| Recto-verso | 5 | 5 |
| Schéma cliquable | 1 | 4 |
| Planche à légender | 1 | 1 |
| Lexique | 8 | 8 |

Dont **8 annales** sur 7 sessions (2015/2016 à 2021/2022), toutes du polycopié
« 6. Tests diagnostiques » ; les 22 autres QCM sont des questions de cours.

Huit thèmes, dans l'ordre du cours. Trois sont ceux du chapitre des tests
diagnostiques, déjà dans `THEME_LABELS` ; cinq sont nouveaux et leurs libellés
restent à ajouter à `THEME_LABELS` (`app/src/med_engine/application/scopes.py`) :

| Clé | Libellé | Notes |
|---|---|---|
| `irm-sequences` *(nouvelle)* | IRM multiparamétrique de la prostate | 5 |
| `irm-performance` *(nouvelle)* | Performance diagnostique de l'IRM : la première étude | 15 |
| `cancer-significatif` *(nouvelle)* | Cancer significatif et critère de maladie | 4 |
| `valeurs-extrinseques` | Valeurs prédictives et prévalence | 6 |
| `irm-lecteurs` *(nouvelle)* | Score objectif, lecteurs et reproductibilité | 5 |
| `pi-rads` *(nouvelle)* | Score PI-RADS et recommandations | 10 |
| `depistage` | Stratégies de dépistage | 7 |
| `concordance` | Concordance et coefficient kappa | 5 |

Le plan C15 proposait `etude-2008` et `etude-2010`, avec « Étude de 2008 » et
« Étude de 2010 » dans le libellé : une clé ou un libellé qui porte un chiffre
n'est pas un thème. D'où `irm-performance` et `irm-lecteurs`.

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-biomed-irm-2526` — Ronéosaure, « FC n°4 - IRM du cancer de la prostate » (9 p.) | 2025-26 | le cours ; `SRC["fiche"]`, ses 12 figures ; fiche provisoire en attendant le ronéo 2026-27 |
| `src-annales-6-tests-diagnostiques` — « 6. Tests diagnostiques » (34 p.) | 2024-25 | 8 questions, table p. 33-34 ; déclaré à l'identique du chapitre des tests diagnostiques |

Lus en appoint, sans être déclarés : le cours 2024-25 (FC n°7, « IRM du cancer
de la prostate »), pour vérifier que deux phrases du ronéo 2025-26 étaient déjà
dans celui de l'année précédente ; la FC n°3 2025-26 (tests diagnostiques),
citée pour les formules (Bayes, dépistage en deux temps, kappa) ; les erratas
des cours 2025-26 et des annales 2024-25, qui n'ont aucune entrée pour ce cours
ni pour ces huit questions. Vérifiés sur des sources sûres : l'essai PRECISION
(Kasivisvanathan, NEJM 2018 ; chiffres repris de l'ASCO Post), la date des
recommandations de l'EAU, les versions du PI-RADS, la définition de l'index de
Youden (Youden 1950 ; manuel de MedCalc).

Les pages citées sont celles du PDF ; la p. 1 est la page de garde et le plan.
Les en-têtes des ronéos, des erratas et du polycopié portent des noms
d'étudiants : aucun n'est repris. Le polycopié d'annales attribue ces questions
au « Pr Puech » : l'attribution n'est pas reprise.

## Ce que le cours a dicté

- **Le rouge** — le but de l'IRM (p. 2), « cancer non significatif » (p. 3),
  « booléennes » et « binaire » (p. 4), « seuil » et « prévalence » (p. 5), les
  deux lignes « Important à retenir » (p. 6), le score objectif, la
  reproductibilité inter-observateurs, « indépendamment du PSA et de l'histoire
  clinique » et le PI-RADS (p. 7), « l'IRM fait mieux que les biopsies » (p. 8),
  « biostatistiques » (p. 9) — a chacun sa carte.
- **Le gris** (p. 3, « Touche pas à ma prostate ») est la voix des rédacteurs :
  il se carte comme le reste, dans les explications du cancer significatif.
- **Les figures** : les deux études ont leurs chiffres sur les diapositives. Le
  tableau des cancers significatifs (p. 5 : 92, 71, 7, 115) devient un exercice
  (`irm-qc-calcul-2008`) ; le tableau par patient, côté et secteur (p. 5),
  une question sur la perspective de lecture (`irm-qc-perspectives`) ; le
  rapport du Prostate Score Trainer (p. 9), un exercice de kappa
  (`irm-qc-kappa-calcul`) ; la démarche de 2025 (p. 8), une planche.
- **Ce qui n'est pas carté ici** (plan C15) : le test diagnostique dans
  l'abstrait — définitions, formules, tableau de contingence, courbe ROC,
  kappa — au chapitre des tests diagnostiques (FC n°3), que les cartes citent.

## Les erreurs du Ronéosaure 2025-26

Le Ronéosaure n'est pas le ronéo de l'année : chaque erreur est portée par un
**ATTENTION nu** dans la carte qui tient la notion, la sorte dite dans le texte,
et rien n'entre dans `contenu/ERRATA_RONEOS_2026-27.md`. Aucune proposition de
carte ne repose sur une phrase douteuse.

| Page | Le ronéo dit | Retenu | Sorte | Carte |
|---|---|---|---|---|
| 5 | MedCalc « détermine l'index de Youden automatique : distance avec le point supérieur gauche » (comme le ronéo 2024-25, p. 6) | J = Se + Sp − 1, la plus grande distance verticale entre la courbe et la diagonale ; le point le plus proche du coin supérieur gauche est la méthode géométrique (FC n°3, p. 6), souvent le même seuil, pas toujours — c'est le cas ici (> 6 sur la figure de la p. 7) | le cours lui-même | `irm-qc-youden` B |
| 6 | en rouge, « le seuil de positivité du test est la prévalence dans la population » (mot pour mot en 2024-25, p. 7) | VPP et VPN dépendent de la prévalence et du seuil choisi ; la diapositive de la p. 5 dit les deux séparément | point douteux | `irm-qc-seuil-maladie` D |
| 7 | « plus reproductible d'un vecteur à l'autre » | d'un lecteur à l'autre (« reproductibilité inter-observateurs », même page) | prise de notes | `irm-qc-resultats-2010` B |
| 7 | le PI-RADS, « standard qui date de 2013 » | v1 publiée par l'ESUR en 2012, v2 en 2015, v2.1 en 2019 | point douteux | `irm-qc-pirads` (explication) |
| 8 | « si jamais l'IRM est négative, alors dans 28 % des cas ça ne sert à rien de faire une biopsie » | essai PRECISION (NEJM 2018) : 71 hommes sur 252 du bras IRM (28 %) avaient une IRM non suspecte et ont évité la biopsie | point douteux | `irm-qc-precision` D |
| 8 | « Recommandations de l'EAU de 2018 » | l'EAU inscrit l'IRM avant toute première biopsie dans sa mise à jour de 2019 | point douteux | `irm-qc-recommandations-2018` (explication) |
| 8 | « EAU : European Agency of Urology » (note 3) | European Association of Urology | prise de notes | `irm-qc-recommandations-2018` E |
| 8 | « la présence d'une hyperdensité » | la densité du PSA : la diapositive porte « PSAd > 0,15 ng/mL/mL », calculée sur le volume IRM | prise de notes | `irm-qc-recommandations-2025` E, `irm-fa-recommandations-2025`, planche n° 8 |
| 9 | « (environ 20 % de biopsies aujourd'hui) » | 20 % de biopsies évitées (p. 8) | prise de notes | `irm-qc-conclusion` E |
| 9 | « Ici, κ = 0,58 » | 0,58 est la concordance observée (58 lésions sur 100 en accord parfait, le « PP » du rapport) ; le kappa simple, recalculé sur le tableau, vaut 0,47 ; le kappa pondéré 0,76 (pondération quadratique : 0,759) | prise de notes probable, point douteux sur ce qu'a dit le professeur | `irm-qc-kappa-calcul` A |

Écarts au plan C15 : l'index de Youden et le κ = 0,58 sont des erreurs trouvées
en relisant (le plan ne les avait pas) ; la « hyperdensité », que le plan tenait
pour douteuse et sans carte, est tranchée par la diapositive de la p. 8, qui
porte « PSAd » : elle a sa carte. Les autres lignes sont celles du plan. Deux
formulations du ronéo sont rendues justes sans ATTENTION, n'étant que
maladroites : « étude modeste avec une seule valeur (monocentrique) » (p. 3 :
un seul centre) ; « le score 3 est bénin » (p. 8 : il n'impose plus de biopsie
d'emblée, mais garde 20 % de cancer significatif — les cartes le disent).

## Ce que les annales ont dicté

| Savoir | Questions |
|---|---|
| La VPP du même PSA selon la population : 87 % au service d'urologie, 3 % chez les plus de 80 ans (P = 0,92 %), 0,02 % chez les 40-50 ans (P = 0,006 %) | 3 : 2021/2022 S1 Q28, 2018/2019 S1 Q5, 2016/2017 S2 Q2 |
| Le test T en deux temps : PSA (T1), puis imagerie (T2) chez les seuls T1 positifs ; VPP 3 %, 8 % et 24 % | 5 : 2018/2019 S2 Q5, 2016/2017 S1 Q12, 2016/2017 S2 Q4, 2015/2016 S1 Q4, 2015/2016 S2 Q12 |

Les trois VPP se retrouvent exactement par le théorème de Bayes avec Se = 0,20
et Sp = 0,94, celles du tableau 20/3/80/47 des questions qui précèdent : le
schéma `vpp-population.svg` le montre. Chaque session a sa carte ; l'explication
renvoie aux autres. Les deux questions qui renvoient à « la question
précédente » (le tableau du PSA, carté au chapitre des tests diagnostiques) le
rappellent dans leur explication.

## Le schéma cliquable, la planche et les figures

**Un schéma cliquable** (`schemas.py`), avec sa version légendée en correction :

| Fichier | Ce qu'on clique | Pourquoi ce dessin |
|---|---|---|
| `pirads.svg` | les scores 1-2 (une zone : le cours les traite ensemble), 3, 4 et 5, chacun nommé par son risque de cancer significatif ou sa conduite — 4 zones | l'échelle de la p. 8 : 20, 70 et 95 % de cancer significatif pour 3, 4 et 5, et le 3 positif avant 2025, « bénin » depuis ; la légende redit la conduite avant et depuis 2025 |

**Une planche à légender**, `irm-pl-strategie-2025` (`planche_depuis_image.py`) :
la démarche de 2025 (p. 8), une capture de diapositive agrandie 1,4 fois, ses
onze cases vidées (évaluations du risque de niveaux 1 et 2, TR et PSA, IRM,
PI-RADS 1-2, 3 et 4-5, densité du PSA, biopsies systématisées et ciblées,
surveillance, traitement) ; la case de titre, « Suspicion clinique », reste
lisible ; trois intrus (bilan d'extension, prostatectomie d'emblée, dosage du
PSA libre). L'aperçu de contrôle a été regardé : chaque rectangle couvre tout le
texte de sa case, aucun reste de lettre ; les couleurs des cases PI-RADS ne
restent qu'en liseré.

**Deux figures redessinées** pour les corrections des annales :
`test-sequentiel.svg` (le test en deux temps) et `vpp-population.svg` (la VPP
dans trois populations, et la formule de Bayes).

**Douze figures de la FC 2025-26**, extraites en PNG (captures de diapositives et
coupes d'IRM), réduites à 1000 px de large au plus et en 256 couleurs. Les
coupes d'IRM (p. 2) n'illustrent que les cartes des séquences qui les
commentent ; aucune photographie de patient seule. **30 QCM sur 30 illustrés**,
53 notes sur 65.

## Les clés qui ne sont pas reprises telles quelles

| Question | Clé imprimée | Retenu | Pourquoi |
|---|---|---|---|
| 2018/2019 S1 Q5 | ABD | CD (`officielle=False`, CONFLITS A, B, C) | la colonne 2018/2019 S1 de la table (AC, ACD, CDE, ABD) ne va avec aucun énoncé de la session ; « ABD » compterait vraies « la VPP est la probabilité qu'un test soit positif chez les non malades » et une VPP qui baisserait « parce que l'effectif augmente », et fausse la formule de Bayes |
| 2016/2017 S2 Q2 | CE | CD, clé déduite | la colonne 2016/2017 S2 (1.C, 2.CE, 3.BCDE, 4.BD) recopie la table de la régression linéaire de la même session |
| 2016/2017 S2 Q4 | BD | BCE, clé déduite | idem ; les mêmes propositions, dans le même ordre, ont la clé BCE en 2018/2019 S2 et 2016/2017 S1 |
| 2015/2016 S2 Q12 | BCE (colonne S2, n° 12) | BCE, clé déduite | la colonne « session 2 » porte, sous les n° 9 à 12, les clés de la session 1 ; ce « 12.BCE » est la clé de la S1 Q4, qui vaut aussi ici, les mêmes propositions étant rangées autrement |

Reprise de la colonne voisine, et gardée officielle : **2015/2016 S1 Q4** (BCE),
que la table imprime dans la colonne « session 2 » sous le n° 12, la colonne
« session 1 » recopiant la régression linéaire 2015/2016 S1 (« 4. AE ») — même
choix que le chapitre des tests diagnostiques pour les Q1-3 ; l'explication le
dit. Les autres anomalies, sans effet sur les clés : en 2021/2022 S1 Q28, la
formule de C est imprimée tronquée (« VPP=Se*P »), fausse telle quelle, et la clé
imprimée D va avec l'énoncé ; en 2015/2016 S2 Q12, les espaces manquent après
les points de l'énoncé (gardé tel quel).

## Le lexique

Huit termes, ceux du plan C15 ; aucun n'existait (vérifié contre les `lex-*`
de tous les paquets et des chapitres en cours). Pages mesurées dans le texte de
la FC 2025-26 avec PyMuPDF, page de plan exclue, ligatures normalisées :

| Terme | Origine | Pages |
|---|---|---|
| Biopsie | grec βίος + ὄψις | 2-9 |
| Prostatectomie | grec προστάτης + ἐκτομή | 3, 6 |
| Multiparamétrique | latin multus + grec παρά + μέτρον | 3, 5, 8 |
| Néovascularisation | grec νέος + latin vasculum | 2 (écrit « néo-vascularisation ») |
| Reproductibilité | latin re- + producere | 7 |
| Sextant | latin sextans | 4 |
| Prostatite | grec προστάτης + -ῖτις | 6 |
| Échographie | grec ἠχώ + γράφειν | 2, 8, 9 |

`bi(o)-` cite la FC de sémantique (1/2, p. 7) et `-ectomie` (2/2, p. 2), comme
dans les autres chapitres. Les racines nouvelles (`multi- (latin)`,
`vasculum (latin)`, `producere (latin)`, `prostat(o)-`, `sextans (latin)`,
`écho- (grec)`) et les huit termes sont proposés à la table commune
(`etymologies.json`, proposition `etym/biostat_irm_prostate.json` du brouillon),
vérifiés sur le Wiktionnaire, le Bailly et le Gaffiot ; les textes du lexique
sont déjà écrits dans la forme que `appliquer_etymologies.py` produirait.
`multi- (latin)` est proposée à l'identique par les chapitres de phase III et
des scores (« multus », « nombreux, beaucoup ») : une seule entrée à la fusion,
et le même sens de racine dans les trois chapitres.

## Questions pour Vincent

1. **Le κ = 0,58 du ronéo** (p. 9) : le calcul sur le tableau de la diapositive
   montre que 0,58 est la concordance observée et que le kappa simple vaut
   0,47. La carte suit le calcul, signale l'erreur, et ne pose aucune
   proposition « κ = 0,58 ». À confirmer sur le ronéo 2026-27 : si le
   professeur dit lui-même « kappa 0,58 », la sorte deviendra « le cours
   lui-même ».
2. **L'index de Youden** (p. 5) : classé « le cours lui-même » (la même phrase
   dans les ronéos 2024-25 et 2025-26). La carte donne la définition juste
   (Se + Sp − 1) et la réponse d'examen (le seuil optimal) ; aucune proposition
   ne demande « distance au point supérieur gauche ».
3. **La « hyperdensité »** : le plan la tenait pour douteuse et sans carte ; la
   diapositive de la p. 8 porte « PSAd > 0,15 ng/mL/mL », d'où une prise de
   notes et trois cartes qui disent la densité du PSA. À garder ainsi ?
4. **2015/2016 S1 Q4** : clé prise dans la colonne voisine de la table et gardée
   officielle, comme le chapitre des tests diagnostiques le fait pour les Q1-3
   (sa question 2). Faut-il plutôt la marquer non officielle ?
5. **Les thèmes `irm-performance` et `irm-lecteurs`**, à la place de
   `etude-2008` et `etude-2010` du plan (une clé à chiffre n'est pas un thème) :
   les libellés vous conviennent-ils ?
6. **La planche de la démarche de 2025**, en plus du schéma PI-RADS prévu : elle
   fait apprendre l'enchaînement des étapes, que les cartes ne demandent qu'en
   texte.

## À relire

**Aucune carte `a-relire`** : chaque carte cite une page de la FC 2025-26, et
chaque clé d'annale a été vérifiée proposition par proposition, énoncés et table
relus sur le PDF (p. 8, 18-21, 26-34).

Reste à Vincent :

- quand le ronéo 2026-27 paraîtra, relire chaque carte sur lui et retirer le
  badge « Cours 2025-26 » ;
- `copier_les_cours.py` avec le dossier `…/S1 25-26/examen décembre` du
  Ronéosaure 2025-26, hors du bac à sable, pour que la fiche s'ouvre dans
  l'application ;
- les cinq libellés de thème nouveaux à ajouter à `THEME_LABELS`.

## L'échelle : Simple → Moyen → Annale (C20, 18/10)

Demande de Vincent, 18/10 (C29), pour l'examen du 16 décembre. Sous les annales, 7 cartes Simple (`niveau-simple`, une idée, trois choix, le schéma troué dans la question) et 2 cartes Moyen (`niveau-moyen`, une paire à ne pas confondre, le schéma à lettres en correction). Chaque annale garde la figure du cours et reçoit son schéma (`diagramme=`).

| Thème | Simple | Moyen | Annales |
|---|---|---|---|
| `valeurs-extrinseques` | 4 | 1 | 3 |
| `depistage` | 3 | 1 | 5 |

**Le schéma** `ech-vpp-deux-temps`, « Le PSA puis l'imagerie · lire un test positif », donne 18 fichiers (complet, troués, à lettres). Il est décrit dans `schemas.py` (`ECH_VPP_DEUX_TEMPS`, `TROUS_*`, `LETTRES_*`) et dessiné par `echelle.py`, copie exacte du modèle du skill. Les marches sont dans `ECHELLE`, à la fin de `donnees.py`, entre deux marqueurs.

**Comment elles ont été faites.** Un agent les a rédigées sur les propositions des annales et leurs justifications. Un sceptique les a ensuite réfutées contre le texte et les figures du cours, et un critique de complétude a relu tous les chapitres du lot ensemble : clés réparties, Moyen d'une à trois vraies, aucune recopie, aucun trou trahi.

**Source déclarée en plus** : `src-fc-biomed-tdg-2526`, à l'identique de `biostat_tests_diagnostiques`, pour `irm-ech-s3`.

## Régénérer

```powershell
..\..\..\app\.venv\Scripts\python.exe generer.py
```

La planche numérotée se refait depuis `app/` (Pillow n'est pas une dépendance
du projet) :

```powershell
uv run --with pillow python ../.claude/skills/nouveau-chapitre/scripts/planche_depuis_image.py ../contenu/chapitres/biostat_irm_prostate irm-pl-strategie-2025 --taille 44 --apercus <brouillon>
```
