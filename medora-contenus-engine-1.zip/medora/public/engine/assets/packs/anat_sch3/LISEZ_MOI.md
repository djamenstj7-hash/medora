# Membre supérieur (Schémas n°3) — paquet Anatomie

24 notes, 26 cartes. Chapitre `chap-ue-anatomie-sch3` de l'UE Anatomie
(identifiant du squelette), cours du **Pr Demondion**. Sources : le livret
**Schémas n°3 - Membre supérieur du Ronéosaure 2024-25** (4 pages), qui est la
fiche du chapitre, l'annale **2021/2022 (session 1)**, et en appoint la FC n°3
2024-25 et le cours 2023-24 (Charonéo, cours 4, p. 1-8) du même professeur.
Examen : partiel de novembre. **Relu le 11/10/2026 sur les deux ronéos
2026-27** du Pr Demondion, qui font foi (section « Relus sur la ronéo
2026-27 »).

**Depuis le 07/10/2026, le Book Schéma 2025-26 fait foi** (Vincent : les
planches les plus récentes, complétées par celles de 2024-25 quand il manque de
la précision). Le cours 2025-26 du membre supérieur est du **Pr Herteleer**
(FC n°2 et n°3 2025-26) ; ses fiches vérifient les légendes du Book. Ses
schémas entrent un à un, chacun en deux cartes : la planche à légender et le
schéma à refaire sur papier (voir plus bas). Au 18/10 : les schémas n° 1 à 6 et 8 (le n° 7 est dans les Schémas n°4).

**Les ronéos d'anatomie 2026-27 du membre supérieur sont parues le 11/10/2026**
(Ronéo & Juliette, deux cours du 29/09/2026). Les planches gardent leur fiche,
le livret dont elles sont tirées (`chapitre=`) ; la phrase de chaque numéro cite
d'abord le cours de l'année. Le cours continue (le 3e ronéo, du 06/10, ne fait
que l'avant-bras et la main ; les CM suivants sont sans ronéo) : aucune carte ne porte « Absent du cours 2026-27 ». Les erreurs du
Ronéosaure gardent un `ATTENTION` sans genre ; celles des ronéos 2026-27
portent leur genre (prise de notes, cours, douteux) et sont à verser dans
`contenu/ERRATA_RONEOS_2026-27.md` (tableau plus bas).

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| Planche à légender | 11 | 11 |
| QRM | 3 | 3 |
| QRU | 2 | 2 |
| Schéma cliquable | 1 | 3 |
| Schéma à refaire sur papier (recto-verso) | 7 | 7 |

Dont **5 cartes d'annales** sur une session (2021/2022, session 1) : la planche
des dix traits, l'orientation et les trois espaces. **6 cartes portent un piège
des ronéos 2026-27** (thème `piege-roneo`) : les trois planches des Schémas n°3,
les planches n° 1 et 3 du Book et la carte d'orientation.

Sept thèmes, un jeu partagé par tout le membre supérieur (plan des quatre
chapitres FC n°3, FC n°4, Schémas n°3 et n°4). Leurs libellés sont dans
`THEME_LABELS` (`app/src/med_engine/application/scopes.py`) :

| Clé | Libellé |
|---|---|
| `region-scapulaire` | Région scapulaire |
| `region-axillaire` | Région axillaire |
| `insertions-musculaires` | Insertions musculaires |
| `nerfs` | Nerfs : origine, trajet, territoire |
| `vascularisation` | Vascularisation |
| `espaces-passages` | Espaces, canaux et passages |
| `orientation-schema` | Orienter et compléter un schéma |

Chaque planche porte sa région en thème et ses couches (muscles, nerfs,
vaisseaux, espaces) en tags.

## Ce que le cours a dicté

L'examen d'anatomie est un **schéma**, pas un QCM (FC n°4 2024-25, p. 2 et 5 ;
Book Schéma, p. 2) : le professeur donne un fond de dessin, on l'oriente, on
nomme les structures fléchées, on dessine et on annote vaisseaux, nerfs,
parfois muscles, et il « insiste sur la bonne localisation ». Le Book Schéma
prévient que ses planches peuvent porter des coquilles. D'où la forme du
chapitre : apprendre à **lire** chaque dessin du livret.

- Le rouge du Ronéosaure n'est pas une consigne, c'est son code couleur
  (artères en rouge, veines en bleu, nerfs en jaune, muscles en brun). Aucun
  gris dans le livret.
- Les trois dessins sont ceux de l'équipe ronéo, redessinés des schémas du
  professeur ; Schémas n°3 p. 2-4 et Book Schéma 2024-25 p. 17-19 sont les
  mêmes fichiers (vérifié). Le Book 2025-26 est un autre jeu de dessins. La p. 1, contour de la région scapulaire « sans
  annotations », n'est pas une planche.
- Conventions de dessin reprises dans les corrections : le nerf axillaire
  d'une autre couleur que le supra-scapulaire, dont il n'est pas la suite
  (FC n°3 p. 4) ; « pas obligé de dessiner 3 faisceaux » au grand pectoral,
  mais le sillon delto-pectoral (FC n°3 p. 5).

## Les planches à légender

Faites par `scripts/planche_depuis_pdf.py` (légendes retirées du PDF, numéros
imprimés au départ des traits) ; chaque aperçu de contrôle a été relu : plus
aucune légende lisible, un numéro par trait, au bon trait (les petits numéros
11 et 14 de la p. 2, les légendes sur deux lignes de la p. 4 compris). Le
dessin légendé du livret fait la correction ; une phrase par numéro dit
l'insertion, le trajet ou le contenu, avec la page de la FC n°3.

| Note | Page | Numéros | Intrus |
|---|---|---|---|
| `ms-s3-scapulaire-post` — vue postérieure de la région scapulaire | 2 | 25 (le n°21 renommé « Aponévrose thoraco-lombaire », le nom du cours 2026-27) | subscapulaire, dentelé antérieur, artère subscapulaire, vaste médial du triceps, artère thoraco-dorsale |
| `ms-s3-axillaire-dissection` — dissection en vue antérieure de la région axillaire | 3 | 8 | petit pectoral, veine axillaire, artère thoracique latérale, veine basilique |
| `ms-s3-axillaire-profonde` — vue antérieure profonde de la région axillaire | 4 | 14 | veine axillaire (dessinée, non légendée), dentelé antérieur, artère thoracique interne, chef long du biceps, artère subscapulaire |
| `ann-ms-2122-muscles` — le dessin de l'annale 2021/2022 | annale p. 3 | 10 | élévateur de la scapula, vaste latéral du triceps, subscapulaire, dentelé antérieur |

- La p. 2 garde ses 25 numéros en une carte : la règle est une planche, une
  carte. La couper en deux (muscles d'un côté ; espaces, vaisseaux et nerfs de
  l'autre) reste possible si elle se révèle trop lourde.
- La p. 3 : « Muscle grand pectoral : 3 faisceaux » est une seule légende
  (un seul trait), retenue « Muscle grand pectoral ».
- La p. 4 : le petit pectoral a deux numéros (3, sur le processus coracoïde ;
  9, sur les côtes), même légende.
- « Vaste latéral du triceps » est le nom du professeur ; la phrase du numéro
  dit le nom international (chef latéral) et le distingue du quadriceps.
- L'annale : le sujet est un dessin scanné, sans texte ni trait vectoriel à
  lire. Ses dix traits ont été mesurés sur un rendu à 300 dpi et numérotés par
  un script du brouillon (`planche_annale.py`), qui écrit aussi le dessin nu
  (`ann-ms-2122-sujet.png`, en énoncé des QCM) et la correction : le même
  dessin avec les noms retenus et l'orientation, en bleu, signée « lecture
  MED_ENGINE ».

**Lecture des dix traits de 2021/2022** (numérotés de haut en bas) :

| N° | Trait | Retenu | Degré |
|---|---|---|---|
| 1 | gauche, le cou, entre les processus épineux et le bord du trapèze (la courbe occiput → acromion) | trapèze | probable : aucun autre trait ne vise le trapèze, et l'élévateur de la scapula n'est dessiné que dans la fenêtre, où aucun trait ne le désigne |
| 2 | oblique, fosse supra-épineuse pointillée | supra-épineux | sûr |
| 3 | gauche, fenêtre, au-dessus de la cloison oblique | petit rhomboïde | probable |
| 4 | droite, galbe de l'épaule | deltoïde | sûr |
| 5 | gauche, fenêtre, sous la cloison | grand rhomboïde | probable |
| 6 | droite, bande vers le moignon hachuré du tubercule majeur | petit rond | probable |
| 7 | gauche, fosse infra-épineuse | infra-épineux | sûr |
| 8 | gauche, sous le petit rond, de l'angle inférieur vers l'humérus | grand rond | probable |
| 9 | gauche, fibres convergentes sous l'angle inférieur | grand dorsal | probable |
| 10 | droite, juste en dehors de la bande étroite qui descend du tubercule infra-glénoïdal, en dedans d'un trait oblique | chef long du triceps | douteux (ou chef latéral, « vaste latéral » du professeur, en dehors du trait oblique) |

Relecture sur des rendus de l'énoncé à 360-720 dpi : les bouts
des traits 3, 5, 6, 8 et 9 tombent bien dans les bandes retenues (3 et 5 de part
et d'autre de la cloison des rhomboïdes, 6 dans la bande qui passe en arrière du
chef long vers le tubercule majeur, 8 sous le petit rond, dans la bande dont la
suite passe en pointillé sous le chef long, c'est-à-dire en avant de lui, 9 dans les fibres qui
convergent sous l'angle inférieur).

## Le Book Schéma 2025-26

`src-book-schema-ms-2526` — « Book Schéma - Membre supérieur » du Ronéosaure
2025-26 (35 p.) : 15 schémas, fonds vides p. 4-18, corrections p. 20-35.
Chemin : `ANATOMIE/Book Schéma - Membre supérieur.pdf`. Ses légendes sont
manuscrites, donc des pixels : chaque planche se fait avec
`scripts/planche_depuis_image.py` du skill, un rectangle à blanchir par légende
dans `donnees.py`, et l'aperçu de contrôle se relit avant l'emploi. Les pages
sont rendues à 130 dpi (`ms-NN-fond.png`, `ms-NN-correction.png`).

| Schéma | Planche à légender | À refaire sur papier |
|---|---|---|
| n° 1 — vue antérieure de la fosse axillaire (fond p. 4, correction p. 20) | `ms-b1-fosse-axillaire-ant` : 17 numéros, dont « Droite » sur la flèche ; « Haut » et le titre restent écrits ; intrus : Gauche, ligament transverse de la scapula, veine axillaire, coraco-brachial, artère thoraco-acromiale, petit rond | `ms-rd-fosse-axillaire-ant` : seize structures, titre et orientation |
| n° 2 — l'artère subclavière et le plexus brachial (fond p. 5, le tracé sans légende ; correction p. 21) | `ms-b2-plexus-brachial` : 19 numéros, les deux flèches du repère comprises ; les racines C5 à T1 restent écrites ; « Tronc » et son accolade s'effacent avec le tronc supérieur | `ms-rd-plexus-brachial` : dix-sept structures, à légender sur le tracé |
| n° 3 — vue postérieure de la région axillaire, la « région scapulaire postérieure » du cours 2026-27 (fond p. 6, correction p. 22) | `ms-b3-axillaire-post` : 14 numéros ; le trapèze réséqué n'est que son contour jaune | `ms-rd-axillaire-post` : douze structures |
| n° 4 — vue postérieure de la région scapulaire, les espaces axillaires (fond p. 7, correction p. 23) | `ms-b4-scapulaire-post` : 19 numéros, dont les trois espaces (texte violet du Book) | `ms-rd-scapulaire-post` : dix-sept structures |
| n° 5 — vue désarticulée de la scapula (fond p. 8, correction p. 24) | `ms-b5-scapula-desarticulee` : 19 numéros, dont « Haut » et « Arrière » | `ms-rd-scapula-desarticulee` : dix-sept structures |
| n° 6 — vue antérieure de la région scapulaire, les ligaments de l'épaule (fond p. 9, correction p. 25) | `ms-b6-scapulaire-ant` : 11 numéros ; les noms de groupe s'effacent avec le premier faisceau, les accolades restent | `ms-rd-scapulaire-ant` : neuf structures |
| n° 8 — vue postérieure de la scapula (fond p. 11, sans repère ni ligne de titre ; correction p. 27) | `ms-b8-scapula-post` : 11 numéros ; « Triceps brachial » s'efface avec le chef long, son accolade reste ; le nerf ulnaire, dessiné sans légende, est dit dans la phrase du grand rond (la FC n°3 2025-26, p. 5, le légende) | `ms-rd-scapula-post` : neuf structures |
| n° 7 (vue antérieure du bras) et n° 9 à 15 | dans le chapitre des Schémas n°4 (`anat_sch4`), qui déclare la même source à l'identique | |

Les phrases des n° 2 à 6 citent d'abord le cours 2026-27 du Pr Demondion,
puis les FC n°2 et n°3 2025-26 du Pr Herteleer, qui portent la vue désarticulée
et les ligaments de l'épaule (FC n°2 2025-26, p. 10-11 ; FC n°3 2025-26, p. 2)
que les cours 2026-27 parus ne traitent pas. Les coquilles du Book sont
corrigées dans la liste et dites dans la phrase : « Nerf radiale », « Muscle su
scapulaire », « Racine latéral », « Tubercule » (le tubercule glénoïdal).
Erreurs de la FC n°3 2025-26 signalées par un `ATTENTION` simple : le nerf
axillaire qui « innerve le col chirurgical » (p. 5), au n° 8 ; il le contourne.
Erreurs de la FC n°2 2025-26 signalées par un `ATTENTION` simple : le grand
dorsal « inséré » sur l'angle inférieur et « terminé » sur les processus
épineux « de C7 » (p. 8). Une confusion relevée dans les notes de cours de
Vincent, dite au n° 6 sans `ATTENTION` (aucun document distribué ne l'écrit) :
il n'y a pas de « muscle infra-glénoïdal », c'est le chef long du triceps qui
naît du tubercule de ce nom.

Relecture du lot 1 (n° 2 à 6) par un sceptique (18/10) : les fonds, les
corrections, les rectangles et les comptes des versos tiennent. Corrigé sur sa
remarque :
- **la flèche du trapèze du n° 3**, que le Book arrête dans le muscle que vise
  aussi l'élévateur de la scapula : une coquille, dite par un `ATTENTION` ; le
  trapèze réséqué est le contour jaune, là où la FC n°2 2025-26 (p. 6) arrête
  la même flèche ;
- deux points douteux du cours 2026-27 que les phrases citaient, déjà dans la
  liste des erreurs : le petit rhomboïde « à partir de C4 environ » et
  l'aponévrose thoraco-lombaire « jusqu'à L2 » (`ATTENTION (douteux)`, et la
  carte ajoutée à leurs lignes) ;
- l'orientation : le cours 2026-27 et la FC n°2 2025-26 tracent la flèche
  inverse (« Droite » vers la droite en vue de dos, « Gauche » vers la droite
  au n° 2, « Avant » vers la droite au n° 5) ; les cartes disent que c'est la
  même orientation ;
- le titre du cours 2026-27, « vue postérieure de la région scapulaire », pour
  le schéma qui réunit les n° 3 et 4 ;
- « en dedans de la capsule », que l'on aurait lu « médial », et des comptes
  ambigus (les racines du plexus, hors barème ; les deux faisceaux du ligament
  coraco-huméral).

- La liste écrit « Muscle dentelé antérieur » là où le Book écrit « Muscle
  serratus antérieur ou dentelé antérieur » : la phrase du numéro donne les
  deux noms.
- **Le grand dorsal** (n° 7) : la FC n°2 2025-26 (p. 4) lui donne pour
  insertion « l'angle inférieur de la scapula ». Ce n'est qu'une insertion
  inconstante : « parfois », dit le cours 2026-27 (p. 4), « non constante » la
  FC n°4 2024-25 (p. 4). Son origine est l'aponévrose thoraco-lombaire (cours
  2026-27, p. 4 ; « thoraco-dorsale » en 2024-25). `ATTENTION` simple pour la
  fiche 2025-26, et `ATTENTION (prise de notes)` pour le 2e ronéo 2026-27, qui
  l'insère « sur le bord latéral de la scapula » (p. 3) avec le grand rond.
- **Son tendon** (n° 6) : la « partie médiale du sillon intertuberculaire »
  pour le cours 2026-27 (p. 4), « lèvre médiale » pour les cours 2025-26 et
  2024-25, le fond du sillon pour la référence (Gray's, Kamina), dont la formule
  2026-27 est plus proche. `ATTENTION` sans genre (deux années qui diffèrent),
  et l'on répond à l'examen « dans la partie médiale du sillon, en dedans du
  grand pectoral », comme `anat_fc3`.
- La fin de l'artère axillaire : le cours dit « bord inférieur du grand
  pectoral » (la tradition française, redite en 2026-27, p. 9), les traités
  anglo-saxons « bord inférieur du grand rond » ; la phrase donne les deux, la
  carte suit le cours.
- **Deux libertés du dessin**, dites dans les phrases des numéros : l'artère
  axillaire passe devant le petit pectoral pour rester visible (en réalité il
  la croise en avant) ; un pointillé rouge non légendé file jusqu'à la tête
  humérale, qu'il ne faut pas prendre pour la suite de la subclavière.
- Relecture du 07/10 par un sceptique (sources : FC n°2 et n°3 2025-26, Gray's,
  Kenhub) : aucune erreur, sept imprécisions corrigées (paroi postérieure de la
  fosse axillaire avec le subscapulaire, origine du grand pectoral, page de
  l'angle inférieur pour le grand rond, barème « s'il manque le titre ou
  l'orientation »…).

## Le schéma cliquable

| Fichier | Ce qu'on clique | Cartes |
|---|---|---|
| `espaces-axillaires.svg` | l'espace que traverse un pédicule : circonflexe de la scapula (médial), nerf axillaire et circonflexe postérieure (latéral), nerf radial et brachiale profonde (inférieur) | 3 |

L'épaule droite vue de dos, redessinée nue : scapula, humérus, petit rond,
grand rond, chef long et chef latéral du triceps sont nommés, les espaces non ;
on les reconnaît à leurs bords, ce que demande l'annale. Les bords des muscles
sont des droites de `schemas.py`, et les sommets des zones leurs intersections :
le dessin et les zones lisent les mêmes constantes.

## Ce que l'annale a dicté

Une seule annale porte sur ce livret : **2021/2022, session 1** (« Anatomie du
membre INF et SUP », p. 3 ; correction p. 4, en bas). Elle demande d'orienter
l'épaule droite vue de dos, de nommer les dix muscles désignés, de repérer les
trois espaces axillaires et d'y dessiner ce qui les traverse. Cinq cartes :
la planche des dix traits, l'orientation (QRU) et un QRM par espace. Chaque
énoncé cite la consigne entre guillemets, mot pour mot, puis dit ce que la
carte demande. L'autre session du fichier (2022/2023, coupe du genou) est au
membre inférieur.

## Les clés qui ne sont pas reprises telles quelles

**Il n'y a pas de clé de la faculté** : la « correction » imprimée est la
planche des Schémas n°3 p. 2, « correction non officielle ». Toutes les clés
d'annale sont donc déduites du cours (`officielle=False`, et l'explication le
dit).

| Question | Correction imprimée | Retenu | Pourquoi |
|---|---|---|---|
| `ann-ms-2122-orientation` | « Haut », « Gauche ← » | Haut ; **Droite** | la correction est un autre dessin, dont la flèche pointe à gauche ; celle du sujet pointe à droite (épaule droite vue de dos). La même vue du cours 2023-24 (figures p. 2-3) porte « Ht » et « D » au bout d'une flèche vers la droite. `CONFLITS`, lettre B |
| `ann-ms-2122-espace-medial` | « artère thoraco-dorsale » | **artère circonflexe de la scapula** | le vaisseau s'anastomose avec la supra-scapulaire dans la fosse infra-épineuse ; la thoraco-dorsale reste sur la paroi du thorax. Cours 2023-24, p. 4 ; référence : l'artère circonflexe de la scapula traverse le triangular space (TeachMeAnatomy ; Gray's). `CONFLITS`, lettre B |
| `ann-ms-2122-espace-inferieur` | le nerf radial seul | nerf radial **et artère brachiale profonde** | ils passent ensemble (cours 2023-24, p. 4 et 7 ; triangular interval, TeachMeAnatomy). `CONFLITS`, lettre B |
| `ann-ms-2122-muscles` | ne répond pas trait par trait | la lecture ci-dessus | clé déduite du dessin et des insertions du cours ; 10 douteux |

**Les erreurs du Ronéosaure dans les planches** (`ATTENTION` sans genre, dans
la phrase du numéro et dans la légende de la correction) :

| Planche, n° | Le livret | Retenu | Source |
|---|---|---|---|
| p. 2, n°19 | « Artère thoraco-dorsale » | Artère circonflexe de la scapula | trouvé en relisant ; cours 2023-24 p. 4, même professeur : une « circonflexe profonde » dans l'espace médial, « issue de l'anastomose entre l'artère supra-scapulaire et l'artère subscapulaire » ; Gray's, TeachMeAnatomy, Wikipedia « Circumflex scapular artery » et « Triangular space ». La même erreur est dans la figure de la FC n°3 p. 2, qui est le même dessin |
| p. 2, n°2 | « Ligne nuchale » | Ligament nuchal | trouvé en relisant : la ligne nuchale est une crête de l'occipital, hors du dessin ; le trait vise la bande tendue sur les processus épineux cervicaux ; cours 2023-24 p. 2 (« ligament nuchal ») |
| p. 4, n°11 | « Aponévrose thoraco-dorsale » | Tendon du muscle grand dorsal | trouvé en relisant : le vert, au bord médial de l'humérus, est la terminaison du grand dorsal ; l'aponévrose thoraco-dorsale est sa lame d'origine, au dos, des processus épineux de T7 au sacrum et sur la crête iliaque (p. 2 ; FC n°3 p. 3 ; Dictionnaire de l'Académie de médecine, IMAIOS « aponévrose thoracolombaire ») |

Le cours 2026-27 confirme les trois corrections : il met l'« Artère circonflexe
de la scapula » dans l'espace axillaire médial (p. 5 ; « circonflexe profonde de
la scapula » sur sa figure p. 3) et légende « m. grand dorsal » la bande verte du
n°11 de la p. 4, sur le même dessin projeté (p. 9) ; il ne nomme pas le ligament
nuchal.

Dit sans `ATTENTION` : la thoraco-acromiale « collatérale de la subclavière »
de la FC n°3 p. 6 est déjà corrigée dans le PDF (« de l'artère axillaire ») ;
le petit pectoral naît des côtes 3 à 5, près de leurs cartilages (la FC écrit
« cartilages chondro-costaux ») ; trapèze jusqu'à T11 dans le cours, T12 en
référence ; grand dorsal sur la lèvre médiale du sillon dans le cours, au fond
du sillon en référence. L'errata d'anatomie 2024-25 n'a aucune entrée sur les
Schémas n°3.

## Le lexique

Aucun terme : le plan du membre supérieur donne le lexique aux chapitres de la
FC n°3 (syssarcose, acromion, cavité glénoïdale, deltoïde, rhomboïde, coiffe
des rotateurs, col chirurgical, veine céphalique) et de la FC n°4, où les
termes sont définis.

## À relire

1 carte porte `a-relire` : `ann-ms-2122-muscles`, la lecture des dix traits de
l'annale, dont un reste douteux (10, chef long ou chef latéral du triceps) et
six probables (1, 3, 5, 6, 8, 9). Le tag tombera avec un corrigé du
professeur, ou à la relecture du dessin par Vincent : les ronéos 2026-27 ne
reprennent pas ce dessin. Le chapitre a été relu le 11/10/2026 sur les deux
premières ronéos 2026-27 ; il le sera de nouveau à la parution des suivantes.

## Relus sur la ronéo 2026-27

Le 11/10/2026, chaque numéro des quatre planches du membre supérieur et le
schéma à refaire ont été relus contre les deux ronéos 2026-27 du Pr Demondion
(Ronéo & Juliette, cours du 29/09/2026), PDF et figures compris. Dans les
phrases, « cours 2026-27, p. N » renvoie au 1er cours (« TOPOGRAPHIE DU MEMBRE
SUP », 10 p.), « 2e cours 2026-27, p. N » au second (« TOPOGRAPHIE MEMBRE SUP 2 »,
8 p.). Ces PDF sont déclarés par `anat_fc3` et `anat_fc4`, pas ici.

**Les dessins se correspondent** :

| Planche du chapitre | Dans le cours 2026-27 |
|---|---|
| Schémas n°3 p. 2, vue postérieure | le même dessin du professeur, complété p. 3 (fond p. 2), orienté « Haut » et « Droite » vers la droite |
| Schémas n°3 p. 3, dissection antérieure | une version plus simple p. 7 (fond p. 6) : graisse, deltoïde, grand pectoral, veine céphalique, thoraco-acromiale et ses branches deltoïdienne et acromiale |
| Schémas n°3 p. 4, vue profonde | le même dessin, « juste projeté pas dessiné » (p. 9-10) |
| Book 2025-26, schéma n° 1 | un autre dessin de la même région ; le cours 2026-27 dit « vue antérieure de la région axillaire » (2e cours, p. 3) |

**Ce qui a changé** :

- Chaque numéro que le cours 2026-27 traite cite sa page d'abord : 23 sur 25
  à la p. 2, 8 sur 8 à la p. 3, 14 sur 14 à la p. 4, 15 sur 17 au Book ; la
  carte d'orientation, le schéma à refaire, le schéma cliquable et les quatre
  annales aussi.
- Une légende renommée : le n°21 de la p. 2, « Aponévrose thoraco-dorsale »,
  devient **« Aponévrose thoraco-lombaire »**, le nom du cours 2026-27 (p. 4 et
  figure p. 3), qui est aussi celui de la nomenclature internationale.
  `ATTENTION` sans genre : la planche et la FC n°3 2024-25 disaient
  thoraco-dorsale. Les autres légendes, numéros, intrus et images sont
  inchangés.
- Le grand dorsal se termine dans la « partie médiale du sillon
  intertuberculaire » (p. 4) : les phrases des n°23 (p. 2), 11 et 13 (p. 4), 6
  (Book) et l'explication du schéma à refaire le disent, avec la « lèvre
  médiale » des années passées et le fond du sillon de la référence.
- Le deltoïde se termine sur la « tubérosité deltoïdienne », au tiers moyen de
  l'humérus (p. 7) : la phrase du Book n°3 disait « tubercule deltoïdien », le
  mot de la FC n°2 2025-26 (p. 3), pour la même structure ; elle donne les deux.
- Dans les phrases du Book, le cours 2026-27 est cité d'abord, la FC n°2
  2025-26 ensuite (artère subclavière, grand dorsal, petit pectoral, grand
  pectoral, dentelé antérieur, relus une seconde fois le 11/10).
- « Artère humérale » n'est pas un nom ancien : le cours 2026-27 l'emploie
  (2e cours, p. 4 et 7) ; le Book n°17 le dit.
- Le schéma à refaire porte le titre du cours 2026-27 en plus de celui du Book,
  et son explication liste ce que le dessin projeté en 2026-27 montre en plus
  (chef court du biceps, coraco-brachial, veine axillaire, thoraco-acromiale,
  thoracique latérale) et en moins (tronc brachio-céphalique, carotide).
- La carte d'orientation cite les flèches des figures 2026-27 : de dos, « D »
  ou « Droite » vers la droite (p. 2-3) ; de face, « Dte » ou « D » vers la
  gauche (p. 7 ; 2e cours, p. 2), ou « Gauche » vers la droite (p. 9).

**Les erreurs des ronéos 2026-27 portées ici**, à verser dans
`contenu/ERRATA_RONEOS_2026-27.md` avec ces cartes :

| Ronéo, page | Ce qu'il dit | Ce qui est juste | Genre | Carte | D'où |
|---|---|---|---|---|---|
| 1er cours, p. 2 (fond) | « sternum » sur la ligne médiane de la vue postérieure | la colonne vertébrale et ses processus épineux | prise de notes | `ms-s3-qc-orientation` (D) | tableau de la promo |
| 1er cours, p. 6 (fond) | la flèche « sillon delto-pectoral » aboutit sur la ligne médiane, au-dessus de l'ombilic | le sillon est entre deltoïde et grand pectoral, à l'avant de l'épaule (même ronéo, p. 8 et figure p. 7) | prise de notes | `ms-s3-axillaire-dissection` (n°3) | tableau de la promo |
| 1er cours, p. 4 | élévateur sur le « Bord supérieur de la scapula » | angle supéro-médial et bord médial jusqu'à l'épine (figure p. 3 ; FC n°3 2024-25 p. 3) | prise de notes | `ms-s3-scapulaire-post` (n°1) | trouvée en relisant |
| 1er cours, p. 9 (phrase manuscrite) | « a. subclavière → a. axillaire après passage du bord inférieur du m. grand pectoral » | c'est l'axillaire qui devient brachiale à ce bord ; la subclavière devient axillaire sous la clavicule (texte de la même page) | prise de notes | `ms-s3-axillaire-profonde` (n°7), `ms-b1-fosse-axillaire-ant` (n°2) | trouvée en relisant |
| 2e cours, p. 3 | grand dorsal et grand rond insérés « sur le bord latéral de la scapula » | vrai du grand rond seul ; le grand dorsal naît de l'aponévrose thoraco-lombaire (1er cours, p. 4) | prise de notes | `ms-b1-fosse-axillaire-ant` (n°7) | trouvée en relisant |
| 1er cours, p. 4 | rhomboïdes nés de la « Colonne cervicale (à partir de C4 environ pour le petit rhomboïde) » | petit : C7-T1 ; grand : T2-T5 (Kenhub ; Gray's) | douteux | `ms-s3-scapulaire-post` (n°3) | trouvée en relisant |
| 1er cours, p. 4 | aponévrose du grand dorsal « jusqu'à L2 » | limite qu'aucune référence ne donne (T7-T12, fascia thoraco-lombaire, crête iliaque, côtes 9-12) | douteux | `ms-s3-scapulaire-post` (n°21) | trouvée en relisant |
| 1er cours, p. 10 | « l'artère thoracique médiale est plus haute » | aucune artère de ce nom : thoracique supérieure, ou thoracique interne (de la subclavière) ? | douteux | `ms-s3-axillaire-profonde` (n°14) | trouvée en relisant |

Ce sont les erreurs déjà relevées par la relecture de `anat_fc3` : ce chapitre
n'en trouve pas d'autre, et ajoute ses cartes à leur ligne.

**Les deux entrées du tableau de la promo** (11/10) ont été vues sur les
pages du PDF : p. 2, la flèche « sternum » vise bien la ligne verticale graduée
C4 et T2 ; p. 6, la flèche « sillon delto-pectoral » finit bien sur la ligne
médiane, au-dessus de l'ombilic. **Aucune planche du chapitre ne reproduit ces
erreurs** : la p. 3 des Schémas n°3 place le sillon entre deltoïde et grand
pectoral, et aucune vue postérieure ne légende la colonne. Les phrases du n°3
(p. 3) et de la proposition D de l'orientation les signalent pour l'élève qui a
lu la ronéo.

**En attente des ronéos suivantes** (le cours 2026-27 n'en parle pas encore ;
les phrases gardent leurs sources des années passées) :

- p. 2, n°2 ligament nuchal (le cours ne cite que les ligaments supra- et
  inter-épineux) et n°13 muscles paravertébraux ;
- Book, n°8 artère carotide commune et n°9 tronc artériel brachio-céphalique,
  que le dessin projeté en 2026-27 ne montre pas ; le n°4, ligament transverse
  de l'humérus, n'est pas nommé, mais le 2e cours décrit le toit du sillon
  (« des fibres qui émanent de la terminaison du subscapulaire », p. 3) ;
- la planche de l'annale 2021/2022, dessin que le cours 2026-27 ne reprend pas.

## Régénérer

```powershell
cd contenu\chapitres\anat_sch3
..\..\..\app\.venv\Scripts\python.exe generer.py
```

Les PNG des planches ne se refont pas à la génération : ils sortent de
`planche_depuis_pdf.py` (pages 2, 3 et 4 du livret, sans option) et, pour
l'annale, du script du brouillon, dont les bouts de traits sont les repères
de `PLANCHES` dans `donnees.py`.

## Questions pour Vincent

- (11/10) Les planches gardent pour fiche leur livret (Schémas n°3 et n°4 2024-25, Book 2025-26), donc le badge d'une année passée, même si leurs phrases citent d'abord la ronéo 2026-27. Veux-tu qu'elles citent la fiche 2026-27 ? Il faudrait un identifiant de source à part pour chacun des deux PDF, ou un choix commun avec anat_fc3 et anat_fc4.
- (11/10) La légende n° 21 de la vue postérieure devient « Aponévrose thoraco-lombaire », le mot du cours 2026-27, au lieu de « thoraco-dorsale » sur la planche et dans la FC 2024-25. Ça te va, ou préfères-tu garder la légende imprimée, avec seulement l'ATTENTION ?
- (11/10) Les figures 2026-27 dessinées par les rédacteurs (vue postérieure p. 3, vue antérieure p. 7, vue antérieure du bras du 2e cours p. 2) peuvent-elles devenir des planches à légender et des cartes « à refaire sur papier » dans anat_sch3 et anat_sch4 ? Leurs légendes sont manuscrites, il faut poser les rectangles à la main.
- (11/10) Si les CM du 06/10 et suivants ne reprennent ni le ligament nuchal ni la carotide et le tronc brachio-céphalique du Book, faut-il dire ces numéros absents du cours 2026-27 dans leur phrase ? La planche, elle, reste entière.
- (11/10) L'ordre du nerf cutané médial du bras et du nerf ulnaire dans l'aisselle (n° 6-7 du plexus, errata E9 de 2024-25) reste ouvert : le professeur l'a-t-il redit cette année ?
