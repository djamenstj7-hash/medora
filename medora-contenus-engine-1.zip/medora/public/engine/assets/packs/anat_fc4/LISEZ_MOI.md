# Membres supérieurs 2 (FC n°4) — paquet Anatomie

101 notes, 210 cartes. Chapitre `chap-ue-anatomie-fc4` de l'UE Anatomie
(identifiant du squelette), quatrième chapitre de l'UE. Cours du
**Pr Demondion, les 29/09 et 06/10/2026** : le plexus brachial, le bras,
l'avant-bras, le canal carpien et la main, en vue antérieure. Examen : partiel
de novembre, un **schéma** — orienter un fond, nommer les structures fléchées,
dessiner et légender vaisseaux et nerfs.

**La base est le cours 2026-27** : deux ronéos de Ronéo & Juliette en sont les
fiches.

- « TOPOGRAPHIE MEMBRE SUP 2 » (`R2`, 8 p., cours du 29/09/2026, 12 h-13 h,
  livré le 11/10 ; réalignement du 11/10), `SRC["fiche"]`. Sa **partie I**, le
  schéma en vue antérieure des muscles scapulaires et huméraux (figure p. 2,
  muscles p. 3, vaisseaux et nerfs p. 4), sert ici pour le bras ; l'épaule et
  l'aisselle sont au chapitre FC n°3. Sa **partie II**, le schéma en vue
  antérieure des muscles de l'avant-bras (figure p. 5, ostéologie p. 6, muscles
  et tendons p. 6-7, « début de la vascularisation et des nerfs » p. 7), est
  entière à ce chapitre.
- « TOPOGRAHIE MEMBRE SUP 3 » (sic, `R3`, 12 p., cours du 06/10/2026,
  10 h-11 h, livré le 19/10 ; réalignement du 19/10), `fiche=R3` sur les cartes
  relues sur lui, qui citent « 3e cours, p. N » : I. l'avant-bras (figure p. 2,
  muscles p. 2-4, nerfs p. 4-5, vaisseaux p. 6) ; II. le canal carpien (p. 7-9,
  coupe p. 8) ; III. les éminences thénar et hypothénar (figure p. 9, ACABA
  p. 10, COCA p. 10-11, CACO p. 11, nerfs de la main p. 12).

Le Ronéosaure 2024-25 (FC n°4, cours du 29/10/2024, même professeur), qui
faisait la base jusqu'au 11/10, reste la fiche des neuf cartes que les ronéos
2026-27 ne traitent pas encore ; le cours 2023-24 du même professeur (Charonéo,
cours 3 et 4) reste l'appoint. La FC n°3 2025-26 du Ronéosaure (Pr Herteleer,
autre professeur) n'est pas reprise. **Le cours continue** : la loge
postérieure, la main en vue latérale et le deuxième rayon (que le Book Schéma
2025-26 dessine) n'ont pas encore de ronéo (voir « En attente des CM
suivants »).

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| QRM | 45 | 45 |
| QRU | 2 | 2 |
| Texte à trous | 15 | 100 |
| QROC | 11 | 11 |
| Recto-verso | 9 | 9 |
| Schéma cliquable | 3 | 27 |
| Planche à légender | 4 | 4 |
| Lexique | 12 | 12 |
| **Total** | **101** | **210** |

**47 QCM sur 47 illustrés** (100 %) : les cinq figures dessinées des ronéos
2026-27 (2e cours p. 2 et 5 ; 3e cours p. 2, 8 et 9), des figures de la FC n°4
2024-25 et du Charonéo 2023-24, en correction, jamais en question. **27 cartes
portent un piège des ronéos 2026-27** (thème « Pièges des ronéos »). **Aucune
annale** : les deux sujets du membre supérieur sont des schémas à compléter, aux
chapitres de schémas (Schémas n°3 et n°4). **Aucune carte absente du cours
2026-27.** **1 carte `a-relire`**, en attente (voir plus bas).

Neuf thèmes, tous déjà libellés dans `THEME_LABELS`
(`app/src/med_engine/application/scopes.py`) : aucune clé nouvelle. Chaque
carte porte sa couche en thème et sa région en tag.

| Clé | Libellé | Rôle |
|---|---|---|
| `bras` | Bras | région (tag) |
| `avant-bras` | Avant-bras | région (tag) |
| `main` | Main et carpe | région (tag) |
| `osteologie` | Ostéologie | couche, partagée avec la FC n°3 |
| `insertions-musculaires` | Insertions musculaires | couche, partagée avec la FC n°3 |
| `nerfs` | Nerfs : origine, trajet, territoire | couche, partagée avec la FC n°3 |
| `vascularisation` | Vascularisation | couche, partagée avec la FC n°3 |
| `lesions-nerveuses` | Lésions nerveuses et syndromes canalaires | couche, partagée avec la FC n°3 |
| `orientation-schemas` | Titre et orientation des schémas | repris des Schémas n°1 et n°2 et de la FC n°3, pour l'orientation de la figure de l'avant-bras |

Les cartes du plexus ne portent pas de région : il est dans l'aisselle, que la
FC n°3 range sous `region-axillaire`.

## Les sources et leurs années

| Source | Année | Rôle |
|---|---|---|
| `src-fc-anat-fc4-2627` — Ronéo & Juliette, « TOPOGRAPHIE MEMBRE SUP 2 » (8 p.), chemin `ANATOMIE/TOPOGRAPHIE MEMBRE SUP 2.pdf` | **2026-27** | **la base** et la fiche du chapitre (`SRC["fiche"]`, `chapitre=`) : 36 notes de cours et 8 termes de lexique la citent |
| `src-fc-anat-fc4-2425` — Ronéosaure, FC n°4 (12 p.), chemin `Anatomie/FC n°4 - Membres supérieurs 2.pdf` (écrit en NFC ; décomposé sur le disque) | 2024-25 | l'ancienne base ; appoint, et fiche (`fiche=FC4`) des 44 cartes en attente ; plus de `chapitre=` |
| `src-anat-ms-2324-3` — cours 2023-24 n°3 (6 p.) | 2023-24 | appoint : plexus C5-T1, trajets des nerfs, griffe cubitale, main en fléau, Froment, 7/10 · 3/10 · 5/10, syndromes canalaires, position fonctionnelle ; fiche de 2 cartes |
| `src-anat-ms-2324-4` — cours 2023-24 n°4 (13 p.) | 2023-24 | appoint : tableaux d'insertions du bras et de l'avant-bras, artère brachiale profonde, compartiments et tabatière, éminences ; fiche d'1 carte |

**Le même PDF a deux identifiants.** Le chapitre FC n°3 déclare
« TOPOGRAPHIE MEMBRE SUP 2 » sous `src-fc-anat-fc3-2627-2`, rattaché à son
chapitre, pour sa partie I ; ce chapitre le déclare sous
`src-fc-anat-fc4-2627`, rattaché à lui. Avec un seul identifiant et deux
`chapitre=`, le dernier paquet importé enlèverait la fiche à l'autre. Les deux
sources 2023-24 ont le même identifiant, le même titre et le même auteur que
dans le chapitre FC n°3 ; seule la note diffère.

Dans le texte d'une carte relue, « p. N » renvoie au ronéo 2026-27, « 1er
cours, p. N » au premier ronéo du même jour (« TOPOGRAPHIE DU MEMBRE SUP »,
chapitre FC n°3), « Ronéosaure 2024-25 p. N » à l'ancienne base. Dans une carte
en attente, « FC4 p. N » renvoie toujours au Ronéosaure 2024-25.

## Ce que le ronéo 2026-27 a changé

**29 notes relues sur le ronéo 2026-27** : elles portent sa page, citent son
texte, et perdent le badge « Cours 2024-25 ». Les propositions que le ronéo ne
reprend pas encore disent, dans leur justification, d'où elles viennent
(Ronéosaure 2024-25 ou cours 2023-24).

| Page | Partie | Notes relues |
|---|---|---|
| 3 | I.B muscles du bras | `ms4-qc-tuberosites`, `ms4-qc-biceps-chef-long`, `ms4-qc-biceps-terminaison`, `ms4-qc-brachial-coracobrachial`, `ms4-fa-biceps`, `ms4-qr-lacertus`, `ms4-rv-tuberosites` |
| 4 | I.C vaisseaux et nerfs du bras | `ms4-qc-plexus`, `ms4-qc-faisceau-medial`, `ms4-qc-faisceaux-branches`, `ms4-qc-median-bras`, `ms4-qc-musculo-cutane`, `ms4-qc-ulnaire-bras`, `ms4-qc-artere-brachiale`, `ms4-qc-radial-humerus`, `ms4-fa-plexus`, `ms4-fa-musculo-cutane`, `ms4-fa-artere-brachiale`, `ms4-zo-coude` |
| 6 | II.A-B ostéologie, muscles | `ms4-qc-humerus-distal`, `ms4-qc-brachio-radial`, `ms4-qc-rond-pronateur`, `ms4-qc-os-carpe`, `ms4-fa-retinaculum`, `ms4-rv-capitulum-trochlee`, `ms4-rv-supinateur` |
| 7 | II.B-C tendons, début des nerfs | `ms4-qc-radial-branches`, `ms4-qc-canal-carpien`, `ms4-fa-radial-branches` |

Ce qui a changé dans leur contenu :

- **Le nerf médian croise l'artère « en forme de S italique »** (p. 4), et non
  plus « en S allongé » : la proposition B de `ms4-qc-median-bras` prend les mots de
  2026-27, la justification garde ceux de 2024-25. Sa clé ne change pas.
- **Le biceps « supinateur accessoire »** est redit en 2026-27 (p. 3) : le
  point douteux de 2024-25 devient un `ATTENTION (cours)` sur
  `ms4-qc-biceps-terminaison` (E), avec ce qu'on répond à l'examen et la
  référence.
- **Le supinateur** a deux faisceaux « un latéral et un médial » (p. 6) :
  `ms4-rv-supinateur` dit désormais « superficiel et profond » au verso, avec un
  `ATTENTION (douteux)`.
- **La branche superficielle du radial « à proximité de l'artère brachiale
  profonde »** (p. 4) : `ATTENTION (douteux)` sur `ms4-qc-brachio-radial` (D).
- **Le chef long du biceps** : le ronéo écrit « labrum supraglénoïdal » et
  ajoute les arrachements du labrum dans les sports de lancer (p. 3) ;
  `ms4-qc-biceps-chef-long` (A) le cite, en donnant le nom anatomique, labrum
  glénoïdal.
- **La branche profonde du radial** « innerve tous les muscles de l'avant-bras
  à la face postérieure » (p. 7) : `ms4-qc-radial-branches` (B) le cite et
  précise que le brachio-radial et le long extenseur radial du carpe, de la loge
  latérale, sont innervés avant la division.
- **L'artère brachiale** s'appelle aussi « artère humérale » (p. 4, p. 7), et
  se divise « au niveau de l'avant-bras », la radiale en dehors, l'ulnaire en
  dedans (p. 7) ; `ms4-qc-artere-brachiale` et `ms4-fa-artere-brachiale` le
  citent. Le passage de l'axillaire à la brachiale reste au bord inférieur du
  grand pectoral (1er cours, p. 9).
- Les figures 2026-27 remplacent celles de 2024-25 en correction partout où
  elles montrent ce que la carte demande ; les figures 2024-25 et 2023-24
  restent là où la figure 2026-27 ne montre rien (os du coude, ligament
  transverse, vue latérale du radial, plexus détaillé).

**9 notes nouvelles**, pour ce que le ronéo 2026-27 enseigne et qu'aucune
carte ne couvrait :

| Note | Ce qu'elle apprend | Page |
|---|---|---|
| `ms4-qc-orientation-avant-bras` | titre et orientation du schéma de l'avant-bras : « Ht », « Dt » vers la gauche, radius à gauche | 5 |
| `ms4-pl-avant-bras-2627` | **planche à légender** du schéma de l'avant-bras, 26 numéros, 8 intrus | 5 |
| `ms4-qc-os-avant-bras` | radius et ulna, bec coronoïdien, olécrane, membrane interosseuse (et l'erreur de la p. 6) | 6 |
| `ms4-qc-flechisseurs-doigts` | insertions des fléchisseurs superficiel, profond, long du pouce ; couches du canal carpien | 6-7 |
| `ms4-qc-pronation-supination` | carré pronateur, supinateur, rond pronateur et leurs interstices | 6-7 |
| `ms4-fa-canal-carpien-couches` | les neuf tendons du canal carpien, leurs couches, le canal inextensible | 7 |
| `ms4-qr-nerf-extension` | le radial, « nerf de l'extension » | 4 |
| `lex-supinateur` | terme du lexique | 3, 4, 6, 7 |
| `lex-olecrane` | terme du lexique | 6 |

Contrôles : aucune note supprimée, aucun identifiant ni type changé, aucune clé
de QCM changée, les numéros des trous des textes à trous conservés (comparé au
paquet de HEAD).

**Relu une seconde fois le 11/10**, carte par carte, sur les pages du ronéo et
ses figures : aucune clé ni aucun genre d'erreur ne change. Corrigés : la
citation de la p. 6 dans la note de la source (« contenant une membrane
interosseuse », et non « contenue ») ; « en forme de S italique », mot pour mot
(`ms4-qc-median-bras`, B) ; la référence du biceps, coude tendu, où la
supination lente revient « surtout » au supinateur (`ms4-qc-biceps-terminaison`,
E) ; la loge latérale, qui compte quatre muscles (`ms4-qc-radial-branches`, B) ;
la place de la zone capitulo-trochléaire, entre capitulum et trochlée
(`ms4-qc-humerus-distal`, C ; `ms4-rv-capitulum-trochlee`) ; une citation de la
FC4 p. 6 (`ms4-qc-aisselle`, E) ; les pages des deux termes nouveaux du lexique
(FC4 p. 4 et cours 2023-24 n°3 p. 5 pour le supinateur, cours 2023-24 n°4
p. 2-3 pour l'olécrane).

## Les erreurs du ronéo 2026-27

Portées dans les cartes avec leur genre (`.claude/rules/cartes.md`), à verser
dans `contenu/ERRATA_RONEOS_2026-27.md`. Chaque preuve est citée dans la carte.

| Page | Ce que dit le ronéo | Ce qui est juste, et la preuve | Genre | Carte |
|---|---|---|---|---|
| p. 6 | « Ces os sont unis par l'articulation du coude, contenant une membrane interosseuse » | la membrane interosseuse unit les corps du radius et de l'ulna, hors du coude : une syndesmose ; le même ronéo y insère les fléchisseurs profond des doigts et long du pouce (p. 6-7) — Gray's ; Wikipedia, « Interosseous membrane of forearm » | prise de notes | `ms4-qc-os-avant-bras` (D) |
| p. 3 | le biceps brachial, « muscle supinateur accessoire » | déjà en 2024-25 (p. 4) : c'est le cours. À l'examen, « supinateur accessoire » ; la référence en fait un supinateur puissant, le plus puissant coude fléchi — Gray's ; Moore ; Kenhub, « Biceps brachii » | cours | `ms4-qc-biceps-terminaison` (E) |
| p. 4 | la branche superficielle du radial, « à proximité de l'artère brachiale profonde » | à l'avant-bras, sous le brachio-radial, elle longe l'artère radiale ; la brachiale profonde suit le nerf au bras — Gray's ; Radiopaedia | douteux | `ms4-qc-brachio-radial` (D) |
| p. 6 | le supinateur, « 2 faisceaux : un latéral et un médial » | un faisceau superficiel et un profond (Kenhub, « Supinator muscle » ; Gray's ; cours 2023-24, « faisceau profond ») ; sur la figure p. 5, les deux bandes sont côte à côte | douteux | `ms4-rv-supinateur` |

Le **tableau des erreurs de la promo** (11/10) a deux entrées, toutes deux sur
le 1er cours du 29/09 : la légende « sternum » de la figure p. 2, qui désigne
la colonne vertébrale, et la flèche « sillon delto-pectoral » de la figure
p. 6, qui pointe la ligne médiane. Vérifiées sur les pages du PDF. Aucune carte
de ce chapitre n'emploie ces figures ni ces points : elles sont au chapitre FC
n°3.

**Vus et laissés sans ATTENTION**, parce qu'ils ne changent aucune réponse :

- la branche profonde du radial qui innerve « tous les muscles de l'avant-bras
  à la face postérieure » (p. 7) : vrai de la loge postérieure au sens français.
  De la loge latérale (quatre muscles), le brachio-radial et le long extenseur
  radial du carpe sont innervés avant la division, le supinateur et le court
  extenseur radial du carpe par la branche profonde ; la précision est dans
  `ms4-qc-radial-branches` (B) ;
- le « labrum supraglénoïdal » (p. 3) : la partie supérieure du labrum
  glénoïdal ;
- l'artère axillaire devenue brachiale « lorsqu'elle chemine dans le sillon
  bicipital médial » (p. 4) : le 1er cours, p. 9, donne le bord inférieur du
  grand pectoral, que les cartes gardent ;
- « le carpe constitue l'articulation du poignet » (p. 6) : le carpe est le
  squelette du poignet ;
- « nerf extenseur des doigts du poignet » (p. 7) : des doigts et du poignet ;
- **la figure p. 5 n'a pas de légende pour le fléchisseur profond des doigts** :
  son trait est resté sans texte. La planche le numérote (n° 12) et sa note le
  dit.

## Absent du cours 2026-27

Aucune carte (`ABSENTS_2026 = []`). Ce que les trois ronéos des 29/09 et
06/10 ne traitent pas n'est pas absent : le cours continue. Les cartes relues
sur le 3e cours ne perdent aucune notion : ce que l'année ne dit pas reste dans
la justification de la proposition, avec son année.

## En attente des CM suivants

**9 notes** que les trois ronéos 2026-27 ne traitent pas. Elles gardent leur
page de la FC n°4 2024-25 (`fiche=FC4`, badge « Cours 2024-25 ») ou du cours
2023-24 (`fiche=C3`), et se reliront à la parution des ronéos des CM suivants
(la loge postérieure et la main en vue latérale restent à faire, d'après le
Book Schéma 2025-26 et la FC n°3 2025-26).

| Sujet | Notes |
|---|---|
| aisselle (place de l'ulnaire et du cutané médial du bras), consignes de dessin de 2024-25 ; le canal brachial et le « nerf de la flexion », que les ronéos 2026-27 ne redisent pas sans rien mettre à leur place (le 3e cours, p. 5, met le médian et l'artère brachiale dans le sillon bicipital médial) | `ms4-qc-aisselle`, `ms4-qc-examen-schema`, `ms4-rv-dessin-nerfs`, `ms4-qr-nerf-flexion`, `ms4-qr-canal-brachial` |
| signes des lésions nerveuses (griffe cubitale, Froment, main en fléau), du cours 2023-24 | `ms4-qc-signes-lesions` |
| compartiments dorsaux du poignet, De Quervain, syndrome du croisement : le 3e cours ne nomme que le long abducteur et le long extenseur du pouce (p. 10) | `ms4-qc-colonne-pouce`, `ms4-qr-de-quervain`, `ms4-fa-compartiments` |

**Relues sur le 3e cours le 19/10 : 38 notes**, qui passent de `fiche=FC4`
(ou `C3`, `C4`) à `fiche=R3` : `ms4-qc-wartenberg`, `-epicondyliens`,
`-flechisseurs-carpe`, `-artere-radiale`, `-artere-ulnaire`,
`-median-avant-bras`, `-syndrome-canal-carpien`, `-ulnaire-avant-bras`,
`-guyon`, `-pisiforme`, `-acaba`, `-thenar-coca`, `-thenar-innervation`,
`-opposant-abducteur`, `-court-flechisseur-pouce`, `-adducteur`,
`-hypothenar`, `-ulnaire-main`, `-paresthesies`, `-syndromes-canalaires` ;
`ms4-qr-guyon`, `-frohse`, `-wartenberg`, `-ancien-nom-retinaculum`,
`-tabatiere` ; `ms4-rv-carpien-guyon`, `-branches-radial`,
`-abducteur-adducteur`, `-sesamoides` ; `ms4-fa-epicondyliens`,
`-median-trajet`, `-ulnaire-trajet`, `-arteres-avant-bras`, `-acaba`,
`-thenar`, `-hypothenar` ; `ms4-zo-poignet`, `-territoires`. Une proposition
que le 3e cours ne dit pas garde sa source d'une autre année, et sa
justification le dit (« le cours 2026-27 ne le nomme pas », « absent des cours
2024-25 et 2026-27 ») : le tronc commun des interosseuses, le long palmaire
inconstant, les causes du canal carpien, les 7/10 et 3/10 de la sensibilité,
la compression au canal de Guyon, les limites de la tabatière, la terminaison
de l'adducteur sur le sésamoïde médial.

## Ce que le 3e ronéo 2026-27 a changé (19/10)

- **La loge hypothénar compte quatre muscles**, CACO : court palmaire (muscle
  peaucier), abducteur, court fléchisseur, opposant du V (p. 11). La FC4
  2024-25 en comptait trois. `ms4-qc-hypothenar` A est réécrite (« le cours
  range dans la loge hypothénar le court palmaire, avec les trois muscles du
  petit doigt ») et `ms4-fa-hypothenar` aussi (le premier trou devient
  « palmaire », sans changer le nombre de trous). `ATTENTION` sans genre : ce
  n'est pas une erreur, la référence décrit trois muscles du petit doigt et le
  court palmaire sous la peau de l'éminence.
- **La gouttière du pouls entre au cours** (p. 6) : elle était « hors
  programme » en 2024-25 (FC4 p. 12). Nouvelle QROC `ms4-qr-gouttiere-pouls`.
- **L'adducteur du pouce n'est plus à relire** : « capitatum et le 3e rayon et
  le 2e » (p. 11), ce que dit la référence pour le faisceau oblique.
- **Les épicondyliens médiaux sont au cours** : le texte les nomme (p. 3, 4 et
  7) et la figure d'atlas p. 7 les montre dans l'ordre de `ms4-qc-epicondyliens`.
  Cette figure (une planche d'atlas légendée en anglais, comme sa voisine) ne
  part pas avec le chapitre.
- **Six notes nouvelles** : trois planches (ci-dessous), la QRM
  `ms4-qc-gaines-canal-carpien` (gaine commune, gaine propre du long fléchisseur
  du pouce, dédoublement pour le fléchisseur radial du carpe, médian en avant du
  tendon superficiel de l'index, toit du canal de Guyon), la QROC de la
  gouttière du pouls et, à la contre-relecture, le recto-verso
  `ms4-rv-membre-droit` (« les anglo-saxons dessinent les membres gauches, nous
  les français les membres droits en priorité », p. 6, que nulle carte ne
  portait).
- Les illustrations des cartes relues passent, quand elle montre la réponse, à
  la figure 2026-27 : la coupe p. 8 (canal carpien, Guyon, zones du poignet), la
  main p. 9 (thénar, hypothénar), l'avant-bras p. 2 (artères, Wartenberg,
  épicondyliens).
- **Contre-relecture (19/10)** : `ms4-qc-radial-branches` C et D, qui disaient
  l'arcade de Frohse « pas encore » au cours 2026-27, citent le 3e cours (p. 3-5) ;
  `ms4-fa-radial-branches` cite le 3e cours et porte l'ATTENTION « Wartelberg » ;
  l'ATTENTION (cours) du biceps « supinateur accessoire » note que le 3e cours le
  redit (p. 2) ; trois cartes citant p. 3-4 passent dans la section I.A ; neuf
  termes du lexique reçoivent leurs pages du 3e cours ; sur la planche de la
  main, le n° 3 est remonté au-dessus du nerf ulnaire, le n° 6 posé dans le
  rétinaculum et le trait courbe du court abducteur numéroté (n° 15).

## Les erreurs du 3e ronéo 2026-27

Aucune n'est encore dans `contenu/ERRATA_RONEOS_2026-27.md` au 19/10 ; elles y
seront versées depuis le rapport.

| Page | Ce qu'il dit | Ce qui est juste | Genre | Carte | D'où |
|---|---|---|---|---|---|
| 9 (figure) | le rétinaculum des fléchisseurs tendu jusqu'au triquetrum | il s'insère sur le pisiforme, juste sous le tendon du fléchisseur ulnaire du carpe (même ronéo p. 4 ; FC4 p. 7) | prise de notes | `ms4-pl-main-2627`, `ms4-fa-retinaculum` | tableau de la promo |
| 9 (figure) | « m. adducteur du petit doigt » | l'abducteur du petit doigt (même ronéo p. 11 ; Gray's) | prise de notes | `ms4-pl-main-2627` | tableau de la promo |
| 9 (figure) | les flèches du médian vont à l'adducteur du pouce et au court fléchisseur entier | l'adducteur et le faisceau profond du court fléchisseur sont à l'ulnaire (même ronéo p. 5 et 12) | prise de notes | `ms4-qc-thenar-innervation`, `ms4-pl-main-2627` | tableau de la promo |
| 6 | l'artère radiale passe « derrière l'os pisiforme » | derrière le scaphoïde, au fond de la tabatière (FC4 p. 9 ; Gray's) | prise de notes | `ms4-qc-artere-radiale` | trouvée en relisant |
| 5 | « syndrome de Wartelberg » | syndrome de Wartenberg (FC4 p. 10 ; StatPearls) | prise de notes | `ms4-qr-wartenberg`, `ms4-qc-wartenberg`, `ms4-fa-radial-branches` | trouvée en relisant |
| 9 | les rangées du carpe « de médial à latéral » : scaphoïde… pisiforme | de latéral à médial (sa propre coupe p. 8 ; Gray's) | prise de notes | `ms4-qc-os-carpe` | trouvée en relisant |
| 10 | l'opposant du pouce « s'insère sur le bord médial du métacarpien » | le bord latéral de M1 (FC4 p. 11 ; cours 2023-24 ; Gray's) | prise de notes | `ms4-qc-opposant-abducteur` | trouvée en relisant |
| 10 | l'opposant du pouce sur « le trapèze et le trapézoïde » | le tubercule du trapèze et le rétinaculum (Gray's) ; la FC4 2024-25 disait déjà trapézoïde | cours | `ms4-qc-opposant-abducteur` | trouvée en relisant |
| 11 | l'abducteur du V inséré « sur le triquetrum » | pisiforme et tendon du fléchisseur ulnaire du carpe (FC4 p. 12 ; Gray's) | prise de notes | `ms4-qc-hypothenar` | trouvée en relisant |
| 11 | le court fléchisseur du V « en terminaison sur la phalange intermédiaire » | base de la phalange proximale (FC4 p. 12 ; Gray's) | prise de notes | `ms4-qc-hypothenar` | trouvée en relisant |
| 11 | l'opposant du V « sur le bord latéral du métacarpien » | le bord médial de M5 (FC4 p. 12 ; Gray's) | prise de notes | `ms4-qc-hypothenar` | trouvée en relisant |
| 12 | adducteur et faisceau profond du court fléchisseur « de la loge hypothénar » | loge thénar (même ronéo p. 10) | prise de notes | `ms4-qc-ulnaire-main` | trouvée en relisant |
| 2 (figure) | « a. ulnaire du carpe » | l'artère ulnaire (texte p. 6) | prise de notes | `ms4-pl-avant-bras-ms3` | trouvée en relisant |
| 4 | le rameau profond du radial « branche sensitive et motrice » | moteur ; ses seules fibres sensitives sont articulaires (FC4 p. 10 ; Gray's) | douteux | `ms4-rv-branches-radial` | trouvée en relisant |
| 7 (figure) | « vue antérieure des os du carpe de la main gauche », scaphoïde à gauche | c'est la disposition d'une main droite en vue antérieure | douteux | `ms4-qc-os-carpe` | trouvée en relisant |

Vus et laissés sans ATTENTION, parce qu'ils ne changent aucune réponse : la
branche « superficielle du rameau superficiel » du radial (p. 3) ; l'artère
ulnaire qui donne « son rameau superficiel profond » (p. 6, dit en précision) ;
« le 3e s'articule avec le capitatum et la tête (pas base) de la phalange »
(p. 10) ; le superficiel du court fléchisseur du pouce terminé « sur le premier
rayon » (p. 10) ; « fleshisseurs » sur la figure p. 8.

## Les planches à légender

Quatre planches, faites des figures des ronéos 2026-27, qui sont des images :
leurs légendes sont effacées par des rectangles posés à la main (`efface`, dans
`donnees.py`), et `.claude/skills/nouveau-chapitre/scripts/planche_depuis_image.py`
en tire l'image numérotée. Une phrase par numéro, des intrus de la même région,
aucun synonyme d'une légende. Chaque image numérotée a été regardée : aucun
reste de lettre, aucun trait mordu qui gêne la lecture.

| Planche | Figure | Numéros | Intrus |
|---|---|---|---|
| `ms4-pl-avant-bras-2627` | 2e cours p. 5, avant-bras (le n° 12, fléchisseur profond, n'a pas de légende sur la figure) | 26 | 8 |
| `ms4-pl-avant-bras-ms3` | 3e cours p. 2, avant-bras droit avec artères et nerfs ; « a. ulnaire du carpe » corrigé en artère ulnaire (n° 11) | 19 | 7 |
| `ms4-pl-canal-carpien-2627` | 3e cours p. 8, coupe du canal carpien | 14 | 7 |
| `ms4-pl-main-2627` | 3e cours p. 9, face palmaire de la main ; les trois erreurs du tableau de la promo dites aux n° 2, 6, 10 et 12, et l'« adducteur du petit doigt » laissé en intrus ; le n° 15 est le second trait de la légende du court abducteur (sa terminaison), et le n° 6, légende sans trait, est posé dans le rectangle vert du rétinaculum | 15 | 7 |

Pour en refaire une : `uv run --with pillow python
../.claude/skills/nouveau-chapitre/scripts/planche_depuis_image.py
../contenu/chapitres/anat_fc4 <identifiant> --apercus <brouillon>`, depuis
`app/`.

## Ce que le cours a dicté

L'examen est un **schéma** : le professeur donne un fond de schéma à compléter
(FC4 p. 2) ; « il ne demandera jamais de dessiner tout le schéma », mais peut
donner les muscles et faire dessiner vaisseaux et nerfs (FC4 p. 5) ; et
« déjà tombé en examen : savoir replacer le trajet des nerfs sur le schéma »
(ronéo 2026-27 p. 4). Les cartes apprennent donc **où passe quoi**, **qui est
latéral ou médial, superficiel ou profond**, **qui innerve quoi**, **où
s'insère quoi**, l'orientation de la figure, et les consignes de dessin : la
petite boule pour une terminaison cutanée (FC4 p. 7), le musculo-cutané en
pointillé dans le coraco-brachial (errata 2024-25). Orienter les autres
schémas se travaille dans les chapitres des Schémas n°3 et n°4 et dans la FC
n°3.

Le rouge des ronéos est leur code couleur (artères en rouge), pas une
consigne ; il n'y a pas de gris. **Hors programme, aucune carte** : la
gouttière du pouls (FC4 p. 12, « pas au programme ») et le « dessin annexe,
inutile de l'apprendre » (FC4 p. 7).

**Frontières avec la FC n°3** (plan de répartition) : le deltoïde, le
subscapulaire, les lèvres du sillon intertuberculaire (grand pectoral, grand
dorsal, grand rond), l'humérus proximal, le nerf axillaire (sauf comme branche
du faisceau postérieur), les espaces axillaires, la pince costo-claviculaire et
les insertions sur le processus coracoïde sont cartés à la FC n°3. De la partie
I du ronéo 2026-27, la FC n°3 a pris l'épaule et l'aisselle
(`ms3-qc-subscapulaire`, `ms3-qc-vue-anterieure-bras`,
`ms3-qc-nerfs-vue-anterieure`), ce chapitre le bras ; aucune carte n'est
doublée.

## Les erreurs du Ronéosaure, et ce que les cartes en font

Le Ronéosaure n'est pas la ronéo de l'année : ses erreurs sont signalées par un
**ATTENTION nu**, « de cette année-là », sans le genre que
`.claude/rules/cartes.md` réserve aux ronéos 2026-27. Aucune n'entre dans
`contenu/ERRATA_RONEOS_2026-27.md`. Le ronéo 2026-27 corrige lui-même trois
d'entre elles (les tubérosités, la division de l'artère, la place du radial
derrière l'humérus) ; le point douteux du biceps « supinateur accessoire » est
devenu une erreur du cours, puisque le ronéo 2026-27 la redit.

| Page | Ce que dit le ronéo | Retenu, et la preuve | Sorte | Carte |
|---|---|---|---|---|
| p. 3 | chef long du biceps sur « le labrum sphénoïdale » | labrum glénoïdal (ronéo 2026-27 p. 3) | prise de notes | `ms4-qc-biceps-chef-long` (A), `ms4-fa-biceps` |
| p. 4 | « Tubérosité brachiale (anciennement bicipitale) : terminaison du muscle brachial » | deux tubérosités : bicipitale sur le radius (biceps), brachiale sur l'ulna (brachial) — ronéo 2026-27 p. 3 | prise de notes | `ms4-qc-tuberosites` (D), `ms4-rv-tuberosites` |
| p. 4 | le biceps « supinateur accessoire » | redit en 2026-27 : voir les erreurs du ronéo 2026-27 | cours | `ms4-qc-biceps-terminaison` (E) |
| p. 6 | « L'artère axillaire se divise ensuite en artère ulnaire et en artère radiale » | l'artère brachiale (même page ; ronéo 2026-27 p. 7) | prise de notes | `ms4-qc-artere-brachiale` (D), `ms4-fa-artere-brachiale` |
| p. 7 | le nerf ulnaire « au départ en avant de la veine » | entre l'artère et la veine, en arrière (cours 2023-24 cours 4 p. 7 ; Gray's) | douteux | `ms4-qc-aisselle` (B), `a-relire` |
| p. 7 | rond pronateur : « une insertion sur l'ulna et une petite sur l'épicondyle » | chef huméral le plus gros (cours 2023-24 cours 4 p. 11 ; Gray's) | prise de notes | `ms4-qc-rond-pronateur` (B) |
| p. 9 | médian : « motricité de l'éminence thénar sauf l'abducteur du pouce » | sauf l'ADDUCTEUR ; la p. 11 du même ronéo est juste | prise de notes | `ms4-qc-thenar-innervation` (D), `ms4-rv-abducteur-adducteur` |
| p. 9 | canal carpien : « hypoesthésie de cette éminence thénar » | peau thénarienne épargnée (StatPearls) | douteux | `ms4-qc-syndrome-canal-carpien` (E) |
| p. 9 | « une position médiale, on l'appelle le nerf médian » | médian = « du milieu » | douteux | `ms4-qc-median-avant-bras` (E) |
| p. 10 | pisiforme : « bosse à la partie latérale du carpe » | partie MÉDIALE (figures p. 7 et 11 ; ronéo 2026-27 figure p. 5) | prise de notes | `ms4-qc-pisiforme` (B) |
| p. 10 | canal de Guyon « accompagné de l'artère du muscle fléchisseur ulnaire du carpe » | l'artère ulnaire (p. 9) | prise de notes | `ms4-qc-guyon` (D) |
| p. 11 | opposant du pouce : « insertion essentielle sur le trapézoïde » | trapèze et rétinaculum (cours 2023-24 ; TeachMeAnatomy) | prise de notes | `ms4-qc-opposant-abducteur` (A) |
| p. 11 | court fléchisseur du pouce : « se termine sur le métacarpien du pouce » | base de la phalange proximale (cours 2023-24 ; Kenhub) | prise de notes | `ms4-qc-court-flechisseur-pouce` (C) |
| p. 11 | adducteur : « se termine sur l'os sésamoïde latéral » | sésamoïde MÉDIAL et base de P1 (cours 2023-24 ; Kenhub) | prise de notes | `ms4-qc-adducteur` (B), `ms4-rv-sesamoides` |
| p. 11 | adducteur : faisceaux mêlés | oblique : capitatum, bases de M2-M3 ; transverse : M3 (Gray's) | douteux | `ms4-qc-adducteur` (C), `a-relire` |
| p. 11 | « passe latéralement à l'os piriforme » | pisiforme | prise de notes | `ms4-qc-pisiforme` (E), `ms4-qc-guyon` (B) |
| p. 2 (figure) | le nerf radial dessiné en avant de l'humérus | en arrière (FC4 p. 2 et 7 ; ronéo 2026-27 p. 4) — errata 2024-25 | dessin | `ms4-qc-radial-humerus` (D), légende de la figure |
| p. 2 (figure) | flèches du nerf ulnaire et du cutané médial du bras | peut-être inversées : point douteux (errata 2024-25) | dessin | légende de la figure, sur `ms4-qc-aisselle` |
| p. 6 (figure) | le musculo-cutané dessiné devant le coraco-brachial | il le traverse ; le professeur le dessine en pointillé — errata 2024-25 | dessin | `ms4-qc-musculo-cutane` (explication), `ms4-qc-examen-schema` (C) |
| p. 9 (figure) | l'artère ulnaire devant le rond pronateur, le fléchisseur radial et le long palmaire | en profondeur d'eux (Gray's) — errata 2024-25 | dessin | `ms4-qc-artere-ulnaire` (D), légende |
| p. 9 (figure) | le nerf médian dessiné en avant du rond pronateur | entre ses deux chefs (FC4 p. 8-9 ; ronéo 2026-27 p. 7) | dessin | `ms4-qc-median-avant-bras` (explication), légende |
| p. 9 (figure) | la branche superficielle du radial devant le brachio-radial | sous sa face profonde (FC4 p. 10) — errata 2024-25 | dessin | `ms4-qc-wartenberg` (explication), légende |
| cours 2023-24 n°4 p. 13 | l'éminence hypothénar « composée de 4 muscles », avec le fléchisseur ulnaire du carpe | trois muscles (FC4 p. 12) | autre année | `ms4-qc-hypothenar` (E) |

Dites sans ATTENTION, parce qu'elles ne changent aucune réponse : « canal de
Cruvelier » (Cruveilhier), « arcade de FROSE » (Frohse), « stenar », « imminor
stenar », « rameau tenarien » (thénar), « long et court extenseur du carpe »
(extenseurs RADIAUX), « Lapersus fibrosus » sur la planche p. 5 (lacertus), et
« Césure scapulaire » p. 3 (incisure). Deux erreurs du cours 2023-24 ne sont
pas reprises du tout : l'ulnaire « provient du faisceau latéral » (cours 4
p. 10, contredit p. 11) et la branche profonde de l'ulnaire pour « l'éminence
thénar » (cours 3 p. 3, contredit p. 6).

À dire sans genre : « l'artère axillaire devient brachiale au bord inférieur du
grand pectoral » est la tradition française, que les cartes suivent ; la
nomenclature internationale met la limite au bord inférieur du grand rond
(`ms4-qc-artere-brachiale`, A).

## Les clés qui ne sont pas reprises telles quelles

Aucune annale dans ce chapitre, donc aucune clé imprimée. Un erratum de la promo
2024-25 n'est **pas repris** :

| Erratum | Ce qu'il propose | Retenu | Pourquoi |
|---|---|---|---|
| E7, planche des muscles du carpe | « le nerf médian innerve […] le faisceau profond du muscle court fléchisseur du pouce (sur le dessin c'est le faisceau superficiel) » | le médian innerve le faisceau SUPERFICIEL, l'ulnaire le profond | le texte du cours (FC4 p. 11) et la référence (Kenhub, TeachMeAnatomy) ; le dessin est juste. `ms4-qc-thenar-innervation` (E) le dit |

Les huit autres entrées de l'errata du membre supérieur sont reprises : E1 (à la
FC n°3), E2 à E5 et E8 (tableau ci-dessus), E6 comme précision (les deux
faisceaux du court fléchisseur, `ms4-qc-court-flechisseur-pouce`, A), E9 en
point douteux.

## Les schémas cliquables

Redessinés dans `schemas.py`, sans aucune légende : seuls les repères
« Avant » et « Latéral » et le nom des faces. Le dessin et les zones lisent les
mêmes constantes, dans un plan de travail agrandi d'un facteur commun pour que
les légendes de la correction, écrites à taille fixe, ne se chevauchent pas.
Les phrases des zones citent la FC n°4 2024-25 (« FC4 ») ; elles restent justes
en 2026-27.

| Fichier | Ce qu'on clique | Cartes |
|---|---|---|
| `coupe-poignet.svg` | coupe du poignet droit : nerf médian, tendons des fléchisseurs des doigts, long fléchisseur du pouce, fléchisseur radial du carpe (loge propre), long palmaire (superficiel), rétinaculum, nerf et artère ulnaires (canal de Guyon), pisiforme, hamulus, fléchisseur ulnaire du carpe, artère radiale (tabatière) | 12 |
| `territoires-main.svg` | main droite, faces palmaire et dorsale : médian et ulnaire palmaires ; radial, ulnaire et médian dorsaux | 5 |
| `coupe-coude.svg` | coupe du pli du coude droit : brachio-radial, nerf radial, brachial, tendon du biceps, lacertus fibrosus, artère brachiale, nerf médian, rond pronateur, épicondyle médial, nerf ulnaire — relue sur le ronéo 2026-27 (p. 3-4) | 10 |

Deux choix à connaître :

- sur la coupe du poignet, le pisiforme et l'hamulus sont réunis, alors que
  l'hamulus est un peu plus distal ; la note de l'hamulus le dit ;
- au dos de la main, la bande grisée (première phalange du médius, moitié
  médiale, et de l'annulaire, moitié latérale) n'est pas une zone : son partage
  entre radial et ulnaire varie selon les sujets et les auteurs, et le cours
  2023-24 (5/10 latéraux au radial, 5/10 médiaux à l'ulnaire) ne tranche pas pour
  la référence. Le territoire dorsal du médian (phalanges moyenne et distale des
  doigts du milieu) vient de la référence, pas du cours, et sa note le dit.

## Le lexique

Douze termes, pages mesurées dans le texte du ronéo 2026-27, de la FC n°4
2024-25 et des cours 2023-24, avec leur origine grecque ou latine. Les pages du
ronéo 2026-27 viennent en premier : c'est elles que cite la provenance du terme.
Les étymologies des deux termes nouveaux sont proposées pour `etymologies.json`
dans `scratchpad/etym/anat_fc4.json`, et déjà écrites dans les définitions et
les racines, mot pour mot comme `appliquer_etymologies.py` les écrirait.

| Terme | Pages 2026-27 | Pages FC4 2024-25 | Note |
|---|---|---|---|
| Plexus brachial | 3, 4 ; 3e cours 5 | 2, 6, 7 | la FC n°3 l'emploie aussi |
| Processus coracoïde | 3 | 3, 4, 5 | FC n°3 |
| Lacertus fibrosus | 3 ; 3e cours 6 | 4, 7 | la planche 2024-25 écrit « Lapersus » |
| Éminence thénar | 3e cours 1, 3, 5, 9 | 1, 9, 10, 11 | provenance : le 3e cours ; le Ronéosaure écrit « stenar » |
| Éminence hypothénar | 3e cours 1, 5, 9, 12 | 1, 12 | provenance : le 3e cours |
| Os pisiforme | 6 ; 3e cours 4, 5, 6, 9, 11, 12 | 7, 8, 10, 11, 12 | |
| Hamulus (de l'hamatum) | 6 ; 3e cours 4, 9, 11, 12 | 7, 11, 12 | |
| Abaxial | — | 11, 12 | en attente |
| Syndrome canalaire | 3e cours 3, 4 | 8, 10 | provenance : le 3e cours |
| Pronateur (rond pronateur) | 6, 7 ; 3e cours 3, 5, 6, 7 | 7, 8, 9 | la définition nomme désormais le carré pronateur |
| **Supinateur (muscle supinateur)** | 3, 4, 6, 7 ; 3e cours 2, 3, 4 | 4, 10 | nouveau ; racine nouvelle `supinus (latin)` ; cours 2023-24 n°3 p. 3 et 5, n°4 p. 11 |
| **Olécrane** | 6 | — | nouveau ; racines nouvelles `ôlénê (grec)`, `kranion (grec)` ; cours 2023-24 n°4 p. 2, 3 et 11 (« olécrâne ») |

Laissés au membre inférieur (FC n°2), qui les emploie autant ou plus :
rétinaculum, épicondyle, sésamoïde.

## À relire

**1 carte `a-relire`**, en attente : `ms4-qc-aisselle`, la place du nerf
ulnaire et du cutané médial du bras dans l'aisselle, où le Ronéosaure, le cours
2023-24 et l'errata 2024-25 ne disent pas la même chose ; les cartes suivent la
référence. La figure 2026-27 p. 2 (2e cours) dessine l'ulnaire en pointillé,
sans montrer la veine. `ms4-qc-adducteur` a été relue le 19/10 sur le 3e cours
(p. 11) : son tag est retiré.

## Régénérer

```powershell
cd contenu\chapitres\anat_fc4
..\..\..\app\.venv\Scripts\python.exe generer.py
```

`generer.py` est la copie exacte de
`.claude/skills/nouveau-chapitre/scripts/generer_modele.py`.

## Questions pour Vincent

- (11/10) Biceps « supinateur accessoire » (p. 3, déjà dit en 2024-25 p. 4) : je l'ai classé ATTENTION (cours), et la carte répond « supinateur accessoire » à l'examen. Le professeur voulait-il dire que la supination est une action accessoire du biceps, à côté de la flexion, ou garde-t-on « point douteux » comme en 2024-25 ?
- (11/10) Supinateur à deux faisceaux « un latéral et un médial » (p. 6) : le professeur a-t-il dit « superficiel et profond », comme en 2023-24, ou décrivait-il son dessin, où les deux bandes sont côte à côte ?
- (11/10) Les épicondyliens médiaux (fléchisseur radial du carpe, long palmaire, fléchisseur ulnaire du carpe) ne sont ni sur le schéma 2026-27 de l'avant-bras ni dans le texte p. 6. Si le CM du 06/10 ne les reprend pas, faut-il passer ms4-qc-epicondyliens, ms4-qc-flechisseurs-carpe et ms4-fa-epicondyliens en « Absent du cours 2026-27 » ?
- (11/10) La planche à légender de l'avant-bras 2026-27 (ms4-pl-avant-bras-2627) est dans ce chapitre. Préfères-tu les planches des figures 2026-27 dans les chapitres de Schémas (anat_sch4) ? Faut-il en tirer une aussi de la vue antérieure du bras (p. 2), et un recto-verso « à redessiner » pour ces deux schémas d'examen ?
- (11/10) Sur la figure p. 5, le trait du fléchisseur profond des doigts n'a pas de légende. Le professeur l'a-t-il nommé au tableau ? La planche le compte comme n° 12.
- (11/10) Les cartes « consignes de dessin » (ms4-qc-examen-schema, ms4-rv-dessin-nerfs) et celles du canal brachial et du « nerf de la flexion » (ms4-qr-canal-brachial, ms4-qr-nerf-flexion) ne sont pas redites par le ronéo du 29/09. Faut-il les garder en attente, ou les passer en « Absent du cours 2026-27 » si les CM suivants n'en parlent pas ?
- (19/10) La loge hypothénar 2026-27 compte le court palmaire (CACO, p. 11), la FC4 2024-25 trois muscles : la carte dit les deux, sans genre. Le professeur compte-t-il le court palmaire comme un muscle de l'éminence à l'examen ?
- (19/10) L'opposant du pouce « sur le trapèze et le trapézoïde » (p. 10), « trapézoïde » déjà en 2024-25 : classé ATTENTION (cours), « À l'examen : le trapèze ». Faut-il plutôt le traiter en prise de notes, puisque le cours 2023-24 du même professeur dit le trapèze seul ?
- (19/10) Le dessin des os du carpe p. 7, titré « main gauche », a la disposition d'une main droite en vue antérieure : point douteux. Le professeur l'a-t-il titré ainsi au tableau ?
- (19/10) Les deux figures d'avant-bras de la p. 7 sont des planches d'atlas (légendes anglaises) : elles ne partent pas avec le chapitre. D'accord ?
- (19/10) Les épicondyliens médiaux sont maintenant au cours (p. 3, 4, 7) : la question du 11/10 sur leur absence est close.
