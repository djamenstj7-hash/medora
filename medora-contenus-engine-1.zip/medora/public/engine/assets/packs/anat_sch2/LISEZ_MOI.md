# Membre inférieur (Schémas n°2) — paquet Anatomie

22 notes, 22 cartes : 11 planches à légender (189 numéros, 74 intrus), un
recto-verso d'annale et 10 schémas à refaire sur papier. Source : le bloc
« Schémas n°2 (AC) - Membre inférieur » du **Ronéosaure 2024-25** (Pr
Demondion, 9 pages, 9 planches), fiche provisoire du chapitre en attendant le
ronéo 2026-27 ; l'annale 2022/2023 Session 1 du polycopié « Anatomie du membre
INF et SUP ». **Le Book Schéma 2025-26 du membre inférieur fait foi** depuis le
07/10 (Vincent) : ses schémas n° 16 à 25 sont les dessins de ce bloc, et les
planches qu'il corrige le citent à sa page (voir plus bas).

## Ce qu'il contient

| Type | Notes | Cartes |
|---|---|---|
| Planches à légender (`legend`) | 11 | 11 |
| Recto-verso (`basic`) | 11 | 11 |
| **Total** | **22** | **22** |

Dont 2 cartes d'annales (1 session : 2022/2023 S1) et 10 schémas à refaire
sur papier (tag `redessiner`, les n° 16 à 25 du Book, 18/10) : le fond vide du
Book en question, la correction en réponse, et l'on se note soi-même (su,
difficile, raté) selon le barème écrit dans l'explication. Aucun QCM, aucune zone,
aucun lexique : le plan des quatre chapitres du membre inférieur laisse les QCM,
les schémas cliquables et le lexique du genou, de la jambe et du pied à
`anat_fc2`, dont ces planches sont les figures. Chaque carte a sa correction
illustrée : le schéma légendé du bloc.

| Thème | Cartes |
|---|---|
| `vaisseaux-mi` — Artères et veines du membre inférieur | 4 (p. 1, 2, et leurs schémas à refaire) |
| `genou` — Le genou | 4 (p. 3, annale ×2, le schéma à refaire n° 18) |
| `loges-jambe` — Loges et muscles de la jambe | 4 (p. 4, 5, et leurs schémas à refaire) |
| `pied-cheville` — Pied et cheville | 6 (p. 6, 7, 8, et leurs schémas à refaire) |
| `territoires-mi` — Territoires sensitifs du membre inférieur | 4 (p. 9 ×2, et leurs schémas à refaire) |
| `orientation-schemas` — Titre et orientation des schémas | 1 (l'annale, en second tag) |

Les six clés sont celles du plan du membre inférieur, avec les mêmes libellés
dans les quatre chapitres ; elles manquent encore à `THEME_LABELS`
(`application/scopes.py`).

## Ce que le cours a dicté

- **L'examen est un schéma, et seulement un schéma** (avis du bureau dans
  l'errata du cours) : orienter un dessin, nommer deux à quatre structures
  fléchées, parfois donner le titre, puis compléter le dessin. D'où une planche
  par dessin, et **les deux flèches du repère orthogonal numérotées** dans
  chaque planche : « Haut », « Droite », « Avant »… sont dans la liste, avec
  leurs contraires en intrus. La note de chaque flèche explique la règle (vue
  postérieure : la gauche du sujet à gauche de l'image ; vue antérieure : sa
  droite à gauche ; coupe de scanner : vue par en dessous, l'avant en haut, la
  droite du patient à gauche).
- **La vue antérieure de la jambe (p. 5)** est le schéma que le professeur a dit
  pouvoir « tout à fait être celui présent durant les examens » (FC n°2, p. 6) :
  son explication le dit.
- **Le territoire sensitif (p. 9)** est « non susceptible de tomber selon le
  prof, mais important à connaître » ; les deux cartes le disent dans leur
  explication.
- « Schéma vu en 1ère année » (p. 1) et la phrase sous le titre de la p. 4 sont
  gardés sur la planche ; les autres phrases en italique des rédacteurs (p. 6, 8,
  9) sont retirées de la question : celle de la p. 6 nommait deux réponses.
- Le rouge du texte des FC est la convention de la ronéo pour les artères, pas
  un « à savoir » ; aucune fiche annotée par Vincent n'existe pour ce cours.

## Ce que les annales ont dicté

Un seul sujet du membre inférieur a pour planche un dessin de ce bloc :
**2022/2023 Session 1**, coupe transversale du genou droit (p. 3 du bloc). Il
fait deux cartes :

| Carte | Consignes | Forme |
|---|---|---|
| `ana-an-2223s1-q12` | 1. orienter ; 2. nommer les trois structures fléchées | planche : le dessin du sujet, flèches numérotées 3 à 5, repère 1 et 2 |
| `ana-an-2223s1-q3` | 3. compléter par les structures vasculaires et nerveuses | recto-verso : le dessin du sujet en question, la planche du cours en correction |

Le numéro de ce sujet se pose à la main (`mi-s2-an-2223s1-coupe.png`) : ses
flèches font partie de l'image, le script de planche n'a rien à lire. Les
repères sont dans `donnees.py`. Les deux sujets « S2 » du polycopié « Anatomie
du membre INF » sont les planches des Schémas n°1 (`anat_sch1`) ; l'autre sujet
du polycopié « INF et SUP » (région scapulaire) est du membre supérieur.

## Les planches

Fabriquées par `.claude/skills/nouveau-chapitre/scripts/planche_depuis_pdf.py`
(pymupdf), aperçus de contrôle relus un par un : aucune légende restée lisible,
chaque numéro au départ de son trait.

| Page | Carte | Numéros | Ce qui a demandé la main |
|---|---|---|---|
| 1 | `ana-pl-s2-genou-arteres` | 16 | `--effacer Haut --effacer Gauche --garder "Schéma vu en 1ère année"` ; cite le Book, schéma n° 16 (p. 45), même dessin et mêmes légendes |
| 2 | `ana-pl-s2-genou-profond` | 12 | seuls vaisseaux, nerfs et tendon du plantaire retirés (`--garder-motif` sur les 14 légendes de muscles et tendons, déjà cartées sur la vue postérieure de la région postérieure du genou, Schémas n°1 p. 16) ; cite le Book, schéma n° 17 (p. 46), une image du même dessin qui ne légende que ces dix structures |
| 3 → Book p. 47 | `ana-pl-s2-coupe-genou` | 25 | **refaite sur l'image du Book** (schéma n° 18), qui ajoute les veines petite et grande saphènes : `planche_depuis_image.py`, rectangles dans `donnees.py`, aperçu relu ; « Tibia » → « Fémur (extrémité distale) » dans la liste, « Tibia » en intrus ; « Veine petite saphène », intrus de la planche 2024-25, devient une légende (intrus « Ligament patellaire » à sa place) |
| 4 | `ana-pl-s2-jambe-insertions` | 16 | `--cote 3:droite` : le trait du repère touchait la légende du ligament collatéral latéral ; cite le Book, schéma n° 19 (p. 48), même dessin et mêmes légendes |
| 5 | `ana-pl-s2-jambe-anterieure` | 23 | le rétinaculum inférieur des extenseurs a deux numéros (deux branches) ; cite le Book, schéma n° 20 (p. 49), même dessin et mêmes légendes |
| 6 | `ana-pl-s2-pied-medial` | 17 | déjà numérotée par le ronéo : ses numéros, sa liste retirée ; le repère « Haut / Avant » reste imprimé ; le soulignement de la note retirée (un trait vectoriel, pas du texte) restait sous le dessin : effacé à la main dans `mi-s2-p6-pied-medial.png` (bande blanche, x = 270-770, y = 770-785, où rien d'autre n'est dessiné) ; cite le Book, schéma n° 21 (p. 50), même dessin, mêmes numéros et même liste |
| 7 → Book p. 51 | `ana-pl-s2-cheville-mediale` | 24 | **refaite sur l'image du Book** (schéma n° 22), qui ajoute la plante (triangle de Kager, artère et nerf plantaires latéraux, court fléchisseur des orteils, aponévrose plantaire) et légende de l'autre côté le nerf et l'artère plantaires médiaux ; le rétinaculum des fléchisseurs coupé a toujours deux numéros |
| 8 → Book p. 52 | `ana-pl-s2-pied-lateral` | 24 | **refaite sur l'image du Book** (schéma n° 23), qui ajoute les ligaments tibio-fibulaires antérieur et postérieur ; la phrase en italique des rédacteurs reste sur l'image (elle ne nomme rien) |
| 9 | `ana-pl-s2-territoires-anterieur`, `-posterieur` | 11 + 12 | deux dessins, deux repères : la page est coupée en deux à x = 490 pt avant le script, le titre commun et la phrase en italique retirés (le titre passe dans la carte) ; citent le Book, schémas n° 24 et 25 (p. 53), même dessin et mêmes légendes |

Les intrus viennent de la même région et du même cours, jamais d'une légende de
la planche ni d'un synonyme. Trois sont des pièges voulus : « Tibia » (p. 3,
l'erreur du bloc), « Nerf calcanéen latéral » (p. 9, l'erreur de la figure de la
FC n°2), « Phalange intermédiaire » (p. 6 : l'hallux n'en a pas).

## Le Book Schéma 2025-26, schéma par schéma

Le Book (`src-book-schema-mi-2526`, Ronéosaure 2025-26, 53 p. : fonds p. 4-27,
corrections p. 29-53) est déclaré à l'identique par `anat_sch1`, dont il est la
fiche ; ses schémas n° 1 à 15 sont là-bas. Chemin : `ANATOMIE/Book Schéma -
Membre inférieur.pdf` dans le dossier des PDF de l'application. Les
corrections ont été comparées à ce bloc par l'empreinte de leur image et par
leur texte.

| Schéma | Correction | Fond | Dans le chapitre |
|---|---|---|---|
| n° 16, vascularisation de la région postérieure du genou | p. 45, identique à la p. 1 (image et légendes) | p. 19 | `ana-pl-s2-genou-arteres`, `ana-rd-genou-arteres` |
| n° 17, vascularisation de la région profonde du genou | p. 46 : une image du dessin de la p. 2, qui ne légende que les vaisseaux, les nerfs et le tendon du plantaire (`mi-17-correction.png`) | p. 20 | `ana-pl-s2-genou-profond` (images 2024-25 gardées : les muscles légendés y complètent la correction), `ana-rd-genou-profond` |
| n° 18, coupe scanner par la fosse poplitée | p. 47 : une image de la coupe de la p. 3, plus les veines petite et grande saphènes ; elle légende toujours « Tibia » l'os de la coupe (`mi-18-correction.png`) | p. 21 | `ana-pl-s2-coupe-genou` (refaite sur l'image, 25 numéros), `ana-rd-coupe-genou` |
| n° 19, insertions de la jambe | p. 48, identique à la p. 4 | p. 22 | `ana-pl-s2-jambe-insertions`, `ana-rd-jambe-insertions` |
| n° 20, vue antérieure de la jambe | p. 49, identique à la p. 5 | p. 23 | `ana-pl-s2-jambe-anterieure`, `ana-rd-jambe-anterieure` |
| n° 21, vue médiale du pied | p. 50, identique à la p. 6 (numéros et liste compris) | p. 24 | `ana-pl-s2-pied-medial`, `ana-rd-pied-medial` |
| n° 22, dissection de la région médiale de la cheville | p. 51 : une image du dessin de la p. 7, complété de la plante (`mi-22-correction.png`) | p. 25 | `ana-pl-s2-cheville-mediale` (refaite sur l'image, 24 numéros), `ana-rd-cheville-mediale` |
| n° 23, vue latérale du pied | p. 52 : une image du dessin de la p. 8, plus les deux ligaments tibio-fibulaires (`mi-23-correction.png`) | p. 26 | `ana-pl-s2-pied-lateral` (refaite sur l'image, 24 numéros), `ana-rd-pied-lateral` |
| n° 24 et 25, territoires sensitifs, vues antérieure et postérieure | p. 53, identique à la p. 9 | p. 27, coupée en deux à x = 490 pt comme la planche (`mi-24-fond.png`, `mi-25-fond.png`) | `ana-pl-s2-territoires-anterieur` et `-posterieur`, `ana-rd-territoires-anterieur` et `-posterieur` |

Relecture du lot 3 par un sceptique (18/10) : les légendes, les rectangles
de la coupe, les fonds et les comptes des versos tiennent. Corrigé sur sa
remarque : la figure de la FC n°1 2025-26 (p. 19), qui dit aussi « Tibia »,
s'ajoute à la liste, et la carte dit ce qu'on écrit à l'examen (« fémur ») —
la règle « l'image fait foi » vise une diapositive du professeur, pas ce
dessin de l'équipe ronéo, fait sur les notes des étudiants (Book, p. 2) ; le
ligament collatéral médial, plus fin que le latéral ; l'artère tibiale
antérieure, au-dessus puis en avant de la membrane interosseuse ; des pages
trop larges pour ce qu'elles portent. Laissé tel quel : la planche n° 17
garde la légende imprimée « Muscle plantaire », qui n'indique pas lequel des
douze numéros est son tendon.

Relecture du lot 4 (n° 19 à 25) par un sceptique (18/10) : les légendes, les
rectangles des n° 22 et 23, les fonds et l'orientation tiennent. Corrigé sur sa
remarque :
- au n° 22, le Book appelle **latéraux** l'artère et le nerf plantaires que la
  planche 2024-25 disait médiaux, et nomme médiaux les branches antérieures :
  `ATTENTION` sur les deux numéros, à l'examen le Book ;
- le compte du n° 22 (vingt et une structures, le rétinaculum des
  fléchisseurs à deux endroits) ;
- les erreurs de la FC n°1 2025-26 et de sa suite que les cartes citaient sans
  les dire : le rétinaculum supérieur des fibulaires « le plus lésé » dans
  l'entorse (point douteux), le tibial antérieur sous le rétinaculum « des
  fibulaires » et sur le naviculaire, « le cuboïde médial et intermédiaire »
  pour les cunéiformes, 130° pour l'angle de Djian-Annonier ;
- l'intrus « Artère dorsale du pied » du n° 20, dessinée sans légende,
  remplacé par « Artère fibulaire » ;
- les cartes des schémas de 1re année disent que le professeur, en 2025-26,
  n'interrogerait pas sur les schémas vus en PASS (FC n°1 (suite) 2025-26,
  p. 2), et celles des territoires qu'il tenait « le schéma de l'innervation de
  l'année dernière » pour à savoir (p. 6) ;
- des citations mal placées (la phrase « non susceptible de tomber » vient du
  Book, pas de la FC n°2 2024-25).

Laissé tel quel : la coupe de la p. 27 à x = 490 pt tranche la phrase en
italique sous le titre, et le fond n° 25 n'a que la fin des pointillés du
titre.

Les citations de ces cartes nomment l'année : « FC n°1 2025-26 » (le
Ronéosaure 2025-26 traite la fosse poplitée et la coupe dans la FC n°1, p.
14-20), « FC n°2 2024-25 » pour ce bloc. La FC n°2 2025-26 est celle du membre
supérieur.

## Les clés qui ne sont pas reprises telles quelles

| Où | Imprimé | Retenu | Pourquoi |
|---|---|---|---|
| Annale 2022/2023 S1, trois flèches | aucune clé : la correction colle la planche du cours | gauche = biceps fémoral, droite = sartorius, bas = semi-tendineux ; repère Avant / Droite | clé déduite du cours (même contour que la p. 3), « absente de la table de corrections » ; l'ordre de la patte d'oie (sartorius, gracile, semi-tendineux d'avant en arrière) vérifié sur les références ; carte non officielle |
| Annale 2022/2023 S1, « complétez » | la planche du cours | artère poplitée (la plus profonde), veine poplitée, nerf tibial (le plus superficiel), nerf fibulaire commun contre le biceps, lymphonœuds | clé déduite de la planche et de la FC n°2, p. 5 ; non officielle |
| Planche p. 3, figure FC n°2 p. 4, correction de l'annale, correction du Book 2025-26 (schéma n° 18, p. 47), figure de la FC n°1 2025-26 (p. 19) | « Tibia » | **Fémur (extrémité distale)** | la coupe passe par la patella, qui ne s'articule qu'avec la trochlée du fémur (FC n°2, p. 4 ; références d'anatomie) ; ATTENTION nu dans la note du numéro, l'explication et la légende de la correction des trois cartes |

Retouches de forme dans la liste, sans changer le sens : « tibia postérieur »
→ « tibial postérieur » (p. 7), « Plan* » → « Plan » (p. 6), « calcanéo-
fibulaire » recollé (p. 8), « Artère et veine poplitée » → « poplitées »,
« Lymphonoeuds » → « Lymphonœuds », « Muscle Sartorius » → « sartorius »,
« 2ème Métatarsien » → « 2e métatarsien », « Cunéiforme médial » → « Os
cunéiforme médial », « Métatarsien 1 » → « 1er métatarsien ».

Les erratas du cours déjà appliqués dans ce bloc, et donc sans effet ici :
« artère tibiale antérieure » (la FC n°2 p. 7 disait « nerf »), « nerf
plantaire latéral » (la figure de la FC n°2 p. 13 dit encore « calcanéen
latéral » : la note du numéro 14 de la vue postérieure le rappelle). L'errata
des annales n'a aucune entrée pour ce sujet.

`contenu/ERRATA_RONEOS_2026-27.md` ne liste que les ronéos 2026-27 : l'erreur
« Tibia » du Ronéosaure n'y entre pas tant que le ronéo d'anatomie 2026-27
n'est pas paru.

## Le lexique

Aucun terme : le plan donne le lexique du membre inférieur aux chapitres des
FC n°1 et n°2.

## À relire

0 carte `a-relire`. Chaque numéro a été relu contre la planche du bloc, et la
clé de l'annale contre la p. 3.

Quand le ronéo d'anatomie 2026-27 paraîtra : vérifier que ses schémas sont les
mêmes dessins, déclarer sa fiche (`SOURCES`, `chapitre=`) et refaire les
planches qui ont changé.

## Le ronéo 2026-27 (relu le 19/10/2026)

Le seul ronéo 2026-27 du membre inférieur paru au 19/10, « TOPOGRAPHIE DU
MEMBRE INF 1 » (CM du 06/10/2026, Pr Herteleer), dessine la région glutéale,
l'articulation de la hanche et la région lombaire et inguino-pelvienne : ses
cinq figures sont devenues des planches du chapitre Schémas n°1 (`anat_sch1`).
**Il ne dessine ni le genou, ni la jambe, ni le pied.**

- **Absent du cours 2026-27** : aucune carte.
- **En attente des CM suivants** : les 22 notes, sur le bloc 2024-25 et le
  Book Schéma 2025-26, jusqu'au ronéo des CM du genou, de la jambe et du pied.

## Régénérer

```powershell
cd contenu\chapitres\anat_sch2
..\..\..\app\.venv\Scripts\python.exe generer.py
```

Les PNG de `media/` ne se régénèrent pas avec le paquet : ils sortent de
`planche_depuis_pdf.py`, page par page, avec les options du tableau des
planches ; la p. 9 passe d'abord par la découpe en deux, le sujet d'annale par
une numérotation à la main, et la p. 6 garde une retouche (le soulignement
effacé) à refaire si on la relance. La coupe du genou (`mi-18-numerotee.png`)
sort de `planche_depuis_image.py`, sur la p. 47 du Book rendue à 130 dpi
(`mi-18-correction.png`), avec les rectangles de `donnees.py` ; de même la
dissection de la cheville (`mi-22-numerotee.png`, sur la p. 51) et la vue
latérale du pied (`mi-23-numerotee.png`, sur la p. 52). Les fonds du Book
(`mi-16-fond.png` à `mi-25-fond.png`) sont ses pages 19 à 27 rendues à 130 dpi,
la p. 27 coupée en deux à x = 490 pt. Les images 2024-25 des p. 3, 7 et 8, que
plus aucune carte n'emploie, ont été retirées de `media/`.
